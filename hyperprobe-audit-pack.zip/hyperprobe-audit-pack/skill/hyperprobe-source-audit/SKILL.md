---
name: hyperprobe-source-audit
description: Deep, evidence-based secure source code audit of the HyperProbe / prodprobe monorepo (TypeScript backend + tRPC, gRPC broker, Node/Python/Java/Ruby agent SDKs, MCP server, VS Code extension, Prisma DB, license manager, Docker/Consul/Traefik infra). Use when auditing this repo (or a similar production-debugger/observability agent product) for security vulnerabilities, functional bugs, reliability/DoS, privacy/data-leak, supply-chain and AI/MCP risks — mapping findings to OWASP/ASVS/CWE/CERT-In with CVSS v3.1. Runs best as a multi-agent workflow under ultracode.
---

# HyperProbe Source Code Audit

A repeatable methodology for a rigorous, audit-grade secure source code review of the
HyperProbe (`prodprobe`) monorepo. It produces findings a maintainer can act on: each one has a
traced source→sink path, `file:line` evidence, a CVSS v3.1 score, a standards mapping, and a fix.

**Golden rule:** almost every high-severity bug here is a path where attacker-controlled data
reaches a dangerous operation and nothing on the way stops it. A scanner matches patterns; you trace
trust. A grep hit with no reachable source is a *candidate*, not a finding.

## Safety & authorisation (always)
- Review by **reading code** and building **local PoCs only**. Never attack, scan, or connect to any
  live/production HyperProbe deployment. Reading source ≠ authorisation to touch a running system.
- **Secrets are radioactive.** Found a live key/token/credential? Report that it exists at
  `file:line`, redacted to the first ~4 chars; never test it, never print it in full; recommend
  rotation. A secret in a public repo is compromised regardless of its power.
- **Do not run the repo's own build/install/postinstall/husky scripts** to "see what happens"
  without reading them first — a repo under review can carry hostile hooks. Run only in a disposable
  Docker lab, never against real infra.
- The demo repo `hp-test-payment-demo` is a **local lab target only** — never file findings on it.

## What this product is (why the risks are what they are)
HyperProbe is a **non-breaking production debugger**. Users/AI agents set "probes" on a line of
code; SDK agents embedded in the customer's **running production app** instrument that line and
capture local variables/stack/trace-id when hit. A probe carries a `condition` and
`watchExpressions` that the SDK **evaluates in-process in production**. Captured data flows back via
a gRPC broker → NATS → Postgres, and out to a dashboard, VS Code, and an **MCP server that feeds an
AI coding agent**.

So the crown-jewel risks are:
1. **Expression-evaluation sandbox escape / unsafe-mode** → RCE *inside the customer's prod app*.
2. **Unauthenticated/at-trusted gRPC broker** → cross-tenant probe leakage + telemetry forgery.
3. **Broken access control / multi-tenancy** in the tRPC control plane.
4. **Captured production data → AI agent** → prompt injection + secret/PII exposure.
5. **Host-app safety** — a debugger that can OOM/hang/deadlock production is a real defect.

## How to run it

Prefer a **multi-agent workflow** (`/effort ultracode`). A ready script is in this pack at
`workflow/hyperprobe-audit.js` — run, adapt, or author your own with this shape:

1. **Map** — fan-in agents build `audit/00-attack-surface-map.md`: entry points, sinks, trust
   boundaries, framework/lib versions, dependency inventory. See `references/component-map.md`.
2. **Review** — fan out, no agent cap, along two axes: **per component** and **per vulnerability
   class**. Each reviewer returns *structured candidates* (traced path + guard gap), not prose.
3. **Verify** — per candidate, 3 independent skeptics prompted to **refute**. Survives only if the
   path is real, reachable, and the guard is truly missing/wrong for that sink. Default to refuted
   when uncertain. Confirm with a local PoC where feasible.
4. **Chain & rank** — state the capability each survivor grants and what it unlocks chained; assign
   CVSS v3.1 + rating.
5. **Variant sweep** — after any finding, check sibling code for the same defect shape (the same
   mistake recurs). Loop 2–5 until two rounds add nothing new.
6. **Report** — one file per finding via `references/finding-template.md`, plus register, coverage,
   executive summary.

If not using a workflow: work the same phases sequentially, keeping a candidate ledger with
confidence scores, and still adversarially self-check each candidate before filing it.

## Where to look first (priority)
Detailed hunt list per area is in `references/component-map.md`; the class-by-class technique is in
`references/review-playbook.md`. In short:

1. **SDK evaluators + unsafe toggles** — `agents/python-sdk/.../core/evaluator.py`,
   `packages/node-sdk/src/core/inspector.ts`, `agents/java-sdk/hyperprobe-evaluator`,
   `agents/ruby-sdk/lib/hyperprobe/core/evaluator.rb`. Check sandbox correctness AND whether a
   server-delivered probe/config can flip `HYPERPROBE_DISABLE_SAFE_EVALUATION` (and peers).
2. **Access control** — `apps/backend/src/trpc.ts` + every router. Each object-load-by-id needs an
   ownership/tenancy guard; each procedure needs the right wrapper; watch `rawInput.serviceId`.
3. **gRPC broker** — `apps/logger/src/index.ts` (`createInsecure()`; trust of `call.request` fields).
4. **Auth/session** — `apps/backend/src/routers/authRouter.ts` (SSO `verifySso` incl. the e2e bypass,
   first-user-admin, `login:<identifier>` handoff, refresh binding, token secret).
5. **Infra** — `infra/prod/*` (Consul `-client=0.0.0.0`, Traefik `api.insecure=true` + `HostRegexp(.*)`,
   secrets in Consul KV, hardcoded DB creds, `.htpasswd`).
6. **Privacy/redaction**, **AI/MCP**, **DoS/host-safety**, **SSRF**, **crypto/secrets**,
   **supply chain/CI** — see the playbook.

## Output contract
Findings under `audit/findings/<category>/` where category is one of: `01-security`, `02-ai-mcp`,
`03-functional-bugs`, `04-reliability-dos`, `05-privacy-data`, `06-supplychain-infra`,
`07-code-quality`. One file per finding (`references/finding-template.md`), plus
`audit/findings-register.md` + `.csv`, `audit/coverage.md`, `audit/executive-summary.md`.

Every finding maps to **CWE + OWASP Top 10:2025** (+ API/LLM/MCP where it fits) **+ ASVS 5.0 +
CERT-In**, scored with **CVSS v3.1**. Standards links are in `references/standards.md`.

## Quality bar
- No finding without a traced, reachable path; label anything hypothetical as such.
- No impact inflation — a missing check is "critical" only when you show what it lets an attacker do.
- Never stop at the first finding or at the seed leads; sweep siblings. An empty scanner run is not a
  stop condition — it raises the priority of the authz/logic bugs only source review can find.
- Record negative results and coverage gaps honestly rather than implying completeness.

## References
- `references/component-map.md` — file-by-file hunt list and trust boundaries.
- `references/review-playbook.md` — class-by-class technique (authz, eval sandboxes, injection, SSRF,
  crypto, privacy, AI/MCP, DoS, supply chain), with what to grep and how to prove each.
- `references/standards.md` — OWASP/ASVS/CWE/CVSS/CERT-In/NIST links and the mapping cheat-sheet.
- `references/finding-template.md` — the exact per-finding format.
- `references/tools.md` — SAST/SCA/secret/CI scanners with commands (accelerators, not oracles).
