# Component Map & Hunt List

Trust boundaries (most dangerous first):
1. **Agent ⇆ Logger (gRPC)** — broker hands probe definitions (source paths + expressions) to agents
   in production apps and receives captured data.
2. **User ⇆ Backend (tRPC)** — RBAC over services/teams/probes/snapshots; multi-tenant isolation.
3. **Probe expression ⇆ SDK evaluator** — a probe's `condition`/`watchExpressions` run in-process in prod.
4. **Captured data ⇆ MCP ⇆ AI agent** — snapshot payloads (possible secrets/PII) reach an AI agent.
5. **Backend/services ⇆ Consul/Traefik/NATS** — config + secrets in Consul; Traefik routing.

---

## Backend control plane — `apps/backend/src`
- `trpc.ts` — auth wrappers: `authProcedure`, `licensedProcedure`, `adminProcedure`,
  `serviceLeadProcedure`, `serviceMemberProcedure`; `hasServiceLeadAccess`/`hasServiceMemberAccess`
  read `serviceId` from **`rawInput`**. Verify: does the gated `serviceId` always match the object
  actually operated on? Missing = IDOR.
- `index.ts` — `createContext` verifies the JWT and sets `ctx.user`; token secret from
  `SystemConfig.tokenSecret` (a per-deploy `crypto.randomUUID()`); CORS `origin:true` + `credentials:true`;
  Prisma `query` debug logging; static/proxy dashboard; license public key bootstrap from env/Consul.
- `routers/authRouter.ts` — `verifySso` (RSA `publicDecrypt` of "encrypted email token", 60s tolerance,
  **`HYPERPROBE_ENV==='e2e'` raw-JSON bypass**, first-user→admin), `pollLogin`/`authorizeVsc`
  (`login:<identifier>` handoff in Redis, unauthenticated poll), `refresh`/`refreshAuthToken`
  (`sessionSecret` binding), `revokeUserSessionSecret`, `me`.
- `routers/probesRouter.ts` — `createProbe`/`deleteProbes`/`toggleProbeStatus`/`listSnapshots`/
  `listLogs`/`listProbes`/`getProbesCount`; **`resolveRuntimeLocation` is public (`t.procedure`)**.
  Check per-service authz on each, and the snapshot/log service-scope filter.
- `routers/servicesRouter.ts`, `teamsRouter.ts`, `usersRouter.ts` — admin vs serviceLead gating;
  `usersFlatRouter.getUserCount` is public; mass-assignment on create/update inputs.
- `routers/rcaRouter.ts` (1.4k lines) + `routers/observabilityIntegrationsRouter.ts` — provider config,
  connection secrets, `serviceMemberProcedure` gating, Sentry query building.
- `observability/` — `sentryAdapter.ts`/`rca/sentryExploreClient.ts` (SSRF allowlist:
  https-only, no creds/query/fragment, host allowlist — check redirect handling & bypass),
  `credentialCipher.ts`/`credentialKeyring.ts` (crypto: KDF, IV/nonce, key in Consul, rotation scripts),
  `redaction.ts` (regex correctness/ReDoS), `requestCoordinator.ts` (Redis Lua `eval`).
- `license/` — `licenseRouter.ts`, `heartbeat.ts`, `phase2.ts` (`jwt.verify ES256`); `cron/` jobs.

## Data plane
- `apps/logger/src/index.ts` — **`grpc.ServerCredentials.createInsecure()`**; `getProbes` trusts
  `call.request.{serviceId,agentId,environment,commitSha}`; license gating; Redis liveness/limits with
  `multi()` (race?); `UploadSourceMap` streaming with 20MB/100MB caps and metadata-consistency checks;
  `ReportTelemetry`.
- `apps/logger-consumer/src/index.ts` — pulls from NATS, writes snapshots to Postgres; trust of message
  content; error handling; Redis `multi`.
- `packages/database` — Prisma schema, migrations (RBAC init, refactor_auth), cascade deletes on probe,
  indexes, `SystemConfig`, `SourceMap` unique key.

## Agent SDKs (run inside customer production)
- **Node** `packages/node-sdk/src/core/inspector.ts` — `Debugger.evaluateOnCallFrame` with
  `throwOnSideEffect:true`, `objectGroup`; `evaluation-utils.ts` `wrapExpressionsForEvaluation` (can it
  defeat side-effect blocking?); `safeStringify`, serialization caps; `source-map-uploader.ts`;
  `quota.ts`, `safety.ts`, `broker.ts`, `lambda.ts`.
- **Python** `agents/python-sdk/hyperprobe/core/evaluator.py` — `ast.parse` + `SafeASTVisitor` +
  `SAFE_BUILTINS` + 256-char cap; `_compile_unsafe`; `is_safe_evaluation_enabled()` keyed on
  `HYPERPROBE_DISABLE_SAFE_EVALUATION`; `monitoring_engine.py` re-reads the toggle from a config snapshot
  (`_is_safe_evaluation_enabled(config_snapshot)`) — **trace where config_snapshot comes from**;
  `serializer.py`, `safety.py`, `agent.py`.
- **Java** `agents/java-sdk/hyperprobe-evaluator` — `MvelEvaluator` + `SafeASTValidator` +
  `CompiledExpressionCache`; `hyperprobe-serializer` `ObjectGraphLimiter`/`RedactionFilter`/`SafeJsonSerializer`;
  `hyperprobe-instrumentation` (ASM `ProbeClassTransformer`, `LocalVariableExtractor`).
- **Ruby** `agents/ruby-sdk/lib/hyperprobe/core/evaluator.rb` — `Binding.instance_method(:eval)`,
  `safe_ast_validator.rb`, `lexical_scope.rb`, `serializer.rb`, `safety.rb`, `monitoring_engine.rb`.
- Parity check: the four evaluators and their toggles should enforce equivalent guards; a gap in one is
  a finding.

## Clients & tooling
- **MCP server** `packages/mcp-server/src/index.ts` — tool defs; `list_snapshots`/`wait_for_snapshot`
  return captured vars/stack as JSON to the AI agent (injection + data exposure); `auth.ts`
  (`HYPERPROBE_ACCESS_TOKEN`, cached refresh token file `~/.hyperprobe/auth.json` `0o700`, background
  refresh); `service-config.ts` (`execFile`); `skills.ts` (`execSync('git rev-parse HEAD')`).
- **VS Code extension** `apps/vsc-extension/src/extension.ts` — webview CSP (note `'unsafe-eval'` in the
  dev CSP branch), `onDidReceiveMessage` cases, token storage (`utils/TokenManager.ts`),
  `child_process` git; `webview-ui/` Vue app (`localStorage`, any `v-html`).
- **Dashboard** `apps/dashboard/app` — `composables/useAuth.ts` (tokens in `localStorage`, storage-event
  sync), `middleware/auth.global.ts`, `utils/token.ts`/`initialRelay.ts`, tRPC client, any `v-html`.

## Licensing & shared
- `external/licensing-server/src/handler.ts` + `phase2.ts` — Firebase Admin creds from env, `ES256`
  signing, heartbeat/relay phases, input validation of `body`.
- `packages/common/src/license/LicenseManager.ts` — `jwt.verify(token, key, {algorithms:['ES256'],
  ignoreExpiration:true})`; status (LOCKED/REVOKED/…); `setBootstrapPublicKey`; snapshot handling.

## Infra & CI
- `infra/prod/docker-compose.prod.yml` — Consul `-client=0.0.0.0` + Traefik router `HostRegexp(.*)`;
  Traefik `--api.insecure=true`; `LICENSE_PUBLIC_KEY` + DB/Redis/NATS URLs written to Consul KV; Postgres
  `user:password`; `.htpasswd` committed; NATS `max_payload 64MB`.
- `infra/docker-compose.yml` (dev) — same KV bootstrap, `LOG_LEVEL debug`.
- `Dockerfile` — `node:25-alpine`, global `prisma`, engine cleanup.
- `build.sh`, `.husky/pre-commit`/`commit-msg`, publish scripts (`publish_*.sh`), `.github/workflows/`
  (`release.yml` self-hosted runner + publish secrets; `google-chat-notifications.yml` PR-triggered +
  Gemini/webhook secret). Lockfiles: `pnpm-lock.yaml`, `agents/*/…` (pip/maven/gem) for CVEs & confusion.
