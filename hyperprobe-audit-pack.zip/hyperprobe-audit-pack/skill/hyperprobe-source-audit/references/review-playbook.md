# Review Playbook — class by class

For each class: what to hunt, what to grep, and how to *prove* it. A proof is a traced path (source
→ sink) + the guard gap + reachability, ideally a local PoC. Refute anything you can't prove.

---

## 1. Broken access control / IDOR / multi-tenancy  (highest yield)
**Hunt:** every tRPC procedure and every gRPC RPC; every object loaded by a user-supplied id.
**Prove:** show a lower-privileged actor (or another tenant) reaching an object/action they shouldn't.
- Enumerate procedures and their wrappers (`t.procedure` vs `authProcedure` vs `adminProcedure` vs
  `serviceLead/Member`). Any `t.procedure` that returns or mutates tenant data is suspect.
- For `serviceLeadProcedure`/`serviceMemberProcedure`: the guard uses `rawInput.serviceId`. Find any
  resolver where the object's real `serviceId` can differ from the one checked (pass a service you
  lead; act on an object in another). That's IDOR (CWE-639).
- `listSnapshots`/`listLogs`/`listProbes`: confirm results are filtered to the caller's permitted
  services, not just by `probeId`/`serviceIds` from input.
- Mass assignment (CWE-915): check create/update Zod schemas can't set `role`/`isAdmin`/permission
  fields. `getPermissionsObj` derives admin from `team.isAdminTeam` — can a user join/craft that?

## 2. Expression-evaluation sandboxes  (crown jewels — RCE in prod)
**Hunt:** the four SDK evaluators + their unsafe toggles + the config path that could flip them.
**Prove:** a probe expression that executes code / reads files / crashes the host, in that SDK's harness.
- **Toggle reachability (do this first):** trace `HYPERPROBE_DISABLE_SAFE_EVALUATION` /
  `disable_safe_evaluation` / `safe_evaluation` from where it's read (`evaluator.py`,
  `monitoring_engine.py` `_is_safe_evaluation_enabled(config_snapshot)`, and Node/Java/Ruby peers) back
  to its source. If a **server-delivered probe or `AgentGlobalConfig`** can set it, that is remote RCE
  in every customer app — Critical. If it's strictly a local env var the operator sets, it's a
  documented foot-gun — still report, lower severity.
- **Python safe mode:** `SafeASTVisitor` + `SAFE_BUILTINS`. Try `__class__`/`__mro__`/`__subclasses__`,
  attribute access on literals, comprehensions/generators, walrus, f-strings, `__builtins__` recovery,
  and the 256-char boundary. Grep: `ast.parse`, `SAFE_BUILTINS`, `visit_`.
- **Node safe mode:** `evaluateOnCallFrame` `throwOnSideEffect:true`. Confirm
  `wrapExpressionsForEvaluation` can't wrap an expression so a side effect slips past; check the
  `silent:true` code path and watch-vs-condition parity. Getters with side effects? Grep:
  `throwOnSideEffect`, `wrapExpressionsForEvaluation`.
- **Java MVEL:** `SafeASTValidator`. Try reflection (`getClass`, `Class.forName`), `Runtime`, static
  method/field access, MVEL template escapes, `with{}`. Grep: `MVEL.executeExpression`, `SafeASTValidator`.
- **Ruby:** `binding.eval` + `safe_ast_validator.rb`. Try backticks, `system`/`exec`, `send`/`__send__`,
  `const_get`, `Kernel`, `ObjectSpace`, string interpolation. Grep: `BINDING_EVAL`, `instance_method(:eval)`.
- **Parity:** all four must enforce equivalent guards. A gap in one SDK is a finding.
- **Timeouts:** an expression that loops forever must not wedge the host thread (ties to DoS §8).

## 3. gRPC broker trust
**Hunt:** `apps/logger/src/index.ts`. **Prove:** an unauthenticated/forged client obtaining probes or forging telemetry.
- `ServerCredentials.createInsecure()` — is auth done at the app layer (metadata token) or at Traefik
  (mTLS/`h2c`)? If neither, any gRPC client that reaches the port is trusted.
- `getProbes` trusts `serviceId`/`agentId` from `call.request`. Can you enumerate services and pull
  their probe sets (revealing source file paths + expressions)? (CWE-306, CWE-862, CWE-200.)
- `ReportTelemetry`/consumer: is snapshot content validated, or can forged snapshots be injected into a
  tenant's data (feeding the dashboard/AI agent)? (CWE-345.)

## 4. Authentication / session / JWT
- Token secret: per-deploy `randomUUID()` in `SystemConfig`; algorithm pinned on verify; refresh bound
  to `sessionSecret` (revocation works?). Grep: `jwt.sign`, `jwt.verify`, `sessionSecret`.
- SSO `verifySso`: RSA `publicDecrypt` design; 60s tolerance replay window; the
  `NODE_ENV!=='production' && HYPERPROBE_ENV==='e2e'` raw-JSON branch — can it run in a real deploy?
  first-user→admin when `userCount==0` (race, or attacker-triggerable on a fresh/wiped DB?).
- `login:<identifier>` handoff: entropy/origin of `identifier`; can one client poll another's tokens?
- License JWT: `jwt.verify(..., {algorithms:['ES256'], ignoreExpiration:true})` — is ignoring
  expiration intended, and what does forgery unlock (agent limits, shutdown gating)?

## 5. Injection & sinks (server)
- Prisma: no `$queryRaw`/`$executeRaw` with interpolation (grep). Redis Lua `eval`: script bodies are
  constants, keys/args validated (`requestCoordinator.ts`).
- `child_process`/`execFile`/`execSync`: args not attacker-controlled (`mcp-server/service-config.ts`,
  `mcp-server/skills.ts`, `vsc-extension/extension.ts`). Grep: `exec`, `execFile`, `execSync`, `spawn`.
- Path/filename handling on source-map `fileName` — used in any FS path or DB key? (CWE-22.)
- ReDoS on untrusted input in redaction/sentry filters (CWE-1333).
- superjson/BigInt/JSON handling → prototype pollution/type confusion (CWE-1321).

## 6. SSRF & outbound
- Sentry `apiBaseUrl` allowlist (`sentryExploreClient.ts` `assertAllowedBaseUrl`): https-only, no
  creds/query/fragment, host in allowlist. Check DNS-rebinding/redirect following and whether the
  cursor/pagination URL construction can escape the base. Any other provider URL validated the same?

## 7. Privacy / captured-data
- Redaction actually blocks secrets/PII before capture/storage/display: backend `redaction.ts`, SDK
  `RedactionFilter`/serializers. Test with keys/tokens/PAN/emails. (CWE-201/312.)
- Snapshot depth/size caps enforced (`ObjectGraphLimiter`, node `safeStringify`) — no full-object leak.
- Cross-tenant snapshot visibility (ties to §1). Debug SQL param logging in prod (`index.ts`).
- Data reaching the AI agent is redacted (ties to §9).

## 8. Reliability / DoS — HOST-APP SAFETY is paramount
- Serialization depth/size/time caps prevent OOM/hang in the customer's prod process.
- Inspector/instrumentation can't pause or deadlock production threads (node inspector session; java ASM).
- Expression-eval timeouts (a pathological `condition` must not wedge the host).
- Quota/rate limiting on capture; unbounded probe hits; broker/consumer queue backpressure; NATS 64MB.
- (CWE-770/674/834/833/1333, OWASP A10.)

## 9. AI / MCP
- `list_snapshots`/`wait_for_snapshot` return captured **production values** to the AI coding agent as
  text. Those values can contain attacker-influenced strings → **prompt injection / tool-output
  poisoning** (OWASP LLM01, MCP03/MCP10). Are they sanitised/framed as untrusted data?
- Secrets/PII in those values reaching the agent (LLM02/MCP10; ties to §7).
- MCP token handling (`auth.ts`): scope/least-privilege of `HYPERPROBE_ACCESS_TOKEN`, refresh-token
  file perms, token in logs (MCP01/MCP07).
- Tool/description poisoning; server identity trust (MCP03). `execSync`/`execFile` context (MCP05).

## 10. Crypto & secrets
- Hardcoded secrets/keys in code/compose/.env/.htpasswd (CWE-798). Credential cipher: KDF, IV/nonce
  uniqueness, mode (`credentialCipher.ts`). Crypto RNG for tokens/identifiers (CWE-338).
- License signing trust anchor (public key in Consul KV → forge licenses if KV is writable).

## 11. Supply chain & CI
- Dep CVEs across npm/pip/maven/gem → map each to CVE/GHSA (OSV-Scanner/Trivy/pip-audit/bundler-audit/
  dependency-check). Dependency confusion on `@hyperprobe/*` (registry scoping in `.npmrc.example`).
- Hostile/blocking install & build hooks — read `build.sh`, `.husky/*`, publish scripts, postinstall
  before running anything (CWE-829).
- GitHub Actions: action pinning by SHA, PR-triggered jobs not running untrusted PR-head code with
  secrets, self-hosted runner hardening, secret handling (`zizmor`, `actionlint`).

## 12. Error handling & logic
- Fail-closed on auth/license/redaction/self-serve fallbacks (e.g. `getIsSelfServeEnabled` returns
  cached/false on Consul error — is that safe?). Swallowed exceptions masking failures. Races/TOCTOU on
  probe counters (`probe:hits`/`probe:limit`) and license locks. Unhandled promise rejections. (A10, CWE-703/362/755.)
