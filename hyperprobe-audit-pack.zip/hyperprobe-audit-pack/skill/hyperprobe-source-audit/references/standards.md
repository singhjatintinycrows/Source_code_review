# Standards & Mapping Cheat-Sheet

Map every finding to **CWE + OWASP + ASVS 5.0 + CERT-In**, score with **CVSS v3.1**. Links verified 2026-09.

## Quick mapping by defect type
| Defect | CWE | OWASP 2025 | API 2023 | ASVS 5.0 |
|---|---|---|---|---|
| Missing/ broken authorization, IDOR | CWE-862 / 863 / 639 / 284 | A01 | API1 / API5 | V8 |
| Broken auth / session / JWT | CWE-287 / 384 / 347 / 613 | A07 | API2 | V6, V7, V9 |
| Code/expression injection (eval sandbox) | CWE-94 / 95 | A05 (A06 design) | — | V1, V2 |
| OS command injection | CWE-78 / 77 | A05 | — | V1 |
| SQL injection | CWE-89 | A05 | — | V1 |
| Path traversal / upload | CWE-22 / 434 | A05 | — | V5 |
| SSRF | CWE-918 | A05 | API7 | V4 |
| Deserialization / integrity | CWE-502 / 345 | A08 | API10 | V1 |
| Sensitive data exposure / logging | CWE-200 / 201 / 312 / 532 | A09 | API3 | V14, V16 |
| Crypto / secrets | CWE-798 / 327 / 326 / 330 / 338 | A02/A04 | API8 | V11 |
| Missing auth for critical function | CWE-306 | A07 | API2 | V6 |
| Resource exhaustion / DoS | CWE-770 / 674 / 834 / 400 | A10 | API4 | V2 |
| Race / TOCTOU | CWE-362 / 367 | A10 | API6 | V2 |
| Improper error handling / fail-open | CWE-703 / 755 / 391 | A10 | — | V16 |
| Security misconfiguration (infra) | CWE-16 / 668 / 942 / 250 | A02 | API8 | V13 |
| Vulnerable/abandoned deps, supply chain | CWE-1395 / 1104 / 829 / 427 | A03 | — | V13 |
| Prompt injection (AI) | CWE-77 (analogue) | — | — | OWASP LLM01 |
| MCP token/tool/context risk | — | — | — | OWASP MCP01/03/07/10 |

## Standard links
- **OWASP Top 10:2025** — https://top10.owasp.org/2025/
- **OWASP API Security Top 10:2023** — https://owasp.org/API-Security/editions/2023/en/0x11-t10/
- **OWASP ASVS 5.0** — https://owasp.org/www-project-application-security-verification-standard/ · https://github.com/OWASP/ASVS/tree/v5.0.0
- **OWASP LLM Top 10 (2025)** — https://genai.owasp.org/llm-top-10/
- **OWASP MCP Top 10 (2025, beta)** — https://owasp.org/www-project-mcp-top-10/ · cheat sheet https://cheatsheetseries.owasp.org/cheatsheets/MCP_Security_Cheat_Sheet.html
- **CWE Top 25 (2025)** — https://cwe.mitre.org/top25/archive/2025/2025_cwe_top25.html · full https://cwe.mitre.org/
- **CVSS v3.1** — spec https://www.first.org/cvss/v3.1/specification-document · calc https://www.first.org/cvss/calculator/3.1
- **CERT-In** — Secure App Guidelines (2023) https://www.cert-in.org.in/PDF/Application_Security_Guidelines.pdf ·
  Comprehensive Audit Policy (Jul 2025) https://www.cert-in.org.in/PDF/Comprehensive_Cyber_Security_Audit_Policy_Guidelines.pdf ·
  SBOM/QBOM/CBOM/AIBOM/HBOM v2.0 https://www.cert-in.org.in/PDF/TechnicalGuidelines-on-SBOM,QBOM&CBOM,AIBOM_and_HBOM_ver2.0.pdf ·
  OEM/Tech-Provider AI-vuln guidelines (2026) https://www.cert-in.org.in/PDF/OEM_and_Technology_Providers_Guidelines.pdf
- **ISO/IEC 27001:2022** — https://www.iso.org/standard/27001 (Annex A.8.25–A.8.31 secure development)
- **NIST SSDF SP 800-218 v1.1** — https://csrc.nist.gov/pubs/sp/800/218/final (v1.2 is draft as of Dec 2025)
- **MITRE ATT&CK** — https://attack.mitre.org/

## CVSS v3.1 rating bands
0.0 None · 0.1–3.9 Low · 4.0–6.9 Medium · 7.0–8.9 High · 9.0–10.0 Critical.
Always record the full vector, e.g. `CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:C/C:H/I:H/A:H`.
