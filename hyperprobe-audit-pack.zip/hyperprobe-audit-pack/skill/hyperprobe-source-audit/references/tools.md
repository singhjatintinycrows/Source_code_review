# Tools — accelerators, not oracles

Run to triage; then hand-verify every hit with a traced path. Never file a raw scanner hit as a
finding. Read any install/build hook before executing it; run untrusted code only in a disposable lab.

## SAST / dataflow
```bash
pipx install semgrep
semgrep --config p/default --config p/owasp-top-ten \
        --config p/javascript --config p/typescript \
        --config p/python --config p/java --config p/ruby --config p/secrets .
pipx install bandit && bandit -r agents/python-sdk
gem install brakeman   # if any Rails-ish surface
# CodeQL (deep dataflow) for js/ts, python, java, ruby where budget allows
```

## Secrets (also scan git history if you have the clone)
```bash
gitleaks detect --source . --report-path gitleaks.json --redact
trufflehog filesystem . --only-verified
```
On any hit: report existence + `file:line`, redacted; recommend rotation; do NOT test the secret.

## SCA / dependency CVEs
```bash
osv-scanner scan --recursive .
trivy fs --scanners vuln,secret,misconfig .
trivy config .
pnpm audit || npm audit
pip-audit -r agents/python-sdk/requirements.txt   # and setup.py deps
bundler-audit check --update       # ruby-sdk
# OWASP Dependency-Check for the Java SDK (maven)
```
Map each confirmed vulnerable version to a CVE/GHSA (osv.dev, github.com/advisories). Check
dependency-confusion exposure for `@hyperprobe/*` and internal packages.

## CI/CD & containers
```bash
pipx install zizmor && zizmor .github/workflows/
actionlint
hadolint Dockerfile
```

## Claude Code security assets to layer in
- `/security-review` command / Action — https://github.com/anthropics/claude-code-security-review
- Trail of Bits skills — `/plugin marketplace add trailofbits/skills` (audit-context-building,
  static-analysis, fp-check, insecure-defaults, sharp-edges, variant-analysis, supply-chain-risk-auditor).
- Anthropic skills — `/plugin marketplace add anthropics/skills`.

## Local dynamic lab (only if you need runtime confirmation)
- Use `infra/docker-compose.yml` to stand up Postgres/Redis/NATS/Consul locally, and the
  `hp-test-payment-demo` repo as an SDK target. Keep it fully isolated; never point an agent at real
  infrastructure. Prove sandbox escapes inside each SDK's own test harness (`agents/*/tests`, `spec/`,
  `src/**/*.test.ts`) rather than against production.
```
