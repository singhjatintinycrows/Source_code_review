# Control Checklist — HyperProbe Source Code Audit

Work through every item. Mark **Status** as `Done` / `Partial` / `N/A` / `Not covered`, record `file:line`
evidence, and open a finding (with the ID prefix shown) where a control fails. This is the Markdown
mirror of the Excel tracker (`templates/hyperprobe-findings-tracker.xlsx`, "Checklist" sheet).

Legend for mappings: **OWASP** = OWASP Top 10:2025 · **API** = API Sec Top 10:2023 · **ASVS** = ASVS 5.0 chapter ·
**CWE** = CWE ID · **CERT-In** = CERT-In secure-app guideline area. Severity is assigned per finding via CVSS v3.1.

---

## A. Access control & multi-tenancy  → findings `SEC-`
| # | Check | Where | Map | Status |
|---|---|---|---|---|
| A1 | Every tRPC procedure has the correct auth wrapper (public vs auth vs licensed vs admin vs serviceLead vs serviceMember) | `apps/backend/src/trpc.ts`, all routers | OWASP A01 / API5 / ASVS V8 / CWE-862 | |
| A2 | `serviceId`-scoped middleware can't be bypassed by omitting/forging `serviceId` in `rawInput` | `trpc.ts` hasServiceLeadAccess/MemberAccess | A01 / API1 / CWE-639 | |
| A3 | Object loads by id (probe, service, snapshot, log, user, team, connection) enforce ownership/tenancy | probesRouter, servicesRouter, rcaRouter, observability… | A01 / API1 / CWE-639 / CWE-284 | |
| A4 | `listSnapshots`/`listLogs`/`listProbes` filter by the caller's permitted services, not just by id | `probesRouter.ts` | A01 / API1 / CWE-200 | |
| A5 | Admin-only mutations (users/teams/service access) truly require admin | usersRouter, teamsRouter, servicesRouter | A01 / API5 / CWE-862 | |
| A6 | No mass assignment: role/permission/isAdmin can't be set through create/update inputs | all create/update Zod schemas | A01 / CWE-915 | |
| A7 | Unauthenticated procedures (`verifySso`, `pollLogin`, `refresh*`, `getUserCount`, `resolveRuntimeLocation`) leak nothing sensitive & can't be abused | authRouter, probesRouter, usersRouter | A01 / API1 | |
| A8 | `pollLogin`/`login:<identifier>` handoff can't let one user retrieve another's tokens (identifier entropy & binding) | `authRouter.ts` | A07 / CWE-384 / CWE-639 | |

## B. Authentication, session & JWT  → `SEC-`
| # | Check | Where | Map | Status |
|---|---|---|---|---|
| B1 | Token secret sourcing & strength; not predictable, rotates safely; single per-deploy `randomUUID` acceptable | `index.ts`, `helpers/tokenSecret.ts` | A07 / ASVS V9 / CWE-330 | |
| B2 | JWT verify pins algorithm; no `alg:none`/confusion; refresh bound to `sessionSecret` | authRouter, `index.ts` createContext | A07 / CWE-347 | |
| B3 | SSO `verifySso`: RSA `publicDecrypt` design, 60s tolerance, replay, and the `HYPERPROBE_ENV==='e2e'` JSON-token bypass can't run in prod | `authRouter.ts`, `helpers/decryptSsoToken.ts` | A07 / CWE-287 / CWE-294 | |
| B4 | First-user-becomes-admin flow can't be triggered by an attacker (race / when userCount==0) | `authRouter.ts` verifySso | A07 / CWE-306 | |
| B5 | Access/refresh token lifetimes, revocation (`revokeUserSessionSecret`), and logout semantics | authRouter | A07 / ASVS V7 | |
| B6 | Dashboard token storage in `localStorage` — XSS blast radius | `apps/dashboard/app/composables/useAuth.ts` | A07 / CWE-522 | |

## C. gRPC broker & agent channel  → `SEC-` / `DOS-`
| # | Check | Where | Map | Status |
|---|---|---|---|---|
| C1 | Is the gRPC server authenticated? (`ServerCredentials.createInsecure()`) — can any client call RPCs? | `apps/logger/src/index.ts` | A02/A07 / CWE-306 / CWE-319 | |
| C2 | `GetProbes` authZ: can a forged `agentId`/`serviceId` pull another tenant's probe set (source paths + expressions)? | logger GetProbes | A01 / CWE-862 | |
| C3 | `ReportTelemetry` trust: is snapshot/log content validated; can it be forged/poisoned? | logger + consumer | A08 / CWE-345 | |
| C4 | Source-map upload: size/zip-bomb caps, path/filename handling, metadata consistency | logger UploadSourceMap | A10 / CWE-409 / CWE-22 | |
| C5 | TLS/transport confidentiality of agent↔broker in prod (Traefik `h2c` scheme) | infra + logger | A02 / CWE-319 | |

## D. Probe expression evaluation (all SDKs)  → `SEC-` (crown jewels)
| # | Check | Where | Map | Status |
|---|---|---|---|---|
| D1 | Python `ast` allowlist (`SafeASTVisitor`, `SAFE_BUILTINS`) blocks dunder/attribute-escape/`__builtins__` recovery | `python-sdk/.../core/evaluator.py` | A03/A05 / CWE-94/95 | |
| D2 | Node `evaluateOnCallFrame` uses `throwOnSideEffect`; expression wrapping can't defeat it | `node-sdk/.../core/inspector.ts`, `evaluation-utils.ts` | A05 / CWE-94 | |
| D3 | Java MVEL `SafeASTValidator` blocks reflection/`Runtime`/class loading; template sandbox holds | `java-sdk/hyperprobe-evaluator` | A05 / CWE-94 | |
| D4 | Ruby `binding.eval` + `safe_ast_validator.rb` blocks backticks/`system`/`send`/const access | `ruby-sdk/.../core/evaluator.rb` | A05 / CWE-94 | |
| D5 | "Unsafe" toggle (`HYPERPROBE_DISABLE_SAFE_EVALUATION`, `disable_safe_evaluation`, config flags): who can set it? Can a server-delivered probe/config flip it? Is it loudly warned & off by default? | all four SDKs + broker config | A05/A06 / CWE-94 / CWE-1188 | |
| D6 | Evaluation parity: the same guard exists and is equally strong across all four SDKs | all SDKs | A06 / CWE-1188 | |
| D7 | Log-template evaluation is as safe as condition evaluation | evaluators (`evaluate_log_template`) | A05 / CWE-94 | |

## E. Injection & sinks (server side)  → `SEC-`
| # | Check | Where | Map | Status |
|---|---|---|---|---|
| E1 | No raw SQL / `$queryRaw` with interpolation; Prisma inputs typed | backend routers, database | A05 / CWE-89 | |
| E2 | Redis Lua `eval` scripts take no untrusted script body; keys/args validated | `observability/requestCoordinator.ts` | A05 / CWE-94 | |
| E3 | `child_process`/`execFile` calls take no untrusted args | mcp-server `service-config.ts`, vsc-extension `extension.ts` | A05 / CWE-78 | |
| E4 | Regex on untrusted input isn't ReDoS-prone | sentryExploreClient filters, redaction | A10 / CWE-1333 | |
| E5 | JSON/`superjson`/BigInt handling can't be abused (prototype pollution, type confusion) | trpc transformer, consumer | A08 / CWE-1321 | |

## F. SSRF & outbound  → `SEC-`
| # | Check | Where | Map | Status |
|---|---|---|---|---|
| F1 | Sentry `apiBaseUrl` allowlist enforced (https-only, no creds/query/fragment, host allowlist) & not bypassable via redirect | `sentryExploreClient.ts`, `sentryAdapter.ts` | A05 / API7 / CWE-918 | |
| F2 | Any other user-supplied URL/host (observability providers) validated equally | observabilityIntegrationsRouter | API7 / CWE-918 | |

## G. Crypto, secrets & config  → `SEC-` / `SUP-`
| # | Check | Where | Map | Status |
|---|---|---|---|---|
| G1 | No hardcoded live secrets in code/compose/.env committed; `.htpasswd`, license keys, DB creds | infra/*, `.env-hp`, docker-compose*, `.htpasswd` | A02 / CWE-798 / CERT-In credential hygiene | |
| G2 | License JWT verify: `ES256` pinned, but check `ignoreExpiration:true` / `algorithms` and key trust bootstrap | `common/.../LicenseManager.ts`, backend license | A02/A08 / CWE-347 | |
| G3 | Credential keyring/cipher: KDF, IV/nonce uniqueness, key storage in Consul, rotation scripts | `observability/credentialCipher.ts`, `credentialKeyring.ts` | A02 / ASVS V11 / CWE-326/327 | |
| G4 | RNG for tokens/identifiers/login handoff is cryptographic | authRouter, agents | A02 / CWE-338 | |
| G5 | Consul exposure (`-client=0.0.0.0`), Traefik `api.insecure=true` + `HostRegexp(.*)`, license public key in KV | `infra/prod/docker-compose.prod.yml`, `dynamic.yml` | A02 / CWE-16 / CWE-668 | |
| G6 | CORS `origin:true` + `credentials:true` blast radius | `apps/backend/src/index.ts` | A02 / CWE-942 | |

## H. Captured-data privacy & redaction  → `PRIV-`
| # | Check | Where | Map | Status |
|---|---|---|---|---|
| H1 | Redaction filters actually stop secrets/PII being captured (keys, tokens, PAN, email) | backend `observability/redaction.ts`, SDK serializers/RedactionFilter | A09 / CWE-201/312 / CERT-In data protection | |
| H2 | Snapshot size/depth caps enforced before storage; no full-object leakage | SDK serializers, `ObjectGraphLimiter` | CWE-770 | |
| H3 | Snapshots/logs aren't visible cross-tenant (ties to A3/A4) | probesRouter, DB | A01 / CWE-200 | |
| H4 | Query logging (`prisma:sql` debug) doesn't persist sensitive params in prod | `apps/backend/src/index.ts` | A09 / CWE-532 | |
| H5 | Trace-id / APM capture doesn't exfiltrate more than intended | SDK apm extractors | CWE-200 | |

## I. AI / MCP-specific  → `AIMCP-`
| # | Check | Where | Map | Status |
|---|---|---|---|---|
| I1 | Captured production values returned to the AI agent can't inject instructions (prompt injection / tool-output poisoning) | `mcp-server/src/index.ts` (list_snapshots/wait_for_snapshot) | OWASP LLM01 / MCP03,MCP10 / CWE-77 | |
| I2 | MCP token handling & scope: `HYPERPROBE_ACCESS_TOKEN`, cached refresh token file perms (0o700), least privilege | `mcp-server/src/auth.ts` | LLM/MCP01,MCP07 / CWE-522 | |
| I3 | Tool descriptions can't be poisoned; server identity/skills text is trusted | `mcp-server/src/skills.ts`, index | MCP03 / CWE-829 | |
| I4 | Snapshot data feeding the agent is redacted (ties to H1) & over-sharing bounded | mcp-server + backend | MCP10 / LLM06 | |
| I5 | MCP `execSync('git rev-parse')` / `execFile` context can't be influenced by repo contents | skills.ts, service-config.ts | MCP05 / CWE-78 | |

## J. Reliability / DoS (host-app safety)  → `DOS-`
| # | Check | Where | Map | Status |
|---|---|---|---|---|
| J1 | Serialization depth/size/time caps prevent OOM/hang in the customer's prod process | all SDK serializers, safety monitors | A10 / CWE-770/674 | |
| J2 | Inspector/instrumentation can't pause or deadlock production threads | node inspector, java instrumentation | CWE-833 | |
| J3 | Quota/rate limiting on capture; unbounded probe hits handled | SDK quota.*, redis counters | API4 / CWE-770 | |
| J4 | Broker/consumer: unbounded queues, backpressure, NATS payload (64MB) handling | logger, logger-consumer | A10 / CWE-770 | |
| J5 | Expression eval timeouts; a pathological condition can't wedge the host | evaluators | CWE-1333/834 | |

## K. Supply chain, dependencies & CI  → `SUP-`
| # | Check | Where | Map | Status |
|---|---|---|---|---|
| K1 | Dependency CVEs across npm/pip/maven/gem (map each to CVE/GHSA) | all lockfiles/manifests | A03 / CWE-1395 / CERT-In SBOM | |
| K2 | Dependency confusion risk on `@hyperprobe/*` / internal packages; registry scoping | `.npmrc.example`, package.json | A03 / CWE-427 | |
| K3 | Hostile/blocking install & build hooks reviewed before running | `build.sh`, `.husky/*`, postinstall, publish scripts | A08 / CWE-829 | |
| K4 | GitHub Actions: action pinning (SHAs), PR-triggered jobs don't run untrusted code with secrets, self-hosted runner hardening, secret handling | `.github/workflows/*` | A08 / CWE-829 / CWE-94 | |
| K5 | Dockerfile hygiene (base image, root, secrets in layers) & IaC misconfig | `Dockerfile`, compose files | A02 / CWE-250/16 | |

## L. Error handling, logging & code quality  → `BUG-` / `CQ-`
| # | Check | Where | Map | Status |
|---|---|---|---|---|
| L1 | Errors fail closed (esp. auth, license, redaction, self-serve toggle fallbacks) | throughout | A10:2025 Mishandling Exceptional Conditions / CWE-703/755 | |
| L2 | No swallowed exceptions that mask security failures | try/catch sites | CWE-390 | |
| L3 | Unhandled promise rejections / race conditions / TOCTOU (probe counters, license locks) | routers, cron, redis multi | CWE-362 | |
| L4 | Weak typing (`any`, `as any`) hiding unsafe assumptions at trust boundaries | createContext, keyring, rawInput casts | CWE-704 | |
| L5 | Security-relevant tests exist and actually assert the guard (not just happy path) | *.test.ts, spec/, e2e | A09 / NIST SSDF PW.7/PW.8 | |
| L6 | Logging is sufficient for security monitoring & doesn't leak secrets | logger, backend | A09 / ASVS V16 | |
