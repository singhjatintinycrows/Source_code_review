# Audit Plan — HyperProbe (prodprobe monorepo)

Prepared for Tinycrows · 25-09-2026 · Independent secure source code review (static + local PoC).

---

## 1. Engagement definition

| Item | Value |
|---|---|
| **Target** | `prodprobe` monorepo (product: **HyperProbe**), a production debugger / observability control plane + in-process agents |
| **Scope** | Entire repository: backend, dashboard, gRPC broker (logger) + consumer, database/Prisma, agent SDKs (Node, Python, Java, Ruby), MCP server, VS Code extension, licensing server, shared license manager, infra (Docker/Consul/Traefik/NATS), CI/CD |
| **Method** | Static source review + local proof-of-concept in a disposable Docker lab. **No testing against any live/production deployment.** |
| **Depth** | Deep, evidence-based; Claude Code Opus 5.5 with multi-agent workflows (ultracode), no agent-count cap |
| **Local test target** | `github.com/hypertestco/hp-test-payment-demo` — used **only** to exercise the SDK/MCP end to end; not itself audited |
| **Standards** | OWASP Top 10:2025, OWASP ASVS 5.0, OWASP API Security Top 10 (2023), OWASP LLM Top 10 (2025), OWASP MCP Top 10 (2025), CWE Top 25 (2025), CERT-In guidelines, ISO/IEC 27001:2022 Annex A, NIST SSDF (SP 800-218), MITRE ATT&CK. Scoring: CVSS v3.1. |
| **Timeline** | 1-day deep automated run + human triage of the register |

### Rules of engagement
- Review by reading code and building local PoCs. Never connect to production.
- Secrets found in code: report existence + location, redacted; recommend rotation; never use.
- Read any build/install/hook script before executing it. Run only in the isolated lab.
- Report honestly: negative results and coverage gaps are recorded, not hidden.

---

## 2. Architecture & data flow (what you're auditing)

HyperProbe is a **non-breaking production debugger**. Developers/AI agents set "probes" (snapshot or log points) on a line of code; agents embedded in the customer's *running production app* instrument that line, capture local variables / stack / trace-id when hit, and ship the data back for viewing.

```
 VS Code ext / MCP server ──tRPC──▶ Backend (Fastify+tRPC) ──▶ Postgres (Prisma)
                                          │  ▲                     ▲
                                          │  │ Consul KV (config, license key, DB/Redis/NATS URLs)
                                          ▼  │                     │
                                   Redis (liveness, login handoff, probe counters)
                                                                    │
 Customer PROD app ── embeds Agent SDK ──gRPC──▶ Logger (broker) ──┤ (GetProbes / ReportTelemetry
   (Node/Python/Java/Ruby)                        │                 │  / UploadSourceMap)
                                                  ▼                 │
                                            NATS JetStream ──▶ Logger-Consumer ──▶ Postgres
 External licensing lambda (Firebase-backed) ◀── heartbeat/relay ── Backend license module
```

**Trust boundaries that matter most:**
1. **Agent ⇆ Logger (gRPC)** — the broker hands probe definitions (including *expressions to evaluate*) to agents running inside production apps, and receives captured production data. Check authentication of this channel end to end.
2. **User ⇆ Backend (tRPC)** — RBAC over services/teams/probes/snapshots; multi-tenant data isolation.
3. **Probe expression ⇆ SDK evaluator** — a probe carries a `condition` and `watchExpressions` that the SDK evaluates *in-process in production*. The safety of every evaluator (and its "unsafe" toggle) is the crown-jewel risk.
4. **Captured production data ⇆ MCP server ⇆ AI coding agent** — snapshot payloads (potentially containing secrets/PII) flow into an AI agent's context: an injection and data-exposure surface.
5. **Backend/services ⇆ Consul / Traefik / NATS** — config and secrets live in Consul; Traefik terminates routing. Exposure here is infrastructure-level compromise.

---

## 3. Component map & where to look

| Component | Path | Primary concerns |
|---|---|---|
| Backend (control plane) | `apps/backend/src` | tRPC auth middleware (`trpc.ts`), routers (probes/agents/services/teams/users/rca/auth/observability/license), JWT/session (`authRouter.ts`, `index.ts`), SSO decrypt (`helpers/decryptSsoToken.ts`), credential keyring/cipher (`observability/`), cron |
| Broker / Logger (data plane) | `apps/logger/src/index.ts` | gRPC server auth (`ServerCredentials.createInsecure`), GetProbes/ReportTelemetry authZ, source-map upload (zip-bomb/size), Redis liveness, license gating |
| Logger-consumer | `apps/logger-consumer/src` | NATS message handling, writing snapshots to Postgres, trust of message content |
| Database | `packages/database` | Prisma schema, migrations, indexes, cascade behaviour, RBAC model |
| Node SDK | `packages/node-sdk/src` | `core/inspector.ts` (v8 `evaluateOnCallFrame`, `throwOnSideEffect`), expression wrapping (`evaluation-utils.ts`), serialization/redaction, quota/safety, source-map uploader |
| Python SDK | `agents/python-sdk/hyperprobe` | `core/evaluator.py` (`ast` allowlist, `SAFE_BUILTINS`, `HYPERPROBE_DISABLE_SAFE_EVALUATION`), monitoring engine, serializer, safety |
| Java SDK | `agents/java-sdk` | `hyperprobe-evaluator` (MVEL `SafeASTValidator`), instrumentation (ASM), serializer (`ObjectGraphLimiter`, `RedactionFilter`) |
| Ruby SDK | `agents/ruby-sdk/lib` | `core/evaluator.rb` (`binding.eval`, `safe_ast_validator.rb`), serializer, safety |
| MCP server | `packages/mcp-server/src` | Tool definitions & descriptions (`index.ts`), auth/token cache (`auth.ts`), `service-config.ts` (`execFile`), skills text, how snapshot data is returned to the agent |
| VS Code extension | `apps/vsc-extension` | Webview CSP (`extension.ts`), `onDidReceiveMessage` handlers, token storage, `child_process` git calls |
| Dashboard | `apps/dashboard` | Token storage in `localStorage` (`useAuth.ts`), auth middleware, any `v-html`, tRPC client |
| Licensing server | `external/licensing-server/src` | Firebase creds, JWT signing (`ES256`), heartbeat/relay phases, input validation (`handler.ts`, `phase2.ts`) |
| License manager (shared) | `packages/common/src/license` | JWT verify (`ignoreExpiration:true`?), status gating, bootstrap public key handling |
| Infra | `infra/`, `Dockerfile`, `build.sh` | docker-compose (dev + prod), Consul `-client=0.0.0.0` exposure, Traefik `api.insecure=true` + `HostRegexp(.*)`, `.htpasswd`, NATS, hardcoded DB creds, license public key in KV |
| CI/CD | `.github/workflows`, `.husky` | Release secrets handling, PR-triggered workflows, action pinning, self-hosted runner, injection into scripts |

---

## 4. Threat model (STRIDE-lite, by actor)

| Actor | Can reach | Key questions |
|---|---|---|
| **Unauthenticated network attacker** | Whatever ports Traefik/Consul/logger expose | Is the gRPC broker authenticated? Can anyone call GetProbes/ReportTelemetry? Is Consul UI/KV reachable? Is Traefik dashboard (`api.insecure=true`) exposed? |
| **Low-privileged authenticated user** (Viewer on one service) | tRPC procedures | Can they read snapshots/logs/probes of services they don't belong to? Escalate role via mass assignment? Reach admin-only mutations? IDOR on probe/service/user ids? |
| **Malicious/compromised agent** (or someone who can speak gRPC to the broker) | Logger RPCs | Can a forged agent pull another tenant's probes (which reveal source paths + expressions)? Poison telemetry? Exhaust the broker? |
| **Attacker who can influence a probe expression** | SDK evaluator in prod | Can a crafted `condition`/`watchExpression` escape the sandbox and run code, read files, or crash the customer's production process? Do all four SDKs enforce the same guard? What does the "unsafe" toggle expose? |
| **Attacker controlling captured data** (values in the prod app) | MCP → AI agent | Can values captured in a snapshot inject instructions into the AI coding agent (prompt injection / tool-output poisoning)? Do secrets/PII flow to the agent unredacted? |
| **Insider / supply chain** | Deps, CI, publish | Vulnerable/abandoned deps? Dependency confusion on `@hyperprobe/*`? Hostile install hooks? CI secret exfiltration via PR? |

---

## 5. Priority order (where the severity usually is)

Work classes roughly in this order, re-prioritising on evidence:

1. **SDK expression-evaluation sandboxes & their unsafe toggles** — RCE *inside the customer's production app* is the highest-impact outcome this product can have. Check all four SDKs for parity; a bypass in any one is critical. Check what enables "unsafe" mode and whether a server-controlled probe can flip it.
2. **Broken access control / IDOR / multi-tenancy** — most prevalent, least detectable by scanners. Every `findUnique/findMany` by id and every tRPC procedure: can a lower role or another tenant reach it? (Note `hasServiceLeadAccess` etc. rely on `rawInput.serviceId`.)
3. **gRPC broker authentication** — `createInsecure()` + how agents are identified. If unauthenticated, probe definitions (source layout + expressions) leak and telemetry can be forged.
4. **Auth/session/JWT** — token secret sourcing (`crypto.randomUUID()` per deploy, stored in DB), refresh-token binding (`sessionSecret`), the SSO `verifySso` flow (RSA `publicDecrypt` of an "encrypted email token", 60s tolerance), the e2e bypass branch, login handoff via Redis `login:<identifier>` (can another user poll someone's tokens?).
5. **Infra exposure** — Consul `-client=0.0.0.0`, Traefik `api.insecure=true` + `HostRegexp(.*)`, hardcoded Postgres creds, license public key & secrets in Consul KV, `.htpasswd`.
6. **Captured-data privacy & redaction** — do the serializers/redaction filters actually stop secrets/PII from being captured and stored? Cross-tenant snapshot visibility?
7. **AI/MCP** — prompt injection via captured values, tool-output poisoning, MCP token scope/handling.
8. **Reliability/DoS on the host app** — serialization depth/size caps, quota/safety monitors, inspector pausing, unbounded work. A debugger that can OOM or hang production is a sev-worthy defect.
9. **SSRF** — Sentry/observability outbound (`apiBaseUrl` allowlist), any user-controlled URL.
10. **Crypto & secrets** — license signing/verify (`ES256`, `ignoreExpiration`), credential cipher, RNG for tokens/identifiers.
11. **Supply chain & CI** — deps→CVEs, lockfile, dependency confusion, action pinning, PR-triggered jobs, self-hosted runner.

---

## 6. Tooling (accelerators, not oracles)

Run these to triage, then hand-verify every hit (see `04-references.md` for links/commands):

- **Semgrep** (`p/default`, `p/javascript`, `p/typescript`, `p/python`, `p/java`, `p/ruby`, `p/secrets`, `p/owasp-top-ten`) — cross-language taint/patterns.
- **Gitleaks** / **TruffleHog** — secret scan (run over git history too if available).
- **OSV-Scanner** + **Trivy** (fs + config + image) — dep CVEs, Dockerfile, IaC.
- **npm/pnpm audit**, **pip-audit**, **bundler-audit**, **OWASP Dependency-Check** (Java) — per-ecosystem SCA.
- **CodeQL** (js/ts, python, java, ruby) — deep dataflow where budget allows.
- **zizmor** + **actionlint** — GitHub Actions security.
- **Bandit** (python), **Brakeman** (ruby/rails), **gosec** (n/a), **hadolint** (Dockerfile).
- **Prisma** schema review by hand; **jwt** flows traced by hand.

Scanner output is a *lead list*. A finding requires a traced, reachable path — never file a raw Semgrep hit as a finding.

---

## 7. Definition of done

Terminate only when all hold (or budget is exhausted and gaps are listed explicitly):
- Every attacker-reachable entry point traced to its sinks, and every dangerous sink traced back to its sources.
- Every authz-bearing tRPC procedure checked in both directions (can a lower role / other tenant reach it?).
- Every object-load-by-id checked for an ownership/tenancy guard.
- All four SDK evaluators checked for sandbox correctness and toggle parity.
- The gRPC broker's authentication settled (present/absent, and impact).
- Every sanitiser on a tainted path checked for correctness *for its specific sink*.
- Every pinned dependency checked against known-CVE data; Docker/Consul/Traefik/NATS/CI configs reviewed.
- Each of the 7 categories either populated or reasoned-out as empty, with coverage honestly recorded in `audit/coverage.md`.
