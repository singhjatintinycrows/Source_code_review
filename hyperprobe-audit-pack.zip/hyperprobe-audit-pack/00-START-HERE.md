# HyperProbe / ProdProbe — Source Code Security Audit Pack

**Target:** `prodprobe` monorepo (product name: **HyperProbe**) — a production debugger/observability platform.
**Prepared for:** Tinycrows · **Date:** 25-09-2026
**Audit type:** Independent, audit-grade secure source code review (static review + local proof-of-concept).

---

## What this pack is

A complete, self-contained kit to run a **deep, evidence-based source code audit** of the HyperProbe codebase using **Claude Code** (Opus 5.5, ultracode / multi-agent workflows). It is built so that a reviewer with no prior context can hand the whole folder to Claude Code and get a rigorous, reproducible audit with findings that a maintainer can act on and that hold up to external scrutiny.

Everything here is **methodology and tooling**. No exploitation of any live system is involved — the review is read-the-code plus local PoCs in a throwaic lab.

## Files in this pack

| File | Purpose |
|---|---|
| `00-START-HERE.md` | This file — orientation and run order |
| `01-master-prompt.md` | **The prompt you paste into Claude Code.** The single most important file |
| `02-audit-plan.md` | The phased plan: scope, threat model, components, what to look at where |
| `03-checklist.md` | The control checklist mapped to OWASP / ASVS / CWE / CERT-In. Mirror of the Excel tracker |
| `04-references.md` | Every standard, tool and doc cited, with verified links (checked 2026-09) |
| `05-finding-template.md` | The exact structure every finding file must follow |
| `06-seed-leads.md` | Unverified hypotheses from a first read-through. **Leads, not findings** — prove or kill each |
| `workflow/hyperprobe-audit.js` | A Claude Code dynamic-workflow (ultracode) script that orchestrates the whole audit |
| `skill/hyperprobe-source-audit/` | A reusable Claude Code **skill** (SKILL.md + references) encoding this methodology |
| `templates/` | Excel findings + checklist tracker |

## How to run it (recommended order)

1. **Set up the workspace.** Put the code under review next to this pack:
   ```
   audit-workspace/
   ├─ hyperprobe-audit-pack/     ← this folder
   └─ prodprobe-master/          ← the source under review (unzipped)
   ```
   If you have the git history, clone it instead of using the zip (better secret scanning). Also clone the test-lab repo (used only as a local target, never reported on):
   `https://github.com/hypertestco/hp-test-payment-demo`

2. **Install the skill (optional but recommended).** Copy `skill/hyperprobe-source-audit/` into `.claude/skills/` inside `prodprobe-master`, or into `~/.claude/skills/` to reuse it across projects. Then `/hyperprobe-source-audit` is available. (Tinycrows: this skill has also been proposed into your Claude account — accept the card to save it.)

3. **Turn on deep mode.** In Claude Code run `/effort ultracode` (or include the word `ultracode` in your prompt). This makes Claude plan multi-agent workflows automatically.

4. **Paste the master prompt.** Open `01-master-prompt.md`, copy it whole, and send it to Claude Code from inside the `prodprobe-master` directory. It references this pack by relative path.

5. **Let the workflow run.** Claude Code will (a) map the code, (b) fan out reviewers per component and per vulnerability class, (c) adversarially verify each candidate, (d) write one file per confirmed finding into `audit/`, and (e) build the tracker and report. Watch progress with `/workflows`.

6. **Review the output.** Findings land under `audit/findings/<category>/`. The register is `audit/findings-register.md` (+ `.csv`). Import the CSV into the Excel tracker's "Findings Register" sheet to track status and get the severity/category counts.

## On the seed leads

`06-seed-leads.md` lists concrete things a first read flagged as *suspicious*. They are **explicitly not findings**. The master prompt instructs Claude Code to treat them as hypotheses to prove or disprove with a traced path and, where feasible, a local PoC — and then to **keep going far beyond them**, because the highest-value bugs (broken access control, logic, chained auth flaws) are usually the ones a first skim misses. Do not let the leads anchor the review.

## Output categories (one main folder, a subfolder per category)

```
audit/findings/
├─ 01-security/            # authz, authn, injection, SSRF, crypto, secrets
├─ 02-ai-mcp/              # MCP + AI-agent-specific risks (prompt injection, tool poisoning, token handling)
├─ 03-functional-bugs/    # logic errors, wrong behaviour, crashes
├─ 04-reliability-dos/    # resource exhaustion, unbounded work, host-app impact
├─ 05-privacy-data/       # PII/secret capture in snapshots, redaction gaps, sensitive logging
├─ 06-supplychain-infra/  # deps/CVEs, Docker, Consul/Traefik/NATS, CI/CD
└─ 07-code-quality/       # weak typing, dead code, insecure defaults, missing tests
```

## Ground rules (repeated in the master prompt)

- **Evidence or it didn't happen.** Every finding cites `file:line` and a traced path from an attacker-reachable source to a dangerous sink. No path → it's a candidate, not a finding.
- **Secrets are radioactive.** If a live credential/key is found in the code, report *that it exists* at `file:line`, redacted. Never test it against any live service, never paste it verbatim, recommend rotation.
- **No touching production.** Reachability is proven by reading code and by local PoCs only.
- **Fail honestly.** Record negative results and note what wasn't covered rather than implying completeness.
