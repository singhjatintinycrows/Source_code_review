# Finding File Template

Every confirmed finding is **one Markdown file** in the right category folder, named
`<ID>-<slug>.md` (e.g. `SEC-001-unauthenticated-grpc-broker.md`). Copy the block below verbatim and fill it.

ID prefixes by category:
`SEC-` security · `AIMCP-` AI/MCP · `BUG-` functional bug · `DOS-` reliability/DoS ·
`PRIV-` privacy/data · `SUP-` supply-chain/infra · `CQ-` code quality. Number sequentially per prefix.

---

```markdown
# <ID> — <Short, specific title>

| Field | Value |
|---|---|
| **Severity** | Critical / High / Medium / Low / Info |
| **CVSS v3.1** | `<base score>` — `CVSS:3.1/AV:_/AC:_/PR:_/UI:_/S:_/C:_/I:_/A:_` |
| **Category** | 01-security / 02-ai-mcp / 03-functional-bugs / 04-reliability-dos / 05-privacy-data / 06-supplychain-infra / 07-code-quality |
| **Component** | e.g. logger (gRPC broker) |
| **CWE** | CWE-___ (name) |
| **OWASP** | A0x:2025 … / API_:2023 / LLM_ / MCP_ |
| **ASVS 5.0** | V__.__.__ (if applicable) |
| **CERT-In** | relevant guideline area (if applicable) |
| **Status** | Confirmed / Hypothetical (path not fully proven) |
| **Confidence** | 0.0–1.0 + what would raise it |

## Summary
One or two sentences: the defect, and the impact in plain terms.

## Location
- Primary: `path/to/file.ext:LINE`
- Related: `path/to/other.ext:LINE`

## Traced path (source → sink)
Show the untrusted **source**, each hop, and the dangerous **sink**, with `file:line` at each step.
State explicitly what guard is missing or wrong *for this specific sink*, and why it doesn't hold.

```text
source:  <where attacker-controlled data enters>            (file:line)
  → hop: <function/assignment/framework boundary>           (file:line)
  → hop: ...
sink:    <dangerous operation reached>                      (file:line)
guard:   <what sits between, and why it's absent/bypassable>
```

## Evidence
The minimal code excerpt(s) that prove it. Quote the actual lines. If a local PoC was built,
include the exact repro (unit test / disposable-lab request) and the observed result. **Never**
include a live production request or a real secret in full (redact to first 4 chars).

## Reachability & preconditions
How an attacker reaches this at runtime: which actor (unauth / low-priv user / forged agent / etc.),
what must be true (auth state, config flag, feature toggle, input shape). If unreachable in the
default config, say so and reclassify.

## Impact & chain
What capability this grants, and what it unlocks when combined with other findings. Map to MITRE
ATT&CK technique(s) where a chain to real-world impact exists. Justify the severity honestly — do
not inflate.

## Remediation
The concrete fix. Prefer the systemic fix (one shared guard) over per-site patches where the class
recurs. Include a short **corrected code snippet**:

```<lang>
// before (vulnerable)
...
// after (fixed)
...
```

## Variant check
Sibling locations checked for the same defect shape, and the result (also vulnerable / safe /
different guard). List the files examined so coverage is auditable.

## References
CWE link, OWASP category link, any advisory/CVE, framework doc consulted.
```

---

## Register row (also add to `audit/findings-register.md` and `.csv`)

`| ID | Title | Category | Severity | CVSS | CWE | file:line | Status |`

The CSV columns must be exactly:
`ID,Title,Category,Severity,CVSS_Score,CVSS_Vector,CWE,OWASP,ASVS,Component,File,Line,Status,Confidence`
so the Excel tracker imports cleanly.
