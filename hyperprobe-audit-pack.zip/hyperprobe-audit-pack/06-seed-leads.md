# Seed Leads — UNVERIFIED first-pass hypotheses

> **These are leads, not findings.** They come from a quick first read of the code, not a traced,
> verified analysis. Each one may be a real bug, a partial issue, or a non-issue with a guard the
> skim missed. For every lead: independently trace the real path and **prove it** (reachable source
> → sink, guard absent/wrong, PoC where feasible) or **disprove it** and record why. Then go far
> beyond this list — it is a floor, not a ceiling. Do **not** cite a lead as a finding until it is
> proven. Do **not** assume a lead is confirmed because it sounds plausible.

Legend: **P(real)** is the first-pass hunch only. Re-derive it yourself.

---

## L1 — gRPC broker appears to listen with insecure credentials  (P(real): high)
`apps/logger/src/index.ts:~1034` → `grpc.ServerCredentials.createInsecure()`. The broker exposes
`GetProbes`, `ReportTelemetry`, `UploadSourceMap`. **Check:** Is there any application-layer auth
(token in metadata, mTLS at Traefik with `h2c`)? Trace `getProbes` — does it authenticate the caller
or trust `call.request.agentId`/`serviceId` as-is? If unauthenticated, what does a client that speaks
gRPC to this port obtain (another tenant's probe list = source paths + expressions) and can it forge
telemetry? Confirm what actually terminates/authenticates the connection in `infra/prod`. → `SEC-`, class C.

## L2 — `GetProbes` trusts request-supplied identifiers  (P(real): high)
Same handler destructures `serviceId, environment, agentId` straight from `call.request` and fetches
probes/limits for that service. **Check:** can any caller pass an arbitrary `serviceId` and receive
that service's active probes? Probes contain runtime file locations and evaluated expressions —
information disclosure across tenants, and a foothold for L1. → `SEC-`, class C2.

## L3 — `serviceId`-scoped tRPC middleware reads `rawInput`  (P(real): medium)
`apps/backend/src/trpc.ts` `hasServiceLeadAccess`/`hasServiceMemberAccess` pull `serviceId` from
`rawInput` before Zod parsing. **Check:** does every gated procedure actually take `serviceId` at the
top level with that exact name? Any procedure where the authz `serviceId` and the operated-on object's
`serviceId` can differ (pass a service you lead, act on an object in another) = IDOR. Cross-check each
`serviceLeadProcedure`/`serviceMemberProcedure` against what the resolver loads by id. → `SEC-`, class A2/A3.

## L4 — Login-handoff via `login:<identifier>` in Redis  (P(real): medium)
`authRouter.ts` `authorizeVsc` writes `{accessToken,refreshToken}` to `login:<identifier>` (2-min TTL);
`pollLogin` (unauthenticated `t.procedure`) reads and deletes it by `identifier`. **Check:** where does
`identifier` come from and what entropy does it have? If a client chooses/guesses it, can one party
poll for another's freshly minted tokens? Trace who sets `identifier` in the VS Code/MCP login flow. → `SEC-`, class A8/B.

## L5 — SSO `verifySso` e2e bypass branch  (P(real): medium)
`authRouter.ts verifySso`: when `NODE_ENV!=='production' && HYPERPROBE_ENV==='e2e'` and the token
starts with `{`, the "token" is trusted as raw JSON (no decryption). **Check:** can `HYPERPROBE_ENV`
be set to `e2e` in a real deployment, or `NODE_ENV` be non-production, such that arbitrary email →
account (and first-user → admin) is possible? Also review the RSA `publicDecrypt`-of-email design and
the 60s tolerance for replay. → `SEC-`, class B3/B4.

## L6 — First user becomes admin when `userCount==0`  (P(real): low–medium)
`verifySso` creates an Admin team + admin user if there are zero users/admin-teams. **Check:** in a
fresh or wiped deployment, can an unauthenticated caller with any valid SSO token seize admin? Is there
a race (two concurrent first-users)? Tie to L5. → `SEC-`, class B4.

## L7 — Infra exposure: Consul, Traefik dashboard, secrets in KV  (P(real): high, infra)
`infra/prod/docker-compose.prod.yml` + dev compose: Consul runs `-client=0.0.0.0` with a Traefik router
`HostRegexp(.*)`; Traefik runs `--api.insecure=true`; the **LICENSE_PUBLIC_KEY** and DB/Redis/NATS URLs
are written into Consul KV; Postgres uses `user:password`; `.htpasswd` ships in the repo. **Check:** what
is actually published to the network vs internal-only? Consul KV holds the license trust anchor and
connection strings — reachable Consul = license/agent control + infra creds. Traefik `api.insecure` +
catch-all host = dashboard/route exposure. Confirm exposure against the entrypoints/ports and document
the real blast radius (don't overstate if it's bound to an internal network). → `SEC-`/`SUP-`, class G5.

## L8 — Hardcoded license public key committed in compose  (P(real): high→verify impact)
The EC `LICENSE_PUBLIC_KEY` is embedded in both compose files. A *public* key isn't itself a secret,
but **check** the trust model: can an attacker who reaches Consul KV (L7) replace it with their own and
thereby forge licenses (`ES256`)? Review `LicenseManager` bootstrap: `setBootstrapPublicKey`, and
`jwt.verify(..., {algorithms:['ES256'], ignoreExpiration:true})` — is `ignoreExpiration:true` intended,
and what does license forgery unlock (agent limits, shutdown gating)? → `SEC-`, class G2/G5.

## L9 — Redis debug SQL logging  (P(real): low)
`apps/backend/src/index.ts` registers a Prisma `query` hook logging `query/params/duration` at debug.
`LOG_LEVEL` is set from Consul (dev compose = `debug`). **Check:** in prod could query params (holding
user data) be logged/persisted? → `PRIV-`, class H4.

## L10 — CORS `origin:true` + `credentials:true`  (P(real): low–medium)
`apps/backend/src/index.ts` registers CORS reflecting any origin with credentials. **Check:** combined
with `localStorage` bearer tokens (dashboard `useAuth.ts`) what is the actual CSRF/credential-theft
exposure? (Bearer-in-header auth may blunt it — verify rather than assume.) → `SEC-`, class G6.

## L11 — SDK "unsafe evaluation" toggles  (P(real): medium — the important one)
Every SDK has a switch that disables the expression sandbox:
Python `HYPERPROBE_DISABLE_SAFE_EVALUATION` / `disable_safe_evaluation` (`agents/python-sdk/.../core/evaluator.py`,
`agent.py`, `monitoring_engine.py`); analogous flags in Node/Java/Ruby. In unsafe mode, arbitrary
function/method calls run **inside the customer's production process**. **Check:** (a) is the flag
strictly local/operator-set, or can a **server-delivered probe or AgentGlobalConfig flip it**? Trace the
config path from broker → agent. (b) Is it off by default and loudly warned? (c) Does the *monitoring
engine* re-read it per-probe from a config snapshot that the server controls? This is the difference
between "operator foot-gun" and "remote RCE in every customer app." → `SEC-`, class D5/D6.

## L12 — Sandbox-escape review for each evaluator  (P(real): unknown — must be tested)
Even in "safe" mode, verify the guards actually hold:
- **Python** `SafeASTVisitor`/`SAFE_BUILTINS` — attempt dunder traversal, `__class__/__mro__/__subclasses__`,
  attribute access, comprehension/generator tricks, `__builtins__` recovery. 256-char limit only.
- **Node** `evaluateOnCallFrame` with `throwOnSideEffect:true` — confirm the wrapping in
  `evaluation-utils.ts` can't defeat side-effect blocking; check watch-vs-condition parity and the
  `silent:true` path.
- **Java MVEL** `SafeASTValidator` — attempt reflection, `Runtime`, class literals, static method access,
  template-mode escapes.
- **Ruby** `binding.eval` + `safe_ast_validator.rb` — attempt backticks, `system`, `send`, `const_get`,
  `Kernel` methods.
Write actual PoC expressions in each SDK's test harness. A confirmed escape in *any* SDK is Critical. → `SEC-`, class D1–D4.

## L13 — Source-map upload resource limits  (P(real): low — guard appears present)
`logger` `UploadSourceMap` caps compressed (20MB) and decompressed (100MB) sizes and streams via gunzip.
**Check:** is the guard complete (per-chunk vs total, gzip ratio, `fileName` used in any path/DB key),
and is the stream authenticated (ties to L1)? Likely partial at worst — verify before rating. → `DOS-`/`SEC-`, class C4.

## L14 — MCP returns raw snapshot payloads to the AI agent  (P(real): medium, AI category)
`packages/mcp-server/src/index.ts` `list_snapshots`/`wait_for_snapshot` return captured variables/stack
as JSON text to the coding agent. **Check:** (a) captured **production values can contain
attacker-influenced strings** → prompt injection / tool-output poisoning of the agent (map LLM01, MCP03/10).
(b) Are those values **redacted** before reaching the agent, or do secrets/PII flow through (H1/I4)?
(c) MCP token handling in `auth.ts` (`HYPERPROBE_ACCESS_TOKEN`, cached refresh token file, 0o700) — scope
and least privilege. → `AIMCP-`, class I1/I2/I4.

## L15 — `.env-hp` and example credential files in the repo  (P(real): verify)
`.env-hp` (dev DB URL/creds), `.htpasswd`, and several `*.example` credential files are committed.
**Check:** are any of these *real* secrets (vs placeholders)? If a real credential/key is present,
report existence + location redacted and recommend rotation — do **not** test it. Run Gitleaks/TruffleHog
over the tree (and git history if available). → `SUP-`/`SEC-`, class G1/K.

## L16 — GitHub Actions: PR-triggered workflow + self-hosted runner  (P(real): verify)
`.github/workflows/google-chat-notifications.yml` triggers on `pull_request` and calls Gemini with a
secret; `release.yml` runs on a self-hosted runner with publish secrets (NPM/PyPI/Maven/GPG/OVSX/AWS).
The notify workflow comments it "Only run trusted code at the event's master commit, never PR-head code."
**Check:** does it actually check out master (not PR head) before any code executes, are actions pinned by
SHA, and can a forked PR reach the secrets or the self-hosted runner? Run `zizmor` + `actionlint`. → `SUP-`, class K4.

---

### Explicitly out of scope as findings
- The deliberate 500 bug in `hp-test-payment-demo` (teaching artifact; lab target only).
- Style/lint nits that a linter already owns — unless they cause a security or correctness defect.
