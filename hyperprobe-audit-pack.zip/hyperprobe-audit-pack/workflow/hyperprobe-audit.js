export const meta = {
  name: 'hyperprobe-audit',
  description: 'Deep multi-agent secure source code audit of the HyperProbe (prodprobe) monorepo: map, review per component and per vulnerability class, adversarially verify, sweep variants, write one finding file per confirmed issue.',
  whenToUse: 'Run from inside the prodprobe-master repo with ../hyperprobe-audit-pack/ alongside it. Turn on /effort ultracode first.',
  phases: [
    { title: 'Map', detail: 'Build the attack-surface map and dependency inventory' },
    { title: 'Review', detail: 'One reviewer per component and per vulnerability class' },
    { title: 'Verify', detail: 'Adversarially refute each candidate; keep only survivors' },
    { title: 'Variant', detail: 'Sweep sibling code for the same defect shape' },
    { title: 'Report', detail: 'Write one finding file per confirmed issue + register + summary' },
  ],
}

// ----------------------------------------------------------------------------
// Shared context every agent is told. Keep it short; agents also read the pack.
// ----------------------------------------------------------------------------
const RULES = `
You are one agent in an independent, audit-grade secure source code audit of the HyperProbe
(prodprobe) monorepo. Read code to find real, reachable defects; do NOT attack any live system and do
NOT run the repo's own build/install/postinstall scripts without reading them first. Secrets found in
code: report existence + file:line redacted, never test or print them in full. Evidence rule: a finding
needs a traced path from an attacker-reachable SOURCE to a dangerous SINK with the guard shown absent or
wrong FOR THAT SINK. A bare pattern match with no reachable source is a candidate, not a finding. The
methodology, checklist, standards and finding format are in ../hyperprobe-audit-pack/ — consult
02-audit-plan.md, 03-checklist.md, 04-references.md, 05-finding-template.md. Map every issue to CWE +
OWASP Top 10:2025 (+ API/LLM/MCP where it fits) + ASVS 5.0 + CERT-In, and score with CVSS v3.1.
`

const CANDIDATE_SCHEMA = {
  type: 'object',
  required: ['candidates'],
  properties: {
    candidates: {
      type: 'array',
      items: {
        type: 'object',
        required: ['title', 'category', 'file', 'line', 'source_to_sink', 'guard_gap', 'reachability', 'prelim_severity', 'confidence'],
        properties: {
          id_hint: { type: 'string' },
          title: { type: 'string' },
          category: { type: 'string', enum: ['01-security', '02-ai-mcp', '03-functional-bugs', '04-reliability-dos', '05-privacy-data', '06-supplychain-infra', '07-code-quality'] },
          component: { type: 'string' },
          file: { type: 'string' },
          line: { type: 'integer' },
          source_to_sink: { type: 'string', description: 'source (file:line) -> hops -> sink (file:line)' },
          guard_gap: { type: 'string', description: 'what guard is missing/wrong for THIS sink' },
          reachability: { type: 'string', description: 'which actor reaches it and preconditions' },
          cwe: { type: 'string' },
          owasp: { type: 'string' },
          prelim_severity: { type: 'string', enum: ['Critical', 'High', 'Medium', 'Low', 'Info'] },
          confidence: { type: 'number' },
          evidence: { type: 'string', description: 'the code excerpt that shows it' },
        },
      },
    },
  },
}

const VERDICT_SCHEMA = {
  type: 'object',
  required: ['refuted', 'reason', 'reachable', 'final_severity'],
  properties: {
    refuted: { type: 'boolean', description: 'true if the candidate is NOT a real, reachable defect' },
    reason: { type: 'string' },
    reachable: { type: 'boolean' },
    corrected_path: { type: 'string', description: 'the accurate source->sink path, or why none exists' },
    cvss_vector: { type: 'string' },
    cvss_score: { type: 'number' },
    final_severity: { type: 'string', enum: ['Critical', 'High', 'Medium', 'Low', 'Info'] },
  },
}

// ----------------------------------------------------------------------------
// PHASE 1 — MAP
// ----------------------------------------------------------------------------
phase('Map')
log('Phase 1: building the attack-surface map and dependency inventory')

const MAP_AREAS = [
  'Entry points: every tRPC procedure in apps/backend/src/routers + apps/backend/src/license, its auth wrapper, and its inputs.',
  'Data plane: the gRPC broker apps/logger/src/index.ts (RPCs, auth, trust of request fields) and apps/logger-consumer (NATS -> Postgres).',
  'Agent SDKs: the expression evaluators and their safe/unsafe toggles in node-sdk, python-sdk, java-sdk, ruby-sdk; serialization/redaction; quota/safety.',
  'MCP server + VS Code extension: tool definitions, how captured data reaches the AI agent, token handling, webview messaging/CSP, child_process use.',
  'Infra + supply chain: Dockerfile, infra/ compose (Consul/Traefik/NATS), build.sh, .husky, .github/workflows, all lockfiles/manifests, licensing server + LicenseManager.',
]

const maps = await parallel(MAP_AREAS.map((area, i) => () =>
  agent(`${RULES}\n\nMAP TASK (area ${i + 1}): ${area}\nList concrete entry points, dangerous sinks, trust boundaries, framework/lib versions, and anything that looks like a source->sink path worth tracing. Return a concise structured map, file:line where possible.`,
    { label: `map:${i + 1}`, phase: 'Map' })))

log('Writing audit/00-attack-surface-map.md from the area maps')
await agent(`${RULES}\n\nCombine these area maps into a single audit/00-attack-surface-map.md file (create the audit/ directory). Sections: Entry points, Dangerous sinks, Trust boundaries, Framework/lib versions, Dependency inventory, and a ranked list of the highest-value source->sink paths to trace next. Write the file.\n\nAREA MAPS:\n${maps.filter(Boolean).join('\n\n---\n\n')}`,
  { label: 'map:write', phase: 'Map' })

// ----------------------------------------------------------------------------
// PHASE 2/3/4 — REVIEW -> VERIFY -> VARIANT, pipelined per review unit
// ----------------------------------------------------------------------------
// Two axes of reviewers. Each returns structured candidates. Then each unit's
// candidates are adversarially verified (3 skeptics), survivors kept.

const COMPONENT_UNITS = [
  ['backend-authz', 'apps/backend/src/trpc.ts + all routers: broken access control, IDOR, multi-tenancy, mass assignment, function-level authz. Check every object-load-by-id for an ownership/tenancy guard and every procedure for the correct wrapper.'],
  ['backend-auth', 'apps/backend/src/routers/authRouter.ts + apps/backend/src/index.ts + helpers: JWT/session, SSO verifySso (incl. the e2e bypass branch and first-user-admin), login handoff via login:<identifier>, refresh binding, token secret sourcing.'],
  ['backend-observability', 'apps/backend/src/observability + rca + routers/observabilityIntegrationsRouter + rcaRouter: SSRF via Sentry apiBaseUrl allowlist, credential keyring/cipher crypto, ReDoS in filters, provider trust.'],
  ['logger-broker', 'apps/logger/src/index.ts: gRPC ServerCredentials.createInsecure, GetProbes/ReportTelemetry authentication & trust of request fields, source-map upload limits, Redis liveness races, license gating.'],
  ['logger-consumer', 'apps/logger-consumer/src: trust of NATS message content, write path to Postgres, error handling, resource limits.'],
  ['database', 'packages/database: Prisma schema, migrations, RBAC model, cascade deletes, indexes, any raw SQL.'],
  ['node-sdk', 'packages/node-sdk/src/core: inspector.ts evaluateOnCallFrame + throwOnSideEffect, evaluation-utils wrapping, serialization/redaction, quota/safety, source-map uploader. Attempt sandbox-escape reasoning.'],
  ['python-sdk', 'agents/python-sdk/hyperprobe: core/evaluator.py ast allowlist + SAFE_BUILTINS + 256-char cap, monitoring_engine safe/unsafe toggle path from server config, serializer, safety. Attempt dunder/attribute escapes.'],
  ['java-sdk', 'agents/java-sdk: hyperprobe-evaluator MVEL SafeASTValidator + template sandbox, instrumentation (ASM), serializer ObjectGraphLimiter/RedactionFilter. Attempt reflection/Runtime/class-loading escapes.'],
  ['ruby-sdk', 'agents/ruby-sdk/lib: core/evaluator.rb binding.eval + safe_ast_validator.rb, serializer, safety. Attempt backticks/system/send/const_get escapes.'],
  ['mcp-server', 'packages/mcp-server/src: tool definitions in index.ts, how snapshot data is returned to the AI agent, auth.ts token handling/scope, skills.ts + service-config.ts child_process/execFile, execSync git.'],
  ['vsc-extension', 'apps/vsc-extension: webview CSP in extension.ts, onDidReceiveMessage handlers, token storage, child_process git calls, trpc/auth.'],
  ['dashboard', 'apps/dashboard: localStorage token storage (useAuth.ts), auth middleware, any v-html/XSS, tRPC client, initialRelay/token utils.'],
  ['licensing', 'external/licensing-server/src + packages/common/src/license: Firebase creds, ES256 signing/verify, ignoreExpiration, heartbeat/relay phase input validation, bootstrap public key trust.'],
  ['infra-ci', 'infra/ (Consul -client=0.0.0.0, Traefik api.insecure + HostRegexp, NATS, hardcoded creds, .htpasswd, secrets in KV), Dockerfile, build.sh, .husky, .github/workflows (zizmor/actionlint reasoning), lockfiles for CVEs & dependency confusion.'],
]

const CLASS_UNITS = [
  ['class-access-control', 'Cross-cutting broken access control / IDOR / multi-tenancy across ALL entry points (tRPC + gRPC). For each object accessed by a user-supplied id, is there an ownership/tenancy check? Can a Viewer reach Manager/Admin actions? Can one tenant read another\'s probes/snapshots/logs?'],
  ['class-injection', 'Cross-cutting injection: probe condition/watch/log-template expressions reaching each SDK evaluator (SSTI/code injection), any SQL/NoSQL, command execution (child_process/execFile/execSync), Redis Lua eval, path traversal on filenames/source maps.'],
  ['class-eval-sandbox', 'The probe expression sandboxes as a class: correctness of Python ast allowlist, Node throwOnSideEffect, Java MVEL validator, Ruby ast validator; AND the unsafe toggle in all four — can a server-delivered probe/AgentGlobalConfig flip it to enable arbitrary execution inside the customer prod app? Trace the config path broker->agent.'],
  ['class-authn', 'Cross-cutting authentication/session/JWT: secret sourcing, algorithm pinning, refresh/session binding, SSO flow, replay, license JWT verification.'],
  ['class-crypto-secrets', 'Cross-cutting crypto & secrets: hardcoded secrets/keys, credential cipher (KDF/IV/mode), RNG for tokens/identifiers, license signing trust, secrets in Consul KV / compose / .env / .htpasswd.'],
  ['class-privacy', 'Cross-cutting data privacy: does redaction actually stop secrets/PII being captured and stored/shown; snapshot size/depth caps; cross-tenant snapshot visibility; debug SQL/param logging; data reaching the AI agent.'],
  ['class-ai-mcp', 'AI/MCP-specific: prompt injection & tool-output poisoning via captured production values returned by the MCP server; tool/description poisoning; MCP token scope & storage; context over-sharing. Map to OWASP LLM Top 10 + MCP Top 10.'],
  ['class-dos-hostsafety', 'Reliability/DoS with emphasis on the CUSTOMER host app: serialization depth/size/time, inspector/instrumentation pausing or deadlock, eval timeouts, quota, unbounded broker/consumer queues, NATS 64MB payloads.'],
  ['class-supplychain', 'Supply chain: dependency CVEs across npm/pip/maven/gem (map to CVE/GHSA), dependency confusion on @hyperprobe/*, hostile/blocking install & build hooks, GitHub Actions security, Dockerfile hygiene.'],
  ['class-error-logic', 'Error handling & logic: do auth/license/redaction/self-serve fallbacks fail closed; swallowed exceptions masking failures; races/TOCTOU on probe counters & license locks; unhandled rejections.'],
]

const ALL_UNITS = [...COMPONENT_UNITS.map(u => ['component', ...u]), ...CLASS_UNITS.map(u => ['class', ...u])]

log(`Phase 2-4: ${ALL_UNITS.length} review units, each pipelined through review -> verify -> variant`)

const perUnit = await pipeline(
  ALL_UNITS,
  // Stage 1: REVIEW -> structured candidates
  (unit) => agent(
    `${RULES}\n\nREVIEW UNIT [${unit[0]}] ${unit[1]}\nFocus: ${unit[2]}\nAlso independently check the relevant seed leads in ../hyperprobe-audit-pack/06-seed-leads.md that fall in this area, but treat them ONLY as hypotheses to prove or disprove — do not report an unproven lead, and look well beyond the leads. Return structured candidates; for each, give the real traced source->sink path and the guard gap, or omit it. Quality over quantity.`,
    { label: `review:${unit[1]}`, phase: 'Review', schema: CANDIDATE_SCHEMA },
  ),
  // Stage 2: VERIFY -> adversarial refutation (3 skeptics), keep survivors
  async (reviewResult, unit) => {
    const cands = (reviewResult && reviewResult.candidates) || []
    if (!cands.length) return { unit: unit[1], survivors: [] }
    const judged = await parallel(cands.map((c) => async () => {
      const votes = await parallel([0, 1, 2].map((k) => () =>
        agent(
          `${RULES}\n\nADVERSARIAL VERIFY (skeptic ${k + 1}). Try HARD to REFUTE this candidate by reading the actual code path. It is refuted if the source is not attacker-reachable, the sink isn't really reached, the guard actually holds for this sink, or the impact is misstated. Default to refuted=true when uncertain. Provide the corrected path and a CVSS v3.1 vector/score if it survives.\n\nCANDIDATE:\n${JSON.stringify(c)}`,
          { label: `verify:${c.title}#${k + 1}`, phase: 'Verify', schema: VERDICT_SCHEMA },
        )))
      const valid = votes.filter(Boolean)
      const refutedCount = valid.filter((v) => v.refuted).length
      const survives = valid.length > 0 && refutedCount < Math.ceil(valid.length / 2)
      // pick the surviving verdict with the highest severity signal for scoring
      const keep = valid.find((v) => !v.refuted) || valid[0] || null
      return { candidate: c, survives, verdicts: valid, chosen: keep }
    }))
    return { unit: unit[1], survivors: judged.filter((j) => j.survives) }
  },
  // Stage 3: VARIANT sweep for each surviving unit
  async (verifyResult, unit) => {
    if (!verifyResult || !verifyResult.survivors.length) return { unit: unit[1], confirmed: [] }
    const variantNote = await agent(
      `${RULES}\n\nVARIANT SWEEP for unit [${unit[1]}]. For each confirmed defect below, search the sibling code for the SAME defect shape (same missing ownership check on other endpoints, same eval toggle in the other SDKs, same string-built query, same unredacted field). List sibling file:line that share it (also vulnerable / safe / different). Keep it factual.\n\nCONFIRMED:\n${JSON.stringify(verifyResult.survivors.map((s) => ({ title: s.candidate.title, file: s.candidate.file, line: s.candidate.line })))}`,
      { label: `variant:${unit[1]}`, phase: 'Variant' })
    return { unit: unit[1], confirmed: verifyResult.survivors, variants: variantNote }
  },
)

// Flatten confirmed findings across units
const confirmed = []
for (const u of perUnit.filter(Boolean)) {
  if (u.confirmed && u.confirmed.length) {
    for (const s of u.confirmed) confirmed.push({ ...s, unit: u.unit, variants: u.variants })
  }
}
log(`Confirmed candidates after verify+variant: ${confirmed.length}`)

// ----------------------------------------------------------------------------
// PHASE 5 — REPORT: one file per finding, then register + summary + coverage
// ----------------------------------------------------------------------------
phase('Report')

await pipeline(
  confirmed,
  (f, _orig, i) => agent(
    `${RULES}\n\nWRITE-UP. Turn this confirmed finding into ONE Markdown file that EXACTLY follows ../hyperprobe-audit-pack/05-finding-template.md, and write it to audit/findings/<category>/<ID>-<slug>.md (create dirs). Assign the ID using the category prefix (SEC-/AIMCP-/BUG-/DOS-/PRIV-/SUP-/CQ-) and a zero-padded number derived from this index ${i + 1}. Fill CVSS v3.1 vector+score, CWE, OWASP/ASVS/CERT-In mapping, the traced path, evidence excerpt, remediation WITH a corrected code snippet, and the variant-check results. Do not inflate severity.\n\nFINDING DATA:\n${JSON.stringify({ candidate: f.candidate, chosen: f.chosen, variants: f.variants, unit: f.unit })}`,
    { label: `write:${f.candidate.title}`, phase: 'Report' }),
)

log('Building register, CSV, coverage and executive summary')
await agent(
  `${RULES}\n\nFINALISE. Read every file under audit/findings/. Produce:\n1) audit/findings-register.md — a table: ID | Title | Category | Severity | CVSS | CWE | file:line | Status.\n2) audit/findings-register.csv — columns exactly: ID,Title,Category,Severity,CVSS_Score,CVSS_Vector,CWE,OWASP,ASVS,Component,File,Line,Status,Confidence.\n3) audit/coverage.md — walk ../hyperprobe-audit-pack/03-checklist.md and mark each item Done/Partial/N-A/Not-covered with evidence, honestly noting gaps.\n4) audit/executive-summary.md — counts by severity and category, top risks, recurring themes, and an explicit statement of what was NOT covered. Write all four files.`,
  { label: 'finalise', phase: 'Report' })

// Completeness critic — one more pass for what was missed
const critic = await agent(
  `${RULES}\n\nCOMPLETENESS CRITIC. Review audit/00-attack-surface-map.md, the checklist, and audit/findings/. What was NOT covered — an entry point not traced, a sink not checked back to its source, an SDK evaluator escape not actually attempted, a dependency not CVE-checked, a claim left unverified? Return a concrete TODO list of the highest-value gaps to run next, file:line specific.`,
  { label: 'critic', phase: 'Report' })

return {
  confirmed_count: confirmed.length,
  units_reviewed: ALL_UNITS.length,
  gaps_next: critic,
}
