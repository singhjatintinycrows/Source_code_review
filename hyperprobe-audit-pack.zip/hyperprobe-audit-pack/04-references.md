# Citation References & Tool Links

All links verified week of **2026-09-24**. Use these exact standards for mapping every finding, and
these tools as triage accelerators (never as the sole basis for a finding).

---

## 1. Standards & frameworks to map findings to

### OWASP Top 10:2025 (web application risks)
Home: https://top10.owasp.org/2025/ · Repo: https://owasp.org/Top10/

| ID | Category |
|---|---|
| A01:2025 | Broken Access Control |
| A02:2025 | Security Misconfiguration |
| A03:2025 | Software Supply Chain Failures |
| A04:2025 | Cryptographic Failures |
| A05:2025 | Injection |
| A06:2025 | Insecure Design |
| A07:2025 | Authentication Failures |
| A08:2025 | Software or Data Integrity Failures |
| A09:2025 | Security Logging and Alerting Failures |
| A10:2025 | Mishandling of Exceptional Conditions |

### OWASP API Security Top 10 — 2023
https://owasp.org/API-Security/editions/2023/en/0x11-t10/
API1 Broken Object Level Authorization · API2 Broken Authentication · API3 Broken Object Property Level
Authorization · API4 Unrestricted Resource Consumption · API5 Broken Function Level Authorization ·
API6 Unrestricted Access to Sensitive Business Flows · API7 Server Side Request Forgery · API8 Security
Misconfiguration · API9 Improper Inventory Management · API10 Unsafe Consumption of APIs.

### OWASP ASVS 5.0.0 (verification requirements) — released May 2025
Project: https://owasp.org/www-project-application-security-verification-standard/ · Release: https://github.com/OWASP/ASVS/tree/v5.0.0
Chapters: V1 Encoding & Sanitization · V2 Validation & Business Logic · V3 Web Frontend Security ·
V4 API & Web Service · V5 File Handling · V6 Authentication · V7 Session Management · V8 Authorization ·
V9 Self-contained Tokens · V10 OAuth & OIDC · V11 Cryptography · V12 Secure Communication ·
V13 Configuration · V14 Data Protection · V15 Secure Coding & Architecture · V16 Security Logging &
Error Handling · V17 WebRTC.

### OWASP Top 10 for LLM Applications — 2025 (for the AI/MCP category)
https://genai.owasp.org/llm-top-10/ · PDF: https://owasp.org/www-project-top-10-for-large-language-model-applications/assets/PDF/OWASP-Top-10-for-LLMs-v2025.pdf
Key: LLM01 Prompt Injection · LLM02 Sensitive Information Disclosure · LLM06 Excessive Agency ·
LLM05 Improper Output Handling · LLM08 Vector/Embedding Weaknesses (as applicable).

### OWASP MCP Top 10 — 2025 (beta v0.1; for MCP server risks)
https://owasp.org/www-project-mcp-top-10/ · Repo: https://github.com/OWASP/www-project-mcp-top-10 ·
Cheat sheet: https://cheatsheetseries.owasp.org/cheatsheets/MCP_Security_Cheat_Sheet.html
MCP01 Token Mismanagement & Secret Exposure · MCP02 Privilege Escalation via Scope Creep ·
MCP03 Tool Poisoning · MCP04 Supply Chain & Dependency Tampering · MCP05 Command Injection & Execution ·
MCP06 Intent Flow Subversion · MCP07 Insufficient Authentication & Authorization · MCP08 Lack of Audit
& Telemetry · MCP09 Shadow MCP Servers · MCP10 Context Injection & Over-Sharing.
(Beta project — cite as guidance, note the version.)

### CWE Top 25 Most Dangerous Software Weaknesses — 2025
https://cwe.mitre.org/top25/archive/2025/2025_cwe_top25.html · CISA: https://www.cisa.gov/news-events/alerts/2025/12/11/2025-cwe-top-25-most-dangerous-software-weaknesses
Rank order: CWE-79 XSS · CWE-89 SQLi · CWE-352 CSRF · CWE-862 Missing Authorization · CWE-787 OOB Write ·
CWE-22 Path Traversal · CWE-416 Use After Free · CWE-125 OOB Read · CWE-78 OS Command Injection ·
CWE-94 Code Injection · CWE-120 Buffer Overflow · CWE-434 Unrestricted Upload · CWE-476 NULL Deref ·
CWE-121 Stack Overflow · CWE-502 Deserialization · CWE-122 Heap Overflow · CWE-863 Incorrect
Authorization · CWE-20 Improper Input Validation · CWE-284 Improper Access Control · CWE-200 Info
Exposure · CWE-306 Missing Authentication · CWE-918 SSRF · CWE-77 Command Injection · CWE-639
Authorization Bypass Through User-Controlled Key · CWE-770 Allocation Without Limits.
Full CWE list: https://cwe.mitre.org/

### CVSS v3.1 (severity scoring — use this)
Spec: https://www.first.org/cvss/v3.1/specification-document · Calculator: https://www.first.org/cvss/calculator/3.1 · User guide: https://www.first.org/cvss/v3-1/user-guide
Ratings: 0.0 None · 0.1–3.9 Low · 4.0–6.9 Medium · 7.0–8.9 High · 9.0–10.0 Critical.

### CERT-In (Indian regulatory guidelines — for the report's compliance annexure)
- Guidelines for Secure Application Design, Development, Implementation & Operations (25 Sep 2023):
  https://www.cert-in.org.in/PDF/Application_Security_Guidelines.pdf
- Comprehensive Cyber Security Audit Policy Guidelines (25 Jul 2025):
  https://www.cert-in.org.in/PDF/Comprehensive_Cyber_Security_Audit_Policy_Guidelines.pdf
- Technical Guidelines on SBOM, QBOM & CBOM, AIBOM, HBOM (v2.0):
  https://www.cert-in.org.in/PDF/TechnicalGuidelines-on-SBOM,QBOM&CBOM,AIBOM_and_HBOM_ver2.0.pdf
- Guidelines on AI-Accelerated Vulnerability Protection & Response for OEMs/Technology Providers
  (v1.0, 10 Jun 2026) — critical(CVSS 9–10)/high(7–8.9) disclosure & patch timelines, hardcoded-credential
  ban, SBOM: https://www.cert-in.org.in/PDF/OEM_and_Technology_Providers_Guidelines.pdf

### ISO/IEC 27001:2022 Annex A & NIST SSDF
- ISO/IEC 27001:2022 (Annex A controls, esp. A.8.25–A.8.31 secure development): https://www.iso.org/standard/27001
- NIST SSDF SP 800-218 v1.1 (current final): https://csrc.nist.gov/pubs/sp/800/218/final ·
  PDF: https://nvlpubs.nist.gov/nistpubs/specialpublications/nist.sp.800-218.pdf ·
  (v1.2 is in **draft** as of Dec 2025 — cite v1.1 as authoritative: PO/PS/PW/RV practices):
  https://csrc.nist.gov/projects/ssdf
- MITRE ATT&CK (technique mapping for impact chains): https://attack.mitre.org/

### OWASP methodology references
- Secure Code Review Cheat Sheet: https://cheatsheetseries.owasp.org/cheatsheets/Secure_Code_Review_Cheat_Sheet.html
- OWASP Web Security Testing Guide (WSTG): https://owasp.org/www-project-web-security-testing-guide/
- OWASP Proactive Controls: https://owasp.org/www-project-proactive-controls/

---

## 2. Tools (triage accelerators — verify every hit by hand)

### SAST / dataflow
- **Semgrep** — https://github.com/semgrep/semgrep · rulesets: `p/default p/javascript p/typescript p/python p/java p/ruby p/secrets p/owasp-top-ten p/docker`
  `pipx install semgrep && semgrep --config p/default --config p/owasp-top-ten .`
- **CodeQL** — https://github.com/github/codeql-cli-binaries (js/ts, python, java, ruby packs) for deep dataflow.
- **Bandit** (Python) — https://github.com/PyCQA/bandit · `pipx install bandit && bandit -r agents/python-sdk`
- **Brakeman** (Ruby) — https://github.com/presidentbeef/brakeman
- **NodeJsScan** — https://github.com/ajinabraham/nodejsscan (optional)

### Secret scanning (run over git history if available)
- **Gitleaks** — https://github.com/gitleaks/gitleaks · `gitleaks detect --source . --report-path gitleaks.json`
- **TruffleHog** — https://github.com/trufflesecurity/trufflehog

### SCA / dependencies / CVEs
- **OSV-Scanner** — https://github.com/google/osv-scanner · `osv-scanner scan --recursive .`
- **Trivy** — https://github.com/aquasecurity/trivy · `trivy fs .` · `trivy config .` · `trivy image <img>`
- **npm/pnpm audit**, **pip-audit** (https://github.com/pypa/pip-audit), **bundler-audit**
  (https://github.com/rubysec/bundler-audit), **OWASP Dependency-Check** (Java, https://owasp.org/www-project-dependency-check/)
- Advisory data: **OSV** https://osv.dev/ · **GitHub Advisory DB** https://github.com/advisories · **NVD** https://nvd.nist.gov/

### CI/CD & containers
- **zizmor** (GitHub Actions static analysis) — https://github.com/zizmorcore/zizmor
- **actionlint** — https://github.com/rhysd/actionlint
- **hadolint** (Dockerfile) — https://github.com/hadolint/hadolint

---

## 3. Claude Code security assets (skills / commands / workflows)

- **Claude Code source-code-review skill** (Anthropic) — the methodology this pack builds on; load it in Claude Code if present.
- **Anthropic `/security-review` command & GitHub Action** — https://github.com/anthropics/claude-code-security-review
  (copy `.claude/commands/security-review.md` into the repo to customise; or use the Action on PRs). Docs:
  https://support.claude.com/en/articles/11932705-automated-security-reviews-in-claude-code
- **Anthropic Agent Skills marketplace** — https://github.com/anthropics/skills · install: `/plugin marketplace add anthropics/skills`
- **Trail of Bits security skills for Claude Code** — https://github.com/trailofbits/skills · install: `/plugin marketplace add trailofbits/skills`
  Especially relevant plugins: `audit-context-building`, `static-analysis` (CodeQL/Semgrep/SARIF),
  `fp-check` (false-positive validation), `insecure-defaults`, `sharp-edges`, `differential-review`,
  `variant-analysis`, `supply-chain-risk-auditor`, `semgrep-rule-creator`.
- **Claude Code skills docs** — https://code.claude.com/docs/en/skills (project skills live in `.claude/skills/<name>/SKILL.md`; personal in `~/.claude/skills/`)
- **Claude Code dynamic workflows / ultracode docs** — https://code.claude.com/docs/en/workflows
  (turn on with `/effort ultracode`; save a run's script into `.claude/workflows/`)

---

## 4. Product / target context

- Target repo: `prodprobe` (product HyperProbe) — supplied as zip.
- Local test lab only (not audited): https://github.com/hypertestco/hp-test-payment-demo
