#!/usr/bin/env bash

echo -e "\n==== Pre commit checks ====="

BRANCH=$(git rev-parse --abbrev-ref HEAD)
# Use ^ and $ outside the group to strictly bound the entire string
PROTECTED_BRANCHES="^(master|main)$"

if [[ "$BRANCH" =~ $PROTECTED_BRANCHES ]]; then
  echo -e "\n=== Cannot commit to $BRANCH branch, please create your own branch and use PR ===="
  exit 1
fi
