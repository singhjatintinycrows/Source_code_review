# HyperProbe Architecture

HyperProbe is a production-grade, non-breaking debugger. This document outlines the lifecycle of a "Snapshot" from its creation in VS Code to its storage and eventual display.

## System Components

- **VS Code Plugin & MCP Server**: The interfaces (IDE extension or AI agent MCP tools) where developers and autonomous agents set Probes (Snapshots/Logs).
- **Backend (Fastify + tRPC)**: The control plane managing Probes and retrieving Snapshot data.
- **Logger (gRPC Broker)**: The stateless data plane that communicates with Agents.
- **Agents (Node-SDK / Java-SDK)**: The instrumentation layer running inside the host application.
- **Infrastructure**:
    - **Postgres**: Primary storage for Probes and Snapshots.
    - **Redis**: Liveliness tracking for Agents.
    - **NATS JetStream**: High-throughput message bus for Snapshot delivery.
    - **Consul**: Service discovery (DB/Redis/NATS urls).

## Snapshot Data Flow

### 1. Probe Creation
1. Developer right-clicks a line in VS Code and selects **"Set HyperProbe Snapshot"**.
2. Plugin sends a `createProbe` mutation to the **Backend** via tRPC.
3. **Backend** persists the Probe (file path, line number, env) in **Postgres**.

### 2. Probe Pickup
1. The **Agent** (running in the production app) periodically calls `GetProbes` on the **Logger** via gRPC.
2. The **Logger** updates the Agent's TTL in **Redis** (Liveliness).
3. **Logger** fetches active Probes for that environment from the **Database** (or a cache) and returns them to the Agent.
4. The **Agent** instruments the target code at the specified line using `v8-inspector` (Node) or `ASM/ByteBuddy` (Java).

### 3. Snapshot Capture & Reporting
1. The production code hits the instrumented line.
2. If a condition is configured, the **Agent** evaluates the condition in the local scope. If true (or unconditional), the **Agent** captures local variables and the stack trace and, when `shouldCaptureTraceId` is enabled, attempts to capture the active APM trace ID (OpenTelemetry, Datadog, New Relic, etc.) *without pausing execution*.
3. **Agent** sends the captured data to the **Logger** via `ReportSnapshot` (gRPC).
4. **Logger** pushes the Snapshot payload into **NATS JetStream**.

### 4. Persistence & Consumption
1. The **Logger-Consumer** pulls the Snapshot from **NATS**.
2. **Logger-Consumer** writes the Snapshot data to **Postgres**.

### 5. Visualization
1. The **VS Code Plugin** polls the **Backend** for new Snapshots.
2. **Backend** queries **Postgres** and returns the Snapshot list.
3. Developer views the rich variable state and stack trace directly in VS Code.

## Sequence Diagram

```mermaid
sequenceDiagram
    participant VSCode as VS Code Plugin
    participant BE as Backend (tRPC)
    participant DB as Postgres
    participant LG as Logger (gRPC)
    participant AG as Agent (SDK)
    participant NATS as NATS JetStream
    participant LC as Logger-Consumer

    %% Phase 1: Creation
    VSCode->>BE: createProbe(file, line, env)
    BE->>DB: Save Probe
    DB-->>BE: Success
    BE-->>VSCode: Success

    %% Phase 2: Pickup
    AG->>LG: GetProbes(agent_id)
    LG->>DB: Fetch active probes
    DB-->>LG: Probe List
    LG-->>AG: Send Probes
    Note over AG: Instrument Code

    %% Phase 3: Capture
    Note over AG: Code Executed
    AG->>LG: ReportSnapshot(data)
    LG->>NATS: Publish Snapshot
    LG-->>AG: Ack

    %% Phase 4: Storage
    LC->>NATS: Pull Snapshot
    LC->>DB: Store Snapshot

    %% Phase 5: Display
    VSCode->>BE: listSnapshots(probeId)
    BE->>DB: Query snapshots
    DB-->>BE: Snapshots
    BE-->>VSCode: Display Data
```

## Safety & Performance Principles

1. **Non-Blocking**: Agents never use `debugger` statements; they use async-safe instrumentation.
2. **Data Capping**: Snapshots are limited in depth and size (e.g., `MAX_DEPTH=5`, `MAX_SNAPSHOT_SIZE=2MB`) to prevent OOM in the host app.
3. **Stateless Broker**: The Logger is purely functional, ensuring horizontal scalability.
4. **Reliability**: NATS JetStream ensures no snapshots are lost if the consumer is temporarily down.
5. **Fail-Safe Conditional Probing**: Conditions evaluate in-process with runtime-specific safeguards (e.g., exception guards in Node and expression validation/allowlisting in JVM), failing closed without crashing the host process or incurring distributed latency.
