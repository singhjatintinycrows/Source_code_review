# Active-Agent Compatibility Gate

The logger again writes `stableStringify` of the full `AgentInfo` (including
`sdkVersion: agentVersion || undefined`) as the member of
`active_agents:<serviceId>`. The global ID set and lenient, non-atomic admission
protocol are unchanged. Backend raw-ID reads only bridge already-written branch
data; they are not a migration path.

As on master, service membership still includes metadata in its identity. A
same-ID metadata change can create another JSON member or fail admission at
capacity; stable-ID behavior is not part of this compatibility fix.

If incompatible loggers ever wrote raw IDs into shared `active_agents:*` keys:

1. Stop all incompatible writers and exclude those builds as rollback targets.
2. Before deploying old backends/loggers, repair the affected sets or allow a
   bounded age-out beyond the 100-second heartbeat window followed by pruning.
   Preserve valid JSON members and their scores. Any raw-ID repair must validate
   sidecar identity, use master-compatible serialization, and preserve the
   original score without overwriting an existing valid JSON member/score.
3. Verify every member of each affected service set is a complete,
   master-compatible `AgentInfo` JSON object for that service, not merely a
   parseable JSON value, before permitting old backends/loggers. Traffic refreshes
   the 120-second key TTL, so waiting for key expiry alone is insufficient;
   inactive service sets also need verification.

This change performs no live cleanup. Stable-ID migration and admission changes
remain deferred. Run heartbeat/E2E verification only against isolated Redis,
database, Consul, and NATS infrastructure; the existing E2E setup resets data.
