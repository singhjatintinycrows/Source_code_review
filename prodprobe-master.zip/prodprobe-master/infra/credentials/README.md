# Database Credential Encryption

Observability-provider credentials are encrypted by the backend before
PostgreSQL storage. The backend decrypts a credential only in memory when
calling an observability provider.

## Consul Keyring

Consul is the only source of credential-encryption key material. Each
deployment uses these keys:

```text
HYPERPROBE/CREDENTIAL_ENCRYPTION/KEYRING
HYPERPROBE/CREDENTIAL_ENCRYPTION/ACTIVE_VERSION
```

Maintenance operations also use a leased lock and a non-secret in-progress
marker under the same Consul prefix. They do not contain encryption UUIDs.

The keyring is a JSON object mapping permanent version names to UUID v4
secrets:

```json
{"v1":"550e8400-e29b-41d4-a716-446655440000"}
```

The active-version value is the version used for new encryption:

```text
v1
```

The backend derives a 32-byte AES-256-GCM key from every UUID with
HKDF-SHA-256. UUIDs, the full JSON keyring, plaintext credentials, and
ciphertext must never be logged or committed to Git.

Every keyring version is retained forever. Versions must use the `v<number>`
format, and rotation creates the next version after the largest existing
numeric suffix.

## Backend Startup

Before accepting HTTP requests, the backend reads and validates both Consul
keys.

- A valid keyring and active version are loaded without writing to Consul.
- When both keys are absent and no observability connections exist, the
  backend atomically creates `v1` and its UUID v4 secret.
- When both keys are absent while connections exist, startup fails. Run the
  explicit destructive initialization script instead.
- A retained in-progress rotation marker blocks initialization until that
  rotation is resumed and completed.
- A missing single key, malformed JSON, invalid version, invalid UUID, or an
  active version absent from the keyring causes startup to fail.
- Consul unavailability is not treated as a missing keyring.
- Backend startup and operations that encrypt or decrypt observability
  credentials are blocked while the maintenance lock is held, preventing an
  automatically restarted or stale instance from joining a rotation in
  progress.

Initialization uses Consul compare-and-set writes for both values, so multiple
backend instances cannot create conflicting initial keyrings.

## Local Development

The root `.env-hp` is tracked and contains only safe local defaults and Consul
connectivity. It must not contain credential-encryption key material.

Start local infrastructure and the backend normally:

```sh
pnpm infra-up
pnpm --filter backend dev
```

The first backend start against an empty local database and empty Consul
automatically creates `v1`. Later starts load the persisted keyring from the
local Consul volume.

Removing the Consul volume while retaining encrypted connection rows prevents
backend startup. This is intentional: a new keyring cannot decrypt those rows.

## Destructive Initialization

Use this only when both Consul encryption keys are absent and existing
connections are intentionally being discarded:

```sh
pnpm credentials:initialize -- --discard-existing-connections --confirm=DISCARD_OBSERVABILITY_CONNECTIONS
```

The script requires a maintenance window. It acquires a Consul lock, removes
all `ObservabilityConnection` rows, allows capability-binding cascades to run,
retains observability audit events, and creates a fresh `v1` keyring. It
refuses to discard connections when a valid Consul keyring already exists.

Deleting rows does not erase historical ciphertext from PostgreSQL WAL or
backups. It only discards application-level connection data.

## Manual Rotation

Rotation is never automatic and has no time-based scheduler. Run it during a
maintenance window with all backend instances stopped:

```sh
pnpm credentials:rotate
```

Preview its work without changing Consul or PostgreSQL:

```sh
pnpm credentials:rotate -- --dry-run
```

The script acquires a Consul lock, records its non-secret in-progress target,
appends a UUID v4 under the next version, sets that version active in the same
Consul transaction, and re-encrypts every connection still using an older
version. It works in batches and resumes the recorded target after a partial
failure. Existing and new versions remain decryptable because old UUIDs are
never removed.

If rotation is interrupted, the in-progress marker keeps credential operations
blocked even after the Consul lock lease expires. Re-run the same rotation
script to finish the recorded target before restarting backend instances.

After a successful rotation, restart all backend instances so they load the
new active version. Running processes do not watch Consul for keyring changes.

## Production Operations

The deployment Compose file provides only Consul connectivity to the backend;
it does not inject credential secrets through environment variables. The
Consul data volume and every Consul snapshot must be retained alongside
PostgreSQL backups. Restoring a database without the matching historical
keyring makes encrypted credentials unrecoverable.

The production image bundles both maintenance scripts. With PostgreSQL and
Consul already running, execute them from `infra/prod` during maintenance:

```sh
docker compose -f docker-compose.prod.yml run --rm --no-deps backend node backend/dist/credentials-initialize.cjs --discard-existing-connections --confirm=DISCARD_OBSERVABILITY_CONNECTIONS
docker compose -f docker-compose.prod.yml run --rm --no-deps backend node backend/dist/credentials-rotate.cjs
```

This deployment currently relies on the configured VPN boundary for Consul
access. Limit access to the Consul endpoint and plan ACL/TLS hardening before
expanding that network boundary.
