# frozen_string_literal: true

# 1. Require HyperProbe initialization as early as possible
require_relative 'hyperprobe'

require 'json'
require 'webrick'
require 'securerandom'

class CheckoutService
  def self.process_checkout(user_id, items)
    cart_total = 0.0 # HP_E2E_DURATION_START

    user_session = {
      'id' => user_id,
      'authenticated' => true,
      'flags' => %w[premium beta-tester],
      'password' => 'super-secret-password'
    }
    # Circular reference to test safe object serialization
    user_session['circular'] = user_session

    if items
      items.each do |item|
        price = item['price'].to_f
        quantity = (item['quantity'] || 1).to_i
        item_price = price * quantity
        discount = item_price > 100 ? 0.1 : 0.0 # HP_E2E_ITEM
        cart_total += item_price - (item_price * discount)
      end
    end

    # Clean version for response
    clean_user_session = user_session.reject { |k, _| k == 'circular' } # HP_E2E_SNAPSHOT_AND_DURATION_END

    {
      'status' => 'success',
      'user' => clean_user_session,
      'total' => cart_total,
      'timestamp' => (Time.now.to_f * 1000).to_i
    }
  end
end

port = (ENV['PORT'] || 4003).to_i
server = WEBrick::HTTPServer.new(Port: port, Logger: WEBrick::Log.new($stderr, WEBrick::Log::WARN), AccessLog: [])

server.mount_proc '/health' do |_req, res|
  res.status = 200
  res['Content-Type'] = 'application/json'
  res.body = JSON.generate({ status: 'UP' })
end

server.mount_proc '/checkout' do |req, res|
  Thread.current[:hyperprobe_demo_trace_id] = SecureRandom.uuid
  res['X-Hyperprobe-Demo-Trace-Id'] = Thread.current[:hyperprobe_demo_trace_id]
  begin
    payload = JSON.parse(req.body || '{}')
    user_id = payload['userId'] || 'anonymous'
    items = payload['items'] || []

    response_data = CheckoutService.process_checkout(user_id, items)

    res.status = 200
    res['Content-Type'] = 'application/json'
    res.body = JSON.generate(response_data)
  rescue StandardError => e
    res.status = 500
    res['Content-Type'] = 'application/json'
    res.body = JSON.generate({ error: e.message })
  ensure
    Thread.current[:hyperprobe_demo_trace_id] = nil
  end
end

trap('INT') do
  server.shutdown
  HyperProbe.shutdown
end

trap('TERM') do
  server.shutdown
  HyperProbe.shutdown
end

puts "Starting Ruby Demo App on port #{port}..."
server.start
