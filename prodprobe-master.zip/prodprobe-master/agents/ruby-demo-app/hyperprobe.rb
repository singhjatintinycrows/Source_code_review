# frozen_string_literal: true

require 'hyperprobe'

# Initialize HyperProbe Agent
HyperProbe.start(
  service_id: ENV['HYPERPROBE_SERVICE_ID'] || 'demo-app-ruby',
  environment: ENV['HYPERPROBE_ENVIRONMENT'] || 'development',
  broker_url: ENV['HYPERPROBE_BROKER_URL'] || 'localhost:50051',
  commit_sha: ENV['GIT_COMMIT'] || ENV['HYPERPROBE_COMMIT_SHA'] || 'ruby-demo-sha',
  set_trace_id: -> { Thread.current[:hyperprobe_demo_trace_id] }
)
