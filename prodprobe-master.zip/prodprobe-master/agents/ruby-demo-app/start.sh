#!/usr/bin/env bash
set -e

DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
export PORT="${PORT:-4003}"
export HYPERPROBE_SERVICE_ID="<service-uuid-from-dashboard>"
export HYPERPROBE_ENVIRONMENT="${HYPERPROBE_ENVIRONMENT:-development}"
export HYPERPROBE_BROKER_URL="${HYPERPROBE_BROKER_URL:-localhost:50051}"
export GIT_COMMIT="${GIT_COMMIT:-ruby-demo-sha}"
# export DEBUG="hyperprobe*"
export HYPERPROBE_SYNC_INTERVAL_MS="5000"

if [ "$1" = "--jruby" ] || [ "$USE_JRUBY" = "true" ] || [ "$USE_JRUBY" = "1" ]; then
  echo "[HyperProbe Demo] Starting with JRuby (JVM)..."
  if [ -z "${BUNDLE_GEMFILE:-}" ]; then
    if jruby -e 'exit(Gem::Version.new(RUBY_VERSION) < Gem::Version.new("3.2") ? 0 : 1)'; then
      export BUNDLE_GEMFILE="$DIR/Gemfile.jruby_legacy"
    else
      export BUNDLE_GEMFILE="$DIR/Gemfile.jruby"
    fi
  fi
  export JRUBY_OPTS="${JRUBY_OPTS:-} --debug -J-Djruby.ir.passes=AddCallProtocolInstructions,AddMissingInitsPass -J-Djruby.ir.jit.passes=AddCallProtocolInstructions,AddMissingInitsPass"
  exec jruby -S bundle exec jruby "$DIR/app.rb"
else
  echo "[HyperProbe Demo] Starting with standard Ruby..."
  export BUNDLE_GEMFILE="${BUNDLE_GEMFILE:-$DIR/Gemfile}"
  exec bundle exec ruby "$DIR/app.rb"
fi
