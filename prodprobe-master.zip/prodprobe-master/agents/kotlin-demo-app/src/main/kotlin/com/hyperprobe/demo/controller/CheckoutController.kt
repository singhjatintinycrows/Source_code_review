package com.hyperprobe.demo.controller

import com.hyperprobe.demo.model.CheckoutRequestDto
import com.hyperprobe.demo.model.CheckoutResponseDto
import com.hyperprobe.demo.service.CheckoutService
import org.springframework.web.bind.annotation.PostMapping
import org.springframework.web.bind.annotation.RequestBody
import org.springframework.web.bind.annotation.RestController

@RestController
class CheckoutController(private val checkoutService: CheckoutService) {

    @PostMapping("/checkout")
    fun checkout(@RequestBody req: CheckoutRequestDto): CheckoutResponseDto {
        val resp = checkoutService.processCheckout(req)
        println("[DemoApp] Checkout processed. Status: ${resp.status}, UserId: ${req.userId}")
        return resp
    }
}
