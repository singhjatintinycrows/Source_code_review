package com.hyperprobe.demo.model

import com.fasterxml.jackson.annotation.JsonIgnore
import java.time.Instant

data class CheckoutRequestDto(
    val userId: String = "",
    val items: List<ItemDto>? = null
)

data class ItemDto(
    val price: Double? = null,
    val quantity: Int? = null
)

class UserSessionDto {
    var id: String? = null
    var authenticated: Boolean = false
    var flags: List<String>? = null
    var password: String? = null
    @JsonIgnore
    var circular: UserSessionDto? = null
}

data class CheckoutResponseDto(
    var status: String? = null,
    var user: UserSessionDto? = null,
    var total: Double? = null,
    var timestamp: String = Instant.now().toString()
)
