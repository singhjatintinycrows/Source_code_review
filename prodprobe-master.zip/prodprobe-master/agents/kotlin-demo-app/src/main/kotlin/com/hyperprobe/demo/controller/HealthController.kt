package com.hyperprobe.demo.controller

import org.springframework.web.bind.annotation.GetMapping
import org.springframework.web.bind.annotation.RestController

@RestController
class HealthController {

    @GetMapping("/health")
    fun health(): Map<String, String> {
        val response = mutableMapOf<String, String>()
        response["status"] = "UP"
        return response
    }
}
