package com.hyperprobe.demo.service

import com.hyperprobe.demo.model.CheckoutRequestDto
import com.hyperprobe.demo.model.CheckoutResponseDto
import com.hyperprobe.demo.model.UserSessionDto
import org.springframework.stereotype.Service
import java.time.Instant
import java.util.concurrent.atomic.AtomicInteger

@Service
class CheckoutService {
    private val numb = AtomicInteger(0)

    fun processCheckout(req: CheckoutRequestDto): CheckoutResponseDto {
        numb.incrementAndGet()
        val userId = req.userId

        var cartTotal = 0.0
        val userSession = UserSessionDto().apply {
            id = userId
            authenticated = true
            flags = listOf("premium", "beta-tester")
            password = "super-secret-password" // Should be redacted
            circular = this // Should be detected
        }

        req.items?.forEach { item ->
            // Loop processing logic where we might want to set a probe
            val itemPrice = (item.price ?: 0.0) * (item.quantity ?: 1)

            // Applying some discount
            val discount = if (itemPrice > 100) 0.1 else 0.0
            cartTotal += itemPrice - (itemPrice * discount)
        }

        // Final confirmation logic
        return CheckoutResponseDto(
            status = "success",
            user = userSession,
            total = cartTotal,
            timestamp = Instant.now().toString()
        )
    }
}
