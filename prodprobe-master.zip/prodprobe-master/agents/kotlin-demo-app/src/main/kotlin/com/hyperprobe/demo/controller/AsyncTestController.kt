package com.hyperprobe.demo.controller

import org.springframework.web.bind.annotation.GetMapping
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.RestController
import reactor.core.publisher.Mono
import reactor.core.scheduler.Schedulers
import java.util.concurrent.CompletableFuture
import kotlin.concurrent.thread

@RestController
@RequestMapping("/api/async")
class AsyncTestController {

    // 1. Fire synchronous operations in a different thread and wait on the main thread
    @GetMapping("/thread")
    fun testRawThread(): Map<String, String> {
        val result = mutableMapOf<String, String>()
        val worker = thread(name = "hyperprobe-simulated-worker") {
            // PROBE TARGET: Place a snapshot here to observe the raw thread stack
            val simulatedHttpCallResult = "Data from simulated HTTP call"
            result["status"] = "success"
            result["data"] = simulatedHttpCallResult
            result["context"] = "raw-thread"
        }

        worker.join() // Main thread waits for completion
        return result
    }

    // 2. Use CompletableFutures for sync/async operations
    @GetMapping("/future")
    fun testCompletableFuture(): CompletableFuture<Map<String, String>> {
        return CompletableFuture.supplyAsync {
            // PROBE TARGET: Place a snapshot here to observe ForkJoinPool stack
            try {
                Thread.sleep(50) // simulate delay
            } catch (e: InterruptedException) {
                Thread.currentThread().interrupt()
            }

            mapOf(
                "status" to "success",
                "data" to "Processed via CompletableFuture",
                "context" to "fork-join-pool"
            )
        }
    }

    // 3. Use Reactor (WebFlux paradigm) to shift execution context
    @GetMapping("/reactor")
    fun testReactor(): Mono<Map<String, String>> {
        return Mono.fromCallable {
            // PROBE TARGET: Place a snapshot here to observe Reactor BoundedElastic stack
            val result = mapOf(
                "status" to "success",
                "data" to "Processed via Reactor Mono",
                "context" to "reactor-elastic"
            )
            println(result)
            
            result // Implicitly returned by the lambda
        }.subscribeOn(Schedulers.boundedElastic()) // Shifts execution to background thread
    }
}
