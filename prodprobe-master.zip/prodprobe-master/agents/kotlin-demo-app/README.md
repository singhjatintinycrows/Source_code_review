# HyperProbe Kotlin Demo Application

This application is a strict 1:1 Kotlin Spring Boot replication of the HyperProbe Java `java-demo-app`. It is designed to act as a target application for testing the HyperProbe Java Agent, verifying that all bytecode manipulation and variable extraction rules work seamlessly with Kotlin constructs.

## Functionality Overview

The application simulates a production e-commerce backend with two primary endpoints:

1.  **High-Throughput Endpoint (`/health`)**: A simple, fast endpoint used to benchmark the overhead of the HyperProbe agent.
2.  **Complex Logic Endpoint (`/checkout`)**: Simulates a checkout flow with loops, conditional logic, and intentional complexity (including circular references). This is used to test how well the HyperProbe agent captures local variables, handles object serialization limits, and reports errors.
3.  **Async Testing Endpoints (`/api/async/*`)**: Demonstrates and tests how the Java SDK handles stack traces across various asynchronous execution boundaries (Raw Threads, CompletableFutures, and Project Reactor).

---

## Prerequisites

- **Java 17** or higher (Java 21 recommended)
- **Maven 3.8+**
- **Built Java SDK**: Ensure you have built the Java SDK first:
  ```bash
  cd ../java-sdk
  mvn clean install -DskipTests
  ```

---

## Testing Artifacts

The following file is provided in this directory for local testing:

- `kotlin-seed-probe.ts`: A script to seed test probes into a running database for Online Mode.

### Seeding Probes (Online Mode)

If you are running the backend in Online Mode and want to quickly inject test probes into your database:

```bash
# From the root of the repository
npx tsx agents/kotlin-demo-app/kotlin-seed-probe.ts
```

---

## Scenarios & Commands

Run all commands from the `agents/kotlin-demo-app` directory.

### 1. Run Without the Agent (Standalone)

Ideal for verifying baseline functionality.

```bash
mvn spring-boot:run
```

### 2. Run With Agent (Online Mode)

Connects to a running HyperProbe Broker (default `localhost:50051`).

```bash
export GIT_COMMIT=test
export HYPERPROBE_SERVICE_ID=kotlin-demo-service
export HYPERPROBE_ENVIRONMENT=development
export HYPERPROBE_BROKER_URL=localhost:50051

mvn spring-boot:run -Dspring-boot.run.jvmArguments="-javaagent:../java-sdk/hyperprobe-agent/target/hyperprobe-agent-0.0.0.jar"
```

### 3. Run With Debug Logging

Enable internal agent debug logs to troubleshoot instrumentation or synchronization.

```bash
export DEBUG=hyperprobe*
export GIT_COMMIT=test
export HYPERPROBE_SERVICE_ID=f74259ba-f7a0-4973-9d37-024a19cbee10
export HYPERPROBE_ENVIRONMENT=development
export HYPERPROBE_BROKER_URL=localhost:50051

mvn spring-boot:run -Dspring-boot.run.jvmArguments="-javaagent:../java-sdk/hyperprobe-agent/target/hyperprobe-agent-0.0.0.jar"
```

---

## Triggering Hits

Once the app is running (default port `8080`), trigger the logic using `curl`:

### Checkout Hit

```bash
curl -X POST http://localhost:8080/checkout \
-H "Content-Type: application/json" \
-d '{"userId": "user-123", "items": [{"price": 1200, "quantity": 1}]}'
```

### Health Check

```bash
curl http://localhost:8080/health
```

### Async Boundaries

These endpoints shift execution to background threads. Try placing a probe inside the respective lambdas in `AsyncTestController.kt` to observe how stack traces are captured on background threads.

```bash
# 1. Raw Thread execution
curl http://localhost:8080/api/async/thread

# 2. CompletableFuture (ForkJoinPool) execution
curl http://localhost:8080/api/async/future

# 3. Project Reactor (BoundedElastic) execution
curl http://localhost:8080/api/async/reactor
```
