# HyperProbe Java 25 Vert.x + RxJava 3 Demo App

This application is a minimal Vert.x 4 + RxJava 3 service compiled under **Java 25**. It simulates reactive route handling with Guice dependency injection and acts as a target application for testing the HyperProbe Java Agent under modern JDK versions.

---

## 🚀 Overview

* **JDK Target**: Java 25 (`25.0.2-open`)
* **Framework**: Vert.x 4 (`4.5.10`)
* **Reactive Engine**: RxJava 3 (`3.1.8`)
* **Dependency Injection**: Google Guice (`7.0.0`)
* **Primary Endpoint**: `/healthcheck` (implemented in `com.fancode.core.rest.HealthCheck`)

---

## 🛠️ Prerequisites

1. **Java 25**: Installed via SDKMAN or system JDK.
2. **Maven 3.8+**: Used to compile the application and agent.
3. **Built Java Agent**: Ensure the HyperProbe Java SDK has been built:
   ```bash
   cd ../java-sdk
   mvn clean package -DskipTests
   ```

---

## 📦 Building the Application

Run the following command inside this directory (`agents/java25-vertx-rx-app`):

```bash
export SDKMAN_DIR="/opt/homebrew/opt/sdkman-cli/libexec"
source "$SDKMAN_DIR/bin/sdkman-init.sh"
sdk use java 25.0.2-open

mvn clean package -DskipTests
```

This generates the shaded fat JAR at:
`target/fancode-service-0.0.0.jar`

---

## ▶️ Running the Application

### 1. Standalone Mode (Without Agent)

To run the application directly without the HyperProbe agent:

```bash
java -jar target/fancode-service-0.0.0.jar
```

The server starts on port `8089`:
`Fancode Vert.x server started on port 8089`

---

### 2. With HyperProbe Agent (Online / Live Broker Mode)

To run the application with the HyperProbe Java Agent attached under Java 25:

```bash
export SDKMAN_DIR="/opt/homebrew/opt/sdkman-cli/libexec"
source "$SDKMAN_DIR/bin/sdkman-init.sh"
sdk use java 25.0.2-open

# Agent & Environment Configuration
export DEBUG="hyperprobe*"
export GIT_COMMIT="testcommit"
export HYPERPROBE_SERVICE_ID="8c680c29-8802-4caf-ad26-a93b52ffbd55"
export HYPERPROBE_ENVIRONMENT="development"
export HYPERPROBE_BROKER_URL="http://localhost:50051"

java -javaagent:../java-sdk/hyperprobe-agent/target/hyperprobe-agent-0.0.0.jar \
     -jar target/fancode-service-0.0.0.jar
```

---

### 3. Integrated Test Runner (With Embedded Mock Broker)

For offline testing without a running backend server, launch the built-in `TestRunner` which starts an embedded mock broker on port `60051`, registers a probe on line 38 of `HealthCheck.java`, and invokes `/healthcheck`:

```bash
export SDKMAN_DIR="/opt/homebrew/opt/sdkman-cli/libexec"
source "$SDKMAN_DIR/bin/sdkman-init.sh"
sdk use java 25.0.2-open

export DEBUG="hyperprobe*"
export GIT_COMMIT="testcommit"
export HYPERPROBE_SERVICE_ID="12345678-1234-1234-1234-123456789012"
export HYPERPROBE_ENVIRONMENT="pre-prod"
export HYPERPROBE_BROKER_URL="http://localhost:60051"

# Terminal 1: Start Mock Broker
java -cp target/fancode-service-0.0.0.jar:../java-sdk/hyperprobe-core/target/hyperprobe-core-0.0.0.jar com.fancode.MockBrokerServer &

# Terminal 2: Run Fancode Vert.x Application with Agent
java -javaagent:../java-sdk/hyperprobe-agent/target/hyperprobe-agent-0.0.0.jar \
     -cp target/fancode-service-0.0.0.jar:../java-sdk/hyperprobe-core/target/hyperprobe-core-0.0.0.jar:../java-sdk/hyperprobe-runtime/target/hyperprobe-runtime-0.0.0.jar:../java-sdk/hyperprobe-config/target/hyperprobe-config-0.0.0.jar \
     com.fancode.TestRunner
```

---

## 🌐 API Call Examples

### Health Check Endpoint (`GET /healthcheck`)

#### **Basic Request**:
```bash
curl http://localhost:8089/healthcheck
```
*Response*:
```json
{
  "redis": { "status": "UP", "latencyMs": 2 },
  "mysql": { "status": "UP", "latencyMs": 5 },
  "vault": {},
  "app": { "version": "" }
}
```

#### **With Version Check Parameter (`checkVersion=true`)**:
```bash
curl "http://localhost:8089/healthcheck?checkVersion=true"
```
*Response*:
```json
{
  "redis": { "status": "UP", "latencyMs": 2 },
  "mysql": { "status": "UP", "latencyMs": 5 },
  "vault": {},
  "app": { "version": "fancode-service-1.0.0" }
}
```

---

## 🎯 Probing with VS Code Extension

1. Ensure `.hprc` file is present in the workspace root with content:
   ```json
   {
     "serviceId": "******"
   }
   ```
2. Open `src/main/java/com/fancode/core/rest/HealthCheck.java` in VS Code.
3. Add a snapshot probe on **Line 38** (`var checkVersion = request.getQueryParam("checkVersion");`).
4. Execute `curl "http://localhost:8089/healthcheck?checkVersion=true"`.
5. The snapshot containing local variables (`request`, `checkVersion`, `this`, `appVersion`) will immediately trigger and appear in your HyperProbe extension view.
