package com.fancode.rest;

public enum HttpMethod {
    GET, POST, PUT, DELETE
}
