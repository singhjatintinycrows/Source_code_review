package com.fancode;

import hyperprobe.agent.v1.Agent;
import hyperprobe.agent.v1.AgentBrokerGrpc;
import io.grpc.Server;
import io.grpc.ServerBuilder;
import io.grpc.stub.StreamObserver;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;

public class TestRunner {

    static class MockBrokerService extends AgentBrokerGrpc.AgentBrokerImplBase {
        @Override
        public void getProbes(Agent.GetProbesRequest request, StreamObserver<Agent.GetProbesResponse> responseObserver) {
            System.out.println("[MockBrokerService] Received GetProbesRequest from agent: " + request.getAgentId());

            Agent.Probe probe = Agent.Probe.newBuilder()
                    .setId("probe-healthcheck-38")
                    .setType(Agent.ProbeType.PROBE_TYPE_SNAPSHOT)
                    .setRuntimeLocation("src/main/java/com/fancode/core/rest/HealthCheck.java")
                    .setRuntimeLine(38) // Line 38: var checkVersion = request.getQueryParam("checkVersion");
                    .setHitLimit(10)
                    .setExpiryTime(System.currentTimeMillis() + 600000)
                    .build();

            Agent.GetProbesResponse response = Agent.GetProbesResponse.newBuilder()
                    .addProbes(probe)
                    .build();

            responseObserver.onNext(response);
            responseObserver.onCompleted();
        }

        @Override
        public void reportTelemetry(Agent.TelemetryBatch request, StreamObserver<Agent.TelemetryResponse> responseObserver) {
            System.out.println("\n🔥🔥🔥 [MockBrokerService] RECEIVED TELEMETRY EVENT FROM AGENT! 🔥🔥🔥");
            System.out.println("[MockBrokerService] Events count: " + request.getEventsCount());
            for (Agent.TelemetryEvent event : request.getEventsList()) {
                System.out.println("  -> Event Probe ID: " + event.getProbeId());
                System.out.println("  -> Captured Vars JSON: " + event.getCapturedVarsJson());
            }

            Agent.TelemetryResponse response = Agent.TelemetryResponse.newBuilder().build();
            responseObserver.onNext(response);
            responseObserver.onCompleted();
        }
    }

    public static void main(String[] args) throws Exception {
        System.out.println("=== Starting Fancode Vert.x App ===");
        FancodeApplication.main(args);
        Thread.sleep(2000); // Wait for sync and Vert.x server startup

        System.out.println("\n---> Invoking HTTP GET http://localhost:8089/healthcheck ...");
        HttpClient client = HttpClient.newHttpClient();
        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create("http://localhost:8089/healthcheck"))
                .GET()
                .build();

        HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());
        System.out.println("<--- Received HTTP " + response.statusCode() + " response: " + response.body());

        System.out.println("\nWaiting for potential telemetry flushing...");
        Thread.sleep(3000);

        System.out.println("=== Test Runner Complete ===");
        System.exit(0);
    }
}
