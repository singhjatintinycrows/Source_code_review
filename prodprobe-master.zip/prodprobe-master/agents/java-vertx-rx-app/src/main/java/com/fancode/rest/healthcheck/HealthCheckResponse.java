package com.fancode.rest.healthcheck;

import io.vertx.core.json.JsonObject;

public class HealthCheckResponse {
    private String status;
    private JsonObject details;

    public HealthCheckResponse() {}

    public HealthCheckResponse(String status, JsonObject details) {
        this.status = status;
        this.details = details;
    }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public JsonObject getDetails() { return details; }
    public void setDetails(JsonObject details) { this.details = details; }
}
