package com.fancode.core.rest;

import com.fancode.core.dao.HealthCheckDao;
import com.fancode.rest.AbstractRoute;
import com.fancode.rest.HttpMethod;
import com.fancode.rest.Request;
import com.fancode.rest.Route;
import com.fancode.rest.healthcheck.HealthCheckResponse;
import com.fancode.rest.healthcheck.HealthCheckUtil;
import com.google.common.collect.ImmutableMap;
import com.google.inject.Inject;
import io.reactivex.rxjava3.core.Single;
import io.vertx.core.json.JsonObject;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Map;

@Route(path = "/healthcheck", consumes = "*", httpMethod = HttpMethod.GET)
public class HealthCheck extends AbstractRoute<HealthCheckResponse> {

  private static final Logger log = LoggerFactory.getLogger(HealthCheck.class);

  HealthCheckDao healthCheckDao;

  public HealthCheck() {
    this.healthCheckDao = new HealthCheckDao();
  }

  @Inject
  public HealthCheck(HealthCheckDao healthCheckDao) {
    this.healthCheckDao = healthCheckDao;
  }


  @Override
  public Single<HealthCheckResponse> handle(Request request) {
    var checkVersion = request.getQueryParam("checkVersion");
    String appVersion = "";
    if ("true".equals(checkVersion)){
      appVersion = getAppVersion();
    }
    var vault = new JsonObject();
    Map<String, Single<JsonObject>> map = ImmutableMap.<String, Single<JsonObject>>builder()
            .put("redis", healthCheckDao.redisHealthCheck())
            .put("mysql", healthCheckDao.mysqlHealthCheck())
            .put("vault", Single.just(vault))
            .put("app", Single.just(new JsonObject().put("version", appVersion)))
            .build();

    return HealthCheckUtil.handler(map);
  }

  public String getAppVersion(){
    try {
      String jarPath = HealthCheck.class.getProtectionDomain().getCodeSource().getLocation().getPath();
      String jarFileName = jarPath.substring(jarPath.lastIndexOf('/') + 1);
      var appVersion =  jarFileName.replace("-fat.jar", "");
      return StringUtils.isBlank(appVersion) ? jarPath : appVersion;
    } catch (Exception e) {
      log.error("Error in reading app name version", e);
      return "";
    }
  }
}
