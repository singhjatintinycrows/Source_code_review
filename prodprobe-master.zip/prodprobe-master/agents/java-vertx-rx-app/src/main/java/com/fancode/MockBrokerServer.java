package com.fancode;

import hyperprobe.agent.v1.Agent;
import hyperprobe.agent.v1.AgentBrokerGrpc;
import io.grpc.Server;
import io.grpc.ServerBuilder;
import io.grpc.stub.StreamObserver;

public class MockBrokerServer {

    static class MockBrokerService extends AgentBrokerGrpc.AgentBrokerImplBase {
        @Override
        public void getProbes(Agent.GetProbesRequest request, StreamObserver<Agent.GetProbesResponse> responseObserver) {
            System.out.println("[MockBrokerServer] Received GetProbesRequest from agent: " + request.getAgentId());

            Agent.Probe probe = Agent.Probe.newBuilder()
                    .setId("probe-healthcheck-38")
                    .setType(Agent.ProbeType.PROBE_TYPE_SNAPSHOT)
                    .setRuntimeLocation("src/main/java/com/fancode/core/rest/HealthCheck.java")
                    .setRuntimeLine(38) // Line 38: var checkVersion = request.getQueryParam("checkVersion");
                    .setHitLimit(10)
                    .setExpiryTime(System.currentTimeMillis() + 600000)
                    .build();

            Agent.GetProbesResponse response = Agent.GetProbesResponse.newBuilder()
                    .addProbes(probe)
                    .build();

            responseObserver.onNext(response);
            responseObserver.onCompleted();
        }

        @Override
        public void reportTelemetry(Agent.TelemetryBatch request, StreamObserver<Agent.TelemetryResponse> responseObserver) {
            System.out.println("\n🔥🔥🔥 [MockBrokerServer] RECEIVED TELEMETRY EVENT FROM AGENT! 🔥🔥🔥");
            System.out.println("[MockBrokerServer] Events count: " + request.getEventsCount());
            for (Agent.TelemetryEvent event : request.getEventsList()) {
                System.out.println("  -> Event Probe ID: " + event.getProbeId());
                System.out.println("  -> Captured Vars JSON: " + event.getCapturedVarsJson());
            }

            Agent.TelemetryResponse response = Agent.TelemetryResponse.newBuilder().build();
            responseObserver.onNext(response);
            responseObserver.onCompleted();
        }
    }

    public static void main(String[] args) throws Exception {
        Server server = ServerBuilder.forPort(60051)
                .addService(new MockBrokerService())
                .build()
                .start();
        System.out.println("=== Standalone Mock Broker running on port 60051 ===");
        server.awaitTermination();
    }
}
