package com.fancode.core.dao;

import io.reactivex.rxjava3.core.Single;
import io.vertx.core.json.JsonObject;

public class HealthCheckDao {
    public Single<JsonObject> redisHealthCheck() {
        return Single.just(new JsonObject().put("status", "UP").put("latencyMs", 2));
    }

    public Single<JsonObject> mysqlHealthCheck() {
        return Single.just(new JsonObject().put("status", "UP").put("latencyMs", 5));
    }
}
