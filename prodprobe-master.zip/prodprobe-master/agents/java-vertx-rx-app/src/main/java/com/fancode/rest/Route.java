package com.fancode.rest;

import java.lang.annotation.*;

@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.TYPE)
public @interface Route {
    String path();
    String consumes() default "*";
    HttpMethod httpMethod() default HttpMethod.GET;
}
