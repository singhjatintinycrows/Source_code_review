package com.fancode;

import com.fancode.core.rest.HealthCheck;
import com.fancode.rest.Request;
import io.vertx.core.AbstractVerticle;
import io.vertx.core.Vertx;
import io.vertx.ext.web.Router;

public class FancodeApplication extends AbstractVerticle {

    @Override
    public void start() {
        Router router = Router.router(vertx);
        HealthCheck healthCheck = new HealthCheck();

        router.get("/healthcheck").handler(ctx -> {
            Request req = new Request(ctx.request());
            healthCheck.handle(req).subscribe(
                response -> ctx.response()
                    .putHeader("content-type", "application/json")
                    .end(response.getDetails().encode()),
                err -> ctx.response().setStatusCode(500).end(err.getMessage())
            );
        });

        vertx.createHttpServer()
            .requestHandler(router)
            .listen(8089, http -> {
                if (http.succeeded()) {
                    System.out.println("Fancode Vert.x server started on port 8089");
                } else {
                    System.err.println("Failed to start Fancode Vert.x server: " + http.cause());
                }
            });
    }

    public static void main(String[] args) {
        Vertx vertx = Vertx.vertx();
        vertx.deployVerticle(new FancodeApplication());
    }
}
