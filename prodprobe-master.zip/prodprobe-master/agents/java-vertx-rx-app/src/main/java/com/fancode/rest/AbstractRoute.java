package com.fancode.rest;

import io.reactivex.rxjava3.core.Single;

public abstract class AbstractRoute<T> {
    public abstract Single<T> handle(Request request);
}
