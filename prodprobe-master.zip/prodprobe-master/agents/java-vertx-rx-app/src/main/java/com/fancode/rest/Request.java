package com.fancode.rest;

public class Request {
    private final io.vertx.core.http.HttpServerRequest vertxRequest;

    public Request(io.vertx.core.http.HttpServerRequest vertxRequest) {
        this.vertxRequest = vertxRequest;
    }

    public String getQueryParam(String paramName) {
        return vertxRequest != null ? vertxRequest.getParam(paramName) : null;
    }
}
