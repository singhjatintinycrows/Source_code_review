package com.fancode.rest.healthcheck;

import io.reactivex.rxjava3.core.Single;
import io.vertx.core.json.JsonObject;
import java.util.Map;

public class HealthCheckUtil {
    public static Single<HealthCheckResponse> handler(Map<String, Single<JsonObject>> map) {
        // Collect results from all Singles in the map asynchronously
        return Single.zip(
            map.values(),
            results -> {
                JsonObject combined = new JsonObject();
                int idx = 0;
                for (String key : map.keySet()) {
                    combined.put(key, (JsonObject) results[idx++]);
                }
                return new HealthCheckResponse("UP", combined);
            }
        );
    }
}
