#!/usr/bin/env bash

# Bootstrap uv, Python 3.12, and the local demo environment.
set -euo pipefail

APP_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
cd "$APP_DIR"

DEFAULT_UV_VERSION="0.11.26"
DEFAULT_UV_INSTALLER_SHA256="92fa9085d24c214bb4445cc1da8c15ca9cca8cffb34726240fa08c5302e94ccc"
UV_VERSION="${UV_VERSION:-$DEFAULT_UV_VERSION}"
UV_INSTALLER_SHA256="${UV_INSTALLER_SHA256:-}"
BOOTSTRAP_DIR="$APP_DIR/.bootstrap"
UV_INSTALL_DIR="$BOOTSTRAP_DIR/bin"
uv_bin="${UV_BIN:-}"

sha256_file() {
  local file="$1"
  local output

  if command -v sha256sum >/dev/null 2>&1; then
    output="$(sha256sum "$file")"
    printf '%s\n' "${output%% *}"
  elif command -v shasum >/dev/null 2>&1; then
    output="$(shasum -a 256 "$file")"
    printf '%s\n' "${output%% *}"
  elif command -v openssl >/dev/null 2>&1; then
    output="$(openssl dgst -sha256 "$file")"
    printf '%s\n' "${output##* }"
  else
    echo "Setup requires sha256sum, shasum, or openssl to verify the uv installer." >&2
    return 1
  fi
}

if [[ -n "$uv_bin" ]]; then
  if [[ ! -x "$uv_bin" ]]; then
    resolved_uv="$(command -v "$uv_bin" 2>/dev/null || true)"
    if [[ -z "$resolved_uv" ]]; then
      echo "UV_BIN does not resolve to an executable: $uv_bin" >&2
      exit 1
    fi
    uv_bin="$resolved_uv"
  fi
else
  if [[ -x "$UV_INSTALL_DIR/uv" ]]; then
    uv_bin="$UV_INSTALL_DIR/uv"
  elif [[ -x "$UV_INSTALL_DIR/uv.exe" ]]; then
    uv_bin="$UV_INSTALL_DIR/uv.exe"
  fi
fi

if [[ -z "$uv_bin" ]]; then
  if [[ -z "$UV_INSTALLER_SHA256" ]]; then
    if [[ "$UV_VERSION" == "$DEFAULT_UV_VERSION" ]]; then
      UV_INSTALLER_SHA256="$DEFAULT_UV_INSTALLER_SHA256"
    else
      echo "UV_INSTALLER_SHA256 is required when overriding UV_VERSION ($UV_VERSION)." >&2
      exit 1
    fi
  fi
  if [[ ! "$UV_INSTALLER_SHA256" =~ ^[0-9a-fA-F]{64}$ ]]; then
    echo "UV_INSTALLER_SHA256 must be a 64-character SHA-256 digest." >&2
    exit 1
  fi

  installer_url="https://astral.sh/uv/$UV_VERSION/install.sh"
  installer_file="$(mktemp "${TMPDIR:-/tmp}/hyperprobe-uv-installer.XXXXXX")"
  trap 'rm -f "$installer_file"' EXIT

  echo "Downloading uv $UV_VERSION..."
  if command -v curl >/dev/null 2>&1; then
    curl -LsSf "$installer_url" -o "$installer_file"
  elif command -v wget >/dev/null 2>&1; then
    wget -qO "$installer_file" "$installer_url"
  else
    echo "Setup requires curl or wget to download uv." >&2
    exit 1
  fi

  actual_installer_sha256="$(sha256_file "$installer_file")"
  if [[ "$actual_installer_sha256" != "$UV_INSTALLER_SHA256" ]]; then
    echo "uv installer checksum verification failed for version $UV_VERSION." >&2
    echo "Expected: $UV_INSTALLER_SHA256" >&2
    echo "Actual:   $actual_installer_sha256" >&2
    exit 1
  fi

  env UV_UNMANAGED_INSTALL="$UV_INSTALL_DIR" sh "$installer_file"
  rm -f "$installer_file"
  trap - EXIT

  if [[ -x "$UV_INSTALL_DIR/uv" ]]; then
    uv_bin="$UV_INSTALL_DIR/uv"
  elif [[ -x "$UV_INSTALL_DIR/uv.exe" ]]; then
    uv_bin="$UV_INSTALL_DIR/uv.exe"
  else
    echo "uv installation did not create an executable in $UV_INSTALL_DIR." >&2
    exit 1
  fi
fi

export UV_PYTHON_INSTALL_DIR="${UV_PYTHON_INSTALL_DIR:-$BOOTSTRAP_DIR/python}"
export UV_CACHE_DIR="${UV_CACHE_DIR:-$BOOTSTRAP_DIR/cache}"

echo "Using $($uv_bin --version)"
"$uv_bin" python install 3.12
if ! python_bin="$("$uv_bin" --directory "${TMPDIR:-/tmp}" python find --managed-python --no-project 3.12)"; then
  echo "uv failed to locate its managed Python 3.12 installation." >&2
  exit 1
fi
python_bin="${python_bin%$'\r'}"

if [[ -z "$python_bin" || ! -x "$python_bin" ]]; then
  echo "uv returned an invalid managed Python executable: ${python_bin:-<empty>}." >&2
  exit 1
fi
if ! "$python_bin" -c 'import sys; raise SystemExit(sys.version_info < (3, 12))'; then
  echo "uv managed Python is not executable or is older than Python 3.12: $python_bin" >&2
  exit 1
fi

exec "$python_bin" setup_env.py --uv "$uv_bin" "$@"
