import contextvars

# Native async-safe context variable
current_trace_id = contextvars.ContextVar("current_trace_id", default=None)

def get_trace_id():
    return current_trace_id.get()
