import time
import asyncio
import uuid
import os
from fastapi import FastAPI
import uvicorn
import tracer
from hyperprobe_agent import initialize_hyperprobe, shutdown_hyperprobe

agent = initialize_hyperprobe()
app = FastAPI()

class CheckoutService:

    @staticmethod
    async def async_heavy_calculation(total):
        # Simulate an asynchronous external API/DB fetch using await
        await asyncio.sleep(0.05)
        return total * 1.05  # Add a tax/markup calculation

    @staticmethod
    async def async_process_checkout(user_id, items):
        cart_total = 0.0
        
        user_session = {
            "id": user_id,
            "authenticated": True,
            "flags": ["premium", "beta-tester"],
            "password": "super-secret-password"
        }
        user_session["circular"] = user_session

        if items:
            for item in items:
                price = item.get("price", 0.0)
                quantity = item.get("quantity", 1)
                item_price = price * quantity
                discount = 0.1 if item_price > 100 else 0.0
                cart_total += item_price - (item_price * discount)
                
        # Await boundary (causes the coroutine frame to suspend and resume)
        final_total = await CheckoutService.async_heavy_calculation(cart_total)
        
        # 🎯 TARGET PLACE: SNAPSHOT PROBE
        clean_user_session = {k: v for k, v in user_session.items() if k != "circular"}

        response = {
            "status": "async_success",
            "user": clean_user_session,
            "total": final_total,
            "timestamp": int(time.time() * 1000)
        }
        return response
    
    @staticmethod
    def process_checkout(user_id, items):
        cart_total = 0.0  # HP_E2E_DURATION_START
        
        user_session = {
            "id": user_id,
            "authenticated": True,
            "flags": ["premium", "beta-tester"],
            "password": "super-secret-password"
        }
        # Circular reference kept here so the Agent can capture and serialize it
        user_session["circular"] = user_session

        if items:
            for item in items:
                price = item.get("price", 0.0)
                quantity = item.get("quantity", 1)
                item_price = price * quantity
                discount = 0.1 if item_price > 100 else 0.0  # HP_E2E_ITEM
                cart_total += item_price - (item_price * discount)
    
        # Create a clean version of user_session without the cycle for the REST JSON response
        clean_user_session = {k: v for k, v in user_session.items() if k != "circular"}  # HP_E2E_SNAPSHOT_AND_DURATION_END

        response = {
            "status": "success",
            "user": clean_user_session,
            "total": cart_total,
            "timestamp": int(time.time() * 1000)
        }

        # --- PLACE SNAPSHOT PROBE HERE ---
        return response


@app.get("/health")
def health():
    return {"status": "UP"}


@app.post("/checkout")
def checkout_sync(payload: dict):
    # Set trace ID for this request
    tracer.current_trace_id.set(str(uuid.uuid4()))
    
    user_id = payload.get("userId", "anonymous")
    items = payload.get("items", [])
    
    # Process checkout synchronously 
    # (FastAPI automatically runs def routes in a separate threadpool to prevent blocking the event loop!)
    resp_data = CheckoutService.process_checkout(user_id, items)
    return resp_data


@app.post("/checkout-async")
async def checkout_async(payload: dict):
    # Set trace ID for this request
    tracer.current_trace_id.set(str(uuid.uuid4()))
    
    user_id = payload.get("userId", "anonymous")
    items = payload.get("items", [])
    
    # Process checkout natively asynchronous on the main event loop
    resp_data = await CheckoutService.async_process_checkout(user_id, items)
    print("returning response.")
    return resp_data


if __name__ == "__main__":
    port = int(os.getenv("PORT", "8000"))
    print(f"Starting FastAPI Async Demo App Server on port {port}...")
    try:
        # Run natively using uvicorn instead of ThreadingHTTPServer
        uvicorn.run(app, host="0.0.0.0", port=port, log_level="warning")
    finally:
        shutdown_hyperprobe()
