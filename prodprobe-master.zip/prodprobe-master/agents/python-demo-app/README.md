# Python Demo App Setup

This demo starts the HyperProbe Python SDK programmatically from `hyperprobe_agent.py`.

## Requirements

- macOS, Linux, or Windows with Git Bash
- An internet connection
- `curl` or `wget`
- The repository layout must keep these directories next to each other:

```text
agents/
  python-demo-app/
  python-sdk/
```

Python and uv do not need to be installed in advance. The setup script installs a project-local uv and uv-managed Python 3.12 because the SDK uses Python's `sys.monitoring` API.

## Setup

Open a Bash terminal in `agents/python-demo-app` and run:

```bash
bash setup.sh
```

The setup script installs a pinned uv binary under `.bootstrap`, installs uv-managed Python 3.12, creates or repairs `.venv`, installs the demo dependencies, and installs the local SDK in editable mode with its development dependencies. Dependencies are installed through uv's pip-compatible interface (`uv pip install`); the standalone `pip` executable is not invoked directly.

To rebuild the environment from scratch:

```text
bash setup.sh --recreate
```

## Verify

With the virtual environment activated:

```bash
python --version
python -c "import hyperprobe; print('HyperProbe SDK import succeeded')"
python -m pytest ../python-sdk/tests -q
```

## Run

On macOS/Linux, `start.sh` supplies the local broker and demo identity defaults; override them for another deployment as needed. The application starts the agent programmatically during module initialization. Direct execution defaults `HYPERPROBE_FORK_MODE` to `none`; the Docker image sets it to `worker` for Gunicorn `--preload`.

macOS/Linux:

```bash
./start.sh
```

For example:

```bash
HYPERPROBE_BROKER_URL="localhost:60051" \
HYPERPROBE_SERVICE_ID="815d3316-95ec-4e38-b8ab-e3a5e6d5e155" \
HYPERPROBE_ENVIRONMENT="development" \
./start.sh
```

Windows PowerShell:

```powershell
$env:HYPERPROBE_BROKER_URL = "localhost:60051"
$env:HYPERPROBE_SERVICE_ID = "815d3316-95ec-4e38-b8ab-e3a5e6d5e155"
$env:HYPERPROBE_ENVIRONMENT = "development"
$env:HYPERPROBE_COMMIT_SHA = "local-demo"
$env:DEBUG = "hyperprobe:*"
python app.py
```

Windows Command Prompt:

```bat
set HYPERPROBE_BROKER_URL=localhost:60051
set HYPERPROBE_SERVICE_ID=815d3316-95ec-4e38-b8ab-e3a5e6d5e155
set HYPERPROBE_ENVIRONMENT=development
set HYPERPROBE_COMMIT_SHA=local-demo
set DEBUG=hyperprobe*
python app.py
```

Replace `HYPERPROBE_BROKER_URL` and the identity values with the values for your broker and deployment. The local `.hprc` contains the demo service ID, but the agent receives its startup identity from environment variables.

The app listens on `http://localhost:8000`. Example request:

```bash
curl -X POST http://localhost:8000/checkout \
  -H "Content-Type: application/json" \
  -d '{"userId":"demo-user","items":[{"price":120,"quantity":2}]}'
```

The equivalent Windows PowerShell request is:

```powershell
Invoke-RestMethod http://localhost:8000/checkout -Method Post -ContentType "application/json" -Body '{"userId":"demo-user","items":[{"price":120,"quantity":2}]}'
```

Stop the server with `Ctrl+C`.
