"""Create the demo app environment and install the SDK and app dependencies."""

from __future__ import annotations

import argparse
import shlex
import shutil
import subprocess
import sys
from pathlib import Path


APP_DIR = Path(__file__).resolve().parent
SDK_DIR = APP_DIR.parent / "python-sdk"
VENV_DIR = APP_DIR / ".venv"
REQUIREMENTS_FILE = APP_DIR / "requirements.txt"


def run(command: list[str | Path]) -> None:
    command = [str(part) for part in command]
    print(f"> {shlex.join(command)}", flush=True)
    subprocess.run(command, cwd=APP_DIR, check=True)


def venv_python() -> Path:
    if sys.platform == "win32":
        return VENV_DIR / "Scripts" / "python.exe"
    return VENV_DIR / "bin" / "python"


def require_python_312() -> None:
    if sys.version_info < (3, 12):
        raise SystemExit(
            "Python 3.12 or newer is required. "
            "Use python3.12 on macOS/Linux or py -3.12 on Windows."
        )


def check_paths() -> None:
    if not SDK_DIR.is_dir():
        raise SystemExit(f"SDK directory was not found: {SDK_DIR}")
    if not REQUIREMENTS_FILE.is_file():
        raise SystemExit(f"Requirements file was not found: {REQUIREMENTS_FILE}")


def remove_environment() -> None:
    print(f"Removing {VENV_DIR}")
    if VENV_DIR.is_symlink():
        VENV_DIR.unlink()
    else:
        shutil.rmtree(VENV_DIR)


def environment_is_compatible(python: Path) -> bool:
    if not python.is_file():
        return False
    result = subprocess.run(
        [
            str(python),
            "-c",
            "import sys; raise SystemExit(sys.version_info < (3, 12))",
        ],
        cwd=APP_DIR,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
    )
    return result.returncode == 0


def create_environment(uv: Path, recreate: bool) -> Path:
    python = venv_python()
    if recreate and VENV_DIR.exists():
        remove_environment()
    elif VENV_DIR.exists() and not environment_is_compatible(python):
        print("The existing virtual environment is missing, broken, or too old.")
        remove_environment()

    if not python.exists():
        run([uv, "venv", "--no-project", "--python", sys.executable, VENV_DIR])

    if not environment_is_compatible(python):
        raise SystemExit(f"uv did not create a usable Python 3.12+ environment: {python}")
    return python


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Set up the Python demo app and editable HyperProbe SDK environment."
    )
    parser.add_argument(
        "--uv",
        required=True,
        type=Path,
        help=argparse.SUPPRESS,
    )
    parser.add_argument(
        "--recreate",
        action="store_true",
        help="Delete and recreate the local .venv before installing dependencies.",
    )
    args = parser.parse_args()

    require_python_312()
    check_paths()
    uv = args.uv.resolve()
    if not uv.is_file():
        raise SystemExit(f"uv executable was not found: {uv}")

    python = create_environment(uv, args.recreate)
    run([
        uv,
        "pip",
        "install",
        "--python",
        python,
        "--strict",
        "-r",
        REQUIREMENTS_FILE,
    ])
    run([
        python,
        "-c",
        "import fastapi, hyperprobe, pytest, uvicorn",
    ])

    print()
    print("Environment setup complete.")
    if sys.platform == "win32":
        print(r"PowerShell: .\.venv\Scripts\Activate.ps1")
        print(r"Command Prompt: .\.venv\Scripts\activate.bat")
    else:
        print("macOS/Linux: source .venv/bin/activate")
    print("Run SDK tests: .venv/bin/python -m pytest ../python-sdk/tests -q")
    print("Run the app with injection: ./start.sh")


if __name__ == "__main__":
    main()
