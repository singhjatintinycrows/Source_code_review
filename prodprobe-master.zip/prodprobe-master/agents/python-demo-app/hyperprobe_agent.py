import os

from hyperprobe import HyperProbe

import tracer


def initialize_hyperprobe():
    return HyperProbe.start(
        {
            "broker_url": os.getenv("HYPERPROBE_BROKER_URL"),
            "service_id": os.getenv("HYPERPROBE_SERVICE_ID"),
            "environment": os.getenv("HYPERPROBE_ENVIRONMENT"),
            "commit_sha": os.getenv("HYPERPROBE_COMMIT_SHA")
            or os.getenv("GIT_COMMIT"),
            "set_trace_id": tracer.get_trace_id,
            "fork_mode": os.getenv("HYPERPROBE_FORK_MODE", "none"),
        }
    )


def shutdown_hyperprobe():
    HyperProbe.shutdown()
