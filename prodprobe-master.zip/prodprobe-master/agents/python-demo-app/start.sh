#!/usr/bin/env bash

# Start the FastAPI demo with programmatic HyperProbe initialization.
# Every value below can be overridden by exporting it before running this script.
set -euo pipefail

APP_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
VENV_DIR="$APP_DIR/.venv"

if [[ ! -x "$VENV_DIR/bin/python" ]]; then
  echo "HyperProbe virtual environment is not ready." >&2
  echo "Run: ./setup.sh" >&2
  exit 1
fi

if ! "$VENV_DIR/bin/python" -c 'import sys; assert sys.version_info >= (3, 12); import fastapi, hyperprobe, uvicorn' >/dev/null 2>&1; then
  echo "The Python demo environment is incomplete or uses Python older than 3.12." >&2
  echo "Run: ./setup.sh" >&2
  exit 1
fi

cd "$APP_DIR"

# Prefer the local virtual environment without requiring the caller to activate it.
export PATH="$VENV_DIR/bin:$PATH"

# Match the local HyperProbe development setup. Deployment environments can
# supply their own values without modifying this file.
export HYPERPROBE_BROKER_URL="${HYPERPROBE_BROKER_URL:-localhost:50051}"
export HYPERPROBE_SERVICE_ID="${HYPERPROBE_SERVICE_ID:-815d3316-95ec-4e38-b8ab-e3a5e6d5e155}"
export HYPERPROBE_ENVIRONMENT="${HYPERPROBE_ENVIRONMENT:-saksham-local}"
export HYPERPROBE_SYNC_INTERVAL_MS="${HYPERPROBE_SYNC_INTERVAL_MS:-10000}"
export HYPERPROBE_FLUSH_INTERVAL_MS="${HYPERPROBE_FLUSH_INTERVAL_MS:-500}"
export HYPERPROBE_TRACE_HOOK="${HYPERPROBE_TRACE_HOOK:-tracer:get_trace_id}"
export HYPERPROBE_FORK_MODE="${HYPERPROBE_FORK_MODE:-none}"
export DEBUG="${DEBUG:-hyperprobe:*}"

# The agent requires a deployment identity for source resolution. Respect an
# explicitly supplied HYPERPROBE_COMMIT_SHA or GIT_COMMIT first.
if [[ -z "${HYPERPROBE_COMMIT_SHA:-}" && -z "${GIT_COMMIT:-}" ]]; then
  if commit_sha="$(git -C "$APP_DIR" rev-parse --verify HEAD 2>/dev/null)"; then
    export HYPERPROBE_COMMIT_SHA="$commit_sha"
  else
    export HYPERPROBE_COMMIT_SHA="local-demo"
  fi
fi

echo "Starting Python demo app with HyperProbe"
echo "  Broker: $HYPERPROBE_BROKER_URL"
echo "  Service: $HYPERPROBE_SERVICE_ID ($HYPERPROBE_ENVIRONMENT)"
echo "  App: http://localhost:${PORT:-8000}"

exec python app.py "$@"
