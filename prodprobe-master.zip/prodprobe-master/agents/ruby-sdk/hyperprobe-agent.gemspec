# frozen_string_literal: true

require_relative 'lib/hyperprobe/version'

Gem::Specification.new do |spec|
  spec.name          = 'hyperprobe-agent'
  spec.version       = HyperProbe::VERSION
  spec.authors       = ['Arif Khan', 'Karan Raina']
  spec.email         = ['arif@hypertest.co', 'karan@hypertest.co']

  spec.summary       = 'Production-grade, non-breaking live debugger and telemetry agent for Ruby.'
  spec.description   = 'HyperProbe agent for Ruby applications, capturing snapshots, logs, metrics, and durations non-breakingly using TracePoint and gRPC.'
  spec.homepage      = 'https://www.hyperprobe.co'
  spec.license       = 'Nonstandard'
  # This is a build target, not the interpreter evaluating the gemspec. Packaged
  # dependency metadata is immutable and must also be correct when built on MRI.
  platform = ENV.fetch('HYPERPROBE_GEM_PLATFORM', 'ruby')
  raise 'HYPERPROBE_GEM_PLATFORM must be ruby or java' unless %w[ruby java].include?(platform)

  spec.platform = platform
  spec.required_ruby_version = platform == 'java' ? '>= 2.6.0' : '>= 3.0.0'

  spec.metadata['homepage_uri'] = spec.homepage
  spec.metadata['source_code_uri'] = 'https://github.com/hypertestco/prodprobe'

  spec.files = Dir['lib/**/*.rb', 'LICENSE*', 'README.md']
  if platform == 'java'
    spec.files += ['lib/hyperprobe/jars/hyperprobe-grpc.jar']
    spec.files += Dir['transport/README.md', 'transport/THIRD_PARTY_NOTICES.md', 'transport/pom.xml', 'transport/src/main/java/**/*.java']
  end
  spec.require_paths = ['lib']

  if platform == 'ruby'
    spec.add_dependency 'debug_inspector', '~> 1.2'
    spec.add_dependency 'google-protobuf', '>= 3.25.0', '< 5.0'
    spec.add_dependency 'grpc', '>= 1.50.0', '< 2.0'
  end

  spec.add_development_dependency 'bundler', '>= 1.17'
  spec.add_development_dependency 'rake', '>= 12.0'
  spec.add_development_dependency 'rspec', '~> 3.12'
end
