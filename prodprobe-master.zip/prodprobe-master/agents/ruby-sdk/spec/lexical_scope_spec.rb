# frozen_string_literal: true

require 'spec_helper'
require 'tempfile'
require 'hyperprobe/core/lexical_scope'

RSpec.describe HyperProbe::Core::LexicalScope do
  def locals(source, marker)
    Tempfile.create(['lexical-scope', '.rb']) do |file|
      file.write(source)
      file.flush
      line = source.lines.index { |text| text.include?(marker) } + 1
      described_class.locals_for(file.path, line)
    end
  end

  let(:checkout) do
    <<~'RUBY'
      class CheckoutService
        def self.process_checkout(
          user_id,
          items
        )
          cart_total = 0
          user_session = { id: user_id }
          items.each do |item|
            price = item['price']
            quantity = item['quantity']
            item_price = price * quantity
            discount = item_price > 100 ? 0.1 : 0.0 # block_probe
            cart_total += item_price - discount
          end
          clean_user_session = user_session # method_probe
        end
      end
    RUBY
  end

  it 'includes only block parameters and new assignments at the checkout item probe' do
    expect(locals(checkout, '# block_probe')).to contain_exactly(:item, :price, :quantity, :item_price, :discount)
  end

  it 'includes multiline method parameters and assignments but not nested block locals' do
    expect(locals(checkout, '# method_probe')).to contain_exactly(:user_id, :items, :cart_total, :user_session, :clean_user_session)
  end

  it 'knows ancestor assignments after nested blocks and respects explicit shadows' do
    source = <<~'RUBY'
      def example(items, secret)
        items.each do |item; secret|
          secret = item
          outer = 1
          items.each do |child; item|
            item = child
            outer += 1
            later = 1
            own = secret # nested_probe
          end
          later = 2
        end
        outer = 2
      end
    RUBY
    expect(locals(source, '# nested_probe')).to contain_exactly(:child, :item, :own)
    expect(locals(source, 'secret = item')).to contain_exactly(:item, :secret, :later)
  end

  it 'collects all parameter forms without declaring names referenced by defaults' do
    source = <<~'RUBY'
      def example(required, optional = service, *rest, post, key:, choice: fallback, **keywords, &callback)
        result = required # probe
      end
    RUBY
    expect(locals(source, '# probe')).to contain_exactly(:required, :optional, :rest, :post, :key, :choice, :keywords, :callback, :result)
  end

  it 'handles destructured block parameters and lambda parameters and semicolon locals' do
    source = <<~'RUBY'
      def example(items, secret)
        items.each do |(left, right), *rest; scratch|
          scratch = left # destructured_probe
        end
        action = lambda do |value, scale: 2; secret|
          secret = value
          result = value * scale # lambda_probe
        end
        empty = lambda { |; secret|
          secret = 1 # empty_lambda_probe
        }
      end
    RUBY
    expect(locals(source, '# destructured_probe')).to contain_exactly(:left, :right, :rest, :scratch)
    expect(locals(source, '# lambda_probe')).to contain_exactly(:value, :scale, :secret, :result)
    expect(locals(source, '# empty_lambda_probe')).to contain_exactly(:secret)
  end

  it 'supports arrow lambdas when Ripper preserves their body, otherwise fails closed' do
    source = <<~'RUBY'
      def example(secret)
        action = ->(value, scale: 2; secret) do
          secret = value
          result = value * scale # arrow_probe
        end
        empty = ->(; secret) {
          secret = 1 # empty_arrow_probe
        }
      end
    RUBY
    # JRuby 10.1.1 emits [:lambda, nil, params] and discards the body.
    incomplete = Ripper.sexp('->(value) { value }')[1][0][1].nil?
    if incomplete
      expect(locals(source, '# arrow_probe')).to be_nil
      expect(locals(source, '# empty_arrow_probe')).to be_nil
    else
      expect(locals(source, '# arrow_probe')).to contain_exactly(:value, :scale, :secret, :result)
      expect(locals(source, '# empty_arrow_probe')).to contain_exactly(:secret)
    end
  end

  it 'does not treat nested blocks in parameter defaults as method locals' do
    source = <<~'RUBY'
      def example(action = lambda { |parameter| parameter })
        result = action # probe
      end
    RUBY
    expect(locals(source, '# probe')).to contain_exactly(:action, :result)
  end

  it 'resets ancestry at methods, classes, modules, and singleton classes' do
    source = <<~'RUBY'
      secret = 1
      class Example
        secret = 2 # class_probe
        def instance_method
          secret = 3 # def_probe
        end
      end
      module Container
        secret = 4 # module_probe
      end
      class << Object.new
        secret = 5 # singleton_probe
      end
    RUBY
    %w[class_probe def_probe module_probe singleton_probe].each do |marker|
      expect(locals(source, marker)).to contain_exactly(:secret)
    end
  end

  it 'collects multiple assignments, rescue variables, for targets, and operator assignments' do
    source = <<~'RUBY'
      def example(items)
        first, *remaining = items
        for item in items
          total ||= item
        end
      rescue => error
        result = error # probe
      end
    RUBY
    expect(locals(source, '# probe')).to contain_exactly(:items, :first, :remaining, :item, :total, :error, :result)
  end

  it 'attributes interpolated expressions and multiline string content to their scope' do
    source = <<~'RUBY'
      def example(secret, items)
        items.each do |item|
          text = "start
      middle
      #{item}
      finish"
          value = "#{result = item}" # probe
        end
      end
    RUBY
    ['middle', '#{item}', '# probe'].each do |marker|
      expect(locals(source, marker)).to contain_exactly(:item, :text, :value, :result)
    end
  end

  it 'fails closed for ambiguous inline blocks, definition headers, and tokenless lines' do
    source = <<~'RUBY'
      def example(items)
        # comment_probe
        result = items.map { |item| item } # inline_probe
      end
    RUBY
    %w[def comment_probe inline_probe end].each do |marker|
      expect(locals(source, marker)).to be_nil
    end
  end

  it 'returns an empty allowlist for a known scope with no own locals' do
    source = "secret = 1\n[1].each do\n  puts secret # probe\nend\n"
    expect(locals(source, '# probe')).to eq([])
  end

  it 'lets the caller filter binding names without exposing closures on unknown lines' do
    binding_names = %i[item price user_id items user_session cart_total]
    allowed = locals(checkout, '# block_probe')
    expect(binding_names & (allowed || [])).to contain_exactly(:item, :price)
    unknown = described_class.locals_for('(eval)', 28)
    expect(binding_names & (unknown || [])).to be_empty
  end

  it 'does not execute source or application conversion hooks' do
    source = "raise 'must not execute'\nvalue = 1 # probe\n"
    expect(locals(source, '# probe')).to eq([:value])
    path = Class.new do
      def to_path
        raise 'must not call to_path'
      end

      def to_str
        raise 'must not call to_str'
      end
    end.new
    expect(path).not_to receive(:to_path)
    expect(path).not_to receive(:to_str)
    expect(described_class.locals_for(path, 1)).to be_nil
  end

  it 'fails closed for unavailable, invalid, oversized, or excessively complex source' do
    expect(described_class.locals_for('/nonexistent/hyperprobe-source.rb', 1)).to be_nil
    expect(described_class.locals_for(__dir__, 1)).to be_nil
    expect(described_class.locals_for(__FILE__, 0)).to be_nil
    expect(described_class.locals_for(__FILE__, '1')).to be_nil
    expect(described_class.locals_for(__FILE__, 100_000)).to be_nil
    expect(locals("def invalid( # probe\n", '# probe')).to be_nil
    expect(locals("# probe\n" + (' ' * described_class::MAX_SOURCE_BYTES), '# probe')).to be_nil
    expect(locals("value = #{'[' * 130}1#{']' * 130} # probe\n", '# probe')).to be_nil
    expect(locals("values = [#{(['1'] * 10_001).join(',')}] # probe\n", '# probe')).to be_nil
  end
end
