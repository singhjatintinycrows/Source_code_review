# frozen_string_literal: true

require 'spec_helper'
require 'tempfile'

RSpec.describe 'Caller-frame snapshot locals' do
  let(:events) { [] }
  let(:quota) { HyperProbe::Core::QuotaManager.new(100, 1024 * 1024) }
  let(:safety) { HyperProbe::Core::SafetyMonitor.new(proc {}, is_ephemeral_lambda: true) }
  let(:engine) { HyperProbe::Core::MonitoringEngine.new(quota, safety, proc { |event| events << event }) }

  after { engine.close }

  def capture(source, **options)
    Tempfile.create(['caller-locals', '.rb']) do |file|
      file.write(source)
      file.flush
      fixture = Module.new
      fixture.module_eval(source, file.path, 1)
      line = source.lines.index { |text| text.include?('# snapshot') } + 1
      engine.set_probes([{ id: 'callers', type: 1, runtime_location: file.path,
                           runtime_line: line, stack_frame_depth: 3 }.merge(options)])
      yield fixture
    end
    expect(events.length).to eq(1)
    event = events.first
    scopes = JSON.parse(event.fetch(:captured_vars_json))
    expect(scopes.length).to eq(event.fetch(:stack_frames).length)
    event[:stack_frames].zip(scopes)
  end

  let(:call_chain) do
    <<~'RUBY'
      def self.leaf(input)
        leaf_only = input * 2
        leaf_only # snapshot
      end

      def self.middle(value)
        middle_only = 'middle'
        leaf(value)
      end

      def self.outer
        outer_only = 'outer'
        middle(21)
      end
    RUBY
  end

  it 'pairs each MRI caller with its own locals and leaves JRuby caller scopes empty' do
    frames = capture(call_chain) { |fixture| expect(fixture.outer).to eq(42) }
    expect(frames.map { |frame, _| frame[:function_name] }).to match([/leaf/, /middle/, /outer/])
    expect(frames[0][1].first['vars']).to include('input' => 21, 'leaf_only' => 42)
    if RUBY_ENGINE == 'ruby'
      expect(frames[1][1].first['vars']).to eq('value' => 21, 'middle_only' => 'middle')
      expect(frames[2][1].first['vars']).to eq('outer_only' => 'outer')
    else
      expect(frames.drop(1).map { |_, scopes| scopes }).to all(eq([{ 'type' => 'local', 'name' => 'Local', 'vars' => {} }]))
    end
  end

  context 'on MRI', if: RUBY_ENGINE == 'ruby' do
    it 'captures locals from a top-level request-handler block' do
      frames = capture(<<~'RUBY', stack_frame_depth: 2) { |fixture| expect(fixture.const_get(:HANDLER).call(21)).to eq(42) }
        def self.leaf(input)
          value = input * 2
          value # snapshot
        end

        HANDLER = proc do |request_id|
          handler_local = 'request'
          leaf(request_id)
        end
      RUBY
      expect(frames[1][0][:function_name]).to start_with('block')
      expect(frames[1][0][:file_name]).to eq(frames[0][0][:file_name])
      expect(frames[1][0][:line_number]).to eq(8)
      expect(frames[1][1].first['vars']).to eq('request_id' => 21, 'handler_local' => 'request')
    end

    it 'keeps recursive invocations distinct even at the same caller source line' do
      frames = capture(<<~'RUBY', stack_frame_depth: 4) { |fixture| expect(fixture.recurse(3)).to eq(100) }
        def self.recurse(level)
          own_value = level + 100
          if level.zero?
            own_value # snapshot
          else
            recurse(level - 1)
          end
        end
      RUBY
      expect(frames.map { |_, scopes| scopes.first['vars'] }).to eq([
        { 'level' => 0, 'own_value' => 100 }, { 'level' => 1, 'own_value' => 101 },
        { 'level' => 2, 'own_value' => 102 }, { 'level' => 3, 'own_value' => 103 }
      ])
    end

    [false, true].each do |capture_closures|
      it "captures block locals across native iterator frames with capture_closures=#{capture_closures}" do
        frames = capture(<<~'RUBY', stack_frame_depth: 5, capture_closures: capture_closures) { |fixture| fixture.outer('enclosing-value') }
          def self.leaf(input)
            leaf_only = input * 2
            leaf_only # snapshot
          end

          def self.outer(enclosing)
            [7].each do |item; scratch|
              scratch = item * 3
              leaf(scratch)
            end
          end
        RUBY
        block_frame, block_scopes = frames.find { |frame, _| frame[:function_name].include?('block in') && frame[:function_name].include?('outer') }
        expect(block_frame[:line_number]).to eq(9)
        expect(block_scopes.first['vars']).to eq('item' => 7, 'scratch' => 21)
        closure = block_scopes.find { |scope| scope['type'] == 'closure' }
        if capture_closures
          expect(closure['vars']).to include('enclosing' => 'enclosing-value')
        else
          expect(closure).to be_nil
        end
        _, outer_scopes = frames.find { |frame, _| frame[:function_name].end_with?('outer') && !frame[:function_name].include?('block') }
        expect(outer_scopes.first['vars']).to eq('enclosing' => 'enclosing-value')
      end
    end

    it 'does not shift later bindings when an intermediate frame binding is unavailable' do
      allow_any_instance_of(DebugInspector).to receive(:frame_binding).and_wrap_original do |original, index|
        location = original.receiver.backtrace_locations[index]
        raise ArgumentError, 'unavailable frame' if location.label.include?('middle')

        original.call(index)
      end
      frames = capture(call_chain) { |fixture| expect(fixture.outer).to eq(42) }
      expect(frames[0][1].first['vars']).to include('leaf_only' => 42)
      expect(frames[1][1].first['vars']).to eq({})
      expect(frames[2][1].first['vars']).to eq('outer_only' => 'outer')
    end

    it 'preserves hit-frame locals and application results when native inspection fails' do
      allow(DebugInspector).to receive(:open).and_raise(ArgumentError, 'inspection failed')
      frames = capture(call_chain) { |fixture| expect(fixture.outer).to eq(42) }
      expect(frames[0][1].first['vars']).to include('leaf_only' => 42)
      expect(frames.drop(1).map { |_, scopes| scopes.first['vars'] }).to all(eq({}))
    end

    it 'redacts caller locals and shares object references with watches and the hit frame' do
      engine.set_global_config(redact_keys: ['password'], redact_values: ['confidential'])
      frames = capture(<<~'RUBY', stack_frame_depth: 2, watch_expressions: ['shared']) { |fixture| fixture.outer }
        def self.leaf(shared)
          shared # snapshot
        end

        def self.outer
          password = 'never-expose'
          note = 'confidential'
          shared = { 'value' => 7 }
          shared['self'] = shared
          leaf(shared)
        end
      RUBY
      expect(frames[0][1].first['vars']['shared']).to eq('[REF - watch["shared"]]')
      expect(frames[1][1].first['vars']).to eq(
        'password' => '[REDACTED Key]', 'note' => '[REDACTED Value]', 'shared' => '[REF - watch["shared"]]'
      )
      watches = JSON.parse(events.first[:watch_results_json])
      expect(watches['shared']).to eq('value' => 7, 'self' => '[REF - watch["shared"]]')
      expect(events.first[:captured_vars_json]).not_to include('never-expose', 'confidential')
    end

    it 'shares the capture budget across distinct caller frames' do
      frames = capture(<<~'RUBY', stack_frame_depth: 5, max_array_length: 128) { |fixture| fixture.recurse(4) }
        def self.recurse(level)
          values = Array.new(128, level)
          if level.zero?
            values # snapshot
          else
            recurse(level - 1)
          end
        end
      RUBY
      expect(frames[0][1].first['vars']['values']).to eq(Array.new(128, 0))
      expect(frames[1][1].first['vars']['values']).to eq(Array.new(128, 1))
      expect(JSON.generate(frames[4][1])).to include('Capture budget exhausted')
    end

    it 'caps caller capture at the existing maximum stack depth' do
      frames = capture(<<~'RUBY', stack_frame_depth: 1000) { |fixture| fixture.recurse(20) }
        def self.recurse(level)
          if level.zero?
            level # snapshot
          else
            recurse(level - 1)
          end
        end
      RUBY
      expect(frames.length).to eq(16)
      expect(frames.map { |_, scopes| scopes.first['vars']['level'] }).to eq((0..15).to_a)
    end

    it 'falls back to hit-frame locals before opening the inspector on a deep stack' do
      expect(DebugInspector).not_to receive(:open)
      frames = capture(<<~'RUBY') { |fixture| fixture.recurse(300) }
        def self.recurse(level)
          if level.zero?
            level # snapshot
          else
            recurse(level - 1)
          end
        end
      RUBY
      expect(frames.first[1].first['vars']).to eq('level' => 0)
      expect(frames.drop(1).map { |_, scopes| scopes.first['vars'] }).to all(eq({}))
    end

    it 'omits an oversized caller without losing other frames or the application result' do
      source = call_chain.sub("middle_only = 'middle'", ("middle_only = 'middle'\n" * 500))
      frames = capture(source, capture_closures: true) { |fixture| expect(fixture.outer).to eq(42) }
      expect(frames.first[1].first['vars']).to include('leaf_only' => 42)
      expect(frames[1][1]).to eq([{ 'type' => 'local', 'name' => 'Local', 'vars' => {} }])
      expect(frames[2][1].first['vars']).to eq('outer_only' => 'outer')
    end

    [0, 1].each do |depth|
      it "does not inspect caller bindings when stack depth is #{depth}" do
        expect(DebugInspector).not_to receive(:open)
        frames = capture(call_chain, stack_frame_depth: depth) { |fixture| expect(fixture.outer).to eq(42) }
        expect(frames.length).to eq(depth)
      end
    end
  end
end
