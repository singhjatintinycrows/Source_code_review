# frozen_string_literal: true

require 'spec_helper'
require 'tempfile'

RSpec.describe 'Advanced Parity and Edge Cases' do
  let(:quota) { HyperProbe::Core::QuotaManager.new(100, 1024 * 1024) }
  let(:safety) { HyperProbe::Core::SafetyMonitor.new(->(_h, _r) {}) }
  let(:events) { [] }
  let(:on_capture) { ->(evt) { events << evt } }

  subject(:engine) do
    HyperProbe::Core::MonitoringEngine.new(quota, safety, on_capture)
  end

  let(:tmp_file) do
    f = Tempfile.new(['adv_target', '.rb'])
    f.write(<<-RUBY)
      class OrderService
        def checkout(order_id, user_email, items)
          cart_total = items.sum { |i| i[:price] * i[:qty] }
          discount = 0.1
          final_total = cart_total * (1.0 - discount) # Line 5: Probe line
          final_total
        end
      end
    RUBY
    f.close
    f
  end

  let(:file_path) { tmp_file.path }

  before do
    load file_path
  end

  after do
    engine.close
    tmp_file.unlink
  end

  it 'handles multiple concurrent probes on the exact same line' do
    engine.set_global_config({
      redact_keys: %w[user_email password],
      redact_values: %w[secret_token]
    })

    engine.set_probes([
      {
        id: 'probe-snapshot',
        type: 1, # SNAPSHOT
        runtime_location: file_path,
        runtime_line: 6,
        watch_expressions: ['cart_total', 'final_total', 'discount']
      },
      {
        id: 'probe-log',
        type: 2, # LOG
        runtime_location: file_path,
        runtime_line: 6,
        template: 'Checkout order ${order_id} total: ${final_total}'
      },
      {
        id: 'probe-counter',
        type: 3, # COUNTER
        runtime_location: file_path,
        runtime_line: 6
      },
      {
        id: 'probe-metric',
        type: 4, # METRIC
        runtime_location: file_path,
        runtime_line: 6,
        metric_expression: 'final_total'
      }
    ])

    service = OrderService.new
    items = [{ price: 100.0, qty: 2 }]
    result = service.checkout('ORD-999', 'user@example.com', items)

    expect(result).to eq(180.0)
    expect(events.length).to eq(4)

    snapshot_evt = events.find { |e| e[:probe_id] == 'probe-snapshot' }
    log_evt = events.find { |e| e[:probe_id] == 'probe-log' }
    counter_evt = events.find { |e| e[:probe_id] == 'probe-counter' }
    metric_evt = events.find { |e| e[:probe_id] == 'probe-metric' }

    expect(snapshot_evt).not_to be_nil
    expect(log_evt).not_to be_nil
    expect(counter_evt).not_to be_nil
    expect(metric_evt).not_to be_nil

    # Verify Snapshot details
    vars = JSON.parse(snapshot_evt[:captured_vars_json])
    locals = vars.first.first['vars']
    expect(locals['order_id']).to eq('ORD-999')
    expect(locals['user_email']).to eq('[REDACTED Key]')
    expect(locals['cart_total']).to eq(200.0)

    watches = JSON.parse(snapshot_evt[:watch_results_json])
    expect(watches['cart_total']).to eq(200.0)
    expect(watches['discount']).to eq(0.1)

    # Verify Log details
    expect(log_evt[:evaluated_log]).to eq('Checkout order ORD-999 total: 180.0')

    # Verify Counter
    expect(counter_evt[:metric_value]).to eq(1.0)

    # Verify Metric
    expect(metric_evt[:metric_value]).to eq(180.0)
  end

  it 'handles rate-limiting gracefully when token quota runs out' do
    exhausted_quota = HyperProbe::Core::QuotaManager.new(1, 1024 * 1024)
    local_events = []
    local_engine = HyperProbe::Core::MonitoringEngine.new(
      exhausted_quota,
      safety,
      ->(e) { local_events << e }
    )

    local_engine.set_probes([
      {
        id: 'rate-limited-probe',
        type: 3, # COUNTER
        runtime_location: file_path,
        runtime_line: 5
      }
    ])

    service = OrderService.new
    items = [{ price: 50.0, qty: 1 }]

    # Hit twice rapidly
    service.checkout('O1', 'u@a.com', items)
    service.checkout('O2', 'u@a.com', items)

    local_engine.close

    # Exactly 1 hit admitted, 1 skipped
    expect(local_events.length).to eq(1)
    stats = local_engine.get_stats
    expect(stats[:skips]).to eq(1)
  end

  it 'suspends and resumes probes during safety health state transitions' do
    engine.set_probes([
      {
        id: 'safety-probe',
        type: 3, # COUNTER
        runtime_location: file_path,
        runtime_line: 5
      }
    ])

    service = OrderService.new
    items = [{ price: 10.0, qty: 1 }]

    # Active
    service.checkout('A1', 'u@a.com', items)
    expect(events.length).to eq(1)

    # Suspend (RED)
    engine.suspend
    expect(engine.is_suspended).to be true
    service.checkout('A2', 'u@a.com', items)
    expect(events.length).to eq(1) # No new events while suspended

    # Resume (GREEN)
    engine.resume
    expect(engine.is_suspended).to be false
    service.checkout('A3', 'u@a.com', items)
    expect(events.length).to eq(2) # Resumed capture
  end
end
