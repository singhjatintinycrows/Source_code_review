# frozen_string_literal: true

require 'spec_helper'
require 'timeout'

RSpec.describe HyperProbe::Core::SafetyMonitor do
  let(:state_changes) { [] }
  let(:callback) { ->(health, reason) { state_changes << [health, reason] } }

  subject(:monitor) do
    described_class.new(callback, max_lag_ms: 50.0, pause_budget_ms: 15.0, heap_runtime: nil)
  end

  after { monitor.stop }

  it 'starts in GREEN status' do
    expect(monitor.get_health).to eq(HyperProbe::Core::AgentHealth::GREEN)
  end

  it 'ignores single transient startup / GC lag spikes (no false alarms)' do
    # 1 transient spike of 80ms followed by normal readings
    monitor.record_thread_lag(80.0)
    expect(monitor.get_health).to eq(HyperProbe::Core::AgentHealth::GREEN)

    monitor.record_thread_lag(5.0)
    monitor.record_thread_lag(10.0)
    expect(monitor.get_health).to eq(HyperProbe::Core::AgentHealth::GREEN)
    expect(state_changes).to be_empty
  end

  it 'transitions to YELLOW when 4 out of 10 recent lag samples breach max_lag_ms' do
    3.times { monitor.record_thread_lag(60.0) }
    expect(monitor.get_health).to eq(HyperProbe::Core::AgentHealth::GREEN)

    # 4th breach in 10-sample window
    monitor.record_thread_lag(60.0)
    expect(monitor.get_health).to eq(HyperProbe::Core::AgentHealth::YELLOW)
    expect(state_changes.last[0]).to eq(HyperProbe::Core::AgentHealth::YELLOW)
  end

  it 'transitions to RED when 7 out of 10 recent lag samples breach max_lag_ms' do
    7.times { monitor.record_thread_lag(60.0) }
    expect(monitor.get_health).to eq(HyperProbe::Core::AgentHealth::RED)
    expect(state_changes.last[0]).to eq(HyperProbe::Core::AgentHealth::RED)
  end

  it 'transitions to RED on severe execution lag (3 of 5 exceeding 4x limit)' do
    2.times { monitor.record_thread_lag(220.0) }
    expect(monitor.get_health).to eq(HyperProbe::Core::AgentHealth::YELLOW) # 1st severe breach sets YELLOW

    monitor.record_thread_lag(220.0) # 3rd severe breach sets RED
    expect(monitor.get_health).to eq(HyperProbe::Core::AgentHealth::RED)
  end

  it 'transitions to RED immediately when cumulative probe pause budget exceeds threshold' do
    monitor.report_pause_duration(16.0) # exceeds 15ms budget
    expect(monitor.get_health).to eq(HyperProbe::Core::AgentHealth::RED)
    expect(state_changes.last[0]).to eq(HyperProbe::Core::AgentHealth::RED)
  end

  it 'transitions to YELLOW when pause reaches 50% of budget' do
    monitor.report_pause_duration(8.0) # 8ms >= 7.5ms (50%)
    expect(monitor.get_health).to eq(HyperProbe::Core::AgentHealth::YELLOW)
    expect(state_changes.last[0]).to eq(HyperProbe::Core::AgentHealth::YELLOW)
  end

  it 'recovers back to GREEN when thread lag and pause budget normalize' do
    7.times { monitor.record_thread_lag(60.0) }
    expect(monitor.get_health).to eq(HyperProbe::Core::AgentHealth::RED)

    # Push 10 clean samples to slide the window clean
    10.times { monitor.record_thread_lag(5.0) }
    expect(monitor.get_health).to eq(HyperProbe::Core::AgentHealth::GREEN)
    expect(state_changes.last[0]).to eq(HyperProbe::Core::AgentHealth::GREEN)
  end

  it 'remains GREEN in ephemeral Lambda mode' do
    lambda_monitor = described_class.new(callback, max_lag_ms: 10.0, pause_budget_ms: 5.0, is_ephemeral_lambda: true)
    lambda_monitor.report_pause_duration(100.0)
    10.times { lambda_monitor.record_thread_lag(500.0) }
    expect(lambda_monitor.get_health).to eq(HyperProbe::Core::AgentHealth::GREEN)
  end

  it 'discards a delayed transition after a newer notification was delivered' do
    entered = Queue.new
    release = Queue.new
    allow(monitor).to receive(:trigger_callback).and_wrap_original do |original, info|
      if info[0] == HyperProbe::Core::AgentHealth::YELLOW
        entered << true
        release.pop
      end
      original.call(info)
    end
    delayed = Thread.new { monitor.report_pause_duration(8.0) }
    Timeout.timeout(3) { entered.pop }
    monitor.report_pause_duration(8.0)
    release << true
    expect(delayed.join(3)).to eq(delayed)
    expect(state_changes.map(&:first)).to eq([HyperProbe::Core::AgentHealth::RED])
  ensure
    delayed&.kill
  end

  it 'does not hold the state lock while dispatching a callback' do
    observed = nil
    callback = ->(_health, _reason) { observed = monitor.get_health }
    monitor.instance_variable_set(:@on_state_change, callback)
    monitor.report_pause_duration(16.0)
    expect(observed).to eq(HyperProbe::Core::AgentHealth::RED)
  end

  it 'rejects stale notifications even when health has returned to the same value' do
    entered = Queue.new
    release = Queue.new
    allow(monitor).to receive(:trigger_callback).and_wrap_original do |original, info|
      if info[2] == 1
        entered << true
        release.pop
      end
      original.call(info)
    end
    delayed = Thread.new { monitor.record_thread_lag(250.0) }
    Timeout.timeout(3) { entered.pop }
    2.times { monitor.record_thread_lag(250.0) }
    3.times { monitor.record_thread_lag(0.0) }
    expect(monitor.get_health).to eq(HyperProbe::Core::AgentHealth::YELLOW)
    release << true
    expect(delayed.join(3)).to eq(delayed)
    expect(state_changes.map(&:first)).to eq([HyperProbe::Core::AgentHealth::RED, HyperProbe::Core::AgentHealth::YELLOW])
  ensure
    delayed&.kill
  end

  it 'orders a cooldown action before a newer RED notification' do
    entered = Queue.new
    release = Queue.new
    actions = Queue.new
    transitioned = Queue.new
    allow(monitor).to receive(:trigger_callback).and_wrap_original do |original, info|
      transitioned << true
      original.call(info)
    end
    monitor.instance_variable_set(:@on_state_change, ->(health, _reason) { actions << health })
    cooldown = Thread.new do
      monitor.with_health(HyperProbe::Core::AgentHealth::GREEN) do
        entered << true
        release.pop
        actions << :resume
      end
    end
    Timeout.timeout(3) { entered.pop }
    transition = Thread.new { monitor.report_pause_duration(16.0) }
    Timeout.timeout(3) { transitioned.pop }
    expect(monitor.get_health).to eq(HyperProbe::Core::AgentHealth::RED)
    release << true
    expect(cooldown.join(3)).to eq(cooldown)
    expect(transition.join(3)).to eq(transition)
    expect(actions.pop).to eq(:resume)
    expect(actions.pop).to eq(HyperProbe::Core::AgentHealth::RED)
  ensure
    cooldown&.kill
    transition&.kill
  end

  it 'allows a callback to report a newer health transition without deadlocking' do
    monitor.instance_variable_set(:@on_state_change, lambda do |health, reason|
      state_changes << [health, reason]
      monitor.report_pause_duration(8.0) if health == HyperProbe::Core::AgentHealth::YELLOW
    end)
    Timeout.timeout(3) { monitor.report_pause_duration(8.0) }
    expect(state_changes.map(&:first)).to eq([HyperProbe::Core::AgentHealth::YELLOW, HyperProbe::Core::AgentHealth::RED])
  end

  [SystemExit, LoadError].each do |failure|
    it "isolates #{failure} from agent-owned notification callbacks" do
      monitor.instance_variable_set(:@on_state_change, ->(*) { raise failure })
      expect { monitor.report_pause_duration(16.0) }.not_to raise_error
      expect(monitor.get_health).to eq(HyperProbe::Core::AgentHealth::RED)
    end
  end

  context 'with JVM heap safety' do
    let(:runtime) { double('JVM runtime', max_memory: 1000, total_memory: 1000, free_memory: 200) }
    subject(:monitor) do
      described_class.new(callback, heap_runtime: runtime)
    end

    def start_clock
      now = 0
      @ticks = Queue.new
      @ready = Queue.new
      allow(monitor).to receive(:monotonic_ms) { now }
      allow(monitor).to receive(:sleep) do
        @ready << true
        now = @ticks.pop
      end
      monitor.start
      Timeout.timeout(3) { @ready.pop }
    end

    def tick_at(ms)
      @ticks << ms
      Timeout.timeout(3) { @ready.pop }
    end

    it 'records expensive captures without changing health or sampling heap on the application thread' do
      monitor.report_pause_duration(33.0)
      monitor.report_pause_duration(17.5)

      expect(monitor.get_health).to eq(HyperProbe::Core::AgentHealth::GREEN)
      expect(state_changes).to be_empty
      expect(monitor.cumulative_pause_time).to eq(50.5)
      expect(runtime).not_to have_received(:max_memory)
    end

    it 'samples heap every five seconds and uses strict 5% and 15% boundaries' do
      start_clock
      allow(runtime).to receive(:free_memory).and_return(49)
      tick_at(4999)
      expect(runtime).not_to have_received(:max_memory)
      expect(monitor.get_health).to eq(HyperProbe::Core::AgentHealth::GREEN)

      tick_at(5000)
      expect(monitor.get_health).to eq(HyperProbe::Core::AgentHealth::RED)
      expect(state_changes.last[1]).to include('JVM heap headroom (4.9%)', 'below 5%')

      allow(runtime).to receive(:free_memory).and_return(50)
      tick_at(9999)
      expect(monitor.get_health).to eq(HyperProbe::Core::AgentHealth::RED)
      tick_at(10000)
      expect(monitor.get_health).to eq(HyperProbe::Core::AgentHealth::YELLOW)

      allow(runtime).to receive(:free_memory).and_return(149)
      tick_at(15000)
      expect(monitor.get_health).to eq(HyperProbe::Core::AgentHealth::YELLOW)
      allow(runtime).to receive(:free_memory).and_return(150)
      tick_at(20000)
      expect(monitor.get_health).to eq(HyperProbe::Core::AgentHealth::GREEN)
      expect(runtime).to have_received(:max_memory).exactly(4).times
    end

    it 'counts uncommitted capacity as available heap, not just free committed memory' do
      allow(runtime).to receive(:total_memory).and_return(500)
      allow(runtime).to receive(:free_memory).and_return(0)
      start_clock
      tick_at(5000)
      expect(monitor.get_health).to eq(HyperProbe::Core::AgentHealth::GREEN)
      expect(state_changes).to be_empty
    end

    it 'keeps timing measurements separate from heap health and recovery' do
      allow(runtime).to receive(:free_memory).and_return(40)
      start_clock
      tick_at(5000)
      expect(monitor.get_health).to eq(HyperProbe::Core::AgentHealth::RED)
      monitor.report_pause_duration(33)
      10.times { monitor.record_thread_lag(500) }
      expect(monitor.get_health).to eq(HyperProbe::Core::AgentHealth::RED)

      allow(runtime).to receive(:free_memory).and_return(200)
      tick_at(10000)
      monitor.report_pause_duration(33)
      10.times { monitor.record_thread_lag(500) }
      expect(monitor.get_health).to eq(HyperProbe::Core::AgentHealth::GREEN)
      expect(state_changes.map(&:first)).to eq([HyperProbe::Core::AgentHealth::RED, HyperProbe::Core::AgentHealth::GREEN])
      recovered = false
      monitor.with_health(HyperProbe::Core::AgentHealth::GREEN) { recovered = true }
      expect(recovered).to be(true)
    end

    it 'retains heap health after a sampling failure and retries on the next interval' do
      allow(runtime).to receive(:free_memory).and_return(40)
      start_clock
      tick_at(5000)
      allow(runtime).to receive(:max_memory).and_raise(LoadError)
      tick_at(10000)
      expect(monitor.get_health).to eq(HyperProbe::Core::AgentHealth::RED)

      allow(runtime).to receive(:max_memory).and_return(1000)
      allow(runtime).to receive(:free_memory).and_return(200)
      tick_at(15000)
      expect(monitor.get_health).to eq(HyperProbe::Core::AgentHealth::GREEN)
    end

    context 'on JRuby', if: RUBY_ENGINE == 'jruby' do
      let(:runtime) { Java::JavaLang::Runtime.get_runtime }

      it 'samples all three heap values through the real JVM API' do
        expect(runtime).to receive(:max_memory).and_call_original
        expect(runtime).to receive(:total_memory).and_call_original
        expect(runtime).to receive(:free_memory).and_call_original
        start_clock
        tick_at(5000)
      end
    end
  end

  it 'selects heap safety automatically only on JRuby' do
    automatic = described_class.new(callback)
    automatic.report_pause_duration(33)
    expected = RUBY_ENGINE == 'jruby' ? HyperProbe::Core::AgentHealth::GREEN : HyperProbe::Core::AgentHealth::RED
    expect(automatic.get_health).to eq(expected)
  ensure
    automatic&.stop
  end
end
