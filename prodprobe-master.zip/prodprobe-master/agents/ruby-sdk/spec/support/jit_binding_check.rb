# frozen_string_literal: true

# Load from -e so the entry-point compiler does not compile the fixture before
# the cold sample. Set HYPERPROBE_JIT_SDK=YES to test the actual SDK engine.
require 'json'
require 'jruby'

module JitBindingCheck
  class Handler
    def call(input)
      doubled = input * 2
      doubled + input
    end
  end
end

handler = JitBindingCheck::Handler.new
line = handler.method(:call).source_location[1] + 2
stage = :cold
counts = { cold: { valid: 0, missing: 0 }, warm: { valid: 0, missing: 0 } }
events = ENV.fetch('HYPERPROBE_TRACE_EVENTS', 'line').split(',').map(&:to_sym)
if ENV['HYPERPROBE_JIT_SDK'] == 'YES'
  require File.join(ENV.fetch('HYPERPROBE_TEST_LIB', File.expand_path('../../lib', __dir__)), 'hyperprobe')
  quota = HyperProbe::Core::QuotaManager.new(100_000, 100_000_000)
  safety = HyperProbe::Core::SafetyMonitor.new(->(*) {}, is_ephemeral_lambda: true)
  engine = HyperProbe::Core::MonitoringEngine.new(quota, safety, lambda do |event|
    watch = JSON.parse(event[:watch_results_json])
    valid = event[:capture_error].empty? && watch == { 'input' => 21, 'doubled' => 42 }
    counts[stage][valid ? :valid : :missing] += 1
  end)
  probes = [{ id: 'jit', type: 1, runtime_location: File.expand_path(__FILE__), runtime_line: line,
              watch_expressions: %w[input doubled], stack_frame_depth: 0 }]
  enable = -> { engine.set_probes(probes) }
  disable = -> { engine.set_probes([]) }
else
  trace = TracePoint.new(*events) do |event|
    if event.event == :line && event.path == __FILE__ && event.lineno == line
      context = event.binding
      valid = context.local_variable_defined?(:input) && context.local_variable_get(:input) == 21
      counts[stage][valid ? :valid : :missing] += 1
    end
  end
  enable = -> { trace.enable }
  disable = -> { trace.disable }
end

begin
  enable.call
  5.times { raise 'Application result changed' unless handler.call(21) == 63 }
  disable.call
  8200.times { raise 'Application result changed' unless handler.call(21) == 63 }
  stage = :warm
  enable.call
  1200.times { raise 'Application result changed' unless handler.call(21) == 63 }
ensure
  disable.call
  engine&.close
end

method = JRuby.reference(JitBindingCheck::Handler).searchMethod('call')
actual = method.respond_to?(:getActualMethod) && method.getActualMethod
passed = counts[:cold][:valid] == 5 && counts[:warm][:valid] == 1200
puts JSON.generate(jruby: JRUBY_VERSION, java: java.lang.System.getProperty('java.version'),
                   counts: counts, sdk: !!engine, events: events, method_type: method.java_class.name,
                   compiled_type: actual && actual.java_class.name, passed: passed)
exit(passed ? 0 : 1)
