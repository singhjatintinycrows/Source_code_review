# frozen_string_literal: true

# Independent C-core peer for both MRI and JRuby client tests.
require 'json'
require 'openssl'
require_relative '../../lib/hyperprobe/protos'

class BrokerInteropService < Hyperprobe::Agent::V1::AgentBroker::Service
  def get_probes(request, call)
    raise GRPC::InvalidArgument, 'metadata missing' unless call.metadata['x-hp-service-id'] == request.service_id
    raise GRPC::InvalidArgument, 'deadline missing' unless call.deadline && call.deadline < Time.now + 30

    response = Hyperprobe::Agent::V1::GetProbesResponse.new(
      probes: [Hyperprobe::Agent::V1::Probe.new(id: 'probe', template: request.to_json)],
      next_sync_interval_ms: 1234
    )
    case request.service_id
    when 'denied'
      raise GRPC::PermissionDenied, 'not authorized'
    when 'unavailable'
      raise GRPC::Unavailable, 'try later'
    when 'data-error'
      # Bypass the unary handler's combined DATA/trailer send to exercise late status.
      call.instance_variable_get(:@wrapped).remote_send(response)
      raise GRPC::PermissionDenied, 'error after DATA'
    when 'data-delay'
      call.instance_variable_get(:@wrapped).remote_send(response)
      sleep 2
      raise GRPC::PermissionDenied, 'late trailers'
    when 'slow'
      sleep 2
    when 'oversized'
      response.probes[0].template = 'x' * (5 * 1024 * 1024)
    end
    response
  end

  def report_telemetry(request, call)
    raise GRPC::InvalidArgument, 'metadata missing' unless call.metadata['x-hp-service-id']
    Hyperprobe::Agent::V1::TelemetryResponse.new(
      finished_probe_ids: [request.agent_id] + request.events.map(&:to_json)
    )
  end
end

key = OpenSSL::PKey::RSA.new(2048)
cert = OpenSSL::X509::Certificate.new
cert.version = 2
cert.serial = 1
cert.subject = OpenSSL::X509::Name.parse('/CN=localhost')
cert.issuer = cert.subject
cert.public_key = key.public_key
cert.not_before = Time.now - 60
cert.not_after = Time.now + 3600
factory = OpenSSL::X509::ExtensionFactory.new
factory.subject_certificate = cert
factory.issuer_certificate = cert
cert.add_extension(factory.create_extension('basicConstraints', 'CA:TRUE', true))
cert.add_extension(factory.create_extension('subjectAltName', 'DNS:localhost'))
cert.sign(key, OpenSSL::Digest.new('SHA256'))

server = GRPC::RpcServer.new(pool_size: 8)
plain_port = server.add_http2_port('127.0.0.1:0', :this_port_is_insecure)
credentials = GRPC::Core::ServerCredentials.new(nil, [{ private_key: key.to_pem, cert_chain: cert.to_pem }], false)
tls_port = server.add_http2_port('127.0.0.1:0', credentials)
server.handle(BrokerInteropService.new)
thread = Thread.new { server.run_till_terminated }
server.wait_till_running
STDOUT.sync = true
puts JSON.generate(plain_port: plain_port, tls_port: tls_port, certificate: cert.to_pem)
STDIN.read
server.stop
thread.join
