# frozen_string_literal: true

require 'spec_helper'
require 'timeout'

RSpec.describe HyperProbe::Agent, 'lifecycle concurrency and failure isolation' do
  let(:options) do
    { service_id: 'service', environment: 'test', commit_sha: 'commit',
      broker_url: 'localhost:60051', is_lambda: true, max_queue_size: 1 }
  end
  let(:broker) do
    double('broker', get_probes: response, estimate_event_size: 10,
           report_telemetry: [], shutdown: nil)
  end
  let(:engine) do
    double('engine', set_global_config: nil, set_probes: nil, close: nil,
           after_fork: nil, suspend: nil, resume: nil, is_suspended: false)
  end
  let(:probe) { Hyperprobe::Agent::V1::Probe.new(id: 'probe', hit_limit: 1) }
  let(:response) { Hyperprobe::Agent::V1::GetProbesResponse.new(probes: [probe]) }
  let(:reservation) { double('reservation', commit: nil, release: nil) }
  let(:event) { { probe_id: probe.id } }

  before do
    allow(HyperProbe::Core::BrokerClient).to receive(:new).and_return(broker)
    allow(HyperProbe::Core::MonitoringEngine).to receive(:new).and_return(engine)
    @threads = []
  end

  after do
    @threads.each { |thread| thread.kill if thread.alive? }
    @threads.each { |thread| thread.join(0.5) }
    @agent&.shutdown
  end

  def start_agent(extra = {})
    @agent = described_class.new(options.merge(extra))
    allow(@agent.quota_manager).to receive(:reserve_bandwidth).and_return(reservation)
    @agent
  end

  def spawn(&block)
    @threads << Thread.new(&block)
    @threads.last
  end

  def take(queue)
    Timeout.timeout(3) { queue.pop }
  end

  def finish(thread)
    expect(thread.join(3)).to eq(thread)
    thread.value
  end

  it 'resumes after cooldown expiration even while the timer thread is still exiting' do
    agent = start_agent(cooldown_sec: 0)
    allow(engine).to receive(:is_suspended).and_return(true)
    agent.safety_monitor.instance_variable_set(:@health, HyperProbe::Core::AgentHealth::YELLOW)
    checked = Queue.new
    release = Queue.new
    allow(agent.safety_monitor).to receive(:with_health).and_wrap_original do |original, health, &block|
      original.call(health, &block)
      checked << true
      release.pop
    end
    agent.send(:handle_health_change, HyperProbe::Core::AgentHealth::RED)
    take(checked)
    expect(agent.instance_variable_get(:@cooldown_timer)).to be_alive
    agent.safety_monitor.instance_variable_set(:@health, HyperProbe::Core::AgentHealth::GREEN)
    agent.send(:handle_health_change, HyperProbe::Core::AgentHealth::GREEN)
    expect(engine).to have_received(:resume).once
    release << true
  end

  it 'does not resume on GREEN before the cooldown deadline' do
    agent = start_agent(cooldown_sec: 30)
    allow(engine).to receive(:is_suspended).and_return(true)
    agent.send(:handle_health_change, HyperProbe::Core::AgentHealth::RED)
    agent.send(:handle_health_change, HyperProbe::Core::AgentHealth::GREEN)
    expect(engine).not_to have_received(:resume)
  end

  it 'does not log or suspend for timing breaches under JVM heap safety' do
    runtime = double('JVM runtime', max_memory: 1000, total_memory: 1000, free_memory: 200)
    allow(HyperProbe::Core::SafetyMonitor).to receive(:new).and_wrap_original do |original, callback, **kwargs|
      original.call(callback, **kwargs.merge(heap_runtime: runtime, is_ephemeral_lambda: false))
    end
    logger = HyperProbe::Core::Logger.get_logger('hyperprobe:safety')
    allow(logger).to receive(:warn)
    allow(logger).to receive(:error)
    agent = start_agent

    agent.safety_monitor.report_pause_duration(33)
    10.times { agent.safety_monitor.record_thread_lag(500) }

    expect(agent.safety_monitor.get_health).to eq(HyperProbe::Core::AgentHealth::GREEN)
    expect(logger).not_to have_received(:warn)
    expect(logger).not_to have_received(:error)
    expect(engine).not_to have_received(:suspend)
  end

  it 'stays suspended after cooldown while RED and resumes only after GREEN' do
    agent = start_agent(cooldown_sec: 0)
    allow(engine).to receive(:is_suspended).and_return(true)
    agent.safety_monitor.instance_variable_set(:@health, HyperProbe::Core::AgentHealth::RED)
    checked = Queue.new
    allow(agent.safety_monitor).to receive(:with_health).and_wrap_original do |original, health, &block|
      original.call(health, &block)
      checked << true
    end

    agent.send(:handle_health_change, HyperProbe::Core::AgentHealth::RED)
    take(checked)
    expect(engine).to have_received(:suspend).once
    expect(engine).not_to have_received(:resume)

    agent.safety_monitor.instance_variable_set(:@health, HyperProbe::Core::AgentHealth::GREEN)
    agent.send(:handle_health_change, HyperProbe::Core::AgentHealth::GREEN)
    expect(engine).to have_received(:resume).once
  end

  it 'admits the final hit once and drops contending application captures without waiting' do
    agent = start_agent
    agent.force_sync
    entered = Queue.new
    release = Queue.new
    allow(broker).to receive(:estimate_event_size) do
      entered << true
      release.pop
      10
    end
    first = spawn { agent.send(:handle_capture, event) }
    take(entered)
    contender = spawn { agent.send(:handle_capture, event) }
    finish(contender)
    expect(agent.telemetry_queue_length).to eq(0)
    expect(agent.active_probes).to be_empty
    expect(agent.instance_variable_get(:@local_hits)).to eq('probe' => 1)
    release << true
    finish(first)
    agent.send(:handle_capture, event)
    expect(agent.telemetry_queue_length).to eq(1)
    expect(agent.active_probes).to be_empty
    expect(agent.instance_variable_get(:@local_hits)).to eq('probe' => 1)
    expect(agent.quota_manager).to have_received(:reserve_bandwidth).once
  end

  it 'never exceeds queue capacity when distinct probes race for the final slot' do
    agent = start_agent
    other = Hyperprobe::Agent::V1::Probe.new(id: 'other', hit_limit: 10)
    agent.active_probes.merge!(probe.id => probe, other.id => other)
    gate = Queue.new
    workers = 20.times.map do |i|
      spawn do
        gate.pop
        agent.send(:handle_capture, probe_id: i.even? ? probe.id : other.id)
      end
    end
    20.times { gate << true }
    workers.each { |thread| finish(thread) }
    expect(agent.telemetry_queue_length).to eq(1)
    hits = agent.instance_variable_get(:@local_hits)
    expect(hits.fetch(probe.id, 0)).to be_between(0, 1)
    expect(hits.fetch(other.id, 0)).to be_between(0, 10)
    expect(hits.values.sum).to be >= 1
    expect(agent.quota_manager).to have_received(:reserve_bandwidth).once
  end

  it 'retires the final attempted hit asynchronously even with zero bandwidth' do
    agent = start_agent(bandwidth_kb_per_sec: 0)
    agent.force_sync
    applied = Queue.new
    allow(engine).to receive(:set_probes) do |probes, generation:|
      applied << [probes, generation, Thread.current]
    end
    allow(agent.quota_manager).to receive(:reserve_bandwidth).and_call_original
    agent.send(:handle_capture, event)
    agent.send(:handle_capture, event)
    expect(agent.telemetry_queue_length).to eq(0)
    expect(agent.active_probes).to be_empty
    expect(agent.instance_variable_get(:@local_hits)).to eq('probe' => 1)
    probes, generation, applying_thread = take(applied)
    expect(probes).to eq([])
    expect(generation).to eq(2)
    expect(applying_thread).not_to eq(Thread.current)
    expect(agent.quota_manager).to have_received(:reserve_bandwidth).once
    expect(reservation).not_to have_received(:release)
    agent.force_sync
    expect(agent.active_probes).to be_empty
  end

  it 'retires the final attempted hit asynchronously even when the queue is full' do
    agent = start_agent
    probe.hit_limit = 2
    agent.force_sync
    applied = Queue.new
    allow(engine).to receive(:set_probes) do |probes, generation:|
      applied << [probes, generation, Thread.current]
    end
    3.times { agent.send(:handle_capture, event) }
    expect(agent.instance_variable_get(:@local_hits)).to eq('probe' => 2)
    expect(agent.active_probes).to be_empty
    expect(agent.telemetry_queue_length).to eq(1)
    probes, generation, applying_thread = take(applied)
    expect(probes).to eq([])
    expect(generation).to eq(2)
    expect(applying_thread).not_to eq(Thread.current)
    expect(broker).to have_received(:estimate_event_size).once
    expect(agent.quota_manager).to have_received(:reserve_bandwidth).once
    expect(reservation).not_to have_received(:release)
    agent.force_sync
    expect(agent.active_probes).to be_empty
  end

  it 'keeps reservations charged across retries and commits only on delivery' do
    agent = start_agent
    agent.force_sync
    agent.send(:handle_capture, event)
    allow(broker).to receive(:report_telemetry).and_raise(IOError)
    2.times { agent.force_flush }
    expect(agent.telemetry_queue_length).to eq(1)
    expect(reservation).not_to have_received(:release)
    expect(reservation).not_to have_received(:commit)
    allow(broker).to receive(:report_telemetry).and_return([])
    agent.force_flush
    expect(agent.telemetry_queue_length).to eq(0)
    expect(reservation).to have_received(:commit).once
    expect(reservation).not_to have_received(:release)
  end

  it 'refunds only discarded retries when captures fill the queue during the RPC' do
    agent = start_agent
    probe.hit_limit = 3
    agent.force_sync
    agent.send(:handle_capture, event)
    entered = Queue.new
    release = Queue.new
    allow(broker).to receive(:report_telemetry) do
      entered << true
      release.pop
      raise IOError
    end
    flushing = spawn { agent.force_flush }
    take(entered)
    newer_reservation = double('new reservation', commit: nil, release: nil)
    allow(agent.quota_manager).to receive(:reserve_bandwidth).and_return(newer_reservation)
    agent.send(:handle_capture, event)
    release << true
    finish(flushing)
    expect(agent.telemetry_queue_length).to eq(1)
    expect(reservation).to have_received(:release).once
    expect(newer_reservation).not_to have_received(:release)
  end

  it 'does not requeue delivered events if applying finished probes fails' do
    agent = start_agent
    probe.hit_limit = 10
    agent.force_sync
    agent.send(:handle_capture, event)
    allow(broker).to receive(:report_telemetry).and_return([probe.id])
    allow(engine).to receive(:set_probes).and_raise(LoadError)
    agent.force_flush
    expect(agent.telemetry_queue_length).to eq(0)
    expect(reservation).to have_received(:commit).once
    expect(reservation).not_to have_received(:release)
  end

  it 'applies retirement off the application thread and rejects a delayed sync snapshot by generation' do
    agent = start_agent
    entered = Queue.new
    release = Queue.new
    applied = Queue.new
    state_mutex = Mutex.new
    current_generation = 0
    current_probes = nil
    allow(engine).to receive(:set_probes) do |probes, generation:|
      expect(agent.instance_variable_get(:@mutex).mon_owned?).to be(false)
      if generation == 1
        entered << true
        release.pop
      end
      state_mutex.synchronize do
        if generation > current_generation
          current_generation = generation
          current_probes = probes
        end
      end
      applied << [generation, Thread.current]
    end
    syncing = spawn { agent.force_sync }
    take(entered)
    agent.send(:handle_capture, event)
    generation, applying_thread = take(applied)
    expect(generation).to eq(2)
    expect(applying_thread).not_to eq(Thread.current)
    release << true
    finish(syncing)
    expect(current_generation).to eq(2)
    expect(current_probes).to eq([])
  end

  it 'does not resurrect a finished probe from an in-flight sync response' do
    agent = start_agent
    probe.hit_limit = 10
    agent.force_sync
    agent.send(:handle_capture, event)
    entered = Queue.new
    release = Queue.new
    allow(broker).to receive(:get_probes) do
      entered << true
      release.pop
      response
    end
    syncing = spawn { agent.force_sync }
    take(entered)
    allow(broker).to receive(:report_telemetry).and_return([probe.id])
    agent.force_flush
    release << true
    finish(syncing)
    expect(agent.active_probes).to be_empty
  end

  it 'does not let a delayed flush snapshot overwrite a newer sync snapshot' do
    agent = start_agent
    probe.hit_limit = 10
    agent.force_sync
    agent.send(:handle_capture, event)
    entered = Queue.new
    release = Queue.new
    applied_generation = 1
    applied_ids = [probe.id]
    state_mutex = Mutex.new
    allow(engine).to receive(:set_probes) do |probes, generation:|
      expect(agent.instance_variable_get(:@mutex).mon_owned?).to be(false)
      if generation == 2
        entered << true
        release.pop
      end
      state_mutex.synchronize do
        if generation > applied_generation
          applied_generation = generation
          applied_ids = probes.map(&:id)
        end
      end
    end
    allow(broker).to receive(:report_telemetry).and_return([probe.id])
    flushing = spawn { agent.force_flush }
    take(entered)
    replacement = Hyperprobe::Agent::V1::Probe.new(id: 'new-probe', hit_limit: 10)
    allow(broker).to receive(:get_probes).and_return(Hyperprobe::Agent::V1::GetProbesResponse.new(probes: [replacement]))
    expect(agent.force_sync).to be(true)
    release << true
    finish(flushing)
    expect(applied_generation).to eq(3)
    expect(applied_ids).to eq(['new-probe'])
  end

  it 'drops overlapping sync calls rather than queueing application callers' do
    agent = start_agent
    entered = Queue.new
    release = Queue.new
    allow(broker).to receive(:get_probes) do
      entered << true
      release.pop
      response
    end
    syncing = spawn { agent.force_sync }
    take(entered)
    expect(agent.force_sync).to be(false)
    release << true
    finish(syncing)
    expect(broker).to have_received(:get_probes).once
  end

  it 'honors explicit protobuf zeros and false while preserving absent fields' do
    agent = start_agent(captureClosures: true)
    config = Hyperprobe::Agent::V1::AgentGlobalConfig.new(
      max_object_depth: 0, max_array_length: 0, stack_frame_depth: 0,
      max_object_properties: 0, max_string_length: 0, capture_closures: false
    )
    allow(broker).to receive(:get_probes).and_return(
      Hyperprobe::Agent::V1::GetProbesResponse.new(global_config: config),
      Hyperprobe::Agent::V1::GetProbesResponse.new(global_config: Hyperprobe::Agent::V1::AgentGlobalConfig.new)
    )
    2.times { expect(agent.force_sync).to be(true) }
    expect(agent.global_config).to include(
      max_object_depth: 0, max_array_length: 0, stack_frame_depth: 0,
      max_object_properties: 0, max_string_length: 0, capture_closures: false
    )
  end

  it 'passes capture_closures configuration to the engine at startup' do
    start_agent(captureClosures: true)
    expect(engine).to have_received(:set_global_config).with(hash_including(capture_closures: true))
  end

  it 'performs the first broker request in the background without blocking startup' do
    entered = Queue.new
    release = Queue.new
    allow(broker).to receive(:get_probes) do
      entered << Thread.current
      release.pop
      response
    end
    agent = start_agent(is_lambda: false)
    expect(take(entered)).not_to eq(Thread.current)
    expect(agent.is_shutdown).to be(false)
    release << true
  end

  [SecurityError, LoadError, RuntimeError].each do |failure|
    it "isolates #{failure} in capture, sync, and flush" do
      agent = start_agent
      probe.hit_limit = 2
      agent.force_sync
      allow(broker).to receive(:estimate_event_size).and_raise(failure)
      expect { agent.send(:handle_capture, event) }.not_to raise_error
      allow(broker).to receive(:estimate_event_size).and_return(10)
      agent.send(:handle_capture, event)
      allow(broker).to receive(:report_telemetry).and_raise(failure)
      expect { agent.force_flush }.not_to raise_error
      expect(agent.telemetry_queue_length).to eq(1)
      expect(reservation).not_to have_received(:release)
      allow(broker).to receive(:get_probes).and_raise(failure)
      expect(agent.force_sync).to be(false)
    end

    it "rolls back safety startup #{failure} without leaking agent threads" do
      safety = double('safety', stop: nil)
      allow(safety).to receive(:start).and_raise(failure)
      allow(HyperProbe::Core::SafetyMonitor).to receive(:new).and_return(safety)
      agent = start_agent(is_lambda: false)
      expect(agent.is_shutdown).to be(true)
      expect(agent.agent_disabled?).to be(true)
      expect(engine).to have_received(:close)
      expect(broker).to have_received(:shutdown)
      expect(safety).to have_received(:stop)
      expect(agent.instance_variable_get(:@apply_thread)).not_to be_alive
    end
  end

  it 'rolls back engine configuration failure and still closes the broker' do
    allow(engine).to receive(:set_global_config).and_raise(LoadError)
    agent = start_agent
    expect(agent.is_shutdown).to be(true)
    expect(engine).to have_received(:close)
    expect(broker).to have_received(:shutdown)
  end

  it 'fails closed without throwing when initialization fails before lifecycle fields exist' do
    invalid_options = double('invalid options')
    allow(invalid_options).to receive(:dup).and_raise(LoadError)
    expect { @agent = described_class.new(invalid_options) }.not_to raise_error
    expect(@agent.is_shutdown).to be(true)
    expect(@agent.agent_disabled?).to be(true)
    expect { @agent.shutdown }.not_to raise_error
    expect(@agent.telemetry_queue_length).to eq(0)
    expect(HyperProbe::Core::BrokerClient).not_to have_received(:new)
  end

  it 'stops safety resources when broker construction fails' do
    safety = double('safety', stop: nil)
    allow(HyperProbe::Core::SafetyMonitor).to receive(:new).and_return(safety)
    allow(HyperProbe::Core::BrokerClient).to receive(:new).and_raise(SecurityError)
    agent = start_agent
    expect(agent.is_shutdown).to be(true)
    expect(safety).to have_received(:stop)
  end

  it 'closes the broker when engine construction raises' do
    allow(HyperProbe::Core::MonitoringEngine).to receive(:new).and_raise(LoadError)
    agent = start_agent
    expect(agent.is_shutdown).to be(true)
    expect(broker).to have_received(:shutdown)
  end

  it 'fails closed when safety construction raises before the broker exists' do
    allow(HyperProbe::Core::SafetyMonitor).to receive(:new).and_raise(SecurityError)
    agent = start_agent
    expect(agent.is_shutdown).to be(true)
    expect(HyperProbe::Core::BrokerClient).not_to have_received(:new)
  end

  it 'rolls back background threads if startup fails after loops were launched' do
    allow_any_instance_of(described_class).to receive(:start_background_loops).and_wrap_original do |original|
      original.call
      raise SecurityError
    end
    agent = start_agent(is_lambda: false)
    expect(agent.is_shutdown).to be(true)
    %i[@sync_thread @flush_thread @stats_thread @apply_thread].each do |name|
      expect(agent.instance_variable_get(name)).not_to be_alive
    end
    expect(engine).to have_received(:close)
    expect(broker).to have_received(:shutdown)
  end

  it 'closes each resource independently even when cleanup raises fatal exceptions' do
    agent = start_agent
    allow(engine).to receive(:close).and_raise(SystemExit)
    allow(agent.safety_monitor).to receive(:stop).and_raise(LoadError)
    allow(broker).to receive(:shutdown).and_raise(SystemExit)
    expect { agent.shutdown }.not_to raise_error
    expect(engine).to have_received(:close).once
    expect(agent.safety_monitor).to have_received(:stop).once
    expect(broker).to have_received(:shutdown).once
    expect(agent.instance_variable_get(:@apply_thread)).not_to be_alive
  end

  it 'bounds shutdown when an agent resource never returns' do
    agent = start_agent
    blocked = Queue.new
    allow(engine).to receive(:close) { blocked.pop }
    started = Process.clock_gettime(Process::CLOCK_MONOTONIC)
    agent.shutdown
    expect(Process.clock_gettime(Process::CLOCK_MONOTONIC) - started).to be < 1.5
    expect(broker).to have_received(:shutdown)
  end

  it 'does not make concurrent shutdown callers wait for resource cleanup' do
    agent = start_agent
    entered = Queue.new
    release = Queue.new
    allow(engine).to receive(:close) do
      entered << true
      release.pop
    end
    stopping = spawn { agent.shutdown }
    take(entered)
    contender = spawn { agent.shutdown }
    expect(contender.join(0.2)).to eq(contender)
    release << true
    finish(stopping)
    expect(engine).to have_received(:close).once
  end

  it 'refunds queued events discarded at shutdown' do
    agent = start_agent
    agent.force_sync
    agent.send(:handle_capture, event)
    agent.shutdown
    expect(agent.telemetry_queue_length).to eq(0)
    expect(reservation).to have_received(:release).once
  end

  it 'ignores late sync responses after shutdown' do
    agent = start_agent
    entered = Queue.new
    release = Queue.new
    allow(broker).to receive(:get_probes) do
      entered << true
      release.pop
      response
    end
    syncing = spawn { agent.force_sync }
    take(entered)
    agent.shutdown
    release << true
    finish(syncing)
    expect(agent.active_probes).to be_empty
    expect(engine).not_to have_received(:set_probes)
  end

  it 'disables an inherited instance without calling any inherited broker or safety resource' do
    agent = start_agent
    agent.instance_variable_set(:@owner_pid, Process.pid - 1)
    expect(agent.after_fork).to be(false)
    expect(agent.is_shutdown).to be(true)
    expect(agent.agent_disabled?).to be(true)
    agent.force_sync
    agent.force_flush
    agent.shutdown
    expect(engine).to have_received(:after_fork).at_least(:once)
    expect(broker).not_to have_received(:get_probes)
    expect(broker).not_to have_received(:report_telemetry)
    expect(broker).not_to have_received(:shutdown)
  ensure
    agent&.instance_variable_get(:@apply_thread)&.kill
  end

  it 'disables inherited hooks in a real MRI child without restarting or closing the broker' do
    skip 'JRuby does not support fork' if RUBY_PLATFORM.match?(/java/)

    agent = start_agent
    reader, writer = IO.pipe
    hooks_disabled = false
    allow(engine).to receive(:after_fork) { hooks_disabled = true }
    allow(broker).to receive(:shutdown) { raise 'inherited broker accessed' if Process.pid != agent.owner_pid }
    allow(broker).to receive(:get_probes) { raise 'inherited broker accessed' }
    child = fork do
      reader.close
      agent.after_fork
      agent.force_sync
      agent.shutdown
      writer.write(hooks_disabled && agent.is_shutdown && agent.agent_disabled? ? 'disabled' : 'failed')
      writer.close
      Process.exit!(0)
    end
    writer.close
    expect(IO.select([reader], nil, nil, 3)).not_to be_nil
    expect(reader.read).to eq('disabled')
    Timeout.timeout(3) { Process.waitpid(child) }
    child = nil
    expect(agent.is_shutdown).to be(false)
  ensure
    reader&.close
    writer&.close unless writer&.closed?
    if child
      Process.kill('KILL', child)
      Process.waitpid(child)
    end
  end
end
