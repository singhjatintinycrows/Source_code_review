# frozen_string_literal: true

require 'spec_helper'
begin
  require 'ostruct'
rescue LoadError
  # OpenStruct is an optional gem on Ruby 4.
end

RSpec.describe HyperProbe::Core::Serializer, 'safe capture regressions' do
  subject(:serializer) { described_class.new }

  def trap_methods(object, calls, methods)
    methods.each do |name|
      object.define_singleton_method(name) do |*|
        calls << name
        raise Exception, 'Application code must not run'
      end
    end
    object
  end

  it 'bypasses overridden primitive introspection, identity, and ivar access' do
    calls = []
    object = Object.new
    object.instance_variable_set(:@name, 'Alice')
    object.instance_variable_set(:@secret, 'not exposed')
    object.instance_variable_set(:@next_person, object)
    trap_methods(object, calls, %i[== equal? is_a? kind_of? class __id__ object_id
                                  instance_variables instance_variable_get inspect
                                  to_s to_json respond_to? method_missing name secret next_person])
    result = described_class.new(redact_keys: ['secret']).serialize(object)
    expect(result).to eq('name' => 'Alice', 'secret' => '[REDACTED Key]', 'next_person' => '[REF - $]')
    expect(calls).to be_empty
  end

  it 'handles hostile BasicObject subclasses without dispatching even equality' do
    calls = []
    klass = Class.new(BasicObject)
    %i[== equal? is_a? class __id__ instance_variables instance_variable_get
       inspect to_s respond_to? method_missing].each do |name|
      klass.define_method(name) do |*|
        calls << name
        ::Kernel.raise ::Exception, 'Application code must not run'
      end
    end
    object = klass.new
    Kernel.instance_method(:instance_variable_set).bind(object).call(:@hidden, 'never exposed')
    expect(serializer.serialize(object)).to eq('[Obj: anonymous]')
    expect(calls).to be_empty
  end

  it 'copies string subclasses using core byte access before encoding or redaction' do
    calls = []
    string = Class.new(String).new('hello confidential')
    trap_methods(string, calls, %i[== is_a? class bytesize byteslice encode length
                                  to_s to_str gsub inspect to_json])
    result = described_class.new(redact_values: ['confidential']).serialize(string)
    expect(result).to eq('hello [REDACTED Value]')
    expect(result.class).to eq(String)
    expect(JSON.generate(result)).to eq('"hello [REDACTED Value]"')
    expect(calls).to be_empty
  end

  it 'uses bound array access and identity for cycles despite singleton overrides' do
    calls = []
    array = [1]
    array << array
    trap_methods(array, calls, %i[== is_a? class __id__ length size [] each to_a to_json])
    expect(serializer.serialize(array)).to eq([1, '[REF - $]'])
    expect(calls).to be_empty
  end

  it 'enumerates hashes without key lookup, key conversion, or overridden accessors' do
    calls = []
    key = Object.new
    hash = { key => 'value', 'safe' => 2 }
    trap_methods(key, calls, %i[hash eql? == to_s inspect to_json is_a? class])
    trap_methods(hash, calls, %i[== is_a? class keys size length [] each each_pair to_h to_json])
    expect(serializer.serialize(hash)).to eq('[Opaque key 1]' => 'value', 'safe' => 2)
    expect(calls).to be_empty
  end

  it 'does not materialize or dispatch through a large Set' do
    calls = []
    set = Set.new(0...100_000)
    trap_methods(set, calls, %i[== is_a? class size length each to_a to_json instance_variable_get])
    if RUBY_PLATFORM.include?('java')
      expect(serializer.serialize(set)).to eq([0, 1, 2, '[+ 99997 more items truncated]'])
    else
      expect(serializer.serialize(set)).to eq('[Obj: Set]')
    end
    expect(calls).to be_empty
  end

  it 'keeps collection subclasses opaque rather than trusting their storage' do
    calls = []
    [Array, Hash, Set].each do |base|
      object = Class.new(base).new
      trap_methods(object, calls, %i[== is_a? class size length [] each each_pair to_a keys])
      expect(serializer.serialize(object)).to eq('[Obj: anonymous]')
    end
    expect(calls).to be_empty
  end

  it 'does not implicitly destructure Set elements through application to_ary' do
    calls = []
    object = Object.new
    set = Set.new([object, [1, 2]])
    trap_methods(object, calls, %i[to_ary hash eql? inspect])
    expect(serializer.serialize(set)).to eq(['[Obj: Object]', [1, 2]])
    expect(calls).to be_empty
  end

  it 'reads bounded Struct storage without custom conversions' do
    calls = []
    struct = Struct.new(:name, :password).new('alice', 'secret')
    trap_methods(struct, calls, %i[to_h each_pair members size [] instance_variable_get])
    result = described_class.new(redact_keys: ['password']).serialize(struct)
    expect(result).to eq('name' => 'alice', 'password' => '[REDACTED Key]')
    expect(calls).to be_empty
  end

  it 'reads OpenStruct storage without custom conversions when installed' do
    skip 'Optional ostruct gem is not installed' unless defined?(OpenStruct)
    calls = []
    object = OpenStruct.new(name: 'alice', password: 'secret')
    trap_methods(object, calls, %i[to_h each_pair members size [] instance_variable_get])
    result = described_class.new(redact_keys: ['password']).serialize(object)
    expect(result).to eq('name' => 'alice', 'password' => '[REDACTED Key]')
    expect(calls).to be_empty
  end

  it 'does not format arbitrary Numeric values or huge integers' do
    calls = []
    klass = Class.new(Numeric)
    %i[== is_a? class to_s to_f to_int to_json inspect].each do |name|
      klass.define_method(name) do |*|
        calls << name
        raise 'Application code must not run'
      end
    end
    number = klass.new
    expect(serializer.serialize(number)).to eq('[Obj: anonymous]')
    expect(serializer.serialize(1 << 100_000)).to eq('[Integer: too large]')
    expect(serializer.serialize(Rational(1, 2))).to eq('[Obj: Rational]')
    expect(calls).to be_empty
  end

  it 'never inspects Regexp or Range values or their application-owned endpoints' do
    calls = []
    endpoint = Object.new
    endpoint.define_singleton_method(:<=>) { |_| 0 }
    range = Range.new(endpoint, endpoint)
    trap_methods(endpoint, calls, %i[inspect to_s ==])
    regexp = /confidential-secret/
    expect(serializer.serialize(range)).to eq('[Obj: Range]')
    expect(serializer.serialize(regexp)).to eq('[Obj: Regexp]')
    expect(calls).to be_empty
  end

  it 'does not call exception accessors or convert arbitrary exception messages' do
    calls = []
    message = Object.new
    trap_methods(message, calls, %i[to_s to_str inspect])
    error = StandardError.new(message)
    trap_methods(error, calls, %i[message to_s backtrace inspect class])
    expect(serializer.serialize(error)).to eq('[Obj: StandardError]')
    expect(calls).to be_empty
  end

  it 'formats ordinary dates, times, and callables without overridden methods' do
    calls = []
    time = Time.utc(2026, 8, 27, 12)
    date = Date.new(2026, 8, 27)
    function = -> { raise 'must not execute' }
    method = 'hello'.method(:upcase)
    [time, date, function, method].each do |object|
      trap_methods(object, calls, %i[is_a? class iso8601 strftime utc? lambda? name to_s call])
    end
    expect(serializer.serialize(time)).to eq('2026-08-27T12:00:00Z')
    expect(serializer.serialize(date)).to eq('2026-08-27')
    expect(serializer.serialize(function)).to eq('[Function: (lambda)]')
    expect(serializer.serialize(method)).to eq('[Function: upcase]')
    expect(calls).to be_empty
  end

  it 'redacts symbols, class names, method names, keys, and reference paths' do
    stub_const('ConfidentialSerializerFixture', Class.new)
    object = ConfidentialSerializerFixture.new
    object.define_singleton_method(:confidential_method) { nil }
    shared = []
    data = [:confidential, object, object.method(:confidential_method),
            { 'confidential' => shared, 'again' => shared }]
    result = described_class.new(max_array_length: 10, redact_values: ['confidential']).serialize(data)
    expect(JSON.generate(result).downcase).not_to include('confidential')
    expect(JSON.generate(result)).to include('[REDACTED Value]')
  end

  it 'keeps out-of-range dates and times opaque instead of formatting huge years' do
    expect(serializer.serialize(Time.utc(100_000))).to eq('[Obj: Time]')
    expect(serializer.serialize(Date.new(100_000, 1, 1))).to eq('[Obj: Date]')
    expect(serializer.serialize(DateTime.new(100_000, 1, 1))).to eq('[Obj: DateTime]')
  end

  it 'bounds multi-megabyte strings before encoding or regex work and does not mutate them' do
    string = ('x' * 2_000_000 + 'confidential').freeze
    result = described_class.new(max_string_length: 32, redact_values: ['confidential']).serialize(string)
    expect(result).to start_with('[REDACTED Value]')
    expect(result.bytesize).to be < 100
    expect(string.bytesize).to eq(2_000_012)
  end

  it 'fails closed for a redacted key that may have been cut before the sensitive suffix' do
    data = { 'x' * 100 + 'password' => 'do not expose' }
    result = described_class.new(max_string_length: 20, redact_keys: ['password']).serialize(data)
    expect(result.values).to eq(['[REDACTED Key]'])
  end

  it 'accepts bounded literal alternatives and anchors for redaction' do
    result = described_class.new(redact_keys: ['^password$'], redact_values: ['secret|token']).serialize(
      'password' => 'hidden', 'other' => 'SECRET and token', 'password_hint' => 'safe'
    )
    expect(result).to eq('password' => '[REDACTED Key]',
                         'other' => '[REDACTED Value] and [REDACTED Value]',
                         'password_hint' => 'safe')
  end

  it 'fails closed instead of compiling pathological or unsupported regexes' do
    ['(a+)+$', '(a|aa)+$', 'a*a*a*a*a*b', '(?=secret)', '[', '\\1', '(?R)', 'x' * 1000].each do |pattern|
      result = described_class.new(redact_values: [pattern]).serialize('a' * 100 + '!')
      expect(result).to eq('[REDACTED Value]')
      result = described_class.new(redact_keys: [pattern]).serialize('anything' => 'hidden')
      expect(result.values).to eq(['[REDACTED Key]'])
    end
  end

  it 'bounds redaction configuration and does not coerce application patterns' do
    calls = []
    pattern = Object.new
    trap_methods(pattern, calls, %i[to_s to_str to_a empty? nil?])
    [pattern, [pattern], Array.new(100_000, 'safe')].each do |patterns|
      expect(described_class.new(redact_values: patterns).serialize('secret')).to eq('[REDACTED Value]')
    end
    expect(calls).to be_empty
  end

  it 'bounds redaction replacement expansion and sanitizes invalid encodings' do
    serializer = described_class.new(max_string_length: 32, redact_values: ['a'])
    result = serializer.serialize('a' * 32)
    expect(result.bytesize).to be < 100
    ["\xffhello".b, "\xffhello".b.force_encoding('UTF-8'), 'hello'.encode('UTF-16LE')].each do |value|
      expect { JSON.parse(described_class.safe_dump_json(serializer.serialize(value))) }.not_to raise_error
    end
  end

  it 'enforces a global node budget across a broad tree even with enormous configured limits' do
    tree = 8.times.reduce(0) { |child, _| Array.new(128) { [child] } }
    result = described_class.new(max_depth: 1_000_000, max_array_length: 1_000_000).serialize(tree)
    json = JSON.generate(result)
    expect(json).to include('Capture budget exhausted').or include('more items truncated')
    expect(json.bytesize).to be <= described_class::MAX_BYTES
  end

  it 'enforces an aggregate byte budget for strings, keys, and deeply nested paths' do
    data = Array.new(128) { |i| { ('k' * 4090 + i.to_s) => Array.new(128, "\x00" * 4096) } }
    result = described_class.new(max_array_length: 128, max_string_length: 4096).serialize(data)
    expect(JSON.generate(result).bytesize).to be <= described_class::MAX_BYTES
    expect(JSON.generate(result)).to include('Capture budget exhausted')
  end

  it 'does not read or mutate a caller-owned visited table or trust its path strings' do
    calls = []
    visited = { 123 => Object.new }.freeze
    trap_methods(visited = visited.dup, calls, %i[key? [] []= each each_pair])
    path = Object.new
    trap_methods(path, calls, %i[to_s == is_a?])
    array = []
    array << array
    expect(serializer.serialize(array, path, 0, visited)).to eq(['[REF - $]'])
    expect(calls).to be_empty
  end

  it 'does not share reference state or budgets between unshared captures or concurrent callers' do
    array = []
    array << array
    threads = Array.new(4) { Thread.new { 20.times.map { serializer.serialize(array) } } }
    expect(threads.flat_map(&:value)).to all(eq(['[REF - $]']))
  end

  it 'shares references across watch and frame roots without touching a hostile token' do
    calls = []
    token = Object.new
    trap_methods(token, calls, %i[== equal? __id__ hash eql? [] []= each is_a? nil?])
    person = Object.new
    person.instance_variable_set(:@name, 'Alice')
    person.instance_variable_set(:@next_person, person)
    watch = serializer.serialize(person, 'watch["sessionUser"]', 0, token)
    locals = serializer.serialize({ 'current_user' => person }, 'frame[0].scopes[0]', 0, token)
    expect(watch).to eq('name' => 'Alice', 'next_person' => '[REF - watch["sessionUser"]]')
    expect(locals).to eq('current_user' => '[REF - watch["sessionUser"]]')
    expect(calls).to be_empty
  end

  it 'shares node budgets across roots even when the token is frozen' do
    token = {}.freeze
    described_class::MAX_NODES.times { expect(serializer.serialize(nil, '$', 0, token)).to be_nil }
    expect(serializer.serialize(nil, '$', 0, token)).to eq(described_class::BUDGET_MARKER)
    expect(serializer.serialize(nil)).to be_nil
    expect(token).to eq({})
  end

  it 'shares byte budgets across roots and starts fresh for a new token' do
    token = {}.freeze
    results = 20.times.map { serializer.serialize('x' * 1024, '$', 0, token) }
    expect(results).to include(described_class::BUDGET_MARKER)
    expect(serializer.serialize('fresh', '$', 0, {})).to eq('fresh')
  end

  it 'retains only the active token context and distinguishes equal tokens by identity' do
    first = Hash.new.freeze
    second = Hash.new.freeze
    object = { 'name' => 'Alice' }
    expect(serializer.serialize(object, 'first', 0, first)).to eq(object)
    expect(serializer.serialize(object, 'again', 0, first)).to eq('[REF - first]')
    expect(serializer.serialize(object, 'second', 0, second)).to eq(object)
    expect(serializer.serialize(object, 'restarted', 0, first)).to eq(object)
    expect(serializer.serialize(object, 'last', 0, first)).to eq('[REF - restarted]')
  end

  it 'keeps unshared captures independent of the active shared context' do
    token = BasicObject.new
    object = []
    expect(serializer.serialize(object, 'watch', 0, token)).to eq([])
    expect(serializer.serialize(object)).to eq([])
    expect(serializer.serialize(object, 'local', 0, token)).to eq('[REF - watch]')
  end

  it 'accounts for concurrent shared roots without racing the reference table' do
    token = {}.freeze
    object = { 'name' => 'Alice' }
    threads = Array.new(4) do
      Thread.new { 10.times.map { serializer.serialize(object, 'shared', 0, token) } }
    end
    results = threads.flat_map(&:value)
    expect(results.count(object)).to eq(1)
    expect(results.count('[REF - shared]')).to eq(39)
  end

  it 'bounds ordinary object field reads and traversal after native ivar-name enumeration' do
    object = Object.new
    1000.times { |i| object.instance_variable_set("@field_#{i}", i) }
    result = described_class.new(max_object_properties: 2).serialize(object)
    expect(result.size).to eq(3)
    expect(result['__probe_meta']).to eq('+ 998 more properties truncated')
    expect(result.values.grep(Integer).size).to eq(2)
  end

  it 'limits and redacts ivar names and values just like hash properties' do
    object = Object.new
    object.instance_variable_set(:@note, 'confidential')
    object.instance_variable_set('@' + 'x' * 100 + 'password', 'never exposed')
    result = described_class.new(max_string_length: 20, redact_keys: ['password'],
                                 redact_values: ['confidential']).serialize(object)
    expect(result['note']).to eq('[REDACTED Value]')
    expect(result.values).to include('[REDACTED Key]')
    expect(JSON.generate(result)).not_to include('never exposed', 'confidential')
  end

  it 'preserves already captured fields and reference markers when JSON-wrapping shared roots' do
    token = {}
    object = Object.new
    object.instance_variable_set(:@name, 'Alice')
    object.instance_variable_set(:@next_person, object)
    watch = serializer.serialize(object, 'watch["person"]', 0, token)
    locals = serializer.serialize({ 'person' => object }, 'frame[0]', 0, token)
    envelope = { 'watches' => { 'person' => watch }, 'frames' => [{ 'locals' => locals }] }
    expect(JSON.parse(described_class.safe_dump_json(envelope))).to eq(envelope)
  end

  it 'does not apply capture depth and node limits again to previously safe wrapped data' do
    capturing = described_class.new(max_depth: described_class::MAX_DEPTH, max_array_length: 128)
    deep = 16.times.reduce('leaf') { |child, _| { 'child' => child } }
    captured = capturing.serialize(deep)
    wrapped = { 'frames' => [{ 'scopes' => [captured] }] }
    expect(JSON.parse(described_class.safe_dump_json(wrapped))).to eq(wrapped)

    captured = capturing.serialize(Array.new(128) { |i| [i, i, i] })
    wrapped = { 'frames' => [{ 'scopes' => [captured] }] }
    expect(JSON.parse(described_class.safe_dump_json(wrapped))).to eq(wrapped)
  end

  it 'preserves generated truncation markers beyond the original collection and string limits' do
    capturing = described_class.new(max_array_length: 128, max_string_length: 4096)
    captured = capturing.serialize(Array.new(130, 1))
    expect(JSON.parse(described_class.safe_dump_json(captured))).to eq(captured)

    captured = capturing.serialize('x' * 5000)
    expect(JSON.parse(described_class.safe_dump_json(captured))).to eq(captured)
  end

  it 'sanitizes all inputs before JSON generation, including singleton to_json methods' do
    calls = []
    string = +'hello'
    array = [string, Object.new]
    hash = { 'value' => array }
    [string, array, hash, array.last].each { |value| trap_methods(value, calls, %i[to_json to_s inspect]) }
    expect(JSON.parse(described_class.safe_dump_json(hash))).to eq('value' => ['hello', '[Obj: Object]'])
    expect(calls).to be_empty
  end

  if RUBY_PLATFORM.include?('java')
    it 'reads only known Java list implementations using bound Java dispatch' do
      calls = []
      [java.util.ArrayList, java.util.LinkedList].each do |klass|
        list = klass.new([1, 2, 3, 4])
        trap_methods(list, calls, %i[get size getClass java_send toString equals to_a iterator])
        expect(serializer.serialize(list)).to eq([1, 2, 3, '[+ 1 more items truncated]'])
      end
      expect(calls).to be_empty
    end

    it 'bounds linked Java map/set iteration without materializing keys or invoking getters' do
      calls = []
      map = java.util.LinkedHashMap.new
      set = java.util.LinkedHashSet.new
      10_000.times { |i| map.put(i, i); set.add(i) }
      trap_methods(map, calls, %i[get keySet entrySet size java_send toString equals])
      trap_methods(set, calls, %i[toArray iterator size java_send toString equals])
      result = described_class.new(max_object_properties: 3).serialize(map)
      expect(result).to eq('0' => 0, '1' => 1, '2' => 2,
                           '__probe_meta' => '+ 9997 more properties truncated')
      expect(serializer.serialize(set)).to eq([0, 1, 2, '[+ 9997 more items truncated]'])
      expect(calls).to be_empty
    end

    it 'does not reorder an access-ordered LinkedHashMap while reading entries' do
      map = java.util.LinkedHashMap.new(16, 0.75, true)
      %w[a b c d].each { |key| map.put(key, key) }
      expect(described_class.new(max_object_properties: 2).serialize(map)).to include('a' => 'a', 'b' => 'b')
      expect(map.keySet.to_a).to eq(%w[a b c d])
    end

    it 'does not invoke mutating Java getters or Throwable accessors' do
      atomic = java.util.concurrent.atomic.AtomicInteger.new(42)
      expect(serializer.serialize(atomic)).to include('AtomicInteger')
      expect(atomic.get).to eq(42)
      calls = []
      throwable = java.lang.RuntimeException.new('confidential')
      trap_methods(throwable, calls, %i[getMessage getStackTrace toString equals])
      expect(serializer.serialize(throwable)).to include('RuntimeException')
      expect(calls).to be_empty
    end

    it 'does not trust Java collection subclasses, sparse hash tables, or application toString/equals' do
      calls = []
      klass = Class.new(java.util.ArrayList)
      %i[get size iterator toString equals].each do |name|
        klass.define_method(name) do |*|
          calls << name
          raise 'Application code must not run'
        end
      end
      expect(serializer.serialize(klass.new)).to start_with('[Obj:')
      expect(serializer.serialize(java.util.HashMap.new)).to include('HashMap')
      expect(serializer.serialize(java.util.HashSet.new)).to include('HashSet')
      expect(calls).to be_empty
    end
  end
end
