# frozen_string_literal: true

require 'spec_helper'
require 'tempfile'

RSpec.describe HyperProbe::Core::MonitoringEngine do
  let(:quota) { HyperProbe::Core::QuotaManager.new(100, 1024 * 1024) }
  let(:safety) { HyperProbe::Core::SafetyMonitor.new(->(_h, _r) {}) }
  let(:events) { [] }
  let(:on_capture) { ->(evt) { events << evt } }

  subject(:engine) do
    described_class.new(quota, safety, on_capture)
  end

  after { engine.close }

  describe 'Live Probe Interception' do
    let(:tmp_file) do
      f = Tempfile.new(['ruby_probe_target', '.rb'])
      f.write(<<-RUBY)
        def target_calculation(val)
          step1 = val * 2
          step2 = step1 + 10 # Line 3: Probe target
          step2
        end

        def target_loop(items)
          # Line 8: Duration start
          t_start = 1
          items.each do |item|
            item_name = item[:name] # Line 12: Log/Counter/Metric
          end
          # Line 15: Duration end
          t_end = 2
        end
      RUBY
      f.close
      f
    end

    let(:file_path) { tmp_file.path }

    before do
      load file_path
    end

    after do
      tmp_file.unlink
    end

    it 'captures SNAPSHOT probes with watches, locals, and stack frames' do
      engine.set_probes([
        {
          id: 'snapshot-1',
          type: 1, # SNAPSHOT
          runtime_location: file_path,
          runtime_line: 3,
          watch_expressions: ['step1 + 5', 'val']
        }
      ])

      target_calculation(20)

      expect(events.length).to eq(1)
      evt = events.first
      expect(evt[:probe_id]).to eq('snapshot-1')

      captured_vars = JSON.parse(evt[:captured_vars_json])
      local_scope = captured_vars.first.first
      expect(local_scope['type']).to eq('local')
      expect(local_scope['vars']['val']).to eq(20)
      expect(local_scope['vars']['step1']).to eq(40)

      watches = JSON.parse(evt[:watch_results_json])
      expect(watches['step1 + 5']).to eq(45)
      expect(watches['val']).to eq(20)

      expect(evt[:stack_frames].length).to be >= 1
      expect(evt[:stack_frames].first[:function_name]).to include('target_calculation')
    end

    it 'evaluates LOG probes and templates' do
      engine.set_probes([
        {
          id: 'log-1',
          type: 2, # LOG
          runtime_location: file_path,
          runtime_line: 11,
          template: 'Processed item ${item[:name]}'
        }
      ])

      target_loop([{ name: 'Alpha' }, { name: 'Beta' }])

      expect(events.length).to eq(2)
      expect(events[0][:evaluated_log]).to eq('Processed item Alpha')
      expect(events[1][:evaluated_log]).to eq('Processed item Beta')
    end

    it 'evaluates COUNTER probes' do
      engine.set_probes([
        {
          id: 'counter-1',
          type: 3, # COUNTER
          runtime_location: file_path,
          runtime_line: 11
        }
      ])

      target_loop([{ name: 'A' }, { name: 'B' }])

      expect(events.length).to eq(2)
      expect(events[0][:metric_value]).to eq(1.0)
      expect(events[1][:metric_value]).to eq(1.0)
    end

    it 'evaluates METRIC probes' do
      engine.set_probes([
        {
          id: 'metric-1',
          type: 4, # METRIC
          runtime_location: file_path,
          runtime_line: 3,
          metric_expression: 'step1 * 1.5'
        }
      ])

      target_calculation(10)

      expect(events.length).to eq(1)
      expect(events[0][:metric_value]).to eq(30.0)
    end

    it 'evaluates DURATION probes with primary and secondary locations' do
      engine.set_probes([
        {
          id: 'duration-1',
          type: 5, # DURATION
          runtime_location: file_path,
          runtime_line: 9,
          secondary_runtime_location: file_path,
          secondary_runtime_line: 14,
          correlation_expression: '"fixed-id"'
        }
      ])

      target_loop([{ name: 'X' }])

      expect(events.length).to eq(1)
      expect(events[0][:probe_id]).to eq('duration-1')
      expect(events[0][:metric_value]).to be > 0.0
    end

    it 'enforces condition expressions and filters non-matching hits' do
      engine.set_probes([
        {
          id: 'cond-probe',
          type: 3, # COUNTER
          runtime_location: file_path,
          runtime_line: 3,
          condition: 'val > 50'
        }
      ])

      target_calculation(10) # 10 not > 50
      expect(events.length).to eq(0)

      target_calculation(100) # 100 > 50
      expect(events.length).to eq(1)
    end

    it 'captures probes inside top-level blocks or code outside class methods' do
      block_tmp = Tempfile.new(['ruby_probe_block_target', '.rb'])
      block_tmp.write(<<-RUBY)
        class MathHelper
          def self.compute(x)
            x * 2 # Line 3
          end
        end

        $block_handler = ->(input) do
          doubled = MathHelper.compute(input) # Line 9
          result = doubled + 10 # Line 10
          result # Line 11
        end
      RUBY
      block_tmp.close
      load block_tmp.path

      engine.set_probes([
        {
          id: 'method-probe',
          type: 1, # SNAPSHOT
          runtime_location: block_tmp.path,
          runtime_line: 3
        },
        {
          id: 'block-probe-1',
          type: 1, # SNAPSHOT
          runtime_location: block_tmp.path,
          runtime_line: 9
        },
        {
          id: 'block-probe-2',
          type: 1, # SNAPSHOT
          runtime_location: block_tmp.path,
          runtime_line: 10
        }
      ])

      $block_handler.call(5)

      probe_ids = events.map { |e| e[:probe_id] }
      expect(probe_ids).to include('method-probe')
      expect(probe_ids).to include('block-probe-1')
      expect(probe_ids).to include('block-probe-2')

      block_tmp.unlink
    end

    it 'ensures SecurityError in probe condition never crashes the application thread' do
      engine.set_probes([
        {
          id: 'forbidden-condition-probe',
          type: 1, # SNAPSHOT
          runtime_location: file_path,
          runtime_line: 3,
          condition: 'system("ls")'
        }
      ])

      expect {
        res = target_calculation(25)
        expect(res).to eq(60)
      }.not_to raise_error

      error_event = events.find { |e| e[:probe_id] == 'forbidden-condition-probe' }
      expect(error_event).not_to be_nil
      expect(error_event[:capture_error]).to include('forbidden')
    end

    it 'caps @duration_starts to MAX_DURATION_ENTRIES to prevent unbounded memory' do
      max_cap = described_class::MAX_DURATION_ENTRIES
      engine.set_probes([
        {
          id: 'duration-overflow',
          type: 5, # DURATION
          runtime_location: file_path,
          runtime_line: 3,
          correlation_expression: 'val'
        }
      ])

      # Call with more than MAX_DURATION_ENTRIES unique values
      (max_cap + 50).times do |i|
        target_calculation(i)
      end

      duration_map = engine.instance_variable_get(:@duration_starts)
      expect(duration_map.size).to be <= max_cap
    end
  end
end
