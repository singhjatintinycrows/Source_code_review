# frozen_string_literal: true

require 'spec_helper'

RSpec.describe HyperProbe::Core::SafeASTValidator do
  describe '.validate!' do
    [
      'cart_total * 1.5', 'items.length > 0 && price <= 50.0',
      'user[:role] == "admin"', 'items.size()', '(1 + 2) / 3',
      '{id: [1, true, nil]}[:id][0]', 'flag ? "yes" : "no"',
      'not false', 'value || 0', '"literal system() and = text"'
    ].each do |expression|
      it "allows restricted expression #{expression}" do
        expect { described_class.validate!(expression) }.not_to raise_error
      end
    end

    [
      '`rm -rf /`', '%x{cat /etc/passwd}', 'a = 10', 'a ||= 1', 'a &&= 1',
      'cart_total += 50', 'items << new_item', 'items.push(1)', 'items.freeze',
      'user.role', 'user.role == Process', 'Math.sqrt(x)', 'File', '::Object',
      'system("ls")', 'exec("whoami")', 'File.delete("secret.txt")',
      'File.read("/etc/hosts")', 'Net::HTTP.get(uri)', 'eval("2 + 2")',
      'user.send(:exit)', 'order.destroy!', 'users.delete_all', 'user.save!',
      'items.pop', 'items.shift', 'while true; end', 'until false; end',
      'for x in [1,2]; end', 'loop { 1 }', 'sleep(5)', 'def exploit; 1; end',
      'class Exploit; end', 'items.map { 1 }', 'self', '@value', '$global',
      '1; 2', 'false && items.push(1)', '2 ** 1000000000', '1 << 1000000',
      '"#{items.push(1)}"', '/expensive/', '%q{string}', 'items[0, 2]',
      '{**user}', '[*items]', 'items.length(1)', 'value&.size', 'value::size'
    ].each do |expression|
      it "rejects unsupported expression #{expression}" do
        expect { described_class.validate!(expression) }.to raise_error(SecurityError, /forbidden/)
      end
    end

    it 'rejects invalid syntax' do
      expect { described_class.validate!('1 +') }.to raise_error(ArgumentError, /syntax/)
    end

    it 'bounds the raw expression before stripping or parsing' do
      expect { described_class.validate!('a + ' * 100) }.to raise_error(SecurityError, /too long/)
      expect { described_class.validate!(' ' * 257) }.to raise_error(SecurityError, /too long/)
      expect { described_class.validate!('"' + ("\u00e9" * 128) + '"') }.to raise_error(SecurityError, /too long/)
    end

    it 'bounds AST depth and nodes' do
      expect { described_class.validate!('(' * 40 + '1' + ')' * 40) }.to raise_error(SecurityError, /complexity/)
      expect { described_class.validate!((['1'] * 100).join('+')) }.to raise_error(SecurityError, /complexity/)
    end

    it 'accepts empty inputs and retains the cache reset entry point' do
      expect(described_class.validate!(nil)).to be_nil
      expect(described_class.validate!(' ')).to be_nil
      expect { described_class.reset_cache! }.not_to raise_error
    end
  end
end
