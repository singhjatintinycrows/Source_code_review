# frozen_string_literal: true

require 'spec_helper'

RSpec.describe 'Restricted probe expressions' do
  let(:evaluator) { HyperProbe::Core::Evaluator }

  def watch(expression, context)
    HyperProbe::Core::Evaluator.evaluate_watches([expression], context).fetch(expression)
  end

  it 'never evaluates Ruby or invokes implicit application getters' do
    state = []
    receiver = Object.new
    receiver.define_singleton_method(:dangerous) { state << :called }
    context = receiver.instance_eval { binding }
    context.define_singleton_method(:eval) { |*| state << :eval; raise 'eval called' }
    context.define_singleton_method(:local_variable_get) { |*| state << :get; raise 'get called' }
    context.define_singleton_method(:local_variable_defined?) { |*| state << :defined; true }
    context.local_variable_set(:amount, 3)

    expect(watch('amount * 2 + 1', context)).to eq(7)
    expect(watch('dangerous', context)).to include('Error: NameError')
    expect(watch('dangerous()', context)).to include('Error: SecurityError')
    expect(state).to eq([])
  end

  it 'rejects mutation, freezing, and getters without changing application state' do
    items = [1]
    optional = nil
    state = []
    user = Object.new
    user.define_singleton_method(:role) { state << :getter; 'admin' }
    context = binding

    ['optional ||= 10', 'items.push(2)', 'items.freeze', 'items[0] = 3',
     'user.role', 'false && items.push(2)'].each do |expression|
      expect(watch(expression, context)).to include('Error: SecurityError')
    end
    expect(optional).to be_nil
    expect(items).to eq([1])
    expect(items).not_to be_frozen
    expect(state).to eq([])
  end

  it 'does not dispatch custom operators, conversions, reflection, or inspect' do
    state = []
    hostile = Object.new
    %i[+ == ! coerce to_f to_s to_str inspect class is_a? length size [] dup freeze].each do |method|
      hostile.define_singleton_method(method) { |*| state << method; raise 'application hook' }
    end
    context = binding

    ['hostile + 1', '1 + hostile', 'hostile == 1', 'hostile.length', 'hostile[0]'].each do |expression|
      expect(watch(expression, context)).to include('Error: SecurityError')
    end
    expect(evaluator.eval_condition('hostile', context)).to be true
    expect(evaluator.eval_condition('!hostile', context)).to be false
    expect(evaluator.coerce_metric_value(hostile)).to be_nil
    expect { evaluator.normalize_correlation_value(hostile) }.to raise_error(TypeError)
    expect(evaluator.evaluate_log_template('${hostile}', context)).to include('<Error: SecurityError')
    expect(state).to eq([])
  end

  it 'bypasses singleton overrides on exact builtin containers and strings' do
    state = []
    text = String.new('abc')
    items = [text]
    data = { key: text }
    [text, items, data].each do |value|
      %i[[] length size class is_a? dup clone freeze inspect to_s hash eql?].each do |method|
        value.define_singleton_method(method) { |*| state << method; raise 'application hook' }
      end
    end
    text.define_singleton_method(:initialize_copy) { |*| state << :copy; raise 'copy hook' }
    data.define_singleton_method(:each_pair) { |*| state << :each; raise 'each hook' }
    context = binding

    expect(watch('items[0][1]', context)).to eq('b')
    expect(watch('data[:key].size', context)).to eq(3)
    expect(watch('items.length + data.length', context)).to eq(2)
    expect(watch('text + "d"', context)).to eq('abcd')
    expect(evaluator.evaluate_log_template('${items}', context)).to eq('["abc"]')
    expect(evaluator.evaluate_correlation('text', context)).to eq('abc')
    expect(state).to eq([])
    expect(Object.instance_method(:frozen?).bind(text).call).to be false
  end

  it 'rejects subclasses instead of invoking overridden methods' do
    state = []
    array_type = Class.new(Array) { define_method(:[]) { |*| state << :lookup } }
    string_type = Class.new(String) { define_method(:to_f) { state << :convert } }
    items = array_type.new([1])
    text = string_type.new('123')
    context = binding

    expect(watch('items[0]', context)).to include('Error: SecurityError')
    expect(evaluator.coerce_metric_value(text)).to be_nil
    expect(state).to eq([])
  end

  it 'rejects fake bindings without invoking their methods' do
    state = []
    fake = Object.new
    %i[eval local_variable_get local_variable_defined? class is_a?].each do |method|
      fake.define_singleton_method(method) { |*| state << method; true }
    end
    expect { evaluator.eval_condition('true', fake) }.to raise_error(SecurityError, /Binding/)
    expect(state).to eq([])
  end

  it 'never invokes hash defaults or stored key hash/eql? hooks' do
    state = []
    defaults = Hash.new { |hash, key| state << :default; hash[key] = 1 }
    key = Object.new
    key.define_singleton_method(:hash) { 0 }
    key.define_singleton_method(:eql?) { |*| state << :eql; false }
    custom_keys = { key => 1 }
    key.define_singleton_method(:hash) { state << :hash; 0 }
    context = binding

    expect(watch('defaults[:missing]', context)).to be_nil
    expect(watch('custom_keys[:missing]', context)).to include('Error: SecurityError')
    expect(defaults).to be_empty
    expect(state).to eq([])
  end

  it 'supports primitive lookups, arithmetic, comparisons, and short circuiting' do
    data = { 'total' => [3, 9], enabled: true }
    context = binding
    {
      'data["total"][-1] / 3 + 2 * 4' => 11,
      'data[:enabled] && data["total"].size == 2' => true,
      'false && missing' => false,
      'true || missing' => true,
      'nil || 4' => 4,
      'true ? 7 : missing' => 7,
      '-3 + +2' => -1,
      '7 % 4' => 3,
      '2 == 2.0 && "a" < "b"' => true,
      '{key: ["hello", 2]}[:key][0][1]' => 'e',
      'data["absent"]' => nil,
      '[1][999999999999999999999999]' => nil
    }.each do |expression, expected|
      expect(watch(expression, context)).to eq(expected)
    end
    expect(data).to eq({ 'total' => [3, 9], enabled: true })
  end

  it 'rejects hash key semantics that a primitive value scan cannot preserve' do
    data = {}.compare_by_identity
    data[String.new('key')] = 1
    nan = Float::NAN
    context = binding
    expect(watch('data["key"]', context)).to include('Error: SecurityError: Identity hash')
    expect(watch('{nan => 1}[nan]', context)).to include('Error: SecurityError: Hash keys must be finite')
  end

  it 'bounds numeric and string computations before expensive operations' do
    text = 'a' * 3000
    huge = 1 << 2048
    number = 1 << 800
    data = (1..129).to_h { |i| [i, i] }
    context = binding
    ['2 ** 1000000000', '"x" * 1000000000', '[1] * 1000000000',
     'text + text', 'huge + 1', 'number * number', '1e308 * 1e308',
     'data[1]'].each do |expression|
      expect(watch(expression, context)).to include('Error: SecurityError')
    end
    expect(watch('1 / 0', context)).to include('Error: ZeroDivisionError')
    expect(text.length).to eq(3000)
    expect(data.length).to eq(129)
  end

  it 'bounds application strings and symbols before conversion or rendering' do
    text = 'x' * 4097
    symbol = text.to_sym
    context = binding
    expect(watch('text', context)).to include('Error: SecurityError')
    expect(watch('symbol', context)).to include('Error: SecurityError')
    expect(evaluator.evaluate_log_template('${symbol}', context)).to include('<Error: SecurityError')
    expect { evaluator.normalize_correlation_value(text) }.to raise_error(SecurityError)
    expect { evaluator.coerce_metric_value(text) }.to raise_error(SecurityError)
  end

  it 'uses bounded trusted copies of expression strings and watch arrays' do
    state = []
    expression = String.new('1 + 2')
    %i[strip bytesize byteslice dup hash eql?].each do |method|
      expression.define_singleton_method(method) { |*| state << method; raise 'expression hook' }
    end
    watches = [expression]
    %i[each length []].each do |method|
      watches.define_singleton_method(method) { |*| state << method; raise 'watch hook' }
    end
    expect(evaluator.evaluate_watches(watches, binding)).to eq({ '1 + 2' => 3 })
    expect { evaluator.evaluate_watches(['1'] * 129, binding) }.to raise_error(SecurityError, /Too many/)
    expect(state).to eq([])
  end

  it 'enforces a shared step budget for repeated bounded hash scans' do
    data = (1..128).to_h { |i| [i, i] }
    context = binding
    expect(watch((['data[128]'] * 5).join('+'), context)).to include('Error: SecurityError: Expression step limit')
  end

  it 'copies and freezes correlations without freezing or retaining the source' do
    source = String.new('request-123')
    result = evaluator.normalize_correlation_value(source)
    expect(result).to be_frozen
    expect(result).not_to equal(source)
    expect(source).not_to be_frozen
    source.replace('changed')
    expect(result).to eq('request-123')
    expect(evaluator.normalize_correlation_value(12.0)).to eq('12')
    expect(evaluator.normalize_correlation_value(Float::NAN)).to eq('NaN')
    expect(evaluator.normalize_correlation_value(Float::INFINITY)).to eq('Infinity')
  end

  it 'parses nested braces and quoted delimiters in both placeholder styles' do
    item = 'Widget'
    context = binding
    template = 'bare {item}: ${ {key: ["}", "{"]}[:key][0] } #{item} ${"a\\"}b"}'
    expect(evaluator.evaluate_log_template(template, context)).to eq('bare {item}: } Widget a"}b')
    expect(evaluator.evaluate_log_template('${{a: {b: 3}}[:a][:b]}', context)).to eq('3')
    expect(evaluator.evaluate_log_template("\u00e9 ${item}", context)).to eq("\u00e9 Widget")
    expect(evaluator.evaluate_log_template('${"a\\nb"}', context)).to eq("a\nb")
    expect(evaluator.evaluate_log_template("${'a\\nb'}", context)).to eq('a\\nb')
  end

  it 'captures malformed placeholders and preserves ordinary braces' do
    context = binding
    expect(evaluator.evaluate_log_template('{literal} {1 + 2}', context)).to eq('{literal} {1 + 2}')
    expect(evaluator.evaluate_log_template('value ${1 +', context)).to include('<Error: ArgumentError: Unterminated')
    expect(evaluator.evaluate_log_template('${1 / 0} ${2 + 3}', context)).to include('<Error: ZeroDivisionError', ' 5')
  end

  it 'bounds template work, output, and cyclic containers' do
    cyclic = []
    cyclic << cyclic
    text = 'a' * 4000
    context = binding
    expect(evaluator.evaluate_log_template('${cyclic}', context)).to include('<Error: SecurityError')
    expect { evaluator.evaluate_log_template('x' * 16_385, context) }.to raise_error(SecurityError, /too long/)
    expect { evaluator.evaluate_log_template('${1}' * 33, context) }.to raise_error(SecurityError, /placeholders/)
    expect(evaluator.evaluate_log_template('${text}' * 5, context)).to include('<Error: SecurityError: Log output')
    expect(cyclic[0]).to equal(cyclic)
  end
end
