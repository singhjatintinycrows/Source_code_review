# frozen_string_literal: true

require 'spec_helper'

RSpec.describe HyperProbe::Lambda do
  let(:valid_opts) do
    {
      service_id: '11111111-2222-4333-8444-555555555555',
      environment: 'production',
      broker_url: 'broker.hyperprobe.co:443',
      commit_sha: 'lambda-sha-12345',
      is_lambda: true
    }
  end

  before do
    allow_any_instance_of(HyperProbe::Core::BrokerClient).to receive(:get_probes).and_return(
      Hyperprobe::Agent::V1::GetProbesResponse.new(probes: [], next_sync_interval_ms: 60_000)
    )
    allow_any_instance_of(HyperProbe::Core::BrokerClient).to receive(:report_telemetry).and_return([])
  end

  after do
    HyperProbe.shutdown
  end

  it 'wraps lambda handler and executes successfully' do
    handler = ->(event:, context:) { { status: 200, received: event[:key] } }
    wrapped = described_class.wrap(valid_opts, &handler)

    context = double('LambdaContext', get_remaining_time_in_millis: 5000)
    result = wrapped.call(event: { key: 'hello' }, context: context)

    expect(result[:status]).to eq(200)
    expect(result[:received]).to eq('hello')
  end

  it 'supports positional (event, context) lambda handlers without ArgumentError' do
    handler = ->(event, context) { { status: 200, event: event, context: context } }
    wrapped = described_class.wrap(valid_opts, &handler)

    context = double('LambdaContext', get_remaining_time_in_millis: 5000)
    result = wrapped.call(event: { key: 'positional' }, context: context)

    expect(result[:status]).to eq(200)
    expect(result[:event]).to eq({ key: 'positional' })
    expect(result[:context]).to eq(context)
  end

  it 'supports single-argument (event) lambda handlers' do
    handler = ->(event) { { status: 200, event: event } }
    wrapped = described_class.wrap(valid_opts, &handler)

    context = double('LambdaContext', get_remaining_time_in_millis: 5000)
    result = wrapped.call(event: { key: 'single' }, context: context)

    expect(result[:status]).to eq(200)
    expect(result[:event]).to eq({ key: 'single' })
  end

  it 'does not double-invoke handler when handler internally raises an ArgumentError' do
    call_count = 0
    handler = ->(event, _context) do
      call_count += 1
      raise ArgumentError, 'internal application argument error'
    end

    wrapped = described_class.wrap(valid_opts, &handler)
    context = double('LambdaContext', get_remaining_time_in_millis: 5000)

    expect {
      wrapped.call(event: { key: 'test' }, context: context)
    }.to raise_error(ArgumentError, 'internal application argument error')

    expect(call_count).to eq(1)
  end
end
