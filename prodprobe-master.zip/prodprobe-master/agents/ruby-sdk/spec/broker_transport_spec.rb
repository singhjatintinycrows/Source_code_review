# frozen_string_literal: true

require 'rspec'
require 'open3'
require 'tmpdir'
require 'json'
require 'socket'
$LOAD_PATH.unshift ENV.fetch('HYPERPROBE_TEST_LIB', File.expand_path('../lib', __dir__))
require 'hyperprobe/core/broker'

RSpec.describe HyperProbe::Core::BrokerClient do
  before(:all) do
    mri = ENV.fetch('HYPERPROBE_MRI_RUBY', RUBY_PLATFORM.match?(/java/) ? 'ruby' : RbConfig.ruby)
    @server_in, @server_out, @server_thread = Open3.popen2(
      { 'RUBYOPT' => nil, 'BUNDLE_GEMFILE' => nil, 'GEM_HOME' => nil, 'GEM_PATH' => nil },
      mri, File.expand_path('support/broker_server.rb', __dir__)
    )
    raise 'Local MRI gRPC server did not start in 20 seconds' unless IO.select([@server_out], nil, nil, 20)
    line = @server_out.gets
    raise 'Local MRI gRPC server exited before ready' unless line
    @peer = JSON.parse(line)
    @tls_dir = Dir.mktmpdir('hyperprobe-broker-tls')
    File.write(File.join(@tls_dir, 'ca.pem'), @peer.fetch('certificate'))
    if RUBY_PLATFORM.match?(/java/)
      trust_store = File.join(@tls_dir, 'trust.p12')
      output, status = Open3.capture2e('keytool', '-importcert', '-noprompt', '-alias', 'broker',
                                      '-file', File.join(@tls_dir, 'ca.pem'), '-keystore', trust_store,
                                      '-storepass', 'test-only-password', '-storetype', 'PKCS12')
      raise output unless status.success?
      @old_trust_store = java.lang.System.getProperty('javax.net.ssl.trustStore')
      @old_trust_password = java.lang.System.getProperty('javax.net.ssl.trustStorePassword')
      java.lang.System.setProperty('javax.net.ssl.trustStore', trust_store)
      java.lang.System.setProperty('javax.net.ssl.trustStorePassword', 'test-only-password')
    end
  end

  after(:all) do
    @server_in&.close
    @server_out&.close
    if @server_thread && !@server_thread.join(5)
      Process.kill('KILL', @server_thread.pid)
      @server_thread.join
    end
    if RUBY_PLATFORM.match?(/java/) && @tls_dir
      { 'javax.net.ssl.trustStore' => @old_trust_store,
        'javax.net.ssl.trustStorePassword' => @old_trust_password }.each do |key, value|
        value ? java.lang.System.setProperty(key, value) : java.lang.System.clearProperty(key)
      end
    end
    FileUtils.remove_entry(@tls_dir) if @tls_dir
  end

  after do
    @clients&.each(&:shutdown)
  end

  def client(service_id: 'service', url: nil, **options)
    @clients ||= []
    @clients << described_class.new(
      broker_url: url || "127.0.0.1:#{@peer.fetch('plain_port')}", service_id: service_id,
      environment: 'test', commit_sha: 'commit', agent_id: 'agent', agent_version: '1.2.3', **options
    )
    @clients.last
  end

  def expect_status(code, &block)
    expect(&block).to raise_error(StandardError) { |error| expect(error.code).to eq(code) }
  end

  def trust_local_certificate
    return if RUBY_PLATFORM.match?(/java/)

    allow(GRPC::Core::ChannelCredentials).to receive(:new).and_wrap_original do |original, *_args|
      original.call(@peer.fetch('certificate'))
    end
  end

  it 'preserves protocol fields, raw host:port and service metadata longer than 255 bytes' do
    broker = client(service_id: 's' * 300)
    response = broker.get_probes
    expect(response.next_sync_interval_ms).to eq(1234)
    expect(JSON.parse(response.probes.first.template)).to include(
      'agentId' => 'agent', 'serviceId' => 's' * 300, 'environment' => 'test', 'commitSha' => 'commit',
      'agentVersion' => '1.2.3', 'language' => RUBY_PLATFORM.match?(/java/) ? 'jruby' : 'ruby'
    )
  end

  it 'supports explicit HTTP prior-knowledge gRPC' do
    expect(client(url: "http://127.0.0.1:#{@peer.fetch('plain_port')}").get_probes.probes.size).to eq(1)
  end

  it 'supports verified HTTPS with ALPN' do
    trust_local_certificate
    expect(client(url: "https://localhost:#{@peer.fetch('tls_port')}").get_probes.probes.size).to eq(1)
  end

  it 'rejects a TLS certificate for the wrong hostname' do
    trust_local_certificate
    expect_status(14) { client(url: "https://127.0.0.1:#{@peer.fetch('tls_port')}").get_probes(1) }
  end

  ["http", "https"].each do |scheme|
    it "round-trips requests and responses over 64 KiB using #{scheme}" do
      trust_local_certificate if scheme == 'https'
      port = @peer.fetch(scheme == 'https' ? 'tls_port' : 'plain_port')
      broker = client(url: "#{scheme}://localhost:#{port}")
      payload = 'large-value-' * 32_768
      result = broker.report_telemetry([{ probe_id: 'p1', captured_vars_json: payload,
                                          trace_id: 'trace', stack_frames: [{ function_name: 'checkout', line_number: 42 }] }])
      expect(result.first).to eq('agent')
      event = JSON.parse(result.last)
      expect(event).to include('probeId' => 'p1', 'capturedVarsJson' => payload, 'traceId' => 'trace')
      expect(event.fetch('stackFrames').first).to include('functionName' => 'checkout', 'lineNumber' => 42)
    end
  end

  { 'denied' => 7, 'unavailable' => 14, 'data-error' => 7 }.each do |mode, code|
    it "propagates terminal status for #{mode}, including after a valid DATA message" do
      expect_status(code) { client(service_id: mode).get_probes }
    end
  end

  it 'waits for terminal error trailers over HTTPS too' do
    trust_local_certificate
    broker = client(service_id: 'data-error', url: "https://localhost:#{@peer.fetch('tls_port')}")
    expect_status(7) { broker.get_probes }
  end

  %w[slow data-delay].each do |mode|
    it "enforces the deadline for #{mode}, even after receiving a complete protobuf" do
      broker = client(service_id: mode)
      broker.report_telemetry([{ probe_id: 'warm-up' }])
      started = Process.clock_gettime(Process::CLOCK_MONOTONIC)
      expect_status(4) { broker.get_probes(0.15) }
      expect(Process.clock_gettime(Process::CLOCK_MONOTONIC) - started).to be < 1.0
    end
  end

  %w[http https].each do |scheme|
    it "bounds #{scheme} connection/handshake waits against a silent peer" do
      socket = TCPServer.new('127.0.0.1', 0)
      broker = client(url: "#{scheme}://127.0.0.1:#{socket.addr[1]}")
      started = Process.clock_gettime(Process::CLOCK_MONOTONIC)
      expect_status(4) { broker.get_probes(0.2) }
      expect(Process.clock_gettime(Process::CLOCK_MONOTONIC) - started).to be < 1.5
    ensure
      socket&.close
    end
  end

  it 'starts the deadline before constructing the telemetry request' do
    broker = client
    allow(broker).to receive(:build_telemetry_event_proto).and_wrap_original do |original, event|
      sleep 0.05
      original.call(event)
    end
    expect_status(4) { broker.report_telemetry([{ probe_id: 'p' }], 0.01) }
  end

  it 'rejects oversized inbound messages instead of growing memory without a limit' do
    expect_status(8) { client(service_id: 'oversized').get_probes }
  end

  it 'cancels an in-flight RPC and shuts down idempotently without waiting for its deadline' do
    broker = client(service_id: 'slow')
    broker.report_telemetry([{ probe_id: 'warm-up' }])
    worker = Thread.new do
      broker.get_probes(10)
    rescue StandardError => e
      e
    end
    sleep 0.1
    started = Process.clock_gettime(Process::CLOCK_MONOTONIC)
    broker.shutdown
    broker.shutdown
    expect(worker.join(1)).not_to be_nil
    expect(worker.value).to be_a(StandardError)
    expect(Process.clock_gettime(Process::CLOCK_MONOTONIC) - started).to be < 1.5
    expect { broker.get_probes(0.1) }.to raise_error(StandardError)
  ensure
    worker&.kill if worker&.alive?
  end

  [0, -1, Float::INFINITY, Float::NAN].each do |timeout|
    it "rejects unbounded or invalid timeout #{timeout.inspect}" do
      expect { client(rpc_timeout_sec: timeout) }.to raise_error(ArgumentError)
      expect { client.get_probes(timeout) }.to raise_error(ArgumentError)
      expect { client.report_telemetry([{ probe_id: 'p' }], timeout) }.to raise_error(ArgumentError)
    end
  end

  it 'does not perform an RPC for an empty telemetry batch' do
    expect(client.report_telemetry([])).to eq([])
  end
end
