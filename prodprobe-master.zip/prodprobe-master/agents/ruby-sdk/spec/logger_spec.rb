# frozen_string_literal: true

require 'spec_helper'
require 'stringio'

RSpec.describe HyperProbe::Core::Logger do
  before do
    described_class.reset_cache!
  end

  after do
    described_class.reset_cache!
  end

  describe '.is_namespace_enabled?' do
    it 'matches exact namespace' do
      expect(described_class.is_namespace_enabled?('hyperprobe:agent', 'hyperprobe:agent')).to be true
      expect(described_class.is_namespace_enabled?('hyperprobe:broker', 'hyperprobe:agent')).to be false
    end

    it 'matches wildcard namespaces' do
      expect(described_class.is_namespace_enabled?('hyperprobe:agent', 'hyperprobe:*')).to be true
      expect(described_class.is_namespace_enabled?('hyperprobe:broker', 'hyperprobe:*')).to be true
      expect(described_class.is_namespace_enabled?('hyperprobe:agent', 'hyperprobe*')).to be true
      expect(described_class.is_namespace_enabled?('hyperprobe:safety', 'hyperprobe*')).to be true
      expect(described_class.is_namespace_enabled?('other:agent', 'hyperprobe:*')).to be false
      expect(described_class.is_namespace_enabled?('hyperprobe:agent', '*')).to be true
    end

    it 'respects namespace exclusions with - prefix' do
      pattern = 'hyperprobe:*,-hyperprobe:stats'
      expect(described_class.is_namespace_enabled?('hyperprobe:agent', pattern)).to be true
      expect(described_class.is_namespace_enabled?('hyperprobe:stats', pattern)).to be false
    end

    it 'handles comma and whitespace separated selectors' do
      pattern = 'hyperprobe:agent, hyperprobe:broker  demo:*'
      expect(described_class.is_namespace_enabled?('hyperprobe:agent', pattern)).to be true
      expect(described_class.is_namespace_enabled?('hyperprobe:broker', pattern)).to be true
      expect(described_class.is_namespace_enabled?('demo:app', pattern)).to be true
      expect(described_class.is_namespace_enabled?('other:service', pattern)).to be false
    end
  end

  describe 'Instance Logging' do
    it 'only writes debug logs when namespace is enabled' do
      allow(ENV).to receive(:[]).and_call_original
      allow(ENV).to receive(:[]).with('DEBUG').and_return('hyperprobe:agent')

      enabled_logger = described_class.new('hyperprobe:agent')
      disabled_logger = described_class.new('hyperprobe:broker')

      expect(enabled_logger.debug_enabled?).to be true
      expect(disabled_logger.debug_enabled?).to be false

      # Capture stdout
      out = StringIO.new
      $stdout = out
      begin
        enabled_logger.debug('Agent started')
        disabled_logger.debug('Broker connecting')
      ensure
        $stdout = STDOUT
      end

      log_output = out.string
      expect(log_output).to include('Agent started')
      expect(log_output).not_to include('Broker connecting')
    end

    it 'always writes force_info and force_error regardless of DEBUG gate' do
      allow(ENV).to receive(:[]).and_call_original
      allow(ENV).to receive(:[]).with('DEBUG').and_return(nil)

      logger = described_class.new('hyperprobe:silent')
      expect(logger.debug_enabled?).to be false

      out = StringIO.new
      err = StringIO.new
      $stdout = out
      $stderr = err
      begin
        logger.force_info('Critical system status')
        logger.force_error('Critical failure')
      ensure
        $stdout = STDOUT
        $stderr = STDERR
      end

      expect(out.string).to include('Critical system status')
      expect(err.string).to include('Critical failure')
    end

    it 'caches logger instances per namespace' do
      log1 = described_class.get_logger('hyperprobe:cache_test')
      log2 = described_class.get_logger('hyperprobe:cache_test')
      expect(log1).to equal(log2)
    end
  end
end
