# frozen_string_literal: true

require 'rspec'
require 'open3'
require 'ripper'
require 'shellwords'
require 'timeout'
require 'pty' if RUBY_ENGINE == 'ruby'

RSpec.describe 'Ruby release integration (offline source checks)' do
  let(:sdk_dir) { File.expand_path('..', __dir__) }
  let(:root_dir) { File.expand_path('../..', sdk_dir) }
  let(:build) { File.read(File.join(root_dir, 'build.sh')) }
  let(:publisher) { File.read(File.join(sdk_dir, 'publish_rubygems.sh')) }
  let(:readme) { File.read(File.join(sdk_dir, 'README.md')) }

  it 'keeps both release scripts valid Bash without executing either' do
    [File.join(root_dir, 'build.sh'), File.join(sdk_dir, 'publish_rubygems.sh')].each do |path|
      _stdout, stderr, status = Open3.capture3('bash', '-n', path)
      expect(status.success?).to be(true), stderr
    end
  end

  def confirmation_script(assume_yes: false)
    confirmation = publisher[/^# 8\. Confirmation prompt\n(.*?)^# 9\. Push to RubyGems/m, 1]
    expect(confirmation).not_to be_nil
    <<~BASH
      set -Eeuo pipefail
      ASSUME_YES=#{assume_yes}
      EXPECTED_GEM_NAME=hyperprobe-agent
      CURRENT_VERSION=test-only
      PKG_DIR=/unused-test-artifacts
      fail() { printf '%s\n' "$*" >&2; exit 1; }
      info() { printf '%s\n' "$*"; }
      #{confirmation}
      printf 'CONFIRMATION_ACCEPTED\n'
    BASH
  end

  it 'requires explicit approval and explains how to retry when stdin is closed' do
    stdout, stderr, status = Open3.capture3('bash', '-c', confirmation_script, stdin_data: '')
    expect(status.success?).to be(false)
    expect(stdout).not_to include('CONFIRMATION_ACCEPTED')
    expect(stderr).to include('--yes')
  end

  it 'preserves piped approval and cancellation' do
    stdout, stderr, status = Open3.capture3('bash', '-c', confirmation_script, stdin_data: "yes\n")
    expect(status.success?).to be(true), stderr
    expect(stdout).to include('CONFIRMATION_ACCEPTED')
    stdout, stderr, status = Open3.capture3('bash', '-c', confirmation_script, stdin_data: "no\n")
    expect(status.success?).to be(true), stderr
    expect(stdout).to include('Publishing canceled')
    expect(stdout).not_to include('CONFIRMATION_ACCEPTED')
  end

  it 'bypasses the input prompt only with explicit --yes authorization' do
    stdout, stderr, status = Open3.capture3('bash', '-c', confirmation_script(assume_yes: true), stdin_data: '')
    expect(status.success?).to be(true), stderr
    expect(stdout).to include('CONFIRMATION_ACCEPTED')
    expect(stdout).not_to include('Ready to publish')
  end

  it 'reads approval from a terminal even when a child left stdin nonblocking', if: RUBY_ENGINE == 'ruby' do
    nonblocking = "#{Shellwords.escape(RbConfig.ruby)} -rfcntl -e 'STDIN.fcntl(Fcntl::F_SETFL, STDIN.fcntl(Fcntl::F_GETFL) | Fcntl::O_NONBLOCK)'"
    output = +''
    child = nil
    status = nil
    PTY.spawn('bash', '-c', "#{nonblocking}\n#{confirmation_script}") do |reader, writer, pid|
      child = pid
      Timeout.timeout(5) do
        output << reader.readpartial(1024) until output.include?('Do you want to proceed')
        sleep 0.05
        writer.puts('yes')
        begin
          loop { output << reader.readpartial(1024) }
        rescue EOFError, Errno::EIO
          # PTYs signal end-of-output differently across platforms.
        end
        _, status = Process.wait2(pid)
        child = nil
      end
    end
    expect(status.success?).to be(true), output
    expect(output).to include('CONFIRMATION_ACCEPTED')
    expect(output).not_to include('Resource temporarily unavailable')
  ensure
    if child
      Process.kill('KILL', child) rescue nil
      Process.wait(child) rescue nil
    end
  end

  it 'requires a clean worktree and both toolchains before Ruby mutations and validation' do
    stages = [
      'DIRTY_WORKTREE="$(git status --porcelain)"',
      "\nverify_ruby_build_prerequisites\n",
      "\nRUBY_RELEASE_FILES_TOUCHED=1\n",
      'VERSION="$RUBY_VERSION" node -e',
      '(cd agents/ruby-sdk && bundle install >/dev/null 2>&1)',
      '(cd agents/ruby-sdk && bash publish_rubygems.sh --dry-run)'
    ]
    offsets = stages.map { |stage| build.index(stage) }
    expect(offsets).not_to include(nil)
    expect(offsets).to eq(offsets.sort)
    expect(build).to include("RUBY_RELEASE_FILES_TOUCHED=0\n")
    expect(publisher.index('bundle exec rake build')).to be < publisher.index('bundle exec rspec')
    expect(publisher).to include('"$JRUBY_BIN" --debug',
                                 '-J-Djruby.ir.passes=AddCallProtocolInstructions,AddMissingInitsPass',
                                 '-J-Djruby.ir.jit.passes=AddCallProtocolInstructions,AddMissingInitsPass -S rspec',
                                 'for BUILT_GEM in "${BUILT_GEMS[@]}"')
  end

  it 'checks every dual-platform tool and honors the JRuby executable override' do
    preflight = build[/^verify_ruby_build_prerequisites\(\) \{\n.*?^\}/m]
    expect(preflight).not_to be_nil
    script = <<~BASH
      set -e
      require_command() { printf '%s\n' "$1"; }
      fail() { printf '%s\n' "$*" >&2; exit 1; }
      ruby() { return 0; }
      test_jruby() { return 0; }
      HYPERPROBE_JRUBY=test_jruby
      #{preflight}
      verify_ruby_build_prerequisites
    BASH
    stdout, stderr, status = Open3.capture3('bash', '-c', script)
    expect(status.success?).to be(true), stderr
    expect(stdout.lines.map(&:strip)).to include('ruby', 'gem', 'bundle', 'mvn', 'java', 'javac', 'test_jruby')
    expect(preflight).to include('RUBY_ENGINE == "ruby"', 'Gem::Version.new("3.0")', 'Gem::Version.new("9.4")')
    expect(preflight).to include('"java.specification.version").to_i >= 11', 'require "rspec"', 'require "google/protobuf"')
  end

  %w[ruby test_jruby].each do |failed_runtime|
    it "fails closed without printing #{failed_runtime} preflight output" do
      preflight = build[/^verify_ruby_build_prerequisites\(\) \{\n.*?^\}/m]
      script = <<~BASH
        require_command() { return 0; }
        fail() { printf '%s\n' "$*" >&2; exit 1; }
        ruby() { return 0; }
        test_jruby() { return 0; }
        #{failed_runtime}() { printf 'credential-canary\n' >&2; return 1; }
        HYPERPROBE_JRUBY=test_jruby
        #{preflight}
        verify_ruby_build_prerequisites
      BASH
      stdout, stderr, status = Open3.capture3('bash', '-c', script)
      expect(status.success?).to be(false)
      expect(stderr).to include('Ruby releases require')
      expect(stdout + stderr).not_to include('credential-canary')
    end
  end

  [0, 1].each do |install_status|
    it "suppresses Bundler output and preserves install status #{install_status}" do
      install = build[/^\(cd agents\/ruby-sdk && bundle install.*?\n  fail [^\n]+/m]
      expect(install).not_to be_nil
      script = <<~BASH
        bundle() { printf 'credential-canary\n'; printf 'credential-canary\n' >&2; return #{install_status}; }
        fail() { printf '%s\n' "$*" >&2; exit 1; }
        #{install}
      BASH
      stdout, stderr, status = Open3.capture3('bash', '-c', script, chdir: root_dir)
      expect(status.exitstatus).to eq(install_status)
      expect(stdout + stderr).not_to include('credential-canary')
      expect(stderr).to include('Ruby bundle install failed') unless install_status.zero?
    end
  end

  [[0, 1], [0, 0], [7, 1]].each do |exit_code, touched|
    it "scopes Ruby cleanup for exit #{exit_code}, touched #{touched}, without running git" do
      cleanup = build[/^cleanup_and_rollback\(\) \{\n.*?^\}/m]
      expect(cleanup).not_to be_nil
      script = <<~BASH
        git() { printf 'FAKE_GIT %s\n' "$*"; }
        find() { return 0; }
        ROOT_DIR=#{Shellwords.escape(sdk_dir)}
        SHOULD_PUBLISH=no
        RUBY_RELEASE_FILES_TOUCHED=#{touched}
        #{cleanup}
        (exit #{exit_code})
        cleanup_and_rollback
      BASH
      stdout, stderr, status = Open3.capture3('bash', '-c', script)
      expect(status.exitstatus).to eq(exit_code), stderr
      ruby_restores = stdout.lines.select { |line| line.start_with?('FAKE_GIT ') && line.include?('agents/ruby-sdk') }
      expected = if exit_code.zero? && touched == 1
                   ["FAKE_GIT restore -- agents/ruby-sdk/lib/hyperprobe/version.rb agents/ruby-sdk/Gemfile.lock\n"]
                 else
                   []
                 end
      expect(ruby_restores).to eq(expected)
    end
  end

  it 'contains parseable Ruby examples and a real Lambda handler method' do
    examples = readme.scan(/^```ruby\n(.*?)^```/m).flatten
    expect(examples).not_to be_empty
    examples.each { |source| expect(Ripper.sexp(source)).not_to be_nil, source }
    expect(readme).to include('def lambda_handler(event:, context:)', 'HYPERPROBE_HANDLER.call(event: event, context: context)')
    expect(readme).not_to include('exports.handler')
  end

  it 'declares the proto compiler only for MRI development and quotes its arguments' do
    gemfile = File.read(File.join(sdk_dir, 'Gemfile'))
    gemspec = File.read(File.join(sdk_dir, 'hyperprobe-agent.gemspec'))
    rakefile = File.read(File.join(sdk_dir, 'Rakefile'))
    expect(gemfile).to match(/group :development, :test do\n.*gem 'grpc-tools'.*platforms: :mri/m)
    expect(gemspec).not_to match(/add_dependency\s+['"]grpc-tools/)
    expect(rakefile).to include("Gem.bin_path('grpc-tools', 'grpc_tools_ruby_protoc')")
    expect(rakefile).to include("sh compiler, '-I', proto_dir,")
  end
end
