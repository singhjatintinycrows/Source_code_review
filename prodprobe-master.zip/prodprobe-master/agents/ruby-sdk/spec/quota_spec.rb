# frozen_string_literal: true

require 'spec_helper'

RSpec.describe HyperProbe::Core::QuotaManager do
  describe HyperProbe::Core::TokenBucket do
    it 'allows consumption within capacity' do
      bucket = described_class.new(5, 5)
      5.times do
        expect(bucket.try_consume(1)).to be true
      end
      expect(bucket.try_consume(1)).to be false
    end

    it 'refills tokens over time' do
      bucket = described_class.new(10, 100) # 100 tokens/sec = 0.1/ms
      10.times { bucket.try_consume(1) }
      expect(bucket.try_consume(1)).to be false

      sleep 0.05 # 50ms = 5 tokens
      expect(bucket.try_consume(3)).to be true
    end

    it 'supports bandwidth reservations and releases' do
      bucket = described_class.new(100, 100)
      res = bucket.reserve(40)
      expect(res).not_to be_nil
      expect(res.tokens).to eq(40)

      # Attempting to consume remaining
      expect(bucket.try_consume(70)).to be false

      # Release reservation
      res.release
      expect(bucket.try_consume(70)).to be true
    end

    it 'does not release tokens twice if committed' do
      bucket = described_class.new(100, 0)
      res = bucket.reserve(50)
      res.commit
      res.release
      expect(bucket.try_consume(60)).to be false
    end
  end

  describe HyperProbe::Core::QuotaManager do
    let(:quota) { described_class.new(2, 500) }

    it 'governs hit rates and bandwidth' do
      expect(quota.can_evaluate?).to be true
      expect(quota.can_evaluate?).to be true
      expect(quota.can_evaluate?).to be false

      expect(quota.can_send?(300)).to be true
      expect(quota.can_send?(300)).to be false
    end
  end
end
