# frozen_string_literal: true

require 'spec_helper'

RSpec.describe 'Startup & Configuration Validation' do
  let(:valid_service_id) { '11111111-2222-4333-8444-555555555555' }
  let(:valid_opts) do
    {
      service_id: valid_service_id,
      environment: 'production',
      broker_url: 'localhost:60051',
      commit_sha: 'commit-12345678',
      is_lambda: true
    }
  end

  before do
    allow_any_instance_of(HyperProbe::Core::BrokerClient).to receive(:get_probes).and_return(
      Hyperprobe::Agent::V1::GetProbesResponse.new(probes: [], next_sync_interval_ms: 60_000)
    )
  end

  after do
    HyperProbe.shutdown
  end

  describe 'Option and Environment Variable Validation' do
    it 'accepts brokerUrl without trailing slash and rejects invalid urls' do
      expect(HyperProbe.valid_broker_url?('localhost:60051')).to be true
      expect(HyperProbe.valid_broker_url?('https://broker.hyperprobe.co:443')).to be true
      expect(HyperProbe.valid_broker_url?('http://broker.hyperprobe.co:8080')).to be true

      # Invalid cases
      expect(HyperProbe.valid_broker_url?('')).to be false
      expect(HyperProbe.valid_broker_url?(nil)).to be false
      expect(HyperProbe.valid_broker_url?('https://broker.hyperprobe.co/')).to be false # Trailing slash
      expect(HyperProbe.valid_broker_url?('https://broker.hyperprobe.co:443?query=1')).to be false # Query params
      expect(HyperProbe.valid_broker_url?('invalid://target')).to be false
    end

    it 'fails to start with invalid brokerUrl' do
      opts = valid_opts.merge(broker_url: 'https://broker.hyperprobe.co:443/')
      agent = HyperProbe.start(opts)
      expect(agent).to be_nil
    end

    it 'warns on non-UUID serviceId but starts' do
      opts = valid_opts.merge(service_id: 'non-uuid-service')
      expect { HyperProbe.start(opts) }.to output(/service_id is not a valid UUID/).to_stderr
    end

    it 'fails to start when HYPERPROBE_ENVIRONMENT is missing and not provided in options' do
      opts = valid_opts.dup
      opts.delete(:environment)
      allow(ENV).to receive(:[]).and_call_original
      allow(ENV).to receive(:[]).with('HYPERPROBE_ENVIRONMENT').and_return(nil)

      agent = nil
      expect { agent = HyperProbe.start(opts) }.to output(/HYPERPROBE_ENVIRONMENT is required/).to_stderr
      expect(agent).to be_nil
    end

    it 'accepts camelCase Node-SDK style options for full cross-SDK interoperability' do
      camel_opts = {
        serviceId: valid_service_id,
        environment: 'production',
        brokerUrl: 'localhost:60051',
        commitSha: 'commit-from-camel-case',
        flushIntervalMs: 2500,
        maxQueueSize: 50,
        hitsPerSec: 25
      }

      agent = HyperProbe.start(camel_opts)
      expect(agent).not_to be_nil
      expect(agent.instance_variable_get(:@service_id)).to eq(valid_service_id)
      expect(agent.instance_variable_get(:@environment)).to eq('production')
      expect(agent.instance_variable_get(:@broker_url)).to eq('localhost:60051')
      expect(agent.instance_variable_get(:@commit_sha)).to eq('commit-from-camel-case')
      expect(agent.instance_variable_get(:@flush_interval_sec)).to eq(2.5)
      expect(agent.instance_variable_get(:@max_queue_size)).to eq(50)
      expect(agent.instance_variable_get(:@hits_per_sec)).to eq(25)
    end

    it 'reads configuration from environment variables' do
      allow(ENV).to receive(:[]).and_call_original
      allow(ENV).to receive(:[]).with('HYPERPROBE_SERVICE_ID').and_return(valid_service_id)
      allow(ENV).to receive(:[]).with('HYPERPROBE_ENVIRONMENT').and_return('staging')
      allow(ENV).to receive(:[]).with('HYPERPROBE_BROKER_URL').and_return('localhost:60051')
      allow(ENV).to receive(:[]).with('GIT_COMMIT').and_return('commit-from-env')

      agent = HyperProbe.start
      expect(agent).not_to be_nil
      expect(HyperProbe.instance).to eq(agent)
    end
  end

  describe 'Dynamic Global Config Updates from Broker' do
    it 'updates redaction keys, values, and serialization limits dynamically' do
      agent = HyperProbe.start(valid_opts)

      global_config_proto = Hyperprobe::Agent::V1::AgentGlobalConfig.new(
        redact_keys: %w[auth_token private_key],
        redact_values: %w[super_secret_val],
        max_object_depth: 5,
        max_array_length: 10,
        stack_frame_depth: 5,
        max_object_properties: 100,
        max_string_length: 2048
      )

      mock_response = Hyperprobe::Agent::V1::GetProbesResponse.new(
        probes: [],
        global_config: global_config_proto
      )

      allow(agent.broker_client).to receive(:get_probes).and_return(mock_response)

      agent.send(:sync_with_broker)

      gc = agent.global_config
      expect(gc[:redact_keys]).to eq(%w[auth_token private_key])
      expect(gc[:redact_values]).to eq(%w[super_secret_val])
      expect(gc[:max_object_depth]).to eq(5)
      expect(gc[:max_array_length]).to eq(10)
      expect(gc[:max_object_properties]).to eq(100)
      expect(gc[:max_string_length]).to eq(2048)
    end
  end

  describe 'Safe evaluation opt-in' do
    let(:logger) { HyperProbe::Core::Logger.get_logger('hyperprobe:agent') }

    before do
      allow(ENV).to receive(:[]).and_call_original
      allow(ENV).to receive(:[]).with('HYPERPROBE_DISABLE_SAFE_EVALUATION').and_return(nil)
      allow(logger).to receive(:warn)
    end

    it 'keeps safe evaluation enabled by default without an unsafe-mode warning' do
      agent = HyperProbe.start(valid_opts)
      expect(agent.global_config[:disable_safe_evaluation]).to be(false)
      expect(logger).not_to have_received(:warn)
    end

    [true, 'true', ' TRUE '].each do |value|
      it "accepts the explicit option #{value.inspect} and warns once at startup" do
        agent = HyperProbe.start(valid_opts.merge(disable_safe_evaluation: value))
        expect(agent.global_config[:disable_safe_evaluation]).to be(true)
        expect(logger).to have_received(:warn).with(/Safe evaluation is DISABLED/).once
      end
    end

    [false, 'false', 'FALSE', '1', 'yes', 1].each do |value|
      it "does not opt in for #{value.inspect}" do
        agent = HyperProbe.start(valid_opts.merge(disable_safe_evaluation: value))
        expect(agent.global_config[:disable_safe_evaluation]).to be(false)
        expect(logger).not_to have_received(:warn)
      end
    end

    it 'accepts the shared environment variable' do
      allow(ENV).to receive(:[]).with('HYPERPROBE_DISABLE_SAFE_EVALUATION').and_return(' TRUE ')
      agent = HyperProbe.start(valid_opts)
      expect(agent.global_config[:disable_safe_evaluation]).to be(true)
      expect(logger).to have_received(:warn).with(/Safe evaluation is DISABLED/).once
    end

    it 'lets an explicit false option override the environment, like other Ruby options' do
      allow(ENV).to receive(:[]).with('HYPERPROBE_DISABLE_SAFE_EVALUATION').and_return('true')
      agent = HyperProbe.start(valid_opts.merge(disable_safe_evaluation: false))
      expect(agent.global_config[:disable_safe_evaluation]).to be(false)
      expect(logger).not_to have_received(:warn)
    end

    it 'accepts string and camelCase option keys' do
      agent = HyperProbe.start(valid_opts.merge('disableSafeEvaluation' => true))
      expect(agent.global_config[:disable_safe_evaluation]).to be(true)
    end

    it 'retains the local opt-in across broker configuration updates' do
      agent = HyperProbe.start(valid_opts.merge(disable_safe_evaluation: true))
      response = Hyperprobe::Agent::V1::GetProbesResponse.new(
        probes: [], global_config: Hyperprobe::Agent::V1::AgentGlobalConfig.new(max_object_depth: 1)
      )
      allow(agent.broker_client).to receive(:get_probes).and_return(response)
      agent.force_sync
      expect(agent.global_config[:disable_safe_evaluation]).to be(true)
      expect(logger).to have_received(:warn).with(/Safe evaluation is DISABLED/).once
    end
  end
end
