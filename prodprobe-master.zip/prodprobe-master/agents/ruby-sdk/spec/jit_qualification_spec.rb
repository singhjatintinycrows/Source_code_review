# frozen_string_literal: true

require 'spec_helper'
require 'open3'
require 'json'

if RUBY_PLATFORM.include?('java')
  RSpec.describe 'JRuby compiled capture qualification' do
    def runtime(profile: false)
      flags = ['-Djruby.jit.background=false']
      if profile
        flags += ['-Djruby.ir.passes=AddCallProtocolInstructions,AddMissingInitsPass',
                  '-Djruby.ir.jit.passes=AddCallProtocolInstructions,AddMissingInitsPass']
      end
      return [RbConfig.ruby, *flags.map { |flag| "-J#{flag}" }] unless RbConfig.ruby.start_with?('uri:')
      [File.join(java.lang.System.getProperty('java.home'), 'bin/java'),
       '--add-opens', 'java.base/sun.nio.ch=ALL-UNNAMED',
       '--add-opens', 'java.base/java.io=ALL-UNNAMED',
       *flags, '-cp', java.lang.System.getProperty('java.class.path'), 'org.jruby.Main']
    end

    let(:environment) do
      { 'JRUBY_OPTS' => nil, 'RUBYOPT' => nil, 'BUNDLE_GEMFILE' => nil,
        'JAVA_TOOL_OPTIONS' => nil, 'JDK_JAVA_OPTIONS' => nil, '_JAVA_OPTIONS' => nil,
        'DEBUG' => nil, 'HYPERPROBE_JIT_SDK' => 'YES' }
    end

    it 'captures correct bindings after a warmed method is JIT compiled and probes are reinstalled' do
      stdout, stderr, status = Open3.capture3(environment, *runtime(profile: true), '--debug',
        '-e', 'load ARGV.fetch(0)', File.expand_path('support/jit_binding_check.rb', __dir__))
      expect(status.success?).to be(true), "#{stdout}\n#{stderr}"
      result = JSON.parse(stdout)
      expect(result['sdk']).to be true
      expect(result['compiled_type']).to eq('org.jruby.internal.runtime.methods.CompiledIRMethod')
      expect(result['counts']).to eq('cold' => { 'valid' => 5, 'missing' => 0 },
                                    'warm' => { 'valid' => 1200, 'missing' => 0 })
    end

    it 'rejects --debug alone without interfering with application execution' do
      code = <<~RUBY
        require 'hyperprobe'
        agent = HyperProbe.start(service_id: '11111111-2222-4333-8444-555555555555',
          environment: 'test', broker_url: 'localhost:50051', commit_sha: 'guard', is_lambda: true)
        raise 'Unsafe profile accepted' if agent
        puts 'application result: 42'
      RUBY
      stdout, stderr, status = Open3.capture3(environment, *runtime, '--debug',
        '-I', File.expand_path('../lib', __dir__), '-e', code)
      expect(status.success?).to be(true), stderr
      expect(stderr).to include('compiled JRuby probes require')
      expect(stdout).to include('application result: 42')
    end
  end
end
