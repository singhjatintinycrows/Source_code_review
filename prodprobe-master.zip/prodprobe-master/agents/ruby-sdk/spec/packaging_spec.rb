# frozen_string_literal: true

require 'rspec'
require 'rubygems/package'
require 'rubygems/user_interaction'
require 'tmpdir'
require 'open3'
require 'java' if RUBY_PLATFORM =~ /java/

RSpec.describe 'Broker transport packaging' do
  around do |example|
    previous = ENV['HYPERPROBE_GEM_PLATFORM']
    Dir.chdir(File.expand_path('..', __dir__)) { example.run }
  ensure
    previous ? ENV['HYPERPROBE_GEM_PLATFORM'] = previous : ENV.delete('HYPERPROBE_GEM_PLATFORM')
  end

  it 'defaults to a Ruby artifact with grpc even when evaluated by JRuby' do
    ENV.delete('HYPERPROBE_GEM_PLATFORM')
    spec = Gem::Specification.load('hyperprobe-agent.gemspec')
    expect(spec.platform.to_s).to eq('ruby')
    expect(spec.runtime_dependencies.map(&:name)).to include('grpc')
    expect(spec.files.grep(/\.jar\z/)).to be_empty
  end

  %w[ruby java].each do |platform|
    it "builds a usable #{platform} package with immutable platform-correct metadata" do
      ENV['HYPERPROBE_GEM_PLATFORM'] = platform
      spec = eval(File.read('hyperprobe-agent.gemspec'), binding, File.expand_path('hyperprobe-agent.gemspec'))
      Dir.mktmpdir('hyperprobe-package') do |dir|
        path = File.join(dir, spec.file_name)
        Gem::DefaultUserInteraction.use_ui(Gem::SilentUI.new) { Gem::Package.build(spec, false, false, path) }
        package = Gem::Package.new(path)
        metadata = package.spec
        expect(metadata.platform.to_s).to eq(platform)
        expect(metadata.required_ruby_version.satisfied_by?(Gem::Version.new('3.0.0'))).to be(true)
        expect(metadata.required_ruby_version.satisfied_by?(Gem::Version.new('2.6.8'))).to eq(platform == 'java')
        dependencies = metadata.runtime_dependencies.map(&:name)
        expect(dependencies).not_to include('binding_of_caller')
        if platform == 'java'
          expect(dependencies).not_to include('grpc', 'jar-dependencies', 'google-protobuf', 'debug_inspector')
          expect(package.contents).to include('lib/hyperprobe/jars/hyperprobe-grpc.jar', 'transport/pom.xml',
                                             'lib/hyperprobe/protos/agent_descriptor.rb',
                                             'lib/hyperprobe/protos/java_messages.rb')
          package.extract_files(File.join(dir, 'unpacked'))
          expect(File.size(File.join(dir, 'unpacked/lib/hyperprobe/jars/hyperprobe-grpc.jar'))).to be > 1_000_000
        else
          expect(dependencies).to include('grpc', 'google-protobuf', 'debug_inspector')
          expect(package.contents.grep(/\.jar\z/)).to be_empty
        end
      end
    end
  end

  if RUBY_PLATFORM.match?(/java/)
    it 'installs the Java artifact offline with Bundler into an empty gem home' do
      ENV['HYPERPROBE_GEM_PLATFORM'] = 'java'
      spec = eval(File.read('hyperprobe-agent.gemspec'), binding, File.expand_path('hyperprobe-agent.gemspec'))
      Dir.mktmpdir('hyperprobe-bundler') do |dir|
        cache = File.join(dir, 'vendor/cache')
        FileUtils.mkdir_p(cache)
        Gem::DefaultUserInteraction.use_ui(Gem::SilentUI.new) do
          Gem::Package.build(spec, false, false, File.join(cache, spec.file_name))
        end
        File.write(File.join(dir, 'Gemfile'), "source 'https://rubygems.org'\ngem 'hyperprobe-agent', '#{spec.version}'\n")
        runtime = if RbConfig.ruby.start_with?('uri:')
                    [File.join(java.lang.System.getProperty('java.home'), 'bin/java'), '-cp',
                     java.lang.System.getProperty('java.class.path'), 'org.jruby.Main']
                  else
                    [RbConfig.ruby]
                  end
        environment = {
          'GEM_HOME' => File.join(dir, 'gems'), 'GEM_PATH' => File.join(dir, 'gems'),
          'BUNDLE_GEMFILE' => File.join(dir, 'Gemfile'), 'BUNDLE_IGNORE_CONFIG' => '1',
          'RUBYOPT' => nil, 'RUBYLIB' => nil, 'HYPERPROBE_GEM_PLATFORM' => nil
        }
        out, status = Open3.capture2e(environment, *runtime, '-rbundler', '-rbundler/cli', '-e',
                                     'Bundler::CLI.start(["install", "--local"])', chdir: dir)
        expect(status.success?).to be(true), out
        code = <<~'RUBY'
          require 'bundler/setup'
          require 'hyperprobe'
          raise 'SDK failed to load' if defined?(HyperProbe::LOAD_FAILED)
          raise 'Google dependency activated' if Gem.loaded_specs.key?('google-protobuf')
          raise 'MRI inspector activated on JRuby' if Gem.loaded_specs.key?('debug_inspector')
          klass = Hyperprobe::Agent::V1::Probe
          raise 'bad wire roundtrip' unless klass.decode(klass.new(capture_closures: false).to_proto).has_capture_closures?
          raise 'not installed from the package' unless Gem.loaded_specs.fetch('hyperprobe-agent').full_gem_path.start_with?(ENV.fetch('GEM_HOME'))
        RUBY
        out, status = Open3.capture2e(environment, *runtime, '-e', code, chdir: dir)
        expect(status.success?).to be(true), out
      end
    end

    it 'exposes a missing bundled JAR as a catchable LoadError without downloading anything' do
      Dir.mktmpdir('hyperprobe-missing-jar') do |dir|
        wrapper = File.join(dir, 'core/transports/java_grpc.rb')
        FileUtils.mkdir_p(File.dirname(wrapper))
        FileUtils.cp('lib/hyperprobe/core/transports/java_grpc.rb', wrapper)
        expect { load wrapper }.to raise_error(LoadError, /hyperprobe-grpc/)
      end
    end

    it 'converts incompatible Java linkage failures into LoadError' do
      allow(JavaUtilities).to receive(:get_proxy_class)
        .with('co.hyperprobe.transport.GrpcTransport')
        .and_raise(Java::JavaLang::NoClassDefFoundError.new('broken transport'))
      expect { load 'lib/hyperprobe/core/transports/java_grpc.rb' }.to raise_error(LoadError, /broken transport/)
    end
  end
end
