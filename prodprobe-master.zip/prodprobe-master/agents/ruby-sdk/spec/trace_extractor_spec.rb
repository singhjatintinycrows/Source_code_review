# frozen_string_literal: true

require 'spec_helper'

RSpec.describe HyperProbe::Core::TraceExtractor do
  describe '.extract_trace_context' do
    it 'prioritizes custom code trace getter hook' do
      custom_hook = -> { 'custom-trace-id-999' }
      expect(described_class.extract_trace_context(custom_hook)).to eq('custom-trace-id-999')
    end

    it 'extracts trace ID from OpenTelemetry Ruby if present' do
      span_context = double('SpanContext', hex_trace_id: '4bf92f3577b34da6a3ce929d0e0e4736')
      span = double('Span', context: span_context)
      otel_trace = double('OpenTelemetryTrace', current_span: span)

      stub_const('OpenTelemetry::Trace', otel_trace)

      expect(described_class.extract_trace_context).to eq('4bf92f3577b34da6a3ce929d0e0e4736')
    end

    it 'extracts trace ID from Datadog Ruby (ddtrace) if present' do
      active_trace = double('ActiveTrace', id: 884729103948271)
      datadog_tracing = double('DatadogTracing', active_trace: active_trace)

      stub_const('Datadog::Tracing', datadog_tracing)

      expect(described_class.extract_trace_context).to eq('884729103948271')
    end

    it 'extracts trace ID from New Relic Ruby if present' do
      agent_mod = Module.new
      tracer_mod = Class.new do
        def self.current_trace_id
          'nr-trace-777'
        end
      end
      agent_mod.const_set('Tracer', tracer_mod)
      stub_const('NewRelic::Agent', agent_mod)

      expect(described_class.extract_trace_context).to eq('nr-trace-777')
    end

    it 'extracts trace ID from Elastic APM Ruby if present' do
      txn = double('Transaction', trace_id: 'elastic-trace-555')
      elastic_apm = double('ElasticAPM', current_transaction: txn)

      stub_const('ElasticAPM', elastic_apm)

      expect(described_class.extract_trace_context).to eq('elastic-trace-555')
    end

    it 'returns nil when no tracing provider is present' do
      expect(described_class.extract_trace_context).to be_nil
    end
  end
end
