# frozen_string_literal: true

require 'spec_helper'
require 'tempfile'

RSpec.describe HyperProbe do
  let(:valid_service_id) { '11111111-2222-4333-8444-555555555555' }
  let(:valid_opts) do
    {
      service_id: valid_service_id,
      environment: 'test',
      broker_url: 'localhost:60051',
      commit_sha: 'commit-sha-12345',
      is_lambda: true
    }
  end

  before do
    allow_any_instance_of(HyperProbe::Core::BrokerClient).to receive(:get_probes).and_return(
      Hyperprobe::Agent::V1::GetProbesResponse.new(probes: [], next_sync_interval_ms: 60_000)
    )
  end

  after do
    HyperProbe.shutdown
  end

  describe '.start' do
    it 'initializes the singleton instance with valid options' do
      agent = HyperProbe.start(valid_opts)
      expect(agent).not_to be_nil
      expect(HyperProbe.instance).to eq(agent)
      expect(agent.service_id).to eq(valid_service_id) if agent.respond_to?(:service_id)
    end

    it 'returns nil and does not start if disabled' do
      allow(ENV).to receive(:[]).and_call_original
      allow(ENV).to receive(:[]).with('HYPERPROBE_DISABLED').and_return('YES')

      agent = HyperProbe.start(valid_opts)
      expect(agent).to be_nil
      expect(HyperProbe.instance).to be_nil
    end

    it 'returns nil if commit_sha is missing or unknown' do
      opts = valid_opts.dup
      opts.delete(:commit_sha)
      allow(ENV).to receive(:[]).and_call_original
      allow(ENV).to receive(:[]).with('GIT_COMMIT').and_return(nil)
      allow(ENV).to receive(:[]).with('HYPERPROBE_COMMIT_SHA').and_return(nil)

      agent = HyperProbe.start(opts)
      expect(agent).to be_nil
    end

    it 'shuts down cleanly' do
      HyperProbe.start(valid_opts)
      expect(HyperProbe.instance).not_to be_nil

      expect { HyperProbe.shutdown }.to output(/Ruby agent successfully shut down/).to_stdout
      expect(HyperProbe.instance).to be_nil
    end

    it 'prints startup banner with version, agent ID, and PID to stdout' do
      expect {
        agent = HyperProbe.start(valid_opts)
        expect(agent).not_to be_nil
      }.to output(/\[HyperProbe\] Ruby agent successfully started \(Version: #{Regexp.escape(HyperProbe::VERSION)}, ID: [^,]+, PID: #{Process.pid}\)/).to_stdout
    end

    it 'can be safely shut down from within a signal trap context without ThreadError' do
      HyperProbe.start(valid_opts)
      expect(HyperProbe.instance).not_to be_nil

      trap_error = nil
      old_handler = trap('USR2') do
        begin
          HyperProbe.shutdown
        rescue Exception => e
          trap_error = e
        end
      end

      begin
        Process.kill('USR2', Process.pid)
        sleep 0.1 # Allow trap handler to complete
        expect(trap_error).to be_nil
        expect(HyperProbe.instance).to be_nil
      ensure
        trap('USR2', old_handler || 'DEFAULT')
      end
    end
  end

  describe 'Hit Limit Enforcement' do
    let(:tmp_file) do
      f = Tempfile.new(['hit_limit_target', '.rb'])
      f.write(<<-RUBY)
        def run_op(n)
          res = n * 2 # Line 2
        end
      RUBY
      f.close
      f
    end

    let(:file_path) { tmp_file.path }

    before do
      load file_path
    end

    after do
      tmp_file.unlink
    end

    it 'removes probe locally once hitLimit is reached' do
      agent = HyperProbe.start(valid_opts)

      probe = Hyperprobe::Agent::V1::Probe.new(
        id: 'hit-limited-probe',
        type: Hyperprobe::Agent::V1::ProbeType::PROBE_TYPE_COUNTER,
        runtime_location: file_path,
        runtime_line: 2,
        hit_limit: 2,
        expiry_time: (Time.now.to_f * 1000 + 60_000).to_i
      )

      agent.engine.set_probes([probe])
      agent.active_probes['hit-limited-probe'] = probe

      3.times { run_op(5) }

      expect(agent.active_probes.key?('hit-limited-probe')).to be false
    end

    it 'safely handles probes with nil hit_limit without raising ArgumentError' do
      agent = HyperProbe.start(valid_opts)

      probe_hash = {
        id: 'nil-hit-limit-probe',
        type: 3, # COUNTER
        runtime_location: file_path,
        runtime_line: 2,
        hit_limit: nil
      }

      agent.engine.set_probes([probe_hash])
      agent.active_probes['nil-hit-limit-probe'] = probe_hash

      expect {
        run_op(5)
      }.not_to raise_error
    end
  end
end
