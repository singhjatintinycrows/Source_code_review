# frozen_string_literal: true

require 'rspec'
require 'open3'
require 'json'
require 'tmpdir'
require 'rbconfig'

if RUBY_PLATFORM =~ /java/
  require 'base64'
  require_relative '../lib/hyperprobe/protos'

  RSpec.describe 'Isolated Java protobuf messages' do
    let(:proto) { Hyperprobe::Agent::V1 }

    def runtime_command
      return [RbConfig.ruby] unless RbConfig.ruby.start_with?('uri:')

      [File.join(java.lang.System.getProperty('java.home'), 'bin/java'), '-cp',
       java.lang.System.getProperty('java.class.path'), 'org.jruby.Main']
    end

    def fixture(descriptor)
      descriptor.getFields.each_with_object({}) do |field, values|
        value = case field.getJavaType.to_s
                when 'MESSAGE' then fixture(field.getMessageType)
                when 'ENUM' then 3
                when 'INT' then field.hasPresence ? 0 : -123
                when 'LONG' then -9_223_372_036_854_775_808
                when 'DOUBLE', 'FLOAT' then -123.625
                when 'BOOLEAN' then false
                when 'BYTE_STRING' then "\x00bytes"
                when 'STRING' then field.hasPresence ? '' : "#{field.getName}-\u03bb"
                else raise "Uncovered field type: #{field.getType}"
                end
        values[field.getName.to_sym] = field.isRepeated ? [value, value] : value
      end
    end

    # The same observable field-by-field snapshot is used in the MRI subprocess.
    def snapshot(message)
      message.class.fields.each_with_object({}) do |(name, _field), result|
        value = message.public_send(name)
        value = value.map { |item| item.respond_to?(:to_proto) ? snapshot(item) : item } if value.is_a?(Array)
        value = snapshot(value) if value.respond_to?(:to_proto)
        result[name] = value.is_a?(Symbol) ? value.to_s : value
        result["has_#{name}"] = !!message.public_send("has_#{name}?") if message.respond_to?("has_#{name}?")
      end
    end

    it 'cross-decodes every canonical field and default with MRI Google protobuf in both directions' do
      requests = Hyperprobe::JavaProto::CLASSES.values.flat_map do |klass|
        [fixture(klass.descriptor), {}].map do |values|
          { name: klass.descriptor.getName, values: values, wire: Base64.strict_encode64(klass.new(values).to_proto) }
        end
      end
      code = <<~'RUBY'
        require 'json'
        require 'base64'
        require 'hyperprobe/protos/agent_pb'
        def snapshot(message)
          message.class.descriptor.each_with_object({}) do |field, result|
            name = field.name
            value = message.public_send(name)
            if field.label == :repeated
              value = value.map { |item| item.respond_to?(:to_proto) ? snapshot(item) : item }
            end
            value = snapshot(value) if value.respond_to?(:to_proto)
            result[name] = value.is_a?(Symbol) ? value.to_s : value
            result["has_#{name}"] = !!message.public_send("has_#{name}?") if message.respond_to?("has_#{name}?")
          end
        end
        result = JSON.parse(STDIN.read, symbolize_names: true).map do |request|
          klass = Hyperprobe::Agent::V1.const_get(request.fetch(:name))
          canonical = klass.new(request.fetch(:values))
          { expected: snapshot(canonical), decoded: snapshot(klass.decode(Base64.strict_decode64(request.fetch(:wire)))),
            wire: Base64.strict_encode64(canonical.to_proto) }
        end
        STDOUT.write(JSON.generate(result))
      RUBY
      out, err, status = Open3.capture3(
        { 'RUBYOPT' => nil, 'BUNDLE_GEMFILE' => nil, 'GEM_HOME' => nil, 'GEM_PATH' => nil },
        ENV.fetch('HYPERPROBE_MRI_RUBY', 'ruby'), '-I', File.expand_path('../lib', __dir__), '-e', code,
        stdin_data: JSON.generate(requests)
      )
      expect(status.success?).to be(true), err
      JSON.parse(out).zip(requests).each do |result, request|
        klass = proto.const_get(request.fetch(:name))
        expect(result.fetch('decoded')).to eq(result.fetch('expected')), request.fetch(:name)
        expect(snapshot(klass.decode(Base64.strict_decode64(result.fetch('wire'))))).to eq(result.fetch('expected'))
      end
    end

    it 'preserves explicit zero, false and empty optional fields through setters and decoding' do
      message = proto::Probe.new
      expect(message.has_max_object_depth?).to be(false)
      expect(message.has_capture_closures?).to be(false)
      expect(message).not_to respond_to(:has_runtime_line?, :has_type?, :has_watch_expressions?)
      message.max_object_depth = 0
      message.capture_closures = false
      message.log_level = ''
      copy = proto::Probe.decode(message.to_proto)
      expect([copy.max_object_depth, copy.capture_closures, copy.log_level]).to eq([0, false, ''])
      expect([copy.has_max_object_depth?, copy.has_capture_closures?, copy.has_log_level?]).to eq([true, true, true])
      copy.capture_closures = nil
      expect(proto::Probe.decode(copy.to_proto).has_capture_closures?).to be(false)
      expect(proto::Probe.new(capture_closures: nil).has_capture_closures?).to be(false)
    end

    it 'supports nested mutable message arrays, repeated strings, hashes and writable fields' do
      batch = proto::TelemetryBatch.new('agent_id' => 'a')
      batch.events << proto::TelemetryEvent.new(stack_frames: [{ function_name: 'first' }])
      batch.events.first.stack_frames.first.line_number = 42
      batch.events.first.stack_frames << proto::StackFrame.new(class_name: '')
      copy = proto::TelemetryBatch.decode(batch.to_proto)
      expect(copy.events.first.stack_frames.map(&:line_number)).to eq([42, 0])
      expect(copy.events.first.stack_frames.last.has_class_name?).to be(true)
      probe = proto::Probe.new(watch_expressions: ['a'])
      probe.watch_expressions << 'b'
      expect(proto::Probe.decode(probe.to_proto).watch_expressions).to eq(%w[a b])
      expect(proto::Probe.new.watch_expressions).to eq([])
      expect(proto::GetProbesResponse.new.global_config).to be_nil
    end

    it 'uses enum symbols and integer constants, including unknown signed enum values' do
      expect(proto::ProbeType::PROBE_TYPE_SNAPSHOT).to eq(1)
      [:PROBE_TYPE_SNAPSHOT, 1, 0, 1234, -1].each do |value|
        message = proto::Probe.new(type: value)
        expect(proto::Probe.decode(message.to_proto).type).to eq(message.type)
      end
      expect(proto::Probe.new(type: 1).type).to eq(:PROBE_TYPE_SNAPSHOT)
      expect(proto::Probe.new.type).to eq(:PROBE_TYPE_UNSPECIFIED)
    end

    it 'round-trips signed int64 boundaries, doubles and arbitrary binary bytes' do
      [-(2**63), 2**63 - 1].each do |value|
        expect(proto::TelemetryEvent.decode(proto::TelemetryEvent.new(timestamp_ms: value).to_proto).timestamp_ms).to eq(value)
      end
      [0.0, -0.0, Float::INFINITY, -Float::INFINITY, 1.0e-200].each do |value|
        decoded = proto::TelemetryEvent.decode(proto::TelemetryEvent.new(metric_value: value).to_proto).metric_value
        expect(decoded).to eq(value)
        expect(1.0 / decoded).to eq(1.0 / value) if value.zero?
      end
      expect(proto::TelemetryEvent.decode(proto::TelemetryEvent.new(metric_value: Float::NAN).to_proto).metric_value.nan?).to be(true)
      bytes = "\x00\xff\x80".b
      expect(proto::SourceMapChunk.decode(proto::SourceMapChunk.new(data: bytes).to_proto).data).to eq(bytes)
    end

    it 'rejects unknown fields, wrong scalar and nested types, overflow and invalid UTF-8' do
      expect { proto::Probe.new(typo: 1) }.to raise_error(ArgumentError, /Unknown field/)
      expect { proto::Probe.new(id: 1) }.to raise_error(TypeError)
      expect { proto::Probe.new(runtime_line: 1.5) }.to raise_error(TypeError)
      expect { proto::Probe.new(capture_closures: 0) }.to raise_error(TypeError)
      expect { proto::Probe.new(type: :NO_SUCH_ENUM) }.to raise_error(ArgumentError)
      expect { proto::Probe.new(type: 2**31) }.to raise_error(RangeError)
      expect { proto::Probe.new(expiry_time: 2**63) }.to raise_error(RangeError)
      expect { proto::Probe.new(runtime_line: -(2**31) - 1) }.to raise_error(RangeError)
      expect { proto::Probe.new(watch_expressions: 'not an array') }.to raise_error(TypeError)
      expect { proto::GetProbesResponse.new(probes: [proto::StackFrame.new]) }.to raise_error(TypeError)
      expect { proto::Probe.new(id: "\xff".b.force_encoding('UTF-8')) }.to raise_error(ArgumentError)
      message = proto::Probe.new
      message.watch_expressions << 42
      expect { message.to_proto }.to raise_error(TypeError)
    end

    it 'rejects malformed, invalid UTF-8, oversized and excessively recursive wire input' do
      ["\x00", "\x0a\x05x", "\x0a\x01\xff", "\x0c", "\x80" * 11].each do |bytes|
        expect { proto::Probe.decode(bytes.b) }.to raise_error(ArgumentError)
      end
      expect { proto::Probe.decode('x' * (4 * 1024 * 1024 + 1)) }.to raise_error(ArgumentError, /4 MiB/)
      # Unknown groups exercise protobuf's recursion guard without changing the schema.
      expect { proto::Probe.decode(("\x7b" * 100 + "\x7c" * 100).b) }.to raise_error(ArgumentError)
      expect { proto::Probe.decode(nil) }.to raise_error(TypeError)
    end

    it 'computes serialized size without bytes, including every canonical field, defaults and unknowns' do
      Hyperprobe::JavaProto::CLASSES.values.each do |klass|
        [klass.new, klass.new(fixture(klass.descriptor))].each do |message|
          expect(message.serialized_size).to eq(message.to_proto.bytesize), klass.name
        end
      end
      wire = proto::Probe.new(id: 'known').to_proto + "\xa0\x06\x01".b
      expect(proto::Probe.decode(wire).serialized_size).to eq(wire.bytesize)
      message = proto::TelemetryEvent.new(captured_vars_json: JSON.generate(body: 'x' * 65_536))
      expected = message.to_proto.bytesize
      expect(message).not_to receive(:to_proto)
      expect(message.serialized_size).to eq(expected)
    end

    it 'revalidates mutable repeated items on both encoding and size estimation' do
      [:to_proto, :serialized_size].each do |operation|
        probe = proto::Probe.new(watch_expressions: ['valid'])
        probe.watch_expressions[0] = 42
        expect { probe.public_send(operation) }.to raise_error(TypeError)
        mutable = +'valid'
        probe.watch_expressions[0] = mutable
        expect(probe.public_send(operation)).not_to be_nil
        mutable.replace("\xff".b.force_encoding('UTF-8'))
        expect { probe.public_send(operation) }.to raise_error(ArgumentError)

        batch = proto::TelemetryBatch.new(events: [{ probe_id: 'valid' }])
        batch.events[0] = proto::StackFrame.new
        expect { batch.public_send(operation) }.to raise_error(TypeError)
        batch.events[0] = { timestamp_ms: 2**63 }
        expect { batch.public_send(operation) }.to raise_error(RangeError)
        batch.events[0] = { stack_frames: [{ line_number: 1.5 }] }
        expect { batch.public_send(operation) }.to raise_error(TypeError)
      end
    end

    it 'reflects nested mutations in size and isolates assigned scalar strings' do
      original = +'first'
      batch = proto::TelemetryBatch.new(events: [{ probe_id: original }])
      original.replace('changed outside the message')
      expect(batch.events.first.probe_id).to eq('first')
      expect(batch.events.first.probe_id).to be_frozen
      before = batch.serialized_size
      batch.events.first.stack_frames << proto::StackFrame.new(function_name: 'nested')
      batch.events << { probe_id: 'inserted hash' }
      expect(batch.serialized_size).to be > before
      expect(batch.serialized_size).to eq(batch.to_proto.bytesize)
    end

    it 'uses the private size API in the broker and retains the JSON error fallback' do
      require_relative '../lib/hyperprobe/core/broker'
      broker = HyperProbe::Core::BrokerClient.allocate
      message = proto::TelemetryEvent.new(probe_id: 'counter', metric_value: 1.0)
      expected = message.to_proto.bytesize
      expect(message).not_to receive(:to_proto)
      expect(broker.estimate_event_size(message)).to eq(expected)
      event = { probe_id: 'counter', timestamp_ms: 123, metric_value: 1.0 }
      expect(broker.estimate_event_size(event)).to eq(broker.send(:build_telemetry_event_proto, event).to_proto.bytesize)
      invalid = { timestamp_ms: 2**63 }
      expect(broker.estimate_event_size(invalid)).to eq(JSON.generate(invalid).bytesize)
    end

    it 'preserves unknown wire fields for forward-compatible broker responses' do
      wire = proto::Probe.new(id: 'known').to_proto + "\xa0\x06\x01".b
      expect(proto::Probe.decode(wire).to_proto).to eq(wire)
    end

    it 'compares message values including optional presence and repeated defaults' do
      message = proto::GetProbesResponse.new(probes: [])
      copy = proto::GetProbesResponse.decode(message.to_proto)
      expect(copy).to eq(message)
      expect(copy).to eql(message)
      expect(copy.hash).to eq(message.hash)
      expect(proto::Probe.new(max_object_depth: 0)).not_to eq(proto::Probe.new)
      expect(proto::Probe.new).not_to eq(proto::StackFrame.new)
    end

    it 'loads only the patched relocated protobuf core from the bundled transport jar' do
      jar = java.util.jar.JarFile.new(File.expand_path('../lib/hyperprobe/jars/hyperprobe-grpc.jar', __dir__))
      begin
        names = jar.entries.to_a.map(&:name)
        expect(names).to include('co/hyperprobe/internal/google/protobuf/DynamicMessage.class')
        expect(names.grep(%r{\Acom/google/protobuf/})).to be_empty
        expect(names.grep(%r{google/protobuf/util/})).to be_empty
        expect(jar.getManifest.getMainAttributes.getValue('HyperProbe-Protobuf-Version')).to eq('3.25.9')
        expect(File.read(File.expand_path('../transport/pom.xml', __dir__))).to include(
          '<protobuf.version>3.25.9</protobuf.version>'
        )
        expect(Hyperprobe::JavaProto::CODEC.getFile.java_class.name).to start_with('co.hyperprobe.internal.google.protobuf.')
        expect($LOADED_FEATURES.grep(%r{/(google/protobuf|agent_pb\.rb)})).to be_empty
      ensure
        jar.close
      end
    end

    %w[before after].each do |order|
      it "does not modify host Google protobuf loaded #{order} the SDK" do
        code = <<~RUBY
          $LOAD_PATH.unshift(ENV.fetch('HYPERPROBE_HOST_PROTOBUF_LIB')) if ENV['HYPERPROBE_HOST_PROTOBUF_LIB']
          require 'hyperprobe/protos' if #{order == 'after'}
          begin
            require 'google/protobuf'
            require 'google/protobuf/descriptor_pb'
          rescue LoadError
            exit 77
          end
          host = Google::Protobuf::FileDescriptorProto
          pool = Google::Protobuf::DescriptorPool.generated_pool
          constants = Google::Protobuf.constants.sort
          original = host.new(name: 'host.proto').to_proto
          require 'hyperprobe/protos'
          raise 'host class replaced' unless host.equal?(Google::Protobuf::FileDescriptorProto)
          raise 'host pool replaced' unless pool.equal?(Google::Protobuf::DescriptorPool.generated_pool)
          raise 'host namespace changed' unless constants == Google::Protobuf.constants.sort
          raise 'SDK registered globally' if pool.lookup('hyperprobe.agent.v1.Probe')
          raise 'host wire changed' unless host.decode(original).name == 'host.proto'
          sdk = Hyperprobe::Agent::V1::Probe
          raise 'SDK broken' unless sdk.decode(sdk.new(id: 'sdk').to_proto).id == 'sdk'
        RUBY
        out, status = Open3.capture2e(*runtime_command, '-I', File.expand_path('../lib', __dir__), '-e', code)
        skip 'Host Google protobuf is not installed for this runtime' if status.exitstatus == 77
        expect(status.success?).to be(true), out
      end
    end
  end
end
