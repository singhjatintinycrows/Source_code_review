# frozen_string_literal: true

require 'spec_helper'

RSpec.describe HyperProbe::Core::Evaluator do
  let(:binding_ctx) do
    item_name = 'Widget'
    price = 19.99
    quantity = 3
    is_active = true
    user = { id: 'user_123', role: 'admin' }
    binding
  end

  describe '.eval_condition' do
    it 'evaluates truthy and falsy conditions' do
      expect(described_class.eval_condition('quantity > 2', binding_ctx)).to be true
      expect(described_class.eval_condition('quantity == 10', binding_ctx)).to be false
      expect(described_class.eval_condition('is_active', binding_ctx)).to be true
      expect(described_class.eval_condition('', binding_ctx)).to be true
      expect(described_class.eval_condition(nil, binding_ctx)).to be true
    end

    it 'raises error on invalid syntax for caller error capture' do
      expect do
        described_class.eval_condition('1 +', binding_ctx)
      end.to raise_error(StandardError)
    end
  end

  describe '.evaluate_watches' do
    it 'evaluates valid watch expressions and isolates failures' do
      watches = ['price * quantity', 'user[:role]', 'non_existent_var']
      results = described_class.evaluate_watches(watches, binding_ctx)

      expect(results['price * quantity']).to be_within(0.01).of(59.97)
      expect(results['user[:role]']).to eq('admin')
      expect(results['non_existent_var']).to include('Error: NameError')
    end
  end

  describe '.evaluate_log_template' do
    it 'interpolates template placeholders' do
      tpl = 'Order item: ${item_name} with total: ${price * quantity}'
      result = described_class.evaluate_log_template(tpl, binding_ctx)
      expect(result).to eq('Order item: Widget with total: 59.97')
    end

    it 'handles errors inside template placeholders gracefully' do
      tpl = 'Item ${item_name} has invalid ${unknown_fn()}'
      result = described_class.evaluate_log_template(tpl, binding_ctx)
      expect(result).to include('Item Widget has invalid <Error:')
    end
  end

  describe '.evaluate_metric' do
    it 'evaluates and coerces metric values' do
      expect(described_class.evaluate_metric('price * quantity', binding_ctx)).to be_within(0.01).of(59.97)
      expect(described_class.evaluate_metric('"123.45 items"', binding_ctx)).to eq(123.45)
      expect(described_class.evaluate_metric('true', binding_ctx)).to be_nil
    end
  end

  describe '.evaluate_correlation' do
    it 'returns correlation string or static-singleton' do
      expect(described_class.evaluate_correlation('user[:id]', binding_ctx)).to eq('user_123')
      expect(described_class.evaluate_correlation(nil, binding_ctx)).to eq('static-singleton')
    end

    it 'raises on invalid correlation type' do
      expect do
        described_class.evaluate_correlation('is_active', binding_ctx)
      end.to raise_error(TypeError)
    end
  end

  describe 'opt-in unrestricted evaluation' do
    before do
      allow(ENV).to receive(:[]).and_call_original
      allow(ENV).to receive(:[]).with('HYPERPROBE_DISABLE_SAFE_EVALUATION').and_return(nil)
    end

    it 'allows custom method calls and mutations only when explicitly disabled' do
      items = [1]
      context = binding
      expression = 'items.push(2).length'

      expect(described_class.evaluate_watches([expression], context)[expression]).to include('Error: SecurityError')
      expect(items).to eq([1])
      expect(described_class.evaluate_watches([expression], context, safe: false)[expression]).to eq(2)
      expect(items).to eq([1, 2])

      expect(described_class.evaluate_watches([expression], context, safe: true)[expression]).to include('Error: SecurityError')
      expect(items).to eq([1, 2])
    end

    it 'applies the selected mode to conditions, watches, logs, metrics, and correlations' do
      context = binding_ctx
      expect(described_class.eval_condition('quantity.positive?', context, safe: false)).to be(true)
      expect(described_class.evaluate_watches(['item_name.upcase'], context, safe: false)).to eq('item_name.upcase' => 'WIDGET')
      expect(described_class.evaluate_log_template('${item_name.upcase} #{quantity.to_s}', context, safe: false)).to eq('WIDGET 3')
      expect(described_class.evaluate_metric('Math.sqrt(81)', context, safe: false)).to eq(9.0)
      expect(described_class.evaluate_correlation('user[:id].upcase', context, safe: false)).to eq('USER_123')
    end

    it 'allows Ruby statements to update existing locals in the hit binding' do
      context = binding_ctx
      result = described_class.evaluate_watches(['quantity += 1; quantity'], context, safe: false)
      expect(result).to eq('quantity += 1; quantity' => 4)
      expect(context.local_variable_get(:quantity)).to eq(4)
    end

    it 'isolates expression failures and does not bypass the existing source and output limits' do
      result = described_class.evaluate_watches(['raise "failed"', '1 +', 'quantity.to_s'], binding_ctx, safe: false)
      expect(result['raise "failed"']).to include('Error: RuntimeError: failed')
      expect(result['1 +']).to include('Error: SyntaxError')
      expect(result['quantity.to_s']).to eq('3')
      expect(described_class.evaluate_log_template('${raise "failed"} ${quantity.to_s}', binding_ctx, safe: false)).to include('<Error: RuntimeError: failed> 3')
      long_expression = '1' * 257
      expect(described_class.evaluate_watches([long_expression], binding_ctx, safe: false).values.first).to include('Error: SecurityError')
      expect { described_class.evaluate_log_template('x' * 16_385, binding_ctx, safe: false) }.to raise_error(SecurityError)
    end

    it 'uses the real binding evaluator and still rejects fake bindings' do
      context = binding_ctx
      expect(context).not_to receive(:eval)
      expect(described_class.evaluate_metric('quantity.to_f', context, safe: false)).to eq(3.0)
      fake = double('fake binding')
      expect(fake).not_to receive(:eval)
      expect { described_class.eval_condition('true', fake, safe: false) }.to raise_error(SecurityError, /Binding/)
    end

    it 'does not swallow termination raised by unrestricted Ruby code' do
      expect do
        described_class.evaluate_watches(['raise SystemExit'], binding_ctx, safe: false)
      end.to raise_error(SystemExit)
    end

    it 'accepts only an explicit true flag and restores safe mode after an environment change' do
      [nil, '', 'false', 'FALSE', '1', 'yes', 'other'].each do |value|
        allow(ENV).to receive(:[]).with('HYPERPROBE_DISABLE_SAFE_EVALUATION').and_return(value)
        expect(described_class.safe_evaluation_enabled?).to be(true)
        expect(described_class.evaluate_watches(['quantity.to_s'], binding_ctx).values.first).to include('Error: SecurityError')
      end
      %w[true TRUE True].each do |value|
        allow(ENV).to receive(:[]).with('HYPERPROBE_DISABLE_SAFE_EVALUATION').and_return(" #{value} ")
        expect(described_class.safe_evaluation_enabled?).to be(false)
        expect(described_class.evaluate_watches(['quantity.to_s'], binding_ctx)).to eq('quantity.to_s' => '3')
      end
      expect(described_class.evaluate_watches(['quantity.to_s'], binding_ctx, safe: true).values.first).to include('Error: SecurityError')
      allow(ENV).to receive(:[]).with('HYPERPROBE_DISABLE_SAFE_EVALUATION').and_return('false')
      expect(described_class.evaluate_watches(['quantity.to_s'], binding_ctx).values.first).to include('Error: SecurityError')
    end
  end
end
