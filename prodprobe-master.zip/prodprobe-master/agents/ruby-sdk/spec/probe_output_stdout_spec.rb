# frozen_string_literal: true

require 'spec_helper'
require 'tempfile'
require 'stringio'

RSpec.describe 'LOG Probe Stdout Output & Formatting' do
  let(:quota) { HyperProbe::Core::QuotaManager.new(100, 1024 * 1024) }
  let(:safety) { HyperProbe::Core::SafetyMonitor.new(->(_h, _r) {}) }
  let(:events) { [] }
  let(:on_capture) { ->(evt) { events << evt } }
  let(:stdout_capture) { StringIO.new }

  subject(:engine) do
    HyperProbe::Core::MonitoringEngine.new(quota, safety, on_capture)
  end

  let(:tmp_file) do
    f = Tempfile.new(['stdout_log_target', '.rb'])
    f.write(<<-RUBY)
      def process_order(order_id, user_email, secret_val = nil)
        status = 'completed' # Line 2: Probe line
      end
    RUBY
    f.close
    f
  end

  around do |example|
    orig_stdout = $stdout
    # The worker can retain the stream while waiting for its first queued log.
    $stdout = stdout_capture
    example.run
  ensure
    $stdout = orig_stdout
  end

  before { load tmp_file.path }
  after do
    engine.close
    tmp_file.unlink
  end

  def wait_for_stdout(expected)
    deadline = Process.clock_gettime(Process::CLOCK_MONOTONIC) + 1.0
    until stdout_capture.string.include?(expected)
      break if Process.clock_gettime(Process::CLOCK_MONOTONIC) >= deadline

      sleep 0.005
    end
    stdout_capture.string
  end

  it 'formats and emits stdout logs with ANSI colors, timestamps, and HyperProbe prefix' do
    engine.set_global_config({
      redact_keys: %w[user_email],
      redact_values: %w[secret_val]
    })

    engine.set_probes([
      {
        id: 'stdout-log-probe',
        type: 2, # LOG
        runtime_location: tmp_file.path,
        runtime_line: 2,
        template: 'Order ${order_id} processed for ${user_email} token=${secret_val}',
        should_log_to_stdout: true,
        log_level: 'INFO'
      }
    ])

    process_order('ORD-777', 'alice@example.com', 'secret_val')

    output = wait_for_stdout("token=[REDACTED Value]\n")
    expect(output).to include('[HyperProbe LOG]')
    expect(output).to include("\e[32m[INFO]\e[0m")
    expect(output).to match(/\[\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d{3}Z\]/)
    expect(output).to include('Order ORD-777 processed')
    expect(output).to include('[REDACTED Value]')

    expect(events.length).to eq(1)
    expect(events.first[:evaluated_log]).to include('Order ORD-777')
  end

  it 'handles ERROR log level with red color formatting' do
    engine.set_probes([
      {
        id: 'stdout-error-probe',
        type: 2, # LOG
        runtime_location: tmp_file.path,
        runtime_line: 2,
        template: 'Failed processing order ${order_id}',
        should_log_to_stdout: true,
        log_level: 'ERROR'
      }
    ])

    process_order('ORD-999', 'bob@example.com')

    output = wait_for_stdout("Failed processing order ORD-999\n")
    expect(output).to include("\e[31m[ERROR]\e[0m")
    expect(output).to include('[HyperProbe LOG]')
    expect(output).to include('Failed processing order ORD-999')
  end
end
