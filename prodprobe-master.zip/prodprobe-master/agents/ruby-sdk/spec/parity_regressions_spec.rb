# frozen_string_literal: true

require 'spec_helper'
require 'tempfile'
require 'json'

RSpec.describe 'Parity & Regression Specifications' do
  let(:quota) { HyperProbe::Core::QuotaManager.new(100, 1024 * 1024) }
  let(:safety) { HyperProbe::Core::SafetyMonitor.new(->(_h, _r) {}) }
  let(:events) { [] }
  let(:on_capture) { ->(evt) { events << evt } }

  subject(:engine) do
    HyperProbe::Core::MonitoringEngine.new(quota, safety, on_capture)
  end

  after { engine.close }

  describe 'Evaluation Quota & Condition Ordering' do
    let(:tmp_file) do
      f = Tempfile.new(['cond_target', '.rb'])
      f.write(<<-RUBY)
        def target_method(val)
          step = val * 2 # Line 2
        end
      RUBY
      f.close
      f
    end

    let(:file_path) { tmp_file.path }

    before { load file_path }
    after { tmp_file.unlink }

    it 'checks evaluation quota before executing condition expression' do
      exhausted_quota = HyperProbe::Core::QuotaManager.new(0, 1024 * 1024) # 0 capacity
      local_events = []
      local_engine = HyperProbe::Core::MonitoringEngine.new(
        exhausted_quota,
        safety,
        ->(e) { local_events << e }
      )

      local_engine.set_probes([
        {
          id: 'probe-quota-first',
          type: 3, # COUNTER
          runtime_location: file_path,
          runtime_line: 2,
          condition: '1 / 0' # Would raise ZeroDivisionError if evaluated
        }
      ])

      expect { target_method(10) }.not_to raise_error
      local_engine.close

      expect(local_events).to be_empty
      expect(local_engine.get_stats[:skips]).to eq(1)
    end

    it 'emits capture error when condition expression raises an error' do
      engine.set_probes([
        {
          id: 'probe-cond-err',
          type: 3, # COUNTER
          runtime_location: file_path,
          runtime_line: 2,
          condition: '1 / 0'
        }
      ])

      target_method(10)

      expect(events.length).to eq(1)
      expect(events.first[:capture_error]).to include('Condition evaluation failed')
      expect(events.first[:capture_error]).to include('ZeroDivisionError')
    end
  end

  describe 'Watch-to-Local Reference Sharing (Java & Node Parity)' do
    class CircularPerson
      attr_accessor :name, :next_person

      def initialize(name)
        @name = name
      end
    end

    it 'preserves object identity across watches and local variables in a single snapshot' do
      person = CircularPerson.new('Alice')
      person.next_person = person

      serializer = HyperProbe::Core::Serializer.new(
        max_depth: 3,
        max_array_length: 3,
        max_object_properties: 10,
        max_string_length: 1024
      )

      visited = {}

      # 1. Sanitize watch first
      watch_val = serializer.serialize(person, 'watch["sessionUser"]', 0, visited)
      expect(watch_val['name']).to eq('Alice')
      expect(watch_val['next_person']).to eq('[REF - watch["sessionUser"]]')

      # 2. Sanitize locals containing the exact same object
      locals_hash = { 'current_user' => person }
      locals_val = serializer.serialize(locals_hash, 'frame[0].scopes[0]', 0, visited)

      expect(locals_val['current_user']).to eq('[REF - watch["sessionUser"]]')
    end
  end

  describe 'Value Redaction Prior to Truncation (Node & Python Parity)' do
    it 'redacts sensitive values before truncating string length' do
      serializer = HyperProbe::Core::Serializer.new(
        max_depth: 3,
        max_array_length: 3,
        max_object_properties: 50,
        max_string_length: 25,
        redact_keys: [],
        redact_values: %w[supersecret]
      )

      input = 'value=supersecret-12345'
      result = serializer.serialize(input)

      expect(result).not_to include('supersecret')
      expect(result).to include('[REDACTED Value]')
      expect(result).to include('[Truncated: +')
    end
  end

  describe 'Broker Flushing and Retry Behavior' do
    let(:valid_opts) do
      {
        service_id: '11111111-2222-4333-8444-555555555555',
        environment: 'test',
        broker_url: 'localhost:60051',
        commit_sha: 'commit-123',
        max_queue_size: 5,
        is_lambda: true
      }
    end

    it 're-queues telemetry batch when broker report fails' do
      agent = HyperProbe.start(valid_opts)

      probe = Hyperprobe::Agent::V1::Probe.new(id: 'p1', hit_limit: 10, expiry_time: (Time.now.to_f * 1000 + 60_000).to_i)
      agent.active_probes['p1'] = probe

      # Simulate broker transport error on report_telemetry
      allow(agent.broker_client).to receive(:report_telemetry).and_raise(RuntimeError.new('Connection refused'))

      # Capture an event
      agent.send(:handle_capture, {
        probe_id: 'p1',
        timestamp_ms: 1000,
        stack_frames: [],
        captured_vars_json: '',
        watch_results_json: '',
        evaluated_log: '',
        metric_value: 1.0,
        capture_error: ''
      })

      expect(agent.telemetry_queue_length).to eq(1)

      # Flush fails
      agent.send(:flush_telemetry)

      # Batch was re-queued on failure
      expect(agent.telemetry_queue_length).to eq(1)
    end

    it 'removes finished probe IDs returned by broker' do
      agent = HyperProbe.start(valid_opts)

      probe1 = Hyperprobe::Agent::V1::Probe.new(id: 'probe-1', hit_limit: 10, expiry_time: (Time.now.to_f * 1000 + 60_000).to_i)
      probe2 = Hyperprobe::Agent::V1::Probe.new(id: 'probe-2', hit_limit: 10, expiry_time: (Time.now.to_f * 1000 + 60_000).to_i)

      agent.active_probes['probe-1'] = probe1
      agent.active_probes['probe-2'] = probe2

      allow(agent.broker_client).to receive(:report_telemetry).and_return(['probe-1'])

      deadline = Process.clock_gettime(Process::CLOCK_MONOTONIC) + 2
      loop do
        agent.send(:handle_capture, { probe_id: 'probe-1', timestamp_ms: 1000, metric_value: 1.0 })
        break unless agent.telemetry_queue_length.zero?
        raise 'Capture admission stayed busy' if Process.clock_gettime(Process::CLOCK_MONOTONIC) >= deadline
        Thread.pass
      end

      agent.send(:flush_telemetry)

      expect(agent.active_probes.key?('probe-1')).to be false
      expect(agent.active_probes.key?('probe-2')).to be true
    end
  end

  describe 'Bandwidth Quota Enqueue Checks' do
    let(:valid_opts) do
      {
        service_id: '11111111-2222-4333-8444-555555555555',
        environment: 'test',
        broker_url: 'localhost:60051',
        commit_sha: 'commit-123',
        bandwidth_kb_per_sec: 0, # 0 KB/s bandwidth available
        is_lambda: true
      }
    end

    it 'drops captured events when bandwidth quota is exceeded' do
      agent = HyperProbe.start(valid_opts)

      probe = Hyperprobe::Agent::V1::Probe.new(id: 'bw-probe', hit_limit: 10, expiry_time: (Time.now.to_f * 1000 + 60_000).to_i)
      agent.active_probes['bw-probe'] = probe

      agent.send(:handle_capture, {
        probe_id: 'bw-probe',
        timestamp_ms: 1000,
        metric_value: 1.0
      })

      # Dropped due to no bandwidth tokens
      expect(agent.telemetry_queue_length).to eq(0)
    end
  end
end
