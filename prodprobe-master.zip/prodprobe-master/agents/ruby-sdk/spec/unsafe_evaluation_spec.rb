# frozen_string_literal: true

require 'spec_helper'
require 'tempfile'

RSpec.describe 'Opt-in evaluation through live probes' do
  let(:events) { [] }
  let(:calls) { [] }
  let(:quota) { HyperProbe::Core::QuotaManager.new(100, 1024 * 1024) }
  let(:safety) { HyperProbe::Core::SafetyMonitor.new(proc {}, is_ephemeral_lambda: true) }
  let(:engine) { HyperProbe::Core::MonitoringEngine.new(quota, safety, proc { |event| events << event }) }
  let(:service) do
    recorded = calls
    Object.new.tap do |receiver|
      { allowed?: true, details: { 'password' => 'hidden', 'value' => 7 },
        label: 'confidential', score: 88.5, key: 'request-1' }.each do |name, value|
        receiver.define_singleton_method(name) { recorded << name; value }
      end
    end
  end

  before do
    allow(ENV).to receive(:[]).and_call_original
    allow(ENV).to receive(:[]).with('HYPERPROBE_DISABLE_SAFE_EVALUATION').and_return(nil)
  end

  after { engine.close }

  def with_target
    source = "def self.target(service)\n  value = 1\n  value += 1\n  value + 1\nend\n"
    Tempfile.create(['unsafe-evaluation', '.rb']) do |file|
      file.write(source)
      file.flush
      fixture = Module.new
      fixture.module_eval(source, file.path, 1)
      yield fixture, file.path
    end
  end

  it 'enables every expression path and restores restrictions without stale unsafe evaluation' do
    with_target do |fixture, path|
      probes = (1..5).map do |type|
        { id: type.to_s, type: type, runtime_location: path, runtime_line: 3,
          condition: 'service.allowed?', stack_frame_depth: 0 }
      end
      probes[0][:watch_expressions] = ['service.details']
      probes[1][:template] = '${service.label}'
      probes[3][:metric_expression] = 'service.score'
      probes[4].merge!(correlation_expression: 'service.key', secondary_runtime_line: 4)
      engine.set_probes(probes)

      expect(fixture.target(service)).to eq(3)
      expect(calls).to be_empty
      expect(events.length).to eq(6)
      expect(events.map { |event| event[:capture_error] }).to all(include('SecurityError'))

      events.clear
      engine.set_global_config(disable_safe_evaluation: true, redact_keys: ['password'], redact_values: ['confidential'])
      expect(fixture.target(service)).to eq(3)
      expect(events.length).to eq(5)
      expect(events.map { |event| event[:capture_error] }).to all(eq(''))
      by_probe = events.to_h { |event| [event[:probe_id], event] }
      watches = JSON.parse(by_probe['1'][:watch_results_json])
      expect(watches['service.details']).to eq('password' => '[REDACTED Key]', 'value' => 7)
      expect(by_probe['2'][:evaluated_log]).to eq('[REDACTED Value]')
      expect(by_probe['3'][:metric_value]).to eq(1.0)
      expect(by_probe['4'][:metric_value]).to eq(88.5)
      expect(by_probe['5'][:metric_value]).to be >= 0
      expect(calls.count(:key)).to eq(2)

      events.clear
      calls.clear
      engine.set_global_config('disable_safe_evaluation' => 'false')
      expect(fixture.target(service)).to eq(3)
      expect(calls).to be_empty
      expect(events.length).to eq(6)
      expect(events.map { |event| event[:capture_error] }).to all(include('SecurityError'))
    end
  end

  it 'does not allow a probe to opt itself into unrestricted evaluation' do
    with_target do |fixture, path|
      engine.set_probes([{ id: 'metric', type: 4, runtime_location: path, runtime_line: 3,
                           metric_expression: 'service.score', disable_safe_evaluation: true }])
      expect(fixture.target(service)).to eq(3)
      expect(calls).to be_empty
      expect(events.first[:capture_error]).to include('SecurityError')
    end
  end

  it 'passes the startup opt-in through broker sync to live evaluation and telemetry' do
    with_target do |fixture, path|
      probe = Hyperprobe::Agent::V1::Probe.new(
        id: 'metric', type: :PROBE_TYPE_METRIC, runtime_location: path, runtime_line: 3,
        metric_expression: 'service.score', hit_limit: 5
      )
      response = Hyperprobe::Agent::V1::GetProbesResponse.new(
        probes: [probe], global_config: Hyperprobe::Agent::V1::AgentGlobalConfig.new(max_object_depth: 1)
      )
      broker = double('broker', get_probes: response, estimate_event_size: 1, shutdown: nil)
      reported = []
      allow(broker).to receive(:report_telemetry) { |batch, *| reported.concat(batch); [] }
      allow(HyperProbe::Core::BrokerClient).to receive(:new).and_return(broker)
      allow(HyperProbe::Core::Logger.get_logger('hyperprobe:agent')).to receive(:warn)
      agent = HyperProbe::Agent.new(service_id: '11111111-2222-4333-8444-555555555555', environment: 'test',
                                    commit_sha: 'test', broker_url: 'localhost:60051', is_lambda: true,
                                    disable_safe_evaluation: true)
      agent.force_sync
      expect(fixture.target(service)).to eq(3)
      agent.force_flush
      expect(reported.length).to eq(1)
      expect(reported.first[:metric_value]).to eq(88.5)
      expect(calls).to eq([:score])
    ensure
      agent&.shutdown
    end
  end

  it 'keeps evaluation mode isolated between engines' do
    other_events = []
    other = HyperProbe::Core::MonitoringEngine.new(quota, safety, proc { |event| other_events << event })
    with_target do |fixture, path|
      probes = [{ id: 'metric', type: 4, runtime_location: path, runtime_line: 3, metric_expression: 'service.score' }]
      engine.set_global_config('disable_safe_evaluation' => ' TRUE ')
      engine.set_probes(probes)
      other.set_probes(probes)
      expect(fixture.target(service)).to eq(3)
      expect(events.first[:metric_value]).to eq(88.5)
      expect(other_events.first[:capture_error]).to include('SecurityError')
      expect(calls).to eq([:score])
    end
  ensure
    other&.close
  end
end
