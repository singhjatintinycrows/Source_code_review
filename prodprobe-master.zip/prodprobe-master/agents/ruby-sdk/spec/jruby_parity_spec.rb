# frozen_string_literal: true

require 'spec_helper'
require 'tempfile'

RSpec.describe 'JRuby Support & Full Parity' do
  let(:serializer) do
    HyperProbe::Core::Serializer.new(
      max_depth: 2,
      max_array_length: 3,
      max_object_properties: 3,
      max_string_length: 30,
      redact_keys: %w[secret token password],
      redact_values: %w[confidential]
    )
  end

  describe 'Java Object & Collection Serialization' do
    before { skip 'Real Java fixtures require JRuby' unless RUBY_PLATFORM.include?('java') }

    it 'serializes LinkedHashMap with key redaction and property truncation' do
      java_map = java.util.LinkedHashMap.new
      {
        'user_id' => 'USR-1',
        'password' => 'secretpass',
        'amount' => 99.99,
        'extra1' => 'val1',
        'extra2' => 'val2'
      }.each { |key, value| java_map.put(key, value) }

      result = serializer.serialize(java_map)
      expect(result['user_id']).to eq('USR-1')
      expect(result['password']).to eq('[REDACTED Key]')
      expect(result['amount']).to eq(99.99)
      expect(result['__probe_meta']).to eq('+ 2 more properties truncated')
    end

    it 'serializes ArrayList with array truncation and item recursion' do
      java_list = java.util.ArrayList.new([10, java.util.ArrayList.new([20]), 30, 40, 50])

      result = serializer.serialize(java_list)
      expect(result.length).to eq(4)
      expect(result[0..2]).to eq([10, [20], 30])
      expect(result[3]).to eq('[+ 2 more items truncated]')
    end

    it 'serializes LinkedHashSet in insertion order' do
      java_set = java.util.LinkedHashSet.new(['alpha', 'beta'])

      result = serializer.serialize(java_set)
      expect(result).to eq(['alpha', 'beta'])
    end

    it 'keeps POJOs and Throwables opaque without calling getters' do
      bean = java.util.concurrent.atomic.AtomicInteger.new(42)
      throwable = java.lang.RuntimeException.new('Database connection timeout')
      expect(bean).not_to receive(:get)
      expect(bean).not_to receive(:getAndIncrement)
      expect(throwable).not_to receive(:getMessage)
      expect(throwable).not_to receive(:getStackTrace)

      [bean, throwable].each do |object|
        expect(serializer.serialize(object)).to start_with('[Obj:')
      end
    end
  end

  describe 'Java APM Distributed Tracing on JRuby' do
    it 'extracts trace context from Java OpenTelemetry' do
      mock_span_context = double('SpanContext', getTraceId: '4bf92f3577b34da6a3ce929d0e0e4736')
      mock_span = double('Span', getSpanContext: mock_span_context)

      otel_class = Class.new do
        def self.current; end
      end
      stub_const('Java::IoOpentelemetryApiTrace::Span', otel_class)
      allow(Java::IoOpentelemetryApiTrace::Span).to receive(:current).and_return(mock_span)

      trace_id = HyperProbe::Core::TraceExtractor.extract_trace_context
      expect(trace_id).to eq('4bf92f3577b34da6a3ce929d0e0e4736')
    end

    it 'extracts trace context from Java Datadog tracer' do
      dd_class = Class.new do
        def self.getTraceId; end
      end
      stub_const('Java::DatadogTraceApi::CorrelationIdentifier', dd_class)
      allow(Java::DatadogTraceApi::CorrelationIdentifier).to receive(:getTraceId).and_return('1234567890123456789')

      trace_id = HyperProbe::Core::TraceExtractor.extract_trace_context
      expect(trace_id).to eq('1234567890123456789')
    end

    it 'extracts trace context from Java New Relic agent' do
      mock_metadata = double('TraceMetadata', getTraceId: 'nr-trace-abcdef123456')
      mock_agent = double('NewRelicAgent', getTraceMetadata: mock_metadata)

      nr_class = Class.new do
        def self.getAgent; end
      end
      stub_const('Java::ComNewrelicApiAgent::NewRelic', nr_class)
      allow(Java::ComNewrelicApiAgent::NewRelic).to receive(:getAgent).and_return(mock_agent)

      trace_id = HyperProbe::Core::TraceExtractor.extract_trace_context
      expect(trace_id).to eq('nr-trace-abcdef123456')
    end
  end

  describe 'JRuby Stack Frame Filtering' do
    it 'filters out JRuby internal runtime paths and Java reflection frames' do
      quota = HyperProbe::Core::QuotaManager.new(100, 1024 * 1024)
      safety = HyperProbe::Core::SafetyMonitor.new(->(_h, _r) {})
      events = []
      engine = HyperProbe::Core::MonitoringEngine.new(quota, safety, ->(e) { events << e })

      tmp = Tempfile.new(['jruby_stack_test', '.rb'])
      tmp.write(<<-RUBY)
        def compute_something
          x = 10
          y = 20 # Line 3
          x + y
        end
      RUBY
      tmp.close
      load tmp.path

      engine.set_probes([
        {
          id: 'probe-stack',
          type: 1, # SNAPSHOT
          runtime_location: tmp.path,
          runtime_line: 3
        }
      ])

      compute_something
      engine.close

      expect(events.length).to eq(1)
      frames = events.first[:stack_frames]
      expect(frames).not_to be_empty

      # Verify none of the frames contain JRuby internals
      frames.each do |frame|
        file = frame[:file_name]
        expect(file).not_to include('org/jruby/')
        expect(file).not_to include('java/lang/')
        expect(file).not_to include('sun/reflect')
        expect(file).not_to include('jdk/internal')
        expect(file).not_to include('hyperprobe/')
      end
    ensure
      engine&.close
      tmp&.unlink
    end
  end

  describe 'JRuby Multi-Threaded Execution Safety' do
    it 'handles concurrent probe hits from multiple threads without race conditions' do
      quota = HyperProbe::Core::QuotaManager.new(1000, 10 * 1024 * 1024)
      safety = HyperProbe::Core::SafetyMonitor.new(->(_h, _r) {})
      events = []
      mutex = Mutex.new
      engine = HyperProbe::Core::MonitoringEngine.new(quota, safety, ->(e) { mutex.synchronize { events << e } })

      tmp = Tempfile.new(['jruby_thread_test', '.rb'])
      tmp.write(<<-RUBY)
        class WorkerService
          def process_job(job_id)
            status = 'processing'
            count = job_id * 2 # Line 4
            status = 'done'
            count
          end
        end
      RUBY
      tmp.close
      load tmp.path

      engine.set_probes([
        {
          id: 'probe-threaded-counter',
          type: 3, # COUNTER
          runtime_location: tmp.path,
          runtime_line: 4
        }
      ])

      service = WorkerService.new
      threads = Array.new(10) do |i|
        Thread.new do
          5.times.map { service.process_job(i) }
        end
      end

      results = threads.map(&:value)
      engine.close

      expect(results).to eq(Array.new(10) { |i| Array.new(5, i * 2) })
      expect(events.length).to be_between(1, 50).inclusive
      expect(events).to all(include(probe_id: 'probe-threaded-counter', metric_value: 1.0))
    ensure
      threads&.each(&:join)
      engine&.close
      tmp&.unlink
    end
  end

  describe 'BrokerClient runtime parity' do
    it 'fetches probes and reports telemetry through the runtime transport' do
      mock_response = Hyperprobe::Agent::V1::GetProbesResponse.new(probes: [])
      mock_telemetry_response = Hyperprobe::Agent::V1::TelemetryResponse.new(finished_probe_ids: ['finished-p1'])

      client = HyperProbe::Core::BrokerClient.new(
        broker_url: 'localhost:60051',
        service_id: 'e2e2e2e2-e2e2-4e2e-8e2e-e2e2e2e2e2e2',
        environment: 'production',
        commit_sha: 'commit123'
      )

      if RUBY_PLATFORM =~ /java/
        transport = client.instance_variable_get(:@transport)
        expect(transport).to receive(:call).with('hyperprobe.agent.v1.AgentBroker/GetProbes', kind_of(String), kind_of(Numeric)) do |_, payload, _|
          request = Hyperprobe::Agent::V1::GetProbesRequest.decode(payload)
          expect(request.service_id).to eq(client.service_id)
          expect(request.language).to eq('jruby')
          mock_response.to_proto
        end
        expect(transport).to receive(:call).with('hyperprobe.agent.v1.AgentBroker/ReportTelemetry', kind_of(String), kind_of(Numeric)) do |_, payload, _|
          request = Hyperprobe::Agent::V1::TelemetryBatch.decode(payload)
          expect(request.events.first.probe_id).to eq('p1')
          expect(request.events.first.metric_value).to eq(10.0)
          mock_telemetry_response.to_proto
        end
      else
        probe_operation = double('GetProbes operation')
        telemetry_operation = double('ReportTelemetry operation')
        expect(probe_operation).to receive(:execute).and_return(mock_response)
        expect(telemetry_operation).to receive(:execute).and_return(mock_telemetry_response)
        expect(client.stub).to receive(:get_probes).with(
          have_attributes(service_id: client.service_id, language: 'ruby'),
          metadata: { 'x-hp-service-id' => client.service_id }, deadline: kind_of(Time), return_op: true
        ).and_return(probe_operation)
        expect(client.stub).to receive(:report_telemetry).with(
          have_attributes(events: contain_exactly(have_attributes(probe_id: 'p1', metric_value: 10.0))),
          metadata: { 'x-hp-service-id' => client.service_id }, deadline: kind_of(Time), return_op: true
        ).and_return(telemetry_operation)
      end

      response = client.get_probes(5.0)
      expect(response).to eq(mock_response)

      finished = client.report_telemetry([{ probe_id: 'p1', metric_value: 10.0 }], 5.0)
      expect(finished).to eq(['finished-p1'])
    ensure
      client&.shutdown
    end

    %w[localhost:50051 http://localhost:50051 https://localhost:50051].each do |url|
      it "supports shutdown-safe transport configuration for #{url}" do
        client = HyperProbe::Core::BrokerClient.new(
          broker_url: url, service_id: 'service', environment: 'test', commit_sha: 'commit',
          enable_keep_alive: false
        )

        expect(client.report_telemetry([])).to eq([])
        expect { 2.times { client.shutdown } }.not_to raise_error
        expect { client.get_probes(0.1) }.to raise_error(StandardError)
      ensure
        client&.shutdown
      end
    end
  end

  describe 'JRuby Version Gating' do
    let(:opts) do
      {
        service_id: 'e2e2e2e2-e2e2-4e2e-8e2e-e2e2e2e2e2e2',
        environment: 'production',
        broker_url: 'localhost:60051',
        commit_sha: 'commit123'
      }
    end

    %w[9.1.17.0 9.2.20.1].each do |version|
      it "blocks execution and warns on unsupported JRuby #{version}" do
        stub_const('JRUBY_VERSION', version)
        stub_const('RUBY_PLATFORM', 'java')
        expect(HyperProbe::Core::BrokerClient).not_to receive(:new)

        expect { expect(HyperProbe.start(opts)).to be_nil }.to output(/JRuby 9\.3\+ is required/).to_stderr
      end
    end

    it 'blocks execution and warns on legacy CRuby < 3.0' do
      hide_const('JRUBY_VERSION') if defined?(JRUBY_VERSION)
      stub_const('RUBY_PLATFORM', 'x86_64-darwin')
      stub_const('RUBY_VERSION', '2.7.5')

      agent = HyperProbe.start(opts)
      expect(agent).to be_nil
    end

    it 'blocks execution on JRuby when --debug flag is missing' do
      stub_const('JRUBY_VERSION', '9.4.15.0')
      stub_const('RUBY_PLATFORM', 'java')
      allow(HyperProbe).to receive(:jruby_debug_enabled?).and_return(false)

      agent = HyperProbe.start(opts)
      expect(agent).to be_nil
    end

    it 'rejects default optimization passes even with full tracing enabled' do
      stub_const('JRUBY_VERSION', '9.4.15.0')
      stub_const('RUBY_PLATFORM', 'java')
      allow(HyperProbe).to receive(:jruby_debug_enabled?).and_return(true)
      allow(HyperProbe).to receive(:jruby_scope_preservation_enabled?).and_return(false)
      expect(HyperProbe::Core::BrokerClient).not_to receive(:new)
      expect { expect(HyperProbe.start(opts)).to be_nil }.to output(/compiled JRuby probes require/).to_stderr
    end

    %w[9.3.15.0 9.4.15.0 10.1.1.0].each do |version|
      it "permits JRuby #{version} with the required tracing profile" do
        stub_const('JRUBY_VERSION', version)
        stub_const('RUBY_PLATFORM', 'java')
        allow(HyperProbe).to receive(:jruby_debug_enabled?).and_return(true)
        allow(HyperProbe).to receive(:jruby_scope_preservation_enabled?).and_return(true)

        broker = instance_double(HyperProbe::Core::BrokerClient,
                                 get_probes: Hyperprobe::Agent::V1::GetProbesResponse.new(probes: []),
                                 shutdown: nil)
        expect(HyperProbe::Core::BrokerClient).to receive(:new).and_return(broker)

        agent = HyperProbe.start(opts)
        expect(agent).to be_a(HyperProbe::Agent)
        expect(agent.is_shutdown).to be false
      ensure
        HyperProbe.shutdown
      end
    end
  end
end
