# frozen_string_literal: true

require 'spec_helper'
require 'tempfile'

RSpec.describe 'Duration & Metric Probes Parity' do
  let(:quota) { HyperProbe::Core::QuotaManager.new(100, 1024 * 1024) }
  let(:safety) { HyperProbe::Core::SafetyMonitor.new(->(_h, _r) {}) }
  let(:events) { [] }
  let(:on_capture) { ->(evt) { events << evt } }

  subject(:engine) do
    HyperProbe::Core::MonitoringEngine.new(quota, safety, on_capture)
  end

  after { engine.close }

  describe 'Metric Expression Coercion (Node.js parseFloat Parity)' do
    it 'accepts valid numeric values, strings with numeric prefixes, and exponents' do
      expect(HyperProbe::Core::Evaluator.coerce_metric_value(12.5)).to eq(12.5)
      expect(HyperProbe::Core::Evaluator.coerce_metric_value('  -12.5ms')).to eq(-12.5)
      expect(HyperProbe::Core::Evaluator.coerce_metric_value('1e2 remainder')).to eq(100.0)
      expect(HyperProbe::Core::Evaluator.coerce_metric_value('0x10')).to eq(0.0)
    end

    it 'returns nil for booleans, hashes, non-finite floats, and invalid strings' do
      expect(HyperProbe::Core::Evaluator.coerce_metric_value(true)).to be_nil
      expect(HyperProbe::Core::Evaluator.coerce_metric_value(false)).to be_nil
      expect(HyperProbe::Core::Evaluator.coerce_metric_value(0.0 / 0.0)).to be_nil
      expect(HyperProbe::Core::Evaluator.coerce_metric_value(1.0 / 0.0)).to be_nil
      expect(HyperProbe::Core::Evaluator.coerce_metric_value('not-a-number')).to be_nil
      expect(HyperProbe::Core::Evaluator.coerce_metric_value({})).to be_nil
    end
  end

  describe 'Duration Probes: Cross-File and Correlation Handling' do
    let(:tmp_file_a) do
      f = Tempfile.new(['cross_file_a', '.rb'])
      f.write(<<-RUBY)
        def start_workflow(req_id)
          start_tag = 'starting' # Line 2
        end
      RUBY
      f.close
      f
    end

    let(:tmp_file_b) do
      f = Tempfile.new(['cross_file_b', '.rb'])
      f.write(<<-RUBY)
        def end_workflow(req_id)
          end_tag = 'ending' # Line 2
        end
      RUBY
      f.close
      f
    end

    before do
      load tmp_file_a.path
      load tmp_file_b.path
    end

    after do
      tmp_file_a.unlink
      tmp_file_b.unlink
    end

    it 'measures duration across different files and correlations' do
      engine.set_probes([
        {
          id: 'cross-file-duration',
          type: 5, # DURATION
          runtime_location: tmp_file_a.path,
          runtime_line: 2,
          secondary_runtime_location: tmp_file_b.path,
          secondary_runtime_line: 2,
          correlation_expression: 'req_id'
        }
      ])

      start_workflow('job-999')
      sleep 0.01 # 10ms
      end_workflow('job-999')

      expect(events.length).to eq(1)
      evt = events.first
      expect(evt[:probe_id]).to eq('cross-file-duration')
      expect(evt[:metric_value]).to be >= 5.0 # At least 5ms
    end

    it 'silently ignores unmatched secondary duration hits' do
      engine.set_probes([
        {
          id: 'unmatched-duration',
          type: 5, # DURATION
          runtime_location: tmp_file_a.path,
          runtime_line: 2,
          secondary_runtime_location: tmp_file_b.path,
          secondary_runtime_line: 2,
          correlation_expression: 'req_id'
        }
      ])

      # Call end without start
      end_workflow('unknown-job')

      expect(events).to be_empty
    end

    it 'normalizes numeric correlations (integer vs float vs string)' do
      expect(HyperProbe::Core::Evaluator.normalize_correlation_value(1)).to eq('1')
      expect(HyperProbe::Core::Evaluator.normalize_correlation_value(1.0)).to eq('1')
      expect(HyperProbe::Core::Evaluator.normalize_correlation_value('1')).to eq('1')
      expect(HyperProbe::Core::Evaluator.normalize_correlation_value(nil)).to eq('static-singleton')
    end

    it 'rejects invalid correlation types with error' do
      expect do
        HyperProbe::Core::Evaluator.normalize_correlation_value(true)
      end.to raise_error(TypeError, /boolean/)

      expect do
        HyperProbe::Core::Evaluator.normalize_correlation_value({ a: 1 })
      end.to raise_error(TypeError, /Hash/)
    end
  end

  describe 'Counter Probe Trace ID Capture' do
    let(:tmp_file) do
      f = Tempfile.new(['counter_trace_target', '.rb'])
      f.write(<<-RUBY)
        def trace_test_action
          count = 1 # Line 2
        end
      RUBY
      f.close
      f
    end

    before { load tmp_file.path }
    after { tmp_file.unlink }

    it 'captures trace_id on counter probe when should_capture_trace_id is true' do
      custom_trace_getter = -> { 'trace-abc-123' }
      engine_with_trace = HyperProbe::Core::MonitoringEngine.new(
        quota,
        safety,
        on_capture,
        custom_trace_getter
      )

      engine_with_trace.set_probes([
        {
          id: 'trace-counter',
          type: 3, # COUNTER
          runtime_location: tmp_file.path,
          runtime_line: 2,
          should_capture_trace_id: true
        }
      ])

      trace_test_action
      engine_with_trace.close

      expect(events.length).to eq(1)
      expect(events.first[:probe_id]).to eq('trace-counter')
      expect(events.first[:metric_value]).to eq(1.0)
      expect(events.first[:trace_id]).to eq('trace-abc-123')
    end
  end
end
