# frozen_string_literal: true

require 'spec_helper'

RSpec.describe 'Legacy-compatible bounded primitives' do
  it 'preserves symbol-keyed watches and captured Ruby fields' do
    data = { total: 42, password: 'hidden' }
    object = Object.new
    object.instance_variable_set(:@total, 42)
    object.instance_variable_set(:@password, 'hidden')
    expect(HyperProbe::Core::Evaluator.evaluate_watches(['data[:total]', ':total'], binding))
      .to eq('data[:total]' => 42, ':total' => :total)
    serializer = HyperProbe::Core::Serializer.new(redact_keys: ['password'])
    expected = { 'total' => 42, 'password' => '[REDACTED Key]' }
    expect(serializer.serialize(data)).to eq(expected)
    expect(serializer.serialize(object)).to eq(expected)
  end

  it 'bounds long symbol names before conversion or output' do
    large = ('s' * 65_536).to_sym
    result = HyperProbe::Core::Evaluator.evaluate_watches(['large'], binding)['large']
    expect(result).to include('Symbol exceeds expression limit')
    serialized = HyperProbe::Core::Serializer.new(max_string_length: 32).serialize(large)
    expect(serialized.bytesize).to be < 128
    expect(serialized).to include('Truncated')
  end

  it 'does not expose a string subclass or invoke its conversion hooks' do
    calls = []
    subclass = Class.new(String) do
      define_method(:encode) { |*| calls << :encode; raise 'application encoding hook' }
      define_method(:to_str) { calls << :to_str; raise 'application conversion hook' }
      define_method(:to_s) { calls << :to_s; raise 'application string hook' }
    end
    result = HyperProbe::Core::Serializer.new.serialize(subclass.new('safe'))
    expect(result).to eq('safe')
    expect(result.class).to eq(String)
    expect(calls).to be_empty
  end

  it 'accepts explicit lengths but still rejects safe-navigation and arbitrary calls' do
    data = [1, 2]
    evaluator = HyperProbe::Core::Evaluator
    expect(evaluator.evaluate_metric('data.length', binding)).to eq(2.0)
    expect(evaluator.evaluate_metric('data.size()', binding)).to eq(2.0)
    expect { evaluator.evaluate_metric('data&.length', binding) }.to raise_error(SecurityError)
    expect { evaluator.evaluate_metric('data.clear', binding) }.to raise_error(SecurityError)
    expect(data).to eq([1, 2])
  end
end
