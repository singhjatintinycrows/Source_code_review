# frozen_string_literal: true

require 'spec_helper'

RSpec.describe HyperProbe::Core::Serializer do
  subject(:serializer) do
    described_class.new(
      max_depth: 2,
      max_array_length: 3,
      max_object_properties: 3,
      max_string_length: 20,
      redact_keys: %w[secret token password],
      redact_values: %w[confidential]
    )
  end

  it 'serializes primitives correctly' do
    expect(serializer.serialize(nil)).to be_nil
    expect(serializer.serialize(true)).to be true
    expect(serializer.serialize(false)).to be false
    expect(serializer.serialize(42)).to eq(42)
    expect(serializer.serialize(3.14)).to eq(3.14)
    expect(serializer.serialize(:my_symbol)).to eq('my_symbol')
  end

  it 'serializes non-finite floats as strings' do
    expect(serializer.serialize(0.0 / 0.0)).to eq('NaN')
    expect(serializer.serialize(1.0 / 0.0)).to eq('Infinity')
    expect(serializer.serialize(-1.0 / 0.0)).to eq('-Infinity')
  end

  it 'truncates long strings and applies value redaction' do
    long_str = 'confidential: ' + ('x' * 50)
    result = serializer.serialize(long_str)
    expect(result).to include('[Truncated: +')
    expect(result).to include('[REDACTED Value]')
  end

  it 'redacts sensitive keys in hashes and objects' do
    data = {
      'secret' => '12345',
      'password' => 'secretpass',
      'username' => 'alice'
    }
    result = serializer.serialize(data)
    expect(result['secret']).to eq('[REDACTED Key]')
    expect(result['password']).to eq('[REDACTED Key]')
    expect(result['username']).to eq('alice')
  end

  it 'truncates arrays beyond max_array_length' do
    arr = [1, 2, 3, 4, 5]
    result = serializer.serialize(arr)
    expect(result.length).to eq(4)
    expect(result[0..2]).to eq([1, 2, 3])
    expect(result[3]).to eq('[+ 2 more items truncated]')
  end

  it 'truncates hash properties beyond max_object_properties' do
    hash = { 'a' => 1, 'b' => 2, 'c' => 3, 'd' => 4, 'e' => 5 }
    result = serializer.serialize(hash)
    expect(result['a']).to eq(1)
    expect(result['b']).to eq(2)
    expect(result['c']).to eq(3)
    expect(result['__probe_meta']).to eq('+ 2 more properties truncated')
  end

  it 'handles cyclic references cleanly' do
    node_a = { 'name' => 'A' }
    node_b = { 'name' => 'B', 'prev' => node_a }
    node_a['next'] = node_b

    result = serializer.serialize(node_a)
    expect(result['name']).to eq('A')
    expect(result['next']['prev']).to eq('[REF - $]')
  end

  it 'formats time objects and keeps exception payloads opaque' do
    t = Time.utc(2026, 8, 27, 12, 0, 0)
    expect(serializer.serialize(t)).to eq('2026-08-27T12:00:00Z')

    err = StandardError.new('Something went wrong')
    err.set_backtrace(['file1.rb:10', 'file2.rb:20'])
    serialized_err = serializer.serialize(err)
    expect(serialized_err).to eq('[Obj: StandardError]')
  end

  it 'caps depth recursion with object summaries' do
    deep = { 'lvl1' => { 'lvl2' => { 'lvl3' => { 'leaf' => 42 } } } }
    result = serializer.serialize(deep)
    expect(result['lvl1']['lvl2']['lvl3']).to eq('[Obj: 1 keys]')
  end

  it 'safely serializes BasicObject instances without raising NoMethodError' do
    bo = BasicObject.new
    result = serializer.serialize(bo)
    expect(result).to eq('[Obj: BasicObject]')
  end

  it 'safely sanitizes invalid UTF-8 byte sequences without raising ArgumentError' do
    invalid_utf8 = "\xFF\xFEhello".dup.force_encoding('UTF-8')
    expect {
      result = serializer.serialize(invalid_utf8)
      expect(result).to include('hello')
    }.not_to raise_error
  end
end
