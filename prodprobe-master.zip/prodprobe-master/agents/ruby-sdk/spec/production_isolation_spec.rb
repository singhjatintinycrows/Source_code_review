# frozen_string_literal: true

require 'spec_helper'
require 'tempfile'
require 'open3'

RSpec.describe 'Production failure isolation' do
  let(:events) { [] }
  let(:quota) { HyperProbe::Core::QuotaManager.new(100, 1024 * 1024) }
  let(:safety) { HyperProbe::Core::SafetyMonitor.new(->(*) {}) }
  let(:engine) { HyperProbe::Core::MonitoringEngine.new(quota, safety, ->(event) { events << event }) }
  let(:options) do
    { service_id: '11111111-2222-4333-8444-555555555555', environment: 'test',
      broker_url: 'localhost:60051', commit_sha: 'isolation-test', is_lambda: true }
  end

  after { engine.close }

  def fixture(source)
    Tempfile.create(['hyperprobe-isolation', '.rb']) do |file|
      file.write(source)
      file.flush
      load file.path
      yield file.path
    end
  end

  def probe(path, type: 3, line: 3, **overrides)
    { id: 'safe', type: type, runtime_location: path, runtime_line: line }.merge(overrides)
  end

  def subprocess_ruby
    return [RbConfig.ruby] unless RbConfig.ruby.start_with?('uri:')
    [File.join(java.lang.System.getProperty('java.home'), 'bin/java'), '-cp',
     java.lang.System.getProperty('java.class.path'), 'org.jruby.Main']
  end

  it 'rejects unsafe live metrics without changing the application result' do
    fixture("def isolation_metric(items)\n  result = items.length\n  result + 1\nend\n") do |path|
      engine.set_probes([probe(path, type: 4, metric_expression: 'items.push(99)')])
      items = [1]
      expect(isolation_metric(items)).to eq(2)
      expect(items).to eq([1])
      expect(events.first[:capture_error]).to include('SecurityError')
    end
  end

  it 'isolates fatal exceptions raised by agent capture code' do
    fixture("def isolation_host\n  value = 40\n  value + 2\nend\n") do |path|
      broken = HyperProbe::Core::MonitoringEngine.new(quota, safety, ->(*) { raise SecurityError, 'agent fault' })
      begin
        broken.set_probes([probe(path)])
        expect(isolation_host).to eq(42)
      ensure
        broken.close
      end
    end
  end

  it 'does not wait for an engine update lock on the application thread' do
    fixture("def isolation_contention\n  value = 40\n  value + 2\nend\n") do |path|
      engine.set_probes([probe(path)])
      entered = Queue.new
      release = Queue.new
      worker = Thread.new do
        engine.instance_variable_get(:@mutex).synchronize do
          entered.push(true)
          release.pop
        end
      end
      entered.pop
      begin
        started = Process.clock_gettime(Process::CLOCK_MONOTONIC)
        expect(isolation_contention).to eq(42)
        expect(Process.clock_gettime(Process::CLOCK_MONOTONIC) - started).to be < 0.2
        expect(events).to be_empty
      ensure
        release.push(true)
        worker.join(1)
      end
    end
  end

  it 'rejects stale generations instead of reinstalling completed probes' do
    fixture("def isolation_generation\n  value = 40\n  value + 2\nend\n") do |path|
      engine.set_probes([], generation: 2)
      engine.set_probes([probe(path)], generation: 1)
      expect(isolation_generation).to eq(42)
      expect(events).to be_empty
      expect(engine.is_active).to be false
    end
  end

  it 'omits closure variables by default and labels explicitly requested closures' do
    fixture("def isolation_scope(outer)\n  [1].map do |item|\n    local = item * 2\n    local\n  end\nend\n") do |path|
      engine.set_probes([probe(path, type: 1, line: 4)])
      expect(isolation_scope('private')).to eq([2])
      scopes = JSON.parse(events.last[:captured_vars_json]).first
      expect(scopes.first['vars']).to include('item' => 1, 'local' => 2)
      expect(scopes.to_s).not_to include('private')

      engine.set_probes([probe(path, type: 1, line: 4, capture_closures: true)])
      isolation_scope('private')
      scopes = JSON.parse(events.last[:captured_vars_json]).first
      expect(scopes.find { |scope| scope['type'] == 'closure' }['vars']).to include('outer' => 'private')
      if RUBY_ENGINE == 'ruby'
        caller_index = events.last[:stack_frames].index do |frame|
          frame[:function_name].end_with?('isolation_scope') && !frame[:function_name].include?('block')
        end
        expect(caller_index).not_to be_nil
        caller_scopes = JSON.parse(events.last[:captured_vars_json])[caller_index]
        expect(caller_scopes.first['vars']).to include('outer' => 'private')
      else
        expect(JSON.parse(events.last[:captured_vars_json]).drop(1).all? { |frame| frame.first['vars'].empty? }).to be true
      end
    end
  end

  it 'honors zero-valued protobuf overrides rather than inheriting positive limits' do
    fixture("def isolation_zero(items)\n  value = items.length\n  value\nend\n") do |path|
      engine.set_global_config(max_array_length: 3, stack_frame_depth: 3)
      p = Hyperprobe::Agent::V1::Probe.new(id: 'safe', type: :PROBE_TYPE_SNAPSHOT,
                                         runtime_location: path, runtime_line: 3,
                                         max_array_length: 0, stack_frame_depth: 0,
                                         watch_expressions: ['items'])
      engine.set_probes([p])
      expect(isolation_zero([10, 20])).to eq(2)
      expect(events.last[:stack_frames]).to eq([])
      expect(JSON.parse(events.last[:captured_vars_json])).to eq([])
      expect(JSON.parse(events.last[:watch_results_json])['items']).to eq(['[+ 2 more items truncated]'])
    end
  end

  it 'emits a duration with one token for the completed measurement' do
    fixture("def isolation_duration\n  value = 40\n  result = value + 2\n  result\nend\n") do |path|
      one = HyperProbe::Core::QuotaManager.new(1, 1024 * 1024)
      timer = HyperProbe::Core::MonitoringEngine.new(one, safety, ->(event) { events << event })
      begin
        timer.set_probes([probe(path, type: 5, line: 2, secondary_runtime_line: 4)])
        expect(isolation_duration).to eq(42)
        expect(events.length).to eq(1)
        expect(events.first[:metric_value]).to be >= 0
      ensure
        timer.close
      end
    end
  end

  it 'leaves application signal handlers working when a probe fires inside them' do
    skip 'CRuby trap mutex restriction' if RUBY_PLATFORM.include?('java')
    fixture("def isolation_signal\n  value = 40\n  value + 2\nend\n") do |path|
      engine.set_probes([probe(path)])
      result = nil
      previous = Signal.trap('USR2') { result = isolation_signal }
      begin
        Process.kill('USR2', Process.pid)
        deadline = Process.clock_gettime(Process::CLOCK_MONOTONIC) + 1
        Thread.pass until result || Process.clock_gettime(Process::CLOCK_MONOTONIC) >= deadline
        expect(result).to eq(42)
      ensure
        Signal.trap('USR2', previous)
      end
    end
  end

  it 'does not expose startup exceptions or publish a failed agent' do
    allow(HyperProbe::Core::BrokerClient).to receive(:new).and_raise(LoadError, 'broken transport')
    expect(HyperProbe.start(options)).to be_nil
    expect(HyperProbe.instance).to be_nil
  end

  it 'returns a working handler if initialization or flush raises an agent exception' do
    agent = double('agent', agent_disabled?: false)
    allow(HyperProbe).to receive(:instance).and_return(agent)
    allow(agent).to receive(:force_sync).and_raise(LoadError, 'missing transport')
    allow(agent).to receive(:force_flush).and_raise(SecurityError, 'broken cleanup')
    wrapped = HyperProbe.wrap_lambda(options) { |event:, context:| event }
    expect(wrapped.call(event: 42, context: Object.new)).to eq(42)
    failing = HyperProbe.wrap_lambda(options) { |event:, context:| raise ArgumentError, 'host error' }
    expect { failing.call(event: 42, context: Object.new) }.to raise_error(ArgumentError, 'host error')
  end

  it 'loads harmlessly when the transport dependency cannot be loaded' do
    code = <<~RUBY
      module Kernel
        alias original_require require
        def require(path)
          raise LoadError, 'unavailable' if path == 'google/protobuf'
          original_require(path)
        end
      end
      require 'hyperprobe'
      raise 'agent unexpectedly started' if HyperProbe.start
      puts 'host healthy'
    RUBY
    out, status = Open3.capture2e(*subprocess_ruby, '-I', File.expand_path('../lib', __dir__), '-e', code)
    expect(status.success?).to be true
    expect(out).to include('host healthy')
  end

  it 'cancels in-flight startup instead of publishing after shutdown' do
    entered = Queue.new
    release = Queue.new
    stopped = false
    candidate = double('candidate', is_shutdown: false)
    allow(candidate).to receive(:shutdown) { stopped = true }
    allow(HyperProbe::Agent).to receive(:new) do
      entered.push(true)
      release.pop
      candidate
    end
    starter = Thread.new { HyperProbe.start(options) }
    entered.pop
    HyperProbe.shutdown
    release.push(true)
    expect(starter.join(2)).to eq(starter)
    expect(starter.value).to be_nil
    expect(HyperProbe.instance).to be_nil
    expect(stopped).to be true
  ensure
    starter&.kill
  end

  it 'does not detach a replacement while an older shutdown finishes' do
    old = HyperProbe.start(options)
    entered = Queue.new
    release = Queue.new
    allow(old).to receive(:shutdown).and_wrap_original do |original|
      entered.push(true)
      release.pop
      original.call
    end
    stopping = Thread.new { HyperProbe.shutdown }
    entered.pop
    HyperProbe.shutdown
    replacement = HyperProbe.start(options)
    release.push(true)
    expect(stopping.join(2)).to eq(stopping)
    expect(HyperProbe.instance).to equal(replacement)
    expect(replacement.is_shutdown).to be false
  ensure
    stopping&.kill
  end

  it 'eventually shuts down even if the lifecycle lock is briefly busy' do
    old = HyperProbe.start(options)
    entered = Queue.new
    release = Queue.new
    holder = Thread.new do
      HyperProbe.instance_variable_get(:@mutex).synchronize do
        entered.push(true)
        release.pop
      end
    end
    entered.pop
    HyperProbe.shutdown
    release.push(true)
    holder.join(1)
    deadline = Process.clock_gettime(Process::CLOCK_MONOTONIC) + 2
    Thread.pass until old.is_shutdown || Process.clock_gettime(Process::CLOCK_MONOTONIC) >= deadline
    expect(HyperProbe.instance).to be_nil
    expect(old.is_shutdown).to be true
  ensure
    holder&.kill
  end

  it 'preserves external SIGINT rather than invoking a Lambda handler after cancellation' do
    skip 'Exercise native CRuby SIGINT delivery' if RUBY_PLATFORM.include?('java')
    code = <<~RUBY
      require 'hyperprobe'
      agent = Object.new
      def agent.agent_disabled?; false; end
      def agent.force_sync(*)
        Process.kill('INT', Process.pid)
        sleep 0.2
      end
      def agent.force_flush(*); end
      HyperProbe.define_singleton_method(:instance) { agent }
      handler = HyperProbe.wrap_lambda(is_lambda: true) { |**| abort 'handler executed after cancellation' }
      begin
        handler.call(event: {}, context: Object.new)
        abort 'interrupt swallowed'
      rescue Interrupt
        puts 'host cancellation preserved'
      end
    RUBY
    out, status = Open3.capture2e(*subprocess_ruby, '-I', File.expand_path('../lib', __dir__), '-e', code)
    expect(status.success?).to be true
    expect(out).to include('host cancellation preserved')
  end

  it 'starts safely after a deferred fork and blocks inherited restart after shutdown' do
    skip 'JRuby does not support fork' if RUBY_PLATFORM.include?('java')
    code = <<~RUBY
      require 'hyperprobe'
      options = #{options.inspect}
      HyperProbe.start(options.merge(defer_start: true))
      raise 'started in parent' if HyperProbe.instance
      pid = fork do
        child = HyperProbe.after_fork
        good = child && !child.is_shutdown
        HyperProbe.shutdown
        exit!(good ? 0 : 1)
      end
      _, status = Process.wait2(pid)
      raise 'deferred child failed' unless status.success?
      raise 'parent startup failed' unless HyperProbe.start(options)
      pid = fork do
        HyperProbe.shutdown
        exit!(HyperProbe.start(options).nil? ? 0 : 1)
      end
      _, status = Process.wait2(pid)
      HyperProbe.shutdown
      raise 'inherited child restarted' unless status.success?
      puts 'fork ownership preserved'
    RUBY
    out, status = Open3.capture2e(*subprocess_ruby, '-I', File.expand_path('../lib', __dir__), '-e', code)
    expect(status.success?).to be true
    expect(out).to include('fork ownership preserved')
  end

  it 'preserves application TERM handlers that exit during an agent RPC' do
    skip 'Exercise native CRuby signal traps' if RUBY_PLATFORM.include?('java')
    code = <<~RUBY
      require 'hyperprobe'
      Signal.trap('TERM') { exit 7 }
      agent = Object.new
      def agent.agent_disabled?; false; end
      def agent.force_sync(*)
        Process.kill('TERM', Process.pid)
        sleep 0.2
      end
      def agent.force_flush(*); end
      HyperProbe.define_singleton_method(:instance) { agent }
      handler = HyperProbe.wrap_lambda(is_lambda: true) { |**| puts 'handler must not run' }
      handler.call(event: {}, context: Object.new)
    RUBY
    out, status = Open3.capture2e(*subprocess_ruby, '-I', File.expand_path('../lib', __dir__), '-e', code)
    expect(status.exitstatus).to eq(7)
    expect(out).not_to include('handler must not run')
  end

  it 'drops diagnostics instead of blocking on a full application output pipe' do
    reader, writer = IO.pipe
    loop do
      break if writer.write_nonblock('x' * 4096, exception: false) == :wait_writable
    end
    previous = $stdout
    begin
      $stdout = writer
      started = Process.clock_gettime(Process::CLOCK_MONOTONIC)
      HyperProbe::Core::Logger.new.warn('agent diagnostic')
      expect(Process.clock_gettime(Process::CLOCK_MONOTONIC) - started).to be < 0.2
    ensure
      $stdout = previous
      reader.close
      writer.close
    end
  end
end
