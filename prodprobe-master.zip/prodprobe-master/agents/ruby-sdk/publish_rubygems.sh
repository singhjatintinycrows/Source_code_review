#!/usr/bin/env bash
# publish_rubygems.sh
# Automates building, verifying, and publishing the hyperprobe-agent gem to RubyGems.org.

set -Eeuo pipefail

# Colors for terminal output
if [[ -t 1 && -z "${NO_COLOR:-}" ]]; then
    GREEN='\033[0;32m'
    BLUE='\033[0;34m'
    RED='\033[0;31m'
    YELLOW='\033[0;33m'
    NC='\033[0m'
else
    GREEN=''
    BLUE=''
    RED=''
    YELLOW=''
    NC=''
fi

readonly RUBYGEMS_PROJECT_URL="https://rubygems.org/gems/hyperprobe-agent"
readonly EXPECTED_GEM_NAME="hyperprobe-agent"

ASSUME_YES=false
DRY_RUN=false
SKIP_TESTS=false
TARGET_VERSION="${VERSION:-}"
API_KEY="${GEM_HOST_API_KEY:-${RUBYGEMS_API_KEY:-}}"

info() {
    printf '%b\n' "${BLUE}$*${NC}"
}

success() {
    printf '%b\n' "${GREEN}$*${NC}"
}

warn() {
    printf '%b\n' "${YELLOW}Warning: $*${NC}"
}

fail() {
    printf '%b\n' "${RED}Error: $*${NC}" >&2
    exit 1
}

usage() {
    cat <<'EOF'
Usage: ./publish_rubygems.sh [OPTIONS]

Build, validate, and upload both ruby and java hyperprobe-agent gems to RubyGems.org.
Requires Maven and JDK 11+ to bundle the Java transport before packaging.
Tests also require JRuby 9.3.15+ with its test gems installed (HYPERPROBE_JRUBY overrides jruby).

Options:
  --version <ver>  Set a specific release version in lib/hyperprobe/version.rb.
  --yes, -y        Confirm the release non-interactively (required for CI).
  --dry-run        Build, test, and validate gem package without publishing.
  --skip-tests     Skip running RSpec test suite prior to packaging.
  --help, -h       Show this help text.

Credentials:
  Set GEM_HOST_API_KEY or RUBYGEMS_API_KEY to a scoped RubyGems API token.
  Alternatively, ensure credentials exist in ~/.gem/credentials (via `gem signin`).
  When run interactively, the script will prompt if no credentials are found.

Examples:
  ./publish_rubygems.sh --dry-run
  VERSION="1.2.26" ./publish_rubygems.sh --yes
  GEM_HOST_API_KEY="rubygems_..." ./publish_rubygems.sh --version 1.2.26 --yes
EOF
}

cleanup() {
    local exit_code=$?
    API_KEY=""
    unset GEM_HOST_API_KEY RUBYGEMS_API_KEY
    return "$exit_code"
}

trap cleanup EXIT
trap 'exit 130' INT
trap 'exit 143' TERM

# Parse command line arguments
while [[ $# -gt 0 ]]; do
    case "$1" in
        --version)
            [[ -n "${2:-}" ]] || fail "--version requires a version argument"
            TARGET_VERSION="$2"
            shift
            ;;
        --yes|-y)
            ASSUME_YES=true
            ;;
        --dry-run)
            DRY_RUN=true
            ;;
        --skip-tests)
            SKIP_TESTS=true
            ;;
        --help|-h)
            usage
            exit 0
            ;;
        *)
            usage >&2
            fail "Unknown argument: $1"
            ;;
    esac
    shift
done

printf '%b\n' "${BLUE}====================================================${NC}"
printf '%b\n' "${BLUE}       HyperProbe RubyGems Release Script           ${NC}"
printf '%b\n' "${BLUE}====================================================${NC}"

# 1. Resolve working directory
SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd -P)"
readonly SCRIPT_DIR
readonly PKG_DIR="$SCRIPT_DIR/pkg"
readonly GEMSPEC_FILE="$SCRIPT_DIR/hyperprobe-agent.gemspec"
readonly VERSION_FILE="$SCRIPT_DIR/lib/hyperprobe/version.rb"

cd -- "$SCRIPT_DIR"

[[ -f "$GEMSPEC_FILE" ]] || fail "hyperprobe-agent.gemspec not found in $SCRIPT_DIR."
[[ -f "$VERSION_FILE" ]] || fail "lib/hyperprobe/version.rb not found in $SCRIPT_DIR."

# 2. Check Ruby and Gem toolchain
command -v ruby >/dev/null 2>&1 || fail "Ruby executable was not found in PATH."
command -v gem >/dev/null 2>&1 || fail "gem CLI tool was not found in PATH."
command -v bundle >/dev/null 2>&1 || fail "Bundler (bundle) was not found in PATH."

RUBY_VER=$(ruby -e 'puts RUBY_VERSION')
info "[1/6] Detected Ruby $RUBY_VER toolchain."

# 3. Handle version setting and RubyGems canonicalization
if [[ -n "$TARGET_VERSION" ]]; then
    CANONICAL_TARGET=$(ruby -e "
      raw = ARGV[0]
      unless Gem::Version.correct?(raw)
        STDERR.puts \"Invalid version format: #{raw}\"
        exit 1
      end
      puts Gem::Version.new(raw).to_s
    " "$TARGET_VERSION") || fail "Invalid version format '$TARGET_VERSION'."

    info "[2/6] Updating version to $CANONICAL_TARGET (canonicalized from $TARGET_VERSION) in $VERSION_FILE..."
    cat > "$VERSION_FILE" <<RUBY
# frozen_string_literal: true

module HyperProbe
  VERSION = '$CANONICAL_TARGET'
end
RUBY
fi

CURRENT_VERSION=$(ruby -r "$VERSION_FILE" -e '
  raw = HyperProbe::VERSION
  puts Gem::Version.correct?(raw) ? Gem::Version.new(raw).to_s : raw
')

IS_PRERELEASE=$(ruby -e "puts Gem::Version.new('$CURRENT_VERSION').prerelease? ? 'true' : 'false'")
if [[ "$IS_PRERELEASE" == "true" ]]; then
    info "Detected RubyGems prerelease version: $CURRENT_VERSION"
fi

if [[ "$CURRENT_VERSION" == "0.0.0" && "$DRY_RUN" != true ]]; then
    warn "Releasing with placeholder version 0.0.0! Use --version <ver> to specify release version."
fi

# 4. Build both platforms before tests (JRuby and packaging specs need the JAR).
info "[3/6] Building MRI and Java packages, including the bundled gRPC transport..."
bundle exec rake build || fail "Gem build failed. Maven and JDK 11+ are required."
readonly BUILT_GEMS=("$PKG_DIR/hyperprobe-agent-$CURRENT_VERSION.gem" "$PKG_DIR/hyperprobe-agent-$CURRENT_VERSION-java.gem")

# 5. Run test suite
if [[ "$SKIP_TESTS" == true ]]; then
    warn "[3/6] Skipping RSpec test suite as requested."
else
    info "[3/6] Running RSpec test suite to ensure code quality..."
    bundle exec rspec || fail "RSpec test suite failed. Aborting release."
    JRUBY_BIN="${HYPERPROBE_JRUBY:-jruby}"
    command -v "$JRUBY_BIN" >/dev/null 2>&1 || fail "JRuby is required to verify the java artifact."
    HYPERPROBE_MRI_RUBY="$(command -v ruby)" "$JRUBY_BIN" --debug \
        -J-Djruby.ir.passes=AddCallProtocolInstructions,AddMissingInitsPass \
        -J-Djruby.ir.jit.passes=AddCallProtocolInstructions,AddMissingInitsPass -S rspec || \
        fail "JRuby RSpec test suite failed. Aborting release."
    success "All test suites passed cleanly."
fi

# 6. Validate both artifacts, not just their names.
info "[5/6] Validating ruby/java platforms, dependencies and bundled transport..."
for BUILT_GEM in "${BUILT_GEMS[@]}"; do
    [[ -f "$BUILT_GEM" ]] || fail "Built gem not found at $BUILT_GEM."
    ruby -e '
      require "rubygems/package"
      package = Gem::Package.new(ARGV[0])
      spec = package.spec
      platform = ARGV[0].end_with?("-java.gem") ? "java" : "ruby"
      abort "Wrong package identity" unless spec.name == ARGV[1] && spec.version.to_s == ARGV[2]
      abort "Wrong platform" unless spec.platform.to_s == platform
      deps = spec.runtime_dependencies.map(&:name)
      abort "Wrong grpc dependency" unless deps.include?("grpc") == (platform == "ruby")
      abort "Wrong protobuf dependency" unless deps.include?("google-protobuf") == (platform == "ruby")
      abort "Wrong Ruby compatibility" unless spec.required_ruby_version.satisfied_by?(Gem::Version.new("2.6.8")) == (platform == "java")
      jars = package.contents.grep(/\.jar\z/)
      expected_jars = platform == "java" ? ["lib/hyperprobe/jars/hyperprobe-grpc.jar"] : []
      abort "Wrong bundled transport" unless jars == expected_jars
      puts "Validated #{File.basename(ARGV[0])}: #{spec.files.length} files"
    ' "$BUILT_GEM" "$EXPECTED_GEM_NAME" "$CURRENT_VERSION" || fail "Package validation failed."
done

if [[ "$DRY_RUN" == true ]]; then
    success "Dry run completed successfully. Artifact ready in $PKG_DIR."
    exit 0
fi

# 7. Check & Resolve Credentials
RESOLVED_KEY=""
CREDS_FILE="${RUBYGEMS_CREDENTIALS_FILE:-}"

if [[ -z "$CREDS_FILE" && -f "$SCRIPT_DIR/../../.gemcredentials" ]]; then
    CREDS_FILE="$SCRIPT_DIR/../../.gemcredentials"
elif [[ -z "$CREDS_FILE" && -f "$SCRIPT_DIR/../../.gem/credentials" ]]; then
    CREDS_FILE="$SCRIPT_DIR/../../.gem/credentials"
elif [[ -z "$CREDS_FILE" && -f "$SCRIPT_DIR/.gemcredentials" ]]; then
    CREDS_FILE="$SCRIPT_DIR/.gemcredentials"
elif [[ -z "$CREDS_FILE" && -f "$SCRIPT_DIR/.gem/credentials" ]]; then
    CREDS_FILE="$SCRIPT_DIR/.gem/credentials"
elif [[ -z "$CREDS_FILE" && -f "$HOME/.gem/credentials" ]]; then
    CREDS_FILE="$HOME/.gem/credentials"
fi

if [[ -n "$API_KEY" ]]; then
    RESOLVED_KEY="$API_KEY"
elif [[ -n "$CREDS_FILE" && -f "$CREDS_FILE" ]]; then
    info "Using RubyGems credentials from: $CREDS_FILE"
    # Extract API key if file is YAML (e.g. :rubygems_api_key: xxx or rubygems_api_key: xxx) or plain token
    RAW_EXTRACT=$(grep -E '(:?rubygems_api_key:)' "$CREDS_FILE" 2>/dev/null | awk '{print $2}' | tr -d '\r\n"' || true)
    if [[ -n "$RAW_EXTRACT" ]]; then
        RESOLVED_KEY="$RAW_EXTRACT"
    else
        # Try reading plain first line
        RESOLVED_KEY=$(head -n 1 "$CREDS_FILE" | tr -d '\r\n ' || true)
    fi
fi

if [[ -z "$RESOLVED_KEY" ]]; then
    if [[ -t 0 ]]; then
        info "Enter your RubyGems API key (input hidden):"
        read -r -s -p "API Key: " RESOLVED_KEY
        printf '\n'
    else
        fail "No RubyGems credentials found. Provide .gemcredentials, set GEM_HOST_API_KEY, or run 'gem signin'."
    fi
fi

[[ -n "$RESOLVED_KEY" ]] || fail "RubyGems API token is empty."

# 8. Confirmation prompt
if [[ "$ASSUME_YES" != true ]]; then
    # Child runtimes can leave inherited stdin nonblocking. Reopen the terminal
    # for interactive approval, while preserving explicitly piped input.
    if [[ -t 0 ]]; then
        exec 0</dev/tty || fail "Unable to open terminal input. Re-run with --yes to explicitly authorize publishing."
    fi
    printf 'Ready to publish %s %s (ruby and java) to RubyGems.org.\n' "$EXPECTED_GEM_NAME" "$CURRENT_VERSION"
    if ! read -r -p "Do you want to proceed with publishing? (y/n): " CONFIRM; then
        fail "Unable to read publishing confirmation. Re-run in an interactive terminal or use --yes to explicitly authorize publishing."
    fi
    case "$CONFIRM" in
        y|Y|yes|YES|Yes)
            ;;
        *)
            info "Publishing canceled. Built artifact remains in $PKG_DIR."
            exit 0
            ;;
    esac
fi

# 9. Push to RubyGems
info "[6/6] Pushing $EXPECTED_GEM_NAME $CURRENT_VERSION (ruby and java) to RubyGems.org..."
export GEM_HOST_API_KEY="$RESOLVED_KEY"
for BUILT_GEM in "${BUILT_GEMS[@]}"; do
    gem push "$BUILT_GEM" || fail "Failed to push $BUILT_GEM. Earlier artifacts may already be published."
done

RESOLVED_KEY=""
unset GEM_HOST_API_KEY

success "Successfully released $EXPECTED_GEM_NAME $CURRENT_VERSION (ruby and java) to RubyGems.org!"
printf 'View the gem at: %b%s%b\n' "$BLUE" "$RUBYGEMS_PROJECT_URL" "$NC"
