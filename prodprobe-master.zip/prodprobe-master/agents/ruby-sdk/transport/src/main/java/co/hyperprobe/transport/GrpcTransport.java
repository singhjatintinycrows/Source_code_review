package co.hyperprobe.transport;

import com.google.common.util.concurrent.ListenableFuture;
import io.grpc.CallOptions;
import io.grpc.Channel;
import io.grpc.ClientInterceptors;
import io.grpc.Deadline;
import io.grpc.ManagedChannel;
import io.grpc.Metadata;
import io.grpc.MethodDescriptor;
import io.grpc.Status;
import io.grpc.netty.shaded.io.grpc.netty.GrpcSslContexts;
import io.grpc.netty.shaded.io.grpc.netty.NettyChannelBuilder;
import io.grpc.netty.shaded.io.netty.channel.nio.NioEventLoopGroup;
import io.grpc.netty.shaded.io.netty.channel.socket.nio.NioSocketChannel;
import io.grpc.netty.shaded.io.netty.handler.ssl.SslProvider;
import io.grpc.netty.shaded.io.netty.handler.ssl.SslContextBuilder;
import io.grpc.netty.shaded.io.netty.util.concurrent.DefaultThreadFactory;
import io.grpc.stub.ClientCalls;
import io.grpc.stub.MetadataUtils;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

/** Byte-only boundary: protobuf encoding remains in Ruby, HTTP/2 belongs to grpc-java. */
public final class GrpcTransport {
    private static final MethodDescriptor.Marshaller<byte[]> BYTES = new MethodDescriptor.Marshaller<byte[]>() {
        public InputStream stream(byte[] value) {
            return new ByteArrayInputStream(value);
        }

        public byte[] parse(InputStream stream) {
            try {
                return stream.readAllBytes();
            } catch (IOException e) {
                throw Status.INTERNAL.withCause(e).asRuntimeException();
            }
        }
    };

    private final NioEventLoopGroup eventLoop;
    private final ManagedChannel channel;
    private final Channel authenticatedChannel;

    public GrpcTransport(String host, int port, boolean secure, String serviceId, boolean keepAlive)
            throws javax.net.ssl.SSLException {
        eventLoop = new NioEventLoopGroup(1, new DefaultThreadFactory("hyperprobe-grpc", true));
        try {
            // Explicit NIO/JDK TLS avoids platform-specific native libraries in the gem.
            NettyChannelBuilder builder = NettyChannelBuilder.forAddress(host, port)
                    .eventLoopGroup(eventLoop).channelType(NioSocketChannel.class)
                    .maxInboundMessageSize(4 * 1024 * 1024).disableRetry();
            if (secure) {
                builder.sslContext(GrpcSslContexts.configure(SslContextBuilder.forClient(), SslProvider.JDK).build());
            } else {
                builder.usePlaintext();
            }
            if (keepAlive) {
                builder.keepAliveTime(60, TimeUnit.SECONDS).keepAliveTimeout(20, TimeUnit.SECONDS)
                        .keepAliveWithoutCalls(true);
            }
            Metadata metadata = new Metadata();
            metadata.put(Metadata.Key.of("x-hp-service-id", Metadata.ASCII_STRING_MARSHALLER), serviceId);
            channel = builder.build();
            authenticatedChannel = ClientInterceptors.intercept(channel,
                    MetadataUtils.newAttachHeadersInterceptor(metadata));
        } catch (RuntimeException | Error | javax.net.ssl.SSLException e) {
            eventLoop.shutdownGracefully(0, 1, TimeUnit.SECONDS);
            throw e;
        }
    }

    public byte[] call(String method, byte[] request, long timeoutNanos) throws RpcException {
        Deadline deadline = Deadline.after(timeoutNanos, TimeUnit.NANOSECONDS);
        MethodDescriptor<byte[], byte[]> descriptor = MethodDescriptor.<byte[], byte[]>newBuilder()
                .setType(MethodDescriptor.MethodType.UNARY).setFullMethodName(method)
                .setRequestMarshaller(BYTES).setResponseMarshaller(BYTES).build();
        ListenableFuture<byte[]> future = ClientCalls.futureUnaryCall(
                authenticatedChannel.newCall(descriptor, CallOptions.DEFAULT.withDeadline(deadline)), request);
        try {
            // The caller is bounded even during DNS, connect, TLS, or a stalled peer.
            // A unary future completes only after terminal grpc-status, not the first DATA frame.
            return future.get(Math.max(0, deadline.timeRemaining(TimeUnit.NANOSECONDS)), TimeUnit.NANOSECONDS);
        } catch (TimeoutException e) {
            throw new RpcException(Status.DEADLINE_EXCEEDED);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new RpcException(Status.CANCELLED);
        } catch (ExecutionException e) {
            throw new RpcException(Status.fromThrowable(e.getCause()));
        } finally {
            if (!future.isDone()) {
                future.cancel(true);
            }
        }
    }

    public void shutdown() {
        channel.shutdownNow();
        eventLoop.shutdownGracefully(0, 1, TimeUnit.SECONDS);
    }

    public static final class RpcException extends Exception {
        private final int code;

        RpcException(Status status) {
            super(status.getCode() + ": " + status.getDescription());
            code = status.getCode().value();
        }

        public int getCode() {
            return code;
        }
    }
}
