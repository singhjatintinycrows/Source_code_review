package co.hyperprobe.transport;

import com.google.protobuf.ByteString;
import com.google.protobuf.CodedInputStream;
import com.google.protobuf.DescriptorProtos.FileDescriptorProto;
import com.google.protobuf.Descriptors;
import com.google.protobuf.DynamicMessage;
import java.io.IOException;

/** SDK-private protobuf runtime. Maven relocates every protobuf type in this API. */
public final class ProtoCodec {
    public static final int MAX_BYTES = 4 * 1024 * 1024;
    private final Descriptors.FileDescriptor file;

    public ProtoCodec(byte[] descriptor) throws IOException, Descriptors.DescriptorValidationException {
        file = Descriptors.FileDescriptor.buildFrom(
                FileDescriptorProto.parseFrom(descriptor), new Descriptors.FileDescriptor[0]);
    }

    public Descriptors.FileDescriptor getFile() {
        return file;
    }

    public DynamicMessage.Builder builder(Descriptors.Descriptor descriptor) {
        return DynamicMessage.newBuilder(descriptor);
    }

    public ByteString bytes(byte[] value) {
        return ByteString.copyFrom(value);
    }

    public DynamicMessage decode(Descriptors.Descriptor descriptor, byte[] bytes) throws IOException {
        if (bytes.length > MAX_BYTES) {
            throw new IllegalArgumentException("Protobuf payload exceeds 4 MiB");
        }
        CodedInputStream input = CodedInputStream.newInstance(bytes);
        input.setSizeLimit(MAX_BYTES);
        input.setRecursionLimit(64);
        DynamicMessage message = DynamicMessage.parseFrom(descriptor, input);
        input.checkLastTagWas(0);
        return message;
    }
}
