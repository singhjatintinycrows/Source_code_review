# JRuby gRPC Transport

Runtime baseline: MRI 3.0+ (tested 4.0.6), or JRuby 9.3+ on Java 11+ with the required
launch profile below. The Java artifact requires Ruby >= 2.6 and has no
`google-protobuf`, native `grpc`, or `ffi` runtime dependencies. MRI remains
Ruby >= 3.0 with `google-protobuf` >= 3.25, < 5 and `grpc` >= 1.50, < 2.
Choose a JDK supported by the selected JRuby.

```sh
jruby --debug \
  -J-Djruby.ir.passes=AddCallProtocolInstructions,AddMissingInitsPass \
  -J-Djruby.ir.jit.passes=AddCallProtocolInstructions,AddMissingInitsPass app.rb
```

`--debug` alone does not preserve all warmed line events/bindings. SDK startup
checks the effective Java field
`Java::OrgJruby::RubyInstanceConfig.FULL_TRACE_ENABLED` (dot access in Ruby code), and
`Java::OrgJrubyUtilCli::Options::IR_COMPILER_PASSES.load` plus
`Java::OrgJrubyUtilCli::Options::IR_JIT_PASSES.load` against the exact lists above.
It rejects unsafe profiles rather than changing process configuration. JIT stays
enabled without method exclusions.

`rake build` builds both `pkg/hyperprobe-agent-VERSION.gem` and
`pkg/hyperprobe-agent-VERSION-java.gem`. It needs Maven and JDK 11+ at build time;
Maven fetches the pinned dependencies then. `rake build:ruby` needs neither Java
nor Maven. `rake transport:build` prepares a source checkout for JRuby tests.
Generated JARs are ignored by Git and must be built before packaging Java.
The release script builds/validates both artifacts and tests both interpreters;
set `HYPERPROBE_JRUBY` if the JRuby executable is not named `jruby`.

Release both artifacts at the same version. Do not build a generic Ruby gem on
JRuby and assume its dependencies will change on installation. The gemspec's
explicit `HYPERPROBE_GEM_PLATFORM=ruby|java` build target controls its immutable
platform and dependency metadata; the default is always `ruby`. The source
Gemfile selects the interpreter's development target. Direct Java `gem build`
requires the previously built JAR. No Maven, jar-dependencies, native compiler,
or network download is used when the installed Java gem loads or connects.

The JAR contains grpc-java 1.84.0 (`grpc-netty-shaded` and `grpc-stub`), its
transitive dependencies, and patched `com.google.protobuf:protobuf-java:3.25.9`
core only. It does not bundle `protobuf-java-util` or Google's JRuby bridge.
Maven Shade relocates gRPC, Netty, Guava and supporting classes under
`co.hyperprobe.internal`; in particular, `com.google.protobuf` becomes
`co.hyperprobe.internal.google.protobuf`. Service descriptors and Apache notices
are merged. The supplemental [third-party notice](THIRD_PARTY_NOTICES.md)
preserves protobuf's upstream BSD 3-Clause license and source credits.

The transport bridge accepts protobuf bytes. For JRuby, an SDK-private Ruby
message adapter delegates encoding/decoding to Java `DynamicMessage` using the
generated descriptor of the existing SDK Ruby protocol schema. No generated
Java message models or Google Ruby runtime API are introduced. It neither creates
nor changes the host's `Google::Protobuf` module; a host application's separately
loaded Google protobuf remains independent. MRI retains its existing generated
Ruby protobuf path. The POM and Java bridge/codec sources ship in the Java gem
so its bundled dependency versions can be audited and rebuilt.

NIO sockets and JDK TLS/ALPN avoid platform-specific native binaries. HTTPS uses
the JVM's normal trust store and hostname verification, never an insecure trust
manager. Configure a private CA with the standard JVM trust-store options.
Raw `host:port` and `http://host:port` use plaintext gRPC; HTTPS uses TLS. IPv6
addresses in URLs must be bracketed. No HTTP/1.1 fallback is attempted.

grpc-java handles fragmentation, flow control, compression and terminal status.
Unary responses are accepted only after an OK terminal status. Inbound messages
are limited to 4 MiB, matching gRPC's usual default. Calls carry a finite deadline
including DNS, connect, TLS, request writes and response reads. The Ruby broker
starts the budget before constructing the request; the Java bridge also bounds
the caller's wait and cancels timed-out/interrupted calls. Shutdown cancels active
RPCs and asynchronously releases its daemon event-loop thread without waiting
for network peers. Errors propagate to the agent's fail-isolation boundary as
Ruby StandardError (RPC status with numeric `code`) or LoadError (missing or
incompatible bundled transport), never as an empty successful response.

Interop specs launch a local MRI C-core gRPC server. Run:

```sh
rake transport:build
ruby -S rspec spec/broker_transport_spec.rb spec/packaging_spec.rb
HYPERPROBE_MRI_RUBY=/path/to/mri/ruby jruby --debug \
  -J-Djruby.ir.passes=AddCallProtocolInstructions,AddMissingInitsPass \
  -J-Djruby.ir.jit.passes=AddCallProtocolInstructions,AddMissingInitsPass \
  -S rspec spec/broker_transport_spec.rb spec/packaging_spec.rb
```

The MRI executable must have `grpc`, `google-protobuf` and `rspec` installed.
The JRuby executable needs `rspec`, not the `google-protobuf` gem. Tests generate disposable
local TLS certificates and a trust store; production trust configuration is not
modified.

Clean packaged Bundler installs have succeeded on JRuby 9.3 and 10.1 without
forced installs or Google Ruby protobuf load-path overrides. JRuby 9.3 needs
Ruby 2.6-compatible Bundler 2.4. Do not reuse a frozen Ruby 4 development
lockfile on older runtimes without resolving for that runtime. The release
script now supplies the complete required profile to its JRuby test invocation.

`HYPERPROBE_TEST_LIB=/installed/gem/lib` runs the interop clients against an
installed package rather than the source checkout. The test server remains the
independent MRI C-core fixture.
