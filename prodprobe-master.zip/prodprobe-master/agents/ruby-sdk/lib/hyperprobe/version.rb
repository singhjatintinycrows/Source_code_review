# frozen_string_literal: true

module HyperProbe
  VERSION = '0.0.0'
end
