# frozen_string_literal: true

if RUBY_PLATFORM =~ /java/
  require_relative 'protos/java_messages'
else
  protos_dir = File.expand_path('protos', __dir__)
  $LOAD_PATH.unshift(protos_dir) unless $LOAD_PATH.include?(protos_dir)
  require 'agent_pb'
  begin
    require 'agent_services_pb'
  rescue LoadError
    # Environments without the C-grpc gem can still use the messages.
  end
end
