# frozen_string_literal: true

module HyperProbe
  module Lambda
    class << self
      def wrap(options = {}, &handler)
        is_aws_lambda = !ENV['AWS_LAMBDA_FUNCTION_NAME'].nil?
        is_local_emulator = ENV['IS_OFFLINE'] == 'true' || ENV['AWS_SAM_LOCAL'] == 'true'
        is_ephemeral = (options[:is_lambda] || is_aws_lambda) && !is_local_emulator

        # If running locally in emulator, standard background agent mode
        unless is_ephemeral
          HyperProbe.start(options)
          return handler
        end

        # Ephemeral Lambda wrapper
        lambda do |event:, context:|
          agent = nil
          begin
            HyperProbe.start(options.merge(is_lambda: true)) unless HyperProbe.instance
            agent = HyperProbe.instance
            agent = nil if agent && agent.agent_disabled?
            if agent
              remaining_ms = context.respond_to?(:get_remaining_time_in_millis) ? context.get_remaining_time_in_millis : nil
              sync_timeout_ms = options[:lambda_sync_timeout_ms] || 2000
              if remaining_ms
                dynamic_budget = (remaining_ms * 0.2).to_i
                sync_timeout_ms = dynamic_budget < 100 ? 0 : [sync_timeout_ms, dynamic_budget].min
              end
              agent.force_sync(sync_timeout_ms / 1000.0) if sync_timeout_ms.positive?
            end
          rescue SignalException, SystemExit
            raise
          rescue Exception
            # This boundary never encloses application handler execution.
          end

          begin
            params = handler.parameters
            has_keywords = params.any? { |type, _| type == :keyreq || type == :key || type == :keyrest }

            if has_keywords
              handler.call(event: event, context: context)
            elsif params.length == 1 && (params.first[0] == :req || params.first[0] == :opt)
              handler.call(event)
            else
              handler.call(event, context)
            end
          ensure
            begin
              if agent
                remaining_ms = context.respond_to?(:get_remaining_time_in_millis) ? context.get_remaining_time_in_millis : nil
                flush_timeout_ms = options[:flush_timeout_ms] || 1500
                if remaining_ms.nil? || remaining_ms > 500
                  flush_timeout_ms = [remaining_ms - 200, flush_timeout_ms].min if remaining_ms
                  agent.force_flush(flush_timeout_ms / 1000.0)
                end
              end
            rescue SignalException, SystemExit
              raise
            rescue Exception
              # Never mask a handler exception with instrumentation cleanup.
            end
          end
        end
      rescue SignalException, SystemExit
        raise
      rescue Exception
        handler
      end

      def stop
        agent = HyperProbe.instance
        if agent && !agent.agent_disabled?
          begin
            agent.force_flush(1.0)
          rescue SignalException, SystemExit
            raise
          rescue Exception
            # Best effort
          end
        end
        HyperProbe.shutdown
      rescue SignalException, SystemExit
        raise
      rescue Exception
        nil
      end
    end
  end
end
