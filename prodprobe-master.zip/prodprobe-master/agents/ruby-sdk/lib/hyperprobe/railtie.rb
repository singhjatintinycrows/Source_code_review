# frozen_string_literal: true

module HyperProbe
  if defined?(::Rails::Railtie)
    class Railtie < ::Rails::Railtie
      config.after_initialize do
        enabled = ENV['HYPERPROBE_ENABLED'] != 'false' && ENV['HYPERPROBE_DISABLED'] != 'YES'
        has_service_id = !ENV['HYPERPROBE_SERVICE_ID'].nil? && !ENV['HYPERPROBE_SERVICE_ID'].empty?

        if enabled && has_service_id
          HyperProbe.start
        end

        if defined?(::Spring) && ::Spring.respond_to?(:after_fork)
          ::Spring.after_fork do
            HyperProbe.after_fork
          end
        end
      end
    end
  end
end
