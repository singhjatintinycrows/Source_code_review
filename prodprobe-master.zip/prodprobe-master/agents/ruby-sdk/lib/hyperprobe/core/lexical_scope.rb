# frozen_string_literal: true

require 'ripper'

module HyperProbe
  module Core
    # Installation-time analysis only. Retain the result on the probe, not a
    # binding. nil means unknown: callers must omit locals, not fall back to all.
    # Tokenless lines and lines shared by different scopes are intentionally
    # unknown. Source must still match the code loaded by the application.
    # Parsers with incomplete lambda ASTs (including JRuby 10.1.1's arrow
    # lambdas) fail closed; ordinary lambda/proc blocks remain supported.
    class LexicalScope
      MAX_SOURCE_BYTES = 512 * 1024
      MAX_NODES = 20_000
      MAX_DEPTH = 128
      CLASS = Object.instance_method(:class)
      Scope = Struct.new(:parent, :declared, :assigned, :locals, :visible)
      private_constant :CLASS, :Scope

      def self.locals_for(path, line)
        return nil unless CLASS.bind(path).call.equal?(String) && CLASS.bind(line).call.equal?(Integer)
        return nil unless line.positive?
        return nil unless File.file?(path)

        source = File.open(path, 'rb') do |file|
          return nil unless file.stat.file? && file.stat.size <= MAX_SOURCE_BYTES
          file.read(MAX_SOURCE_BYTES + 1)
        end
        return nil if source.bytesize > MAX_SOURCE_BYTES

        new(source).locals_for(line)
      rescue StandardError, SystemStackError
        nil
      end

      def initialize(source)
        tree = Ripper.sexp(source)
        raise ArgumentError, 'Invalid Ruby source' unless tree

        # Check iteratively before any recursive AST work (including positions).
        stack = [[tree, 0]]
        count = 0
        until stack.empty?
          node, depth = stack.pop
          count += 1
          raise ArgumentError, 'AST limit' if count > MAX_NODES || depth > MAX_DEPTH
          node.each { |child| stack << [child, depth + 1] if child.is_a?(Array) }
        end

        @lambda_headers = lambda_headers(source)
        @lambda_index = 0
        @scopes = []
        @lines = {}
        @unknown_lines = {}
        walk(tree, scope(nil))
        raise ArgumentError, 'Unmatched lambda' unless @lambda_index == @lambda_headers.length

        # Ancestors are complete before descendants, including assignments
        # textually after a block. Such names are conservatively kept private.
        @scopes.each do |current|
          ancestors = current.parent ? current.parent.visible : []
          current.locals = (current.declared + (current.assigned - ancestors)).uniq.freeze
          current.visible = (ancestors + current.locals).uniq
        end
      end

      def locals_for(line)
        return nil if @unknown_lines[line]

        owners = @lines[line]
        owners && owners.length == 1 ? owners.first.locals.dup : nil
      end

      private

      def scope(parent)
        current = Scope.new(parent, [], [], nil, nil)
        @scopes << current
        current
      end

      def walk(node, current)
        return unless node.is_a?(Array)

        kind = node[0]
        if kind.is_a?(Symbol) && kind.to_s.start_with?('@')
          first = node[2][0]
          last = first + node[1].count("\n")
          last -= 1 if node[1].end_with?("\n")
          (first..last).each do |line|
            owners = (@lines[line] ||= [])
            owners << current unless owners.any? { |owner| owner.equal?(current) }
          end
          return
        end

        case kind
        when :def, :defs
          # A line alone cannot distinguish definition from default evaluation.
          header, params, body = kind == :def ? [node[1..2], node[2], node[3]] : [node[1..4], node[4], node[5]]
          token_positions(header).each { |position| @unknown_lines[position[0]] = true }
          method_scope = scope(nil)
          parameters(params, method_scope)
          walk(node[1], current) if kind == :defs
          walk(params, method_scope)
          walk(body, method_scope)
        when :class, :module, :sclass
          inner = scope(nil)
          token_positions(node[1...-1]).each { |position| @unknown_lines[position[0]] = true }
          walk(node[1...-1], current)
          walk(node[-1], inner)
        when :do_block, :brace_block, :lambda
          inner = scope(current)
          parameters(node[1], inner)
          if kind == :lambda
            raise ArgumentError, 'Incomplete lambda AST' unless node[1].is_a?(Array)

            header = @lambda_headers.fetch(@lambda_index)
            @lambda_index += 1
            inner.declared.concat(header[:locals])
            # Ripper leaves lambda semicolon locals out of sexp entirely.
            # Validate the association when there are positioned parameters.
            positions = token_positions(node[1])
            unless positions.all? { |position| (position <=> header[:start]) >= 0 && (position <=> header[:finish]) <= 0 }
              raise ArgumentError, 'Ambiguous lambda header'
            end
            unless token_positions(node[2]).all? { |position| (position <=> header[:finish]) >= 0 }
              raise ArgumentError, 'Ambiguous lambda body'
            end
          end
          walk(node[1], inner)
          walk(node[2], inner)
        when :var_field
          current.assigned << node[1][1].to_sym if node[1] && node[1][0] == :@ident
          node.each { |child| walk(child, current) }
        when :BEGIN, :END
          raise ArgumentError, 'Unsupported execution scope'
        else
          node.each { |child| walk(child, current) }
        end
      end

      def parameters(node, current)
        return unless node.is_a?(Array)

        case node[0]
        when :paren
          parameters(node[1], current)
        when :block_var
          parameters(node[1], current)
          declare(node[2], current)
        when :params
          declare(node[1], current)
          (node[2] || []).each { |pair| declare(pair[0], current) }
          declare(node[3], current)
          declare(node[4], current)
          (node[5] || []).each { |pair| declare(pair[0], current) }
          declare(node[6], current)
          declare(node[7], current)
        end
      end

      def declare(node, current)
        return unless node.is_a?(Array)

        if node[0] == :@ident || node[0] == :@label
          current.declared << node[1].delete_suffix(':').to_sym
        else
          node.each { |child| declare(child, current) }
        end
      end

      def token_positions(node)
        return [] unless node.is_a?(Array)
        return [node[2]] if node[0].is_a?(Symbol) && node[0].to_s.start_with?('@')

        node.flat_map { |child| token_positions(child) }
      end

      def lambda_headers(source)
        tokens = Ripper.lex(source)
        raise ArgumentError, 'Token limit' if tokens.length > MAX_NODES

        headers = []
        work = 0
        tokens.each_with_index do |token, index|
          next unless token[1] == :on_tlambda

          header = { start: token[0], finish: token[0], locals: [] }
          depth = 0
          shadow = false
          cursor = index + 1
          while cursor < tokens.length
            work += 1
            raise ArgumentError, 'Lambda header limit' if work > MAX_NODES
            position, type, text = tokens[cursor]
            cursor += 1
            header[:finish] = position
            break if depth.zero? && (type == :on_tlambeg || (type == :on_kw && text == 'do'))

            if shadow
              if type == :on_rparen && depth == 1
                shadow = false
              elsif !%i[on_ident on_comma on_sp on_nl on_ignored_nl on_comment].include?(type)
                raise ArgumentError, 'Ambiguous lambda shadow declaration'
              end
              header[:locals] << text.to_sym if type == :on_ident
            end
            depth += 1 if type == :on_lparen
            depth -= 1 if type == :on_rparen
            shadow = true if depth == 1 && type == :on_semicolon
          end
          headers << header
        end
        headers
      end

      private_class_method :new
    end
  end
end
