# frozen_string_literal: true

require 'json'
require 'time'
require 'set'
require 'objspace' unless RUBY_PLATFORM.include?('java')

module HyperProbe
  module Core
    class Serializer
      DEFAULT_MAX_DEPTH = 3
      DEFAULT_MAX_ARRAY_LENGTH = 3
      DEFAULT_MAX_OBJECT_PROPERTIES = 50
      DEFAULT_MAX_STRING_LENGTH = 1024
      MAX_DEPTH = 16
      MAX_ITEMS = 128
      MAX_STRING_BYTES = 4096
      MAX_NODES = 512
      MAX_BYTES = 65_536
      MAX_PATTERNS = 16
      MAX_PATTERN_BYTES = 256
      HASH_STORAGE_BYTES = 131_072
      MEMORY_SIZE = ObjectSpace.method(:memsize_of) if ObjectSpace.respond_to?(:memsize_of)
      LEGACY_STRING_SLICE = RUBY_PLATFORM.include?('java') && RUBY_VERSION.start_with?('2.6.')
      BUDGET_MARKER = '[Capture budget exhausted]'

      # Capture implementations once, then bind them directly. Even innocuous
      # calls such as obj.class, ==, or hash[key] can execute application code.
      CORE = {
        klass: Kernel.instance_method(:class),
        kind: Kernel.instance_method(:is_a?),
        identity: BasicObject.instance_method(:__id__),
        equal: BasicObject.instance_method(:equal?),
        ivars: Kernel.instance_method(:instance_variables),
        ivar: Kernel.instance_method(:instance_variable_get),
        class_name: Module.instance_method(:name),
        string_size: String.instance_method(:bytesize),
        string_slice: String.instance_method(:byteslice),
        array_size: Array.instance_method(:length),
        array_get: Array.instance_method(:[]),
        hash_size: Hash.instance_method(:size),
        hash_each: Hash.instance_method(:each_pair),
        integer_bits: Integer.instance_method(:bit_length),
        integer_string: Integer.instance_method(:to_s),
        float_finite: Float.instance_method(:finite?),
        float_nan: Float.instance_method(:nan?),
        float_positive: Float.instance_method(:positive?),
        time_format: Time.instance_method(:strftime),
        time_utc: Time.instance_method(:utc?),
        time_compare: Time.instance_method(:<=>),
        date_format: Date.instance_method(:strftime),
        date_compare: Date.instance_method(:<=>),
        proc_lambda: Proc.instance_method(:lambda?),
        method_name: Method.instance_method(:name),
        unbound_name: UnboundMethod.instance_method(:name),
        struct_size: Struct.instance_method(:size),
        struct_each: Struct.instance_method(:each_pair)
      }.freeze
      SYMBOL_NAME = if Symbol.method_defined?(:name)
                      Symbol.instance_method(:name)
                    elsif RUBY_PLATFORM.include?('java')
                      # JRuby shares the symbol's bytes; slice before encoding.
                      Symbol.instance_method(:to_s)
                    end
      if Set.instance_method(:each).source_location.nil? && Set.instance_method(:size).source_location.nil?
        SET_EACH = Set.instance_method(:each)
        SET_SIZE = Set.instance_method(:size)
      end
      JAVA_SEND = Java::JavaLang::Object.instance_method(:java_send) if RUBY_PLATFORM.include?('java')
      TIME_MIN = Time.utc(0).freeze
      TIME_MAX = Time.utc(10_000).freeze
      DATE_MIN = Date.new(0, 1, 1).freeze
      DATE_MAX = Date.new(10_000, 1, 1).freeze

      def initialize(max_depth: DEFAULT_MAX_DEPTH,
                     max_array_length: DEFAULT_MAX_ARRAY_LENGTH,
                     max_object_properties: DEFAULT_MAX_OBJECT_PROPERTIES,
                     max_string_length: DEFAULT_MAX_STRING_LENGTH,
                     redact_keys: nil, redact_values: nil)
        @max_depth = limit(max_depth, DEFAULT_MAX_DEPTH, MAX_DEPTH)
        @max_array_length = limit(max_array_length, DEFAULT_MAX_ARRAY_LENGTH, MAX_ITEMS)
        @max_object_properties = limit(max_object_properties, DEFAULT_MAX_OBJECT_PROPERTIES, MAX_ITEMS)
        @max_string_length = limit(max_string_length, DEFAULT_MAX_STRING_LENGTH, MAX_STRING_BYTES)
        @redact_keys_re = compile_regex(redact_keys)
        @redact_values_re = compile_regex(redact_values)
        @capture_lock = Mutex.new
        @capture_context = nil
      end

      # A supplied visited object is an identity token, never a mutable table.
      # Keep only the active snapshot's context; a different token replaces it.
      # Calls without a token use fresh state without disturbing that context.
      def serialize(obj, path = '$', depth = 0, visited = nil)
        @capture_lock.synchronize do
          shared = !core(:equal, visited, nil)
          if shared && @capture_context && core(:equal, visited, @capture_context[0])
            state = @capture_context[1]
          else
            # Leave room for exhaustion markers while unwinding containers.
            state = { nodes: MAX_NODES, bytes: MAX_BYTES - 4096, visited: {} }
            @capture_context = [visited, state] if shared
          end
          return BUDGET_MARKER if exhausted?(state)
          path = kind?(path, String) ? text(path, state) : '$'
          capture(obj, path, limit(depth, 0, MAX_DEPTH), state)
        end
      rescue SignalException, SystemExit
        raise
      rescue Exception # Snapshot failures must not escape into the client.
        '[Serialization unavailable]'
      end

      def self.safe_dump_json(data)
        # JSON.generate dispatches to to_json on arbitrary inputs, including
        # singleton methods on strings/containers. Only give it fresh core data.
        new.send(:dump_json, data)
      rescue SignalException, SystemExit
        raise
      rescue Exception
        '{"error":"JSON serialization failed"}'
      end

      def finish_capture
        @capture_lock.synchronize { @capture_context = nil }
      end

      private

      def dump_json(data)
        # Captures have already spent their budgets. Allow bounded headroom for
        # frame/watch wrappers and generated summaries/truncation markers, rather
        # than erasing captured fields by applying capture limits a second time.
        @max_depth = MAX_DEPTH * 2
        @max_array_length = @max_object_properties = MAX_NODES * 2
        @max_string_length = MAX_STRING_BYTES * 2
        state = { nodes: MAX_NODES * 4, bytes: MAX_BYTES * 2, visited: {} }
        JSON.generate(capture(data, '$', 0, state))
      end

      def core(name, obj, *args, &block)
        CORE.fetch(name).bind(obj).call(*args, &block)
      end

      def kind?(obj, klass)
        core(:kind, obj, klass)
      end

      def exact?(obj, klass)
        core(:equal, core(:klass, obj), klass)
      end

      def limit(value, default, maximum)
        return default unless exact?(value, Integer)
        [[value, 0].max, maximum].min
      end

      def compile_regex(patterns)
        return nil if core(:equal, patterns, nil)
        patterns = [patterns] if kind?(patterns, String)
        return /\A[\s\S]*\z/ unless exact?(patterns, Array)
        count = core(:array_size, patterns)
        return nil if count.zero?
        return /\A[\s\S]*\z/ if count > MAX_PATTERNS

        sources = []
        count.times do |i|
          pattern = core(:array_get, patterns, i)
          return /\A[\s\S]*\z/ unless kind?(pattern, String)
          return /\A[\s\S]*\z/ if core(:string_size, pattern) > MAX_PATTERN_BYTES
          source = core(:string_slice, pattern, 0, MAX_PATTERN_BYTES).encode('UTF-8', invalid: :replace, undef: :replace).strip
          next if source.empty?

          # Only literal alternatives with optional anchors and escaped literal
          # punctuation. No repetition, groups, lookaround, backreferences, or
          # character classes: bounded input alone does not prevent ReDoS.
          return /\A[\s\S]*\z/ unless /\A\^?(?:[a-zA-Z0-9 _:@,\/-]|\\[.\^$|?*+()\[\]{}\\-])+(?:\|(?:[a-zA-Z0-9 _:@,\/-]|\\[.\^$|?*+()\[\]{}\\-])+)*\$?\z/.match?(source)
          sources << Regexp.new(source, Regexp::IGNORECASE)
        end
        sources.empty? ? nil : Regexp.union(sources)
      rescue SignalException, SystemExit
        raise
      rescue Exception
        /\A[\s\S]*\z/
      end

      def exhausted?(state)
        state[:nodes] <= 0 || state[:bytes] <= 0
      end

      def emit(value, state)
        return BUDGET_MARKER if state[:bytes] <= 0
        cost = value.bytesize * 6 + 8
        if cost > state[:bytes]
          state[:bytes] = 0
          return BUDGET_MARKER
        end
        # Account conservatively for JSON escaping and container punctuation.
        state[:bytes] -= cost
        value
      end

      def bounded_string(str, offset = 0)
        size = core(:string_size, str) - offset
        raw = core(:string_slice, str, offset, @max_string_length)
        # Older JRuby preserves String subclasses on byteslice; normalize the
        # already-bounded slice before calling encoding methods.
        raw = String.new(raw) if LEGACY_STRING_SLICE
        val = raw.encode('UTF-8', invalid: :replace, undef: :replace, replace: '?')
        [val, size > @max_string_length, size]
      end

      def text(str, state, key: false, offset: 0)
        val, truncated, size = bounded_string(str, offset)
        sensitive = key && @redact_keys_re && (truncated || @redact_keys_re.match?(val))
        if @redact_values_re
          # A cut can split a secret. With value redaction enabled, do not expose
          # any prefix of a string whose remaining bytes we have not examined.
          val = truncated ? '[REDACTED Value]' : val.gsub(@redact_values_re, '[REDACTED Value]')
        end
        if val.bytesize > @max_string_length
          val = val.byteslice(0, @max_string_length).scrub('?')
          truncated = true
        end
        val += "... [Truncated: +#{[size - @max_string_length, 0].max} more bytes]" if truncated
        result = emit(val, state)
        key ? [result, sensitive] : result
      end

      def symbol_text(obj, state)
        return emit('[Symbol]', state) unless SYMBOL_NAME
        text(SYMBOL_NAME.bind(obj).call, state)
      end

      def summary(obj, state)
        name = core(:class_name, core(:klass, obj))
        name = kind?(name, String) ? text(name, state) : 'anonymous'
        emit("[Obj: #{name}]", state)
      end

      def capture(obj, path, depth, state)
        return BUDGET_MARKER if exhausted?(state)
        state[:nodes] -= 1
        state[:bytes] -= 16
        return nil if core(:equal, obj, nil)
        return true if core(:equal, obj, true)
        return false if core(:equal, obj, false)
        if exact?(obj, Integer)
          return emit('[Integer: too large]', state) if core(:integer_bits, obj) > 256
          state[:bytes] -= 80
          return obj
        end
        if exact?(obj, Float)
          state[:bytes] -= 32
          return obj if core(:float_finite, obj)
          return emit('NaN', state) if core(:float_nan, obj)
          return emit(core(:float_positive, obj) ? 'Infinity' : '-Infinity', state)
        end
        return text(obj, state) if kind?(obj, String)
        return symbol_text(obj, state) if exact?(obj, Symbol)
        if kind?(obj, Proc)
          return emit(core(:proc_lambda, obj) ? '[Function: (lambda)]' : '[Function]', state)
        end
        if kind?(obj, Method) || kind?(obj, UnboundMethod)
          method = kind?(obj, Method) ? :method_name : :unbound_name
          return emit("[Function: #{symbol_text(core(method, obj), state)}]", state)
        end
        if exact?(obj, Time)
          # Formatting an astronomical year can allocate an astronomical string.
          return summary(obj, state) unless core(:time_compare, obj, TIME_MIN) >= 0 && core(:time_compare, obj, TIME_MAX) < 0
          format = core(:time_utc, obj) ? '%Y-%m-%dT%H:%M:%SZ' : '%Y-%m-%dT%H:%M:%S%:z'
          return text(core(:time_format, obj, format), state)
        end
        if exact?(obj, Date) || exact?(obj, DateTime)
          return summary(obj, state) unless core(:date_compare, obj, DATE_MIN) >= 0 && core(:date_compare, obj, DATE_MAX) < 0
          format = exact?(obj, Date) ? '%Y-%m-%d' : '%Y-%m-%dT%H:%M:%S%:z'
          return text(core(:date_format, obj, format), state)
        end

        id = core(:identity, obj)
        return emit("[REF - #{state[:visited][id][1]}]", state) if state[:visited].key?(id)
        if depth > @max_depth
          return emit("[Arr: #{core(:array_size, obj)}]", state) if exact?(obj, Array)
          return emit("[Obj: #{core(:hash_size, obj)} keys]", state) if exact?(obj, Hash)
          return summary(obj, state)
        end
        # Retain bounded references too: object IDs can otherwise be reused by
        # GC between separate roots sharing the same snapshot token.
        state[:visited][id] = [obj, path]

        if exact?(obj, Array)
          size = core(:array_size, obj)
          return sequence(size, path, depth, state) { |i| core(:array_get, obj, i) }
        end
        if exact?(obj, Set)
          return summary(obj, state) if defined?(MEMORY_SIZE) && MEMORY_SIZE.call(obj) > HASH_STORAGE_BYTES
          result = []
          if defined?(SET_EACH)
            size = SET_SIZE.bind(obj).call
            enumerate = ->(&block) { SET_EACH.bind(obj).call(&block) }
          else
            hash = core(:ivar, obj, :@hash)
            return summary(obj, state) unless exact?(hash, Hash)
            return summary(obj, state) if defined?(MEMORY_SIZE) && MEMORY_SIZE.call(hash) > HASH_STORAGE_BYTES
            size = core(:hash_size, hash)
            enumerate = lambda do |&block|
              core(:hash_each, hash) { |key, _value| block.call(key) }
            end
          end
          enumerate.call do |key|
            break if result.length >= @max_array_length || exhausted?(state)
            result << capture(key, "#{path}[#{result.length}]", depth + 1, state)
          end
          append_remaining(result, size, state)
          return result
        end
        if exact?(obj, Hash)
          return summary(obj, state) if defined?(MEMORY_SIZE) && MEMORY_SIZE.call(obj) > HASH_STORAGE_BYTES
          return properties(core(:hash_size, obj), path, depth, state) do |&block|
            core(:hash_each, obj, &block)
          end
        end
        if kind?(obj, Struct)
          # Struct#each_pair is native, but some runtimes build all member names.
          size = core(:struct_size, obj)
          return summary(obj, state) if size > MAX_ITEMS
          return properties(size, path, depth, state) { |&block| core(:struct_each, obj, &block) }
        end
        if defined?(OpenStruct) && exact?(obj, OpenStruct)
          table = core(:ivar, obj, :@table)
          return capture(table, path, depth, state) if exact?(table, Hash)
        end
        return java_capture(obj, path, depth, state) if defined?(JAVA_SEND) && kind?(obj, Java::JavaLang::Object)

        return summary(obj, state) unless kind?(obj, Object)
        # Even bound Exception#to_s calls a message object's to_s on CRuby and
        # JRuby. Keep exceptions and unsupported built-in subclasses opaque.
        if [Array, Hash, Set, Numeric, Exception, Regexp, Range, Time, Date].any? { |type| kind?(obj, type) }
          return summary(obj, state)
        end
        return summary(obj, state) if defined?(OpenStruct) && kind?(obj, OpenStruct)
        return summary(obj, state) if exhausted?(state)

        # Like Node's own-property-name enumeration, this native operation
        # materializes the full name list. Ruby has no bounded alternative.
        # Only subsequent field reads, recursion, and output are budget-bounded.
        names = core(:ivars, obj)
        size = core(:array_size, names)
        return summary(obj, state) if size.zero?
        properties(size, path, depth, state, ivars: true) do |&block|
          [size, @max_object_properties].min.times do |i|
            break if exhausted?(state)
            name = core(:array_get, names, i)
            block.call(name, core(:ivar, obj, name))
          end
        end
      rescue SignalException, SystemExit
        raise
      rescue Exception
        emit('[Serialization unavailable]', state)
      end

      def sequence(size, path, depth, state)
        result = []
        [size, @max_array_length].min.times do |i|
          break if exhausted?(state)
          result << capture(yield(i), "#{path}[#{i}]", depth + 1, state)
        end
        append_remaining(result, size, state)
        result
      end

      def append_remaining(result, size, state)
        remaining = size - result.length
        result << emit("[+ #{remaining} more items truncated]", state) if remaining > 0
      end

      def properties(size, path, depth, state, ivars: false, &enumerate)
        result = {}
        count = 0
        enumerate.call do |key, value|
          break if count >= @max_object_properties || exhausted?(state)
          count += 1
          state[:nodes] -= 1
          if kind?(key, String)
            name, sensitive = text(key, state, key: true)
          elsif exact?(key, Symbol) && SYMBOL_NAME
            name, sensitive = text(SYMBOL_NAME.bind(key).call, state, key: true, offset: ivars ? 1 : 0)
          elsif exact?(key, Integer) && core(:integer_bits, key) <= 256
            name, sensitive = text(core(:integer_string, key), state, key: true)
          else
            # Never hash, compare, inspect, or stringify application map keys.
            name = emit("[Opaque key #{count}]", state)
            sensitive = !!@redact_keys_re
          end
          child_path = path == '$' ? name : "#{path}.#{name}"
          child_path = child_path.byteslice(0, MAX_STRING_BYTES).scrub('?')
          result[name] = sensitive ? emit('[REDACTED Key]', state) : capture(value, child_path, depth + 1, state)
        end
        result['__probe_meta'] = emit("+ #{size - count} more properties truncated", state) if size > count
        result
      end

      def java_call(obj, method, types = [], *args)
        JAVA_SEND.bind(obj).call(method, types, *args)
      end

      def java_capture(obj, path, depth, state)
        # getClass is final. Bound java_send bypasses Ruby singleton overrides;
        # checking the actual Java class excludes Java/Ruby collection subclasses.
        name = java_call(java_call(obj, :getClass), :getName)
        case name
        when 'java.util.ArrayList', 'java.util.LinkedList'
          size = java_call(obj, :size)
          sequence(size, path, depth, state) { |i| java_call(obj, :get, [Java::int], i) }
        when 'java.util.LinkedHashMap'
          size = java_call(obj, :size)
          iterator = java_call(java_call(obj, :entrySet), :iterator)
          properties(size, path, depth, state) do |&block|
            [size, @max_object_properties].min.times do
              break if exhausted?(state) || !java_call(iterator, :hasNext)
              entry = java_call(iterator, :next)
              block.call(java_call(entry, :getKey), java_call(entry, :getValue))
            end
          end
        when 'java.util.LinkedHashSet'
          size = java_call(obj, :size)
          iterator = java_call(obj, :iterator)
          sequence(size, path, depth, state) { java_call(iterator, :next) }
        else
          # No POJO getters, Throwable accessors, equals, or toString. HashMap
          # and HashSet are opaque too: sparse bucket scans have unbounded work.
          summary(obj, state)
        end
      end
    end
  end
end
