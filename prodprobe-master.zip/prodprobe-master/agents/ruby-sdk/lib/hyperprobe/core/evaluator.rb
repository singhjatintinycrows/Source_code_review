# frozen_string_literal: true

require_relative 'safe_ast_validator'
require 'objspace' unless RUBY_PLATFORM.include?('java')

module HyperProbe
  module Core
    class Evaluator
      MAX_STRING_BYTES = 4096
      MAX_INTEGER_BITS = 1024
      MAX_COLLECTION_ITEMS = 128
      MAX_STEPS = 512
      MAX_TEMPLATE_BYTES = 16_384
      MAX_PLACEHOLDERS = 32
      MEMORY_SIZE = ObjectSpace.method(:memsize_of) if ObjectSpace.respond_to?(:memsize_of)
      JS_FLOAT_PREFIX_RE = /\A\s*([+-]?(?:(?:[0-9]+\.?[0-9]*)|(?:\.[0-9]+))(?:[eE][+-]?[0-9]+)?)/.freeze
      CLASS = Object.instance_method(:class)
      IDENTITY = BasicObject.instance_method(:equal?)
      LOCAL_GET = Binding.instance_method(:local_variable_get)
      LOCAL_DEFINED = Binding.instance_method(:local_variable_defined?)
      BINDING_EVAL = Binding.instance_method(:eval)
      TYPES = { string: String, integer: Integer, float: Float, symbol: Symbol,
                array: Array, hash: Hash, binding: Binding, nil: NilClass,
                 true: TrueClass, false: FalseClass }.freeze
      SYMBOL_NAME = if Symbol.method_defined?(:name)
                      Symbol.instance_method(:name)
                    elsif RUBY_PLATFORM.include?('java')
                      # JRuby 9.3 returns a constant-sized copy-on-write wrapper.
                      Symbol.instance_method(:to_s)
                    end
      # Bind captured builtin implementations, bypassing singleton overrides.
      # Only allowlisted interpreter operations reach this table.
      BUILTINS = {
        string: %i[bytesize byteslice [] length + == < <= > >= inspect to_f],
        integer: %i[bit_length + - * / % == < <= > >= +@ -@ to_f to_s],
        float: %i[+ - * / % == < <= > >= +@ -@ to_f to_s finite? nan? infinite? to_i],
        symbol: %i[== name inspect],
        array: %i[length []],
        hash: %i[length each_pair compare_by_identity?]
      }.each_with_object({}) do |(kind, methods), result|
        result[kind] = methods.to_h do |method|
          implementation = kind == :symbol && method == :name ? SYMBOL_NAME : TYPES.fetch(kind).instance_method(method)
          [method, implementation]
        end.freeze
      end.freeze

      class << self
        def safe_evaluation_enabled?(disable = nil)
          disable = ENV['HYPERPROBE_DISABLE_SAFE_EVALUATION'] if disable.nil?
          !(disable == true || (disable.is_a?(String) && disable.strip.downcase == 'true'))
        end

        def eval_condition(condition, binding_ctx, safe: safe_evaluation_enabled?)
          return true if blank?(condition)

          truthy?(evaluate(condition, binding_ctx, safe: safe))
        end

        def evaluate_watches(watch_expressions, binding_ctx, safe: safe_evaluation_enabled?)
          results = {}
          return results if kind(watch_expressions) == :nil
          raise SecurityError, 'Watches must be an exact builtin Array' unless kind(watch_expressions) == :array
          size = builtin(watch_expressions, :length)
          raise SecurityError, 'Too many watch expressions' if size > MAX_COLLECTION_ITEMS

          size.times do |index|
            expression = nil
            begin
              expression = SafeASTValidator.source(builtin(watch_expressions, :[], index))
              next if expression.strip.empty?
              results[expression] = evaluate(expression, binding_ctx, safe: safe)
            rescue StandardError, ScriptError, SecurityError => e
              results[expression || "<invalid expression #{index}>"] = "Error: #{e.class.name}: #{e.message}"
            end
          end
          results
        end

        def evaluate_log_template(template, binding_ctx, safe: safe_evaluation_enabled?)
          return '' if kind(template) == :nil

          text = SafeASTValidator.source(template, MAX_TEMPLATE_BYTES)
          characters = text.chars
          output = String.new
          cursor = 0
          placeholders = 0
          while cursor < characters.length
            unless ['$', '#'].include?(characters[cursor]) && characters[cursor + 1] == '{'
              output << characters[cursor]
              cursor += 1
              next
            end

            placeholders += 1
            raise SecurityError, 'Too many log placeholders' if placeholders > MAX_PLACEHOLDERS
            start = cursor + 2
            cursor = start
            depth = 1
            quote = nil
            escaped = false
            while cursor < characters.length && depth > 0
              char = characters[cursor]
              if quote
                if escaped
                  escaped = false
                elsif char == '\\'
                  escaped = true
                elsif char == quote
                  quote = nil
                end
              elsif ["'", '"'].include?(char)
                quote = char
              elsif char == '{'
                depth += 1
              elsif char == '}'
                depth -= 1
              end
              cursor += 1
            end

            begin
              raise ArgumentError, 'Unterminated log placeholder' unless depth.zero?
              value = evaluate(characters[start...(cursor - 1)].join, binding_ctx, safe: safe)
              rendered = display(value, [MAX_STEPS], 0)
              raise SecurityError, 'Log output is too large' if output.bytesize + rendered.bytesize > MAX_TEMPLATE_BYTES
              output << rendered
            rescue StandardError, ScriptError, SecurityError => e
              output << "<Error: #{e.class.name}: #{e.message}>"
            end
            raise SecurityError, 'Log output is too large' if output.bytesize > MAX_TEMPLATE_BYTES
          end
          raise SecurityError, 'Log output is too large' if output.bytesize > MAX_TEMPLATE_BYTES
          output
        end

        def evaluate_metric(metric_expression, binding_ctx, safe: safe_evaluation_enabled?)
          return nil if blank?(metric_expression)

          coerce_metric_value(evaluate(metric_expression, binding_ctx, safe: safe))
        end

        def evaluate_correlation(correlation_expression, binding_ctx, safe: safe_evaluation_enabled?)
          return 'static-singleton' if blank?(correlation_expression)

          normalize_correlation_value(evaluate(correlation_expression, binding_ctx, safe: safe))
        end

        def coerce_metric_value(value)
          case kind(value)
          when :integer, :float
            checked(value)
            number = builtin(value, :to_f)
          when :string
            match = JS_FLOAT_PREFIX_RE.match(copy_string(value))
            number = match && match[1].to_f
          else
            return nil
          end
          number && builtin(number, :finite?) ? number : nil
        end

        def normalize_correlation_value(value)
          case kind(value)
          when :nil
            'static-singleton'
          when :true, :false
            raise TypeError, 'Correlation expression must evaluate to a string or number, got boolean'
          when :string
            copy = copy_string(value)
            raise StandardError, copy if copy.start_with?('Error: ')
            copy.freeze
          when :integer
            builtin(checked(value), :to_s).freeze
          when :float
            return 'NaN' if builtin(value, :nan?)
            infinite = builtin(value, :infinite?)
            return infinite == 1 ? 'Infinity' : '-Infinity' if infinite
            return builtin(checked(builtin(value, :to_i)), :to_s).freeze if builtin(value, :%, 1.0).zero?

            builtin(value, :to_s).freeze
          else
            type = { array: 'Array', hash: 'Hash', symbol: 'Symbol' }[kind(value)] || 'unsupported object'
            raise TypeError, "Correlation expression must evaluate to a string or number, got #{type}"
          end
        end

        private

        def kind(value)
          type = CLASS.bind(value).call
          TYPES.each { |name, trusted| return name if IDENTITY.bind(trusted).call(type) }
          :unsupported
        end

        def builtin(value, method, *args, &block)
          implementation = BUILTINS.fetch(kind(value)).fetch(method)
          implementation.bind(value).call(*args, &block)
        end

        def truthy?(value)
          !IDENTITY.bind(value).call(nil) && !IDENTITY.bind(value).call(false)
        end

        def blank?(expression)
          kind(expression) == :nil || SafeASTValidator.source(expression).strip.empty?
        end

        def copy_string(value)
          raise SecurityError, 'String exceeds expression limit' if builtin(value, :bytesize) > MAX_STRING_BYTES
          copy = builtin(value, :byteslice, 0, MAX_STRING_BYTES + 1)
          raise SecurityError, 'String exceeds expression limit' if copy.bytesize > MAX_STRING_BYTES
          copy
        end

        def checked(value)
          case kind(value)
          when :integer
            raise SecurityError, 'Number exceeds expression limit' if builtin(value, :bit_length) > MAX_INTEGER_BITS
          when :string
            return copy_string(value)
          when :symbol
            if builtin(builtin(value, :name), :bytesize) > MAX_STRING_BYTES
              raise SecurityError, 'Symbol exceeds expression limit'
            end
          end
          value
        end

        def step!(budget)
          budget[0] -= 1
          raise SecurityError, 'Expression step limit exceeded' if budget[0] < 0
        end

        def evaluate(expression, binding_ctx, safe:)
          raise SecurityError, 'Expected an exact builtin Binding' unless kind(binding_ctx) == :binding
          if safe == false
            # Explicit opt-in executes Ruby in the hit binding, with application
            # permissions and side effects. Source and output size limits remain.
            return BINDING_EVAL.bind(binding_ctx).call(SafeASTValidator.source(expression), '(hyperprobe)', 1)
          end

          tree = SafeASTValidator.parse!(expression)
          execute(tree, binding_ctx, [MAX_STEPS])
        end

        def execute(node, binding_ctx, budget)
          step!(budget)
          case node[0]
          when :literal
            checked(node[1])
          when :local
            unless LOCAL_DEFINED.bind(binding_ctx).call(node[1])
              raise NameError, "Unknown local variable '#{node[1]}'"
            end
            checked(LOCAL_GET.bind(binding_ctx).call(node[1]))
          when :array
            node[1].map { |item| execute(item, binding_ctx, budget) }
          when :hash
            node[1].each_with_object({}) do |(key_node, value_node), hash|
              key = primitive_key(execute(key_node, binding_ctx, budget))
              hash[key] = execute(value_node, binding_ctx, budget)
            end
          when :lookup
            receiver = execute(node[1], binding_ctx, budget)
            index = execute(node[2], binding_ctx, budget)
            lookup(receiver, index, budget)
          when :length
            receiver = execute(node[1], binding_ctx, budget)
            unless %i[string array hash].include?(kind(receiver))
              raise SecurityError, 'length/size requires an exact builtin String, Array or Hash'
            end
            builtin(receiver, :length)
          when :conditional
            branch = truthy?(execute(node[1], binding_ctx, budget)) ? node[2] : node[3]
            execute(branch, binding_ctx, budget)
          when :unary
            value = execute(node[2], binding_ctx, budget)
            return !truthy?(value) if %i[! not].include?(node[1])
            raise SecurityError, 'Unary arithmetic requires builtin numbers' unless numeric?(value)
            checked(builtin(value, node[1]))
          when :binary
            left = execute(node[2], binding_ctx, budget)
            operator = node[1]
            if %i[&& and].include?(operator)
              return truthy?(left) ? execute(node[3], binding_ctx, budget) : left
            elsif %i[|| or].include?(operator)
              return truthy?(left) ? left : execute(node[3], binding_ctx, budget)
            end
            right = execute(node[3], binding_ctx, budget)
            binary(left, operator, right)
          else
            raise SecurityError, 'Unsupported expression instruction'
          end
        end

        def numeric?(value)
          %i[integer float].include?(kind(value))
        end

        def primitive_key(value)
          unless %i[string symbol integer float nil true false].include?(kind(value))
            raise SecurityError, 'Hash keys must be builtin primitives'
          end
          if kind(value) == :float && !builtin(value, :finite?)
            raise SecurityError, 'Hash keys must be finite'
          end
          # Numeric and symbol objects cannot carry singleton overrides. Strings
          # must be copied before insertion, which invokes hash/eql? internally.
          checked(value)
        end

        def lookup(receiver, index, budget)
          case kind(receiver)
          when :array, :string
            raise SecurityError, 'Subscript must be a builtin Integer' unless kind(index) == :integer
            # Oversized indices must not reach native long conversion.
            return nil if builtin(index, :bit_length) > 62
            checked(builtin(receiver, :[], index))
          when :hash
            key = primitive_key(index)
            raise SecurityError, 'Identity hash lookup is unsupported' if builtin(receiver, :compare_by_identity?)
            raise SecurityError, 'Hash exceeds lookup limit' if builtin(receiver, :length) > MAX_COLLECTION_ITEMS
            if defined?(MEMORY_SIZE) && MEMORY_SIZE.call(receiver) > 131_072
              raise SecurityError, 'Hash storage exceeds lookup limit'
            end
            # Hash#[]/fetch can execute default procs or custom hash/eql? keys.
            # A bounded scan avoids all of those hooks, even on missing keys.
            builtin(receiver, :each_pair) do |stored, value|
              step!(budget)
              stored = primitive_key(stored)
              next unless kind(stored) == kind(key)
              return checked(value) if primitive_equal?(stored, key)
            end
            nil
          else
            raise SecurityError, 'Subscript requires an exact builtin Array, Hash or String'
          end
        end

        def primitive_equal?(left, right)
          left_kind = kind(left)
          right_kind = kind(right)
          allowed = %i[string symbol integer float nil true false]
          unless allowed.include?(left_kind) && allowed.include?(right_kind)
            raise SecurityError, 'Comparison requires builtin primitives'
          end
          if numeric?(left) && numeric?(right)
            builtin(left, :==, right)
          elsif left_kind != right_kind
            false
          elsif %i[nil true false].include?(left_kind)
            true
          else
            builtin(left, :==, right)
          end
        end

        def binary(left, operator, right)
          if %i[== !=].include?(operator)
            equal = primitive_equal?(left, right)
            return operator == :== ? equal : !equal
          end
          if numeric?(left) && numeric?(right)
            result = builtin(left, operator, right)
            if kind(result) == :float && !builtin(result, :finite?)
              raise SecurityError, 'Non-finite arithmetic result'
            end
            return checked(result)
          end
          if kind(left) == :string && kind(right) == :string && %i[+ < <= > >=].include?(operator)
            if operator == :+ && builtin(left, :bytesize) + builtin(right, :bytesize) > MAX_STRING_BYTES
              raise SecurityError, 'String computation exceeds expression limit'
            end
            return builtin(left, operator, right)
          end
          raise SecurityError, 'Operator requires builtin numbers or supported string operands'
        end

        def display(value, budget, depth, nested = false)
          step!(budget)
          raise SecurityError, 'Log value nesting limit exceeded' if depth > SafeASTValidator::MAX_DEPTH
          value = checked(value)
          result = case kind(value)
                   when :string
                     nested ? builtin(value, :inspect) : value
                   when :integer, :float
                     builtin(value, :to_s)
                   when :symbol
                     builtin(value, :inspect)
                   when :nil, :true, :false
                     { nil: 'nil', true: 'true', false: 'false' }.fetch(kind(value))
                   when :array
                     size = builtin(value, :length)
                     raise SecurityError, 'Log collection exceeds limit' if size > MAX_COLLECTION_ITEMS
                     parts = []
                     size.times do |index|
                       parts << display(builtin(value, :[], index), budget, depth + 1, true)
                       raise SecurityError, 'Log value exceeds limit' if parts.sum(&:bytesize) > MAX_STRING_BYTES
                     end
                     "[#{parts.join(', ')}]"
                   when :hash
                     raise SecurityError, 'Log collection exceeds limit' if builtin(value, :length) > MAX_COLLECTION_ITEMS
                     parts = []
                     builtin(value, :each_pair) do |key, item|
                       parts << "#{display(key, budget, depth + 1, true)}=>#{display(item, budget, depth + 1, true)}"
                       raise SecurityError, 'Log value exceeds limit' if parts.sum(&:bytesize) > MAX_STRING_BYTES
                     end
                     "{#{parts.join(', ')}}"
                   else
                     raise SecurityError, 'Log rendering requires builtin primitives or containers'
                   end
          raise SecurityError, 'Log value exceeds limit' if result.bytesize > MAX_STRING_BYTES
          result
        end
      end
    end
  end
end
