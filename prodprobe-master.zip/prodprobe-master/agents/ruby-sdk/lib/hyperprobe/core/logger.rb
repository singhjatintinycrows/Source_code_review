# frozen_string_literal: true

require 'time'

module HyperProbe
  module Core
    class Logger
      COLOR_CODES = [32, 33, 34, 35, 36, 31, 92, 93, 94, 95, 96, 91].freeze # Vibrant ANSI colors
      DISABLED_COLOR_VALUES = %w[0 false no off].freeze
      SELECTOR_SEPARATOR = /[\s,]+/.freeze

      @logger_cache = {}
      @cache_mutex = Mutex.new

      class << self
        def get_logger(namespace = 'hyperprobe:agent')
          @cache_mutex.synchronize do
            @logger_cache[namespace.to_s] ||= new(namespace.to_s)
          end
        end

        def is_namespace_enabled?(namespace, debug_value = nil)
          val = debug_value.nil? ? ENV['DEBUG'] : debug_value
          return false if val.nil? || val.strip.empty?

          enabled_patterns, skipped_patterns = parse_selectors(val)

          # Check exclusions first
          return false if skipped_patterns.any? { |p| p.match?(namespace) }

          # Check inclusions
          enabled_patterns.any? { |p| p.match?(namespace) }
        end

        def parse_selectors(value)
          enabled = []
          skipped = []

          (value || '').split(SELECTOR_SEPARATOR).each do |selector|
            clean = selector.strip
            next if clean.empty?

            is_skip = clean.start_with?('-')
            raw_pattern = is_skip ? clean[1..-1] : clean
            next if raw_pattern.nil? || raw_pattern.empty?

            regex = compile_selector(raw_pattern)
            if is_skip
              skipped << regex
            else
              enabled << regex
            end
          end

          [enabled, skipped]
        end

        def compile_selector(pattern)
          regex_str = '^' + Regexp.escape(pattern).gsub('\\*', '.*?') + '$'
          Regexp.new(regex_str, Regexp::IGNORECASE)
        end

        def reset_cache!
          @cache_mutex.synchronize do
            @logger_cache.clear
          end
        end
      end

      attr_reader :namespace, :enabled, :color

      def initialize(namespace = 'hyperprobe:agent')
        @namespace = namespace.to_s
        @enabled = self.class.is_namespace_enabled?(@namespace)
        @color = select_namespace_color(@namespace)
        @last_log_time_ms = monotonic_ms
        @mutex = Mutex.new
      end

      def debug_enabled?
        @enabled
      end

      alias is_debug_enabled debug_enabled?

      def debug(message)
        return unless @enabled

        write_log(message, $stdout)
      end

      def info(message)
        if @enabled
          write_log(message, $stdout)
        end
      end

      def warn(message)
        timestamp = Time.now.utc.strftime('%Y-%m-%d %H:%M:%S.%L')
        formatted = "#{timestamp} \e[33m[HyperProbe WARN]\e[0m [#{@namespace}] #{message}"
        emit($stdout, formatted)
      end

      def error(message, exception = nil)
        timestamp = Time.now.utc.strftime('%Y-%m-%d %H:%M:%S.%L')
        formatted = "#{timestamp} \e[31m[HyperProbe ERROR]\e[0m [#{@namespace}] #{message}"
        emit($stderr, formatted)
        if exception
          type = Kernel.instance_method(:class).bind(exception).call
          emit($stderr, "  #{Module.instance_method(:name).bind(type).call}")
        end
      rescue SignalException, SystemExit
        raise
      rescue Exception
        nil
      end

      def force_info(message)
        timestamp = Time.now.utc.strftime('%Y-%m-%d %H:%M:%S.%L')
        formatted = "#{timestamp} \e[34mHyperProbe\e[0m -- [#{@namespace}] #{message}"
        emit($stdout, formatted)
      end

      alias forceInfo force_info

      def force_error(message, exception = nil)
        error(message, exception)
      end

      alias forceError force_error

      private

      def write_log(message, stream)
        now = monotonic_ms
        delta_str = ''

        return unless @mutex.try_lock
        begin
          delta = now - @last_log_time_ms
          delta_str = " \e[#{@color}m+#{delta}ms\e[0m" if delta > 0
          @last_log_time_ms = now
        ensure
          @mutex.unlock
        end

        prefix = if colors_enabled?(stream)
                   "\e[1m\e[#{@color}m#{@namespace}\e[0m"
                 else
                   @namespace
                 end

        emit(stream, "  #{prefix} \e[90m#{message}\e[0m#{delta_str}")
      rescue SignalException, SystemExit
        raise
      rescue Exception
        nil
      end

      def emit(stream, message)
        line = "#{message}\n".byteslice(0, 4096)
        if IO === stream
          IO.instance_method(:write_nonblock).bind(stream).call(line, exception: false)
        elsif defined?(StringIO) && StringIO === stream
          StringIO.instance_method(:write).bind(stream).call(line)
        end
      rescue SignalException, SystemExit
        raise
      rescue Exception
        # Never block or call arbitrary application output adapters.
        nil
      end

      def select_namespace_color(ns)
        hash_val = 0
        ns.each_char.with_index do |char, idx|
          hash_val += (idx + 1) * char.ord
        end
        COLOR_CODES[hash_val % COLOR_CODES.length]
      end

      def colors_enabled?(stream)
        configured = ENV['DEBUG_COLORS']
        if configured
          return !DISABLED_COLOR_VALUES.include?(configured.strip.downcase)
        end

        IO === stream && IO.instance_method(:tty?).bind(stream).call
      rescue StandardError
        false
      end

      def monotonic_ms
        Process.clock_gettime(Process::CLOCK_MONOTONIC, :millisecond)
      end
    end
  end
end
