# frozen_string_literal: true

require 'ripper'

module HyperProbe
  module Core
    # This is deliberately a small expression language, not read-only Ruby.
    # Compile the entire tree before executing even a short-circuited branch.
    class SafeASTValidator
      MAX_EXPRESSION_LENGTH = 256
      MAX_NODES = 128
      MAX_DEPTH = 32
      BINARY_OPERATORS = %i[+ - * / % == != < <= > >= && || and or].freeze
      UNARY_OPERATORS = %i[+@ -@ ! not].freeze
      CLASS = Object.instance_method(:class)
      IDENTITY = BasicObject.instance_method(:equal?)
      STRING_SIZE = String.instance_method(:bytesize)
      STRING_SLICE = String.instance_method(:byteslice)

      class << self
        def validate!(expression)
          parse!(expression)
          nil
        end

        # Copy through a builtin, never dup/clone/to_str hooks on application data.
        def source(expression, limit = MAX_EXPRESSION_LENGTH)
          unless IDENTITY.bind(CLASS.bind(expression).call).call(String)
            raise SecurityError, 'Expression must be an exact builtin String'
          end
          if STRING_SIZE.bind(expression).call > limit
            raise SecurityError, "Expression is too long (max #{limit} bytes)"
          end

          copy = STRING_SLICE.bind(expression).call(0, limit + 1)
          raise SecurityError, "Expression is too long (max #{limit} bytes)" if copy.bytesize > limit
          copy
        end

        def parse!(expression)
          return [:literal, nil] if IDENTITY.bind(expression).call(nil)

          text = source(expression)
          return [:literal, nil] if text.strip.empty?

          tree = Ripper.sexp(text)
          raise ArgumentError, 'Invalid expression syntax' unless tree

          # Only ordinary quoted strings are supported. Decode their contents
          # ourselves; Ripper returns escaped source, not evaluated strings.
          strings = {}
          quote = nil
          Ripper.lex(text).each do |position, type, token, _state|
            case type
            when :on_tstring_beg
              reject!('string syntax') unless ["'", '"'].include?(token)
              quote = token
            when :on_tstring_content
              strings[position] = decode_string(token, quote)
            when :on_tstring_end
              quote = nil
            when :on_embexpr_beg, :on_embvar, :on_heredoc_beg
              reject!('string interpolation or heredoc')
            end
          end

          compile(tree, strings, [0], 0)
        end

        # Kept for callers that used to clear the lexical validator's cache.
        # Parsing is bounded and no user-controlled expressions are retained.
        def reset_cache!; end

        private

        def reject!(feature)
          raise SecurityError, "Unsupported #{feature}: forbidden in probe expressions"
        end

        def decode_string(text, quote)
          reject!('string syntax') unless quote
          text.gsub(/\\(.)/m) do
            char = Regexp.last_match(1)
            if quote == "'"
              ["'", '\\'].include?(char) ? char : "\\#{char}"
            else
              escapes = { 'n' => "\n", 'r' => "\r", 't' => "\t", '\\' => '\\', '"' => '"', "'" => "'", '#' => '#' }
              reject!('string escape') unless escapes.key?(char)
              escapes[char]
            end
          end
        end

        def compile(node, strings, budget, depth)
          budget[0] += 1
          reject!('expression complexity') if budget[0] > MAX_NODES || depth > MAX_DEPTH
          child = ->(value) { compile(value, strings, budget, depth + 1) }

          case node[0]
          when :program, :paren
            reject!('multiple statements') unless node[1]&.length == 1
            child.call(node[1][0])
          when :vcall, :var_ref
            token = node[1]
            if token[0] == :@ident
              [:local, token[1]]
            elsif token[0] == :@kw && %w[true false nil].include?(token[1])
              [:literal, { 'true' => true, 'false' => false, 'nil' => nil }[token[1]]]
            else
              reject!('variable or constant access')
            end
          when :@int
            [:literal, Integer(node[1])]
          when :@float
            [:literal, Float(node[1])]
          when :string_literal
            content = node[1]
            reject!('string syntax') unless content[0] == :string_content
            value = content.drop(1).map do |part|
              reject!('string interpolation') unless part[0] == :@tstring_content
              strings.fetch(part[2])
            end.join
            [:literal, value]
          when :symbol_literal
            symbol = node[1]
            reject!('symbol syntax') unless symbol[0] == :symbol && %i[@ident @op @kw].include?(symbol[1][0])
            [:literal, symbol[1][1].to_sym]
          when :@label
            [:literal, node[1][0...-1].to_sym]
          when :array
            [:array, (node[1] || []).map { |item| child.call(item) }]
          when :hash
            pairs = node[1]
            reject!('hash syntax') if pairs && pairs[0] != :assoclist_from_args
            [:hash, (pairs ? pairs[1] : []).map do |pair|
              reject!('hash expansion') unless pair[0] == :assoc_new
              [child.call(pair[1]), child.call(pair[2])]
            end]
          when :aref
            args = node[2]
            unless args && args[0] == :args_add_block && args[2] == false && args[1].length == 1
              reject!('subscript arguments')
            end
            [:lookup, child.call(node[1]), child.call(args[1][0])]
          when :call
            unless (node[2][0] == :@period || node[2] == :'.') && node[3][0] == :@ident && %w[length size].include?(node[3][1])
              reject!('method call')
            end
            [:length, child.call(node[1])]
          when :method_add_arg
            unless node[1][0] == :call && node[2] == [:arg_paren, nil]
              reject!('method arguments or function call')
            end
            child.call(node[1])
          when :binary
            reject!('operator') unless BINARY_OPERATORS.include?(node[2])
            [:binary, node[2], child.call(node[1]), child.call(node[3])]
          when :unary
            reject!('unary operator') unless UNARY_OPERATORS.include?(node[1])
            [:unary, node[1], child.call(node[2])]
          when :ifop
            [:conditional, child.call(node[1]), child.call(node[2]), child.call(node[3])]
          else
            reject!("syntax #{node[0]}")
          end
        end
      end
    end
  end
end
