# frozen_string_literal: true

module HyperProbe
  module Core
    class TraceExtractor
      class << self
        def extract_trace_context(custom_get_trace_id = nil)
          # 1. Custom User Hook (Passed via options[:set_trace_id])
          if custom_get_trace_id.respond_to?(:call)
            begin
              trace_id = custom_get_trace_id.call
              return trace_id.to_s if trace_id && !trace_id.to_s.empty?
            rescue StandardError
              # Never fail on user hook error
            end
          end

          # 2. OpenTelemetry
          if defined?(::OpenTelemetry::Trace)
            begin
              span = ::OpenTelemetry::Trace.current_span
              if span && span.respond_to?(:context)
                ctx = span.context
                if ctx
                  if ctx.respond_to?(:hex_trace_id)
                    trace_id = ctx.hex_trace_id
                    return trace_id if trace_id && trace_id != '00000000000000000000000000000000'
                  elsif ctx.respond_to?(:trace_id) && ctx.trace_id
                    raw_id = ctx.trace_id
                    hex_id = raw_id.is_a?(String) ? raw_id.unpack1('H*') : raw_id.to_s(16)
                    return hex_id if hex_id && hex_id != '00000000000000000000000000000000'
                  end
                end
              end
            rescue StandardError
              # Silently ignore OTel errors
            end
          end

          # 3. Datadog
          if defined?(::Datadog::Tracing)
            begin
              if ::Datadog::Tracing.respond_to?(:active_trace)
                trace = ::Datadog::Tracing.active_trace
                trace_id = trace&.id&.to_s
                return trace_id if trace_id && !trace_id.empty?
              end
              if ::Datadog::Tracing.respond_to?(:active_span)
                span = ::Datadog::Tracing.active_span
                trace_id = span&.trace_id&.to_s
                return trace_id if trace_id && !trace_id.empty?
              end
            rescue StandardError
              # Silently ignore Datadog errors
            end
          end

          # 4. New Relic
          if defined?(::NewRelic::Agent)
            begin
              if defined?(::NewRelic::Agent::Tracer) && ::NewRelic::Agent::Tracer.respond_to?(:current_trace_id)
                trace_id = ::NewRelic::Agent::Tracer.current_trace_id
                return trace_id if trace_id && !trace_id.empty?
              end
              if ::NewRelic::Agent.respond_to?(:linking_metadata)
                metadata = ::NewRelic::Agent.linking_metadata
                trace_id = metadata['trace.id'] || metadata[:trace_id]
                return trace_id.to_s if trace_id && !trace_id.to_s.empty?
              end
            rescue StandardError
              # Silently ignore New Relic errors
            end
          end

          # 5. Elastic APM
          if defined?(::ElasticAPM)
            begin
              if ::ElasticAPM.respond_to?(:current_transaction)
                txn = ::ElasticAPM.current_transaction
                trace_id = txn&.trace_id
                return trace_id if trace_id && !trace_id.empty?
              end
            rescue StandardError
              # Silently ignore Elastic APM errors
            end
          end

          # 6. Java APMs (When running on JRuby / JVM)
          if defined?(JRUBY_VERSION) || defined?(Java)
            trace_id = extract_java_apm_trace_context
            return trace_id if trace_id && !trace_id.empty?
          end

          nil
        end

        private

        def extract_java_apm_trace_context
          # 6a. Java OpenTelemetry
          if defined?(Java::IoOpentelemetryApiTrace::Span)
            begin
              span = Java::IoOpentelemetryApiTrace::Span.current
              if span
                ctx = span.getSpanContext rescue nil
                tid = ctx&.getTraceId
                return tid.to_s if tid && tid.to_s != '00000000000000000000000000000000' && !tid.to_s.empty?
              end
            rescue StandardError
            end
          end

          # 6b. Java Datadog
          if defined?(Java::DatadogTraceApi::CorrelationIdentifier)
            begin
              tid = Java::DatadogTraceApi::CorrelationIdentifier.getTraceId
              return tid.to_s if tid && tid.to_s != '0' && !tid.to_s.empty?
            rescue StandardError
            end
          end

          # 6c. Java New Relic
          if defined?(Java::ComNewrelicApiAgent::NewRelic)
            begin
              tid = Java::ComNewrelicApiAgent::NewRelic.getAgent.getTraceMetadata.getTraceId rescue nil
              return tid.to_s if tid && !tid.to_s.empty?
            rescue StandardError
            end
          end

          # 6d. Java Brave / Zipkin
          if defined?(Java::Brave::Tracing)
            begin
              tracer = Java::Brave::Tracing.currentTracer rescue nil
              span = tracer&.currentSpan rescue nil
              tid = span&.context&.traceIdString rescue nil
              return tid.to_s if tid && !tid.to_s.empty?
            rescue StandardError
            end
          end

          # 6e. Java SkyWalking
          if defined?(Java::OrgApacheSkywalkingApmToolkitTrace::TraceContext)
            begin
              tid = Java::OrgApacheSkywalkingApmToolkitTrace::TraceContext.traceId rescue nil
              return tid.to_s if tid && !tid.to_s.empty? && tid.to_s != 'N/A'
            rescue StandardError
            end
          end

          nil
        rescue StandardError
          nil
        end
      end
    end
  end
end
