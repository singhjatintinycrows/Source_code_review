# frozen_string_literal: true

module HyperProbe
  module Core
    class TokenBucket
      attr_reader :capacity, :tokens

      def initialize(capacity, refill_rate_per_sec)
        @capacity = capacity.to_f
        @refill_rate = refill_rate_per_sec.to_f / 1000.0 # tokens per millisecond
        @tokens = @capacity
        @last_refill = monotonic_ms
        @mutex = Mutex.new
      end

      def try_consume(count = 1)
        @mutex.synchronize do
          refill
          if @tokens >= count
            @tokens -= count
            true
          else
            false
          end
        end
      end

      def reserve(count)
        @mutex.synchronize do
          refill
          if @tokens >= count
            @tokens -= count
            BandwidthReservation.new(self, count)
          else
            nil
          end
        end
      end

      def release_tokens(count)
        @mutex.synchronize do
          @tokens = [@capacity, @tokens + count].min
        end
      end

      private

      def refill
        now = monotonic_ms
        delta = now - @last_refill
        amount = delta * @refill_rate
        @tokens = [@capacity, @tokens + amount].min
        @last_refill = now
      end

      def monotonic_ms
        Process.clock_gettime(Process::CLOCK_MONOTONIC, :millisecond)
      end
    end

    class BandwidthReservation
      attr_reader :tokens

      def initialize(bucket, tokens)
        @bucket = bucket
        @tokens = tokens
        @committed = false
        @released = false
        @mutex = Mutex.new
      end

      def commit
        @mutex.synchronize do
          @committed = true
        end
      end

      def release
        @mutex.synchronize do
          return if @committed || @released

          @released = true
          @bucket.release_tokens(@tokens)
        end
      end
    end

    class QuotaManager
      def initialize(hits_per_sec = 10, bytes_per_sec = 200 * 1024)
        @eval_bucket = TokenBucket.new(hits_per_sec, hits_per_sec)
        @bandwidth_bucket = TokenBucket.new(bytes_per_sec, bytes_per_sec)
      end

      def can_evaluate?
        @eval_bucket.try_consume(1)
      end

      alias can_evaluate can_evaluate?

      def can_send?(bytes)
        @bandwidth_bucket.try_consume(bytes)
      end

      alias can_send can_send?

      def reserve_bandwidth(bytes)
        @bandwidth_bucket.reserve(bytes)
      end
    end
  end
end
