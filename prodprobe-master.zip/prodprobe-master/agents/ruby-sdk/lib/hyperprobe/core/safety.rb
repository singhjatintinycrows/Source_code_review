# frozen_string_literal: true

require 'monitor'
require 'java' if RUBY_ENGINE == 'jruby'

module HyperProbe
  module Core
    module AgentHealth
      GREEN = :GREEN
      YELLOW = :YELLOW
      RED = :RED
    end

    class SafetyMonitor
      SAMPLE_INTERVAL_SECONDS = 0.1
      LAG_WINDOW_SIZE = 10
      LAG_YELLOW_BREACHES = 4
      LAG_RED_BREACHES = 7
      SEVERE_LAG_WINDOW_SIZE = 5
      SEVERE_LAG_RED_BREACHES = 3
      SEVERE_LAG_MULTIPLIER = 4.0
      HEAP_SAMPLE_INTERVAL_MS = 5000.0
      HEAP_YELLOW_FRACTION = 0.15
      HEAP_RED_FRACTION = 0.05

      attr_reader :health, :last_thread_lag_ms, :cumulative_pause_time, :max_lag_ms, :pause_budget_ms

      def initialize(on_state_change, max_lag_ms: 50.0, pause_budget_ms: 15.0, is_ephemeral_lambda: false,
                     heap_runtime: (RUBY_ENGINE == 'jruby' ? Java::JavaLang::Runtime.get_runtime : nil))
        @on_state_change = on_state_change
        @max_lag_ms = max_lag_ms.to_f
        @pause_budget_ms = pause_budget_ms.to_f
        @is_ephemeral_lambda = is_ephemeral_lambda
        @heap_runtime = heap_runtime
        @heap_available_fraction = 1.0

        @health = AgentHealth::GREEN
        @last_heartbeat = monotonic_ms
        @last_thread_lag_ms = 0.0
        @thread_lag_samples = []
        @cumulative_pause_time = 0.0
        @last_window_reset = monotonic_ms

        @mutex = Mutex.new
        @notification_mutex = Monitor.new
        @transition_generation = 0
        @running = false
        @thread = nil
      end

      def start
        @mutex.synchronize do
          return if @running && @thread&.alive?

          @running = true
          @last_heartbeat = monotonic_ms
          @last_window_reset = monotonic_ms
          @last_heap_sample = @last_window_reset

          @thread = Thread.new { monitor_loop }
          @thread.name = 'hyperprobe-safety' if @thread.respond_to?(:name=)
        end
      end

      def after_fork
        @mutex.synchronize do
          @running = false
          @thread = nil
        end
        start
      end

      def stop
        thread = @mutex.synchronize do
          @running = false
          current = @thread
          @thread = nil
          current
        end
        return if !thread || thread == Thread.current

        thread.kill
        thread.join(0.1)
      rescue Exception
        # Stop is agent-owned cleanup, including when called from a trap.
      end

      def report_pause_duration(ms)
        callback_info = nil
        return unless @mutex.try_lock
        begin
          @cumulative_pause_time += ms.to_f
          callback_info = evaluate_health_locked
          # A live monitor delivers transitions off the application thread.
          @pending_notification = callback_info if @running && callback_info
        ensure
          @mutex.unlock
        end
        trigger_callback(callback_info) if callback_info && !@running
      end

      def record_thread_lag(thread_lag_ms)
        callback_info = nil
        @mutex.synchronize do
          record_thread_lag_locked(thread_lag_ms)
          callback_info = evaluate_health_locked
        end
        trigger_callback(callback_info) if callback_info
      end

      def get_health
        @mutex.synchronize { @health }
      end

      def with_health(expected)
        @notification_mutex.synchronize do
          return unless @mutex.synchronize { @health == expected }

          yield
        end
      rescue Exception
        # Serialize cooldown actions with transition delivery, not state updates.
      end

      private

      def monitor_loop
        while @running
          wait_started = monotonic_ms
          sleep SAMPLE_INTERVAL_SECONDS
          break unless @running

          callback_info = nil
          @mutex.synchronize do
            now = monotonic_ms
            # Expected interval is 100ms; excess time is lag/jitter
            thread_lag_ms = [0.0, now - wait_started - (SAMPLE_INTERVAL_SECONDS * 1000.0)].max
            record_thread_lag_locked(thread_lag_ms)

            if @heap_runtime && !@is_ephemeral_lambda && now - @last_heap_sample >= HEAP_SAMPLE_INTERVAL_MS
              sample_heap_locked
              @last_heap_sample = now
            end

            # Reset pause budget window every second
            if now - @last_window_reset > 1000.0
              @cumulative_pause_time = 0.0
              @last_window_reset = now
            end

            callback_info = evaluate_health_locked || @pending_notification
            @pending_notification = nil
          end

          trigger_callback(callback_info) if callback_info
        end
      rescue Exception
        @running = false
      end

      def record_thread_lag_locked(lag_ms)
        clean_lag = [0.0, lag_ms.to_f].max
        @last_thread_lag_ms = clean_lag
        @thread_lag_samples << clean_lag
        @thread_lag_samples.shift while @thread_lag_samples.length > LAG_WINDOW_SIZE
      end

      def sample_heap_locked
        maximum = @heap_runtime.max_memory.to_f
        return unless maximum.positive?

        committed = @heap_runtime.total_memory
        free = @heap_runtime.free_memory
        @heap_available_fraction = (free + maximum - committed) / maximum
      rescue Exception
        # Preserve the last heap health and retry at the next sample.
      end

      def evaluate_health_locked
        prev_health = @health
        reason = nil

        if @is_ephemeral_lambda
          @health = AgentHealth::GREEN
          return nil if prev_health == AgentHealth::GREEN

          @transition_generation += 1
          return [@health, 'System stabilized in Lambda mode.', @transition_generation]
        end

        recent_lags = @thread_lag_samples.dup
        lag_breaches = recent_lags.count { |lag| lag > @max_lag_ms }
        severe_lag_ms = @max_lag_ms * SEVERE_LAG_MULTIPLIER
        severe_window = recent_lags.last(SEVERE_LAG_WINDOW_SIZE)
        severe_lag_breaches = severe_window.count { |lag| lag > severe_lag_ms }

        if @heap_runtime
          if @heap_available_fraction < HEAP_RED_FRACTION
            @health = AgentHealth::RED
            reason = "JVM heap headroom (#{(@heap_available_fraction * 100).round(1)}%) below 5% of maximum heap"
          elsif @heap_available_fraction < HEAP_YELLOW_FRACTION
            @health = AgentHealth::YELLOW
            reason = "JVM heap headroom (#{(@heap_available_fraction * 100).round(1)}%) below 15% of maximum heap"
          else
            @health = AgentHealth::GREEN
            reason = 'JVM heap headroom stabilized.' if prev_health != AgentHealth::GREEN
          end
        elsif severe_lag_breaches >= SEVERE_LAG_RED_BREACHES
          @health = AgentHealth::RED
          reason = "Severe Execution Thread Lag exceeded #{severe_lag_ms.round(1)}ms in #{severe_lag_breaches}/#{SEVERE_LAG_WINDOW_SIZE} recent readings"
        elsif lag_breaches >= LAG_RED_BREACHES
          @health = AgentHealth::RED
          reason = "Execution Thread Lag exceeded #{@max_lag_ms.round(1)}ms in #{lag_breaches}/#{LAG_WINDOW_SIZE} recent readings"
        elsif @cumulative_pause_time > @pause_budget_ms
          @health = AgentHealth::RED
          reason = "Cumulative Pause Budget (#{@cumulative_pause_time.round(1)}ms) exceeded limit (#{@pause_budget_ms.round(1)}ms)"
        elsif severe_lag_breaches.positive?
          @health = AgentHealth::YELLOW
          reason = "Moderate impact: Severe Execution Thread Lag exceeded #{severe_lag_ms.round(1)}ms in #{severe_lag_breaches}/#{SEVERE_LAG_WINDOW_SIZE} recent readings"
        elsif lag_breaches >= LAG_YELLOW_BREACHES
          @health = AgentHealth::YELLOW
          reason = "Moderate impact: Execution Thread Lag exceeded #{@max_lag_ms.round(1)}ms in #{lag_breaches}/#{LAG_WINDOW_SIZE} recent readings"
        elsif @cumulative_pause_time > (@pause_budget_ms / 2.0)
          @health = AgentHealth::YELLOW
          reason = "Moderate impact: Cumulative Pause Budget (#{@cumulative_pause_time.round(1)}ms) reached 50% of limit (#{@pause_budget_ms.round(1)}ms)"
        else
          @health = AgentHealth::GREEN
          reason = 'System stabilized.' if prev_health != AgentHealth::GREEN
        end

        return unless @health != prev_health

        @transition_generation += 1
        [@health, reason, @transition_generation]
      end

      def trigger_callback(callback_info)
        health, reason, generation = callback_info
        @notification_mutex.synchronize do
          # State transitions release @mutex before acquiring the delivery lock.
          # Recheck here so a delayed notification cannot undo a newer one.
          current = @mutex.synchronize { generation == @transition_generation && health == @health }
          return unless current

          @on_state_change&.call(health, reason)
        end
      rescue Exception
        # Never crash application thread or safety monitor on callback error
      end

      def monotonic_ms
        Process.clock_gettime(Process::CLOCK_MONOTONIC, :millisecond)
      end
    end
  end
end
