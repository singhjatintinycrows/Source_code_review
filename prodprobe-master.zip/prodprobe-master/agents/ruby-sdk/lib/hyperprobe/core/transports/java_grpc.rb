# frozen_string_literal: true

require 'java'
require 'uri'

begin
  require_relative '../../jars/hyperprobe-grpc.jar'
  JavaUtilities.get_proxy_class('co.hyperprobe.transport.GrpcTransport')
rescue Java::JavaLang::LinkageError => e
  raise LoadError, "Cannot load HyperProbe gRPC transport (Java 11+ required): #{e.message}"
end

module HyperProbe
  module Core
    module Transports
      class JavaGrpc
        class Error < StandardError
          attr_reader :code

          def initialize(code, message)
            @code = code
            super(message)
          end
        end

        def initialize(url, service_id, keep_alive)
          raw = url.to_s.strip
          uri = URI.parse(raw.include?('://') ? raw : "http://#{raw}")
          unless %w[http https].include?(uri.scheme) && uri.hostname && uri.port &&
                 uri.userinfo.nil? && ['', '/'].include?(uri.path) && uri.query.nil? && uri.fragment.nil?
            raise ArgumentError, 'Broker URL must be http(s)://host:port or host:port'
          end

          @client = Java::CoHyperprobeTransport::GrpcTransport.new(uri.hostname, uri.port, uri.scheme == 'https', service_id, keep_alive)
        rescue Java::JavaLang::LinkageError => e
          raise LoadError, "Cannot initialize HyperProbe gRPC transport: #{e.message}"
        end

        def call(method, payload, deadline)
          bytes = payload.to_java_bytes
          remaining = deadline - Process.clock_gettime(Process::CLOCK_MONOTONIC)
          raise Error.new(4, 'DEADLINE_EXCEEDED') unless remaining.positive?

          # Saturate before conversion to Java long; never overflow into an unlimited call.
          nanos = [(remaining * 1_000_000_000).to_i, 9_223_372_036_854_775_807].min
          String.from_java_bytes(@client.call(method, bytes, nanos))
        rescue Java::CoHyperprobeTransport::GrpcTransport::RpcException => e
          raise Error.new(e.code, e.message)
        end

        def shutdown
          @client.shutdown
        end
      end
    end
  end
end
