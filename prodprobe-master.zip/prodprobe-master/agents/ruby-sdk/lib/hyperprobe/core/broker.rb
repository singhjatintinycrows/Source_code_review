# frozen_string_literal: true

require 'securerandom'
require 'socket'
require 'json'

if RUBY_PLATFORM !~ /java/
  require 'grpc'
else
  require_relative 'transports/java_grpc'
end
require_relative '../protos'

module HyperProbe
  module Core
    class BrokerClient
      attr_reader :agent_id, :service_id, :environment, :commit_sha, :agent_version, :stub

      def initialize(
        broker_url:,
        service_id:,
        environment:,
        commit_sha:,
        agent_id: nil,
        agent_version: '1.0.0',
        rpc_timeout_sec: 10.0,
        enable_keep_alive: true
      )
        @service_id = service_id.to_s
        @environment = environment.to_s
        @commit_sha = commit_sha.to_s
        @agent_id = agent_id || SecureRandom.uuid
        @agent_version = agent_version.to_s
        @rpc_timeout_sec = valid_timeout(rpc_timeout_sec)
        @hostname = ENV['HOSTNAME'] || Socket.gethostname rescue 'unknown'
        @is_jruby = RUBY_PLATFORM =~ /java/

        if @is_jruby
          @transport = Transports::JavaGrpc.new(broker_url, @service_id, enable_keep_alive)
        else
          @calls_mutex = Mutex.new
          @active_calls = []
          @closed = false
          target, creds, channel_args = parse_broker_url(broker_url, enable_keep_alive)
          @channel = GRPC::Core::Channel.new(target, channel_args, creds)
          @stub = Hyperprobe::Agent::V1::AgentBroker::Stub.new(target, creds, channel_override: @channel)
        end
      end

      def get_probes(timeout_sec = nil)
        deadline = calculate_deadline(timeout_sec || @rpc_timeout_sec)
        req = Hyperprobe::Agent::V1::GetProbesRequest.new(
          agent_id: @agent_id,
          service_id: @service_id,
          environment: @environment,
          commit_sha: @commit_sha,
          language: @is_jruby ? 'jruby' : 'ruby',
          agent_version: @agent_version,
          hostname: @hostname
        )

        if @is_jruby
          call_jruby_rpc('hyperprobe.agent.v1.AgentBroker/GetProbes', req, Hyperprobe::Agent::V1::GetProbesResponse, deadline)
        else
          call_cruby_rpc(:get_probes, req, deadline)
        end
      end

      def report_telemetry(events, timeout_sec = nil)
        return [] if events.nil? || events.empty?

        deadline = calculate_deadline(timeout_sec || @rpc_timeout_sec)
        proto_events = events.map { |evt| build_telemetry_event_proto(evt) }
        batch = Hyperprobe::Agent::V1::TelemetryBatch.new(agent_id: @agent_id, events: proto_events)

        response = if @is_jruby
                     call_jruby_rpc('hyperprobe.agent.v1.AgentBroker/ReportTelemetry', batch, Hyperprobe::Agent::V1::TelemetryResponse, deadline)
                   else
                     call_cruby_rpc(:report_telemetry, batch, deadline)
                   end
        response.finished_probe_ids.to_a
      end

      def estimate_event_size(event)
        proto = build_telemetry_event_proto(event)
        proto.respond_to?(:serialized_size) ? proto.serialized_size : proto.to_proto.bytesize
      rescue StandardError
        JSON.generate(event).bytesize rescue 512
      end

      def shutdown
        if @is_jruby
          @transport.shutdown
        else
          calls = @calls_mutex.synchronize do
            @closed = true
            @active_calls.dup
          end
          # Closing a C-core channel alone does not cancel outstanding Ruby operations.
          calls.each(&:cancel)
          @channel.close
        end
      end

      private

      def call_cruby_rpc(method, request, deadline)
        operation = @stub.public_send(method, request, metadata: { 'x-hp-service-id' => @service_id },
                                      deadline: deadline, return_op: true)
        @calls_mutex.synchronize do
          raise IOError, 'Broker transport is shut down' if @closed

          @active_calls << operation
        end
        operation.execute
      ensure
        @calls_mutex.synchronize { @active_calls.delete(operation) }
      end

      def call_jruby_rpc(method_path, request_proto, response_class, deadline)
        payload = request_proto.to_proto
        response_class.decode(@transport.call(method_path, payload, deadline))
      end

      def build_telemetry_event_proto(evt)
        return evt if evt.is_a?(Hyperprobe::Agent::V1::TelemetryEvent)

        stack_frames = Array(evt[:stack_frames]).map do |frame|
          Hyperprobe::Agent::V1::StackFrame.new(
            function_name: frame[:function_name].to_s,
            file_name: frame[:file_name].to_s,
            line_number: frame[:line_number].to_i,
            column_number: frame[:column_number].to_i,
            class_name: frame[:class_name] ? frame[:class_name].to_s : nil
          )
        end

        proto_params = {
          probe_id: evt[:probe_id].to_s,
          timestamp_ms: (evt[:timestamp_ms] || (Time.now.to_f * 1000)).to_i,
          stack_frames: stack_frames,
          captured_vars_json: evt[:captured_vars_json].to_s,
          watch_results_json: evt[:watch_results_json].to_s,
          evaluated_log: evt[:evaluated_log].to_s,
          metric_value: evt[:metric_value].to_f,
          capture_error: evt[:capture_error].to_s
        }

        proto_params[:trace_id] = evt[:trace_id].to_s if evt[:trace_id] && !evt[:trace_id].to_s.empty?

        Hyperprobe::Agent::V1::TelemetryEvent.new(proto_params)
      end

      def calculate_deadline(timeout_sec)
        now = @is_jruby ? Process.clock_gettime(Process::CLOCK_MONOTONIC) : Time.now
        now + valid_timeout(timeout_sec)
      end

      def valid_timeout(value)
        timeout = Float(value)
        raise ArgumentError, 'RPC timeout must be finite and positive' unless timeout.finite? && timeout.positive?

        timeout
      end

      def parse_broker_url(url, enable_keep_alive)
        raw_url = url.to_s.strip
        channel_args = {}
        if enable_keep_alive
          channel_args['grpc.keepalive_time_ms'] = 60_000
          channel_args['grpc.keepalive_timeout_ms'] = 20_000
          channel_args['grpc.keepalive_permit_without_calls'] = 1
        end

        if raw_url.start_with?('https://')
          [raw_url.sub('https://', ''), GRPC::Core::ChannelCredentials.new, channel_args]
        else
          [raw_url.sub(/\Ahttp:\/\//, ''), :this_channel_is_insecure, channel_args]
        end
      end
    end
  end
end
