# frozen_string_literal: true

require 'java'
require_relative 'agent_descriptor'

begin
  require_relative '../jars/hyperprobe-grpc.jar'
  JavaUtilities.get_proxy_class('co.hyperprobe.transport.ProtoCodec')
rescue Java::JavaLang::LinkageError => e
  raise LoadError, "Cannot load HyperProbe protobuf codec (Java 11+ required): #{e.message}"
end

module Hyperprobe
  module Agent
    module V1
    end
  end

  # Only the SDK's canonical messages are exposed, not Google's Ruby runtime API.
  module JavaProto
    CODEC = JavaUtilities.get_proxy_class('co.hyperprobe.transport.ProtoCodec').new(DESCRIPTOR_DATA.to_java_bytes)
    CLASSES = {}

    class Message
      class << self
        attr_accessor :descriptor, :fields

        def decode(bytes)
          raise TypeError, 'Expected protobuf bytes as a String' unless bytes.is_a?(String)
          raise ArgumentError, 'Protobuf payload exceeds 4 MiB' if bytes.bytesize > 4 * 1024 * 1024

          from_java(CODEC.decode(descriptor, bytes.to_java_bytes))
        rescue Java::JavaLang::Exception => e
          raise ArgumentError, "Invalid protobuf: #{e.message}"
        end

        def encode(message)
          raise TypeError, "Expected #{self}" unless message.is_a?(self)

          message.to_proto
        end

        def from_java(message)
          result = new
          message.getAllFields.each do |field, value|
            decoded = field.isRepeated ? value.map { |item| decode_value(field, item) } : decode_value(field, value)
            result.public_send("#{field.getName}=", decoded)
          end
          result.instance_variable_set(:@unknown_fields, message.getUnknownFields)
          result
        end

        def decode_value(field, value)
          case field.getJavaType.to_s
          when 'MESSAGE' then CLASSES.fetch(field.getMessageType.getFullName).from_java(value)
          when 'ENUM' then value.getIndex < 0 ? value.getNumber : value.getName.to_sym
          when 'BYTE_STRING' then String.from_java_bytes(value.toByteArray)
          else value
          end
        end

        def normalize(field, value)
          case field.getJavaType.to_s
          when 'MESSAGE'
            klass = CLASSES.fetch(field.getMessageType.getFullName)
            value = klass.new(value) if value.is_a?(Hash)
            raise TypeError, "Expected #{klass} for #{field.getName}" unless value.is_a?(klass)
          when 'ENUM'
            enum = field.getEnumType
            if value.is_a?(Symbol)
              entry = enum.findValueByName(value.to_s)
              raise ArgumentError, "Unknown enum #{value}" unless entry
              return value
            end
            integer!(field, value, 32)
            entry = enum.findValueByNumber(value)
            value = entry.getName.to_sym if entry
          when 'INT', 'LONG'
            integer!(field, value, field.getJavaType.to_s == 'INT' ? 32 : 64)
          when 'DOUBLE', 'FLOAT'
            raise TypeError, "Expected number for #{field.getName}" unless value.is_a?(Numeric) && !value.is_a?(Complex)
            value = value.to_f
          when 'BOOLEAN'
            raise TypeError, "Expected boolean for #{field.getName}" unless value.equal?(true) || value.equal?(false)
          when 'STRING', 'BYTE_STRING'
            raise TypeError, "Expected String for #{field.getName}" unless value.is_a?(String)
            value = field.getJavaType.to_s == 'STRING' ? value.encode(Encoding::UTF_8) : value.b
            raise ArgumentError, 'Invalid UTF-8 protobuf string' unless value.valid_encoding?
            value = value.dup.freeze
          else
            raise ArgumentError, "Unsupported canonical field #{field.getName}"
          end
          value
        end

        def integer!(field, value, bits)
          raise TypeError, "Expected Integer for #{field.getName}" unless value.is_a?(Integer)
          raise RangeError, "Out of range for #{field.getName}" unless value >= -(2**(bits - 1)) && value < 2**(bits - 1)
        end

        def java_value(field, value)
          case field.getJavaType.to_s
          when 'MESSAGE' then value.to_java_message
          when 'ENUM'
            enum = field.getEnumType
            value.is_a?(Symbol) ? enum.findValueByName(value.to_s) : enum.findValueByNumberCreatingIfUnknown(value)
          when 'BYTE_STRING' then CODEC.bytes(value.to_java_bytes)
          when 'STRING' then value.to_java(:string)
          when 'INT' then value.to_java(:int)
          when 'LONG' then value.to_java(:long)
          when 'FLOAT' then value.to_java(:float)
          when 'DOUBLE' then value.to_java(:double)
          when 'BOOLEAN' then value.to_java(:boolean)
          end
        end
      end

      def initialize(values = {})
        raise ArgumentError, 'Expected a field Hash' unless values.is_a?(Hash)

        @values = {}
        values.each do |name, value|
          key = name.to_s
          raise ArgumentError, "Unknown field #{key}" unless self.class.fields.key?(key)
          public_send("#{key}=", value) unless value.nil?
        end
      end

      def to_java_message
        builder = CODEC.builder(self.class.descriptor)
        builder.mergeUnknownFields(@unknown_fields) if @unknown_fields
        @values.each do |name, value|
          field = self.class.fields.fetch(name)
          if field.isRepeated
            # Arrays remain mutable; scalar setters already normalize and freeze strings.
            value.each { |item| builder.addRepeatedField(field, self.class.java_value(field, self.class.normalize(field, item))) }
          else
            builder.setField(field, self.class.java_value(field, value))
          end
        end
        builder.build
      end

      def to_proto
        String.from_java_bytes(to_java_message.toByteArray)
      end

      def serialized_size
        to_java_message.getSerializedSize
      end

      def ==(other)
        other.instance_of?(self.class) && to_java_message == other.to_java_message
      end
      alias eql? ==

      def hash
        to_java_message.hashCode
      end
    end

    CODEC.getFile.getEnumTypes.each do |enum|
      mod = Module.new
      enum.getValues.each { |value| mod.const_set(value.getName, value.getNumber) }
      Agent::V1.const_set(enum.getName, mod)
    end

    CODEC.getFile.getMessageTypes.each do |descriptor|
      klass = Class.new(Message)
      klass.descriptor = descriptor
      klass.fields = descriptor.getFields.each_with_object({}) { |field, fields| fields[field.getName] = field }.freeze
      CLASSES[descriptor.getFullName] = klass
      Agent::V1.const_set(descriptor.getName, klass)
      klass.fields.each do |name, field|
        klass.define_method(name) do
          return @values[name] if @values.key?(name)
          return @values[name] = [] if field.isRepeated
          return nil if field.getJavaType.to_s == 'MESSAGE'

          self.class.decode_value(field, field.getDefaultValue)
        end
        klass.define_method("#{name}=") do |value|
          if value.nil? && field.hasPresence
            @values.delete(name)
          elsif field.isRepeated
            raise TypeError, "Expected Array for #{name}" unless value.is_a?(Array)
            @values[name] = value.map { |item| self.class.normalize(field, item) }
          else
            @values[name] = self.class.normalize(field, value)
          end
        end
        if field.hasPresence
          klass.define_method("has_#{name}?") { @values.key?(name) }
        end
      end
    end
    CLASSES.freeze
  end
end
