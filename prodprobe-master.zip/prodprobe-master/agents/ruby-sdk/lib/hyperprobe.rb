# frozen_string_literal: true

begin
  require_relative 'hyperprobe/version'
  require_relative 'hyperprobe/protos'
  require_relative 'hyperprobe/core/logger'
  require_relative 'hyperprobe/agent'
  require_relative 'hyperprobe/lambda'
  require_relative 'hyperprobe/railtie' if defined?(::Rails::Railtie)
rescue SignalException, SystemExit
  raise
rescue Exception
  # Missing native dependencies or a broken JVM transport disable only the SDK.
  module HyperProbe
    LOAD_FAILED = true
  end
end

module HyperProbe
  @instance = nil
  @mutex = Mutex.new
  @owner_pid = Process.pid

  class << self
    def logger(namespace = 'hyperprobe:agent')
      Core::Logger.get_logger(namespace)
    end
    def start(options = {})
      reset_after_fork
      return nil if defined?(LOAD_FAILED) || @fork_disabled
      return nil unless @mutex.try_lock
      locked = true
      begin
        return @instance if @instance
        @stop_requested = false

        if ENV['HYPERPROBE_DISABLED']&.strip&.upcase == 'YES'
          puts '[HyperProbe] Explicitly disabled via ENV["HYPERPROBE_DISABLED"].'
          return nil
        end

        opts = (options || {}).dup
        commit_sha = opts[:commit_sha] || opts[:commitSha] || opts['commit_sha'] || opts['commitSha'] || ENV['GIT_COMMIT'] || ENV['HYPERPROBE_COMMIT_SHA']
        if commit_sha.nil? || commit_sha.to_s.strip.empty? || commit_sha.to_s.strip.downcase == 'unknown'
          warn "\e[1m\e[33m⚠️  [HyperProbe] CRITICAL: Failed to start agent. A valid \"commit_sha\" is required via options or the GIT_COMMIT environment variable to ensure accurate source map resolution and prevent cross-deployment collisions.\e[0m"
          return nil
        end
        opts[:commit_sha] = commit_sha

        service_id = opts[:service_id] || opts[:serviceId] || opts['service_id'] || opts['serviceId'] || ENV['HYPERPROBE_SERVICE_ID']
        if service_id.nil? || service_id.to_s.strip.empty?
          warn "\e[1m\e[33m⚠️  [HyperProbe] CRITICAL: Failed to start agent. HYPERPROBE_SERVICE_ID is required.\e[0m"
          return nil
        end
        if service_id && !UUID_REGEX.match?(service_id.to_s)
          warn "\e[1m\e[33m⚠️  [HyperProbe] WARN: service_id is not a valid UUID, please check again.\e[0m"
        end
        opts[:service_id] = service_id

        environment = opts[:environment] || opts['environment'] || ENV['HYPERPROBE_ENVIRONMENT']
        if environment.nil? || environment.to_s.strip.empty?
          warn "\e[1m\e[33m⚠️  [HyperProbe] CRITICAL: Failed to start agent. HYPERPROBE_ENVIRONMENT is required.\e[0m"
          return nil
        end
        opts[:environment] = environment

        broker_url = opts[:broker_url] || opts[:brokerUrl] || opts['broker_url'] || opts['brokerUrl'] || ENV['HYPERPROBE_BROKER_URL']
        unless valid_broker_url?(broker_url)
          warn "\e[1m\e[33m⚠️  [HyperProbe] CRITICAL: Failed to start agent. Invalid broker_url \"#{broker_url}\". It must be a valid URL (http:// or https://) or a raw gRPC target (e.g. localhost:60051), with no query parameters and no trailing slash.\e[0m"
          return nil
        end
        opts[:broker_url] = broker_url

        if defined?(JRUBY_VERSION) || (defined?(RUBY_PLATFORM) && RUBY_PLATFORM =~ /java/)
          raw_jruby_ver = defined?(JRUBY_VERSION) ? JRUBY_VERSION.to_s : '0'
          jruby_ver = Gem::Version.new(raw_jruby_ver)
          if jruby_ver < Gem::Version.new('9.3.0.0')
            warn "[HyperProbe] Unsupported JRuby version (#{raw_jruby_ver}); JRuby 9.3+ is required."
            return nil
          end

          unless jruby_debug_enabled?
            warn "\e[1m\e[31m❌ [HyperProbe] CRITICAL: Failed to start agent on JRuby. The '--debug' launch flag (or JRUBY_OPTS=\"--debug\") is required for JRuby to preserve line boundaries and local variables. Please add 'ENV JRUBY_OPTS=\"--debug\"' to your deployment environment or start with 'jruby --debug'.\e[0m"
            return nil
          end

          unless jruby_scope_preservation_enabled?
            warn '[HyperProbe] Agent disabled: compiled JRuby probes require -J-Djruby.ir.passes=AddCallProtocolInstructions,AddMissingInitsPass and -J-Djruby.ir.jit.passes=AddCallProtocolInstructions,AddMissingInitsPass at process startup. These preserve locals with JIT enabled; benchmark their application-wide cost before deployment.'
            return nil
          end

          begin
            require 'java'
            java_ver_str = java.lang.System.getProperty('java.specification.version') || '11'
            java_major = java_ver_str.sub(/^1\./, '').to_i
            if java_major.positive? && java_major < 11
              warn "\e[1m\e[33m⚠️  [HyperProbe] Unsupported Java runtime (#{java_ver_str}). HyperProbe on JRuby requires Java 11+ for native HTTP/2 gRPC.\e[0m"
              return nil
            end
          rescue LoadError, StandardError
            # Pass through if on non-JVM or property read is restricted
          end
        else
          ruby_ver = Gem::Version.new(RUBY_VERSION)
          if ruby_ver < Gem::Version.new('3.0.0')
            warn "\e[1m\e[33m⚠️  [HyperProbe] Unsupported Ruby version (#{RUBY_VERSION}). HyperProbe requires Ruby 3.0+ for targeted line hooks.\e[0m"
            return nil
          end
        end

        if opts.delete(:defer_start) || opts.delete(:deferStart)
          @deferred_options = opts
          return nil
        end
        @native_owner_pid = Process.pid
        candidate = Agent.new(opts)
        return nil if candidate.is_shutdown
        if @stop_requested
          candidate.shutdown
          return nil
        end
        @instance = candidate
        puts "[HyperProbe] Ruby agent successfully started (Version: #{VERSION}, ID: #{@instance.agent_id}, PID: #{@instance.owner_pid})."
        @instance
      ensure
        @mutex.unlock if locked
      end
    rescue SignalException, SystemExit
      candidate&.shutdown
      raise
    rescue Exception
      nil
    end

    def shutdown
      reset_after_fork
      @stop_requested = true
      unless @mutex.try_lock
        defer_shutdown
        return nil
      end
      begin
        inst = @instance
        @instance = nil
      ensure
        @mutex.unlock
      end
      return unless inst
      inst.shutdown
      puts '[HyperProbe] Ruby agent successfully shut down.'
    rescue ThreadError
      defer_shutdown
      nil
    rescue SignalException, SystemExit
      raise
    rescue Exception
      nil
    end

    def instance
      @instance
    end

    def after_fork
      return unless Process.respond_to?(:fork) && !defined?(JRUBY_VERSION)

      return @instance if @owner_pid == Process.pid
      reset_after_fork
      if @fork_disabled
        warn '[HyperProbe] Inherited agent disabled. Use defer_start: true before preloading and after_fork in each worker.'
        return nil
      end
      options = @deferred_options
      @deferred_options = nil
      start(options) if options
    rescue SignalException, SystemExit
      raise
    rescue Exception
      nil
    end

    def wrap_lambda(options = {}, &handler)
      return handler if defined?(LOAD_FAILED)
      Lambda.wrap(options, &handler)
    rescue SignalException, SystemExit
      raise
    rescue Exception
      handler
    end

    def stop_lambda
      Lambda.stop if defined?(Lambda)
    rescue SignalException, SystemExit
      raise
    rescue Exception
      nil
    end

    def jruby_debug_enabled?
      begin
        require 'java'
        return Java::OrgJruby::RubyInstanceConfig.FULL_TRACE_ENABLED == true
      rescue StandardError, ScriptError, NameError
      end

      false
    end

    def jruby_scope_preservation_enabled?
      require 'java'
      required = 'AddCallProtocolInstructions,AddMissingInitsPass'
      Java::OrgJrubyUtilCli::Options::IR_COMPILER_PASSES.load.to_s == required &&
        Java::OrgJrubyUtilCli::Options::IR_JIT_PASSES.load.to_s == required
    rescue StandardError, ScriptError
      false
    end

    def valid_broker_url?(url)
      return false if url.nil? || url.to_s.strip.empty?

      raw = url.to_s.strip
      if raw.start_with?('http://', 'https://')
        begin
          uri = URI.parse(raw)
          return !raw.end_with?('/') && (uri.query.nil? || uri.query.empty?) && !uri.host.nil? && !uri.host.empty?
        rescue URI::InvalidURIError
          return false
        end
      end

      # Raw gRPC target
      !raw.include?('://') && !raw.include?('/') && !raw.include?('?')
    end

    private

    def defer_shutdown
      Thread.new do
        inst = @mutex.synchronize do
          current = @instance
          @instance = nil
          current
        end
        inst&.shutdown
      rescue Exception
        # Cleanup waits only on an agent worker, never on an application thread.
        nil
      end
    end

    def reset_after_fork
      return if @owner_pid == Process.pid
      @owner_pid = Process.pid
      @mutex = Mutex.new
      if @native_owner_pid
        @fork_disabled = true
        @instance&.after_fork
        @instance = nil
      end
    end

    def puts(message)
      notice($stdout, message)
    end

    def warn(message)
      notice($stderr, message)
    end

    def notice(stream, message)
      if IO === stream
        IO.instance_method(:write_nonblock).bind(stream).call("#{message}\n", exception: false)
      elsif defined?(StringIO) && StringIO === stream
        StringIO.instance_method(:write).bind(stream).call("#{message}\n")
      end
    rescue SignalException, SystemExit
      raise
    rescue Exception
      nil
    end
  end
end
