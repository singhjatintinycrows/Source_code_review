import sys
import os
import uuid
import time
import threading
import queue
import re
from urllib.parse import urlparse

from hyperprobe.core.quota import QuotaManager
from hyperprobe.core.safety import SafetyMonitor, AgentHealth
from hyperprobe.core.broker import BrokerClient
from hyperprobe.core.logger import get_logger
from hyperprobe.core.probe_output import ProbeLogWriter

logger = get_logger("hyperprobe:agent")
broker_logger = get_logger("hyperprobe:broker")
from hyperprobe.protos.agent_pb2 import PROBE_TYPE_UNSPECIFIED,PROBE_TYPE_SNAPSHOT,PROBE_TYPE_LOG,PROBE_TYPE_COUNTER,PROBE_TYPE_METRIC,PROBE_TYPE_DURATION

UUID_REGEX = re.compile(r"^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$", re.IGNORECASE)

SUPPORTED_PROBE_TYPES = {PROBE_TYPE_UNSPECIFIED,PROBE_TYPE_SNAPSHOT,PROBE_TYPE_LOG,PROBE_TYPE_COUNTER,PROBE_TYPE_METRIC,PROBE_TYPE_DURATION}


class _TelemetryItem:
    def __init__(self, event, bandwidth_reservation=None):
        self.event = event
        self.bandwidth_reservation = bandwidth_reservation


def is_valid_broker_url(url):
    if not url or not str(url).strip():
        return False
    url = str(url).strip()
    
    if url.startswith("http://") or url.startswith("https://"):
        try:
            parsed = urlparse(url)
            return not url.endswith("/") and not parsed.query and bool(parsed.hostname)
        except Exception:
            return False
            
    # Raw gRPC targets should have no schema, no path, and no query parameters
    return "://" not in url and "/" not in url and "?" not in url

class HyperProbeAgent:
    _instance = None
    _lock = threading.Lock()
    _fork_handlers_registered = False
    _fork_owner_pid = None
    _fork_options = None
    _fork_agent = None
    _fork_pending = False

    def __init__(self, options):
        self.options = dict(options)
        self.owner_pid = os.getpid()
        self.agent_id = str(uuid.uuid4())
        self.is_shutdown = False
        self.stop_event = threading.Event()

        self.fork_mode = str(
            self.options.get("fork_mode")
            or os.getenv("HYPERPROBE_FORK_MODE", "none")
        ).strip().lower()
        if self.fork_mode not in {"none", "worker"}:
            raise ValueError('fork_mode must be either "none" or "worker"')

        # Options & Envs Parsing
        self.sync_interval_sec = (options.get("sync_interval_ms") or int(os.getenv("HYPERPROBE_SYNC_INTERVAL_MS", 60000))) / 1000.0
        self.flush_interval_sec = (options.get("flush_interval_ms") or int(os.getenv("HYPERPROBE_FLUSH_INTERVAL_MS", 1000))) / 1000.0
        self.max_queue_size = options.get("max_queue_size") or int(os.getenv("HYPERPROBE_MAX_QUEUE_SIZE", 100))
        self._cooldown_sec = options.get("hyperprobe_cooldown_sec") or int(os.getenv("HYPERPROBE_COOLDOWN_SEC", 10))

        hits_per_sec = options.get("hits_per_sec") or int(os.getenv("HYPERPROBE_HITS_PER_SEC", 10))
        bandwidth_kb = options.get("bandwidth_kb_per_sec") or int(os.getenv("HYPERPROBE_BANDWIDTH_KB_PER_SEC", 1024))
        rpc_timeout_sec = options.get("hyperprobe_rpc_timeout_sec") or float(os.getenv("HYPERPROBE_RPC_TIMEOUT_SEC", 10.0))
        max_lag_ms = options.get("hyperprobe_max_lag_ms") or float(os.getenv("HYPERPROBE_MAX_LAG_MS", 50.0))
        pause_budget_ms = options.get("hyperprobe_pause_budget_ms") or float(os.getenv("HYPERPROBE_PAUSE_BUDGET_MS", 15.0))

        opt_disable_safe_eval = options.get("disable_safe_evaluation", False)
        disable_safe_eval = (
            os.getenv("HYPERPROBE_DISABLE_SAFE_EVALUATION", "").strip().lower() == "true"
            or opt_disable_safe_eval is True
            or (
                isinstance(opt_disable_safe_eval, str)
                and opt_disable_safe_eval.strip().lower() == "true"
            )
        )

        if disable_safe_eval:
            logger.forceInfo(
                "\033[1m\033[33m⚠️  [HyperProbe] WARN: Safe evaluation is DISABLED via "
                "HYPERPROBE_DISABLE_SAFE_EVALUATION. Function and method calls are permitted in probe expressions.\033[0m"
            )

        self.global_config = {
            "redact_keys": options.get("redact_keys") or os.getenv("HYPERPROBE_REDACT_KEYS", "password,secret,token,authorization,cookie,key,signature").split(","),
            "redact_values": options.get("redact_values") or os.getenv("HYPERPROBE_REDACT_VALUES", "").split(","),
            "max_object_depth": options.get("max_object_depth") or int(os.getenv("HYPERPROBE_MAX_OBJECT_DEPTH", 3)),
            "max_array_length": options.get("max_array_length") or int(os.getenv("HYPERPROBE_MAX_ARRAY_LENGTH", 3)),
            "stack_frame_depth": options.get("stack_frame_depth") or int(os.getenv("HYPERPROBE_STACK_FRAME_DEPTH", 3)),
            "max_object_properties": options.get("max_object_properties") or int(os.getenv("HYPERPROBE_MAX_OBJECT_PROPERTIES", 50)),
            "max_string_length": options.get("max_string_length") or int(os.getenv("HYPERPROBE_MAX_STRING_LENGTH", 1024)),
            "disable_safe_evaluation": disable_safe_eval,
        }

        # Strip empty redaction strings
        self.global_config["redact_keys"] = [k.strip() for k in self.global_config["redact_keys"] if k.strip()]
        self.global_config["redact_values"] = [v.strip() for v in self.global_config["redact_values"] if v.strip()]

        # Initialize core telemetry components
        self.quota_manager = QuotaManager(hits_per_sec, bandwidth_kb * 1024)
        self.safety_monitor = SafetyMonitor(
            self._handle_health_change,
            max_lag_ms=max_lag_ms,
            pause_budget_ms=pause_budget_ms,
        )

        self.broker_client = BrokerClient(
            broker_url=options["broker_url"],
            service_id=options["service_id"],
            environment=options["environment"],
            commit_sha=options.get("commit_sha") or os.getenv("GIT_COMMIT", "unknown"),
            agent_id=self.agent_id,
            rpc_timeout_sec=rpc_timeout_sec,
        )
        self.agent_version = self.broker_client.agent_version

        # Thread-safe queue for telemetry events
        self.telemetry_queue = queue.Queue(maxsize=self.max_queue_size)
        self.probe_log_writer = ProbeLogWriter(self.max_queue_size)
        self.active_probes = {}  # probe_id -> Probe
        self.local_hits = {}     # probe_id -> count
        self.pending_hits = {}   # probe_id -> queued capture reservations
        self.cooldown_timer = None
        self._cooldown_generation = 0
        self._agent_lock = threading.RLock()  # Synchronizes state access with re-entrancy safety
        self._inflight_batch = None

        # Determine and initialize dynamic instrumentation engine
        self.engine = self._init_instrumentation_engine()
        self.engine.set_global_config(self.global_config)

        # Background worker threads
        self.sync_thread = None
        self.flush_thread = None
        self.stats_thread = None

    @classmethod
    def start(cls, options):
        """Starts the global HyperProbe Agent singleton."""
        options = dict(options or {})
        with cls._lock:
            if (
                cls._fork_owner_pid == os.getpid()
                and cls._fork_agent is not None
            ):
                logger.forceInfo("[HyperProbe] Worker fork mode is already configured.")
                return cls._fork_agent
            if cls._instance is not None:
                if cls._instance.owner_pid != os.getpid():
                    logger.forceError(
                        "[HyperProbe] Inherited agent state detected in a forked "
                        "process. Configure fork_mode='worker' before forking."
                    )
                    return None
                logger.forceInfo("[HyperProbe] Agent is already running.")
                return cls._instance

            # Check kill switch
            if os.getenv("HYPERPROBE_DISABLED", "").strip().upper() == "YES":
                logger.forceInfo("[HyperProbe] Explicitly disabled via HYPERPROBE_DISABLED.")
                return None

            commit_sha = options.get("commit_sha") or os.getenv("HYPERPROBE_COMMIT_SHA") or os.getenv("GIT_COMMIT")
            if not commit_sha or not str(commit_sha).strip() or str(commit_sha).strip().lower() == "unknown":
                logger.forceError('\033[1m\033[33m⚠️  [HyperProbe] CRITICAL: Failed to start agent. A valid "commit_sha" is required via options or the GIT_COMMIT environment variable to ensure accurate source map resolution and prevent cross-deployment collisions.\033[0m')
                return None
            options["commit_sha"] = commit_sha

            service_id = options.get("service_id") or os.getenv(
                "HYPERPROBE_SERVICE_ID"
            )
            if not service_id or not str(service_id).strip():
                logger.forceError('\033[1m\033[33m⚠️  [HyperProbe] CRITICAL: Failed to start agent. HYPERPROBE_SERVICE_ID is required.\033[0m')
                return None
            if not UUID_REGEX.match(str(service_id).strip()):
                allow_non_uuid = options.get("allow_non_uuid")
                if allow_non_uuid is None:
                    allow_non_uuid = (
                        os.getenv("HYPERPROBE_ALLOW_NON_UUID", "")
                        .strip()
                        .lower()
                        == "yes"
                    )
                elif isinstance(allow_non_uuid, str):
                    allow_non_uuid = allow_non_uuid.strip().lower() == "yes"

                if not allow_non_uuid:
                    logger.forceError('\033[1m\033[33m⚠️  [HyperProbe] CRITICAL: Failed to start agent. service_id is not a valid UUIDv4. Set HYPERPROBE_ALLOW_NON_UUID=yes to allow non-UUID identifiers.\033[0m')
                    return None
                logger.forceInfo('\033[1m\033[33m⚠️  [HyperProbe] WARN: service_id is not a valid UUIDv4, please check again.\033[0m')
            options["service_id"] = service_id

            environment = options.get("environment") or os.getenv("HYPERPROBE_ENVIRONMENT")
            if not environment or not str(environment).strip():
                logger.forceError('\033[1m\033[33m⚠️  [HyperProbe] CRITICAL: Failed to start agent. HYPERPROBE_ENVIRONMENT is required.\033[0m')
                return None
            options["environment"] = environment

            broker_url = options.get("broker_url") or os.getenv(
                "HYPERPROBE_BROKER_URL"
            )
            if not is_valid_broker_url(broker_url):
                logger.forceError(f'\033[1m\033[33m⚠️  [HyperProbe] CRITICAL: Failed to start agent. Invalid broker_url "{broker_url}". It must be a valid URL (http:// or https://) or a raw gRPC target (e.g. localhost:60051), with no query parameters and no trailing slash.\033[0m')
                return None
            options["broker_url"] = broker_url

            fork_mode = str(
                options.get("fork_mode")
                or os.getenv("HYPERPROBE_FORK_MODE", "none")
            ).strip().lower()
            if fork_mode not in {"none", "worker"}:
                logger.forceError(
                    '[HyperProbe] Invalid fork_mode. Expected "none" or "worker".'
                )
                return None
            options["fork_mode"] = fork_mode

            if fork_mode == "worker":
                return cls._prepare_worker_fork_mode_locked(options)

            instance = cls.__new__(cls)
            try:
                instance.__init__(options)
                cls._instance = instance
                instance._start_background_loops()
            except Exception as exc:
                instance._cleanup_failed_start()
                cls._instance = None
                logger.forceError(
                    f"[HyperProbe] Agent failed to initialize "
                    f"({type(exc).__name__}: {exc}). "
                    "Running application uninstrumented."
                )
                return None
            logger.forceInfo(
                f"[HyperProbe] Python agent successfully started "
                f"(Version: {cls._instance.agent_version}, "
                f"ID: {cls._instance.agent_id}, PID: {cls._instance.owner_pid})."
            )
            return cls._instance

    @classmethod
    def _prepare_worker_fork_mode_locked(cls, options):
        if not hasattr(os, "register_at_fork"):
            logger.forceError(
                "[HyperProbe] fork_mode='worker' is not supported on this platform."
            )
            return None

        # Return a stable placeholder to application code imported by the
        # prefork parent. It is initialized in place after each child fork.
        instance = cls.__new__(cls)
        instance.options = dict(options)
        instance.owner_pid = os.getpid()
        instance.agent_id = None
        instance.is_shutdown = True
        instance.fork_mode = "worker"

        cls._fork_owner_pid = os.getpid()
        cls._fork_options = dict(options)
        cls._fork_agent = instance

        if cls._fork_handlers_registered:
            logger.forceInfo(
                f"[HyperProbe] Worker fork mode configured (PID: {os.getpid()})."
            )
            return instance

        os.register_at_fork(
            before=cls._before_fork,
            after_in_parent=cls._after_fork_parent,
            after_in_child=cls._after_fork_child,
        )
        cls._fork_handlers_registered = True
        logger.forceInfo(
            f"[HyperProbe] Worker fork mode configured (PID: {os.getpid()})."
        )
        return instance

    @classmethod
    def _before_fork(cls):
        if cls._fork_owner_pid != os.getpid() or cls._fork_options is None:
            return

        cls._lock.acquire()
        cls._fork_pending = True

    @classmethod
    def _after_fork_parent(cls):
        if not cls._fork_pending:
            return
        cls._fork_pending = False
        cls._lock.release()

    @classmethod
    def _after_fork_child(cls):
        if not cls._fork_pending:
            return

        options = dict(cls._fork_options or {})
        instance = cls._fork_agent

        # Locks and process resources inherited from a multithreaded parent must
        # never be reused in the child.
        cls._lock = threading.Lock()
        cls._instance = None
        cls._fork_pending = False
        cls._fork_owner_pid = None
        cls._fork_options = None
        cls._fork_agent = None

        if instance is None or not options:
            return

        try:
            # Reinitialize in place so the object returned by HyperProbe.start()
            # remains valid in application modules imported before the fork.
            instance.__init__(options)
            cls._instance = instance
            instance._start_background_loops()
        except Exception as exc:
            instance._cleanup_failed_start()
            cls._instance = None
            logger.forceError(
                f"[HyperProbe] Failed to restart the agent after fork: {exc}"
            )
            return

        logger.forceInfo(
            f"[HyperProbe] Python agent started after fork "
            f"(Version: {instance.agent_version}, "
            f"ID: {instance.agent_id}, PID: {instance.owner_pid})."
        )

    @classmethod
    def shutdown(cls):
        """Cleanly and safely shuts down the running agent singleton."""
        with cls._lock:
            if cls._instance is None:
                if cls._fork_owner_pid == os.getpid():
                    cls._clear_fork_state_locked()
                return
            if cls._instance.owner_pid != os.getpid():
                cls._instance = None
                return
            cls._instance._stop()
            cls._instance = None
            if cls._fork_owner_pid == os.getpid():
                cls._clear_fork_state_locked()
            print("[HyperProbe] Python agent successfully shut down.")

    @classmethod
    def _clear_fork_state_locked(cls):
        cls._fork_owner_pid = None
        cls._fork_options = None
        cls._fork_agent = None
        cls._fork_pending = False

    def _init_instrumentation_engine(self):
        from hyperprobe.core.monitoring_engine import MonitoringEngine
        return MonitoringEngine(
            self.quota_manager,
            self.safety_monitor,
            self._handle_capture,
            custom_set_trace_id=self.options.get("set_trace_id")
        )

    def _start_background_loops(self):
        if self.owner_pid != os.getpid():
            return
        self.stop_event.clear()
        self.safety_monitor.start()

        self.sync_thread = threading.Thread(target=self._sync_loop, name="hyperprobe-sync")
        self.sync_thread.daemon = True
        self.sync_thread.start()

        self.flush_thread = threading.Thread(target=self._flush_loop, name="hyperprobe-flush")
        self.flush_thread.daemon = True
        self.flush_thread.start()

        self.stats_thread = threading.Thread(target=self._stats_loop, name="hyperprobe-stats")
        self.stats_thread.daemon = True
        self.stats_thread.start()

    def _stop(self):
        self.is_shutdown = True
        self.stop_event.set()

        try:
            self.safety_monitor.stop()
        except Exception as exc:
            logger.error(f"[HyperProbe] Failed to stop safety monitor: {exc}")

        try:
            self.engine.set_probes([])
        except Exception as exc:
            logger.error(f"[HyperProbe] Failed to clear monitoring probes: {exc}")
        try:
            self.engine.close()
        except Exception as exc:
            logger.error(f"[HyperProbe] Failed to stop monitoring engine: {exc}")

        try:
            self.probe_log_writer.stop(timeout=2.0)
        except Exception as exc:
            logger.error(f"[HyperProbe] Failed to stop probe output: {exc}")

        cooldown_timer = None
        try:
            with self._agent_lock:
                self._cooldown_generation += 1
                cooldown_timer = self.cooldown_timer
                self.cooldown_timer = None
        except Exception as exc:
            logger.error(f"[HyperProbe] Failed to clear cooldown state: {exc}")
        if cooldown_timer:
            try:
                cooldown_timer.cancel()
            except Exception:
                pass

        try:
            self.broker_client.shutdown()
        except Exception as exc:
            logger.error(f"[HyperProbe] Failed to close broker client: {exc}")

        current_thread = threading.current_thread()
        for thread in (self.sync_thread, self.flush_thread, self.stats_thread):
            try:
                if thread and thread is not current_thread and thread.is_alive():
                    thread.join(timeout=2.0)
            except Exception as exc:
                logger.error(f"[HyperProbe] Failed to join worker thread: {exc}")

    def _cleanup_failed_start(self):
        """Best-effort cleanup for a partially initialized child agent."""
        self.is_shutdown = True

        stop_event = getattr(self, "stop_event", None)
        if stop_event is not None:
            stop_event.set()

        for component_name in ("safety_monitor", "probe_log_writer"):
            component = getattr(self, component_name, None)
            if component is None:
                continue
            try:
                component.stop()
            except Exception:
                pass

        engine = getattr(self, "engine", None)
        if engine is not None:
            try:
                engine.close()
            except Exception:
                pass

        broker_client = getattr(self, "broker_client", None)
        if broker_client is not None:
            try:
                broker_client.shutdown()
            except Exception:
                pass

        cooldown_timer = getattr(self, "cooldown_timer", None)
        if cooldown_timer is not None:
            try:
                cooldown_timer.cancel()
            except Exception:
                pass
            self.cooldown_timer = None
        if hasattr(self, "_cooldown_generation"):
            self._cooldown_generation += 1

        current_thread = threading.current_thread()
        for thread_name in ("sync_thread", "flush_thread", "stats_thread"):
            thread = getattr(self, thread_name, None)
            if thread is None or thread is current_thread:
                continue
            try:
                if thread.is_alive():
                    thread.join(timeout=2.0)
            except Exception:
                pass

    def _sync_loop(self):
        while self.owner_pid == os.getpid() and not self.stop_event.is_set():
            try:
                self._sync_with_broker()
            except Exception as e:
                cause = getattr(e, "__cause__", None)
                msg = f"{e} (cause: {cause})" if cause and str(cause) not in str(e) else str(e)
                logger.error(f"[HyperProbe] Sync loop encountered error: {msg}")
            self.stop_event.wait(self.sync_interval_sec)

    def _sync_with_broker(self):
        response = self.broker_client.get_probes()
        if not response:
            return

        # Update global config if returned
        if response.HasField("global_config"):
            gc = response.global_config
            with self._agent_lock:
                self.global_config.update({
                    "redact_keys": list(gc.redact_keys) if gc.redact_keys else self.global_config["redact_keys"],
                    "redact_values": list(gc.redact_values) if gc.redact_values else self.global_config["redact_values"],
                    "max_object_depth": gc.max_object_depth if gc.HasField("max_object_depth") else self.global_config["max_object_depth"],
                    "max_array_length": gc.max_array_length if gc.HasField("max_array_length") else self.global_config["max_array_length"],
                    "stack_frame_depth": gc.stack_frame_depth if gc.HasField("stack_frame_depth") else self.global_config["stack_frame_depth"],
                    "max_object_properties": gc.max_object_properties if gc.HasField("max_object_properties") else self.global_config["max_object_properties"],
                    "max_string_length": gc.max_string_length if gc.HasField("max_string_length") else self.global_config["max_string_length"],
                })
            self.engine.set_global_config(self.global_config)

        # Only activate probe types implemented by this SDK.
        server_probes = {}
        for probe in response.probes:
            if probe.type in SUPPORTED_PROBE_TYPES:
                server_probes[probe.id] = probe
            else:
                msg = f"[HyperProbe] Ignoring unsupported probe type {probe.type} for probe {probe.id}."
                logger.error(msg)

        now_ms = int(time.time() * 1000)

        with self._agent_lock:
            # Cleanup stale state
            self.active_probes = {pid: p for pid, p in self.active_probes.items() if pid in server_probes}
            self.local_hits = {pid: count for pid, count in self.local_hits.items() if pid in server_probes}
            self.pending_hits = {pid: count for pid, count in self.pending_hits.items() if pid in server_probes}

            to_apply = []
            for pid, p in server_probes.items():
                hits = self.local_hits.get(pid, 0)
                is_expired = p.expiry_time <= now_ms if p.expiry_time else False

                if hits < p.hit_limit and not is_expired:
                    to_apply.append(p)
                    self.active_probes[pid] = p
                else:
                    self.active_probes.pop(pid, None)

        # set_probes updates the configured probes; the engine decides whether
        # instrumentation may run while suspended.
        self.engine.set_probes(to_apply)

    def _flush_loop(self):
        while self.owner_pid == os.getpid() and not self.stop_event.is_set():
            try:
                self._flush_telemetry()
            except Exception as e:
                logger.error(f"[HyperProbe] Flush loop encountered error: {str(e)}")
            self.stop_event.wait(self.flush_interval_sec)

    def _stats_loop(self):
        while self.owner_pid == os.getpid() and not self.stop_event.is_set():
            try:
                stats = self.engine.get_stats()
                if stats["hits"] > 0 or stats["skips"] > 0:
                    logger.info(f"[HyperProbe] Probes Hit: {stats['hits']}, Probes Skipped: {stats['skips']}")
            except Exception as e:
                logger.error(f"[HyperProbe] Stats loop encountered error: {str(e)}")
            self.stop_event.wait(5.0)

    def _flush_telemetry(self):
        batch = self._inflight_batch
        if batch is None:
            batch = []
            # Pull all currently queued events up to capacity. Keep the batch
            # in-flight until the broker call succeeds so retries cannot lose it.
            while not self.telemetry_queue.empty():
                try:
                    item = self.telemetry_queue.get_nowait()
                    if not isinstance(item, _TelemetryItem):
                        item = _TelemetryItem(item)
                    batch.append(item)
                except queue.Empty:
                    break

        if not batch:
            return

        self._inflight_batch = batch
        broker_logger.info(
            f"[HyperProbe] Flushing {len(batch)} telemetry events to broker..."
        )
        try:
            finished_probe_ids = self.broker_client.report_telemetry(
                [item.event for item in batch]
            )
            broker_logger.info(
                f"[HyperProbe] Successfully flushed {len(batch)} telemetry events to broker."
            )
        except Exception as e:
            cause = getattr(e, "__cause__", None)
            msg = f"{e} (cause: {cause})" if cause and str(cause) not in str(e) else str(e)
            broker_logger.error(
                f"[HyperProbe] Failed to flush telemetry: {msg}. "
                f"Retaining {len(batch)} events for retry."
            )
            return

        for item in batch:
            if item.bandwidth_reservation is not None:
                item.bandwidth_reservation.commit()
        self._inflight_batch = None

        # If broker confirmed certain probes reached global limit, clear them locally
        if finished_probe_ids:
            changed = False
            with self._agent_lock:
                for pid in finished_probe_ids:
                    if pid in self.active_probes:
                        self.active_probes.pop(pid, None)
                        changed = True
                if changed:
                    probes_list = list(self.active_probes.values())
            if changed:
                self.engine.set_probes(probes_list)

    def _reserve_hit_slot(self, probe_id, probe):
        with self._agent_lock:
            if self.active_probes.get(probe_id) is not probe:
                return False
            committed_hits = self.local_hits.get(probe_id, 0)
            pending_hits = self.pending_hits.get(probe_id, 0)
            if committed_hits + pending_hits >= probe.hit_limit:
                return False
            self.pending_hits[probe_id] = pending_hits + 1
            return True

    def _release_hit_slot(self, probe_id):
        with self._agent_lock:
            pending_hits = self.pending_hits.get(probe_id, 0)
            if pending_hits <= 1:
                self.pending_hits.pop(probe_id, None)
            else:
                self.pending_hits[probe_id] = pending_hits - 1

    def _commit_hit_slot(self, probe_id, probe):
        with self._agent_lock:
            pending_hits = self.pending_hits.get(probe_id, 0)
            if pending_hits <= 1:
                self.pending_hits.pop(probe_id, None)
            else:
                self.pending_hits[probe_id] = pending_hits - 1

            hits = self.local_hits.get(probe_id, 0) + 1
            self.local_hits[probe_id] = hits
            if hits < probe.hit_limit:
                return None

            self.active_probes.pop(probe_id, None)
            return list(self.active_probes.values())

    def _handle_capture(self, event):
        if (
            getattr(self, "owner_pid", os.getpid()) != os.getpid()
            or getattr(self, "is_shutdown", False)
        ):
            return
        probe_id = event["probe_id"]
        with self._agent_lock:
            probe = self.active_probes.get(probe_id)
            if not probe:
                return

            if probe.type not in SUPPORTED_PROBE_TYPES:
                return

        if not self._reserve_hit_slot(probe_id, probe):
            return

        try:
            event_size = self.broker_client.estimate_event_size(event)
            logger.info(f"[HyperProbe] Got event size : {event_size} Bytes")
        except Exception as exc:
            logger.error(
                f"[HyperProbe] Failed to size telemetry for probe {probe_id}: {exc}"
            )
            self._release_hit_slot(probe_id)
            return

        bandwidth_reservation = self.quota_manager.reserve_bandwidth(event_size)
        if bandwidth_reservation is None:
            msg = f"[HyperProbe] Bandwidth quota exceeded; dropping event for probe {probe_id} , event size was : {event_size} bytes."
            logger.error(msg)
            self._release_hit_slot(probe_id)
            return

        # Hold the bandwidth reservation with the event until the broker
        # confirms the batch. Release it if local queue admission fails.
        item = _TelemetryItem(event, bandwidth_reservation)
        try:
            self.telemetry_queue.put_nowait(item)
        except queue.Full:
            bandwidth_reservation.release()
            self._release_hit_slot(probe_id)
            return
        except Exception as exc:
            bandwidth_reservation.release()
            self._release_hit_slot(probe_id)
            logger.error(
                f"[HyperProbe] Failed to queue telemetry for probe {probe_id}: {exc}"
            )
            return

        probes_list = self._commit_hit_slot(probe_id, probe)
        if (
            probe.type == PROBE_TYPE_LOG
            and getattr(probe, "should_log_to_stdout", False) is True
            and not event.get("capture_error")
        ):
            try:
                timestamp_ms = event.get("timestamp_ms")
                if timestamp_ms is None:
                    timestamp_ms = int(time.time() * 1000)
                self.probe_log_writer.submit(
                    timestamp_ms,
                    getattr(probe, "log_level", ""),
                    event.get("evaluated_log", ""),
                )
            except Exception as exc:
                # Local output must not affect admitted telemetry or hit accounting.
                logger.error(
                    f"[HyperProbe] Failed to queue local output for probe "
                    f"{probe_id}: {exc}"
                )
        if probes_list is not None:
            self.engine.set_probes(probes_list)

    def _handle_health_change(self, health, reason):
        if self.owner_pid != os.getpid() or self.is_shutdown:
            return

        if health == AgentHealth.RED:
            logger.error(f"[HyperProbe] Safety Shield Triggered (RED): {reason or ''}. Suspending instrumentation.")
            with self._agent_lock:
                self.engine.suspend()

                if self.cooldown_timer is not None:
                    self.cooldown_timer.cancel()

                self._cooldown_generation += 1
                cooldown_generation = self._cooldown_generation
                cooldown_sec = self._cooldown_sec
                self.cooldown_timer = threading.Timer(
                    cooldown_sec,
                    lambda: self._cooldown_expired(cooldown_generation),
                )
                self.cooldown_timer.daemon = True
                self.cooldown_timer.start()

        elif health == AgentHealth.YELLOW:
            logger.error(f"[HyperProbe] Safety Warning (YELLOW): {reason or ''}.")
        elif health == AgentHealth.GREEN:
            with self._agent_lock:
                cooldown_expired = self.cooldown_timer is None
            if cooldown_expired:
                logger.info(f"[HyperProbe] Status back to GREEN. {reason or ''}.")
                self._resume_instrumentation()

    def _cooldown_expired(self, cooldown_generation):
        with self._agent_lock:
            if cooldown_generation != self._cooldown_generation:
                return
            self.cooldown_timer = None
            self._resume_instrumentation()

    def _resume_instrumentation(self):
        with self._agent_lock:
            if (
                self.is_shutdown
                or not self.engine.is_suspended
                or self.safety_monitor.get_health() != AgentHealth.GREEN
                or self.cooldown_timer is not None
            ):
                return
            logger.info("[HyperProbe] Cooldown window expired. Resuming probes from local cache.")
            probes_list = list(self.active_probes.values())
            self.engine.set_probes(probes_list)
            self.engine.resume()
