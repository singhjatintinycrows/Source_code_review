__all__ = ["HyperProbe"]

def __getattr__(name):
    if name == "HyperProbe":
        from hyperprobe.agent import HyperProbeAgent
        return HyperProbeAgent
    raise AttributeError(f"module '{__name__}' has no attribute '{name}'")
