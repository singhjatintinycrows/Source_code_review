import math


def _type_summary(obj):
    type_name = type(obj).__name__
    if isinstance(obj, (bytes, bytearray, memoryview)):
        try:
            return f"[{type_name}: {len(obj)} bytes]"
        except Exception:
            return f"[{type_name}]"
    if isinstance(obj, dict):
        try:
            return f"[Dict: {len(obj)} keys]"
        except Exception:
            return "[Dict]"
    if isinstance(obj, (list, tuple, set)):
        try:
            return f"[List: {len(obj)} items]"
        except Exception:
            return "[List]"
    return f"[Obj: {type_name}]"


def _safe_key(key):
    if isinstance(key, (str, int, float, bool)) or key is None:
        return str(key)
    return f"[{type(key).__name__} key]"


def _safe_length(value):
    try:
        return len(value)
    except Exception:
        return None


def serialize(
    obj,
    max_depth=3,
    max_array_length=3,
    max_object_properties=50,
    max_string_length=1024,
    redact_keys_re=None,
    redact_values_re=None,
    visited=None,
    depth=0,
    path="$",
):
    """Serialize a bounded object graph without invoking arbitrary repr()."""
    if visited is None:
        visited = {}

    if obj is None:
        return None
    if isinstance(obj, bool):
        return obj
    if isinstance(obj, int):
        return obj
    if isinstance(obj, float):
        if not math.isfinite(obj):
            return str(obj)
        return obj
    if isinstance(obj, str):
        value = obj
        if len(value) > max_string_length:
            value = (
                value[:max_string_length]
                + f"... [Truncated: +{len(value) - max_string_length} more chars]"
            )
        if redact_values_re and redact_values_re.search(value):
            value = redact_values_re.sub("[REDACTED Value]", value)
        return value
    if isinstance(obj, (bytes, bytearray, memoryview)):
        return _type_summary(obj)

    obj_id = id(obj)
    previous = visited.get(obj_id)
    if previous is not None:
        previous_obj, previous_path = previous
        if previous_obj is obj:
            return f"[REF - {previous_path}]"

    if depth > max_depth:
        return _type_summary(obj)

    # Retain the object for the whole serialization operation. This preserves
    # aliases and prevents stale id() reuse while traversing generators.
    visited[obj_id] = (obj, path)

    if isinstance(obj, dict):
        result = {}
        processed = 0
        try:
            iterator = iter(obj.items())
            while processed < max_object_properties:
                try:
                    key, value = next(iterator)
                except StopIteration:
                    break

                key_string = _safe_key(key)
                if redact_keys_re and redact_keys_re.search(key_string):
                    result[key_string] = "[REDACTED Key]"
                else:
                    child_path = f"{path}.{key_string}" if path else key_string
                    result[key_string] = serialize(
                        value,
                        max_depth=max_depth,
                        max_array_length=max_array_length,
                        max_object_properties=max_object_properties,
                        max_string_length=max_string_length,
                        redact_keys_re=redact_keys_re,
                        redact_values_re=redact_values_re,
                        visited=visited,
                        depth=depth + 1,
                        path=child_path,
                    )
                processed += 1

            total = _safe_length(obj)
            if total is not None and total > processed:
                result["__probe_meta"] = (
                    f"+ {total - processed} more properties truncated"
                )
            elif total is None:
                try:
                    next(iterator)
                except StopIteration:
                    pass
                else:
                    result["__probe_meta"] = "+ more properties truncated"
        except Exception:
            result["__probe_meta"] = "[Dictionary traversal failed]"
        return result

    if isinstance(obj, (list, tuple, set)):
        result = []
        processed = 0
        try:
            iterator = iter(obj)
            while processed < max_array_length:
                try:
                    value = next(iterator)
                except StopIteration:
                    break
                result.append(
                    serialize(
                        value,
                        max_depth=max_depth,
                        max_array_length=max_array_length,
                        max_object_properties=max_object_properties,
                        max_string_length=max_string_length,
                        redact_keys_re=redact_keys_re,
                        redact_values_re=redact_values_re,
                        visited=visited,
                        depth=depth + 1,
                        path=f"{path}[{processed}]",
                    )
                )
                processed += 1

            total = _safe_length(obj)
            if total is not None and total > processed:
                result.append(f"[+ {total - processed} more items truncated]")
            elif total is None:
                try:
                    next(iterator)
                except StopIteration:
                    pass
                else:
                    result.append("[+ more items truncated]")
        except Exception:
            result.append("[Iterable traversal failed]")
        return result

    try:
        properties = vars(obj)
    except Exception:
        return _type_summary(obj)

    result = {}
    try:
        keys = [key for key in properties if not key.startswith("_")]
    except Exception:
        return _type_summary(obj)

    for index, key in enumerate(keys[:max_object_properties]):
        if redact_keys_re and redact_keys_re.search(key):
            result[key] = "[REDACTED Key]"
            continue

        child_path = f"{path}.{key}" if path else key
        try:
            value = properties[key]
            result[key] = serialize(
                value,
                max_depth=max_depth,
                max_array_length=max_array_length,
                max_object_properties=max_object_properties,
                max_string_length=max_string_length,
                redact_keys_re=redact_keys_re,
                redact_values_re=redact_values_re,
                visited=visited,
                depth=depth + 1,
                path=child_path,
            )
        except Exception:
            result[key] = "[Inaccessible]"

    if len(keys) > max_object_properties:
        result["__probe_meta"] = (
            f"+ {len(keys) - max_object_properties} more properties truncated"
        )
    return result
