"""Small, dependency-free namespace debugging for the HyperProbe SDK.

The ``DEBUG`` environment variable accepts comma- or whitespace-separated
namespace patterns. ``*`` matches any characters and a pattern prefixed with
``-`` excludes a namespace.
"""

import os
import re
import sys
import threading


_SELECTOR_SEPARATOR = re.compile(r"[\s,]+")
_COLOR_CODES = (31, 32, 33, 34, 35, 36, 91, 92, 93, 94, 95, 96)
_DISABLED_COLOR_VALUES = {"0", "false", "no", "off"}
_logger_cache: dict[str, "HyperProbeLogger"] = {}
_logger_cache_lock = threading.Lock()


def _compile_selector(pattern: str) -> re.Pattern[str]:
    """Compile a Node-style namespace selector where only ``*`` is special."""
    return re.compile("^" + re.escape(pattern).replace(r"\*", ".*?") + "$")


def _parse_selectors(value: str | None) -> tuple[list[re.Pattern[str]], list[re.Pattern[str]]]:
    enabled: list[re.Pattern[str]] = []
    skipped: list[re.Pattern[str]] = []

    for selector in _SELECTOR_SEPARATOR.split(value or ""):
        if not selector:
            continue

        is_skip = selector.startswith("-")
        pattern = selector[1:] if is_skip else selector
        if not pattern:
            continue

        (skipped if is_skip else enabled).append(_compile_selector(pattern))

    return enabled, skipped


def _matches_selector(pattern: re.Pattern[str], namespace: str) -> bool:
    return pattern.fullmatch(namespace) is not None


def is_namespace_enabled(namespace: str, debug_value: str | None = None) -> bool:
    """Return whether ``namespace`` is selected by ``debug_value`` or ``DEBUG``."""
    enabled, skipped = _parse_selectors(
        os.getenv("DEBUG") if debug_value is None else debug_value
    )
    return (
        bool(enabled)
        and not any(_matches_selector(pattern, namespace) for pattern in skipped)
        and any(_matches_selector(pattern, namespace) for pattern in enabled)
    )


def _namespace_color(namespace: str) -> int:
    # Avoid Python's randomized hash so a namespace keeps its color between runs.
    value = sum((index + 1) * ord(character) for index, character in enumerate(namespace))
    return _COLOR_CODES[value % len(_COLOR_CODES)]


def _colors_enabled(stream: object) -> bool:
    configured = os.getenv("DEBUG_COLORS")
    if configured is not None:
        return configured.strip().lower() not in _DISABLED_COLOR_VALUES
    return bool(getattr(stream, "isatty", lambda: False)())


class HyperProbeLogger:
    """A namespace logger controlled by the ``DEBUG`` environment variable."""

    def __init__(self, namespace: str = "hyperprobe:agent"):
        self.namespace = namespace
        self.enabled = is_namespace_enabled(namespace)
        self.color = _namespace_color(namespace)

    def _prefix(self, stream: object) -> str:
        if _colors_enabled(stream):
            return f"\033[{self.color}m{self.namespace}\033[0m"
        return self.namespace

    def _write(self, message: str, stream: object) -> None:
        print(f"{self._prefix(stream)} {message}", file=stream, flush=True)

    def info(self, message: str) -> None:
        if self.enabled:
            self._write(message, sys.stdout)

    def error(self, message: str) -> None:
        if self.enabled:
            self._write(message, sys.stderr)

    def forceInfo(self, message: str) -> None:
        """Write an informational message without applying the ``DEBUG`` gate."""
        print(message, file=sys.stdout, flush=True)

    def forceError(self, message: str) -> None:
        """Write an error message without applying the ``DEBUG`` gate."""
        print(message, file=sys.stderr, flush=True)


def get_logger(namespace: str) -> HyperProbeLogger:
    """Return the process-wide logger for a namespace.

    ``DEBUG`` is intentionally read when a namespace is first created, matching
    the launch-time configuration behavior of the previous logger.
    """
    with _logger_cache_lock:
        logger = _logger_cache.get(namespace)
        if logger is None:
            logger = HyperProbeLogger(namespace)
            _logger_cache[namespace] = logger
        return logger


# Existing imports continue to work and now use the primary agent namespace.
logger = get_logger("hyperprobe:agent")
