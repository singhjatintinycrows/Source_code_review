import queue
import sys
import threading
from datetime import datetime, timezone


_COLOR_RESET = "\x1b[0m"
_COLOR_BOLD = "\x1b[1m"
_COLOR_GRAY = "\x1b[90m"
_COLOR_MAGENTA = "\x1b[35m"
_LEVEL_COLORS = {
    "ERROR": "\x1b[31m",
    "INFO": "\x1b[32m",
}
_STOP = object()


def normalize_probe_log_level(value):
    candidate = value.strip().upper() if isinstance(value, str) else ""
    return candidate if candidate in _LEVEL_COLORS else "INFO"


def sanitize_probe_log_message(value):
    message = value if isinstance(value, str) else str(value)
    sanitized = []
    escapes = {
        "\n": r"\n",
        "\r": r"\r",
        "\t": r"\t",
    }

    for character in message:
        if character in escapes:
            sanitized.append(escapes[character])
        elif character.isprintable():
            sanitized.append(character)
        else:
            codepoint = ord(character)
            if codepoint <= 0xFF:
                sanitized.append(f"\\x{codepoint:02x}")
            elif codepoint <= 0xFFFF:
                sanitized.append(f"\\u{codepoint:04x}")
            else:
                sanitized.append(f"\\U{codepoint:08x}")

    return "".join(sanitized)


def format_probe_log(timestamp_ms, level, message, use_color=False):
    normalized_level = normalize_probe_log_level(level)
    timestamp = datetime.fromtimestamp(
        timestamp_ms / 1000,
        tz=timezone.utc,
    ).isoformat(timespec="milliseconds").replace("+00:00", "Z")
    safe_message = sanitize_probe_log_message(message)

    if not use_color:
        return f"[{timestamp}] [{normalized_level}] [HyperProbe LOG] {safe_message}\n"

    level_color = _LEVEL_COLORS[normalized_level]
    return (
        f"{_COLOR_GRAY}[{timestamp}]{_COLOR_RESET} "
        f"{_COLOR_BOLD}{level_color}[{normalized_level}]{_COLOR_RESET} "
        f"{_COLOR_BOLD}{_COLOR_MAGENTA}[HyperProbe LOG]{_COLOR_RESET} "
        f"{safe_message}\n"
    )


class ProbeLogWriter:
    """Best-effort probe output that never blocks capture threads."""

    def __init__(self, max_queue_size, stdout=None, stderr=None):
        self._queue = queue.Queue(maxsize=max_queue_size)
        self._stdout = stdout
        self._stderr = stderr
        self._lifecycle_lock = threading.RLock()
        self._thread = None
        self._closed = False
        self.dropped_count = 0
        self.error_count = 0

    def start(self):
        with self._lifecycle_lock:
            return self._start_locked()

    def _start_locked(self):
        if self._closed:
            return False
        if self._thread and self._thread.is_alive():
            return True
        self._thread = threading.Thread(
            target=self._run,
            name="hyperprobe-probe-output",
            daemon=True,
        )
        self._thread.start()
        return True

    def is_running(self):
        with self._lifecycle_lock:
            return bool(self._thread and self._thread.is_alive())

    def submit(self, timestamp_ms, level, message):
        record = (timestamp_ms, normalize_probe_log_level(level), message)
        with self._lifecycle_lock:
            if self._closed:
                return False
            try:
                self._queue.put_nowait(record)
                self._start_locked()
                return True
            except queue.Full:
                self.dropped_count += 1
                return False
            except Exception:
                self.error_count += 1
                return False

    def stop(self, timeout=2.0):
        with self._lifecycle_lock:
            self._closed = True
            thread = self._thread
            if thread:
                try:
                    self._queue.put_nowait(_STOP)
                except queue.Full:
                    pass

        if thread and thread is not threading.current_thread():
            thread.join(timeout=timeout)

    def _run(self):
        while True:
            try:
                record = self._queue.get(timeout=0.1)
            except queue.Empty:
                if self._retire_if_empty():
                    return
                continue

            try:
                if record is not _STOP:
                    self._write(record)
            finally:
                self._queue.task_done()

            if self._retire_if_empty():
                return

    def _retire_if_empty(self):
        with self._lifecycle_lock:
            if not self._queue.empty():
                return False
            if self._thread is threading.current_thread():
                self._thread = None
            return True

    def _write(self, record):
        timestamp_ms, level, message = record
        stream = (
            self._stderr if self._stderr is not None else sys.stderr
        ) if level == "ERROR" else (
            self._stdout if self._stdout is not None else sys.stdout
        )

        try:
            use_color = bool(getattr(stream, "isatty", lambda: False)())
            output = format_probe_log(timestamp_ms, level, message, use_color)
            written = stream.write(output)
            if written is not None and written != len(output):
                with self._lifecycle_lock:
                    self.error_count += 1
                return
            stream.flush()
        except Exception:
            with self._lifecycle_lock:
                self.error_count += 1
