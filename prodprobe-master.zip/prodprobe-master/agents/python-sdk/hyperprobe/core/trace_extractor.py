import sys
import os
import importlib
from hyperprobe.core.logger import get_logger

logger = get_logger("hyperprobe:trace")

def extract_trace_context(custom_get_trace_id=None):
    """
    Safely extract the active trace ID from standard APMs via sys.modules reflection
    or utilize a custom user-defined hook.
    """
    # 1. User-defined custom hook (Highest Priority - passed via code)
    if custom_get_trace_id and callable(custom_get_trace_id):
        try:
            trace_id = custom_get_trace_id()
            if trace_id:
                return str(trace_id)
        except Exception as e:
            logger.info(f"[HyperProbe] Custom trace extractor failed: {e}")

    # 1.5. Environment variable hook 
    hook_path = os.getenv("HYPERPROBE_TRACE_HOOK")
    if hook_path and ":" in hook_path:
        try:
            module_name, func_name = hook_path.split(":", 1)
            # Safely ensure CWD is in the import path
            cwd = os.getcwd()
            added_to_path = False
            
            if cwd not in sys.path:
                sys.path.insert(0, cwd)
                added_to_path = True
                
            try:
                user_module = importlib.import_module(module_name)
                user_func = getattr(user_module, func_name)
                trace_id = user_func()
                if trace_id:
                    return str(trace_id)
            finally:
                # Clean up if we modified sys.path
                if added_to_path:
                    sys.path.remove(cwd)
                    
        except Exception as e:
            logger.info(f"[HyperProbe] Failed to execute HYPERPROBE_TRACE_HOOK: {e}")

    # 2. OpenTelemetry
    try:
        if 'opentelemetry.trace' in sys.modules:
            otel_trace = sys.modules['opentelemetry.trace']
            span = otel_trace.get_current_span()
            if span:
                ctx = span.get_span_context()
                if ctx and ctx.is_valid:
                    return format(ctx.trace_id, '032x')
    except Exception:
        pass

    # 3. Datadog (ddtrace)
    try:
        if 'ddtrace' in sys.modules:
            ddtrace = sys.modules['ddtrace']
            span = ddtrace.tracer.current_span()
            if span and span.trace_id:
                return str(span.trace_id)
    except Exception:
        pass

    # 4. New Relic
    try:
        if 'newrelic.agent' in sys.modules:
            nr = sys.modules['newrelic.agent']
            if hasattr(nr, 'current_trace_id'):
                trace_id = nr.current_trace_id()
                if trace_id:
                    return str(trace_id)
    except Exception:
        pass

    # 5. Elastic APM
    try:
        if 'elasticapm' in sys.modules:
            elasticapm = sys.modules['elasticapm']
            trace_id = elasticapm.get_trace_id()
            if trace_id:
                return str(trace_id)
    except Exception:
        pass
    
    logger.info("[HyperProbe] trace id could not be extracted.")
    return None
