import os
import sys
import time

try:
    # Shaded/vendored fallback
    import _vendor.grpc as grpc
except ImportError:
    import grpc

# Import our generated protos
from hyperprobe.protos import agent_pb2
from hyperprobe.protos import agent_pb2_grpc
from hyperprobe.core.logger import get_logger

logger = get_logger("hyperprobe:broker")


class BrokerTransportError(RuntimeError):
    """Raised when a broker RPC cannot be completed."""

class BrokerClient:
    def __init__(
        self,
        broker_url,
        service_id,
        environment,
        commit_sha,
        agent_id,
        agent_version=None,
        rpc_timeout_sec=10.0,
    ):
        self.broker_url = broker_url
        self.service_id = service_id
        self.environment = environment
        self.commit_sha = commit_sha
        self.agent_id = agent_id
        if agent_version is None:
            try:
                from importlib.metadata import version
                agent_version = version("hyperprobe-agent")
            except Exception:
                agent_version = "unknown"
        self.agent_version = agent_version
        self.rpc_timeout_sec = max(float(rpc_timeout_sec), 0.1)
        self.metadata = (("x-hp-service-id", str(service_id)),)
        self.hostname = os.uname().nodename if hasattr(os, 'uname') else 'unknown'

        # Establish channel depending on URL protocol to support both secure (SSL) and insecure brokers
        if broker_url.startswith("https://"):
            clean_url = broker_url[8:]
            self.channel = grpc.secure_channel(clean_url, grpc.ssl_channel_credentials())
        elif broker_url.startswith("http://"):
            clean_url = broker_url[7:]
            self.channel = grpc.insecure_channel(clean_url)
        else:
            self.channel = grpc.insecure_channel(broker_url)
            
        self.stub = agent_pb2_grpc.AgentBrokerStub(self.channel)

    def shutdown(self):
        self.channel.close()

    def get_probes(self):
        """Fetches active probes from the HyperProbe Broker."""
        request = agent_pb2.GetProbesRequest(
            agent_id=self.agent_id,
            service_id=self.service_id,
            environment=self.environment,
            commit_sha=self.commit_sha,
            language="python",
            agent_version=self.agent_version,
            hostname=self.hostname
        )
        try:
            response = self.stub.GetProbes(
                request,
                timeout=self.rpc_timeout_sec,
                metadata=self.metadata,
            )
            return response
        except Exception as e:
            raise BrokerTransportError(f"GetProbes failed: {e}") from e

    @staticmethod
    def _to_proto_event(event):
        stack_frames = [
            agent_pb2.StackFrame(
                function_name=frame["function_name"],
                file_name=frame["file_name"],
                line_number=frame["line_number"],
                column_number=frame["column_number"],
            )
            for frame in event.get("stack_frames", [])
        ]

        proto_event = agent_pb2.TelemetryEvent(
            probe_id=event["probe_id"],
            timestamp_ms=event["timestamp_ms"],
            stack_frames=stack_frames,
            captured_vars_json=event.get("captured_vars_json", ""),
            watch_results_json=event.get("watch_results_json", ""),
            evaluated_log=event.get("evaluated_log", ""),
            metric_value=event.get("metric_value", 0.0),
            capture_error=event.get("capture_error", ""),
        )
        if event.get("trace_id"):
            proto_event.trace_id = event["trace_id"]
        return proto_event

    def estimate_event_size(self, event):
        return len(self._to_proto_event(event).SerializeToString())

    def report_telemetry(self, events):
        """Sends a batch of captured Telemetry Events to the HyperProbe Broker."""
        batch_events = [self._to_proto_event(event) for event in events]

        batch = agent_pb2.TelemetryBatch(
            agent_id=self.agent_id,
            events=batch_events
        )
        
        try:
            response = self.stub.ReportTelemetry(
                batch,
                timeout=self.rpc_timeout_sec,
                metadata=self.metadata,
            )
            return response.finished_probe_ids
        except Exception as e:
            raise BrokerTransportError(f"ReportTelemetry failed: {e}") from e
