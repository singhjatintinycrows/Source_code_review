import time
import threading


class QuotaReservation:
    def __init__(self, bucket, count: float):
        self._bucket = bucket
        self._count = count
        self._closed = False
        self._lock = threading.Lock()

    def commit(self):
        with self._lock:
            self._closed = True

    def release(self):
        with self._lock:
            if self._closed:
                return
            self._closed = True
        self._bucket.refund(self._count)


class TokenBucket:
    def __init__(self, capacity: float, refill_rate_per_sec: float):
        self.capacity = capacity
        self.refill_rate = refill_rate_per_sec  # tokens per second
        self.tokens = capacity
        self.last_refill = time.monotonic()
        self.lock = threading.Lock()

    def try_consume(self, count: float = 1.0) -> bool:
        reservation = self.reserve(count)
        if reservation is None:
            return False
        reservation.commit()
        return True

    def reserve(self, count: float = 1.0):
        with self.lock:
            self._refill()
            if self.tokens >= count:
                self.tokens -= count
                return QuotaReservation(self, count)
            return None

    def refund(self, count: float):
        with self.lock:
            self._refill()
            self.tokens = min(self.capacity, self.tokens + count)

    def _refill(self):
        now = time.monotonic()
        delta = now - self.last_refill
        amount = delta * self.refill_rate
        self.tokens = min(self.capacity, self.tokens + amount)
        self.last_refill = now


class QuotaManager:
    def __init__(self, hits_per_sec: float = 10.0, bytes_per_sec: float = 200.0 * 1024.0):
        # Burst capacity of hits_per_sec and bytes_per_sec (1 second worth)
        self.eval_bucket = TokenBucket(hits_per_sec, hits_per_sec)
        self.bandwidth_bucket = TokenBucket(bytes_per_sec, bytes_per_sec)

    def can_evaluate(self) -> bool:
        return self.eval_bucket.try_consume(1.0)

    def can_send(self, bytes_count: float) -> bool:
        return self.bandwidth_bucket.try_consume(bytes_count)

    def reserve_bandwidth(self, bytes_count: float):
        return self.bandwidth_bucket.reserve(bytes_count)