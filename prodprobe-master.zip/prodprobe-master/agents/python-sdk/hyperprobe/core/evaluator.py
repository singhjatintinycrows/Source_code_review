import os
import re
import ast
from functools import lru_cache
from typing import Optional

from hyperprobe.core.logger import get_logger

logger = get_logger("hyperprobe:evaluator")

SAFE_BUILTINS = {
    "len": len, "str": str, "int": int, "float": float, 
    "bool": bool, "list": list, "dict": dict, "set": set,
    "max": max, "min": min, "abs": abs, "round": round,
    "isinstance": isinstance, "type": type
}

COMPILED_CACHE_SIZE = 200

SAFE_METHODS = {
    # Dictionary/List read-only methods
    "keys", "values", "items", "count",
    # String read-only methods
    "lower", "upper",
    "isdigit", "isalpha", "isnumeric", "isalnum",
}

def is_safe_evaluation_enabled() -> bool:
    return os.getenv("HYPERPROBE_DISABLE_SAFE_EVALUATION", "").strip().lower() != "true"

class SafeASTVisitor(ast.NodeVisitor):
    def visit_Call(self, node):
        # 1. Is it a direct function call? e.g. len(items)
        if isinstance(node.func, ast.Name):
            if node.func.id not in SAFE_BUILTINS:
                raise ValueError(f"Function call '{node.func.id}' is not allowed.")
                
        # 2. Is it a method call on an object? e.g. user.get_id() or my_dict.keys()
        elif isinstance(node.func, ast.Attribute):
            method_name = node.func.attr
            if method_name not in SAFE_METHODS:
                raise ValueError(f"Method call '.{method_name}()' is strictly forbidden.")
                
        else:
            raise ValueError("Complex dynamic calls are strictly forbidden.")
            
        self.generic_visit(node)


class ProbeEvaluator:
    _placeholder_regex = re.compile(r'\$?\{([^}]+)\}')

    @classmethod
    def is_safe_evaluation_enabled(cls) -> bool:
        return is_safe_evaluation_enabled()

    @classmethod
    def _get_or_compile(cls, expr: str, safe: bool = True):
        # Normalize the string to prevent duplicate cache entries
        clean_expr = expr.strip()
        if safe:
            return cls._compile_safe(clean_expr)
        return cls._compile_unsafe(clean_expr)

    @classmethod
    def _get_or_compile_safe(cls, expr: str):
        return cls._get_or_compile(expr, safe=True)

    @staticmethod
    @lru_cache(maxsize=COMPILED_CACHE_SIZE)
    def _compile_safe(clean_expr: str):
        # Cache misses are parsed and compiled once; least-recently-used
        # expressions are evicted after the bounded cache reaches capacity.
        if len(clean_expr) > 256:
            raise ValueError("Expression is too long (max 256 characters).")

        tree = ast.parse(clean_expr, mode='eval')
        visitor = SafeASTVisitor()
        visitor.visit(tree)
        
        # Compile it to bytecode
        compiled_code = compile(tree, filename="<string>", mode="eval")
        
        return compiled_code

    @staticmethod
    @lru_cache(maxsize=COMPILED_CACHE_SIZE)
    def _compile_unsafe(clean_expr: str):
        # Unsafe mode allows function/method calls without AST validation
        return compile(clean_expr, filename="<string>", mode="eval")

    @classmethod
    def evaluate(cls, expr: str, globals_dict: dict, locals_dict: dict, safe: Optional[bool] = None):
        if safe is None:
            safe = cls.is_safe_evaluation_enabled()

        if safe:
            # Create a shadow copy of globals, forcefully removing dangerous builtins
            safe_globals = globals_dict.copy()
            safe_globals["__builtins__"] = SAFE_BUILTINS

            # Grab the pre-compiled safe bytecode
            compiled = cls._get_or_compile(expr, safe=True)
            
            # Execute the bytecode
            return eval(compiled, safe_globals, locals_dict)
        else:
            # Grab the pre-compiled unsafe bytecode allowing full execution
            compiled = cls._get_or_compile(expr, safe=False)
            return eval(compiled, globals_dict, locals_dict)

    @classmethod
    def safe_eval(cls, expr: str, globals_dict: dict, locals_dict: dict, safe: Optional[bool] = None):
        """Evaluates an expression, delegating to ProbeEvaluator.evaluate."""
        return cls.evaluate(expr, globals_dict, locals_dict, safe=safe)

    @classmethod
    def evaluate_log_template(cls, template: str, globals_dict: dict, locals_dict: dict, safe: Optional[bool] = None) -> str:
        """Parses and formats a log template string."""
        if not template:
            return ""
        
        if safe is None:
            safe = cls.is_safe_evaluation_enabled()

        result = []
        last_idx = 0
        for match in cls._placeholder_regex.finditer(template):
            # Append plain text preceding placeholder
            result.append(template[last_idx:match.start()])
            expr = match.group(1).strip()
            
            try:
                # Execute expression
                val = cls.evaluate(expr, globals_dict, locals_dict, safe=safe)
                result.append(str(val))
            except Exception as e:
                result.append(f"<Error: {type(e).__name__}: {str(e)}>")
            last_idx = match.end()
            
        result.append(template[last_idx:])
        return "".join(result)

    @classmethod
    def evaluate_watches(cls, watch_expressions: list, globals_dict: dict, locals_dict: dict, safe: Optional[bool] = None) -> dict:
        """Evaluates a set of independent watch expressions."""
        results = {}
        if not watch_expressions:
            return results
        if safe is None:
            safe = cls.is_safe_evaluation_enabled()
        for expr in watch_expressions:
            try:
                results[expr] = cls.evaluate(expr, globals_dict, locals_dict, safe=safe)
            except Exception as e:
                results[expr] = f"Error: {type(e).__name__}: {str(e)}"
        return results
