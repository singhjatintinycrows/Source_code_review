import time
import threading
from collections import deque

class AgentHealth:
    GREEN = 'GREEN'   # All good
    YELLOW = 'YELLOW' # Rate limited (Reactive Shedding)
    RED = 'RED'       # Critical Lag (Proactive Shedding - Detach)


class SafetyMonitor:
    _SAMPLE_INTERVAL_SECONDS = 0.1
    _LAG_WINDOW_SIZE = 10
    _LAG_YELLOW_BREACHES = 4
    _LAG_RED_BREACHES = 7
    _SEVERE_LAG_WINDOW_SIZE = 5
    _SEVERE_LAG_RED_BREACHES = 3
    _SEVERE_LAG_MULTIPLIER = 4.0

    def __init__(self, on_state_change, max_lag_ms=50.0, pause_budget_ms=15.0):
        self.on_state_change = on_state_change
        self.max_lag_ms = max_lag_ms
        self.pause_budget_ms = pause_budget_ms
        
        self.health = AgentHealth.GREEN
        self.cumulative_pause_time = 0.0
        self.last_window_reset = time.monotonic()
        self.last_thread_lag_ms = 0.0
        self.thread_lag_samples = deque(maxlen=self._LAG_WINDOW_SIZE)
        
        self.lock = threading.RLock()
        self._notification_lock = threading.RLock()
        
        self.is_running = False
        self.thread = None
        self.stop_event = threading.Event()

    def start(self):
        self.stop_event.clear()
        self.is_running = True
        self.thread = threading.Thread(target=self._run_loop, name="hyperprobe-safety")
        self.thread.daemon = True
        self.thread.start()

    def stop(self):
        self.is_running = False
        self.stop_event.set()
        if self.thread and self.thread is not threading.current_thread():
            self.thread.join(timeout=2.0)
        self.thread = None

    def report_pause_duration(self, ms: float):
        with self.lock:
            self.cumulative_pause_time += ms
            transition = self._evaluate_health_locked()

        self._notify_state_change(transition)

    def _run_loop(self):
        while self.is_running:
            wait_started_at = time.monotonic()
            if self.stop_event.wait(self._SAMPLE_INTERVAL_SECONDS):
                break

            now = time.monotonic()
            thread_lag_ms = max(
                0.0,
                (
                    now
                    - wait_started_at
                    - self._SAMPLE_INTERVAL_SECONDS
                ) * 1000.0,
            )

            with self.lock:
                self._record_thread_lag_locked(thread_lag_ms)
                if now - self.last_window_reset > 1.0:
                    self.cumulative_pause_time = 0.0
                    self.last_window_reset = now

                transition = self._evaluate_health_locked()

            self._notify_state_change(transition)

    def _check_health(self, thread_lag_ms=None):
        """
        Records an optional lag sample and executes callbacks outside the
        state lock.
        """
        with self.lock:
            if thread_lag_ms is not None:
                self._record_thread_lag_locked(thread_lag_ms)
            transition = self._evaluate_health_locked()

        self._notify_state_change(transition)

    def _record_thread_lag_locked(self, thread_lag_ms: float):
        thread_lag_ms = max(0.0, thread_lag_ms)
        self.last_thread_lag_ms = thread_lag_ms
        self.thread_lag_samples.append(thread_lag_ms)

    def _evaluate_health_locked(self):
        previous_health = self.health
        reason = None

        recent_lags = list(self.thread_lag_samples)
        lag_breaches = sum(
            lag > self.max_lag_ms for lag in recent_lags
        )
        severe_lag_ms = self.max_lag_ms * self._SEVERE_LAG_MULTIPLIER
        severe_lag_breaches = sum(
            lag > severe_lag_ms
            for lag in recent_lags[-self._SEVERE_LAG_WINDOW_SIZE:]
        )

        if severe_lag_breaches >= self._SEVERE_LAG_RED_BREACHES:
            self.health = AgentHealth.RED
            reason = (
                f"Severe Execution Thread Lag exceeded {severe_lag_ms}ms in "
                f"{severe_lag_breaches}/{self._SEVERE_LAG_WINDOW_SIZE} "
                f"recent readings"
            )
        elif lag_breaches >= self._LAG_RED_BREACHES:
            self.health = AgentHealth.RED
            reason = (
                f"Execution Thread Lag exceeded {self.max_lag_ms}ms in "
                f"{lag_breaches}/{self._LAG_WINDOW_SIZE} recent readings"
            )
        elif self.cumulative_pause_time > self.pause_budget_ms:
            self.health = AgentHealth.RED
            reason = (
                f"Cumulative Pause Budget ({self.cumulative_pause_time:.1f}ms) "
                f"exceeded limit ({self.pause_budget_ms}ms)"
            )
        elif severe_lag_breaches > 0:
            self.health = AgentHealth.YELLOW
            reason = (
                f"Moderate impact: Severe Execution Thread Lag exceeded "
                f"{severe_lag_ms}ms in {severe_lag_breaches}/"
                f"{self._SEVERE_LAG_WINDOW_SIZE} recent readings"
            )
        elif lag_breaches >= self._LAG_YELLOW_BREACHES:
            self.health = AgentHealth.YELLOW
            reason = (
                f"Moderate impact: Execution Thread Lag exceeded "
                f"{self.max_lag_ms}ms in {lag_breaches}/"
                f"{self._LAG_WINDOW_SIZE} recent readings"
            )
        elif self.cumulative_pause_time > self.pause_budget_ms / 2.0:
            self.health = AgentHealth.YELLOW
            reason = (
                f"Moderate impact: Cumulative Pause Budget "
                f"({self.cumulative_pause_time:.1f}ms) reached 50% of limit "
                f"({self.pause_budget_ms}ms)"
            )
        else:
            self.health = AgentHealth.GREEN
            if previous_health != AgentHealth.GREEN:
                reason = "System stabilized."

        if self.health != previous_health:
            return self.health, reason

        return None

    def _notify_state_change(self, transition):
        if transition is None:
            return

        health, reason = transition

        with self._notification_lock:
            with self.lock:
                if self.health != health:
                    return

            try:
                self.on_state_change(health, reason)
            except Exception:
                # Safety callbacks must never break application execution.
                pass

    def get_health(self) -> str:
        with self.lock:
            return self.health
