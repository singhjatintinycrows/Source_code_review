import sys
import os

# Inject current directory into sys.path temporarily so generated protobuf imports resolve correctly
current_dir = os.path.dirname(os.path.abspath(__file__))
if current_dir not in sys.path:
    sys.path.insert(0, current_dir)
