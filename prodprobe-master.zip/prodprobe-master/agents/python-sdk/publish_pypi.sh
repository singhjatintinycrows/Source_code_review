#!/usr/bin/env bash
# publish_pypi.sh
# Automates building, verifying, and publishing the hyperprobe-agent SDK to PyPI.

set -Eeuo pipefail

# Colors for output (disabled when output is not a terminal or NO_COLOR is set).
if [[ -t 1 && -z "${NO_COLOR:-}" ]]; then
    GREEN='\033[0;32m'
    BLUE='\033[0;34m'
    RED='\033[0;31m'
    NC='\033[0m'
else
    GREEN=''
    BLUE=''
    RED=''
    NC=''
fi

readonly PYPI_REPOSITORY_URL="https://upload.pypi.org/legacy/"
readonly PYPI_PROJECT_URL="https://pypi.org/project/hyperprobe-agent/"
readonly EXPECTED_PACKAGE_NAME="hyperprobe-agent"

ASSUME_YES=false
DRY_RUN=false
TOOL_VENV=""
TOKEN=""
PYPI_TOKEN_FROM_ENV="${PYPI_API_TOKEN:-}"
TWINE_TOKEN_FROM_ENV="${TWINE_PASSWORD:-}"

# Keep release credentials out of build backend and dependency-install subprocesses.
# They are exported only for the final Twine upload.
unset PYPI_API_TOKEN TWINE_USERNAME TWINE_PASSWORD

info() {
    printf '%b\n' "${BLUE}$*${NC}"
}

success() {
    printf '%b\n' "${GREEN}$*${NC}"
}

fail() {
    printf '%b\n' "${RED}Error: $*${NC}" >&2
    exit 1
}

validate_release_python() {
    "$1" - <<'PY'
import ssl
import sys

if sys.version_info < (3, 12):
    raise SystemExit(
        f"Python 3.12+ is required; found {sys.version.split()[0]}."
    )

if not ssl.OPENSSL_VERSION.startswith("OpenSSL "):
    raise SystemExit(
        f"An OpenSSL-backed Python is required; found {ssl.OPENSSL_VERSION}."
    )

if ssl.OPENSSL_VERSION_INFO < (1, 1, 1):
    raise SystemExit(
        f"OpenSSL 1.1.1+ is required; found {ssl.OPENSSL_VERSION}."
    )
PY
}

usage() {
    cat <<'EOF'
Usage: ./publish_pypi.sh [--yes] [--dry-run]

Build, validate, and upload hyperprobe-agent to production PyPI.

Options:
  --yes, -y   Confirm the production upload non-interactively (required in CI).
  --dry-run   Build and validate artifacts without uploading them.
  --help, -h  Show this help text.

Credentials:
  Set PYPI_API_TOKEN (preferred) or TWINE_PASSWORD to a scoped PyPI API token.
  When run from a terminal, the script securely prompts if neither is set.

Runtime:
  Python 3.12+ linked against OpenSSL 1.1.1+ is required. Set PYTHON_BIN to
  select a specific interpreter or release virtual environment.

Examples:
  PYPI_API_TOKEN='pypi-...' ./publish_pypi.sh --yes
  ./publish_pypi.sh --dry-run
EOF
}

cleanup() {
    local exit_code=$?

    # Do not retain credentials longer than the upload process needs them.
    TOKEN=""
    PYPI_TOKEN_FROM_ENV=""
    TWINE_TOKEN_FROM_ENV=""
    unset PYPI_API_TOKEN TWINE_USERNAME TWINE_PASSWORD

    if [[ -n "$TOOL_VENV" && -d "$TOOL_VENV" ]]; then
        rm -rf -- "$TOOL_VENV"
    fi

    return "$exit_code"
}

trap cleanup EXIT
trap 'exit 130' INT
trap 'exit 143' TERM

while [[ $# -gt 0 ]]; do
    case "$1" in
        --yes|-y)
            ASSUME_YES=true
            ;;
        --dry-run)
            DRY_RUN=true
            ;;
        --help|-h)
            usage
            exit 0
            ;;
        *)
            usage >&2
            fail "Unknown argument: $1"
            ;;
    esac
    shift
done

printf '%b\n' "${BLUE}====================================================${NC}"
printf '%b\n' "${BLUE}          HyperProbe PyPI Release Script           ${NC}"
printf '%b\n' "${BLUE}====================================================${NC}"

# 1. Ensure we are in the correct directory (the setup.py parent).
SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd -P)"
readonly SCRIPT_DIR
readonly DIST_DIR="$SCRIPT_DIR/dist"
readonly BUILD_DIR="$SCRIPT_DIR/build"
readonly EGG_INFO_DIR="$SCRIPT_DIR/hyperprobe_agent.egg-info"

# Resolve a caller-provided relative interpreter path before changing directories.
REQUESTED_PYTHON_BIN="${PYTHON_BIN:-python3}"
PYTHON_BIN="$(command -v "$REQUESTED_PYTHON_BIN")" || \
    fail "Python executable '$REQUESTED_PYTHON_BIN' was not found."
if [[ "$PYTHON_BIN" == */* ]]; then
    PYTHON_BIN_DIR="$(cd -- "$(dirname -- "$PYTHON_BIN")" && pwd -P)"
    PYTHON_BIN="$PYTHON_BIN_DIR/$(basename -- "$PYTHON_BIN")"
fi

cd -- "$SCRIPT_DIR"

[[ -f "$SCRIPT_DIR/setup.py" ]] || \
    fail "setup.py was not found. Place this script in agents/python-sdk/."

if [[ "$DRY_RUN" != true && "$ASSUME_YES" != true && ! -t 0 ]]; then
    fail "Refusing a non-interactive production upload without --yes."
fi

# 2. Select an isolated packaging toolchain without modifying the caller's environment.
validate_release_python "$PYTHON_BIN" || \
    fail "Select a supported release interpreter with PYTHON_BIN."

TOOL_PYTHON="$PYTHON_BIN"
if "$TOOL_PYTHON" -c 'import build, twine' >/dev/null 2>&1; then
    success "[1/6] Found build and twine in the selected Python environment."
else
    info "[1/6] Packaging tools were not found. Creating a temporary virtual environment..."
    TOOL_VENV="$(mktemp -d "${TMPDIR:-/tmp}/hyperprobe-pypi-tools.XXXXXX")"
    "$PYTHON_BIN" -m venv "$TOOL_VENV" || \
        fail "Unable to create the temporary packaging environment."
    TOOL_PYTHON="$TOOL_VENV/bin/python"

    info "[2/6] Installing build and twine in the temporary environment..."
    "$TOOL_PYTHON" -m pip install \
        --disable-pip-version-check \
        --no-cache-dir \
        --upgrade build twine || \
        fail "Unable to install the required packaging tools."
fi

if [[ -z "$TOOL_VENV" ]]; then
    success "[2/6] Packaging toolchain is ready."
fi

# 3. Validate the packaging toolchain before changing build artifacts.
"$TOOL_PYTHON" -m build --version >/dev/null 2>&1 || \
    fail "The selected Python environment cannot run build."
"$TOOL_PYTHON" -m twine --version >/dev/null 2>&1 || \
    fail "The selected Python environment cannot run twine."
success "[3/6] Packaging toolchain validated."

# 4. Clean only this package's known build artifacts.
info "[4/6] Cleaning previous hyperprobe-agent build artifacts..."
rm -rf -- "$DIST_DIR" "$BUILD_DIR" "$EGG_INFO_DIR"

# 5. Build the package (sdist and wheel).
info "[5/6] Packaging SDK (generating wheel and sdist)..."
"$TOOL_PYTHON" -m build --outdir "$DIST_DIR" "$SCRIPT_DIR" || \
    fail "Package build failed. Nothing was uploaded."

shopt -s nullglob
WHEELS=("$DIST_DIR"/*.whl)
SDISTS=("$DIST_DIR"/*.tar.gz)
shopt -u nullglob

[[ ${#WHEELS[@]} -eq 1 ]] || \
    fail "Expected exactly one wheel in dist/, found ${#WHEELS[@]}."
[[ ${#SDISTS[@]} -eq 1 ]] || \
    fail "Expected exactly one source distribution in dist/, found ${#SDISTS[@]}."
[[ -f "${WHEELS[0]}" && ! -L "${WHEELS[0]}" ]] || \
    fail "The wheel artifact is missing or is a symbolic link."
[[ -f "${SDISTS[0]}" && ! -L "${SDISTS[0]}" ]] || \
    fail "The source distribution is missing or is a symbolic link."

ARTIFACTS=("${WHEELS[0]}" "${SDISTS[0]}")

# 6. Validate artifact descriptions and ensure both archives identify the intended release.
info "[6/6] Validating package metadata standards via twine..."
"$TOOL_PYTHON" -m twine check --strict "${ARTIFACTS[@]}" || \
    fail "Package metadata validation failed. Nothing was uploaded."

PACKAGE_METADATA="$("$TOOL_PYTHON" - "${WHEELS[0]}" "${SDISTS[0]}" <<'PY'
import email.parser
import re
import sys
import tarfile
import zipfile

from packaging.version import InvalidVersion, Version


def fields(raw_metadata):
    message = email.parser.BytesParser().parsebytes(raw_metadata)
    name = message.get("Name", "").strip()
    version = message.get("Version", "").strip()
    if not name or not version:
        raise ValueError("artifact metadata is missing Name or Version")
    try:
        Version(version)
    except InvalidVersion as error:
        raise ValueError(f"invalid package version: {version}") from error
    return name, version


wheel_path, sdist_path = sys.argv[1:]
with zipfile.ZipFile(wheel_path) as wheel:
    members = [name for name in wheel.namelist() if name.endswith(".dist-info/METADATA")]
    if len(members) != 1:
        raise ValueError(f"wheel contains {len(members)} METADATA files; expected one")
    wheel_fields = fields(wheel.read(members[0]))

with tarfile.open(sdist_path, mode="r:gz") as sdist:
    members = [member for member in sdist.getmembers() if member.isfile() and member.name.count("/") == 1 and member.name.endswith("/PKG-INFO")]
    if len(members) != 1:
        raise ValueError(f"sdist contains {len(members)} top-level PKG-INFO files; expected one")
    stream = sdist.extractfile(members[0])
    if stream is None:
        raise ValueError("unable to read PKG-INFO from sdist")
    sdist_fields = fields(stream.read())

if wheel_fields != sdist_fields:
    raise ValueError("wheel and sdist package metadata do not match")

normalized_name = re.sub(r"[-_.]+", "-", wheel_fields[0]).lower()
print(f"{normalized_name}|{wheel_fields[1]}")
PY
)" || fail "Artifact identity validation failed. Nothing was uploaded."

PACKAGE_NAME="${PACKAGE_METADATA%%|*}"
PACKAGE_VERSION="${PACKAGE_METADATA#*|}"
[[ "$PACKAGE_NAME" == "$EXPECTED_PACKAGE_NAME" ]] || \
    fail "Built '$PACKAGE_NAME', expected '$EXPECTED_PACKAGE_NAME'. Nothing was uploaded."
[[ -n "$PACKAGE_VERSION" && "$PACKAGE_VERSION" != "$PACKAGE_METADATA" ]] || \
    fail "Could not determine the package version from the artifacts."

success "===================================================="
success " Build & Validation Completed: $PACKAGE_NAME $PACKAGE_VERSION"
success "===================================================="

if [[ "$DRY_RUN" == true ]]; then
    success "Dry run complete. Validated artifacts are available in $DIST_DIR."
    exit 0
fi

# 7. Require explicit confirmation before the production upload.
if [[ "$ASSUME_YES" != true ]]; then
    printf 'Ready to upload %s %s to production PyPI.\n' "$PACKAGE_NAME" "$PACKAGE_VERSION"
    read -r -p "Do you want to proceed with uploading? (y/n): " CONFIRM
    case "$CONFIRM" in
        y|Y|yes|YES|Yes)
            ;;
        *)
            info "Upload canceled. Validated build files remain in $DIST_DIR."
            exit 0
            ;;
    esac
fi

# 8. Resolve credentials (via .pypirc config file or environment token).
TWINE_CONFIG="${TWINE_CONFIG_FILE:-}"
if [[ -z "$TWINE_CONFIG" && -f "$SCRIPT_DIR/../../.pypirc" ]]; then
    TWINE_CONFIG="$SCRIPT_DIR/../../.pypirc"
elif [[ -z "$TWINE_CONFIG" && -f "$SCRIPT_DIR/.pypirc" ]]; then
    TWINE_CONFIG="$SCRIPT_DIR/.pypirc"
fi

EXTRA_TWINE_ARGS=()
if [[ -n "$TWINE_CONFIG" && -f "$TWINE_CONFIG" ]]; then
    info "Using PyPI configuration file: $TWINE_CONFIG"
    EXTRA_TWINE_ARGS+=(--config-file "$TWINE_CONFIG")
else
    if [[ -n "$PYPI_TOKEN_FROM_ENV" && -n "$TWINE_TOKEN_FROM_ENV" && \
          "$PYPI_TOKEN_FROM_ENV" != "$TWINE_TOKEN_FROM_ENV" ]]; then
        fail "PYPI_API_TOKEN and TWINE_PASSWORD are both set but do not match."
    fi

    TOKEN="${PYPI_TOKEN_FROM_ENV:-$TWINE_TOKEN_FROM_ENV}"
    PYPI_TOKEN_FROM_ENV=""
    TWINE_TOKEN_FROM_ENV=""
    if [[ -z "$TOKEN" ]]; then
        [[ -t 0 ]] || \
            fail "No API token or .pypirc found. Provide .pypirc or set PYPI_API_TOKEN / TWINE_PASSWORD."
        info "Enter a scoped production PyPI API token (input will be hidden)."
        read -r -s -p "API Token: " TOKEN
        printf '\n'
    fi

    [[ "$TOKEN" == pypi-* ]] || \
        fail "Invalid API token format; PyPI API tokens must start with 'pypi-'."

    export TWINE_USERNAME="__token__"
    export TWINE_PASSWORD="$TOKEN"
fi

info "Uploading $PACKAGE_NAME $PACKAGE_VERSION to production PyPI..."
"$TOOL_PYTHON" -m twine upload \
    "${EXTRA_TWINE_ARGS[@]}" \
    --repository pypi \
    --non-interactive \
    --skip-existing \
    "${ARTIFACTS[@]}" || \
    fail "PyPI upload failed. Existing releases were left unchanged; rerun to retry."

TOKEN=""
unset TWINE_USERNAME TWINE_PASSWORD

success "Successfully completed the PyPI upload for $PACKAGE_NAME $PACKAGE_VERSION."
printf 'View the package at: %b%s%b\n' "$BLUE" "$PYPI_PROJECT_URL" "$NC"
