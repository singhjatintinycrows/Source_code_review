#!/bin/bash
# publish_testpypi.sh
# Automates building, verifying, and publishing the hyperprobe-agent SDK to TestPyPI.

set -e

# Colors for output
GREEN='\033[0;32m'
BLUE='\033[0;34m'
RED='\033[0;31m'
NC='\033[0m' # No Color

echo -e "${BLUE}====================================================${NC}"
echo -e "${BLUE}        HyperProbe TestPyPI Release Script          ${NC}"
echo -e "${BLUE}====================================================${NC}"

# 1. Ensure we are in the correct directory (the setup.py parent)
SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
cd "$SCRIPT_DIR"

if [ ! -f "setup.py" ]; then
    echo -e "${RED}Error: setup.py not found in the current directory!${NC}"
    echo "Please make sure this script is placed in: agents/python-sdk/"
    exit 1
fi

# 2. Check for or create the virtual environment
if [ ! -d ".venv" ]; then
    echo -e "${BLUE}[1/6] Virtual environment (.venv) not found. Creating it...${NC}"
    python3 -m venv .venv
else
    echo -e "${GREEN}[1/6] Found existing virtual environment (.venv).${NC}"
fi

# 3. Activate Virtual Environment
echo -e "${BLUE}[2/6] Activating virtual environment...${NC}"
source .venv/bin/activate

# 4. Install & Upgrade build requirements
echo -e "${BLUE}[3/6] Ensuring packaging tools (pip, build, twine) are installed and up to date...${NC}"
pip install --upgrade pip build twine

# 5. Clean previous build artifacts to prevent duplicate uploads
echo -e "${BLUE}[4/6] Cleaning up old builds...${NC}"
rm -rf dist/ build/ *.egg-info/

# 6. Build the package (sdist and wheel)
echo -e "${BLUE}[5/6] Packaging SDK (generating wheel & sdist)...${NC}"
python3 -m build

# 7. Validate build artifacts
echo -e "${BLUE}[6/6] Validating package metadata standards via twine...${NC}"
twine check dist/*

echo -e "${GREEN}====================================================${NC}"
echo -e "${GREEN}       Build & Validation Completed Successfully!   ${NC}"
echo -e "${GREEN}====================================================${NC}"

# 8. Interactive Secure Upload
echo -e "Ready to upload your package to TestPyPI."
read -p "Do you want to proceed with uploading? (y/n): " confirm
if [[ $confirm == [yY] || $confirm == [yY][eE][sS] ]]; then
    # Prompt securely for API token
    echo -e "\n${BLUE}Please enter your TestPyPI API token (it starts with 'pypi-')${NC}"
    echo -e "Note: Your input will be hidden for security."
    read -s -p "API Token: " token
    echo -e "\n"

    if [[ ! $token == pypi-* ]]; then
        echo -e "${RED}Error: Invalid token format! API tokens must start with 'pypi-'${NC}"
        exit 1
    fi

    # Set temporary environment credentials for twine upload
    export TWINE_USERNAME="__token__"
    export TWINE_PASSWORD="$token"

    echo -e "${BLUE}Uploading package artifacts to TestPyPI...${NC}"
    twine upload --repository testpypi dist/*

    echo -e "\n${GREEN}🎉 Successfully published hyperprobe-agent!${NC}"
    echo -e "You can view your package live here:"
    echo -e "👉 ${BLUE}https://test.pypi.org/project/hyperprobe-agent/${NC}"
else
    echo -e "\n${RED}Upload canceled. Your build files are saved in the 'dist/' folder.${NC}"
fi