import json
import os
from pathlib import Path
import subprocess
import sys
import textwrap

import pytest


SDK_DIR = Path(__file__).resolve().parents[1]


@pytest.mark.skipif(
    not hasattr(os, "fork") or not hasattr(os, "register_at_fork"),
    reason="requires POSIX fork handlers",
)
def test_worker_fork_mode_reinitializes_each_child():
    script = textwrap.dedent(
        """
        import json
        import os
        import time

        import hyperprobe.agent as agent_module


        class FakeBrokerClient:
            def __init__(self, **kwargs):
                self.agent_id = kwargs["agent_id"]
                self.agent_version = "test-version"
                self.reported = []

            def shutdown(self):
                pass

            def get_probes(self):
                return None

            def report_telemetry(self, events):
                self.reported.extend(events)
                return []


        agent_module.BrokerClient = FakeBrokerClient
        HyperProbeAgent = agent_module.HyperProbeAgent

        agent = HyperProbeAgent.start({
            "broker_url": "localhost:60051",
            "service_id": "87c699ba-a5a4-4ca8-927b-e7b33707cf6d",
            "environment": "test",
            "commit_sha": "test-commit",
            "flush_interval_ms": 10,
            "fork_mode": "worker",
        })
        parent_agent_id = agent.agent_id
        repeated_start_is_same = HyperProbeAgent.start({}) is agent
        parent_runtime_deferred = all([
            HyperProbeAgent._instance is None,
            not hasattr(agent, "broker_client"),
            not hasattr(agent, "engine"),
            not hasattr(agent, "sync_thread"),
        ])
        children = []

        for index in range(2):
            read_fd, write_fd = os.pipe()
            child_pid = os.fork()
            if child_pid == 0:
                os.close(read_fd)
                payload = {}
                exit_code = 0
                try:
                    current = HyperProbeAgent._instance
                    payload.update({
                        "same_object": current is agent,
                        "owner_pid": current.owner_pid,
                        "process_pid": os.getpid(),
                        "agent_id": current.agent_id,
                        "parent_agent_id": parent_agent_id,
                        "threads_alive": all([
                            current.sync_thread.is_alive(),
                            current.flush_thread.is_alive(),
                            current.stats_thread.is_alive(),
                            current.safety_monitor.thread.is_alive(),
                        ]),
                    })

                    current.telemetry_queue.put_nowait({
                        "probe_id": f"probe-{index}",
                        "timestamp_ms": index,
                    })
                    deadline = time.monotonic() + 2.0
                    while (
                        not current.broker_client.reported
                        and time.monotonic() < deadline
                    ):
                        time.sleep(0.01)
                    payload["reported"] = list(current.broker_client.reported)
                except BaseException as exc:
                    payload["error"] = repr(exc)
                    exit_code = 1
                finally:
                    HyperProbeAgent.shutdown()
                    os.write(write_fd, json.dumps(payload).encode())
                    os.close(write_fd)
                    os._exit(exit_code)

            os.close(write_fd)
            with os.fdopen(read_fd) as child_output:
                payload = json.loads(child_output.read())
            _, status = os.waitpid(child_pid, 0)
            assert os.waitstatus_to_exitcode(status) == 0, payload
            children.append(payload)

        result = {
            "children": children,
            "parent_agent_stopped": HyperProbeAgent._instance is None,
            "parent_object_stopped": agent.is_shutdown,
            "parent_runtime_deferred": parent_runtime_deferred,
            "repeated_start_is_same": repeated_start_is_same,
        }
        print("FORK_RESULT=" + json.dumps(result))
        """
    )

    env = os.environ.copy()
    env.pop("HYPERPROBE_DISABLED", None)
    env.pop("HYPERPROBE_FORK_MODE", None)
    result = subprocess.run(
        [sys.executable, "-c", script],
        cwd=SDK_DIR,
        env=env,
        capture_output=True,
        text=True,
        timeout=30,
    )

    assert result.returncode == 0, result.stdout + result.stderr
    assert result.stdout.count(
        "Python agent started after fork (Version: test-version"
    ) == 2
    result_line = next(
        line for line in result.stdout.splitlines() if line.startswith("FORK_RESULT=")
    )
    fork_result = json.loads(result_line.removeprefix("FORK_RESULT="))

    assert fork_result["parent_agent_stopped"] is True
    assert fork_result["parent_object_stopped"] is True
    assert fork_result["parent_runtime_deferred"] is True
    assert fork_result["repeated_start_is_same"] is True
    assert len(fork_result["children"]) == 2

    child_ids = set()
    for index, child in enumerate(fork_result["children"]):
        assert "error" not in child
        assert child["same_object"] is True
        assert child["owner_pid"] == child["process_pid"]
        assert child["agent_id"] != child["parent_agent_id"]
        assert child["threads_alive"] is True
        assert child["reported"] == [
            {"probe_id": f"probe-{index}", "timestamp_ms": index}
        ]
        child_ids.add(child["agent_id"])

    assert len(child_ids) == 2


@pytest.mark.skipif(
    not hasattr(os, "fork") or not hasattr(os, "register_at_fork"),
    reason="requires POSIX fork handlers",
)
def test_worker_fork_mode_child_start_failure_is_nonfatal():
    script = textwrap.dedent(
        """
        import json
        import os

        import hyperprobe.agent as agent_module


        class FakeBrokerClient:
            def __init__(self, **_kwargs):
                self.agent_version = "test-version"
                self.closed = False

            def shutdown(self):
                self.closed = True

            def get_probes(self):
                return None


        agent_module.BrokerClient = FakeBrokerClient
        HyperProbeAgent = agent_module.HyperProbeAgent
        start_background_loops = HyperProbeAgent._start_background_loops

        def fail_after_start(self):
            start_background_loops(self)
            self._handle_health_change(
                agent_module.AgentHealth.RED,
                "forced startup failure",
            )
            raise RuntimeError("worker startup failed")

        HyperProbeAgent._start_background_loops = fail_after_start
        agent = HyperProbeAgent.start({
            "broker_url": "localhost:60051",
            "service_id": "87c699ba-a5a4-4ca8-927b-e7b33707cf6d",
            "environment": "test",
            "commit_sha": "test-commit",
            "fork_mode": "worker",
        })

        read_fd, write_fd = os.pipe()
        child_pid = os.fork()
        if child_pid == 0:
            os.close(read_fd)
            payload = {
                "application_continued": True,
                "instance_cleared": HyperProbeAgent._instance is None,
                "placeholder_stopped": agent.is_shutdown,
                "broker_closed": agent.broker_client.closed,
                "engine_closed": agent.engine.tool_id is None,
                "cooldown_cleared": agent.cooldown_timer is None,
                "threads_stopped": not any(
                    thread is not None and thread.is_alive()
                    for thread in [
                        agent.sync_thread,
                        agent.flush_thread,
                        agent.stats_thread,
                        agent.safety_monitor.thread,
                    ]
                ),
            }
            os.write(write_fd, json.dumps(payload).encode())
            os.close(write_fd)
            os._exit(0)

        os.close(write_fd)
        with os.fdopen(read_fd) as child_output:
            payload = json.loads(child_output.read())
        _, status = os.waitpid(child_pid, 0)
        assert os.waitstatus_to_exitcode(status) == 0
        print("FORK_FAILURE_RESULT=" + json.dumps(payload))
        """
    )

    env = os.environ.copy()
    env.pop("HYPERPROBE_DISABLED", None)
    env.pop("HYPERPROBE_FORK_MODE", None)
    result = subprocess.run(
        [sys.executable, "-c", script],
        cwd=SDK_DIR,
        env=env,
        capture_output=True,
        text=True,
        timeout=30,
    )

    assert result.returncode == 0, result.stdout + result.stderr
    result_line = next(
        line
        for line in result.stdout.splitlines()
        if line.startswith("FORK_FAILURE_RESULT=")
    )
    fork_result = json.loads(result_line.removeprefix("FORK_FAILURE_RESULT="))
    assert fork_result == {
        "application_continued": True,
        "instance_cleared": True,
        "placeholder_stopped": True,
        "broker_closed": True,
        "engine_closed": True,
        "cooldown_cleared": True,
        "threads_stopped": True,
    }
