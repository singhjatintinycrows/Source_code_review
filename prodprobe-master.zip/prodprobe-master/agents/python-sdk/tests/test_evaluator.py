from hyperprobe.core.evaluator import ProbeEvaluator

def test_evaluate_log_template_basic():
    template = "User {name} has age {age}"
    globals_dict = {}
    locals_dict = {"name": "Arif", "age": 28}
    res = ProbeEvaluator.evaluate_log_template(template, globals_dict, locals_dict)
    assert res == "User Arif has age 28"

def test_evaluate_log_template_node_compatible_placeholder():
    template = "User ${name}"
    res = ProbeEvaluator.evaluate_log_template(template, {}, {"name": "Arif"})
    assert res == "User Arif"

def test_evaluate_log_template_error():
    template = "User {name} has score {score_fails}"
    globals_dict = {}
    locals_dict = {"name": "Arif"}
    res = ProbeEvaluator.evaluate_log_template(template, globals_dict, locals_dict)
    assert "score_fails" in res
    assert "<Error: NameError" in res

def test_evaluate_watches():
    exprs = ["x + y", "z.name", "non_existent"]
    class User:
        name = "Karan"
    locals_dict = {"x": 5, "y": 10, "z": User()}
    res = ProbeEvaluator.evaluate_watches(exprs, {}, locals_dict)
    assert res["x + y"] == 15
    assert res["z.name"] == "Karan"
    assert "NameError" in res["non_existent"]

def test_safe_eval_security():
    locals_dict = {"x": 5}
    
    # Safe operations
    assert ProbeEvaluator.safe_eval("x > 2", {}, locals_dict) is True
    assert ProbeEvaluator.safe_eval("x == 5", {}, locals_dict) is True
    assert ProbeEvaluator.safe_eval("len('test')", {}, locals_dict) == 4
    
    # Unsafe operations (should raise ValueError)
    import pytest
    with pytest.raises(ValueError, match="forbidden"):
        ProbeEvaluator.safe_eval("__import__('os').system('echo pwned')", {}, locals_dict)
        
    with pytest.raises(ValueError, match="forbidden|not allowed"):
        ProbeEvaluator.safe_eval("open('secret.txt', 'r')", {}, locals_dict)
        
    class Mutable:
        def mutate(self):
            self.x = 10
    locals_dict["m"] = Mutable()
    with pytest.raises(ValueError, match="forbidden|not allowed"):
        ProbeEvaluator.safe_eval("m.mutate()", {}, locals_dict)


def test_compiled_expression_cache_is_bounded():
    ProbeEvaluator._compile_safe.cache_clear()
    try:
        for value in range(201):
            ProbeEvaluator.safe_eval(f"x == {value}", {}, {"x": value})

        assert ProbeEvaluator._compile_safe.cache_info().currsize == 200
    finally:
        ProbeEvaluator._compile_safe.cache_clear()


def test_unsafe_eval_allows_function_and_method_calls():
    class Account:
        def __init__(self, balance):
            self.balance = balance
        def get_balance(self):
            return self.balance
        def add(self, amount):
            self.balance += amount
            return self.balance

    account = Account(100)
    locals_dict = {"account": account, "factor": 2}
    import pytest

    # Safe mode (default) blocks custom method calls
    with pytest.raises(ValueError, match="forbidden|not allowed"):
        ProbeEvaluator.safe_eval("account.get_balance()", {}, locals_dict, safe=True)

    # Unsafe mode explicitly allows method calls
    result = ProbeEvaluator.safe_eval("account.get_balance()", {}, locals_dict, safe=False)
    assert result == 100

    # Unsafe mode allows method calls with side-effects / arguments
    mutated = ProbeEvaluator.safe_eval("account.add(50)", {}, locals_dict, safe=False)
    assert mutated == 150
    assert account.balance == 150

    # Unsafe mode allows builtins / arbitrary function calls
    res = ProbeEvaluator.evaluate("sum([1, 2, 3, 4])", {}, locals_dict, safe=False)
    assert res == 10


def test_safe_evaluation_env_var_toggle(monkeypatch):
    class Item:
        def custom_calc(self):
            return 42

    item = Item()
    locals_dict = {"item": item}
    import pytest

    # 1. By default, safe evaluation is True
    monkeypatch.delenv("HYPERPROBE_DISABLE_SAFE_EVALUATION", raising=False)
    assert ProbeEvaluator.is_safe_evaluation_enabled() is True
    with pytest.raises(ValueError, match="forbidden|not allowed"):
        ProbeEvaluator.safe_eval("item.custom_calc()", {}, locals_dict)

    # 2. When HYPERPROBE_DISABLE_SAFE_EVALUATION is explicitly set to true
    for truthy in ["true", "TRUE", "True"]:
        monkeypatch.setenv("HYPERPROBE_DISABLE_SAFE_EVALUATION", truthy)
        assert ProbeEvaluator.is_safe_evaluation_enabled() is False
        assert ProbeEvaluator.safe_eval("item.custom_calc()", {}, locals_dict) == 42

        # Log template in unsafe mode
        log_res = ProbeEvaluator.evaluate_log_template("Item value is {item.custom_calc()}", {}, locals_dict)
        assert log_res == "Item value is 42"

        # Watch expressions in unsafe mode
        watches_res = ProbeEvaluator.evaluate_watches(["item.custom_calc()"], {}, locals_dict)
        assert watches_res["item.custom_calc()"] == 42

    # 3. When HYPERPROBE_DISABLE_SAFE_EVALUATION is not true (e.g. false or unset)
    for non_truthy in ["false", "FALSE", "", "other"]:
        monkeypatch.setenv("HYPERPROBE_DISABLE_SAFE_EVALUATION", non_truthy)
        assert ProbeEvaluator.is_safe_evaluation_enabled() is True
        with pytest.raises(ValueError, match="forbidden|not allowed"):
            ProbeEvaluator.safe_eval("item.custom_calc()", {}, locals_dict)
