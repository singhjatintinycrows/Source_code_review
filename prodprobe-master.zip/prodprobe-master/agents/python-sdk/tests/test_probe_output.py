import io
import inspect
import queue
import threading
import time
from types import SimpleNamespace

from hyperprobe.agent import HyperProbeAgent
from hyperprobe.core.monitoring_engine import MonitoringEngine
from hyperprobe.core.probe_output import (
    ProbeLogWriter,
    format_probe_log,
    normalize_probe_log_level,
    sanitize_probe_log_message,
)
from hyperprobe.core.quota import QuotaManager
from hyperprobe.core.safety import SafetyMonitor
from hyperprobe.protos import agent_pb2


TIMESTAMP_MS = 1_722_165_296_789


class TtyStream(io.StringIO):
    def isatty(self):
        return True


class BlockingStream(io.StringIO):
    def __init__(self):
        super().__init__()
        self.started = threading.Event()
        self.release = threading.Event()

    def write(self, value):
        self.started.set()
        self.release.wait(timeout=2.0)
        return super().write(value)


class BrokenStream:
    def isatty(self):
        return False

    def write(self, _value):
        raise OSError("stream closed")


class PartialStream(io.StringIO):
    def write(self, value):
        super().write(value[:1])
        return 1


class RecordingWriter:
    def __init__(self, result=True, error=None):
        self.calls = []
        self.result = result
        self.error = error

    def submit(self, *record):
        self.calls.append(record)
        if self.error:
            raise self.error
        return self.result


def make_agent(probe, writer, queue_size=2, bandwidth=10_000):
    agent = HyperProbeAgent.__new__(HyperProbeAgent)
    agent._agent_lock = threading.RLock()
    agent.active_probes = {probe.id: probe}
    agent.local_hits = {}
    agent.pending_hits = {}
    agent.telemetry_queue = queue.Queue(maxsize=queue_size)
    agent.quota_manager = QuotaManager(hits_per_sec=10, bytes_per_sec=bandwidth)
    agent.broker_client = SimpleNamespace(estimate_event_size=lambda _event: 100)
    agent.engine = SimpleNamespace(set_probes=lambda _probes: None)
    agent.probe_log_writer = writer
    return agent


def make_log_probe(**overrides):
    values = {
        "id": "probe",
        "type": agent_pb2.PROBE_TYPE_LOG,
        "hit_limit": 1,
        "should_log_to_stdout": True,
    }
    values.update(overrides)
    return agent_pb2.Probe(**values)


def make_event(**overrides):
    event = {
        "probe_id": "probe",
        "timestamp_ms": TIMESTAMP_MS,
        "stack_frames": [],
        "captured_vars_json": "",
        "watch_results_json": "",
        "evaluated_log": "processed request",
        "metric_value": 0.0,
        "capture_error": "",
        "trace_id": None,
    }
    event.update(overrides)
    return event


def test_level_normalization_accepts_only_info_and_error():
    assert normalize_probe_log_level(" info ") == "INFO"
    assert normalize_probe_log_level("error") == "ERROR"
    assert normalize_probe_log_level("") == "INFO"
    assert normalize_probe_log_level("WARN") == "INFO"
    assert normalize_probe_log_level("ERROR\nforged") == "INFO"
    assert normalize_probe_log_level(None) == "INFO"


def test_plain_format_matches_node_layout_without_ansi():
    output = format_probe_log(TIMESTAMP_MS, "INFO", "processed", use_color=False)

    assert output == (
        "[2024-07-28T11:14:56.789Z] [INFO] "
        "[HyperProbe LOG] processed\n"
    )
    assert "\x1b" not in output


def test_tty_format_uses_node_color_codes():
    output = format_probe_log(TIMESTAMP_MS, "ERROR", "failed", use_color=True)

    assert output.startswith("\x1b[90m[2024-07-28T11:14:56.789Z]\x1b[0m ")
    assert "\x1b[1m\x1b[31m[ERROR]\x1b[0m " in output
    assert "\x1b[1m\x1b[35m[HyperProbe LOG]\x1b[0m " in output
    assert output.endswith("failed\n")


def test_message_controls_are_escaped_to_one_physical_line():
    sanitized = sanitize_probe_log_message(
        "first\nsecond\r\t\x1b[31m\x07\u2028\u202eend"
    )

    assert sanitized == (
        r"first\nsecond\r\t\x1b[31m\x07\u2028\u202eend"
    )
    assert "\n" not in sanitized
    assert "\x1b" not in sanitized


def test_writer_routes_info_to_stdout_and_error_to_stderr():
    stdout = io.StringIO()
    stderr = io.StringIO()
    writer = ProbeLogWriter(4, stdout=stdout, stderr=stderr)
    writer.start()

    assert writer.submit(TIMESTAMP_MS, "INFO", "info message") is True
    assert writer.submit(TIMESTAMP_MS, "ERROR", "error message") is True
    writer.stop()

    assert "[INFO] [HyperProbe LOG] info message" in stdout.getvalue()
    assert "[ERROR] [HyperProbe LOG] error message" in stderr.getvalue()
    assert "error message" not in stdout.getvalue()
    assert "info message" not in stderr.getvalue()


def test_writer_starts_lazily_and_retires_when_queue_is_empty():
    stdout = io.StringIO()
    writer = ProbeLogWriter(1, stdout=stdout)
    assert writer.is_running() is False

    assert writer.submit(TIMESTAMP_MS, "INFO", "first") is True
    deadline = time.monotonic() + 1.0
    while writer.is_running() and time.monotonic() < deadline:
        time.sleep(0.001)

    assert writer.is_running() is False
    assert "first" in stdout.getvalue()

    assert writer.submit(TIMESTAMP_MS, "INFO", "second") is True
    writer.stop()
    assert "second" in stdout.getvalue()


def test_writer_colors_only_tty_streams():
    stdout = TtyStream()
    stderr = io.StringIO()
    writer = ProbeLogWriter(2, stdout=stdout, stderr=stderr)
    writer.start()

    writer.submit(TIMESTAMP_MS, "INFO", "colored")
    writer.submit(TIMESTAMP_MS, "ERROR", "plain")
    writer.stop()

    assert "\x1b[32m" in stdout.getvalue()
    assert "\x1b" not in stderr.getvalue()


def test_writer_isolates_stream_errors_and_partial_writes():
    broken_writer = ProbeLogWriter(1, stdout=BrokenStream())
    broken_writer.start()
    broken_writer.submit(TIMESTAMP_MS, "INFO", "broken")
    broken_writer.stop()

    partial_writer = ProbeLogWriter(1, stdout=PartialStream())
    partial_writer.start()
    partial_writer.submit(TIMESTAMP_MS, "INFO", "partial")
    partial_writer.stop()

    assert broken_writer.error_count == 1
    assert partial_writer.error_count == 1


def test_blocked_stream_drops_excess_records_without_blocking_submitter():
    stream = BlockingStream()
    writer = ProbeLogWriter(1, stdout=stream)
    writer.start()
    assert writer.submit(TIMESTAMP_MS, "INFO", "first") is True
    assert stream.started.wait(timeout=1.0)
    assert writer.submit(TIMESTAMP_MS, "INFO", "second") is True

    started = time.perf_counter()
    assert writer.submit(TIMESTAMP_MS, "INFO", "third") is False
    elapsed = time.perf_counter() - started

    assert elapsed < 0.1
    assert writer.dropped_count == 1
    stream.release.set()
    writer.stop()


def test_blocked_stream_does_not_block_shutdown():
    stream = BlockingStream()
    writer = ProbeLogWriter(1, stdout=stream)
    writer.start()
    writer.submit(TIMESTAMP_MS, "INFO", "blocked")
    assert stream.started.wait(timeout=1.0)

    started = time.perf_counter()
    writer.stop(timeout=0.01)
    elapsed = time.perf_counter() - started

    assert elapsed < 0.1
    stream.release.set()
    writer.stop()


def test_successful_admission_commits_hit_then_submits_local_output():
    writer = RecordingWriter()
    probe = make_log_probe(log_level="ERROR")
    agent = make_agent(probe, writer)

    agent._handle_capture(make_event())

    assert agent.local_hits == {"probe": 1}
    assert agent.telemetry_queue.qsize() == 1
    assert "probe" not in agent.active_probes
    assert writer.calls == [(TIMESTAMP_MS, "ERROR", "processed request")]


def test_none_event_timestamp_uses_capture_time(monkeypatch):
    monkeypatch.setattr("hyperprobe.agent.time.time", lambda: 1_700_000_000.123)
    writer = RecordingWriter()
    probe = make_log_probe()
    agent = make_agent(probe, writer)

    agent._handle_capture(make_event(timestamp_ms=None))

    assert writer.calls == [(1_700_000_000_123, "", "processed request")]


def test_bandwidth_and_telemetry_queue_rejection_do_not_emit_locally():
    writer = RecordingWriter()
    probe = make_log_probe()
    bandwidth_agent = make_agent(probe, writer, bandwidth=1)
    bandwidth_agent._handle_capture(make_event())

    full_queue_agent = make_agent(probe, writer, queue_size=1)
    full_queue_agent.telemetry_queue.put("existing")
    full_queue_agent._handle_capture(make_event())

    assert writer.calls == []
    assert bandwidth_agent.local_hits == {}
    assert full_queue_agent.local_hits == {}


def test_output_rejection_does_not_undo_telemetry_admission():
    probe = make_log_probe()
    agent = make_agent(probe, RecordingWriter(result=False))

    agent._handle_capture(make_event())

    assert agent.local_hits == {"probe": 1}
    assert agent.telemetry_queue.qsize() == 1
    assert "probe" not in agent.active_probes


def test_output_failure_is_logged_without_undoing_admission(monkeypatch):
    errors = []
    monkeypatch.setattr("hyperprobe.agent.logger.error", errors.append)
    probe = make_log_probe()
    agent = make_agent(
        probe,
        RecordingWriter(error=OSError("stdout unavailable")),
    )

    agent._handle_capture(make_event())

    assert agent.local_hits == {"probe": 1}
    assert agent.telemetry_queue.qsize() == 1
    assert "probe" not in agent.active_probes
    assert errors == [
        "[HyperProbe] Failed to queue local output for probe probe: "
        "stdout unavailable"
    ]


def test_disabled_non_log_and_failed_capture_events_do_not_emit_locally():
    writer = RecordingWriter()
    disabled_probe = make_log_probe(should_log_to_stdout=False)
    make_agent(disabled_probe, writer)._handle_capture(make_event())

    snapshot_probe = agent_pb2.Probe(
        id="probe",
        type=agent_pb2.PROBE_TYPE_SNAPSHOT,
        hit_limit=1,
        should_log_to_stdout=True,
    )
    make_agent(snapshot_probe, writer)._handle_capture(make_event())

    failed_probe = make_log_probe()
    make_agent(failed_probe, writer)._handle_capture(
        make_event(capture_error="evaluation failed", evaluated_log="")
    )

    assert writer.calls == []


def test_log_values_are_redacted_before_truncation():
    captured = []
    engine = MonitoringEngine(
        QuotaManager(hits_per_sec=10, bytes_per_sec=10_000),
        SafetyMonitor(lambda *_: None),
        captured.append,
    )
    engine.set_global_config(
        {
            "max_object_depth": 3,
            "max_array_length": 3,
            "max_object_properties": 50,
            "max_string_length": 12,
            "stack_frame_depth": 3,
            "redact_keys": [],
            "redact_values": ["supersecret"],
        }
    )
    probe = agent_pb2.Probe(
        id="probe",
        type=agent_pb2.PROBE_TYPE_LOG,
        hit_limit=1,
        template="value={secret}",
    )
    secret = "supersecret"

    try:
        engine._handle_probe_hit(probe, inspect.currentframe())
    finally:
        engine.close()

    assert len(captured) == 1
    assert "supersecret" not in captured[0]["evaluated_log"]
    assert "value=[REDAC" in captured[0]["evaluated_log"]
