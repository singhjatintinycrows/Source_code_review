import pytest

from hyperprobe.core.safety import AgentHealth, SafetyMonitor


def test_ordinary_lag_window_transitions_to_yellow_and_red():
    changes = []
    monitor = SafetyMonitor(
        lambda health, reason: changes.append((health, reason)),
        max_lag_ms=50.0,
    )

    for _ in range(3):
        monitor._check_health(51.0)

    assert monitor.get_health() == AgentHealth.GREEN

    monitor._check_health(51.0)

    assert monitor.get_health() == AgentHealth.YELLOW
    assert changes[-1][0] == AgentHealth.YELLOW
    assert "4/10" in changes[-1][1]

    for _ in range(3):
        monitor._check_health(51.0)

    assert monitor.get_health() == AgentHealth.RED
    assert changes[-1][0] == AgentHealth.RED
    assert "7/10" in changes[-1][1]


def test_severe_lag_requires_three_of_five_readings_for_red():
    changes = []
    monitor = SafetyMonitor(
        lambda health, reason: changes.append((health, reason)),
        max_lag_ms=50.0,
    )

    monitor._check_health(5000.0)

    assert monitor.get_health() == AgentHealth.YELLOW
    assert changes[-1][0] == AgentHealth.YELLOW
    assert "1/5" in changes[-1][1]

    monitor._check_health(0.0)
    monitor._check_health(500.0)

    assert monitor.get_health() == AgentHealth.YELLOW

    monitor._check_health(500.0)

    assert monitor.get_health() == AgentHealth.RED
    assert changes[-1][0] == AgentHealth.RED
    assert "3/5" in changes[-1][1]


def test_ordinary_lag_window_recovers_as_breaches_are_evicted():
    changes = []
    monitor = SafetyMonitor(
        lambda health, reason: changes.append((health, reason)),
        max_lag_ms=50.0,
    )

    for _ in range(7):
        monitor._check_health(51.0)

    assert monitor.get_health() == AgentHealth.RED

    for _ in range(4):
        monitor._check_health(0.0)

    assert monitor.get_health() == AgentHealth.YELLOW

    for _ in range(3):
        monitor._check_health(0.0)

    assert monitor.get_health() == AgentHealth.GREEN
    assert [health for health, _ in changes] == [
        AgentHealth.YELLOW,
        AgentHealth.RED,
        AgentHealth.YELLOW,
        AgentHealth.GREEN,
    ]


def test_severe_lag_window_recovers_after_five_healthy_readings():
    monitor = SafetyMonitor(lambda *_: None, max_lag_ms=50.0)

    for _ in range(3):
        monitor._check_health(500.0)

    assert monitor.get_health() == AgentHealth.RED

    for _ in range(3):
        monitor._check_health(0.0)

    assert monitor.get_health() == AgentHealth.YELLOW

    for _ in range(2):
        monitor._check_health(0.0)

    assert monitor.get_health() == AgentHealth.GREEN


def test_pause_budget_remains_an_independent_red_signal():
    changes = []
    monitor = SafetyMonitor(
        lambda health, reason: changes.append((health, reason)),
        pause_budget_ms=10.0,
    )

    monitor.report_pause_duration(11.0)

    assert monitor.get_health() == AgentHealth.RED
    assert changes[-1][0] == AgentHealth.RED
    assert "Cumulative Pause Budget" in changes[-1][1]


def test_run_loop_measures_only_wait_overshoot(monkeypatch):
    class FakeStopEvent:
        def __init__(self):
            self.wait_count = 0

        def wait(self, _timeout):
            self.wait_count += 1
            return self.wait_count == 3

    monitor = SafetyMonitor(lambda *_: None)
    monitor.stop_event = FakeStopEvent()
    monitor.is_running = True

    timestamps = iter([
        10.0,
        10.1,
        10.5,
        10.6,
        10.9,
    ])
    monkeypatch.setattr(
        "hyperprobe.core.safety.time.monotonic",
        lambda: next(timestamps),
    )

    monitor._run_loop()

    assert list(monitor.thread_lag_samples) == [
        pytest.approx(0.0),
        pytest.approx(0.0),
    ]
