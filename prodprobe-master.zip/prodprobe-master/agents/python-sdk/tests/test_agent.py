from hyperprobe.agent import HyperProbeAgent as HyperProbe
from hyperprobe.core.quota import QuotaManager
from hyperprobe.core.safety import SafetyMonitor, AgentHealth

def test_quota_manager_basic():
    qm = QuotaManager(hits_per_sec=2, bytes_per_sec=100)
    assert qm.can_evaluate() is True
    assert qm.can_evaluate() is True
    assert qm.can_evaluate() is False # Rate limited


def test_quota_reservation_release_is_idempotent():
    qm = QuotaManager(hits_per_sec=2, bytes_per_sec=100)
    qm.bandwidth_bucket.refill_rate = 0

    reservation = qm.reserve_bandwidth(100)
    assert reservation is not None
    reservation.release()
    reservation.release()

    assert qm.bandwidth_bucket.tokens == 100


def test_safety_monitor_state_change():
    changes = []
    def on_change(health, reason):
        changes.append((health, reason))

    sm = SafetyMonitor(on_change, max_lag_ms=10.0, pause_budget_ms=10.0)
    # Exceed pause budget
    sm.report_pause_duration(15.0)
    assert sm.get_health() == AgentHealth.RED
    assert len(changes) == 1
    assert changes[0][0] == AgentHealth.RED

def test_suspension_recovery():
    options = {
        "broker_url": "localhost:60051",
        "service_id": "87c699ba-a5a4-4ca8-927b-e7b33707cf6d",
        "environment": "test",
        "commit_sha": "test-commit"
    }
    agent = HyperProbe(options)
    
    class MockProbe:
        id = "test-probe"
        runtime_location = "test.py"
        runtime_line = 10
        hit_limit = 10
        
    agent.active_probes["test-probe"] = MockProbe()
    agent.engine.set_probes([agent.active_probes["test-probe"]])
    
    # Verify we can trigger RED health change
    agent._handle_health_change(AgentHealth.RED, "Test Trigger")
    
    # The desired probe set remains configured while instrumentation is suspended.
    assert len(agent.engine.active_probes) == 1
    assert agent.engine.is_suspended is True
    assert agent.engine.is_active is False
    
    # Check that agent's cache of probes is untouched
    assert len(agent.active_probes) == 1
    
    # Simulate the cooldown timer expiring before triggering recovery directly.
    with agent._agent_lock:
        cooldown_timer = agent.cooldown_timer
        agent.cooldown_timer = None
    cooldown_timer.cancel()
    agent._resume_instrumentation()
    
    # Check that the probe is restored into the engine's active list
    assert len(agent.engine.active_probes) == 1
    assert agent.engine.is_suspended is False
    agent._stop()


def test_red_restarts_cooldown_timer(monkeypatch):
    class FakeTimer:
        def __init__(self, _interval, _callback):
            self.cancelled = False
            self.daemon = False

        def start(self):
            pass

        def cancel(self):
            self.cancelled = True

    monkeypatch.setattr("hyperprobe.agent.threading.Timer", FakeTimer)
    agent = HyperProbe({
        "broker_url": "localhost:60051",
        "service_id": "87c699ba-a5a4-4ca8-927b-e7b33707cf6d",
        "environment": "test",
        "commit_sha": "test-commit",
    })

    agent._handle_health_change(AgentHealth.RED, "First Trigger")
    first_timer = agent.cooldown_timer
    agent._handle_health_change(AgentHealth.RED, "Second Trigger")

    assert first_timer.cancelled is True
    assert agent.cooldown_timer is not first_timer
    agent._stop()


def test_stale_cooldown_timer_cannot_end_newer_cooldown(monkeypatch):
    class FakeTimer:
        def __init__(self, _interval, callback):
            self.callback = callback
            self.cancelled = False
            self.daemon = False

        def start(self):
            pass

        def cancel(self):
            self.cancelled = True

    monkeypatch.setattr("hyperprobe.agent.threading.Timer", FakeTimer)
    agent = HyperProbe({
        "broker_url": "localhost:60051",
        "service_id": "87c699ba-a5a4-4ca8-927b-e7b33707cf6d",
        "environment": "test",
        "commit_sha": "test-commit",
    })

    agent._handle_health_change(AgentHealth.RED, "First Trigger")
    first_timer = agent.cooldown_timer
    agent._handle_health_change(AgentHealth.RED, "Second Trigger")
    second_timer = agent.cooldown_timer

    # Timer.cancel() cannot stop a callback that has already been dispatched.
    first_timer.callback()

    assert agent.cooldown_timer is second_timer
    assert agent.engine.is_suspended is True

    second_timer.callback()

    assert agent.cooldown_timer is None
    assert agent.engine.is_suspended is False
    agent._stop()


def test_agent_stats_and_retain_failed_batch():
    options = {
        "broker_url": "localhost:60051",
        "service_id": "87c699ba-a5a4-4ca8-927b-e7b33707cf6d",
        "environment": "test",
        "commit_sha": "test-commit"
    }
    
    agent = HyperProbe(options)
    
    stats = agent.engine.get_stats()
    assert stats["hits"] == 0
    assert stats["skips"] == 0
    
    # Force mock a skip
    agent.quota_manager.can_evaluate = lambda: False
    class MockProbe:
        id = "test-probe"
    agent.engine._handle_probe_hit(MockProbe(), None)
    
    stats = agent.engine.get_stats()
    assert stats["skips"] == 1
    assert stats["hits"] == 0
    
    def mock_report_telemetry(batch):
        raise Exception("Mock Network Error")
    
    agent.broker_client.report_telemetry = mock_report_telemetry
    
    event = {"probe_id": "test-probe"}
    agent.telemetry_queue.put(event)
    assert agent.telemetry_queue.qsize() == 1
    
    agent._flush_telemetry()

    assert agent.telemetry_queue.empty()
    assert len(agent._inflight_batch) == 1
    assert agent._inflight_batch[0].event == event
    agent._stop()


def test_agent_safe_evaluation_disabled_logging(monkeypatch, capsys):
    monkeypatch.setenv("HYPERPROBE_DISABLE_SAFE_EVALUATION", "true")
    options = {
        "broker_url": "localhost:60051",
        "service_id": "87c699ba-a5a4-4ca8-927b-e7b33707cf6d",
        "environment": "test",
        "commit_sha": "test-commit"
    }

    agent = HyperProbe(options)
    captured = capsys.readouterr()
    assert "Safe evaluation is DISABLED via HYPERPROBE_DISABLE_SAFE_EVALUATION" in captured.out
    assert agent.global_config["disable_safe_evaluation"] is True
    assert agent.engine.safe_evaluation is False
    agent._stop()


def test_agent_safe_evaluation_options_string_handling(monkeypatch, capsys):
    monkeypatch.delenv("HYPERPROBE_DISABLE_SAFE_EVALUATION", raising=False)
    base_options = {
        "broker_url": "localhost:60051",
        "service_id": "87c699ba-a5a4-4ca8-927b-e7b33707cf6d",
        "environment": "test",
        "commit_sha": "test-commit"
    }

    # "false" string must not disable safe evaluation
    agent_false = HyperProbe({**base_options, "disable_safe_evaluation": "false"})
    assert agent_false.global_config["disable_safe_evaluation"] is False
    assert agent_false.engine.safe_evaluation is True
    agent_false._stop()

    # "true" string must disable safe evaluation
    agent_true = HyperProbe({**base_options, "disable_safe_evaluation": "true"})
    assert agent_true.global_config["disable_safe_evaluation"] is True
    assert agent_true.engine.safe_evaluation is False
    agent_true._stop()
