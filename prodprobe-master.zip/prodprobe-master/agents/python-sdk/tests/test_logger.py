from hyperprobe.core.logger import HyperProbeLogger, is_namespace_enabled


def test_namespace_selectors_support_wildcards_and_multiple_delimiters():
    assert is_namespace_enabled(
        "hyperprobe:broker", "hyperprobe:agent, hyperprobe:broker"
    )
    assert is_namespace_enabled("hyperprobe:broker", "hyperprobe:bro*")
    assert is_namespace_enabled("hyperprobe:broker", "hyperprobe:agent hyperprobe:broker")
    assert not is_namespace_enabled("hyperprobe:monitor", "hyperprobe:broker")


def test_exclusions_override_inclusions():
    selectors = "hyperprobe:*,-hyperprobe:telemetry"
    assert is_namespace_enabled("hyperprobe:broker", selectors)
    assert not is_namespace_enabled("hyperprobe:telemetry", selectors)


def test_bare_selector_is_exact_and_wildcards_match_components():
    assert is_namespace_enabled("hyperprobe", "hyperprobe")
    assert not is_namespace_enabled("hyperprobe:agent", "hyperprobe")
    assert is_namespace_enabled("hyperprobe:agent", "hyperprobe*")
    assert is_namespace_enabled("hyperprobe:agent", "hyperprobe:*")
    assert not is_namespace_enabled("other:agent", "hyperprobe")


def test_logger_snapshots_its_debug_selection(monkeypatch):
    monkeypatch.setenv("DEBUG", "hyperprobe:broker")
    enabled = HyperProbeLogger("hyperprobe:broker")
    disabled = HyperProbeLogger("hyperprobe:monitor")

    assert enabled.enabled is True
    assert disabled.enabled is False


def test_debug_output_is_colored_when_forced(monkeypatch, capsys):
    monkeypatch.setenv("DEBUG", "hyperprobe:broker")
    monkeypatch.setenv("DEBUG_COLORS", "1")
    logger = HyperProbeLogger("hyperprobe:broker")

    logger.info("connected")

    output = capsys.readouterr().out
    assert "\033[" in output
    assert "hyperprobe:broker" in output
    assert "connected" in output


def test_debug_colors_can_be_disabled(monkeypatch, capsys):
    monkeypatch.setenv("DEBUG", "hyperprobe:broker")
    monkeypatch.setenv("DEBUG_COLORS", "0")
    logger = HyperProbeLogger("hyperprobe:broker")

    logger.info("connected")

    assert capsys.readouterr().out == "hyperprobe:broker connected\n"


def test_force_methods_bypass_debug_gate(monkeypatch, capsys):
    monkeypatch.delenv("DEBUG", raising=False)
    logger = HyperProbeLogger("hyperprobe:agent")

    logger.info("hidden")
    logger.forceInfo("always shown")
    logger.forceError("always an error")

    captured = capsys.readouterr()
    assert captured.out == "always shown\n"
    assert captured.err == "always an error\n"
