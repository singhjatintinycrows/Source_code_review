import inspect
import math
import threading
import time
from types import SimpleNamespace

import pytest

from hyperprobe.core.broker import BrokerClient
from hyperprobe.core.monitoring_engine import MonitoringEngine
from hyperprobe.protos import agent_pb2


class FakeQuotaManager:
    def __init__(self, allow_evaluate=True):
        self.allow_evaluate = allow_evaluate
        self.evaluation_calls = 0

    def can_evaluate(self):
        self.evaluation_calls += 1
        return self.allow_evaluate

class FakeSafetyMonitor:
    def __init__(self):
        self.pause_durations = []

    def report_pause_duration(self, duration_ms):
        self.pause_durations.append(duration_ms)


def make_probe(probe_type, probe_id="probe", **overrides):
    values = {
        "id": probe_id,
        "type": probe_type,
        "runtime_location": __file__,
        "runtime_line": 999_999,
        "hit_limit": 100,
        "expiry_time": int(time.time() * 1000) + 60_000,
    }
    values.update(overrides)
    return agent_pb2.Probe(**values)


def make_frame(**local_values):
    return SimpleNamespace(f_globals={}, f_locals=local_values)


@pytest.fixture
def engine_harness():
    events = []
    quota = FakeQuotaManager()
    safety = FakeSafetyMonitor()
    engine = MonitoringEngine(quota, safety, events.append)
    engine.set_global_config({})
    yield engine, events, quota, safety
    engine.close()


def test_counter_emits_node_compatible_payload_with_trace_id(engine_harness):
    engine, events, quota, safety = engine_harness
    engine.custom_set_trace_id = lambda: "trace-123"
    probe = make_probe(
        agent_pb2.PROBE_TYPE_COUNTER,
        condition="enabled",
        should_capture_trace_id=True,
    )

    engine._handle_probe_hit(probe, make_frame(enabled=True))

    assert len(events) == 1
    assert events[0] == {
        "probe_id": "probe",
        "timestamp_ms": events[0]["timestamp_ms"],
        "stack_frames": [],
        "captured_vars_json": "",
        "watch_results_json": "",
        "evaluated_log": "",
        "metric_value": 1.0,
        "capture_error": "",
        "trace_id": "trace-123",
    }
    assert quota.evaluation_calls == 1
    assert len(safety.pause_durations) == 1


def test_false_condition_does_not_consume_quota_or_emit(engine_harness):
    engine, events, quota, _ = engine_harness
    probe = make_probe(agent_pb2.PROBE_TYPE_COUNTER, condition="enabled")

    engine._handle_probe_hit(probe, make_frame(enabled=False))

    assert events == []
    assert quota.evaluation_calls == 0


@pytest.mark.parametrize(
    ("raw_value", "expected"),
    [
        (12.5, 12.5),
        ("  -12.5ms", -12.5),
        ("1e2 remainder", 100.0),
        ("0x10", 0.0),
    ],
)
def test_metric_accepts_node_parse_float_values(engine_harness, raw_value, expected):
    engine, events, _, _ = engine_harness
    probe = make_probe(
        agent_pb2.PROBE_TYPE_METRIC,
        metric_expression="metric_result",
    )

    engine._handle_probe_hit(probe, make_frame(metric_result=raw_value))

    assert events[-1]["metric_value"] == expected
    assert events[-1]["capture_error"] == ""


@pytest.mark.parametrize("raw_value", [True, "not-a-number", math.nan, math.inf, {}])
def test_metric_reports_non_finite_or_non_numeric_results(engine_harness, raw_value):
    engine, events, _, _ = engine_harness
    probe = make_probe(
        agent_pb2.PROBE_TYPE_METRIC,
        metric_expression="metric_result",
    )

    engine._handle_probe_hit(probe, make_frame(metric_result=raw_value))

    assert events[-1]["metric_value"] == 0.0
    assert events[-1]["capture_error"].startswith("Metric evaluation failed:")


def test_metric_expression_error_is_exported_without_consuming_eval_quota(
    engine_harness,
):
    engine, events, quota, _ = engine_harness
    probe = make_probe(
        agent_pb2.PROBE_TYPE_METRIC,
        metric_expression="missing_value",
    )

    engine._handle_probe_hit(probe, make_frame())

    assert "missing_value" in events[0]["capture_error"]
    assert quota.evaluation_calls == 0


def test_metric_probes_enforce_evaluation_quota(engine_harness):
    engine, events, quota, _ = engine_harness
    probe = make_probe(agent_pb2.PROBE_TYPE_COUNTER)

    quota.allow_evaluate = False
    engine._handle_probe_hit(probe, make_frame())
    assert events == []
    assert engine.get_stats() == {"hits": 0, "skips": 1}

    quota.allow_evaluate = True
    engine._handle_probe_hit(probe, make_frame())
    assert len(events) == 1
    assert engine.get_stats() == {"hits": 1, "skips": 0}


def test_duration_pairs_correlated_start_and_end_in_milliseconds(
    engine_harness, monkeypatch
):
    engine, events, quota, _ = engine_harness
    probe = make_probe(
        agent_pb2.PROBE_TYPE_DURATION,
        correlation_expression="request_id",
    )
    clock = iter([0.0, 1.0, 2.0, 3.0, 11.0, 12.0])
    monkeypatch.setattr(
        "hyperprobe.core.monitoring_engine.time.perf_counter", lambda: next(clock)
    )

    frame = make_frame(request_id="request-1")
    engine._handle_probe_hit(probe, frame, is_secondary=False)
    engine._handle_probe_hit(probe, frame, is_secondary=True)

    assert len(events) == 1
    assert events[0]["metric_value"] == 10_000.0
    assert events[0]["capture_error"] == ""
    assert len(engine.duration_starts) == 0
    assert quota.evaluation_calls == 1


def test_unmatched_duration_end_is_silent_and_free(engine_harness):
    engine, events, quota, _ = engine_harness
    probe = make_probe(
        agent_pb2.PROBE_TYPE_DURATION,
        correlation_expression="request_id",
    )

    engine._handle_probe_hit(
        probe, make_frame(request_id="missing"), is_secondary=True
    )

    assert events == []
    assert quota.evaluation_calls == 0


def test_duration_without_correlation_uses_singleton_and_restarts(
    engine_harness, monkeypatch
):
    engine, events, quota, _ = engine_harness
    probe = make_probe(agent_pb2.PROBE_TYPE_DURATION)
    clock = iter(float(value) for value in range(9))
    monkeypatch.setattr(
        "hyperprobe.core.monitoring_engine.time.perf_counter", lambda: next(clock)
    )

    frame = make_frame()
    engine._handle_probe_hit(probe, frame, is_secondary=False)
    engine._handle_probe_hit(probe, frame, is_secondary=False)
    assert len(engine.duration_starts) == 1
    engine._handle_probe_hit(probe, frame, is_secondary=True)

    assert events[0]["metric_value"] == 3_000.0
    assert quota.evaluation_calls == 1
    assert len(engine.duration_starts) == 0


@pytest.mark.parametrize(
    ("correlation", "expected_error"),
    [
        (True, "got boolean"),
        ({"request": 1}, "got object"),
        ("Error: application value", "Error: application value"),
    ],
)
def test_duration_rejects_invalid_correlation_values(
    engine_harness, correlation, expected_error
):
    engine, events, quota, _ = engine_harness
    probe = make_probe(
        agent_pb2.PROBE_TYPE_DURATION,
        correlation_expression="correlation",
    )

    engine._handle_probe_hit(
        probe, make_frame(correlation=correlation), is_secondary=False
    )

    assert expected_error in events[0]["capture_error"]
    assert len(engine.duration_starts) == 0
    assert quota.evaluation_calls == 0


def test_duration_state_is_normalized_and_expired(engine_harness):
    engine, _, _, _ = engine_harness
    keys = [engine._normalize_correlation_key(f"request-{i}") for i in range(3)]
    assert engine._normalize_correlation_key("1") == engine._normalize_correlation_key(1)
    assert engine._normalize_correlation_key(1) == engine._normalize_correlation_key(1.0)

    for key in keys:
        engine._start_duration("duration-probe", key)

    assert len(engine.duration_starts) == 3
    assert ("duration-probe", keys[0]) in engine.duration_starts

    for duration_key, (started_at, _) in list(engine.duration_starts.items()):
        engine.duration_starts[duration_key] = (started_at, 0.0)
    engine._next_duration_cleanup = 0.0
    with engine.lock:
        engine._cleanup_durations_locked(engine.DURATION_TTL_SECONDS + 1.0)
    assert len(engine.duration_starts) == 0

    duration_probe = make_probe(
        agent_pb2.PROBE_TYPE_DURATION,
        probe_id="duration-probe",
        secondary_runtime_line=999_998,
    )
    engine.set_probes([duration_probe])
    assert len(engine.secondary_duration_probes) == 1
    engine.set_probes([])
    assert engine.secondary_duration_probes == {}


def test_duration_indexes_a_secondary_location_in_another_file(
    engine_harness, tmp_path
):
    engine, _, _, _ = engine_harness
    primary_path = tmp_path / "primary.py"
    secondary_path = tmp_path / "secondary.py"
    probe = make_probe(
        agent_pb2.PROBE_TYPE_DURATION,
        probe_id="cross-file-duration",
        runtime_location=str(primary_path),
        runtime_line=10,
        secondary_runtime_location=str(secondary_path),
        secondary_runtime_line=20,
    )

    engine.set_probes([probe])

    assert (str(primary_path), 10) in engine.active_probes
    assert (str(secondary_path), 20) in engine.secondary_duration_probes
    assert str(primary_path) in engine.instrumented_files
    assert str(secondary_path) in engine.instrumented_files


def _instrumented_target(value, correlation, delay):
    metric_value = value * 2
    duration_start_marker = metric_value
    counter_marker = duration_start_marker + 1
    if delay:
        time.sleep(delay)
    duration_end_marker = counter_marker
    return duration_end_marker, correlation


def _source_line_containing(function, text):
    lines, first_line = inspect.getsourcelines(function)
    return first_line + next(index for index, line in enumerate(lines) if text in line)


def test_sys_monitoring_integration_for_counter_metric_and_concurrent_duration():
    events = []
    quota = FakeQuotaManager()
    safety = FakeSafetyMonitor()
    engine = MonitoringEngine(quota, safety, events.append)
    target_path = inspect.getsourcefile(_instrumented_target)
    metric_line = _source_line_containing(_instrumented_target, "counter_marker =")
    duration_start_line = _source_line_containing(
        _instrumented_target, "duration_start_marker ="
    )
    duration_end_line = _source_line_containing(
        _instrumented_target, "duration_end_marker ="
    )
    probes = [
        make_probe(
            agent_pb2.PROBE_TYPE_COUNTER,
            probe_id="counter",
            runtime_location=target_path,
            runtime_line=metric_line,
        ),
        make_probe(
            agent_pb2.PROBE_TYPE_METRIC,
            probe_id="metric",
            runtime_location=target_path,
            runtime_line=metric_line,
            metric_expression="metric_value",
        ),
        make_probe(
            agent_pb2.PROBE_TYPE_DURATION,
            probe_id="duration",
            runtime_location=target_path,
            runtime_line=duration_start_line,
            secondary_runtime_location=target_path,
            secondary_runtime_line=duration_end_line,
            correlation_expression="correlation",
        ),
    ]

    try:
        engine.set_probes(probes)
        threads = [
            threading.Thread(
                target=_instrumented_target,
                args=(index + 1, f"request-{index}", 0.005),
            )
            for index in range(4)
        ]
        for thread in threads:
            thread.start()
        for thread in threads:
            thread.join()
    finally:
        engine.close()

    counter_events = [event for event in events if event["probe_id"] == "counter"]
    metric_events = [event for event in events if event["probe_id"] == "metric"]
    duration_events = [event for event in events if event["probe_id"] == "duration"]
    assert len(counter_events) == 4
    assert {event["metric_value"] for event in counter_events} == {1.0}
    assert len(metric_events) == 4
    assert {event["metric_value"] for event in metric_events} == {
        2.0,
        4.0,
        6.0,
        8.0,
    }
    assert len(duration_events) == 4
    assert all(event["metric_value"] >= 1.0 for event in duration_events)
    assert len(engine.duration_starts) == 0


def test_broker_serializes_metric_event_without_payload_translation():
    captured = {}

    class Stub:
        def ReportTelemetry(self, batch, **_kwargs):
            captured["batch"] = batch
            return SimpleNamespace(finished_probe_ids=["counter"])

    client = object.__new__(BrokerClient)
    client.agent_id = "python-agent"
    client.stub = Stub()
    client.rpc_timeout_sec = 1.0
    client.metadata = (("x-hp-service-id", "service"),)
    event = {
        "probe_id": "counter",
        "timestamp_ms": 123,
        "stack_frames": [],
        "captured_vars_json": "",
        "watch_results_json": "",
        "evaluated_log": "",
        "metric_value": 1.0,
        "capture_error": "",
        "trace_id": "trace-123",
    }

    finished = client.report_telemetry([event])

    assert finished == ["counter"]
    proto_event = captured["batch"].events[0]
    assert proto_event.probe_id == "counter"
    assert proto_event.metric_value == 1.0
    assert proto_event.trace_id == "trace-123"
    assert proto_event.stack_frames == []
    assert proto_event.captured_vars_json == ""
    assert proto_event.watch_results_json == ""
    assert proto_event.evaluated_log == ""
    assert proto_event.capture_error == ""


def test_monitoring_engine_unsafe_evaluation_allows_methods(engine_harness):
    engine, events, quota, safety = engine_harness
    engine.set_global_config({"disable_safe_evaluation": True})

    class CustomService:
        def compute_metric(self):
            return 88.5
        def is_valid(self):
            return True

    probe = make_probe(
        agent_pb2.PROBE_TYPE_METRIC,
        condition="service.is_valid()",
        metric_expression="service.compute_metric()",
    )
    engine.set_probes([probe])

    frame = SimpleNamespace(
        f_globals={"service": CustomService()},
        f_locals={},
    )

    engine._handle_metric_probe_hit(probe, frame, is_secondary=False)

    assert len(events) == 1
    assert events[0]["metric_value"] == 88.5
    assert events[0]["capture_error"] == ""
