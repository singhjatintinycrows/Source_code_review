class CheckoutService:
    @staticmethod
    def process_checkout(user_id, items):
        cart_total = 0.0

        user_session = {
            "id": user_id,
            "authenticated": True,
            "flags": ["premium", "beta-tester"],
            "password": "super-secret-password",
        }
        user_session["circular"] = user_session

        if items:
            for item in items:
                price = item.get("price", 0.0)
                quantity = item.get("quantity", 1)
                cart_total += price * quantity

        response = {
            "status": "success",
            "user": user_session,
            "total": cart_total,
        }
        return response
