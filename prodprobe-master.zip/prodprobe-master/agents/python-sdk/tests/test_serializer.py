import re
from hyperprobe.core.serializer import serialize

class CustomObject:
    def __init__(self, name, age):
        self.name = name
        self.age = age
        self._private_field = "secret"

def test_serialize_primitives():
    assert serialize(None) is None
    assert serialize(42) == 42
    assert serialize(3.14) == 3.14
    assert serialize(True) is True
    assert serialize("hello") == "hello"

def test_serialize_list_truncation():
    lst = [1, 2, 3, 4, 5]
    res = serialize(lst, max_array_length=2)
    assert res == [1, 2, "[+ 3 more items truncated]"]

def test_serialize_dict_truncation():
    d = {f"k{i}": i for i in range(5)}
    res = serialize(d, max_object_properties=3)
    assert len(res) == 4  # 3 properties + __probe_meta
    assert res["__probe_meta"] == "+ 2 more properties truncated"

def test_serialize_string_truncation():
    s = "a" * 100
    res = serialize(s, max_string_length=10)
    assert res == "aaaaaaaaaa... [Truncated: +90 more chars]"

def test_serialize_circular_reference():
    a = {}
    b = {"ref": a}
    a["ref"] = b
    res = serialize(a, path='watch["a"]')
    assert res["ref"]["ref"] == '[REF - watch["a"]]'

def test_serialize_shared_reference_uses_original_path():
    shared = {"id": 1}
    value = {"first": shared, "second": shared}

    res = serialize(value, path='watch["value"]')

    assert res["first"] == {"id": 1}
    assert res["second"] == '[REF - watch["value"].first]'

def test_serialize_self_reference_uses_root_path():
    value = {}
    value["self"] = value

    res = serialize(value, path='watch["value"]')

    assert res["self"] == '[REF - watch["value"]]'

def test_serialize_equal_but_distinct_objects_are_not_references():
    value = {
        "first": {"id": 1},
        "second": {"id": 1},
    }

    res = serialize(value, path='watch["value"]')

    assert res == {
        "first": {"id": 1},
        "second": {"id": 1},
    }

def test_serialize_custom_object():
    obj = CustomObject("Karan", 30)
    res = serialize(obj)
    assert res == {"name": "Karan", "age": 30}

def test_serialize_redact_keys():
    d = {"password": "123", "normal": "safe", "secret_token": "456"}
    redact_keys_re = re.compile(r"password|token", re.IGNORECASE)
    res = serialize(d, redact_keys_re=redact_keys_re)
    assert res["password"] == "[REDACTED Key]"
    assert res["secret_token"] == "[REDACTED Key]"
    assert res["normal"] == "safe"

def test_serialize_redact_values():
    d = {"text": "My Bearer my-sensitive-token is here"}
    redact_values_re = re.compile(r"Bearer [\w-]+", re.IGNORECASE)
    res = serialize(d, redact_values_re=redact_values_re)
    assert res["text"] == "My [REDACTED Value] is here"
