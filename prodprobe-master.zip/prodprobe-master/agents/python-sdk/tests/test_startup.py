import pytest

import hyperprobe.agent as agent_module


class FakeBrokerClient:
    def __init__(self, **kwargs):
        self.kwargs = kwargs
        self.agent_version = "test-version"

    def shutdown(self):
        pass

    def get_probes(self):
        return None


@pytest.fixture(autouse=True)
def reset_agent(monkeypatch):
    for key in (
        "GIT_COMMIT",
        "HYPERPROBE_ALLOW_NON_UUID",
        "HYPERPROBE_BROKER_URL",
        "HYPERPROBE_COMMIT_SHA",
        "HYPERPROBE_DISABLED",
        "HYPERPROBE_ENVIRONMENT",
        "HYPERPROBE_FORK_MODE",
        "HYPERPROBE_SERVICE_ID",
    ):
        monkeypatch.delenv(key, raising=False)
    agent_module.HyperProbeAgent.shutdown()
    yield
    agent_module.HyperProbeAgent.shutdown()


def test_programmatic_start_reads_required_environment(monkeypatch):
    startup_messages = []
    monkeypatch.setattr(agent_module, "BrokerClient", FakeBrokerClient)
    monkeypatch.setattr(
        agent_module.logger,
        "forceInfo",
        startup_messages.append,
    )
    monkeypatch.setenv(
        "HYPERPROBE_SERVICE_ID",
        "87c699ba-a5a4-4ca8-927b-e7b33707cf6d",
    )
    monkeypatch.setenv("HYPERPROBE_ENVIRONMENT", "test")
    monkeypatch.setenv("HYPERPROBE_BROKER_URL", "localhost:60051")
    monkeypatch.setenv("HYPERPROBE_COMMIT_SHA", "test-commit")

    agent = agent_module.HyperProbeAgent.start({})

    assert agent is not None
    assert agent.options["service_id"] == (
        "87c699ba-a5a4-4ca8-927b-e7b33707cf6d"
    )
    assert agent.options["environment"] == "test"
    assert agent.options["broker_url"] == "localhost:60051"
    assert agent.options["commit_sha"] == "test-commit"
    assert any(
        "Python agent successfully started (Version: test-version" in message
        for message in startup_messages
    )


def test_programmatic_start_failure_leaves_application_uninstrumented(
    monkeypatch,
):
    monkeypatch.setenv("HYPERPROBE_SYNC_INTERVAL_MS", "invalid")

    agent = agent_module.HyperProbeAgent.start(
        {
            "service_id": "87c699ba-a5a4-4ca8-927b-e7b33707cf6d",
            "environment": "test",
            "broker_url": "localhost:60051",
            "commit_sha": "test-commit",
        }
    )

    assert agent is None
    assert agent_module.HyperProbeAgent._instance is None


def test_programmatic_start_cleans_partially_initialized_resources(monkeypatch):
    brokers = []

    class TrackingBrokerClient(FakeBrokerClient):
        def __init__(self, **kwargs):
            super().__init__(**kwargs)
            self.closed = False
            brokers.append(self)

        def shutdown(self):
            self.closed = True

    def fail_engine_initialization(_agent):
        raise RuntimeError("engine initialization failed")

    monkeypatch.setattr(agent_module, "BrokerClient", TrackingBrokerClient)
    monkeypatch.setattr(
        agent_module.HyperProbeAgent,
        "_init_instrumentation_engine",
        fail_engine_initialization,
    )

    agent = agent_module.HyperProbeAgent.start(
        {
            "service_id": "87c699ba-a5a4-4ca8-927b-e7b33707cf6d",
            "environment": "test",
            "broker_url": "localhost:60051",
            "commit_sha": "test-commit",
        }
    )

    assert agent is None
    assert agent_module.HyperProbeAgent._instance is None
    assert len(brokers) == 1
    assert brokers[0].closed is True


def test_non_uuid_service_id_is_rejected_by_default(monkeypatch):
    errors = []
    monkeypatch.setattr(agent_module.logger, "forceError", errors.append)

    agent = agent_module.HyperProbeAgent.start(
        {
            "service_id": "legacy-service",
            "environment": "test",
            "broker_url": "localhost:60051",
            "commit_sha": "test-commit",
        }
    )

    assert agent is None
    assert agent_module.HyperProbeAgent._instance is None
    assert any("not a valid UUIDv4" in message for message in errors)


def test_non_uuid_service_id_can_be_allowed_by_option(monkeypatch):
    monkeypatch.setattr(agent_module, "BrokerClient", FakeBrokerClient)

    agent = agent_module.HyperProbeAgent.start(
        {
            "service_id": "legacy-service",
            "allow_non_uuid": True,
            "environment": "test",
            "broker_url": "localhost:60051",
            "commit_sha": "test-commit",
        }
    )

    assert agent is not None
    assert agent.options["service_id"] == "legacy-service"


def test_non_uuid_service_id_can_be_allowed_by_environment(monkeypatch):
    monkeypatch.setattr(agent_module, "BrokerClient", FakeBrokerClient)
    monkeypatch.setenv("HYPERPROBE_ALLOW_NON_UUID", " YES ")

    agent = agent_module.HyperProbeAgent.start(
        {
            "service_id": "legacy-service",
            "environment": "test",
            "broker_url": "localhost:60051",
            "commit_sha": "test-commit",
        }
    )

    assert agent is not None
    assert agent.options["service_id"] == "legacy-service"


def test_allow_non_uuid_option_overrides_environment(monkeypatch):
    monkeypatch.setenv("HYPERPROBE_ALLOW_NON_UUID", "yes")

    agent = agent_module.HyperProbeAgent.start(
        {
            "service_id": "legacy-service",
            "allow_non_uuid": False,
            "environment": "test",
            "broker_url": "localhost:60051",
            "commit_sha": "test-commit",
        }
    )

    assert agent is None
    assert agent_module.HyperProbeAgent._instance is None
