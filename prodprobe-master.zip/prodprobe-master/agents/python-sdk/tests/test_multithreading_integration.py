import os
import threading
import json
import inspect
from hyperprobe.core.quota import QuotaManager
from hyperprobe.core.safety import SafetyMonitor
from hyperprobe.core.monitoring_engine import MonitoringEngine
from tests.fixtures.demo_app.app import CheckoutService

# Define a mock Probe class to mimic the protobuf format
class MockProbe:
    def __init__(self, id, type, location, line, hit_limit=10, condition=None, template=None):
        self.id = id
        self.type = type # 1=Snapshot, 2=Log
        self.runtime_location = location
        self.runtime_line = line
        self.hit_limit = hit_limit
        self.condition = condition
        self.template = template
        self.watch_expressions = []

def test_multithreading_snapshot_capture():
    # 1. Setup telemetry logs accumulator
    captured_events = []
    def on_capture(event):
        captured_events.append(event)

    qm = QuotaManager(hits_per_sec=100, bytes_per_sec=1024 * 1024)
    sm = SafetyMonitor(lambda h, r: None)

    # 2. Initialize the instrumentation engine
    engine = MonitoringEngine(qm, sm, on_capture)
    engine.set_global_config({
        "max_object_depth": 3,
        "max_array_length": 3,
        "max_object_properties": 50,
        "max_string_length": 1024,
        "redact_keys": ["password"],
        "redact_values": []
    })
    
    # Resolve the fixture path and target executable line dynamically.
    app_filepath = os.path.abspath(inspect.getsourcefile(CheckoutService.process_checkout))
    source_lines, source_start = inspect.getsourcelines(CheckoutService.process_checkout)
    target_line = source_start + next(
        index for index, line in enumerate(source_lines) if "return response" in line
    )

    # Create a Snapshot Probe targeting the return statement.
    probe_snap = MockProbe(
        id="probe-snapshot-checkout",
        type=1, # Snapshot
        location=app_filepath,
        line=target_line,
        hit_limit=15
    )

    # Create a Log Probe targeting the exact same line.
    probe_log = MockProbe(
        id="probe-log-checkout",
        type=2, # Log
        location=app_filepath,
        line=target_line,
        hit_limit=15,
        template="Checkout processed for {user_id} with total {cart_total}"
    )

    # 3. Apply both probes on the same line simultaneously
    engine.set_probes([probe_snap, probe_log])

    # 4. Simulate a concurrent multi-threaded execution of REST API requests
    threads = []
    
    # Start 3 parallel threads processing checkouts concurrently
    for i in range(3):
        items = [{"price": 100.0, "quantity": 1}]
        t = threading.Thread(
            target=CheckoutService.process_checkout,
            args=(f"user-{i+1}", items),
            name=f"RequestThread-{i+1}"
        )
        threads.append(t)
        t.start()

    # Wait for execution to finish
    for t in threads:
        t.join()

    # Disable engine tracing and release the PEP 669 tool for later tests.
    engine.set_probes([])
    engine.close()

    # 5. Assertions: We expect exactly 6 captures (3 snapshots + 3 logs)
    assert len(captured_events) == 6

    snapshot_events = [e for e in captured_events if e["probe_id"] == "probe-snapshot-checkout"]
    log_events = [e for e in captured_events if e["probe_id"] == "probe-log-checkout"]

    assert len(snapshot_events) == 3
    assert len(log_events) == 3

    # Check evaluated logs
    for event in log_events:
        assert event["evaluated_log"].startswith("Checkout processed for user-")
        assert "with total 100.0" in event["evaluated_log"]

    # Deserialize and check snapshot locals
    for event in snapshot_events:
        vars_dict = json.loads(event["captured_vars_json"])[0][0]["vars"]
        
        # Verify captured local variables inside the running thread frame
        assert "user_id" in vars_dict
        assert vars_dict["user_id"].startswith("user-")
        assert "cart_total" in vars_dict
        assert vars_dict["cart_total"] == 100.0
        
        # Verify complex objects (user_session)
        assert "user_session" in vars_dict
        user_sess = vars_dict["user_session"]
        
        # Verify redaction of secrets
        assert "password" in user_sess
        assert user_sess["password"] == "[REDACTED Key]"
        
        # Verify circular reference protection
        assert "circular" in user_sess
        assert user_sess["circular"] == "[REF - frame[0].scopes[0].user_session]"

        # Verify stack frames are captured
        assert len(event["stack_frames"]) > 0
        assert event["stack_frames"][0]["function_name"] == "process_checkout"
        assert "app.py" in event["stack_frames"][0]["file_name"]
