import queue
import sys
import inspect
import json
from types import SimpleNamespace

import pytest

from hyperprobe.agent import HyperProbeAgent
from hyperprobe.core.broker import BrokerClient, BrokerTransportError
from hyperprobe.core.monitoring_engine import MonitoringEngine
from hyperprobe.core.quota import QuotaManager
from hyperprobe.core.safety import SafetyMonitor
from hyperprobe.core.serializer import serialize


class Probe:
    def __init__(self, probe_id="probe", probe_type=1, location=__file__, line=1):
        self.id = probe_id
        self.type = probe_type
        self.runtime_location = location
        self.runtime_line = line
        self.hit_limit = 10
        self.condition = None
        self.template = None
        self.watch_expressions = []


def test_invalid_redaction_update_retains_last_known_good_config():
    events = []
    engine = MonitoringEngine(
        QuotaManager(),
        SafetyMonitor(lambda *_: None),
        events.append,
    )
    valid_config = {
        "redact_keys": ["password"],
        "redact_values": [r"secret-\w+"],
        "stack_frame_depth": 1,
    }

    try:
        assert engine.set_global_config(valid_config) is True
        keys_re = engine._redact_keys_re
        values_re = engine._redact_values_re

        assert engine.set_global_config({
            "redact_keys": ["api_key"],
            "redact_values": ["["],
            "stack_frame_depth": 1,
        }) is False
        assert engine.global_config == valid_config
        assert engine._redact_keys_re is keys_re
        assert engine._redact_values_re is values_re

        password = "raw-password"
        message = "contains secret-token"
        engine._handle_probe_hit(Probe(), inspect.currentframe())
    finally:
        engine.close()

    captured = json.loads(events[0]["captured_vars_json"])[0][0]["vars"]
    assert captured["password"] == "[REDACTED Key]"
    assert captured["message"] == "contains [REDACTED Value]"


def test_probe_hit_uses_precompiled_redaction_patterns(monkeypatch):
    events = []
    engine = MonitoringEngine(
        QuotaManager(),
        SafetyMonitor(lambda *_: None),
        events.append,
    )

    try:
        assert engine.set_global_config({"redact_keys": ["password"]}) is True
        monkeypatch.setattr(
            "hyperprobe.core.monitoring_engine.re.compile",
            lambda *_args, **_kwargs: (_ for _ in ()).throw(
                AssertionError("redaction patterns were compiled during capture")
            ),
        )

        password = "raw-password"
        engine._handle_probe_hit(Probe(), inspect.currentframe())
    finally:
        engine.close()

    captured = json.loads(events[0]["captured_vars_json"])[0][0]["vars"]
    assert captured["password"] == "[REDACTED Key]"


def test_pending_location_is_removed_when_probes_are_cleared():
    engine = MonitoringEngine(
        QuotaManager(),
        SafetyMonitor(lambda *_: None),
        lambda _: None,
    )
    try:
        engine.set_probes([Probe(line=999999)])
        assert engine.pending_pivots

        engine.set_probes([])

        assert not engine.pending_pivots
        assert not engine.is_active
    finally:
        engine.close()


def test_monitoring_engine_close_releases_tool_id():
    engine = MonitoringEngine(
        QuotaManager(),
        SafetyMonitor(lambda *_: None),
        lambda _: None,
    )
    tool_id = engine.tool_id

    engine.close()
    engine.close()

    assert engine.tool_id is None
    if hasattr(sys, "monitoring") and tool_id is not None:
        assert sys.monitoring.get_tool(tool_id) is None


def test_suspended_engine_does_not_restart_monitoring_from_set_probes():
    engine = MonitoringEngine(
        QuotaManager(),
        SafetyMonitor(lambda *_: None),
        lambda _: None,
    )
    try:
        probe = Probe(location=__file__, line=1)
        engine.suspend()
        engine.set_probes([probe])

        assert engine.is_suspended is True
        assert engine.is_active is False

        engine.resume()
        assert engine.is_suspended is False
        if engine.tool_id is not None:
            assert engine.is_active is True
    finally:
        engine.close()


def test_resume_requeues_pivoted_locations_after_suspend():
    engine = MonitoringEngine(
        QuotaManager(),
        SafetyMonitor(lambda *_: None),
        lambda _: None,
    )
    try:
        location = (engine._resolve_filename_cached(__file__), 1)
        engine.pivoted_locations.add(location)

        engine.suspend()
        engine.resume()

        assert location in engine.pending_pivots
    finally:
        engine.close()


def test_agent_filters_unsupported_probe_type_before_engine():
    applied_probes = []
    response = SimpleNamespace(
        probes=[Probe(probe_type=99)],
        HasField=lambda _field: False,
    )
    agent = HyperProbeAgent.__new__(HyperProbeAgent)
    agent.broker_client = SimpleNamespace(get_probes=lambda: response)
    agent._agent_lock = __import__("threading").RLock()
    agent.active_probes = {}
    agent.local_hits = {}
    agent.pending_hits = {}
    agent.safety_monitor = SafetyMonitor(lambda *_: None)
    agent.cooldown_timer = None
    agent.engine = SimpleNamespace(set_probes=applied_probes.extend)

    agent._sync_with_broker()

    assert applied_probes == []
    assert agent.active_probes == {}


def test_evaluation_quota_is_checked_before_condition():
    class RejectingQuota:
        def __init__(self):
            self.calls = 0

        def can_evaluate(self):
            self.calls += 1
            return False

    quota = RejectingQuota()
    events = []
    engine = MonitoringEngine(
        quota,
        SafetyMonitor(lambda *_: None),
        events.append,
    )
    try:
        probe = Probe()
        probe.condition = "1 / 0"
        engine._handle_probe_hit(probe, inspect.currentframe())

        assert quota.calls == 1
        assert events == []
        assert engine.get_stats()["skips"] == 1
    finally:
        engine.close()


def test_condition_error_emits_normal_capture_event():
    class AllowingQuota:
        def can_evaluate(self):
            return True

    events = []
    engine = MonitoringEngine(
        AllowingQuota(),
        SafetyMonitor(lambda *_: None),
        events.append,
    )
    try:
        probe = Probe()
        probe.condition = "1 / 0"
        engine._handle_probe_hit(probe, inspect.currentframe())

        assert len(events) == 1
        assert "Condition evaluation failed" in events[0]["capture_error"]
    finally:
        engine.close()


def test_broker_report_failure_is_not_returned_as_success():
    class FailingStub:
        def ReportTelemetry(self, *_args, **_kwargs):
            raise RuntimeError("network down")

    client = BrokerClient.__new__(BrokerClient)
    client.agent_id = "agent"
    client.stub = FailingStub()
    client.rpc_timeout_sec = 1.0
    client.metadata = (("x-hp-service-id", "service"),)

    event = {
        "probe_id": "probe",
        "timestamp_ms": 1,
        "stack_frames": [],
        "captured_vars_json": "{}",
        "watch_results_json": "{}",
        "evaluated_log": "",
        "metric_value": 0.0,
        "capture_error": "",
    }

    with pytest.raises(BrokerTransportError):
        client.report_telemetry([event])


def test_realistic_flush_failure_retains_batch_for_retry():
    class FailingBroker:
        def report_telemetry(self, _batch):
            raise BrokerTransportError("network down")

    agent = HyperProbeAgent.__new__(HyperProbeAgent)
    agent.is_shutdown = False
    agent.telemetry_queue = queue.Queue(maxsize=2)
    agent.broker_client = FailingBroker()
    agent._inflight_batch = None
    event = {"probe_id": "probe"}
    agent.telemetry_queue.put(event)

    agent._flush_telemetry()

    assert agent.telemetry_queue.empty()
    assert len(agent._inflight_batch) == 1
    assert agent._inflight_batch[0].event == event


def test_flush_retry_reuses_bandwidth_reservation():
    class FlakyBroker:
        def __init__(self):
            self.calls = 0

        def estimate_event_size(self, _event):
            return 100

        def report_telemetry(self, _batch):
            self.calls += 1
            if self.calls == 1:
                raise BrokerTransportError("network down")
            return []

    agent = HyperProbeAgent.__new__(HyperProbeAgent)
    agent._agent_lock = __import__("threading").RLock()
    agent.active_probes = {"probe": Probe()}
    agent.local_hits = {}
    agent.pending_hits = {}
    agent.telemetry_queue = queue.Queue(maxsize=2)
    agent._inflight_batch = None
    agent.quota_manager = QuotaManager(hits_per_sec=10, bytes_per_sec=100)
    agent.quota_manager.bandwidth_bucket.refill_rate = 0
    agent.broker_client = FlakyBroker()
    agent.engine = SimpleNamespace(set_probes=lambda _probes: None)

    agent._handle_capture({"probe_id": "probe", "timestamp_ms": 1})
    assert agent.quota_manager.bandwidth_bucket.tokens == 0

    agent._flush_telemetry()
    assert agent._inflight_batch is not None
    assert agent.quota_manager.bandwidth_bucket.tokens == 0

    agent._flush_telemetry()
    assert agent._inflight_batch is None
    assert agent.quota_manager.bandwidth_bucket.tokens == 0


def test_bandwidth_quota_is_checked_before_enqueue():
    agent = HyperProbeAgent.__new__(HyperProbeAgent)
    agent._agent_lock = __import__("threading").RLock()
    agent.active_probes = {"probe": Probe()}
    agent.local_hits = {}
    agent.pending_hits = {}
    agent.telemetry_queue = queue.Queue(maxsize=2)
    agent.quota_manager = QuotaManager(hits_per_sec=10, bytes_per_sec=1)
    agent.broker_client = SimpleNamespace(estimate_event_size=lambda _event: 100)
    agent.engine = SimpleNamespace(set_probes=lambda _probes: None)

    agent._handle_capture(
        {
            "probe_id": "probe",
            "timestamp_ms": 1,
            "stack_frames": [],
            "captured_vars_json": "{}",
            "watch_results_json": "{}",
            "evaluated_log": "",
            "metric_value": 0.0,
            "capture_error": "",
            "trace_id": None,
        }
    )

    assert agent.telemetry_queue.empty()
    assert agent.local_hits == {}
    assert agent.pending_hits == {}


def test_queue_full_releases_bandwidth_and_hit_reservation():
    agent = HyperProbeAgent.__new__(HyperProbeAgent)
    agent._agent_lock = __import__("threading").RLock()
    agent.active_probes = {"probe": Probe()}
    agent.local_hits = {}
    agent.pending_hits = {}
    agent.telemetry_queue = queue.Queue(maxsize=1)
    agent.telemetry_queue.put("existing")
    agent.quota_manager = QuotaManager(hits_per_sec=10, bytes_per_sec=100)
    agent.broker_client = SimpleNamespace(estimate_event_size=lambda _event: 100)
    agent.engine = SimpleNamespace(set_probes=lambda _probes: None)

    agent._handle_capture({"probe_id": "probe", "timestamp_ms": 1})

    assert agent.local_hits == {}
    assert agent.pending_hits == {}
    assert agent.quota_manager.can_send(100) is True


def test_accepted_event_commits_hit_only_once():
    agent = HyperProbeAgent.__new__(HyperProbeAgent)
    agent._agent_lock = __import__("threading").RLock()
    probe = Probe()
    probe.hit_limit = 1
    agent.active_probes = {"probe": probe}
    agent.local_hits = {}
    agent.pending_hits = {}
    agent.telemetry_queue = queue.Queue(maxsize=1)
    agent.quota_manager = QuotaManager(hits_per_sec=10, bytes_per_sec=100)
    agent.broker_client = SimpleNamespace(estimate_event_size=lambda _event: 100)
    agent.engine = SimpleNamespace(set_probes=lambda _probes: None)

    agent._handle_capture({"probe_id": "probe", "timestamp_ms": 1})

    assert agent.local_hits == {"probe": 1}
    assert agent.pending_hits == {}
    assert "probe" not in agent.active_probes
    assert agent.telemetry_queue.qsize() == 1


def test_binary_and_cycle_values_are_bounded_and_identity_preserved():
    value = {}
    value["self"] = value
    value["payload"] = b"x" * 1_000_000

    result = serialize(value, path='watch["value"]')

    assert result["self"] == '[REF - watch["value"]]'
    assert result["payload"] == "[bytes: 1000000 bytes]"
