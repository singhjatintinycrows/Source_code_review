import os
from pathlib import Path
from setuptools import setup, find_packages

this_directory = Path(__file__).parent
long_description = (this_directory / "README.md").read_text() if (this_directory / "README.md").exists() else ""

setup(
    name="hyperprobe-agent",
    version="0.0.0",
    author="Arif, Saksham, Karan",
    author_email="arif@hypertest.co, saksham@hypertest.co, karan@hypertest.co",
    description="Production-grade, non-breaking live debugger and telemetry agent for Python.",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://www.hyperprobe.co",
    license="Hyperprobe Proprietary License",
    license_files=["LICENSE"],
    packages=find_packages(exclude=["tests", "tests.*", "demo_app", "demo_app.*"]),
    python_requires=">=3.12",
    install_requires=[
        "protobuf>=4.25.3,<6.0.0",
        "grpcio>=1.62.2",
    ],
    extras_require={
        "dev": [
            "grpcio>=1.50.0",
            "grpcio-tools>=1.50.0",
            "protobuf>=4.21.0",
            "pytest>=7.0.0",
        ]
    },
    classifiers=[
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.12",
        "Programming Language :: Python :: 3.13",
        "Operating System :: OS Independent",
    ],
)
