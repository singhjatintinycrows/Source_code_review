package io.opentracing;

public class SpanContext {
    private String traceId;

    public SpanContext(String traceId) {
        this.traceId = traceId;
    }

    public String toTraceId() {
        return traceId;
    }
}
