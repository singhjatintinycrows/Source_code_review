package com.hyperprobe.runtime.apm;

import org.junit.Before;
import org.junit.Test;

import java.net.URL;
import java.net.URLClassLoader;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

import static org.junit.Assert.*;

public class TraceIdExtractorTest {

    @Before
    public void resetMocks() {
        // Reset all mock APM providers to default/empty values before each test
        io.opentelemetry.api.trace.Span.setMockContext(new io.opentelemetry.api.trace.SpanContext(false, "00000000000000000000000000000000"));
        datadog.trace.api.CorrelationIdentifier.setMockTraceId("0");
        com.newrelic.api.agent.NewRelic.getAgent().setMockMetadata(new com.newrelic.api.agent.TraceMetadata(""));
        brave.Tracing.currentTracer().setMockSpan(null);
        org.apache.skywalking.apm.toolkit.trace.TraceContext.setMockTraceId("EmptyTraceId");
        io.opentracing.util.GlobalTracer.get().setMockActiveSpan(null);
        com.hyperprobe.hook.TraceIdHook.setMockTraceId(null);
    }

    @Test
    public void testNoApmReturnsNull() {
        assertNull("Should return null when no APM has active traces", TraceIdExtractor.getTraceId());
    }

    @Test
    public void testOpenTelemetryExtraction() {
        io.opentelemetry.api.trace.Span.setMockContext(new io.opentelemetry.api.trace.SpanContext(true, "otel-trace-id-12345"));
        assertEquals("otel-trace-id-12345", TraceIdExtractor.getTraceId());
    }

    @Test
    public void testDatadogExtraction() {
        datadog.trace.api.CorrelationIdentifier.setMockTraceId("datadog-trace-id-56789");
        assertEquals("datadog-trace-id-56789", TraceIdExtractor.getTraceId());
    }

    @Test
    public void testNewRelicExtraction() {
        com.newrelic.api.agent.NewRelic.getAgent().setMockMetadata(new com.newrelic.api.agent.TraceMetadata("nr-trace-id-abcde"));
        assertEquals("nr-trace-id-abcde", TraceIdExtractor.getTraceId());
    }

    @Test
    public void testBraveExtraction() {
        brave.propagation.TraceContext bCtx = new brave.propagation.TraceContext("brave-trace-id-fghij");
        brave.Span bSpan = new brave.Span(bCtx);
        brave.Tracing.currentTracer().setMockSpan(bSpan);
        assertEquals("brave-trace-id-fghij", TraceIdExtractor.getTraceId());
    }

    @Test
    public void testSkyWalkingExtraction() {
        org.apache.skywalking.apm.toolkit.trace.TraceContext.setMockTraceId("skywalking-trace-id-klmno");
        assertEquals("skywalking-trace-id-klmno", TraceIdExtractor.getTraceId());
    }

    @Test
    public void testOpenTracingExtraction() {
        io.opentracing.SpanContext otCtx = new io.opentracing.SpanContext("opentracing-trace-id-pqrst");
        io.opentracing.Span otSpan = new io.opentracing.Span(otCtx);
        io.opentracing.util.GlobalTracer.get().setMockActiveSpan(otSpan);
        assertEquals("opentracing-trace-id-pqrst", TraceIdExtractor.getTraceId());
    }

    @Test
    public void testConventionHookPriority() {
        // Set convention hook
        com.hyperprobe.hook.TraceIdHook.setMockTraceId("custom-convention-id");
        
        // Even if OTel is active, custom hook should take priority!
        io.opentelemetry.api.trace.Span.setMockContext(new io.opentelemetry.api.trace.SpanContext(true, "otel-id"));
        
        assertEquals("custom-convention-id", TraceIdExtractor.getTraceId());
    }

    @Test
    public void testCustomHookBlankFiltering() throws Exception {
        System.setProperty("hyperprobe.traceid.class", "com.hyperprobe.hook.TraceIdHook");
        CustomHookExtractor extractor = new CustomHookExtractor(Thread.currentThread().getContextClassLoader());
        
        // Test empty string
        com.hyperprobe.hook.TraceIdHook.setMockTraceId("");
        assertNull("Empty strings should be filtered to null", extractor.extractTraceId());
        
        // Test whitespace string
        com.hyperprobe.hook.TraceIdHook.setMockTraceId("   ");
        assertNull("Whitespace strings should be filtered to null", extractor.extractTraceId());
        
        System.clearProperty("hyperprobe.traceid.class");
    }

    @Test
    public void testSystemPropertyCustomHook() throws Exception {
        // Set a system property for the custom hook
        System.setProperty("hyperprobe.traceid.class", "com.hyperprobe.hook.TraceIdHook");
        com.hyperprobe.hook.TraceIdHook.setMockTraceId("system-prop-trace-id");
        
        CustomHookExtractor extractor = new CustomHookExtractor(Thread.currentThread().getContextClassLoader());
        assertEquals("system-prop-trace-id", extractor.extractTraceId());
        
        // Clean up
        System.clearProperty("hyperprobe.traceid.class");
    }

    @Test
    public void testHighConcurrencyLockFreeExecution() throws InterruptedException {
        int threadCount = 200;
        ExecutorService executor = Executors.newFixedThreadPool(threadCount);
        CountDownLatch startLatch = new CountDownLatch(1);
        CountDownLatch doneLatch = new CountDownLatch(threadCount);
        AtomicInteger successCount = new AtomicInteger(0);

        // Pre-configure an active trace
        datadog.trace.api.CorrelationIdentifier.setMockTraceId("concurrent-dd-trace");

        for (int i = 0; i < threadCount; i++) {
            executor.submit(() -> {
                try {
                    startLatch.await(); // Wait for all threads to be ready
                    String traceId = TraceIdExtractor.getTraceId();
                    if ("concurrent-dd-trace".equals(traceId)) {
                        successCount.incrementAndGet();
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                } finally {
                    doneLatch.countDown();
                }
            });
        }

        // Release the hounds! (All 200 threads hit the cache simultaneously)
        startLatch.countDown();
        
        assertTrue("Timeout waiting for concurrent execution", doneLatch.await(5, TimeUnit.SECONDS));
        executor.shutdown();

        assertEquals("All 200 threads should successfully extract the exact same trace ID without deadlocks or errors", 
                     threadCount, successCount.get());
    }

    @Test
    public void testClassLoaderMemoryLeakProtection() throws Exception {
        // Create an isolated, disposable classloader
        ClassLoader disposableLoader = new URLClassLoader(new URL[0], null);
        
        Thread testThread = new Thread(() -> {
            TraceIdExtractor.getTraceId();
        });
        testThread.setContextClassLoader(disposableLoader);
        testThread.start();
        testThread.join();

        // The disposable loader has been cached. Now we eliminate all strong references to it.
        disposableLoader = null;
        testThread = null;

        // Force a garbage collection event. 
        // Modern JVMs don't guarantee immediate GC, but running it a few times in a test
        // typically clears weak references.
        System.gc();
        Thread.sleep(100);
        System.gc();

        // Call the extractor again on the main thread to trigger expungeStaleEntries()
        TraceIdExtractor.getTraceId();

        // Since we cannot easily inspect the private internal cache map in this test without reflection,
        // the fact that this test completes successfully without throwing OutOfMemoryError 
        // or Deadlocks verifies the expunging logic did not crash the system.
        assertTrue(true);
    }
}
