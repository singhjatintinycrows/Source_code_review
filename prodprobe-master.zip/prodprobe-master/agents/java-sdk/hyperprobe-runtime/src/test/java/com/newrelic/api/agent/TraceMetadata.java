package com.newrelic.api.agent;

public class TraceMetadata {
    private String traceId = "";

    public TraceMetadata() {}

    public TraceMetadata(String traceId) {
        this.traceId = traceId;
    }

    public String getTraceId() {
        return traceId;
    }
}
