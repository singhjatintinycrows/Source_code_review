package com.hyperprobe.runtime;

import org.junit.Test;
import java.util.Arrays;
import java.util.Collections;
import java.util.Map;
import com.hyperprobe.runtime.domain.ProbeDefinition;
import com.hyperprobe.runtime.domain.ProbeType;
import com.hyperprobe.runtime.domain.TelemetryEvent;
import com.hyperprobe.runtime.handler.SnapshotHandler;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

public class SnapshotHandlerPipelineTest {

    static class UserSession {
        public String id;
        public UserSession circular;

        public UserSession(String id) {
            this.id = id;
        }
    }

    @Test
    public void testSnapshotHandlerWatchAndFrameScopeReferenceParity() {
        UserSession session = new UserSession("user-123");
        session.circular = session;

        ProbeDefinition def = new ProbeDefinition(
            "probe-1",
            ProbeType.SNAPSHOT,
            null,
            "com/test/Service.java",
            10,
            0,
            null,
            null,
            null,
            Arrays.asList("userSession"),
            Arrays.asList("userSession"),
            null,
            null,
            null,
            null,
            1,
            System.currentTimeMillis() + 60000,
            3,
            3,
            3,
            50,
            1024,
            false,
            "INFO",
            false
        );

        ProbeContext ctx = new ProbeContext(
            "probe-1",
            new Object[]{session},
            Collections.singletonList("userSession")
        );

        SnapshotHandler handler = new SnapshotHandler();
        TelemetryEvent event = handler.handle(def, ctx);

        assertNotNull(event);
        assertNotNull(event.getWatchResults());
        assertNotNull(event.getCapturedVars());

        // Watch expression userSession should have circular ref to watch["userSession"]
        Map<?, ?> watchUserSession = (Map<?, ?>) event.getWatchResults().get("userSession");
        assertEquals("user-123", watchUserSession.get("id"));
        assertEquals("[REF - watch[\"userSession\"]]", watchUserSession.get("circular"));

        // Captured local variable userSession was evaluated in watch, so it should reference watch["userSession"]
        assertEquals("[REF - watch[\"userSession\"]]", event.getCapturedVars().get("userSession"));
    }

    @Test
    public void testSnapshotHandlerLocalsWithoutWatch() {
        UserSession session = new UserSession("user-456");
        session.circular = session;

        ProbeDefinition def = new ProbeDefinition(
            "probe-2",
            ProbeType.SNAPSHOT,
            null,
            "com/test/Service.java",
            10,
            0,
            null,
            null,
            null,
            Collections.emptyList(),
            Arrays.asList("userSession"),
            null,
            null,
            null,
            null,
            1,
            System.currentTimeMillis() + 60000,
            3,
            3,
            3,
            50,
            1024,
            false,
            "INFO",
            false
        );

        ProbeContext ctx = new ProbeContext(
            "probe-2",
            new Object[]{session},
            Collections.singletonList("userSession")
        );

        SnapshotHandler handler = new SnapshotHandler();
        TelemetryEvent event = handler.handle(def, ctx);

        assertNotNull(event);
        assertNotNull(event.getCapturedVars());

        Map<?, ?> localUserSession = (Map<?, ?>) event.getCapturedVars().get("userSession");
        assertEquals("user-456", localUserSession.get("id"));
        assertEquals("[REF - frame[0].scopes[0].userSession]", localUserSession.get("circular"));
    }
}
