package com.hyperprobe.runtime.handler;

import com.hyperprobe.runtime.ProbeContext;
import com.hyperprobe.runtime.domain.ProbeDefinition;
import com.hyperprobe.runtime.domain.ProbeType;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.util.Collections;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

public class LogHandlerTest {
    private PrintStream originalOut;
    private PrintStream originalErr;
    private ByteArrayOutputStream stdout;
    private ByteArrayOutputStream stderr;

    @Before
    public void captureOutputStreams() {
        originalOut = System.out;
        originalErr = System.err;
        stdout = new ByteArrayOutputStream();
        stderr = new ByteArrayOutputStream();
        System.setOut(new PrintStream(stdout));
        System.setErr(new PrintStream(stderr));
    }

    @After
    public void restoreOutputStreams() {
        System.setOut(originalOut);
        System.setErr(originalErr);
    }

    @Test
    public void writesInfoLogsOnlyToStdout() {
        emitLog("INFO", true);

        assertTrue(stdout.toString().contains("[INFO]"));
        assertTrue(stdout.toString().contains("probe message"));
        assertEquals("", stderr.toString());
    }

    @Test
    public void writesErrorLogsOnlyToStderr() {
        emitLog("eRrOr", true);

        assertTrue(stderr.toString().contains("[ERROR]"));
        assertTrue(stderr.toString().contains("probe message"));
        assertEquals("", stdout.toString());
    }

    @Test
    public void doesNotWriteLocallyWhenStdoutLoggingIsDisabled() {
        emitLog("ERROR", false);

        assertEquals("", stdout.toString());
        assertEquals("", stderr.toString());
    }

    private void emitLog(String logLevel, boolean shouldLogToStdout) {
        ProbeDefinition definition = new ProbeDefinition(
            "probe-1",
            ProbeType.LOG,
            null,
            "Test.java",
            1,
            null,
            null,
            null,
            null,
            Collections.emptyList(),
            Collections.emptyList(),
            "probe message",
            null,
            null,
            null,
            1,
            System.currentTimeMillis() + 60_000,
            null,
            null,
            null,
            null,
            null,
            false,
            logLevel,
            shouldLogToStdout
        );
        ProbeContext context = new ProbeContext(
            "probe-1",
            new Object[0],
            Collections.emptyList()
        );

        new LogHandler().handle(definition, context);
    }
}
