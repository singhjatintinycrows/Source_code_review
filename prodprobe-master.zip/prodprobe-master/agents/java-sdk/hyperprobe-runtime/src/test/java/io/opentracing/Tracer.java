package io.opentracing;

public class Tracer {
    private Span activeSpan;

    public Span activeSpan() {
        return activeSpan;
    }

    public void setMockActiveSpan(Span span) {
        this.activeSpan = span;
    }
}
