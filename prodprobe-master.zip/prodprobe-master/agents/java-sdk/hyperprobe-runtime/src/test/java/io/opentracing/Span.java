package io.opentracing;

public class Span {
    private SpanContext context;

    public Span(SpanContext context) {
        this.context = context;
    }

    public SpanContext context() {
        return context;
    }
}
