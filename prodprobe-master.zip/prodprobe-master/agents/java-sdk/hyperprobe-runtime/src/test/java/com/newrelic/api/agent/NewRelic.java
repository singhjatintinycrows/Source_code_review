package com.newrelic.api.agent;

public class NewRelic {
    private static Agent agent = new Agent();

    public static Agent getAgent() {
        return agent;
    }
}
