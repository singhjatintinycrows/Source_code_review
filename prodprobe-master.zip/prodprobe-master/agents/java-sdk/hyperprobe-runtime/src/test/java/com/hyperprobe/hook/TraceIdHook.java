package com.hyperprobe.hook;

public class TraceIdHook {
    private static String mockTraceId = null;

    public static String getTraceId() {
        return mockTraceId;
    }

    public static void setMockTraceId(String id) {
        mockTraceId = id;
    }
}
