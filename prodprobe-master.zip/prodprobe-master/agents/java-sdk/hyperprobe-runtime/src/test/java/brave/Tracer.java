package brave;

public class Tracer {
    private Span currentSpan;

    public Span currentSpan() {
        return currentSpan;
    }

    public void setMockSpan(Span mockSpan) {
        this.currentSpan = mockSpan;
    }
}
