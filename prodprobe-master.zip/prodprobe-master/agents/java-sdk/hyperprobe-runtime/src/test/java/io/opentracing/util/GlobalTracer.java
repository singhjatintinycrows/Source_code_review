package io.opentracing.util;

import io.opentracing.Tracer;

public class GlobalTracer {
    private static Tracer tracer = new Tracer();

    public static Tracer get() {
        return tracer;
    }
}
