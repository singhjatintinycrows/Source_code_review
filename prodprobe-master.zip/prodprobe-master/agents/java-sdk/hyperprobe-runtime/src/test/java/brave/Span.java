package brave;

import brave.propagation.TraceContext;

public class Span {
    private TraceContext context;

    public Span(TraceContext context) {
        this.context = context;
    }

    public TraceContext context() {
        return context;
    }
}
