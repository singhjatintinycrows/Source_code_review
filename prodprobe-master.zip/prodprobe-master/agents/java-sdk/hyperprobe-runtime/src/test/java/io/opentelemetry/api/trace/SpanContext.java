package io.opentelemetry.api.trace;

public class SpanContext {
    private boolean valid = false;
    private String traceId = "00000000000000000000000000000000";

    public SpanContext() {}

    public SpanContext(boolean valid, String traceId) {
        this.valid = valid;
        this.traceId = traceId;
    }

    public boolean isValid() {
        return valid;
    }

    public String getTraceId() {
        return traceId;
    }
}
