package brave;

public class Tracing {
    private static Tracer tracer = new Tracer();

    public static Tracer currentTracer() {
        return tracer;
    }
    
    public static void setMockTracer(Tracer mockTracer) {
        tracer = mockTracer;
    }
}
