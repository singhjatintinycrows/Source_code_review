package org.apache.skywalking.apm.toolkit.trace;

public class TraceContext {
    private static String traceId = "EmptyTraceId";

    public static String traceId() {
        return traceId;
    }

    public static void setMockTraceId(String id) {
        traceId = id;
    }
}
