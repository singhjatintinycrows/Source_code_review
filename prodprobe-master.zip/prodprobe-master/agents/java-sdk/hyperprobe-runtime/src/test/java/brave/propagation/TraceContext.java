package brave.propagation;

public class TraceContext {
    private String traceIdString;

    public TraceContext(String id) {
        this.traceIdString = id;
    }

    public String traceIdString() {
        return traceIdString;
    }
}
