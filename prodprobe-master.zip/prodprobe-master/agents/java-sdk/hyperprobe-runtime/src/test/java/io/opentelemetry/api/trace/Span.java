package io.opentelemetry.api.trace;

public class Span {
    private static Span current = new Span();
    private static SpanContext context = new SpanContext();

    public static Span current() {
        return current;
    }

    public SpanContext getSpanContext() {
        return context;
    }

    public static void setMockContext(SpanContext mockContext) {
        context = mockContext;
    }
}
