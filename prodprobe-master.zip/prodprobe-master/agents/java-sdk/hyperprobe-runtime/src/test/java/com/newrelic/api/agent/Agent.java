package com.newrelic.api.agent;

public class Agent {
    private TraceMetadata metadata = new TraceMetadata();

    public TraceMetadata getTraceMetadata() {
        return metadata;
    }

    public void setMockMetadata(TraceMetadata mockMetadata) {
        this.metadata = mockMetadata;
    }
}
