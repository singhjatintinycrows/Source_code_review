package datadog.trace.api;

public class CorrelationIdentifier {
    private static String traceId = "0";

    public static String getTraceId() {
        return traceId;
    }

    public static void setMockTraceId(String id) {
        traceId = id;
    }
}
