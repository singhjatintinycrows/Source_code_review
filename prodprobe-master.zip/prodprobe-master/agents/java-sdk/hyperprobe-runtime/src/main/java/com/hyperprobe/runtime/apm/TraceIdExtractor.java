package com.hyperprobe.runtime.apm;

import com.hyperprobe.config.logging.HyperProbeLogger;

import java.lang.ref.Reference;
import java.lang.ref.ReferenceQueue;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

public class TraceIdExtractor {
    private static final HyperProbeLogger log = HyperProbeLogger.getLogger(TraceIdExtractor.class);

    private static final class WeakClassLoaderKey extends WeakReference<ClassLoader> {
        private final int hash;

        WeakClassLoaderKey(ClassLoader referent, ReferenceQueue<ClassLoader> q) {
            super(referent, q);
            this.hash = referent != null ? System.identityHashCode(referent) : 0;
        }

        @Override
        public int hashCode() {
            return hash;
        }

        @Override
        public boolean equals(Object obj) {
            if (this == obj) return true;
            if (obj instanceof WeakClassLoaderKey) {
                ClassLoader t = this.get();
                ClassLoader u = ((WeakClassLoaderKey) obj).get();
                return t != null && t == u;
            }
            return false;
        }
    }

    // High-performance, fully concurrent, memory-safe cache
    private static final ConcurrentMap<WeakClassLoaderKey, List<ApmExtractor>> cache = new ConcurrentHashMap<>();
    private static final ReferenceQueue<ClassLoader> refQueue = new ReferenceQueue<>();

    private static volatile List<ApmExtractor> bootstrapExtractors = null;

    private static void expungeStaleEntries() {
        Reference<? extends ClassLoader> ref;
        while ((ref = refQueue.poll()) != null) {
            cache.remove(ref);
        }
    }

    public static String getTraceId() {
        expungeStaleEntries(); // Lightweight poll to clean up GC'd classloaders

        ClassLoader cl = Thread.currentThread().getContextClassLoader();
        if (cl == null) {
            cl = ClassLoader.getSystemClassLoader();
        }

        final ClassLoader finalCl = cl;

        if (finalCl == null) {
            // Both TCCL and System ClassLoader are null (Bootstrap ClassLoader context)
            if (bootstrapExtractors == null) {
                synchronized (TraceIdExtractor.class) {
                    if (bootstrapExtractors == null) {
                        log.debug("Initializing TraceId discovery for Bootstrap ClassLoader");
                        bootstrapExtractors = discoverExtractors(null);
                        List<String> names = new ArrayList<>();
                        for (ApmExtractor ext : bootstrapExtractors) {
                            names.add(ext.getClass().getSimpleName());
                        }
                        log.debug("Discovered trace extractors for Bootstrap ClassLoader: %s", names);
                    }
                }
            }
            return extract(bootstrapExtractors);
        }

        // Lock-free read
        WeakClassLoaderKey lookupKey = new WeakClassLoaderKey(finalCl, null);
        List<ApmExtractor> extractors = cache.get(lookupKey);
        
        if (extractors == null) {
            // Avoid ConcurrentHashMap.computeIfAbsent deadlock risks (JDK-8062841)
            // by computing discovery completely outside the map lock.
            log.debug("Initializing TraceId discovery for ClassLoader: %s", finalCl);
            List<ApmExtractor> newlyDiscovered = discoverExtractors(finalCl);
            
            List<String> names = new ArrayList<>();
            for (ApmExtractor ext : newlyDiscovered) {
                names.add(ext.getClass().getSimpleName());
            }
            log.debug("Discovered trace extractors for ClassLoader %s: %s", finalCl, names);
            
            WeakClassLoaderKey insertKey = new WeakClassLoaderKey(finalCl, refQueue);
            List<ApmExtractor> existing = cache.putIfAbsent(insertKey, newlyDiscovered);
            extractors = (existing != null) ? existing : newlyDiscovered;
        }

        return extract(extractors);
    }

    private static String extract(List<ApmExtractor> extractors) {
        for (ApmExtractor extractor : extractors) {
            String traceId = extractor.extractTraceId();
            if (traceId != null) {
                log.debug("Successfully extracted TraceId [%s] using %s", traceId, extractor.getClass().getSimpleName());
                return traceId;
            }
        }
        return null;
    }

    private static List<ApmExtractor> discoverExtractors(ClassLoader cl) {
        List<ApmExtractor> list = new ArrayList<>();
        
        // Priority 1: Check for custom hooks (convention class or custom class via env var)
        try {
            list.add(new CustomHookExtractor(cl));
        } catch (Throwable ignored) {}

        // Priority 2: Auto-detect Standard APMs on the classpath
        // 1. OpenTelemetry
        try {
            list.add(new OpenTelemetryExtractor(cl));
        } catch (Throwable ignored) {}

        // 2. Datadog
        try {
            list.add(new DatadogExtractor(cl));
        } catch (Throwable ignored) {}

        // 3. New Relic
        try {
            list.add(new NewRelicExtractor(cl));
        } catch (Throwable ignored) {}

        // 4. Brave / Spring Cloud Sleuth (Zipkin)
        try {
            list.add(new BraveExtractor(cl));
        } catch (Throwable ignored) {}

        // 5. SkyWalking
        try {
            list.add(new SkyWalkingExtractor(cl));
        } catch (Throwable ignored) {}

        // 6. OpenTracing (General fallback)
        try {
            list.add(new OpenTracingExtractor(cl));
        } catch (Throwable ignored) {}

        return list;
    }
}
