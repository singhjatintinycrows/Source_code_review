package com.hyperprobe.runtime;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Represents the runtime context of a specific probe hit.
 * Created per-hit to encapsulate execution state.
 */
public class ProbeContext {
    private final String probeId;
    private final long hitTimestamp;
    private final Thread thread;
    private final Map<String, Object> localVariables;
    
    // Lazy loaded stack trace to avoid heavy overhead if not needed (e.g., counters)
    private StackTraceElement[] stackTrace;

    private static final StackWalker STACK_WALKER = StackWalker.getInstance();

    public ProbeContext(String probeId, Object[] localsArray, List<String> variableNames) {
        this.probeId = probeId;
        this.hitTimestamp = System.currentTimeMillis();
        this.thread = Thread.currentThread();
        this.localVariables = buildLocalsMap(localsArray, variableNames);
    }

    private Map<String, Object> buildLocalsMap(Object[] localsArray, List<String> variableNames) {
        if (localsArray == null || localsArray.length == 0 || variableNames == null) {
            return Collections.emptyMap();
        }
        
        Map<String, Object> map = new HashMap<>(localsArray.length);
        int maxLen = Math.min(localsArray.length, variableNames.size());
        
        for (int i = 0; i < maxLen; i++) {
            map.put(variableNames.get(i), localsArray[i]);
        }
        return map;
    }

    public String getProbeId() { return probeId; }
    public long getHitTimestamp() { return hitTimestamp; }
    public Thread getThread() { return thread; }
    public Map<String, Object> getLocalVariables() { return localVariables; }

    /**
     * Lazily captures the stack trace using Java 9+ StackWalker for zero-allocation streaming,
     * stripping out the agent's internal frames and respecting the configured stack depth.
     */
    public StackTraceElement[] getStackTrace(int depth) {
        if (stackTrace == null) {
            stackTrace = STACK_WALKER.walk(stream -> stream
                .map(StackWalker.StackFrame::toStackTraceElement)
                .dropWhile(frame -> {
                    String className = frame.getClassName();
                    return className.startsWith("java.lang.Thread") || 
                           className.startsWith("com.hyperprobe.agent.") ||
                           className.startsWith("com.hyperprobe.core.") ||
                           className.startsWith("com.hyperprobe.runtime.") ||
                           className.startsWith("com.hyperprobe.instrumentation.") ||
                           className.startsWith("com.hyperprobe.serializer.") ||
                           className.startsWith("com.hyperprobe.transport.");
                })
                .limit(depth)
                .toArray(StackTraceElement[]::new));
        }
        return stackTrace;
    }

    // Keep original method for compatibility if needed elsewhere, but default to depth 10
    public StackTraceElement[] getStackTrace() {
        return getStackTrace(10);
    }
}
