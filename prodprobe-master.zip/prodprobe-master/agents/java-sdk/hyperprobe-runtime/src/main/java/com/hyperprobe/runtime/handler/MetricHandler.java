package com.hyperprobe.runtime.handler;

import com.hyperprobe.runtime.ProbeContext;
import com.hyperprobe.runtime.domain.ProbeDefinition;
import com.hyperprobe.runtime.domain.ProbeType;
import com.hyperprobe.runtime.domain.TelemetryEvent;
import com.hyperprobe.evaluator.MvelEvaluator;

public class MetricHandler implements ProbeHandler {

    @Override
    public TelemetryEvent handle(ProbeDefinition def, ProbeContext ctx) {
        TelemetryEvent event = new TelemetryEvent(def.getId(), def.getType());

        if (def.getType() == ProbeType.COUNTER) {
            event.setMetricValue(1.0);
        } else if (def.getType() == ProbeType.METRIC) {
            String expr = def.getMetricExpression();
            if (expr != null && !expr.trim().isEmpty()) {
                try {
                    Object result = MvelEvaluator.evaluateExpression(expr, ctx.getLocalVariables());
                    
                    if (result instanceof Number) {
                        double val = ((Number) result).doubleValue();
                        if (Double.isFinite(val)) {
                            event.setMetricValue(val);
                        } else {
                            event.setCaptureError("Metric evaluation failed: " + result);
                        }
                    } else if (result != null) {
                        try {
                            double parsed = Double.parseDouble(result.toString());
                            if (Double.isFinite(parsed)) {
                                event.setMetricValue(parsed);
                            } else {
                                event.setCaptureError("Metric evaluation failed: " + result);
                            }
                        } catch (NumberFormatException e) {
                            event.setCaptureError("Metric evaluation failed: " + result);
                        }
                    } else {
                        event.setCaptureError("Metric evaluation failed: null");
                    }
                } catch (Throwable t) {
                    event.setCaptureError("Metric evaluation failed: " + t.getMessage());
                }
            } else {
                event.setCaptureError("Metric evaluation failed: Expression is empty");
            }
        }

        return event;
    }
}
