package com.hyperprobe.runtime.domain;

public enum ProbeType {
    SNAPSHOT,
    LOG,
    METRIC,
    COUNTER,
    DURATION
}
