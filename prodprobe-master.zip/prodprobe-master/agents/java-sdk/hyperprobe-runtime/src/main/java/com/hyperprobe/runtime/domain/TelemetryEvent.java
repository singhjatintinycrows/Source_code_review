package com.hyperprobe.runtime.domain;

import java.util.Map;

/**
 * Internal representation of a telemetry event produced by a handler.
 */
public class TelemetryEvent {
    private final String probeId;
    private final long timestampMs;
    private final ProbeType type;

    // Output fields
    private Map<String, Object> capturedVars; // Serialized JSON string in final proto
    private Map<String, Object> watchResults; // Serialized JSON string in final proto
    private StackTraceElement[] stackFrames;
    private String evaluatedLog;
    private Double metricValue;
    private String captureError;
    private String traceId;

    public TelemetryEvent(String probeId, ProbeType type) {
        this.probeId = probeId;
        this.type = type;
        this.timestampMs = System.currentTimeMillis();
    }

    public String getProbeId() { return probeId; }
    public long getTimestampMs() { return timestampMs; }
    public ProbeType getType() { return type; }

    public void setCapturedVars(Map<String, Object> vars) { this.capturedVars = vars; }
    public void setWatchResults(Map<String, Object> results) { this.watchResults = results; }
    public void setStackFrames(StackTraceElement[] frames) { this.stackFrames = frames; }
    public void setEvaluatedLog(String log) { this.evaluatedLog = log; }
    public void setMetricValue(Double val) { this.metricValue = val; }
    public void setCaptureError(String error) { this.captureError = error; }
    public void setTraceId(String traceId) { this.traceId = traceId; }

    // Getters for serialization layer
    public Map<String, Object> getCapturedVars() { return capturedVars; }
    public Map<String, Object> getWatchResults() { return watchResults; }
    public StackTraceElement[] getStackFrames() { return stackFrames; }
    public String getEvaluatedLog() { return evaluatedLog; }
    public Double getMetricValue() { return metricValue; }
    public String getCaptureError() { return captureError; }
    public String getTraceId() { return traceId; }
}
