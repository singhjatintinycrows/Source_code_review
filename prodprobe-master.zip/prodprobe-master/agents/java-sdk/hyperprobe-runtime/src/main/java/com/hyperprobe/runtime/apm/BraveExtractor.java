package com.hyperprobe.runtime.apm;

import java.lang.reflect.Method;

public class BraveExtractor implements ApmExtractor {
    private final Method currentTracerMethod;
    private final Method currentSpanMethod;
    private final Method contextMethod;
    private final Method traceIdStringMethod;

    public BraveExtractor(ClassLoader cl) throws Exception {
        Class<?> tracingClass = Class.forName("brave.Tracing", false, cl);
        this.currentTracerMethod = tracingClass.getMethod("currentTracer");
        
        Class<?> tracerClass = Class.forName("brave.Tracer", false, cl);
        this.currentSpanMethod = tracerClass.getMethod("currentSpan");
        
        Class<?> spanClass = Class.forName("brave.Span", false, cl);
        this.contextMethod = spanClass.getMethod("context");
        
        Class<?> traceContextClass = Class.forName("brave.propagation.TraceContext", false, cl);
        this.traceIdStringMethod = traceContextClass.getMethod("traceIdString");
    }

    @Override
    public String extractTraceId() {
        try {
            Object tracer = currentTracerMethod.invoke(null);
            if (tracer != null) {
                Object span = currentSpanMethod.invoke(tracer);
                if (span != null) {
                    Object context = contextMethod.invoke(span);
                    if (context != null) {
                        String traceId = (String) traceIdStringMethod.invoke(context);
                        if (traceId != null && !traceId.isEmpty()) {
                            return traceId;
                        }
                    }
                }
            }
        } catch (Throwable t) {
            // Safe fallback
        }
        return null;
    }
}
