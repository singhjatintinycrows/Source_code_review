package com.hyperprobe.runtime.apm;

public interface ApmExtractor {
    /**
     * Extracts the active trace ID, or returns null if not active.
     */
    String extractTraceId();
}
