package com.hyperprobe.runtime.handler;

import com.hyperprobe.runtime.ProbeContext;
import com.hyperprobe.runtime.domain.ProbeDefinition;
import com.hyperprobe.runtime.domain.TelemetryEvent;
import com.hyperprobe.evaluator.MvelEvaluator;
import com.hyperprobe.serializer.RedactionFilter;
import com.hyperprobe.serializer.SerializationConfig;

public class LogHandler implements ProbeHandler {

    @Override
    public TelemetryEvent handle(ProbeDefinition def, ProbeContext ctx) {
        TelemetryEvent event = new TelemetryEvent(def.getId(), def.getType());

        String template = def.getTemplate();
        if (template != null) {
            try {
                // 1. Evaluate template using MVEL string interpolation
                String evaluated = MvelEvaluator.evaluateTemplate(template, ctx.getLocalVariables());
                
                // 2. Apply Redaction & Truncation (Parity with Node.js)
                SerializationConfig config = SerializationConfig.getInstance();
                RedactionFilter filter = new RedactionFilter(config);
                
                String redacted = filter.redactValue(evaluated);
                
                if (redacted != null && redacted.length() > config.getMaxStringLength()) {
                    int remaining = redacted.length() - config.getMaxStringLength();
                    redacted = redacted.substring(0, config.getMaxStringLength()) + "... [Truncated: +" + remaining + " more chars]";
                }
                
                event.setEvaluatedLog(redacted);

                if (def.isShouldLogToStdout()) {
                    String level = def.getLogLevel() != null ? def.getLogLevel().toUpperCase() : "INFO";
                    String timestamp = java.time.Instant.now().toString();

                    String COLOR_RESET = "\u001B[0m";
                    String COLOR_BOLD = "\u001B[1m";
                    String COLOR_GRAY = "\u001B[90m";
                    String COLOR_MAGENTA = "\u001B[35m";

                    String levelColor;
                    switch (level) {
                        case "ERROR": levelColor = "\u001B[31m"; break; // Red
                        case "INFO":
                        default:      levelColor = "\u001B[32m"; break; // Green
                    }

                    String outputLine = String.format(
                        "%s[%s]%s %s%s[%s]%s %s%s[HyperProbe LOG]%s %s%n",
                        COLOR_GRAY, timestamp, COLOR_RESET,
                        COLOR_BOLD, levelColor, level, COLOR_RESET,
                        COLOR_BOLD, COLOR_MAGENTA, COLOR_RESET,
                        redacted
                    );
                    if ("ERROR".equalsIgnoreCase(level)) {
                        System.err.print(outputLine);
                    } else {
                        System.out.print(outputLine);
                    }
                }
            } catch (Throwable t) {
                // If evaluation fails, populate the dedicated captureError field (Node.js parity)
                event.setCaptureError(MvelEvaluator.formatErrorMessage(t));
            }
        }

        return event;
    }
}
