package com.hyperprobe.runtime.apm;

import com.hyperprobe.config.logging.HyperProbeLogger;
import java.lang.reflect.Method;

public class CustomHookExtractor implements ApmExtractor {
    private static final HyperProbeLogger log = HyperProbeLogger.getLogger(CustomHookExtractor.class);
    private final Method hookMethod;

    public CustomHookExtractor(ClassLoader cl) throws Exception {
        // 1. Try JVM System Properties first, then fallback to OS Environment Variables
        String className = System.getProperty("hyperprobe.traceid.class", System.getenv("HYPERPROBE_TRACE_ID_CLASS"));
        String methodName = System.getProperty("hyperprobe.traceid.method", System.getenv("HYPERPROBE_TRACE_ID_METHOD"));
        
        if (className != null && !className.trim().isEmpty()) {
            String finalMethodName = (methodName != null && !methodName.trim().isEmpty()) ? methodName.trim() : "getTraceId";
            log.debug("Initializing custom trace ID hook via environment: class=%s, method=%s", className.trim(), finalMethodName);
            Class<?> hookClass = Class.forName(className.trim(), false, cl);
            this.hookMethod = hookClass.getMethod(finalMethodName);
            return;
        }

        // 2. Fallback to Convention class
        Class<?> hookClass = Class.forName("com.hyperprobe.hook.TraceIdHook", false, cl);
        this.hookMethod = hookClass.getMethod("getTraceId");
        log.debug("Convention-over-configuration custom hook TraceIdHook detected and registered");
    }

    @Override
    public String extractTraceId() {
        try {
            Object result = hookMethod.invoke(null);
            if (result != null) {
                String traceId = result.toString().trim();
                if (!traceId.isEmpty()) {
                    return traceId;
                }
            }
        } catch (Throwable t) {
            // Safe fallback
        }
        return null;
    }
}
