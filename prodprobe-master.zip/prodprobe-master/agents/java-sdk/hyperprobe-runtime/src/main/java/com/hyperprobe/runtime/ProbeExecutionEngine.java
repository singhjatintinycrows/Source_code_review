package com.hyperprobe.runtime;

import com.hyperprobe.config.logging.HyperProbeLogger;
import com.hyperprobe.runtime.domain.ProbeDefinition;
import com.hyperprobe.runtime.domain.ProbeType;
import com.hyperprobe.runtime.domain.TelemetryEvent;
import com.hyperprobe.runtime.handler.*;

import java.util.EnumMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * The high-performance runtime execution engine.
 * Receives hits directly from the AgentBridge, processes them, and routes
 * them to the appropriate subsystem (Evaluator, Serializer, Queue).
 */
public class ProbeExecutionEngine {

    private static final HyperProbeLogger log = HyperProbeLogger.getLogger(ProbeExecutionEngine.class);

    // Registry of active probes, managed by the Control Plane
    private static volatile Map<String, ProbeDefinition> activeProbes = java.util.Collections.emptyMap();
    
    // Persistent cache for discovered variable names (preserves names across sync polls)
    private static final Map<String, java.util.List<String>> discoveredNames = new ConcurrentHashMap<>();
    
    // Callback to trigger when a probe self-expires to detach bytecode
    private static Runnable probeExpiryCallback;

    // Callback to dispatch captured telemetry events to the core module's queue
    private static java.util.function.Consumer<TelemetryEvent> telemetryCallback;
    
    // Quota manager to enforce global hit limits
    private static java.util.function.Supplier<Boolean> quotaCheck;
    
    // Handlers mapped by ProbeType
    private static final Map<ProbeType, ProbeHandler> handlers = new EnumMap<>(ProbeType.class);

    static {
        handlers.put(ProbeType.SNAPSHOT, new SnapshotHandler());
        handlers.put(ProbeType.LOG, new LogHandler());
        handlers.put(ProbeType.METRIC, new MetricHandler());
        handlers.put(ProbeType.COUNTER, new MetricHandler());
        handlers.put(ProbeType.DURATION, new DurationHandler());
    }

    public static void setProbeExpiryCallback(Runnable callback) {
        probeExpiryCallback = callback;
    }

    public static void setTelemetryCallback(java.util.function.Consumer<TelemetryEvent> callback) {
        telemetryCallback = callback;
    }

    public static void setQuotaCheck(java.util.function.Supplier<Boolean> check) {
        quotaCheck = check;
    }

    public static void updateProbeVariableNames(String probeId, java.util.List<String> names) {
        if (log.isDebugEnabled()) {
            log.debug("Discovered variable names for probe " + probeId + ": " + names);
        }
        discoveredNames.put(probeId, names);
        
        String baseProbeId = probeId.endsWith(":secondary") ? probeId.substring(0, probeId.length() - 10) : probeId;
        ProbeDefinition def = activeProbes.get(baseProbeId);
        if (def != null && !probeId.endsWith(":secondary")) {
            // Only sync primary names into the domain object to avoid confusing secondary overrides,
            // though discoveredNames handles the specific hit context directly.
            def.setLocalVariableNames(names);
        }
    }

    /**
     * Target method invoked by the AgentBridge.
     */
    public static void handleHit(String probeId, Object[] locals) {
        try {
            // 1. Enforce Global Hit Quota (CPU protection)
            if (quotaCheck != null && !quotaCheck.get()) {
                return; // Global limit reached, shed load immediately
            }

            String baseProbeId = probeId.endsWith(":secondary") ? probeId.substring(0, probeId.length() - 10) : probeId;

            ProbeDefinition def = activeProbes.get(baseProbeId);
            if (def == null) {
                return; // Probe was removed or expired
            }

            // 2. Check per-probe hit limits and expiration
            long now = System.currentTimeMillis();
            if (now >= def.getExpiryTime() || def.getLocalHits().get() >= def.getHitLimit()) {
                removeProbe(baseProbeId);
                discoveredNames.remove(baseProbeId);
                discoveredNames.remove(baseProbeId + ":secondary");
                // Command retransformation asynchronously to remove bytecode
                if (probeExpiryCallback != null) {
                    java.util.concurrent.CompletableFuture.runAsync(probeExpiryCallback);
                }
                return; // Skip capture
            }

            // 3. Build Context
            // Use persistent names if available (sync loop might have cleared the object's local copy)
            java.util.List<String> names = discoveredNames.get(probeId);
            if (names == null) {
                // Fallback to primary definition names if secondary is missing or identical
                names = def.getLocalVariableNames();
            }
            
            ProbeContext ctx = new ProbeContext(probeId, locals, names);
            if (ctx.getLocalVariables().isEmpty() && locals != null && locals.length > 0) {
                if (log.isDebugEnabled()) {
                    log.debug("WARNING: No local variable names found for hit " + baseProbeId + ". Captured " + locals.length + " values but names were empty.");
                }
            }

            // 4. Evaluate Condition (if any)
            String condition = def.getCondition();
            if (condition != null && !condition.isEmpty()) {
                boolean passed = com.hyperprobe.evaluator.MvelEvaluator.evaluateCondition(condition, ctx.getLocalVariables());
                if (!passed) {
                    return; // Condition failed, drop hit
                }
            }

            // 5. Route to Handler
            ProbeHandler handler = handlers.get(def.getType());
            if (handler != null) {
                TelemetryEvent event = handler.handle(def, ctx);
                
                if (event != null) {
                    if (def.isShouldCaptureTraceId()) {
                        try {
                            String traceId = com.hyperprobe.runtime.apm.TraceIdExtractor.getTraceId();
                            if (traceId != null) {
                                event.setTraceId(traceId);
                            }
                        } catch (Throwable t) {
                            // Extreme safety: never let trace resolution crash event delivery
                        }
                    }

                    // 6. Increment hit limit safely ONLY after an event is produced (Parity with Node SDK)
                    if (def.getLocalHits().incrementAndGet() >= def.getHitLimit()) {
                        removeProbe(baseProbeId);
                        discoveredNames.remove(baseProbeId);
                        discoveredNames.remove(baseProbeId + ":secondary");
                        if (probeExpiryCallback != null) {
                            java.util.concurrent.CompletableFuture.runAsync(probeExpiryCallback);
                        }
                    }

                    // 7. Dispatch Telemetry
                    if (telemetryCallback != null) {
                        telemetryCallback.accept(event);
                    }
                }
            }

        } catch (Throwable t) {
            // Extreme safety guardrail: Never allow a probe failure to crash the user thread.
            // Log for internal tracking so we aren't completely blind to fatal engine bugs.
            if (log.isDebugEnabled()) {
                log.debug("Critical failure inside handleHit for probe " + probeId + ": " + t.getMessage());
            }
        }
    }

    /**
     * Called by the Control Plane to update active definitions.
     * PARITY FIX: Merges new definitions with existing ones to preserve discovered metadata (like variable names).
     */
    public static synchronized void updateProbes(java.util.List<ProbeDefinition> newProbes) {
        // Build map of new probes
        java.util.Map<String, ProbeDefinition> nextProbes = new java.util.HashMap<>();
        for (ProbeDefinition p : newProbes) {
            // If probe already existed, preserve its discovered metadata
            ProbeDefinition existing = activeProbes.get(p.getId());
            if (existing != null) {
                p.setLocalVariableNames(existing.getLocalVariableNames());
                p.getLocalHits().set(existing.getLocalHits().get());
            }
            nextProbes.put(p.getId(), p);
        }

        // Cleanup stale discovered names to prevent memory leaks
        java.util.Set<String> newProbeIds = nextProbes.keySet();
        discoveredNames.keySet().removeIf(key -> {
            String baseId = key.endsWith(":secondary") ? key.substring(0, key.length() - 10) : key;
            return !newProbeIds.contains(baseId);
        });

        // Atomic pointer swap. Zero locks, zero dropped hits.
        activeProbes = java.util.Collections.unmodifiableMap(nextProbes);
    }
    
    private static synchronized void removeProbe(String probeId) {
        java.util.Map<String, ProbeDefinition> newMap = new java.util.HashMap<>(activeProbes);
        newMap.remove(probeId);
        activeProbes = java.util.Collections.unmodifiableMap(newMap);
    }
    
    public static java.util.List<ProbeDefinition> getActiveProbes() {
        return new java.util.ArrayList<>(activeProbes.values());
    }

    /**
     * Performs periodic background maintenance tasks (e.g., purging stale durations).
     */
    public static void runMaintenanceTasks() {
        ProbeHandler durationHandler = handlers.get(ProbeType.DURATION);
        if (durationHandler instanceof DurationHandler) {
            ((DurationHandler) durationHandler).cleanup();
        }
    }
}
