package com.hyperprobe.runtime.domain;

import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Represents the configuration and metadata of an active probe.
 */
public class ProbeDefinition {
    private final String id;
    private final ProbeType type;
    private final String condition;
    private final String runtimeLocation;
    private final int runtimeLine;
    private final Integer runtimeColumn;
    
    // Secondary Location (Only for DURATION)
    private final String secondaryRuntimeLocation;
    private final Integer secondaryRuntimeLine;
    private final Integer secondaryRuntimeColumn;
    
    private final List<String> watchExpressions;
    
    // Ordered list of variable names corresponding to the Object[] captured by ASM
    private volatile List<String> localVariableNames; 

    // Specific configurations
    private final String template; // For LOG
    private final String metricName; // For METRIC/COUNTER/DURATION
    private final String metricExpression; // For METRIC
    private final String correlationExpression; // For DURATION

    // Limits
    private final int hitLimit;
    private final long expiryTime;
    
    // Per-probe Serialization Overrides
    private final Integer maxObjectDepth;
    private final Integer maxArrayLength;
    private final Integer stackFrameDepth;
    private final Integer maxObjectProperties;
    private final Integer maxStringLength;
    
    private final boolean shouldCaptureTraceId;
    
    private final String logLevel;
    private final boolean shouldLogToStdout;
    
    private final AtomicInteger localHits = new AtomicInteger(0);

    public ProbeDefinition(String id, ProbeType type, String condition, 
                           String runtimeLocation, int runtimeLine, Integer runtimeColumn,
                           String secondaryRuntimeLocation, Integer secondaryRuntimeLine, Integer secondaryRuntimeColumn,
                           List<String> watchExpressions, List<String> localVariableNames,
                           String template, String metricName, String metricExpression,
                           String correlationExpression, int hitLimit, long expiryTime,
                           Integer maxObjectDepth, Integer maxArrayLength, Integer stackFrameDepth,
                           Integer maxObjectProperties, Integer maxStringLength, boolean shouldCaptureTraceId,
                           String logLevel, boolean shouldLogToStdout) {
        this.id = id;
        this.type = type;
        this.condition = condition;
        this.runtimeLocation = runtimeLocation;
        this.runtimeLine = runtimeLine;
        this.runtimeColumn = runtimeColumn;
        this.secondaryRuntimeLocation = secondaryRuntimeLocation;
        this.secondaryRuntimeLine = secondaryRuntimeLine;
        this.secondaryRuntimeColumn = secondaryRuntimeColumn;
        this.watchExpressions = watchExpressions;
        this.localVariableNames = localVariableNames != null ? localVariableNames : java.util.Collections.emptyList();
        
        // Translate Node-style JS template literals (${...}) to MVEL-style (@{...}) at parse time
        this.template = template != null ? template.replace("${", "@{") : null;
        
        this.metricName = metricName;
        this.metricExpression = metricExpression;
        this.correlationExpression = correlationExpression;
        this.hitLimit = hitLimit;
        this.expiryTime = expiryTime;
        
        this.maxObjectDepth = maxObjectDepth;
        this.maxArrayLength = maxArrayLength;
        this.stackFrameDepth = stackFrameDepth;
        this.maxObjectProperties = maxObjectProperties;
        this.maxStringLength = maxStringLength;
        this.shouldCaptureTraceId = shouldCaptureTraceId;
        this.logLevel = logLevel;
        this.shouldLogToStdout = shouldLogToStdout;
    }

    public String getId() { return id; }
    public ProbeType getType() { return type; }
    public String getCondition() { return condition; }
    public String getRuntimeLocation() { return runtimeLocation; }
    public int getRuntimeLine() { return runtimeLine; }
    public Integer getRuntimeColumn() { return runtimeColumn; }
    public String getSecondaryRuntimeLocation() { return secondaryRuntimeLocation; }
    public Integer getSecondaryRuntimeLine() { return secondaryRuntimeLine; }
    public Integer getSecondaryRuntimeColumn() { return secondaryRuntimeColumn; }
    public List<String> getWatchExpressions() { return watchExpressions; }
    public List<String> getLocalVariableNames() { return localVariableNames; }
    public String getTemplate() { return template; }
    public String getMetricName() { return metricName; }
    public String getMetricExpression() { return metricExpression; }
    public String getCorrelationExpression() { return correlationExpression; }
    public int getHitLimit() { return hitLimit; }
    public long getExpiryTime() { return expiryTime; }
    
    public Integer getMaxObjectDepth() { return maxObjectDepth; }
    public Integer getMaxArrayLength() { return maxArrayLength; }
    public Integer getStackFrameDepth() { return stackFrameDepth; }
    public Integer getMaxObjectProperties() { return maxObjectProperties; }
    public Integer getMaxStringLength() { return maxStringLength; }
    public boolean isShouldCaptureTraceId() { return shouldCaptureTraceId; }
    public String getLogLevel() { return logLevel; }
    public boolean isShouldLogToStdout() { return shouldLogToStdout; }
    
    public AtomicInteger getLocalHits() { return localHits; }
    
    public void setLocalVariableNames(List<String> localVariableNames) {
        this.localVariableNames = localVariableNames;
    }
}
