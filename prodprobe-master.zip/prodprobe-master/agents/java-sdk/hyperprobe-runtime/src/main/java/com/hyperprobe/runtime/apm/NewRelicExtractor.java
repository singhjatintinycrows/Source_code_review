package com.hyperprobe.runtime.apm;

import java.lang.reflect.Method;

public class NewRelicExtractor implements ApmExtractor {
    private final Method getAgentMethod;
    private final Method getTraceMetadataMethod;
    private final Method getTraceIdMethod;

    public NewRelicExtractor(ClassLoader cl) throws Exception {
        Class<?> nrClass = Class.forName("com.newrelic.api.agent.NewRelic", false, cl);
        this.getAgentMethod = nrClass.getMethod("getAgent");
        
        Class<?> agentClass = Class.forName("com.newrelic.api.agent.Agent", false, cl);
        this.getTraceMetadataMethod = agentClass.getMethod("getTraceMetadata");
        
        Class<?> traceMetadataClass = Class.forName("com.newrelic.api.agent.TraceMetadata", false, cl);
        this.getTraceIdMethod = traceMetadataClass.getMethod("getTraceId");
    }

    @Override
    public String extractTraceId() {
        try {
            Object agent = getAgentMethod.invoke(null);
            if (agent != null) {
                Object traceMetadata = getTraceMetadataMethod.invoke(agent);
                if (traceMetadata != null) {
                    String traceId = (String) getTraceIdMethod.invoke(traceMetadata);
                    if (traceId != null && !traceId.isEmpty()) {
                        return traceId;
                    }
                }
            }
        } catch (Throwable t) {
            // Safe fallback
        }
        return null;
    }
}
