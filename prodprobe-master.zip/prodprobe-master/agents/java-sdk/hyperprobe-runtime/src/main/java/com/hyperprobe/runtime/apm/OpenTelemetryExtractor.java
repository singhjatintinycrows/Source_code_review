package com.hyperprobe.runtime.apm;

import java.lang.reflect.Method;

public class OpenTelemetryExtractor implements ApmExtractor {
    private final Method currentMethod;
    private final Method getSpanContextMethod;
    private final Method isValidMethod;
    private final Method getTraceIdMethod;

    public OpenTelemetryExtractor(ClassLoader cl) throws Exception {
        Class<?> spanClass = Class.forName("io.opentelemetry.api.trace.Span", false, cl);
        this.currentMethod = spanClass.getMethod("current");
        this.getSpanContextMethod = spanClass.getMethod("getSpanContext");
        
        Class<?> spanContextClass = Class.forName("io.opentelemetry.api.trace.SpanContext", false, cl);
        this.isValidMethod = spanContextClass.getMethod("isValid");
        this.getTraceIdMethod = spanContextClass.getMethod("getTraceId");
    }

    @Override
    public String extractTraceId() {
        try {
            Object span = currentMethod.invoke(null);
            if (span != null) {
                Object spanContext = getSpanContextMethod.invoke(span);
                if (spanContext != null && (Boolean) isValidMethod.invoke(spanContext)) {
                    String traceId = (String) getTraceIdMethod.invoke(spanContext);
                    if (traceId != null && !"00000000000000000000000000000000".equals(traceId)) {
                        return traceId;
                    }
                }
            }
        } catch (Throwable t) {
            // Safe fallback
        }
        return null;
    }
}
