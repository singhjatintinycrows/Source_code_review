package com.hyperprobe.runtime.handler;

import com.hyperprobe.runtime.ProbeContext;
import com.hyperprobe.runtime.domain.ProbeDefinition;
import com.hyperprobe.runtime.domain.TelemetryEvent;
import com.hyperprobe.evaluator.MvelEvaluator;
import com.hyperprobe.config.logging.HyperProbeLogger;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Handles Duration probes.
 * Supports asynchronous correlation across threads using correlation expressions.
 */
public class DurationHandler implements ProbeHandler {

    private static final HyperProbeLogger log = HyperProbeLogger.getLogger(DurationHandler.class);
    private static final long ENTRY_TTL_MS = 60_000; // 60 seconds matching Node.js

    // Global state for correlation entries: "probeId:correlationId" -> EntryState
    private final Map<String, EntryState> activeEntries = new ConcurrentHashMap<>();

    private static class EntryState {
        final long startTime;
        final long createdAt;

        EntryState(long startTime) {
            this.startTime = startTime;
            this.createdAt = System.currentTimeMillis();
        }
    }

    @Override
    public TelemetryEvent handle(ProbeDefinition def, ProbeContext ctx) {
        String correlationId = "static-singleton";
        String expr = def.getCorrelationExpression();
        
        if (expr != null && !expr.trim().isEmpty()) {
            try {
                Object result = MvelEvaluator.evaluateExpression(expr, ctx.getLocalVariables());
                
                if (result == null) {
                    correlationId = "static-singleton";
                } else if (result instanceof String && (((String) result).startsWith("Error: ") || ((String) result).startsWith("Cannot resolve identifier"))) {
                    TelemetryEvent errorEvent = new TelemetryEvent(def.getId(), def.getType());
                    errorEvent.setCaptureError(((String) result).startsWith("Error: ") ? (String) result : "Error: " + result);
                    return errorEvent;
                } else if (result instanceof String || result instanceof Number) {
                    correlationId = result.toString();
                } else {
                    TelemetryEvent errorEvent = new TelemetryEvent(def.getId(), def.getType());
                    errorEvent.setCaptureError("Correlation expression must evaluate to a string or number, got " + result.getClass().getName());
                    return errorEvent;
                }
            } catch (Throwable t) {
                if (log.isDebugEnabled()) {
                    log.debug("Failed to evaluate correlation expression for probe " + def.getId() + ": " + t.getMessage());
                }
                TelemetryEvent errorEvent = new TelemetryEvent(def.getId(), def.getType());
                errorEvent.setCaptureError("Error: " + t.getMessage());
                return errorEvent;
            }
        }

        String key = def.getId() + ":" + correlationId;
        boolean isExitHit = ctx.getProbeId().endsWith(":secondary");
        
        if (!isExitHit) {
            // This is the Entry hit
            activeEntries.put(key, new EntryState(System.nanoTime()));
            return null;
        } else {
            // This is the Exit hit
            EntryState entry = activeEntries.remove(key);
            if (entry == null) {
                return null;
            }
            
            // Calculate duration in milliseconds with high precision
            double durationMs = (System.nanoTime() - entry.startTime) / 1_000_000.0;
            
            TelemetryEvent event = new TelemetryEvent(def.getId(), def.getType());
            event.setMetricValue(durationMs);
            return event;
        }
    }

    /**
     * Purges orphaned duration entries that never reached an exit hit.
     * Should be called periodically by a background task.
     */
    public void cleanup() {
        long now = System.currentTimeMillis();
        activeEntries.entrySet().removeIf(entry -> (now - entry.getValue().createdAt) > ENTRY_TTL_MS);
    }
}
