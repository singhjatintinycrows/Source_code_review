package com.hyperprobe.runtime.handler;

import com.hyperprobe.runtime.ProbeContext;
import com.hyperprobe.runtime.domain.ProbeDefinition;
import com.hyperprobe.runtime.domain.TelemetryEvent;

/**
 * Base interface for all specific probe execution logic.
 */
public interface ProbeHandler {
    
    /**
     * Executes the specific logic for this probe type.
     *
     * @param def The definition of the probe.
     * @param ctx The current execution context.
     * @return A TelemetryEvent to be serialized and dispatched, or null if no event should be emitted.
     */
    TelemetryEvent handle(ProbeDefinition def, ProbeContext ctx);
}
