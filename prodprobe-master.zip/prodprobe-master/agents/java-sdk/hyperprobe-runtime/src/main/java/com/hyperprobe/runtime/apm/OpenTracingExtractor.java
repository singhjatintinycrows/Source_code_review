package com.hyperprobe.runtime.apm;

import java.lang.reflect.Method;

public class OpenTracingExtractor implements ApmExtractor {
    private final Method getTracerMethod;
    private final Method activeSpanMethod;
    private final Method contextMethod;
    private final Method toTraceIdMethod;

    public OpenTracingExtractor(ClassLoader cl) throws Exception {
        Class<?> globalTracerClass = Class.forName("io.opentracing.util.GlobalTracer", false, cl);
        this.getTracerMethod = globalTracerClass.getMethod("get");
        
        Class<?> tracerClass = Class.forName("io.opentracing.Tracer", false, cl);
        this.activeSpanMethod = tracerClass.getMethod("activeSpan");
        
        Class<?> spanClass = Class.forName("io.opentracing.Span", false, cl);
        this.contextMethod = spanClass.getMethod("context");
        
        Class<?> spanContextClass = Class.forName("io.opentracing.SpanContext", false, cl);
        this.toTraceIdMethod = spanContextClass.getMethod("toTraceId");
    }

    @Override
    public String extractTraceId() {
        try {
            Object tracer = getTracerMethod.invoke(null);
            if (tracer != null) {
                Object span = activeSpanMethod.invoke(tracer);
                if (span != null) {
                    Object context = contextMethod.invoke(span);
                    if (context != null) {
                        String traceId = (String) toTraceIdMethod.invoke(context);
                        if (traceId != null && !traceId.isEmpty() && !"0".equals(traceId)) {
                            return traceId;
                        }
                    }
                }
            }
        } catch (Throwable t) {
            // Safe fallback
        }
        return null;
    }
}
