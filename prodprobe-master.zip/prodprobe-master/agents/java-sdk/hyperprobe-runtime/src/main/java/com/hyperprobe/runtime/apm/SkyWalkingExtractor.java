package com.hyperprobe.runtime.apm;

import java.lang.reflect.Method;

public class SkyWalkingExtractor implements ApmExtractor {
    private final Method traceIdMethod;

    public SkyWalkingExtractor(ClassLoader cl) throws Exception {
        Class<?> traceContextClass = Class.forName("org.apache.skywalking.apm.toolkit.trace.TraceContext", false, cl);
        this.traceIdMethod = traceContextClass.getMethod("traceId");
    }

    @Override
    public String extractTraceId() {
        try {
            String traceId = (String) traceIdMethod.invoke(null);
            if (traceId != null && !traceId.isEmpty() && !"EmptyTraceId".equalsIgnoreCase(traceId)) {
                return traceId;
            }
        } catch (Throwable t) {
            // Safe fallback
        }
        return null;
    }
}
