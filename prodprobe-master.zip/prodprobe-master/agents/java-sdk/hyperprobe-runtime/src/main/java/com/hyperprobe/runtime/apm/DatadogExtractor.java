package com.hyperprobe.runtime.apm;

import java.lang.reflect.Method;

public class DatadogExtractor implements ApmExtractor {
    private final Method getTraceIdMethod;

    public DatadogExtractor(ClassLoader cl) throws Exception {
        Class<?> correlationIdentifierClass = Class.forName("datadog.trace.api.CorrelationIdentifier", false, cl);
        this.getTraceIdMethod = correlationIdentifierClass.getMethod("getTraceId");
    }

    @Override
    public String extractTraceId() {
        try {
            String traceId = (String) getTraceIdMethod.invoke(null);
            if (traceId != null && !traceId.isEmpty() && !"0".equals(traceId)) {
                return traceId;
            }
        } catch (Throwable t) {
            // Safe fallback
        }
        return null;
    }
}
