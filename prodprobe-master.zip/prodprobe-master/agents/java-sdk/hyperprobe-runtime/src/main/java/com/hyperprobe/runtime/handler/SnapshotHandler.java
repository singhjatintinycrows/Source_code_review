package com.hyperprobe.runtime.handler;

import com.hyperprobe.runtime.ProbeContext;
import com.hyperprobe.runtime.domain.ProbeDefinition;
import com.hyperprobe.runtime.domain.TelemetryEvent;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class SnapshotHandler implements ProbeHandler {

    @Override
    public TelemetryEvent handle(ProbeDefinition def, ProbeContext ctx) {
        TelemetryEvent event = new TelemetryEvent(def.getId(), def.getType());
        com.hyperprobe.serializer.SerializationConfig globalConfig = com.hyperprobe.serializer.SerializationConfig.getInstance();

        // 1. Resolve limits (Probe override -> Global config fallback)
        int maxDepth = def.getMaxObjectDepth() != null ? def.getMaxObjectDepth() : globalConfig.getMaxObjectDepth();
        int maxArrayLength = def.getMaxArrayLength() != null ? def.getMaxArrayLength() : globalConfig.getMaxArrayLength();
        int stackDepth = def.getStackFrameDepth() != null ? def.getStackFrameDepth() : globalConfig.getStackFrameDepth();
        int maxObjectProps = def.getMaxObjectProperties() != null ? def.getMaxObjectProperties() : globalConfig.getMaxObjectProperties();
        int maxStringLength = def.getMaxStringLength() != null ? def.getMaxStringLength() : globalConfig.getMaxStringLength();

        // Create a custom config for this execution if overrides exist
        com.hyperprobe.serializer.SerializationConfig activeConfig = new com.hyperprobe.serializer.SerializationConfig(
                maxDepth, maxArrayLength, maxObjectProps, maxStringLength, stackDepth,
                globalConfig.getRedactKeys(), globalConfig.getRedactValues()
        );

        // 2. Capture stack trace (Respect resolved depth)
        event.setStackFrames(ctx.getStackTrace(activeConfig.getStackFrameDepth()));

        // 3. Safely limit the object graph of captured local variables
        com.hyperprobe.serializer.ObjectGraphLimiter limiter = 
            new com.hyperprobe.serializer.ObjectGraphLimiter(activeConfig);
        
        // 4. Evaluate watch expressions (Before snapshotting locals to match Node SDK order)
        List<String> watches = def.getWatchExpressions();
        if (watches != null && !watches.isEmpty()) {
            Map<String, Object> watchResults = new HashMap<>(watches.size());
            for (String watch : watches) {
                if (watchResults.containsKey(watch)) {
                    // Ignore exact duplicate expressions to prevent overwriting valid evaluations 
                    // with [CIRCULAR] references in the map.
                    continue;
                }
                
                try {
                    // Evaluate the expression using MVEL against the raw context variables
                    Object result = com.hyperprobe.evaluator.MvelEvaluator.evaluateExpression(watch, ctx.getLocalVariables());
                    
                    // We must also sanitize the result of the watch expression because it could be a large object graph
                    String escapedWatch = watch.replace("\\", "\\\\").replace("\"", "\\\"");
                    String watchPath = "watch[\"" + escapedWatch + "\"]";
                    Object sanitizedResult = limiter.sanitize(watchPath, result);
                    watchResults.put(watch, sanitizedResult);
                } catch (Throwable t) {
                    Throwable cause = t.getCause() != null ? t.getCause() : t;
                    watchResults.put(watch, "Error: " + cause.getMessage());
                }
            }
            event.setWatchResults(watchResults);
        }

        // 3. Safely limit the object graph of captured local variables
        Object sanitizedLocals = limiter.sanitize("frame[0].scopes[0]", ctx.getLocalVariables());
        if (sanitizedLocals instanceof Map) {
            // Safe cast since ProbeContext always builds a Map for local variables
            event.setCapturedVars((Map<String, Object>) sanitizedLocals);
        } else {
            // Safely fallback without passing the raw cyclic variables
            Map<String, Object> fallback = new HashMap<>();
            fallback.put("error", "Sanitization failed to produce a Map. Result: " + sanitizedLocals);
            event.setCapturedVars(fallback);
        }

        return event;
    }
}
