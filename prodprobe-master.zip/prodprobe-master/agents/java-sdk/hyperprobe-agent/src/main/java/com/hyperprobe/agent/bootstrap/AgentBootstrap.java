package com.hyperprobe.agent.bootstrap;

import java.lang.instrument.Instrumentation;
import java.net.URL;

/**
 * The standard JVM javaagent entry point.
 * This class is loaded by the System ClassLoader. Its primary responsibility
 * is to spin up the isolated AgentClassLoader and hand off execution to the
 * AgentInitializer, preventing the host app from seeing the agent's dependencies.
 */
public class AgentBootstrap {

    // Keep a strong reference to prevent the classloader from being garbage collected.
    // We MUST NOT set this as the Thread Context ClassLoader (TCCL) in premain,
    // as it would leak into the host application's main thread and corrupt framework boot sequences.
    private static AgentClassLoader agentClassLoader;

    public static void premain(String agentArgs, Instrumentation inst) {
        // 0. Check if agent is enabled
        String mode = System.getenv("HYPERPROBE_DISABLED");
        if ("YES".equalsIgnoreCase(mode)) {
            System.out.println("[HyperProbe] Explicitly disabled via HYPERPROBE_DISABLED.");
            return;
        }

        try {
            // 1. Resolve the location of the agent JAR currently running
            URL agentJarUrl = AgentBootstrap.class.getProtectionDomain().getCodeSource().getLocation();

            // 2. Create the isolated child-first classloader pointing to the FAT jar
            agentClassLoader = new AgentClassLoader(new URL[]{agentJarUrl}, AgentBootstrap.class.getClassLoader());

            // 3. Reflectively load and execute the AgentInitializer using the isolated classloader
            Class<?> initializerClass = agentClassLoader.loadClass("com.hyperprobe.agent.initializer.AgentInitializer");
            
            // Invoke: public static void initialize(String args, Instrumentation inst)
            initializerClass.getMethod("initialize", String.class, Instrumentation.class)
                            .invoke(null, agentArgs, inst);

        } catch (Throwable t) {
            System.err.println("[HyperProbe] : Failed to bootstrap Java");
            t.printStackTrace(System.err);
            System.err.flush();            
        }
    }
}
