package com.hyperprobe.agent.initializer;

import java.lang.instrument.Instrumentation;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;

import com.hyperprobe.agent.bootstrap.AgentBridge;
import com.hyperprobe.config.util.VersionUtils;
import com.hyperprobe.config.logging.HyperProbeLogger;
import com.hyperprobe.instrumentation.InstrumentationEngine;
import com.hyperprobe.core.HyperProbeAgent;
import com.hyperprobe.runtime.ProbeExecutionEngine;

/**
 * Initializes the agent components from within the isolated AgentClassLoader.
 * This class coordinates the startup sequence securely away from the host application.
 */
public class AgentInitializer {

    private static final HyperProbeLogger log = HyperProbeLogger.getLogger(AgentInitializer.class);

    /**
     * Called reflectively by AgentBootstrap.
     * 
     * @param args The javaagent arguments string.
     * @param inst The JVM Instrumentation instance.
     */
    public static void initialize(String args, Instrumentation inst) {
        log.forceInfo("HyperProbe JavaAgent version " + VersionUtils.getVersion() + " initialized.");
        try {
            // 1. Bind Bridge to the Runtime Engine securely via MethodHandle.
            // We do this first so any hits immediately delegate correctly.
            MethodHandles.Lookup lookup = MethodHandles.publicLookup();
            java.lang.invoke.MethodHandle handleHitMh = lookup.findStatic(
                ProbeExecutionEngine.class, 
                "handleHit", 
                MethodType.methodType(void.class, String.class, Object[].class)
            );
            AgentBridge.initialize(handleHitMh);

            // 2. Install ByteBuddy Instrumentation Layer
            InstrumentationEngine.install(inst);

            // 3. Start the Control Plane (Broker, Sync, Guardrails)
            HyperProbeAgent.start();

            log.debug("Java SDK Agent initialized successfully.");
        } catch (Throwable t) {
            log.error("CRITICAL: Agent initialization failed.", t);
        }
    }
}
