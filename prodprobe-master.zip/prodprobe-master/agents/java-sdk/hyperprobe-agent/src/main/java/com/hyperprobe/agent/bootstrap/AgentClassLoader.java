package com.hyperprobe.agent.bootstrap;

import java.net.URL;
import java.net.URLClassLoader;

public class AgentClassLoader extends URLClassLoader {

    static {
        ClassLoader.registerAsParallelCapable();
    }

    public AgentClassLoader(URL[] urls, ClassLoader parent) {
        super(urls, parent);
    }

    @Override
    protected Class<?> loadClass(String name, boolean resolve) throws ClassNotFoundException {
        synchronized (getClassLoadingLock(name)) {
            Class<?> c = findLoadedClass(name);
            if (c == null) {
                if (isIsolatedPackage(name)) {
                    try {
                        c = findClass(name);
                    } catch (ClassNotFoundException e) {
                    }
                }
                if (c == null) {
                    c = super.loadClass(name, false);
                }
            }
            if (resolve) {
                resolveClass(c);
            }
            return c;
        }
    }

    private boolean isIsolatedPackage(String name) {
        // This is to force usage of the agent's shaded dependencies and prevent any accidental usage from the host app that would cause linkage errors.
        // We allow "com.hyperprobe.agent.bootstrap" to be parent-loaded since it contains only the AgentBootstrap entry point and no dependencies,
        // but all other "com.hyperprobe.agent" classes must be child-loaded to ensure isolation.
        if (name.startsWith("com.hyperprobe.agent.bootstrap.")) {
            return false;
        }
        if (name.startsWith("hyperprobe.agent.")) {
            return true;
        }
        return name.startsWith("com.hyperprobe.") ;
    }
}
