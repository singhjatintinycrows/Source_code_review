package com.hyperprobe.agent.bootstrap;

import java.lang.invoke.MethodHandle;

/**
 * A highly lightweight bridge injected into the Application/Bootstrap ClassLoader.
 * 
 * This is the ONLY class that the instrumented application code directly calls.
 * It uses a MethodHandle to rapidly delegate execution to the isolated ProbeExecutionEngine
 * living in the AgentClassLoader, completely avoiding dependency leaks.
 */
public class AgentBridge {

    // Volatile for safe publication during initialization.
    private static volatile MethodHandle handleHitMethod;

    /**
     * Invoked internally by the AgentInitializer to bind the runtime engine.
     * @param targetMethod The MethodHandle pointing to ProbeExecutionEngine.handleHit
     */
    public static void initialize(MethodHandle targetMethod) {
        handleHitMethod = targetMethod;
    }

    /**
     * The callback method injected into the host application's bytecode via ByteBuddy/ASM.
     * Must execute extremely fast and NEVER throw exceptions that could crash the host app.
     *
     * @param probeId The ID of the probe that was hit.
     * @param locals  The captured local variables from the current stack frame.
     */
    public static void onLineHit(String probeId, Object[] locals) {
        MethodHandle mh = handleHitMethod;
        if (mh != null) {
            try {
                // Must perfectly match target signature: (String, Object[])void
                mh.invokeExact(probeId, locals);
            } catch (Throwable t) {
                // Extreme safety guardrail: do not crash the host application.
                // Normally we'd want to increment an internal error counter here via another handle,
                // but swallowing is the safest fallback to guarantee 0 impact on host crashes.
            }
        }
    }
}
