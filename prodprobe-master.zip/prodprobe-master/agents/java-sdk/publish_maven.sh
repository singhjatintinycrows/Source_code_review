#!/bin/bash

# Prompt for the version
read -p "Enter version to deploy: " VERSION

# Validate that a version was entered
if [ -z "$VERSION" ]; then
    echo "Version cannot be empty. Aborting."
    exit 1
fi

echo "Setting version to $VERSION..."
mvn versions:set -B -DnewVersion="$VERSION" -DprocessAllModules=true -DgenerateBackupPoms=false

echo "Running clean deploy..."

if [ -z "${MAVEN_GPG_PASSPHRASE:-}" ]; then
    JAVA_GPG_PASSPHRASE_FILE="${MAVEN_GPG_PASSPHRASE_FILE:-${HOME}/.config/hyperprobe-java-sdk-gpg-passphrase}"
    if [ -r "$JAVA_GPG_PASSPHRASE_FILE" ]; then
        export MAVEN_GPG_PASSPHRASE="$(<"$JAVA_GPG_PASSPHRASE_FILE")"
    fi
fi

mvn clean deploy -DskipTests
