package com.hyperprobe.serializer;

import com.hyperprobe.config.logging.HyperProbeLogger;

import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.atomic.AtomicReference;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

/**
 * Configuration for the serialization guardrails.
 */
public class SerializationConfig {
    
    private static final HyperProbeLogger log = HyperProbeLogger.getLogger(SerializationConfig.class);

    private final int maxObjectDepth;
    private final int maxArrayLength;
    private final int maxObjectProperties;
    private final int maxStringLength;
    private final int stackFrameDepth;
    private final List<String> redactKeys;
    private final List<String> redactValues;
    
    private final List<Pattern> compiledRedactKeys;
    private final List<Pattern> compiledRedactValues;

    // Thread-safe state for hot-swapping
    private static final AtomicReference<SerializationConfig> instance = 
        new AtomicReference<>(defaultConfig());

    public SerializationConfig(int maxObjectDepth, int maxArrayLength, 
                               int maxObjectProperties, int maxStringLength, 
                               int stackFrameDepth,
                               List<String> redactKeys, List<String> redactValues) {
        this.maxObjectDepth = maxObjectDepth;
        this.maxArrayLength = maxArrayLength;
        this.maxObjectProperties = maxObjectProperties;
        this.maxStringLength = maxStringLength;
        this.stackFrameDepth = stackFrameDepth;
        this.redactKeys = redactKeys != null ? redactKeys : Collections.emptyList();
        this.redactValues = redactValues != null ? redactValues : Collections.emptyList();
        
        this.compiledRedactKeys = compilePatternsSafely(this.redactKeys);
        this.compiledRedactValues = compilePatternsSafely(this.redactValues);
    }

    private List<Pattern> compilePatternsSafely(List<String> rawPatterns) {
        if (rawPatterns == null || rawPatterns.isEmpty()) {
            return Collections.emptyList();
        }
        return rawPatterns.stream()
                .map(patternStr -> {
                    if (patternStr == null || patternStr.trim().isEmpty()) {
                        return null;
                    }
                    // Prevent catastrophic ReDoS from massive regex payloads
                    if (patternStr.length() > 256) {
                        log.error("Redaction pattern rejected (exceeds max length of 256 chars): " + patternStr);
                        return null;
                    }
                    try {
                        return Pattern.compile(patternStr, Pattern.CASE_INSENSITIVE);
                    } catch (Exception e) {
                        log.error("Invalid redaction pattern dropped: " + patternStr + " - " + e.getMessage());
                        return null;
                    }
                })
                .filter(Objects::nonNull)
                .collect(Collectors.toList());
    }

    public static SerializationConfig getInstance() {
        return instance.get();
    }

    public static void updateConfig(int maxObjectDepth, int maxArrayLength, 
                                    int maxObjectProperties, int maxStringLength, 
                                    int stackFrameDepth,
                                    List<String> redactKeys, List<String> redactValues) {
        SerializationConfig current = instance.get();
        
        // Merge rules: Keep current value if new value is empty/invalid
        List<String> newRedactKeys = (redactKeys != null && !redactKeys.isEmpty()) ? redactKeys : current.getRedactKeys();
        List<String> newRedactValues = (redactValues != null && !redactValues.isEmpty()) ? redactValues : current.getRedactValues();
        
        int newMaxDepth = maxObjectDepth > 0 ? maxObjectDepth : current.getMaxObjectDepth();
        int newMaxArrayLength = maxArrayLength > 0 ? maxArrayLength : current.getMaxArrayLength();
        int newMaxObjectProperties = maxObjectProperties > 0 ? maxObjectProperties : current.getMaxObjectProperties();
        int newMaxStringLength = maxStringLength > 0 ? maxStringLength : current.getMaxStringLength();
        int newStackDepth = stackFrameDepth > 0 ? stackFrameDepth : current.getStackFrameDepth();

        instance.set(new SerializationConfig(
                newMaxDepth, 
                newMaxArrayLength, 
                newMaxObjectProperties, 
                newMaxStringLength, 
                newStackDepth,
                newRedactKeys, 
                newRedactValues
        ));
    }

    // Default configuration
    public static SerializationConfig defaultConfig() {
        return new SerializationConfig(
            3, 
            3,
            50, 
            1024, 
            3, // Default stack depth matching Node.js
            List.of("password", "secret", "token", "authorization", "cookie", "key", "signature"), 
            Collections.emptyList()
        );
    }

    public int getMaxObjectDepth() { return maxObjectDepth; }
    public int getMaxArrayLength() { return maxArrayLength; }
    public int getMaxObjectProperties() { return maxObjectProperties; }
    public int getMaxStringLength() { return maxStringLength; }
    public int getStackFrameDepth() { return stackFrameDepth; }
    public List<String> getRedactKeys() { return redactKeys; }
    public List<String> getRedactValues() { return redactValues; }
    public List<Pattern> getCompiledRedactKeys() { return compiledRedactKeys; }
    public List<Pattern> getCompiledRedactValues() { return compiledRedactValues; }
}
