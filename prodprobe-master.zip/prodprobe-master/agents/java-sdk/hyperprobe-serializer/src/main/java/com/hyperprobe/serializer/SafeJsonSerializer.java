package com.hyperprobe.serializer;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;

/**
 * Entry point for safe object serialization.
 * Enforces limits and prevents JVM crashes before delegating to Jackson.
 */
public class SafeJsonSerializer {

    // Thread-safe ObjectMapper
    private static final ObjectMapper MAPPER = new ObjectMapper()
            .disable(SerializationFeature.FAIL_ON_EMPTY_BEANS);

    /**
     * Serializes a pre-sanitized object directly to JSON.
     * Use this ONLY when the object has already been safely passed through ObjectGraphLimiter
     * to avoid double-truncation bugs.
     *
     * @param value The pre-sanitized object to serialize.
     * @return A JSON string representation of the object.
     */
    public static String serializeSanitized(Object value) {
        if (value == null) {
            return "null";
        }
        try {
            return MAPPER.writeValueAsString(value);
        } catch (JsonProcessingException e) {
            try {
                return MAPPER.writeValueAsString(java.util.Collections.singletonMap("<serialization-error>", e.getMessage()));
            } catch (JsonProcessingException inner) {
                return "{\"<fatal-error>\":\"Serialization aborted safely\"}";
            }
        } catch (Throwable t) {
            return "{\"<fatal-error>\":\"Serialization aborted safely\"}";
        }
    }

    /**
     * Serializes an arbitrary object to a JSON string safely.
     * Enforces limits and prevents JVM crashes before delegating to Jackson.
     *
     * @param value  The object to serialize.
     * @param config The guardrail configuration.
     * @return A JSON string representation of the sanitized object.
     */
    public static String serialize(Object value, SerializationConfig config) {
        if (value == null) {
            return "null";
        }

        try {
            // 1. Traverse and sanitize the object graph to enforce guardrails
            ObjectGraphLimiter limiter = new ObjectGraphLimiter(config);
            Object sanitized = limiter.sanitize(value);

            // 2. Delegate to Jackson to convert the sanitized Map/List graph to JSON
            return MAPPER.writeValueAsString(sanitized);

        } catch (JsonProcessingException e) {
            try {
                return MAPPER.writeValueAsString(java.util.Collections.singletonMap("<serialization-error>", e.getMessage()));
            } catch (JsonProcessingException inner) {
                return "{\"<fatal-error>\":\"Serialization aborted safely\"}";
            }
        } catch (Throwable t) {
            // Final safety net: Never crash the host thread on serialization failures
            return "{\"<fatal-error>\":\"Serialization aborted safely\"}";
        }
    }
}
