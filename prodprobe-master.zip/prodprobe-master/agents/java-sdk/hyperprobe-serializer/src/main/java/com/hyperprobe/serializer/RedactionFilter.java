package com.hyperprobe.serializer;

import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Applies redaction rules based on configured keys and values.
 */
public class RedactionFilter {

    private final List<Pattern> redactKeys;
    private final List<Pattern> redactValues;

    public RedactionFilter(SerializationConfig config) {
        this.redactKeys = config.getCompiledRedactKeys();
        this.redactValues = config.getCompiledRedactValues();
    }

    /**
     * Checks if a key should be redacted based on regex match.
     */
    public boolean shouldRedactKey(String key) {
        if (key == null || redactKeys.isEmpty()) {
            return false;
        }
        for (Pattern redactKey : redactKeys) {
            if (redactKey.matcher(key).find()) {
                return true;
            }
        }
        return false;
    }

    /**
     * Redacts portions of a string value based on regex match.
     * Returns the original string if no rules match.
     */
    public String redactValue(String value) {
        if (value == null || redactValues.isEmpty()) {
            return value;
        }
        
        String result = value;
        for (Pattern redactValue : redactValues) {
            Matcher m = redactValue.matcher(result);
            if (m.find()) {
                result = m.replaceAll("[REDACTED Value]");
            }
        }
        return result;
    }
}
