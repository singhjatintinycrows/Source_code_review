package com.hyperprobe.serializer;

import java.lang.reflect.Array;
import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.time.format.DateTimeFormatter;
import java.time.temporal.TemporalAccessor;
import java.util.*;

/**
 * Traverses an object graph safely, enforcing limits, detecting cycles,
 * and producing a sanitized Map/List/Primitive structure ready for simple JSON encoding.
 * 
 * Instantiated per serialization to maintain cyclic graph state safely.
 */
public class ObjectGraphLimiter {

    private final SerializationConfig config;
    private final RedactionFilter redactionFilter;
    
    // IdentityHashMap used to detect cyclic references and track their paths
    private final Map<Object, String> visitedPaths = new IdentityHashMap<>();

    // Implement a static cache for reflected fields to avoid runtime lookup overhead
    private static final Map<Class<?>, List<Field>> FIELD_CACHE = new java.util.concurrent.ConcurrentHashMap<>();

    public ObjectGraphLimiter(SerializationConfig config) {
        this.config = config;
        this.redactionFilter = new RedactionFilter(config);
    }

    public Object sanitize(Object obj) {
        return traverse(obj, "", 0);
    }

    public Object sanitize(String rootPath, Object obj) {
        return traverse(obj, rootPath, 0);
    }

    private Object traverse(Object obj, String path, int currentDepth) {
        if (obj == null) {
            return null;
        }

        // 1. Primitives, Wrappers, and basic immutable types
        if (obj instanceof java.math.BigInteger) {
            return obj.toString() + "n";
        }
        if (obj instanceof java.math.BigDecimal) {
            return obj.toString(); 
        }
        if (isPrimitiveOrWrapper(obj.getClass())) {
            return obj;
        }

        // 2. Strings
        if (obj instanceof String || obj instanceof CharSequence) {
            return handleString(obj.toString());
        }

        // 3. Cyclic Reference Check (CRITICAL: Must stay enabled to prevent JVM crash)
        if (visitedPaths.containsKey(obj)) {
            return "[REF - " + visitedPaths.get(obj) + "]";
        }

        // 4. Special Type: Date/Time (ISO-8601 Parity)
        if (obj instanceof Date || obj instanceof Calendar || obj instanceof TemporalAccessor) {
            return handleDate(obj);
        }

        // 5. Special Type: Throwable (Error Parity)
        if (obj instanceof Throwable) {
            return handleThrowable((Throwable) obj, path, currentDepth);
        }

        // 5b. Special Type: StackTraceElement
        if (obj instanceof StackTraceElement) {
            return handleStackTraceElement((StackTraceElement) obj);
        }

        // 6. Depth Limit Check
        if (currentDepth > config.getMaxObjectDepth()) {
            return getSummary(obj);
        }

        visitedPaths.put(obj, path);

        // 7. Arrays
        if (obj.getClass().isArray()) {
            return handleArray(obj, path, currentDepth);
        }

        // 8. Collections (Lists, Sets)
        if (obj instanceof Iterable) {
            return handleIterable((Iterable<?>) obj, path, currentDepth);
        }

        // 9. Maps
        if (obj instanceof Map) {
            return handleMap((Map<?, ?>) obj, path, currentDepth);
        }

        // 10. Custom Objects (Reflection)
        return handleCustomObject(obj, path, currentDepth);
    }

    private boolean isPrimitiveOrWrapper(Class<?> type) {
        return type.isPrimitive() || type == Double.class || type == Float.class || type == Long.class ||
               type == Integer.class || type == Short.class || type == Character.class ||
               type == Byte.class || type == Boolean.class || java.util.UUID.class.isAssignableFrom(type);
    }

    private Object getSummary(Object obj) {
        if (obj instanceof Iterable) {
            int len = (obj instanceof Collection) ? ((Collection<?>) obj).size() : -1;
            return len >= 0 ? "[Arr: " + len + "]" : "[Arr]";
        } else if (obj.getClass().isArray()) {
            return "[Arr: " + Array.getLength(obj) + "]";
        } else if (obj instanceof Map) {
            return "[Obj: " + ((Map<?, ?>) obj).size() + " props]";
        } else {
            return "[Obj]";
        }
    }

    private String handleString(String str) {
        String redacted = redactionFilter.redactValue(str);
        int limit = config.getMaxStringLength();
        if (redacted.length() > limit) {
            String head = redacted.substring(0, limit);
            int lastSpace = head.lastIndexOf(' ');
            String truncatedHead = lastSpace > 0 ? head.substring(0, lastSpace) : head;
            int remaining = redacted.length() - limit;
            return truncatedHead + "... [Truncated: +" + remaining + " more chars]";
        }
        return redacted;
    }

    private Object handleDate(Object obj) {
        try {
            if (obj instanceof Date) {
                return ((Date) obj).toInstant().toString();
            } else if (obj instanceof Calendar) {
                return ((Calendar) obj).toInstant().toString();
            } else if (obj instanceof TemporalAccessor) {
                return DateTimeFormatter.ISO_INSTANT.format((TemporalAccessor) obj);
            }
        } catch (Exception e) {
            return obj.toString();
        }
        return obj.toString();
    }

    private Map<String, Object> handleThrowable(Throwable t, String path, int depth) {
        Map<String, Object> errorMap = new LinkedHashMap<>();
        errorMap.put("name", t.getClass().getSimpleName());
        errorMap.put("message", t.getMessage());
        
        StackTraceElement[] frames = t.getStackTrace();
        if (frames != null && frames.length > 0) {
            StringBuilder sb = new StringBuilder();
            int limit = Math.min(frames.length, 3);
            for (int i = 0; i < limit; i++) {
                sb.append(frames[i].toString()).append("\n");
            }
            if (frames.length > 3) {
                sb.append("...");
            }
            errorMap.put("stack", sb.toString().trim());
        }
        return errorMap;
    }

    private Map<String, Object> handleStackTraceElement(StackTraceElement ste) {
        Map<String, Object> map = new LinkedHashMap<>();
            map.put("className", ste.getClassName());
        map.put("methodName", ste.getMethodName());
        map.put("fileName", ste.getFileName());
        map.put("lineNumber", ste.getLineNumber());
        return map;
    }

    private List<Object> handleIterable(Iterable<?> iterable, String path, int depth) {
        List<Object> safeList = new ArrayList<>();
        int count = 0;
        int totalSize = (iterable instanceof Collection) ? ((Collection<?>) iterable).size() : -1;

        for (Object item : iterable) {
            if (count >= config.getMaxArrayLength()) {
                int remaining = (totalSize != -1) ? (totalSize - count) : -1;
                String msg = (remaining >= 0) ? "[+ " + remaining + " more items truncated]" : "[+ more items truncated]";
                safeList.add(msg);
                break;
            }
            safeList.add(traverse(item, path + "[" + count + "]", depth + 1));
            count++;
        }
        return safeList;
    }

    private List<Object> handleArray(Object array, String path, int depth) {
        int length = Array.getLength(array);
        int safeLength = Math.min(length, config.getMaxArrayLength());
        List<Object> safeList = new ArrayList<>(safeLength + (length > safeLength ? 1 : 0));

        for (int i = 0; i < safeLength; i++) {
            safeList.add(traverse(Array.get(array, i), path + "[" + i + "]", depth + 1));
        }

        if (length > safeLength) {
            safeList.add("[+ " + (length - safeLength) + " more items truncated]");
        }

        return safeList;
    }

    private Map<String, Object> handleMap(Map<?, ?> map, String path, int depth) {
        Map<String, Object> safeMap = new LinkedHashMap<>();
        int count = 0;
        for (Map.Entry<?, ?> entry : map.entrySet()) {
            if (count >= config.getMaxObjectProperties()) {
                int remainingCount = map.size() - count;
                safeMap.put("__probe_meta", "+ " + remainingCount + " more properties truncated");
                break;
            }

            String keyStr = String.valueOf(entry.getKey());
            String subPath = path + (path.isEmpty() ? "" : ".") + keyStr;

            if (redactionFilter.shouldRedactKey(keyStr)) {
                safeMap.put(keyStr, "[REDACTED Key]");
            } else {
                safeMap.put(keyStr, traverse(entry.getValue(), subPath, depth + 1));
            }
            count++;
        }
        return safeMap;
    }

    private Map<String, Object> handleCustomObject(Object obj, String path, int depth) {
        Map<String, Object> safeObject = new LinkedHashMap<>();
        Class<?> clazz = obj.getClass();
        
        // safeObject.put("@class", clazz.getSimpleName());
        
        List<Field> allFields = FIELD_CACHE.computeIfAbsent(clazz, c -> {
            List<Field> fields = new ArrayList<>();
            Class<?> current = c;
            while (current != null && current != Object.class) {
                for (Field field : current.getDeclaredFields()) {
                    if (!Modifier.isStatic(field.getModifiers())) {
                        try {
                            field.setAccessible(true);
                            fields.add(field);
                        } catch (Exception e) {
                            // Skip fields that cannot be made accessible (e.g. due to strong JDK encapsulation in Java 16+)
                        }
                    }
                }
                current = current.getSuperclass();
            }
            return fields;
        });

        int count = 0;
        for (Field field : allFields) {
            if (count >= config.getMaxObjectProperties()) {
                safeObject.put("__probe_meta", "+ " + (allFields.size() - count) + " more properties truncated");
                break;
            }

            String fieldName = field.getName();
            String subPath = path + (path.isEmpty() ? "" : ".") + fieldName;

            if (redactionFilter.shouldRedactKey(fieldName)) {
                safeObject.put(fieldName, "[REDACTED Key]");
                count++;
                continue;
            }

            try {
                Object value = field.get(obj);
                safeObject.put(fieldName, traverse(value, subPath, depth + 1));
            } catch (Exception e) {
                safeObject.put(fieldName, "<inaccessible>");
            }
            count++;
        }
        
        return safeObject;
    }
}
