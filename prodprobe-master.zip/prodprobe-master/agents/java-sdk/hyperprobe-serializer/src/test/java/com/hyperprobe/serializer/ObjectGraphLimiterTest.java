package com.hyperprobe.serializer;

import org.junit.Test;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

public class ObjectGraphLimiterTest {

    static class CircularNode {
        public String name;
        public CircularNode circular;

        public CircularNode(String name) {
            this.name = name;
        }
    }

    @Test
    public void testPrimitiveArrayTruncation() {
        // Force config: Max array length = 3
        SerializationConfig config = new SerializationConfig(
            3, 3, 50, 1024, 3, Collections.emptyList(), Collections.emptyList()
        );
        ObjectGraphLimiter limiter = new ObjectGraphLimiter(config);

        int[] arr = {10, 20, 30, 40, 50, 60};
        
        Object result = limiter.sanitize(arr);
        
        assertTrue("Result should be a List", result instanceof List);
        List<?> list = (List<?>) result;
        
        // Expected size: 3 items + 1 truncation message = 4
        assertEquals(4, list.size());
        assertEquals(10, list.get(0));
        assertEquals(20, list.get(1));
        assertEquals(30, list.get(2));
        assertEquals("[+ 3 more items truncated]", list.get(3));
        
        System.out.println("Test Output: " + list);
    }

    @Test
    public void testCircularReferenceWithFrameScope() {
        SerializationConfig config = new SerializationConfig(
            3, 3, 50, 1024, 3, Collections.emptyList(), Collections.emptyList()
        );
        ObjectGraphLimiter limiter = new ObjectGraphLimiter(config);

        CircularNode node = new CircularNode("test");
        node.circular = node;

        Map<String, Object> locals = new HashMap<>();
        locals.put("node", node);

        Object result = limiter.sanitize("frame[0].scopes[0]", locals);
        assertTrue(result instanceof Map);
        Map<?, ?> map = (Map<?, ?>) result;
        Map<?, ?> nodeMap = (Map<?, ?>) map.get("node");
        assertEquals("test", nodeMap.get("name"));
        assertEquals("[REF - frame[0].scopes[0].node]", nodeMap.get("circular"));
    }

    @Test
    public void testWatchToLocalReference() {
        SerializationConfig config = new SerializationConfig(
            3, 3, 50, 1024, 3, Collections.emptyList(), Collections.emptyList()
        );
        ObjectGraphLimiter limiter = new ObjectGraphLimiter(config);

        CircularNode session = new CircularNode("user-123");
        session.circular = session;

        // 1. Sanitize watch first
        Object watchSanitized = limiter.sanitize("watch[\"userSession\"]", session);
        assertTrue(watchSanitized instanceof Map);
        Map<?, ?> watchMap = (Map<?, ?>) watchSanitized;
        assertEquals("user-123", watchMap.get("name"));
        assertEquals("[REF - watch[\"userSession\"]]", watchMap.get("circular"));

        // 2. Sanitize locals containing the same session object
        Map<String, Object> locals = new HashMap<>();
        locals.put("userSession", session);

        Object localsSanitized = limiter.sanitize("frame[0].scopes[0]", locals);
        assertTrue(localsSanitized instanceof Map);
        Map<?, ?> localsMap = (Map<?, ?>) localsSanitized;
        assertEquals("[REF - watch[\"userSession\"]]", localsMap.get("userSession"));
    }
}
