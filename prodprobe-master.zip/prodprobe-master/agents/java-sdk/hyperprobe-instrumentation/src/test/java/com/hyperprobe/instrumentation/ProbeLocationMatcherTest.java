package com.hyperprobe.instrumentation;

import com.hyperprobe.runtime.domain.ProbeDefinition;
import net.bytebuddy.description.type.TypeDescription;
import org.junit.Test;
import java.util.Collections;
import java.util.Map;
import java.util.Set;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

public class ProbeLocationMatcherTest {

    @Test
    public void testJavaFileMapping() {
        Set<String> fqcns = ProbeLocationMatcher.mapRuntimeFileToFqcn("src/main/java/com/hyperprobe/demo/App.java", "");
        assertEquals(1, fqcns.size());
        assertTrue(fqcns.contains("com.hyperprobe.demo.App"));
    }

    @Test
    public void testKotlinFileMapping() {
        Set<String> fqcns = ProbeLocationMatcher.mapRuntimeFileToFqcn("src/main/kotlin/com/hyperprobe/demo/App.kt", "");
        assertEquals(2, fqcns.size());
        assertTrue(fqcns.contains("com.hyperprobe.demo.App"));
        assertTrue(fqcns.contains("com.hyperprobe.demo.AppKt"));
    }

    @Test
    public void testInnerClassProbeResolution() {
        ProbeLocationMatcher matcher = new ProbeLocationMatcher();
        ProbeDefinition probe = new ProbeDefinition(
                "probe-1",
                null,
                null,
                "src/main/java/com/hyperprobe/demo/App.java",
                10,
                null,
                null, null, null,
                null, null,
                null, null, null, null,
                0, 0,
                null, null, null, null, null,
                false, null, false
        );

        matcher.updateProbesAndGetChangedClasses(Collections.singletonList(probe));

        Map<Integer, Set<String>> outerProbes = matcher.getProbesForClass("com.hyperprobe.demo.App");
        assertNotNull(outerProbes);

        Map<Integer, Set<String>> innerProbes = matcher.getProbesForClass("com.hyperprobe.demo.App$1");
        assertNotNull(innerProbes);
        assertEquals(outerProbes, innerProbes);

        Map<Integer, Set<String>> nestedInnerProbes = matcher.getProbesForClass("com.hyperprobe.demo.App$Inner$1");
        assertNotNull(nestedInnerProbes);
        assertEquals(outerProbes, nestedInnerProbes);
    }

    @Test
    public void testKotlinProbeRegisteredByPackageAndSourceFile() {
        ProbeLocationMatcher matcher = new ProbeLocationMatcher();
        ProbeDefinition probe = probeAt(
                "probe-dtos",
                "src/main/kotlin/com/hyperprobe/demo/model/Dtos.kt",
                27);

        ProbeLocationMatcher.ProbeUpdateResult update =
                matcher.updateProbes(Collections.singletonList(probe));

        // No filename-derived class is registered: Dtos.kt may contain any number
        // of classes with names unrelated to the source filename.
        assertNull(matcher.getProbesForClass("com.hyperprobe.demo.model.Dtos"));
        assertNull(matcher.getProbesForClass("com.hyperprobe.demo.model.CheckoutResponseDto"));

        Map<String, Map<Integer, Set<String>>> sourceProbes =
                matcher.getKotlinSourceProbesForClass("com.hyperprobe.demo.model.CheckoutResponseDto");
        assertNotNull(sourceProbes);
        assertTrue(sourceProbes.get("Dtos.kt").get(27).contains("probe-dtos"));

        assertTrue(update.matches("com.hyperprobe.demo.model.CheckoutRequestDto"));
        assertTrue(update.matches("com.hyperprobe.demo.model.CheckoutResponseDto"));
        assertTrue(update.matches("com.hyperprobe.demo.model.CheckoutResponseDto", "Dtos.kt"));
        assertFalse(update.matches("com.hyperprobe.demo.model.Unrelated", "Unrelated.kt"));
        assertFalse(update.matches("com.hyperprobe.demo.model.nested.Unrelated"));
        assertNull(matcher.getKotlinSourceProbesForClass("com.hyperprobe.demo.other.Unrelated"));

        assertTrue(matcher.updateProbes(Collections.singletonList(probe)).isEmpty());
        ProbeLocationMatcher.ProbeUpdateResult removal =
                matcher.updateProbes(Collections.emptyList());
        assertTrue(removal.matches("com.hyperprobe.demo.model.CheckoutResponseDto", "Dtos.kt"));
        assertFalse(removal.matches("com.hyperprobe.demo.model.Unrelated", "Unrelated.kt"));
    }

    @Test
    public void testClassSourceFileCanBeReadWithoutTransformingClass() {
        assertEquals(
                "ProbeLocationMatcherTest.java",
                ProbeClassTransformer.getSourceFileName(
                        ProbeLocationMatcherTest.class.getName(),
                        ProbeLocationMatcherTest.class.getClassLoader()));
    }

    @Test
    public void testRawTypeMatchRejectsDifferentSourceInSamePackage() {
        ProbeLocationMatcher matcher = new ProbeLocationMatcher();
        matcher.updateProbes(Collections.singletonList(probeAt(
                "probe-other-source",
                "src/main/kotlin/com/hyperprobe/instrumentation/Dtos.kt",
                10)));

        assertFalse(matcher.matchesType(
                new TypeDescription.ForLoadedType(ProbeLocationMatcherTest.class),
                ProbeLocationMatcherTest.class.getClassLoader()));
    }

    private ProbeDefinition probeAt(String id, String runtimeLocation, int runtimeLine) {
        return new ProbeDefinition(
                id,
                null,
                null,
                runtimeLocation,
                runtimeLine,
                null,
                null, null, null,
                null, null,
                null, null, null, null,
                0, 0,
                null, null, null, null, null,
                false, null, false
        );
    }
}
