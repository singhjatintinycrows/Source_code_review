package com.hyperprobe.instrumentation;

import net.bytebuddy.description.type.TypeDescription;
import org.junit.Test;
import org.objectweb.asm.ClassVisitor;
import org.objectweb.asm.Label;
import org.objectweb.asm.Opcodes;
import org.objectweb.asm.tree.AbstractInsnNode;
import org.objectweb.asm.tree.ClassNode;
import org.objectweb.asm.tree.LdcInsnNode;
import org.objectweb.asm.tree.MethodNode;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import static org.junit.Assert.*;

public class LineNumberAsmVisitorTest {

    @Test
    public void testSyntheticBridgeMethodSkipped() {
        ClassNode cn = new ClassNode(Opcodes.ASM9);
        cn.name = "com/example/MyService";

        // Add a normal method
        MethodNode normalMethod = new MethodNode(Opcodes.ASM9, Opcodes.ACC_PUBLIC, "process", "(Ljava/lang/String;)V", null, null);
        Label l1 = new Label();
        normalMethod.visitLabel(l1);
        normalMethod.visitLineNumber(10, l1);
        normalMethod.visitLdcInsn("hello");
        normalMethod.visitInsn(Opcodes.RETURN);
        cn.methods.add(normalMethod);

        // Add a synthetic bridge method sharing line 10
        MethodNode bridgeMethod = new MethodNode(Opcodes.ASM9, Opcodes.ACC_PUBLIC | Opcodes.ACC_BRIDGE | Opcodes.ACC_SYNTHETIC, "process", "(Ljava/lang/Object;)V", null, null);
        Label l2 = new Label();
        bridgeMethod.visitLabel(l2);
        bridgeMethod.visitLineNumber(10, l2);
        bridgeMethod.visitLdcInsn("hello");
        bridgeMethod.visitInsn(Opcodes.RETURN);
        cn.methods.add(bridgeMethod);

        Map<Integer, Set<String>> classProbes = new HashMap<>();
        classProbes.put(10, Collections.singleton("probe-1"));

        LineNumberAsmVisitor visitor = new LineNumberAsmVisitor(classProbes);
        TypeDescription typeDesc = new TypeDescription.ForLoadedType(Object.class);
        ClassNode targetCn = new ClassNode(Opcodes.ASM9);
        ClassVisitor cv = visitor.wrap(typeDesc, targetCn, null, null, null, null, 0, 0);

        // Feed the ClassNode to visitEnd
        cn.accept(cv);

        // Find methods in targetCn
        MethodNode normalRes = targetCn.methods.stream().filter(m -> "(Ljava/lang/String;)V".equals(m.desc)).findFirst().orElse(null);
        MethodNode bridgeRes = targetCn.methods.stream().filter(m -> "(Ljava/lang/Object;)V".equals(m.desc)).findFirst().orElse(null);

        assertNotNull(normalRes);
        assertNotNull(bridgeRes);
        assertTrue("Normal method should be instrumented", hasProbeInjected(normalRes, "probe-1"));
        assertFalse("Synthetic bridge method must not be instrumented", hasProbeInjected(bridgeRes, "probe-1"));
    }

    @Test
    public void testKotlinSyntheticDefaultConstructorSkipped() {
        MethodNode constructor = new MethodNode(
                Opcodes.ASM9,
                Opcodes.ACC_PUBLIC | Opcodes.ACC_SYNTHETIC,
                "<init>",
                "(ILkotlin/jvm/internal/DefaultConstructorMarker;)V",
                null,
                null);
        Label lineLabel = new Label();
        constructor.visitLabel(lineLabel);
        constructor.visitLineNumber(26, lineLabel);
        constructor.visitInsn(Opcodes.RETURN);

        Map<Integer, Set<String>> classProbes = new HashMap<>();
        classProbes.put(26, Collections.singleton("probe-constructor"));

        ClassNode sourceCn = cnWithCustomName("com/example/KotlinDto", constructor);
        sourceCn.methods.add(methodAtLine("primaryConstructorBody", 30));
        ClassNode targetCn = applyVisitor(
                sourceCn,
                LineNumberAsmVisitor.forKotlinSource(classProbes));

        assertFalse(
                "Kotlin synthetic constructors must not capture uninitialized this",
                hasProbeInjected(targetCn.methods.get(0), "probe-constructor"));
    }

    @Test
    public void testLineSlidingCanCrossMethodBoundary() {
        MethodNode firstMethod = new MethodNode(Opcodes.ASM9, Opcodes.ACC_PUBLIC, "first", "()V", null, null);
        Label l1 = new Label();
        firstMethod.visitLabel(l1);
        firstMethod.visitLineNumber(10, l1);
        firstMethod.visitInsn(Opcodes.RETURN);

        MethodNode secondMethod = new MethodNode(Opcodes.ASM9, Opcodes.ACC_PUBLIC, "second", "()V", null, null);
        Label l2 = new Label();
        secondMethod.visitLabel(l2);
        secondMethod.visitLineNumber(30, l2);
        secondMethod.visitInsn(Opcodes.RETURN);

        Map<Integer, Set<String>> classProbes = new HashMap<>();
        classProbes.put(20, Collections.singleton("probe-cross-method"));

        LineNumberAsmVisitor visitor = new LineNumberAsmVisitor(classProbes);
        ClassNode targetCn = new ClassNode(Opcodes.ASM9);
        TypeDescription typeDesc = new TypeDescription.ForLoadedType(Object.class);
        ClassVisitor cv = visitor.wrap(typeDesc, targetCn, null, null, null, null, 0, 0);

        ClassNode sourceCn = new ClassNode(Opcodes.ASM9);
        sourceCn.name = "com/example/MyService";
        sourceCn.methods.add(firstMethod);
        sourceCn.methods.add(secondMethod);
        sourceCn.accept(cv);

        assertFalse("Earlier method should not be instrumented", hasProbeInjected(targetCn.methods.get(0), "probe-cross-method"));
        assertTrue("Probe should slide to the next executable line in a later method", hasProbeInjected(targetCn.methods.get(1), "probe-cross-method"));
    }

    @Test
    public void testLineSlidingAllowsArbitraryDistance() {
        MethodNode method = new MethodNode(Opcodes.ASM9, Opcodes.ACC_PUBLIC, "doWork", "()V", null, null);
        Label lineLabel = new Label();
        method.visitLabel(lineLabel);
        method.visitLineNumber(100, lineLabel);
        method.visitInsn(Opcodes.RETURN);

        Map<Integer, Set<String>> classProbes = new HashMap<>();
        classProbes.put(10, Collections.singleton("probe-long-slide"));

        LineNumberAsmVisitor visitor = new LineNumberAsmVisitor(classProbes);
        ClassNode targetCn = new ClassNode(Opcodes.ASM9);
        TypeDescription typeDesc = new TypeDescription.ForLoadedType(Object.class);
        ClassVisitor cv = visitor.wrap(typeDesc, targetCn, null, null, null, null, 0, 0);

        cnWithCustomName("com/example/MyService", method).accept(cv);

        assertTrue(
                "Probe should slide to the next executable line regardless of distance",
                hasProbeInjected(targetCn.methods.get(0), "probe-long-slide"));
    }

    @Test
    public void testLineSlidingDoesNotBindWithoutLaterExecutableLine() {
        MethodNode method = new MethodNode(Opcodes.ASM9, Opcodes.ACC_PUBLIC, "doWork", "()V", null, null);
        Label lineLabel = new Label();
        method.visitLabel(lineLabel);
        method.visitLineNumber(10, lineLabel);
        method.visitInsn(Opcodes.RETURN);

        Map<Integer, Set<String>> classProbes = new HashMap<>();
        classProbes.put(20, Collections.singleton("probe-after-last-line"));

        LineNumberAsmVisitor visitor = new LineNumberAsmVisitor(classProbes);
        ClassNode targetCn = new ClassNode(Opcodes.ASM9);
        TypeDescription typeDesc = new TypeDescription.ForLoadedType(Object.class);
        ClassVisitor cv = visitor.wrap(typeDesc, targetCn, null, null, null, null, 0, 0);

        cnWithCustomName("com/example/MyService", method).accept(cv);

        assertFalse(
                "Probe should not bind when the class has no later executable line",
                hasProbeInjected(targetCn.methods.get(0), "probe-after-last-line"));
    }

    @Test
    public void testKotlinSourceAwareVisitorInstrumentsMatchingSourceFile() {
        Map<Integer, Set<String>> sourceProbes = new HashMap<>();
        sourceProbes.put(27, Collections.singleton("probe-dtos"));
        Map<String, Map<Integer, Set<String>>> probesBySource = new HashMap<>();
        probesBySource.put("Dtos.kt", sourceProbes);

        MethodNode method = methodAtLine("getTimestamp", 27);
        ClassNode sourceCn = cnWithCustomName("com/hyperprobe/demo/model/CheckoutResponseDto", method);
        sourceCn.sourceFile = "Dtos.kt";

        ClassNode targetCn = applyVisitor(
                sourceCn,
                LineNumberAsmVisitor.forKotlinSources(probesBySource));

        assertTrue(hasProbeInjected(targetCn.methods.get(0), "probe-dtos"));
    }

    @Test
    public void testKotlinSourceAwareVisitorLeavesOtherFilesUntouched() {
        Map<Integer, Set<String>> sourceProbes = new HashMap<>();
        sourceProbes.put(27, Collections.singleton("probe-dtos"));
        Map<String, Map<Integer, Set<String>>> probesBySource = new HashMap<>();
        probesBySource.put("Dtos.kt", sourceProbes);

        MethodNode method = methodAtLine("unrelated", 27);
        ClassNode sourceCn = cnWithCustomName("com/hyperprobe/demo/model/Unrelated", method);
        sourceCn.sourceFile = "Unrelated.kt";

        ClassNode targetCn = applyVisitor(
                sourceCn,
                LineNumberAsmVisitor.forKotlinSources(probesBySource));

        assertFalse(hasProbeInjected(targetCn.methods.get(0), "probe-dtos"));
    }

    @Test
    public void testKotlinSourceAwareVisitorDoesNotSlideIntoLaterClassFromSameFile() {
        Map<Integer, Set<String>> sourceProbes = new HashMap<>();
        sourceProbes.put(6, Collections.singleton("probe-request-dto"));

        MethodNode method = methodAtLine("getPrice", 11);
        ClassNode sourceCn = cnWithCustomName("com/hyperprobe/demo/model/ItemDto", method);
        sourceCn.sourceFile = "Dtos.kt";

        ClassNode targetCn = applyVisitor(
                sourceCn,
                LineNumberAsmVisitor.forKotlinSource(sourceProbes));

        assertFalse(hasProbeInjected(targetCn.methods.get(0), "probe-request-dto"));
    }

    @Test
    public void testKotlinSourceAwareVisitorStillSlidesWithinClassRange() {
        Map<Integer, Set<String>> sourceProbes = new HashMap<>();
        sourceProbes.put(20, Collections.singleton("probe-within-class"));

        MethodNode firstMethod = methodAtLine("first", 10);
        MethodNode secondMethod = methodAtLine("second", 30);
        ClassNode sourceCn = cnWithCustomName("com/hyperprobe/demo/Example", firstMethod);
        sourceCn.methods.add(secondMethod);
        sourceCn.sourceFile = "Example.kt";

        ClassNode targetCn = applyVisitor(
                sourceCn,
                LineNumberAsmVisitor.forKotlinSource(sourceProbes));

        assertFalse(hasProbeInjected(targetCn.methods.get(0), "probe-within-class"));
        assertTrue(hasProbeInjected(targetCn.methods.get(1), "probe-within-class"));
    }

    private ClassNode applyVisitor(ClassNode sourceCn, LineNumberAsmVisitor visitor) {
        ClassNode targetCn = new ClassNode(Opcodes.ASM9);
        TypeDescription typeDesc = new TypeDescription.ForLoadedType(Object.class);
        ClassVisitor cv = visitor.wrap(typeDesc, targetCn, null, null, null, null, 0, 0);
        sourceCn.accept(cv);
        return targetCn;
    }

    private MethodNode methodAtLine(String name, int line) {
        MethodNode method = new MethodNode(Opcodes.ASM9, Opcodes.ACC_PUBLIC, name, "()V", null, null);
        Label label = new Label();
        method.visitLabel(label);
        method.visitLineNumber(line, label);
        method.visitInsn(Opcodes.RETURN);
        return method;
    }

    private boolean hasProbeInjected(MethodNode method, String probeId) {
        AbstractInsnNode insn = method.instructions.getFirst();
        while (insn != null) {
            if (insn instanceof LdcInsnNode) {
                LdcInsnNode ldc = (LdcInsnNode) insn;
                if (probeId.equals(ldc.cst)) {
                    return true;
                }
            }
            insn = insn.getNext();
        }
        return false;
    }

    private ClassNode cnWithCustomName(String name, MethodNode method) {
        ClassNode cn = new ClassNode(Opcodes.ASM9);
        cn.name = name;
        cn.methods.add(method);
        return cn;
    }
}
