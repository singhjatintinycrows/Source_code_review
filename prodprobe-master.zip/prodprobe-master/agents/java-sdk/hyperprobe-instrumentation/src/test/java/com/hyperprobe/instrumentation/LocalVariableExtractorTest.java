package com.hyperprobe.instrumentation;

import org.junit.Test;
import org.objectweb.asm.Opcodes;
import org.objectweb.asm.tree.InsnNode;
import org.objectweb.asm.tree.LabelNode;
import org.objectweb.asm.tree.LocalVariableNode;
import org.objectweb.asm.tree.MethodNode;

import java.util.ArrayList;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

public class LocalVariableExtractorTest {

    @Test
    public void testSyntheticThis0Sanitization() {
        MethodNode mn = new MethodNode(Opcodes.ASM9, Opcodes.ACC_PUBLIC, "innerMethod", "()V", null, null);
        LabelNode start = new LabelNode();
        LabelNode end = new LabelNode();
        mn.instructions.add(start);
        mn.instructions.add(new InsnNode(Opcodes.RETURN));
        mn.instructions.add(end);

        mn.localVariables = new ArrayList<>();
        mn.localVariables.add(new LocalVariableNode("this", "Ljava/lang/Object;", null, start, end, 0));
        mn.localVariables.add(new LocalVariableNode("$this$0", "Ljava/lang/Object;", null, start, end, 1));
        mn.localVariables.add(new LocalVariableNode("$this$receiver", "Ljava/lang/Object;", null, start, end, 2));

        String probeId = "probe-test-sanitization";
        LocalVariableExtractor.generateCaptureInstructions(mn, mn.instructions.getFirst(), probeId);

        // Verify discovered variable names were correctly mapped
        com.hyperprobe.runtime.domain.ProbeDefinition def = new com.hyperprobe.runtime.domain.ProbeDefinition(
                probeId, null, null, "App.java", 1, null,
                null, null, null, null, null, null, null, null, null,
                10, 1000, null, null, null, null, null, false, null, false
        );
        com.hyperprobe.runtime.ProbeExecutionEngine.updateProbes(java.util.Collections.singletonList(def));

        // Trigger local variable generation via capture
        LocalVariableExtractor.generateCaptureInstructions(mn, mn.instructions.getFirst(), probeId);
        assertNotNull(def.getLocalVariableNames());
        assertEquals(3, def.getLocalVariableNames().size());
        assertEquals("this", def.getLocalVariableNames().get(0));
        assertEquals("this$0", def.getLocalVariableNames().get(1));
        assertEquals("receiver", def.getLocalVariableNames().get(2));
    }

    @Test
    public void testSyntheticThis0WithoutNativeThis() {
        // Method without native 'this' parameter (e.g. static extension or lambda)
        MethodNode mn = new MethodNode(Opcodes.ASM9, Opcodes.ACC_STATIC, "lambda$0", "()V", null, null);
        LabelNode start = new LabelNode();
        LabelNode end = new LabelNode();
        mn.instructions.add(start);
        mn.instructions.add(new InsnNode(Opcodes.RETURN));
        mn.instructions.add(end);

        mn.localVariables = new ArrayList<>();
        // $this$0 appears before $this$receiver in LVT
        mn.localVariables.add(new LocalVariableNode("$this$0", "Ljava/lang/Object;", null, start, end, 0));
        mn.localVariables.add(new LocalVariableNode("$this$receiver", "Ljava/lang/Object;", null, start, end, 1));

        String probeId = "probe-test-no-native-this";
        com.hyperprobe.runtime.domain.ProbeDefinition def = new com.hyperprobe.runtime.domain.ProbeDefinition(
                probeId, null, null, "App.java", 1, null,
                null, null, null, null, null, null, null, null, null,
                10, 1000, null, null, null, null, null, false, null, false
        );
        com.hyperprobe.runtime.ProbeExecutionEngine.updateProbes(java.util.Collections.singletonList(def));

        LocalVariableExtractor.generateCaptureInstructions(mn, mn.instructions.getFirst(), probeId);

        assertNotNull(def.getLocalVariableNames());
        assertEquals(2, def.getLocalVariableNames().size());
        // $this$0 must NOT steal "this"
        assertEquals("this$0", def.getLocalVariableNames().get(0));
        // $this$receiver must be re-mapped to "this"
        assertEquals("this", def.getLocalVariableNames().get(1));
    }

    @Test
    public void testEmptySuffixThisFallbackWhenThisTaken() {
        MethodNode mn = new MethodNode(Opcodes.ASM9, Opcodes.ACC_PUBLIC, "method", "()V", null, null);
        LabelNode start = new LabelNode();
        LabelNode end = new LabelNode();
        mn.instructions.add(start);
        mn.instructions.add(new InsnNode(Opcodes.RETURN));
        mn.instructions.add(end);

        mn.localVariables = new ArrayList<>();
        mn.localVariables.add(new LocalVariableNode("this", "Ljava/lang/Object;", null, start, end, 0));
        mn.localVariables.add(new LocalVariableNode("$this$", "Ljava/lang/Object;", null, start, end, 1));

        String probeId = "probe-test-empty-this-fallback";
        com.hyperprobe.runtime.domain.ProbeDefinition def = new com.hyperprobe.runtime.domain.ProbeDefinition(
                probeId, null, null, "App.java", 1, null,
                null, null, null, null, null, null, null, null, null,
                10, 1000, null, null, null, null, null, false, null, false
        );
        com.hyperprobe.runtime.ProbeExecutionEngine.updateProbes(java.util.Collections.singletonList(def));

        LocalVariableExtractor.generateCaptureInstructions(mn, mn.instructions.getFirst(), probeId);

        assertNotNull(def.getLocalVariableNames());
        assertEquals(2, def.getLocalVariableNames().size());
        assertEquals("this", def.getLocalVariableNames().get(0));
        assertEquals("receiver", def.getLocalVariableNames().get(1));
    }
}
