package com.hyperprobe.instrumentation;

import org.objectweb.asm.Opcodes;
import org.objectweb.asm.Type;
import org.objectweb.asm.tree.*;

import java.util.ArrayList;
import java.util.List;

/**
 * Extracts visible local variables at a specific instruction index
 * and generates the bytecode required to pack them into an Object[] array.
 */
public class LocalVariableExtractor {

    /**
     * Injects bytecode to capture local variables active at the target instruction,
     * pack them into an Object[] array, and invoke the AgentBridge.
     */
    public static InsnList generateCaptureInstructions(MethodNode methodNode, AbstractInsnNode targetNode, String probeId) {
        InsnList il = new InsnList();

        // Find active local variables at this instruction point
        List<LocalVariableNode> activeLocals = getActiveLocals(methodNode, targetNode);
        
        // --- PARITY FIX: Bridge Names to Runtime ---
        // We include all variables including "this" so that MVEL can resolve fields.
        boolean hasNativeThis = activeLocals.stream().anyMatch(lvn -> "this".equals(lvn.name));
        java.util.List<String> names = new java.util.ArrayList<>();
        for (LocalVariableNode lvn : activeLocals) {
            String sanitizedName = lvn.name;
            // Kotlin variable sanitization
            if (sanitizedName.startsWith("$this$")) {
                String suffix = sanitizedName.substring(6);
                boolean isNumericSuffix = !suffix.isEmpty() && Character.isDigit(suffix.charAt(0));

                if (!hasNativeThis && !names.contains("this") && !isNumericSuffix) {
                    sanitizedName = "this"; // Re-map non-numeric extension function receivers dynamically if no 'this' exists
                } else {
                    if (!suffix.isEmpty()) {
                        // If suffix starts with a digit (e.g. $this$0 for synthetic outer class references),
                        // prefix with 'this$' so MVEL treats it as a valid identifier instead of an integer literal.
                        if (isNumericSuffix) {
                            suffix = "this$" + suffix;
                        }
                        String fallback = suffix;
                        int count = 1;
                        while (names.contains(fallback)) {
                            fallback = suffix + "_" + count++;
                        }
                        sanitizedName = fallback;
                    } else {
                        // If suffix is empty ($this$) and "this" is already taken, fallback to a clean identifier
                        String fallback = "receiver";
                        if (names.contains(fallback)) {
                            fallback = "this$receiver";
                        }
                        int count = 1;
                        while (names.contains(fallback)) {
                            fallback = "receiver" + count++;
                        }
                        sanitizedName = fallback;
                    }
                }
            }
            names.add(sanitizedName);
        }
        com.hyperprobe.runtime.ProbeExecutionEngine.updateProbeVariableNames(probeId, names);
        // -------------------------------------------------------------

        // 1. Push probeId string onto the stack
        il.add(new LdcInsnNode(probeId));

        // 2. Create the Object[] array for local variables
        pushInt(il, activeLocals.size());
        il.add(new TypeInsnNode(Opcodes.ANEWARRAY, "java/lang/Object"));

        // 3. Populate the array
        int arrayIndex = 0;
        for (LocalVariableNode lvn : activeLocals) {
            il.add(new InsnNode(Opcodes.DUP)); // Duplicate array reference
            pushInt(il, arrayIndex++);

            Type varType = Type.getType(lvn.desc);
            il.add(new VarInsnNode(varType.getOpcode(Opcodes.ILOAD), lvn.index)); // Load variable

            // Box primitives (int -> Integer, double -> Double, etc.)
            boxIfPrimitive(varType, il);

            il.add(new InsnNode(Opcodes.AASTORE)); // Store in array
        }

        // 4. Invoke the AgentBridge: AgentBridge.onLineHit(String probeId, Object[] locals)
        il.add(new MethodInsnNode(
                Opcodes.INVOKESTATIC,
                "com/hyperprobe/agent/bootstrap/AgentBridge",
                "onLineHit",
                "(Ljava/lang/String;[Ljava/lang/Object;)V",
                false
        ));

        return il;
    }

    private static List<LocalVariableNode> getActiveLocals(MethodNode methodNode, AbstractInsnNode targetNode) {
        List<LocalVariableNode> active = new ArrayList<>();
        
        // 1. Instance check: Determine if we have a "this" pointer
        boolean isStatic = (methodNode.access & Opcodes.ACC_STATIC) != 0;
        
        if (methodNode.localVariables == null) {
            // Fallback for missing debug symbols: At least capture "this" if we are in an instance method
            if (!isStatic) {
                active.add(new LocalVariableNode("this", "Ljava/lang/Object;", null, null, null, 0));
            }
            return active;
        }

        int targetIndex = methodNode.instructions.indexOf(targetNode);
        if (targetIndex == -1) {
            // Failsafe: If targetNode is not found in instructions, assume no locals (except maybe this)
            if (!isStatic) {
                active.add(new LocalVariableNode("this", "Ljava/lang/Object;", null, null, null, 0));
            }
            return active;
        }

        for (LocalVariableNode lvn : methodNode.localVariables) {
            int startIndex = methodNode.instructions.indexOf(lvn.start);
            int endIndex = methodNode.instructions.indexOf(lvn.end);
            
            // Defensively handle -1 indices
            if (startIndex == -1 || endIndex == -1) {
                continue;
            }
            
            // Modern JVMs often place the LineNumberNode exactly AT the startIndex of the variable.
            // Arguments usually span the entire method. The endIndex is exclusive.
            if (targetIndex >= startIndex && targetIndex < endIndex) {
                active.add(lvn);
            }
        }
        
        // Ensure "this" is included if it exists in LVT but boundary was weird, 
        // or add it manually if missing but we are in an instance method.
        boolean hasThis = active.stream().anyMatch(v -> "this".equals(v.name));
        if (!hasThis && !isStatic) {
            for (LocalVariableNode lvn : methodNode.localVariables) {
                if (lvn.index == 0) {
                    active.add(lvn);
                    hasThis = true;
                    break;
                }
            }
            if (!hasThis) {
                active.add(new LocalVariableNode("this", "Ljava/lang/Object;", null, null, null, 0));
            }
        }
        
        return active;
    }

    private static void boxIfPrimitive(Type type, InsnList il) {
        switch (type.getSort()) {
            case Type.BOOLEAN:
                il.add(new MethodInsnNode(Opcodes.INVOKESTATIC, "java/lang/Boolean", "valueOf", "(Z)Ljava/lang/Boolean;", false));
                break;
            case Type.CHAR:
                il.add(new MethodInsnNode(Opcodes.INVOKESTATIC, "java/lang/Character", "valueOf", "(C)Ljava/lang/Character;", false));
                break;
            case Type.BYTE:
                il.add(new MethodInsnNode(Opcodes.INVOKESTATIC, "java/lang/Byte", "valueOf", "(B)Ljava/lang/Byte;", false));
                break;
            case Type.SHORT:
                il.add(new MethodInsnNode(Opcodes.INVOKESTATIC, "java/lang/Short", "valueOf", "(S)Ljava/lang/Short;", false));
                break;
            case Type.INT:
                il.add(new MethodInsnNode(Opcodes.INVOKESTATIC, "java/lang/Integer", "valueOf", "(I)Ljava/lang/Integer;", false));
                break;
            case Type.FLOAT:
                il.add(new MethodInsnNode(Opcodes.INVOKESTATIC, "java/lang/Float", "valueOf", "(F)Ljava/lang/Float;", false));
                break;
            case Type.LONG:
                il.add(new MethodInsnNode(Opcodes.INVOKESTATIC, "java/lang/Long", "valueOf", "(J)Ljava/lang/Long;", false));
                break;
            case Type.DOUBLE:
                il.add(new MethodInsnNode(Opcodes.INVOKESTATIC, "java/lang/Double", "valueOf", "(D)Ljava/lang/Double;", false));
                break;
        }
    }

    private static void pushInt(InsnList il, int value) {
        if (value >= -1 && value <= 5) {
            il.add(new InsnNode(Opcodes.ICONST_0 + value));
        } else if (value >= Byte.MIN_VALUE && value <= Byte.MAX_VALUE) {
            il.add(new IntInsnNode(Opcodes.BIPUSH, value));
        } else if (value >= Short.MIN_VALUE && value <= Short.MAX_VALUE) {
            il.add(new IntInsnNode(Opcodes.SIPUSH, value));
        } else {
            il.add(new LdcInsnNode(value));
        }
    }
}
