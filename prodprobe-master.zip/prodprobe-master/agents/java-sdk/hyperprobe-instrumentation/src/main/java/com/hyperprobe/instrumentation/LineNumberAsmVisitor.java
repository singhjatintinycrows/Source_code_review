package com.hyperprobe.instrumentation;

import com.hyperprobe.config.logging.HyperProbeLogger;
import net.bytebuddy.asm.AsmVisitorWrapper;
import net.bytebuddy.description.field.FieldDescription;
import net.bytebuddy.description.field.FieldList;
import net.bytebuddy.description.method.MethodList;
import net.bytebuddy.description.type.TypeDescription;
import net.bytebuddy.implementation.Implementation;
import net.bytebuddy.pool.TypePool;

import org.objectweb.asm.ClassVisitor;
import org.objectweb.asm.Opcodes;
import org.objectweb.asm.tree.AbstractInsnNode;
import org.objectweb.asm.tree.ClassNode;
import org.objectweb.asm.tree.LineNumberNode;
import org.objectweb.asm.tree.MethodNode;

import java.util.HashMap;
import java.util.Map;

import java.util.Set;

import java.util.TreeSet;
import java.util.NavigableSet;

/**
 * ByteBuddy AsmVisitorWrapper that utilizes the ASM Tree API (ClassNode)
 * to perform exact line-number bytecode injection.
 */
public class LineNumberAsmVisitor implements AsmVisitorWrapper {

    private static final HyperProbeLogger logger = HyperProbeLogger.getLogger(InstrumentationEngine.class);

    private final Map<Integer, Set<String>> classProbes;
    private final Map<String, Map<Integer, Set<String>>> kotlinProbesBySourceFile;
    private final boolean constrainToSourceClassRange;

    public LineNumberAsmVisitor(Map<Integer, Set<String>> classProbes) {
        this.classProbes = classProbes;
        this.kotlinProbesBySourceFile = null;
        this.constrainToSourceClassRange = false;
    }

    private LineNumberAsmVisitor(
            Map<Integer, Set<String>> classProbes,
            Map<String, Map<Integer, Set<String>>> kotlinProbesBySourceFile) {
        this.classProbes = classProbes;
        this.kotlinProbesBySourceFile = kotlinProbesBySourceFile;
        this.constrainToSourceClassRange = true;
    }

    public static LineNumberAsmVisitor forKotlinSource(Map<Integer, Set<String>> sourceProbes) {
        return new LineNumberAsmVisitor(sourceProbes, null);
    }

    public static LineNumberAsmVisitor forKotlinSources(
            Map<String, Map<Integer, Set<String>>> kotlinProbesBySourceFile) {
        return new LineNumberAsmVisitor(null, kotlinProbesBySourceFile);
    }

    @Override
    public int mergeWriter(int flags) {
        // COMPUTE_FRAMES and COMPUTE_MAXS are necessary because we add new stack elements (Object[])
        return flags | org.objectweb.asm.ClassWriter.COMPUTE_FRAMES | org.objectweb.asm.ClassWriter.COMPUTE_MAXS;
    }

    @Override
    public int mergeReader(int flags) {
        return flags;
    }

    @Override
    public ClassVisitor wrap(TypeDescription instrumentedType, ClassVisitor classVisitor,
                             Implementation.Context implementationContext, TypePool typePool,
                             FieldList<FieldDescription.InDefinedShape> fields, MethodList<?> methods,
                             int writerFlags, int readerFlags) {

        // Return a ClassNode. This buffers the entire class into an object tree,
        // allowing us to freely search for line numbers and read local variable tables.
        return new ClassNode(Opcodes.ASM9) {
            @Override
            public void visitEnd() {
                Map<Integer, Set<String>> probesForVisitedClass = classProbes;
                if (kotlinProbesBySourceFile != null) {
                    probesForVisitedClass = this.sourceFile != null ? kotlinProbesBySourceFile.get(this.sourceFile) : null;
                    if (probesForVisitedClass == null || probesForVisitedClass.isEmpty()) {
                        // The package matched an active Kotlin probe, but this class was compiled
                        // from a different source file. Preserve it without injecting anything.
                        accept(classVisitor);
                        return;
                    }
                }

                logger.debug("LineNumberAsmVisitor wrapping class: " + instrumentedType.getName()
                        + " from source: " + this.sourceFile + " with requested probes: " + probesForVisitedClass);

                // Pre-process the entire class to find all valid executable line numbers
                NavigableSet<Integer> allValidLines = new TreeSet<>();

                for (MethodNode method : this.methods) {
                    if (isSyntheticWrapper(method)) {
                        continue;
                    }
                    AbstractInsnNode node = method.instructions.getFirst();
                    while (node != null) {
                        if (node instanceof LineNumberNode) {
                            allValidLines.add(((LineNumberNode) node).line);
                        }
                        node = node.getNext();
                    }
                }

                logger.debug("Class " + instrumentedType.getName() + " valid executable lines: " + allValidLines);

                if (allValidLines.isEmpty()) {
                    // Interfaces (and annotations) naturally lack executable instructions and LineNumberTables.
                    // If a Kotlin source file contains both a class and an interface, the broad source matcher
                    // may attempt to evaluate the interface. We should skip them quietly without logging an error.
                    if ((this.access & Opcodes.ACC_INTERFACE) == 0) {
                        java.util.Set<String> failedProbes = new java.util.LinkedHashSet<>();
                        for (Set<String> probes : probesForVisitedClass.values()) {
                            failedProbes.addAll(probes);
                        }
                        
                        com.hyperprobe.config.logging.HyperProbeLogger.getLogger(LineNumberAsmVisitor.class).error(
                            "CRITICAL: Failed to apply probes " + failedProbes + " to class [" + instrumentedType.getName() + "]. " +
                            "The class is missing LineNumberTable metadata. " +
                            "To fix this, ensure your compiler is not using '-g:none' and that your shrinker/obfuscator is configured to retain line numbers."
                        );
                    }
                    
                    accept(classVisitor);
                    return;
                }

                // Resolve requested lines to global target lines for V8-style sliding
                Map<Integer, Set<String>> globallyResolvedProbes = new HashMap<>();
                for (Map.Entry<Integer, Set<String>> entry : probesForVisitedClass.entrySet()) {
                    int requestedLine = entry.getKey();

                    // One Kotlin file may emit several unrelated classes. Do not slide a
                    // probe from an earlier/later declaration into this class merely because
                    // it shares the same SourceFile attribute.
                    if (constrainToSourceClassRange
                            && (requestedLine < allValidLines.first() || requestedLine > allValidLines.last())) {
                        continue;
                    }

                    int targetLine = requestedLine;

                    // If the requested line was stripped by the compiler (e.g. blank line, comment)
                    if (!allValidLines.contains(requestedLine)) {
                        // Find the next highest executable line in the entire class.
                        Integer nextLine = allValidLines.higher(requestedLine);
                        if (nextLine != null) {
                            targetLine = nextLine;
                        }
                    }
                    
                    Set<String> targetSet = globallyResolvedProbes.computeIfAbsent(targetLine, k -> new java.util.LinkedHashSet<>());
                    targetSet.addAll(entry.getValue());
                }

                // Process all methods in the class
                for (MethodNode method : this.methods) {
                    if (isSyntheticWrapper(method)) {
                        continue;
                    }
                    processMethod(method, globallyResolvedProbes);
                }
                // Write the modified ClassNode back to the next visitor in the chain
                accept(classVisitor);
            }
        };
    }

    private boolean isSyntheticWrapper(MethodNode method) {
        boolean isSynthetic = (method.access & Opcodes.ACC_SYNTHETIC) != 0;
        return (method.access & Opcodes.ACC_BRIDGE) != 0
                || (isSynthetic && method.name.endsWith("$default"))
                // Kotlin default-argument constructors delegate to the primary
                // constructor. Their source lines occur before that delegation,
                // while `this` is still uninitialized and cannot be captured.
                || (isSynthetic && "<init>".equals(method.name));
    }

    private void processMethod(MethodNode method, Map<Integer, Set<String>> globallyResolvedProbes) {
        if (globallyResolvedProbes.isEmpty()) {
            return;
        }

        // Iterate through instructions and inject bytecode at the effective lines
        AbstractInsnNode insn = method.instructions.getFirst();
        
        while (insn != null) {
            if (insn instanceof LineNumberNode) {
                LineNumberNode lineNode = (LineNumberNode) insn;
                
                // Check if this line has registered probes
                Set<String> encodedProbeIds = globallyResolvedProbes.get(lineNode.line);
                if (encodedProbeIds != null && !encodedProbeIds.isEmpty()) {
                    
                    for (String encodedProbeId : encodedProbeIds) {
                        String probeId = encodedProbeId;
                        boolean isSecondary = false;
                        if (encodedProbeId.endsWith(":secondary")) {
                            isSecondary = true;
                            // Keep the :secondary suffix in the probeId for the runtime to detect exit hits
                        }
                        
                        // Generate capture bytecode
                        logger.debug(
                            "Injecting capture instructions for probe [" + probeId + "] into method [" + method.name + "] at line " + lineNode.line
                        );
                        org.objectweb.asm.tree.InsnList captureInstructions = 
                                LocalVariableExtractor.generateCaptureInstructions(method, lineNode, probeId);
                        
                        if (isSecondary) {
                            // The Node SDK inserts the secondary (duration end) bytecode IMMEDIATELY BEFORE the secondary line executes.
                            method.instructions.insertBefore(lineNode, captureInstructions);
                        } else {
                            // Find the next instruction that isn't a label or another line number to ensure 
                            // local variables assigned on this specific line are fully written to their slots.
                            AbstractInsnNode next = lineNode.getNext();
                            while (next != null && (next.getType() == AbstractInsnNode.LABEL || next.getType() == AbstractInsnNode.LINE)) {
                                next = next.getNext();
                            }
                            
                            if (next != null) {
                                method.instructions.insert(next, captureInstructions);
                            } else {
                                method.instructions.insert(lineNode, captureInstructions);
                            }
                        }
                    }
                }
            }
            insn = insn.getNext();
        }
    }
}
