package com.hyperprobe.instrumentation;

import com.hyperprobe.runtime.domain.ProbeDefinition;
import net.bytebuddy.description.type.TypeDescription;
import net.bytebuddy.matcher.ElementMatcher;

import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArraySet;

/**
 * Registry mapping physical probe locations (files/lines) to JVM class definitions.
 */
public class ProbeLocationMatcher {

    // Maps FQCN (Fully Qualified Class Name) -> (Line Number -> Set of Probe IDs)
    private volatile Map<String, Map<Integer, Set<String>>> activeProbes = new ConcurrentHashMap<>();
    // Maps package -> source filename -> (Line Number -> Set of Probe IDs).
    // Kotlin source filenames do not necessarily match any class declared in the file.
    private volatile Map<String, Map<String, Map<Integer, Set<String>>>> activeKotlinSourceProbes = new ConcurrentHashMap<>();
    private String appRoot = "";

    public void setAppRoot(String appRoot) {
        if (appRoot != null) {
            this.appRoot = appRoot.replace("\\", "/");
            if (!this.appRoot.isEmpty() && !this.appRoot.endsWith("/")) {
                this.appRoot += "/";
            }
        }
    }

    /**
     * Updates the active probes and returns exact Java class changes plus Kotlin source changes.
     * This is used to accurately trigger Instrumentation.retransformClasses().
     */
    public ProbeUpdateResult updateProbes(List<ProbeDefinition> newProbes) {
        Set<String> changedFqcns = new HashSet<>();
        Map<String, Set<String>> changedKotlinSources = new HashMap<>();
        Map<String, Map<Integer, Set<String>>> newActiveProbes = new ConcurrentHashMap<>();
        Map<String, Map<String, Map<Integer, Set<String>>>> newKotlinSourceProbes = new ConcurrentHashMap<>();

        for (ProbeDefinition p : newProbes) {
            // 1. Primary Line Mapping
            addProbeMapping(newActiveProbes, newKotlinSourceProbes,
                    p.getRuntimeLocation(), p.getRuntimeLine(), p.getId());

            // 2. Secondary Line Mapping (For Duration Probes)
            if (p.getSecondaryRuntimeLocation() != null && p.getSecondaryRuntimeLine() != null) {
                addProbeMapping(newActiveProbes, newKotlinSourceProbes,
                        p.getSecondaryRuntimeLocation(), p.getSecondaryRuntimeLine(),
                        p.getId() + ":secondary"); // Encode secondary intent
            }
        }

        // Determine which classes need retransformation by comparing old and new states
        Set<String> allFqcns = new HashSet<>(activeProbes.keySet());
        allFqcns.addAll(newActiveProbes.keySet());

        for (String fqcn : allFqcns) {
            Map<Integer, Set<String>> oldLines = activeProbes.get(fqcn);
            Map<Integer, Set<String>> newLines = newActiveProbes.get(fqcn);
            
            if (oldLines == null || newLines == null || !oldLines.equals(newLines)) {
                changedFqcns.add(fqcn);
            }
        }

        Set<String> allKotlinPackages = new HashSet<>(activeKotlinSourceProbes.keySet());
        allKotlinPackages.addAll(newKotlinSourceProbes.keySet());

        for (String packageName : allKotlinPackages) {
            Map<String, Map<Integer, Set<String>>> oldSources = activeKotlinSourceProbes.get(packageName);
            Map<String, Map<Integer, Set<String>>> newSources = newKotlinSourceProbes.get(packageName);

            Set<String> allSourceFiles = new HashSet<>();
            if (oldSources != null) {
                allSourceFiles.addAll(oldSources.keySet());
            }
            if (newSources != null) {
                allSourceFiles.addAll(newSources.keySet());
            }

            for (String sourceFile : allSourceFiles) {
                Map<Integer, Set<String>> oldLines = oldSources == null ? null : oldSources.get(sourceFile);
                Map<Integer, Set<String>> newLines = newSources == null ? null : newSources.get(sourceFile);
                if (oldLines == null || newLines == null || !oldLines.equals(newLines)) {
                    changedKotlinSources
                            .computeIfAbsent(packageName, k -> new HashSet<>())
                            .add(sourceFile);
                }
            }
        }

        activeProbes = newActiveProbes;
        activeKotlinSourceProbes = newKotlinSourceProbes;

        return new ProbeUpdateResult(changedFqcns, changedKotlinSources);
    }

    /**
     * Compatibility helper for callers that only consume exact JVM class changes.
     * InstrumentationEngine uses {@link #updateProbes(List)} so Kotlin package changes
     * are included when loaded classes are retransformed.
     */
    public Set<String> updateProbesAndGetChangedClasses(List<ProbeDefinition> newProbes) {
        ProbeUpdateResult update = updateProbes(newProbes);
        Set<String> legacyClassNames = new HashSet<>(update.getChangedClassNames());
        for (Map.Entry<String, Set<String>> entry : update.changedKotlinSources.entrySet()) {
            for (String sourceFile : entry.getValue()) {
                String filename = sourceFile.substring(0, sourceFile.length() - 3);
                String packagePrefix = entry.getKey().isEmpty() ? "" : entry.getKey() + ".";
                legacyClassNames.add(packagePrefix + filename);
                if (!filename.isEmpty()) {
                    legacyClassNames.add(packagePrefix
                            + Character.toUpperCase(filename.charAt(0))
                            + filename.substring(1)
                            + "Kt");
                }
            }
        }
        return legacyClassNames;
    }

    private void addProbeMapping(
            Map<String, Map<Integer, Set<String>>> exactProbes,
            Map<String, Map<String, Map<Integer, Set<String>>>> kotlinSourceProbes,
            String runtimeLocation,
            Integer runtimeLine,
            String encodedProbeId) {
        KotlinSourceLocation kotlinLocation = mapRuntimeFileToKotlinSource(runtimeLocation, appRoot);
        if (kotlinLocation != null) {
            kotlinSourceProbes
                    .computeIfAbsent(kotlinLocation.packageName, k -> new ConcurrentHashMap<>())
                    .computeIfAbsent(kotlinLocation.sourceFile, k -> new ConcurrentHashMap<>())
                    .computeIfAbsent(runtimeLine, k -> new CopyOnWriteArraySet<>())
                    .add(encodedProbeId);
            return;
        }

        Set<String> fqcns = mapRuntimeFileToFqcn(runtimeLocation, appRoot);
        if (fqcns == null) {
            return;
        }
        for (String fqcn : fqcns) {
            exactProbes.computeIfAbsent(fqcn, k -> new ConcurrentHashMap<>())
                    .computeIfAbsent(runtimeLine, k -> new CopyOnWriteArraySet<>())
                    .add(encodedProbeId);
        }
    }

    public static Set<String> mapRuntimeFileToFqcn(String runtimeFile) {
        return mapRuntimeFileToFqcn(runtimeFile, "");
    }

    /**
     * Maps physical file paths to Fully Qualified Class Names (FQCN).
     * e.g., src/main/java/com/foo/service/UserService.java -> Set of [com.foo.service.UserService]
     * e.g., src/main/kotlin/com/foo/service/UserService.kt -> Set of [com.foo.service.UserService, com.foo.service.UserServiceKt]
     */
    public static Set<String> mapRuntimeFileToFqcn(String runtimeFile, String appRoot) {
        String path = normalizeRuntimeSourcePath(runtimeFile, appRoot);
        if (path == null) return null;
        
        Set<String> result = new HashSet<>();
        
        // 3. Strip file extensions and build class names
        if (path.endsWith(".java")) {
            path = path.substring(0, path.length() - 5);
            result.add(path.replace('/', '.'));
        } else if (path.endsWith(".kt")) {
            // Extract the filename part for Kotlin top-level functions (e.g. MyFile.kt -> MyFileKt)
            String filename = path.substring(path.lastIndexOf('/') + 1, path.length() - 3);
            path = path.substring(0, path.length() - 3);
            
            // Standard class definition inside the file
            result.add(path.replace('/', '.'));
            
            // Kotlin top-level functions compile to a class with a 'Kt' suffix
            if (!filename.isEmpty()) {
                String capitalizedFileName = Character.toUpperCase(filename.charAt(0)) + filename.substring(1);
                String packagePath = path.contains("/") ? path.substring(0, path.lastIndexOf('/') + 1) : "";
                result.add((packagePath + capitalizedFileName + "Kt").replace('/', '.'));
            }
        } else {
            // Fallback (e.g., if already a class name)
            result.add(path.replace('/', '.'));
        }
        
        return result;
    }

    private static KotlinSourceLocation mapRuntimeFileToKotlinSource(String runtimeFile, String appRoot) {
        String path = normalizeRuntimeSourcePath(runtimeFile, appRoot);
        if (path == null || !path.endsWith(".kt")) {
            return null;
        }

        int separator = path.lastIndexOf('/');
        String sourceFile = separator == -1 ? path : path.substring(separator + 1);
        String packageName = separator == -1 ? "" : path.substring(0, separator).replace('/', '.');
        return new KotlinSourceLocation(packageName, sourceFile);
    }

    private static String normalizeRuntimeSourcePath(String runtimeFile, String appRoot) {
        if (runtimeFile == null || runtimeFile.isEmpty()) return null;
        String path = runtimeFile.replace("\\", "/");

        if (appRoot != null && !appRoot.isEmpty() && path.startsWith(appRoot)) {
            path = path.substring(appRoot.length());
        }

        String[] sourceMarkers = {
            "WEB-INF/classes/",
            "src/main/java/",
            "src/main/kotlin/",
            "src/test/java/",
            "src/test/kotlin/",
            "src/java/",
            "src/kotlin/",
            "java/",
            "kotlin/",
        };

        boolean foundMarker = false;
        for (String marker : sourceMarkers) {
            int idx = path.indexOf(marker);
            if (idx != -1) {
                path = path.substring(idx + marker.length());
                foundMarker = true;
                break;
            }
        }

        if (!foundMarker) {
            path = path.replaceAll("^(\\.\\.?/)+", "");
        }
        return path;
    }

    public Map<Integer, Set<String>> getProbesForClass(String fqcn) {
        Map<Integer, Set<String>> probes = activeProbes.get(fqcn);
        if (probes != null) {
            return probes;
        }
        String current = fqcn;
        int lastDollar;
        while ((lastDollar = current.lastIndexOf('$')) != -1) {
            current = current.substring(0, lastDollar);
            probes = activeProbes.get(current);
            if (probes != null) {
                return probes;
            }
        }
        return null;
    }

    public Map<String, Map<Integer, Set<String>>> getKotlinSourceProbesForClass(String fqcn) {
        return activeKotlinSourceProbes.get(packageNameOf(fqcn));
    }

    public ElementMatcher<TypeDescription> getTypeMatcher() {
        return target -> {
            String name = target.getName();
            boolean match = matchesExactProbeClass(name);
            if (!match) {
                match = activeKotlinSourceProbes.containsKey(packageNameOf(name));
            }
            return match;
        };
    }

    public boolean matchesType(TypeDescription target, ClassLoader classLoader) {
        String name = target.getName();
        if (matchesExactProbeClass(name)) {
            return true;
        }

        Map<String, Map<Integer, Set<String>>> probesBySource =
                activeKotlinSourceProbes.get(packageNameOf(name));
        if (probesBySource == null) {
            return false;
        }

        String sourceFile = ProbeClassTransformer.getSourceFileName(name, classLoader);
        // Retain a source-aware ASM fallback for custom class loaders that do not
        // expose bytecode as resources.
        return sourceFile == null || probesBySource.containsKey(sourceFile);
    }

    private boolean matchesExactProbeClass(String name) {
        if (activeProbes.containsKey(name)) {
            return true;
        }
        for (String baseClass : activeProbes.keySet()) {
            if (name.startsWith(baseClass + "$")) {
                return true;
            }
        }
        return false;
    }

    private static String packageNameOf(String fqcn) {
        int separator = fqcn.lastIndexOf('.');
        return separator == -1 ? "" : fqcn.substring(0, separator);
    }
    
    public void clear() {
        activeProbes = new ConcurrentHashMap<>();
        activeKotlinSourceProbes = new ConcurrentHashMap<>();
    }

    private static final class KotlinSourceLocation {
        private final String packageName;
        private final String sourceFile;

        private KotlinSourceLocation(String packageName, String sourceFile) {
            this.packageName = packageName;
            this.sourceFile = sourceFile;
        }
    }

    public static final class ProbeUpdateResult {
        private final Set<String> changedClassNames;
        private final Map<String, Set<String>> changedKotlinSources;

        private ProbeUpdateResult(Set<String> changedClassNames, Map<String, Set<String>> changedKotlinSources) {
            this.changedClassNames = Collections.unmodifiableSet(new HashSet<>(changedClassNames));
            Map<String, Set<String>> immutableSources = new HashMap<>();
            for (Map.Entry<String, Set<String>> entry : changedKotlinSources.entrySet()) {
                immutableSources.put(
                        entry.getKey(),
                        Collections.unmodifiableSet(new HashSet<>(entry.getValue())));
            }
            this.changedKotlinSources = Collections.unmodifiableMap(immutableSources);
        }

        public Set<String> getChangedClassNames() {
            return changedClassNames;
        }

        public Set<String> getChangedKotlinPackages() {
            return changedKotlinSources.keySet();
        }

        public boolean isEmpty() {
            return changedClassNames.isEmpty() && changedKotlinSources.isEmpty();
        }

        public boolean matches(String fqcn) {
            return matchesExactClass(fqcn) || changedKotlinSources.containsKey(packageNameOf(fqcn));
        }

        public boolean matches(String fqcn, String sourceFile) {
            if (matchesExactClass(fqcn)) {
                return true;
            }
            Set<String> changedSources = changedKotlinSources.get(packageNameOf(fqcn));
            // Source lookup can fail for unusual class loaders. Preserve the package-level
            // fallback in that case so probes are not silently missed.
            return changedSources != null && (sourceFile == null || changedSources.contains(sourceFile));
        }

        private boolean matchesExactClass(String fqcn) {
            if (changedClassNames.contains(fqcn)) {
                return true;
            }
            for (String changedClassName : changedClassNames) {
                if (fqcn.startsWith(changedClassName + "$")) {
                    return true;
                }
            }
            return false;
        }
    }
}
