package com.hyperprobe.instrumentation;

import com.hyperprobe.config.logging.HyperProbeLogger;
import com.hyperprobe.runtime.domain.ProbeDefinition;
import net.bytebuddy.agent.builder.AgentBuilder;
import net.bytebuddy.matcher.ElementMatchers;

import java.lang.instrument.Instrumentation;
import java.util.ArrayList;
import java.util.List;

/**
 * Manages the ByteBuddy instrumentation pipeline.
 * Responsible for applying retransformations dynamically based on active probes.
 */
public class InstrumentationEngine {

    private static final HyperProbeLogger log = HyperProbeLogger.getLogger(InstrumentationEngine.class);

    private static Instrumentation instrumentation;
    private static AgentBuilder agentBuilder;
    private static final ProbeLocationMatcher probeLocationMatcher = new ProbeLocationMatcher();

    // Keeps track of the classes that need retransformation after the last update
    private static final java.util.concurrent.atomic.AtomicReference<ProbeLocationMatcher.ProbeUpdateResult> pendingRetransformations = new java.util.concurrent.atomic.AtomicReference<>();

    /**
     * Initializes ByteBuddy and installs the class file transformer.
     *
     * @param inst The JVM Instrumentation instance.
     */
    public static void install(Instrumentation inst) {
        instrumentation = inst;
        
        agentBuilder = new AgentBuilder.Default()
                .disableClassFormatChanges()
                .with(AgentBuilder.RedefinitionStrategy.RETRANSFORMATION)
                .with(AgentBuilder.TypeStrategy.Default.REDEFINE)
                .with(new AgentBuilder.Listener.Adapter() {
                    @Override
                    public void onError(String typeName, ClassLoader classLoader, net.bytebuddy.utility.JavaModule module, boolean loaded, Throwable throwable) {
                        log.error("ByteBuddy transformation error for class [" + typeName + "]: " + throwable.getMessage(), throwable);
                    }
                })
                .ignore(ElementMatchers.nameStartsWith("java.")
                        .or(ElementMatchers.nameStartsWith("javax."))
                        .or(ElementMatchers.nameStartsWith("sun."))
                        .or(ElementMatchers.nameStartsWith("com.sun."))
                        .or(ElementMatchers.nameStartsWith("jdk."))
                        .or(ElementMatchers.nameStartsWith("com.hyperprobe.agent"))
                        .or(ElementMatchers.nameStartsWith("com.hyperprobe.core"))
                        .or(ElementMatchers.nameStartsWith("com.hyperprobe.config"))
                        .or(ElementMatchers.nameStartsWith("com.hyperprobe.evaluator"))
                        .or(ElementMatchers.nameStartsWith("com.hyperprobe.instrumentation"))
                        .or(ElementMatchers.nameStartsWith("com.hyperprobe.runtime"))
                        .or(ElementMatchers.nameStartsWith("com.hyperprobe.serializer"))
                        .or(ElementMatchers.nameStartsWith("com.hyperprobe.transport")))
                .type((AgentBuilder.RawMatcher) (typeDescription, classLoader, module,
                        classBeingRedefined, protectionDomain) ->
                        probeLocationMatcher.matchesType(typeDescription, classLoader))
                .transform(new ProbeClassTransformer(probeLocationMatcher));

        agentBuilder.installOn(instrumentation);
    }

    /**
     * Updates the internal matcher with new probe definitions.
     */
    public static void updateProbeLocations(List<ProbeDefinition> probes) {
        if (instrumentation == null) return;
        pendingRetransformations.set(probeLocationMatcher.updateProbes(probes));
    }

    /**
     * Finds loaded JVM classes matching the changed probe locations and triggers retransformation.
     * ByteBuddy will automatically intercept these calls using the updated matcher.
     */
    public static void retransformAffectedClasses() {
        if (instrumentation == null) {
            return;
        }
        ProbeLocationMatcher.ProbeUpdateResult pending = pendingRetransformations.getAndSet(null);
        if (pending == null || pending.isEmpty()) {
            return;
        }

        List<Class<?>> classesToRetransform = new ArrayList<>();

        // Find the physical loaded classes that correspond to the affected FQCNs
        for (Class<?> clazz : instrumentation.getAllLoadedClasses()) {
            String name = clazz.getName();
            String sourceFile = null;
            if (pending.getChangedKotlinPackages().contains(packageNameOf(name))) {
                sourceFile = ProbeClassTransformer.getSourceFileName(name, clazz.getClassLoader());
            }
            boolean match = pending.matches(name, sourceFile);

            if (match) {
                if (instrumentation.isModifiableClass(clazz)) {
                    classesToRetransform.add(clazz);
                }
            }
        }

        if (!classesToRetransform.isEmpty()) {
            try {
                instrumentation.retransformClasses(classesToRetransform.toArray(new Class<?>[0]));
                log.debug("Successfully retransformed " + classesToRetransform.size() + " affected classes.");
            } catch (Exception e) {
                log.error("Failed to retransform classes: " + e.getMessage(), e);
            }
        }
    }

    public static ProbeLocationMatcher getMatcher() {
        return probeLocationMatcher;
    }

    private static String packageNameOf(String fqcn) {
        int separator = fqcn.lastIndexOf('.');
        return separator == -1 ? "" : fqcn.substring(0, separator);
    }
}
