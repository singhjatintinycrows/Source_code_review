package com.hyperprobe.instrumentation;

import net.bytebuddy.agent.builder.AgentBuilder;
import net.bytebuddy.description.type.TypeDescription;
import net.bytebuddy.dynamic.DynamicType;
import net.bytebuddy.utility.JavaModule;
import org.objectweb.asm.ClassReader;
import org.objectweb.asm.ClassVisitor;
import org.objectweb.asm.Opcodes;

import java.io.IOException;
import java.io.InputStream;
import java.security.ProtectionDomain;
import java.util.Map;
import java.util.Set;

/**
 * ByteBuddy Transformer that applies the LineNumberAsmVisitor only to classes
 * that match the ProbeLocationMatcher criteria.
 */
public class ProbeClassTransformer implements AgentBuilder.Transformer {

    private final ProbeLocationMatcher matcher;

    public ProbeClassTransformer(ProbeLocationMatcher matcher) {
        this.matcher = matcher;
    }

    @Override
    public DynamicType.Builder<?> transform(DynamicType.Builder<?> builder,
                                            TypeDescription typeDescription,
                                            ClassLoader classLoader,
                                            JavaModule module,
                                            ProtectionDomain protectionDomain) {

        // Get active probes specifically for this matched class
        Map<Integer, Set<String>> probesForClass = matcher.getProbesForClass(typeDescription.getName());

        if (probesForClass != null && !probesForClass.isEmpty()) {
            return builder.visit(new LineNumberAsmVisitor(probesForClass));
        }

        Map<String, Map<Integer, Set<String>>> kotlinProbesBySource =
                matcher.getKotlinSourceProbesForClass(typeDescription.getName());
        if (kotlinProbesBySource != null && !kotlinProbesBySource.isEmpty()) {
            String sourceFile = getSourceFileName(typeDescription.getName(), classLoader);
            Map<Integer, Set<String>> sourceProbes = sourceFile != null ? kotlinProbesBySource.get(sourceFile) : null;
            if (sourceProbes != null && !sourceProbes.isEmpty()) {
                return builder.visit(LineNumberAsmVisitor.forKotlinSource(sourceProbes));
            }
            if (sourceFile != null) {
                // A Kotlin probe exists in this package, but not for this source file.
                // Returning the unmodified builder avoids touching unrelated classes.
                return builder;
            }

            // Some custom class loaders do not expose class resources. Fall back to
            // checking SourceFile from the bytes already being visited by ASM.
            return builder.visit(LineNumberAsmVisitor.forKotlinSources(kotlinProbesBySource));
        }

        return builder; // Sanity check, should not happen due to ElementMatcher
    }

    static String getSourceFileName(String typeName, ClassLoader classLoader) {
        try {
            String resourceName = typeName.replace('.', '/') + ".class";
            InputStream stream = classLoader == null
                    ? ClassLoader.getSystemResourceAsStream(resourceName)
                    : classLoader.getResourceAsStream(resourceName);
            if (stream == null) {
                return null;
            }

            try (InputStream classStream = stream) {
                ClassReader reader = new ClassReader(classStream);
                final String[] sourceFile = new String[1];
                reader.accept(new ClassVisitor(Opcodes.ASM9) {
                    @Override
                    public void visitSource(String source, String debug) {
                        sourceFile[0] = source;
                    }
                }, ClassReader.SKIP_CODE | ClassReader.SKIP_FRAMES);
                return sourceFile[0];
            }
        } catch (IOException | RuntimeException ignored) {
            return null;
        }
    }
}
