package com.hyperprobe.evaluator;

import org.mvel2.MVEL;
import org.mvel2.integration.VariableResolver;
import org.mvel2.integration.VariableResolverFactory;
import org.mvel2.integration.impl.BaseVariableResolverFactory;
import org.mvel2.integration.impl.MapVariableResolverFactory;

import java.io.Serializable;
import java.lang.reflect.Field;
import java.util.HashMap;
import java.util.Map;

/**
 * High-performance execution engine for evaluating dynamic conditions
 * and watch expressions using MVEL.
 */
public class MvelEvaluator {

    /**
     * Evaluates a boolean condition.
     */
    public static boolean evaluateCondition(String expression, Map<String, Object> context) {
        if (expression == null || expression.trim().isEmpty()) {
            return true;
        }

        try {
            Serializable compiled = CompiledExpressionCache.getCompiledExpression(expression);
            if (compiled == null) return false;

            VariableResolverFactory factory = createPermissiveFactory(context);
            Object thisObj = context.get("this");
            Object result = MVEL.executeExpression(compiled, thisObj, factory);
            
            if (result instanceof Boolean) {
                return (Boolean) result;
            }
            return false;
        } catch (Throwable t) {
            return false;
        }
    }

    /**
     * Evaluates an expression and returns the resulting object.
     */
    public static Object evaluateExpression(String expression, Map<String, Object> context) {
        if (expression == null || expression.trim().isEmpty()) {
            return null;
        }

        try {
            Serializable compiled = CompiledExpressionCache.getCompiledExpression(expression);
            if (compiled == null) return null;

            VariableResolverFactory factory = createPermissiveFactory(context);
            Object thisObj = context.get("this");
            
            // PARITY FIX: Use 'this' object as context if available to resolve class fields (e.g. 'numb')
            // while using the factory to resolve local variables (e.g. 'req', 'cartTotal').
            return MVEL.executeExpression(compiled, thisObj, factory);
        } catch (Throwable t) {
            return formatErrorMessage(t);
        }
    }

    /**
     * Specialized execution for string templates.
     */
    public static String evaluateTemplate(String template, Map<String, Object> context) throws Exception {
        if (template == null || template.trim().isEmpty()) return "";
        
        org.mvel2.templates.CompiledTemplate compiled = CompiledExpressionCache.getCompiledTemplate(template);
        if (compiled == null) return "";

        VariableResolverFactory factory = createPermissiveFactory(context);
        Object thisObj = context.get("this");
        Object result = org.mvel2.templates.TemplateRuntime.execute(compiled, thisObj, factory);
        return result != null ? result.toString() : "";
    }

    /**
     * Creates a MVEL VariableResolverFactory that handles local variables from the map
     * AND provides a fallback to use reflection (bypassing private/protected access)
     * for fields of the 'this' object.
     */
    private static VariableResolverFactory createPermissiveFactory(Map<String, Object> context) {
        // 1. Primary factory for local variables
        MapVariableResolverFactory localFactory = new MapVariableResolverFactory(context);
        
        Object thisObj = context.get("this");
        if (thisObj == null) {
            return localFactory;
        }

        // 2. Chained factory that resolves missing variables as fields of 'this' using reflection
        BaseVariableResolverFactory fieldFallbackFactory = new BaseVariableResolverFactory() {
            @Override
            public VariableResolver createVariable(String name, Object value) { return null; }
            @Override
            public VariableResolver createVariable(String name, Object value, Class<?> type) { return null; }
            @Override
            public boolean isTarget(String name) {
                try {
                    return getField(thisObj.getClass(), name) != null;
                } catch (Exception e) { return false; }
            }
            @Override
            public boolean isResolveable(String name) {
                return isTarget(name);
            }
            @Override
            public VariableResolver getVariableResolver(String name) {
                return new VariableResolver() {
                    @Override public String getName() { return name; }
                    @Override public Class getType() { return Object.class; }
                    @Override public void setStaticType(Class type) {}
                    @Override public int getFlags() { return 0; }
                    @Override public Object getValue() {
                        try {
                            Field f = getField(thisObj.getClass(), name);
                            f.setAccessible(true);
                            return f.get(thisObj);
                        } catch (Exception e) { 
                            // Log for internal tracing, but do not abort execution
                            // Returning null allows MVEL to handle the missing identifier gracefully
                            return null;
                        }
                    }
                    @Override public void setValue(Object value) {}
                };
            }
        };

        localFactory.setNextFactory(fieldFallbackFactory);
        return localFactory;
    }

    private static final Map<String, java.util.Optional<Field>> fieldCache = new java.util.concurrent.ConcurrentHashMap<>();

    private static Field getField(Class<?> clazz, String name) {
        String key = clazz.getName() + "#" + name;
        java.util.Optional<Field> cached = fieldCache.get(key);
        if (cached != null) return cached.orElse(null);
        
        Class<?> current = clazz;
        while (current != null && current != Object.class) {
            try {
                Field f = current.getDeclaredField(name);
                fieldCache.put(key, java.util.Optional.of(f));
                return f;
            } catch (NoSuchFieldException e) {
                current = current.getSuperclass();
            }
        }
        fieldCache.put(key, java.util.Optional.empty());
        return null;
    }

    /**
     * Formats an exception thrown during MVEL evaluation into a clean, human-readable
     * error message similar to what IDE debuggers display (e.g., IntelliJ).
     */
    public static String formatErrorMessage(Throwable t) {
        Throwable cause = t.getCause() != null ? t.getCause() : t;
        String message = cause.getMessage();
        
        if (message == null) {
            return "Error: " + cause.getClass().getSimpleName();
        }

        // MVEL errors often look like:
        // [Error: unresolvable property or identifier: myMissingVar]
        // [Near : {... myMissingVar ...}]
        // ...
        
        // 1. Check for unresolvable property (Java IDE style error)
        java.util.regex.Pattern pattern = java.util.regex.Pattern.compile("unresolvable property or identifier:\\s*([^\\n\\]]+)");
        java.util.regex.Matcher matcher = pattern.matcher(message);
        if (matcher.find()) {
            String varName = matcher.group(1).trim();
            return "Cannot resolve identifier '" + varName + "'";
        }

        // 2. Generic cleanup for other MVEL errors (strip multiline noise)
        // Extract just the core message inside [Error: ...] if it exists
        if (message.startsWith("[Error:")) {
            int endIdx = message.indexOf(']');
            if (endIdx > 0) {
                // Return just the text inside the brackets, skipping "[Error: "
                return "Error: " + message.substring(8, endIdx).trim();
            }
        }
        
        // 3. Fallback: return the first line of the error to avoid massive stack traces in the UI
        int newlineIdx = message.indexOf('\n');
        if (newlineIdx > 0) {
            return "Error: " + message.substring(0, newlineIdx).trim();
        }

        return "Error: " + message;
    }
}
