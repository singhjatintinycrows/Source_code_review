package com.hyperprobe.evaluator;

import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Validates MVEL expressions prior to compilation using conservative lexical/regex checks to enforce read-only evaluation.
 * Blocks unauthorized method/constructor invocations, assignments, and imports, while allowing a narrow allowlist
 * of standard-library methods intended to be side-effect free (parity with Python SDK).
 */
public class SafeASTValidator {

    /**
     * Read-only instance methods permitted on standard objects (String, Collection, Map, Number, Object).
     */
    private static final Set<String> SAFE_METHODS = Collections.unmodifiableSet(new HashSet<>(Arrays.asList(
        // String read-only operations
        "length", "isEmpty", "isBlank", "toLowerCase", "toUpperCase", "trim", "strip",
        "stripLeading", "stripTrailing", "startsWith", "endsWith", "contains", "charAt",
        "substring", "indexOf", "lastIndexOf", "matches", "split", "equalsIgnoreCase",
        "compareTo", "compareToIgnoreCase",
        
        // Collection / List / Set read-only operations
        "size", "get", "indexOf", "lastIndexOf", "subList", "toArray", "containsAll",
        
        // Map read-only operations
        "containsKey", "containsValue", "getOrDefault", "keySet", "values", "entrySet",
        
        // Number / Primitive boxed read-only operations
        "intValue", "longValue", "doubleValue", "floatValue", "byteValue", "shortValue",
        "booleanValue", "charValue", "isNaN", "isInfinite",
        
        // Universal safe Object / Optional methods
        "equals", "hashCode", "toString", "isPresent", "orElse"
    )));

    /**
     * Pure mathematical static methods allowed from java.lang.Math.
     */
    private static final Set<String> SAFE_MATH_METHODS = Collections.unmodifiableSet(new HashSet<>(Arrays.asList(
        "abs", "min", "max", "round", "floor", "ceil", "sqrt", "pow", "log", "log10",
        "exp", "sin", "cos", "tan", "asin", "acos", "atan", "atan2"
    )));

    /**
     * Safe classes permitted for static method invocation.
     */
    private static final Set<String> SAFE_STATIC_CLASSES = Collections.unmodifiableSet(new HashSet<>(Arrays.asList(
        "Math", "java.lang.Math",
        "Objects", "java.util.Objects",
        "String", "java.lang.String",
        "Integer", "java.lang.Integer",
        "Long", "java.lang.Long",
        "Double", "java.lang.Double",
        "Float", "java.lang.Float",
        "Boolean", "java.lang.Boolean",
        "Character", "java.lang.Character",
        "Byte", "java.lang.Byte",
        "Short", "java.lang.Short"
    )));

    /**
     * Safe static conversion / utility methods on standard wrapper types.
     */
    private static final Set<String> SAFE_STATIC_CONVERSIONS = Collections.unmodifiableSet(new HashSet<>(Arrays.asList(
        "valueOf", "parseInt", "parseLong", "parseDouble", "parseFloat", "parseBoolean",
        "parseByte", "parseShort", "toString", "equals", "compare"
    )));

    /**
     * Language keywords that may be followed by parentheses.
     */
    private static final Set<String> KEYWORDS_WITH_PARENS = Collections.unmodifiableSet(new HashSet<>(Arrays.asList(
        "if", "while", "for", "with", "foreach", "until", "do", "switch", "catch"
    )));

    private static final Pattern NEW_PATTERN = Pattern.compile("\\bnew\\s+");
    private static final Pattern KEYWORD_BLOCK_PATTERN = Pattern.compile("\\b(import|def|function|class|interface|enum)\\b");
    private static final Pattern ASSIGNMENT_MUTATION_PATTERN = Pattern.compile("(?<![=!<>])=(?![=])|(\\+=|-=|\\*=|/=|%=|\\|=|&=|\\^=|<<=|>>=|\\+\\+|--)");
    private static final Pattern METHOD_INVOCATION_PATTERN = Pattern.compile("(?<![a-zA-Z0-9_$])(?:([a-zA-Z0-9_$.]+)\\.)?([a-zA-Z0-9_$]+)\\s*\\(");

    private static volatile Boolean safeEvaluationOverride = null;
    private static volatile Boolean lastResolvedSafeEvaluation = null;

    /**
     * Checks if safe evaluation is enabled.
     * By default, safe evaluation is enabled (returns true) unless explicitly disabled
     * by setting HYPERPROBE_DISABLE_SAFE_EVALUATION=true.
     */
    public static boolean isSafeEvaluationEnabled() {
        if (safeEvaluationOverride != null) {
            return safeEvaluationOverride;
        }

        String disableVal = System.getProperty(
            "hyperprobe.disable.safe.evaluation",
            System.getenv("HYPERPROBE_DISABLE_SAFE_EVALUATION")
        );

        boolean enabled = !(disableVal != null && "true".equalsIgnoreCase(disableVal.trim()));

        Boolean prev = lastResolvedSafeEvaluation;
        if (prev != null && prev.booleanValue() != enabled) {
            CompiledExpressionCache.clear();
        }
        lastResolvedSafeEvaluation = enabled;

        return enabled;
    }

    /**
     * Programmatically sets the safe evaluation override flag.
     * Setting this clears the compiled expression cache to avoid stale bytecode.
     */
    public static void setSafeEvaluationEnabled(Boolean enabled) {
        safeEvaluationOverride = enabled;
        CompiledExpressionCache.clear();
    }

    /**
     * Resets the safe evaluation override flag to default (env/property based).
     */
    public static void resetSafeEvaluationOverride() {
        safeEvaluationOverride = null;
        CompiledExpressionCache.clear();
    }

    /**
     * Validates an expression for side-effects and unauthorized method calls.
     *
     * @param expression The raw expression to validate.
     * @throws SecurityException if the expression contains forbidden operations.
     */
    public static void validate(String expression) {
        if (!isSafeEvaluationEnabled()) {
            return;
        }

        if (expression == null || expression.trim().isEmpty()) {
            return;
        }

        // 1. Strip comments and string literals to prevent false positives/bypasses
        String clean = stripCommentsAndStrings(expression);

        // 2. Reject constructor invocations ('new')
        if (NEW_PATTERN.matcher(clean).find()) {
            throw new SecurityException("Object instantiation ('new') is strictly forbidden in probe expressions.");
        }

        // 3. Reject imports, function declarations, type definitions
        if (KEYWORD_BLOCK_PATTERN.matcher(clean).find()) {
            throw new SecurityException("Imports and custom definitions are strictly forbidden in probe expressions.");
        }

        // 4. Reject assignments and mutating operators
        if (ASSIGNMENT_MUTATION_PATTERN.matcher(clean).find()) {
            throw new SecurityException("Assignments and state mutations are strictly forbidden in probe expressions.");
        }

        // 5. Detect and validate all function / method invocations
        Matcher m = METHOD_INVOCATION_PATTERN.matcher(clean);
        while (m.find()) {
            String prefix = m.group(1);
            String methodName = m.group(2);

            // Skip language control keywords (if, while, etc.) when not preceded by a dot
            if (prefix == null && KEYWORDS_WITH_PARENS.contains(methodName)) {
                continue;
            }

            // Check if it is a static method invocation on a class
            if (prefix != null && isClassReference(prefix)) {
                if (SAFE_STATIC_CLASSES.contains(prefix)) {
                    if (prefix.endsWith("Math") && SAFE_MATH_METHODS.contains(methodName)) {
                        continue; // Permitted Math static method
                    }
                    if (SAFE_METHODS.contains(methodName) || SAFE_STATIC_CONVERSIONS.contains(methodName)) {
                        continue; // Permitted safe static conversion / method
                    }
                    throw new SecurityException("Static method invocation '" + prefix + "." + methodName + "()' is strictly forbidden.");
                } else {
                    throw new SecurityException("Static method invocation on unauthorized class '" + prefix + "' is strictly forbidden.");
                }
            }

            // Check against safe instance methods allowlist
            if (!SAFE_METHODS.contains(methodName)) {
                throw new SecurityException("Method invocation '." + methodName + "()' is strictly forbidden during probe evaluation.");
            }
        }
    }

    /**
     * Determines whether a method invocation prefix represents a class reference (static call)
     * rather than an instance/variable reference.
     */
    private static boolean isClassReference(String prefix) {
        if (prefix == null || prefix.isEmpty()) {
            return false;
        }

        // Package prefix convention (e.g. java.lang.System, com.foo.Bar)
        if (prefix.startsWith("java.") || prefix.startsWith("javax.") || prefix.startsWith("com.")
                || prefix.startsWith("org.") || prefix.startsWith("io.") || prefix.startsWith("net.")
                || prefix.startsWith("co.")) {
            return true;
        }

        // Identifier capitalization convention (e.g. Math, Paths, Arrays, System)
        int lastDot = prefix.lastIndexOf('.');
        String simpleName = lastDot >= 0 ? prefix.substring(lastDot + 1) : prefix;
        return !simpleName.isEmpty() && Character.isUpperCase(simpleName.charAt(0));
    }

    /**
     * Strips single-line comments, multi-line comments, and string literals (both single and double quoted)
     * while properly respecting escape sequences.
     */
    public static String stripCommentsAndStrings(String expr) {
        StringBuilder sb = new StringBuilder(expr.length());
        int n = expr.length();
        int i = 0;

        while (i < n) {
            char c = expr.charAt(i);

            // Single-line comment: // ...
            if (c == '/' && i + 1 < n && expr.charAt(i + 1) == '/') {
                i += 2;
                while (i < n && expr.charAt(i) != '\n' && expr.charAt(i) != '\r') {
                    i++;
                }
                continue;
            }

            // Multi-line comment: /* ... */
            if (c == '/' && i + 1 < n && expr.charAt(i + 1) == '*') {
                i += 2;
                while (i + 1 < n && !(expr.charAt(i) == '*' && expr.charAt(i + 1) == '/')) {
                    i++;
                }
                i += 2; // skip */
                sb.append(' ');
                continue;
            }

            // Single quote string: '...'
            if (c == '\'') {
                i++;
                while (i < n) {
                    if (expr.charAt(i) == '\\') {
                        i += 2; // skip escaped character
                        continue;
                    }
                    if (expr.charAt(i) == '\'') {
                        i++;
                        break;
                    }
                    i++;
                }
                sb.append("''");
                continue;
            }

            // Double quote string: "..."
            if (c == '"') {
                i++;
                while (i < n) {
                    if (expr.charAt(i) == '\\') {
                        i += 2; // skip escaped character
                        continue;
                    }
                    if (expr.charAt(i) == '"') {
                        i++;
                        break;
                    }
                    i++;
                }
                sb.append("\"\"");
                continue;
            }

            sb.append(c);
            i++;
        }

        return sb.toString();
    }
}
