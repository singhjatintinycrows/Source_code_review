package com.hyperprobe.evaluator;

import com.hyperprobe.config.logging.HyperProbeLogger;
import org.mvel2.MVEL;
import org.mvel2.ParserConfiguration;
import org.mvel2.ParserContext;
import org.mvel2.compiler.CompiledExpression;
import org.mvel2.compiler.ExpressionCompiler;
import org.mvel2.integration.PropertyHandler;
import org.mvel2.integration.PropertyHandlerFactory;
import org.mvel2.integration.VariableResolverFactory;
import org.mvel2.templates.CompiledTemplate;
import org.mvel2.templates.TemplateCompiler;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Thread-safe cache for compiled MVEL expressions.
 * Ensures expressions are parsed and compiled only once, drastically 
 * reducing overhead during high-throughput probe execution.
 */
public class CompiledExpressionCache {

    private static final HyperProbeLogger log = HyperProbeLogger.getLogger(CompiledExpressionCache.class);

    private static final Map<String, Serializable> expressionCache = new ConcurrentHashMap<>();
    private static final Map<String, CompiledTemplate> templateCache = new ConcurrentHashMap<>();
    
    // Globally shared parser context
    private static final ParserContext PARSER_CONTEXT;

    static {
        // Enforce Read-Only sandbox to mimic V8's throwOnSideEffect: true
        // This prevents expressions like `user.password = "hacked"` from mutating state.
        PropertyHandlerFactory.registerPropertyHandler(Object.class, new PropertyHandler() {
            @Override
            public Object getProperty(String name, Object contextObj, VariableResolverFactory variableFactory) {
                // Allow read access, letting MVEL's default reflection extract the property.
                return org.mvel2.PropertyAccessor.get(name, contextObj);
            }

            @Override
            public Object setProperty(String name, Object contextObj, VariableResolverFactory variableFactory, Object value) {
                if (SafeASTValidator.isSafeEvaluationEnabled()) {
                    throw new UnsupportedOperationException("Side effects are blocked: Cannot mutate property '" + name + "' during probe evaluation.");
                }
                org.mvel2.PropertyAccessor.set(contextObj, name, value);
                return value;
            }
        });

        ParserConfiguration config = new ParserConfiguration();
        config.setAllowBootstrapBypass(false);
        
        PARSER_CONTEXT = new ParserContext(config);
        // We MUST keep type enforcement false to allow dynamic JS-like expression evaluation.
        // Side-effects are now handled via the PropertyHandler above.
        PARSER_CONTEXT.setStrictTypeEnforcement(false);
        PARSER_CONTEXT.setStrongTyping(false);
    }

    /**
     * Compiles an MVEL expression or retrieves it from the cache.
     *
     * @param expression The raw string expression.
     * @return The compiled Serializable MVEL AST.
     */
    public static Serializable getCompiledExpression(String expression) {
        if (expression == null || expression.trim().isEmpty()) {
            return null;
        }

        // Fast path
        Serializable compiled = expressionCache.get(expression);
        if (compiled == null) {
            try {
                validateNoSideEffects(expression, false);
                ExpressionCompiler compiler = new ExpressionCompiler(expression, PARSER_CONTEXT);
                compiled = compiler.compile();
                expressionCache.put(expression, compiled);
            } catch (Exception e) {
                log.error("Failed to compile MVEL expression: " + expression + ". Error: " + e.getMessage(), e);
                return null;
            }
        }
        return compiled;
    }

    /**
     * Compiles an MVEL template or retrieves it from the cache.
     *
     * @param template The raw string template.
     * @return The compiled MVEL template.
     */
    public static CompiledTemplate getCompiledTemplate(String template) {
        if (template == null || template.trim().isEmpty()) {
            return null;
        }

        CompiledTemplate compiled = templateCache.get(template);
        if (compiled == null) {
            try {
                validateNoSideEffects(template, true);
                compiled = TemplateCompiler.compileTemplate(template, PARSER_CONTEXT);
                templateCache.put(template, compiled);
            } catch (Exception e) {
                log.error("Failed to compile MVEL template: " + template + ". Error: " + e.getMessage(), e);
                return null;
            }
        }
        return compiled;
    }

    private static final Pattern TAG_START_PATTERN = Pattern.compile("@[a-zA-Z]*\\{");

    private static void validateNoSideEffects(String script, boolean isTemplate) {
        if (!SafeASTValidator.isSafeEvaluationEnabled()) {
            return;
        }
        if (isTemplate) {
            List<String> expressions = extractTemplateExpressions(script);
            for (String expr : expressions) {
                SafeASTValidator.validate(expr);
            }
        } else {
            SafeASTValidator.validate(script);
        }
    }

    private static List<String> extractTemplateExpressions(String template) {
        List<String> expressions = new ArrayList<>();
        if (template == null || template.isEmpty()) {
            return expressions;
        }

        Matcher matcher = TAG_START_PATTERN.matcher(template);
        int searchIndex = 0;
        int n = template.length();

        while (searchIndex < n && matcher.find(searchIndex)) {
            int startExpr = matcher.end(); // Index right after '{'
            int i = startExpr;
            int depth = 1;

            while (i < n && depth > 0) {
                char c = template.charAt(i);

                // Single-line comment inside tag: // ...
                if (c == '/' && i + 1 < n && template.charAt(i + 1) == '/') {
                    i += 2;
                    while (i < n && template.charAt(i) != '\n' && template.charAt(i) != '\r') {
                        i++;
                    }
                    continue;
                }

                // Multi-line comment inside tag: /* ... */
                if (c == '/' && i + 1 < n && template.charAt(i + 1) == '*') {
                    i += 2;
                    while (i + 1 < n && !(template.charAt(i) == '*' && template.charAt(i + 1) == '/')) {
                        i++;
                    }
                    i = Math.min(i + 2, n);
                    continue;
                }

                // Single-quoted string: '...'
                if (c == '\'') {
                    i++;
                    while (i < n) {
                        if (template.charAt(i) == '\\') {
                            i += 2;
                            continue;
                        }
                        if (template.charAt(i) == '\'') {
                            i++;
                            break;
                        }
                        i++;
                    }
                    continue;
                }

                // Double-quoted string: "..."
                if (c == '"') {
                    i++;
                    while (i < n) {
                        if (template.charAt(i) == '\\') {
                            i += 2;
                            continue;
                        }
                        if (template.charAt(i) == '"') {
                            i++;
                            break;
                        }
                        i++;
                    }
                    continue;
                }

                if (c == '{') {
                    depth++;
                } else if (c == '}') {
                    depth--;
                    if (depth == 0) {
                        expressions.add(template.substring(startExpr, i));
                        searchIndex = i + 1;
                        break;
                    }
                }
                i++;
            }

            if (depth > 0) {
                // Unclosed brace reaching EOF
                expressions.add(template.substring(startExpr, n));
                searchIndex = n;
            }
        }

        return expressions;
    }
    
    /**
     * Clears the expression caches. Usually called on Agent re-sync.
     */
    public static void clear() {
        expressionCache.clear();
        templateCache.clear();
    }
}
