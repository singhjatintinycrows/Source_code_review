package com.hyperprobe.evaluator;

import java.util.HashMap;
import java.util.Map;

/**
 * Encapsulates the variables and metadata exposed to MVEL scripts.
 * Serves as the "root object" or variable map during MVEL evaluation.
 */
public class EvaluationContext extends HashMap<String, Object> {

    public EvaluationContext(Map<String, Object> localVariables, String probeId, long timestamp, String threadName) {
        // Pre-size map: locals size + 3 metadata fields + safety margin
        super(localVariables != null ? localVariables.size() + 5 : 5);
        
        if (localVariables != null) {
            this.putAll(localVariables);
        }
        
        // Inject metadata variables accessible to the MVEL script
        this.put("@probeId", probeId);
        this.put("@timestamp", timestamp);
        this.put("@thread", threadName);
    }
}
