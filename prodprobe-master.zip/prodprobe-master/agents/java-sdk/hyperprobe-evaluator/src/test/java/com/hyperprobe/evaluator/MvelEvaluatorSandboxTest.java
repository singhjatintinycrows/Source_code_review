package com.hyperprobe.evaluator;

import org.junit.Test;
import java.util.*;
import static org.junit.Assert.*;

public class MvelEvaluatorSandboxTest {

    public static class TestUser {
        public String role = "guest";
        public String name = "Arif";
        public boolean wasDeleted = false;

        public void delete() {
            this.wasDeleted = true;
        }

        public String getRole() {
            return role;
        }
    }

    @Test
    public void testSideEffectsAreBlocked() {
        Map<String, Object> context = new HashMap<>();
        TestUser user = new TestUser();
        context.put("user", user);

        // Attempting to mutate the state
        String expression = "user.role = 'admin'";

        // Should return a formatted error and NOT mutate the role
        Object result = MvelEvaluator.evaluateExpression(expression, context);
        
        // Assert mutation failed
        assertEquals("guest", user.role);
        // Assert error was safely caught and formatted
        // Result is null because compilation fails early and safely returns null.
        assertNull(result);
    }

    @Test
    public void testSideEffectsBypassBlocked() {
        Map<String, Object> context = new HashMap<>();
        TestUser user = new TestUser();
        context.put("user", user);

        // Copilot bypass: assignment + equality check
        String expression = "user.role = 'admin' && 1 == 1";

        Object result = MvelEvaluator.evaluateExpression(expression, context);
        
        assertEquals("guest", user.role);
        assertNull(result);
        
        // Another bypass: compound assignment
        String expr2 = "user.role += 'admin'";
        Object res2 = MvelEvaluator.evaluateExpression(expr2, context);
        assertEquals("guest", user.role);
        assertNull(res2);
    }

    @Test
    public void testDangerousMethodCallBlockedInEvaluator() {
        Map<String, Object> context = new HashMap<>();
        TestUser user = new TestUser();
        context.put("user", user);

        String expression = "user.delete()";
        Object result = MvelEvaluator.evaluateExpression(expression, context);

        // Method was blocked at compile/validation stage, so wasDeleted is false
        assertFalse(user.wasDeleted);
        assertNull(result);
    }

    @Test
    public void testDangerousMethodCallBlockedInCondition() {
        Map<String, Object> context = new HashMap<>();
        TestUser user = new TestUser();
        context.put("user", user);

        String condition = "user.delete() == true";
        boolean passed = MvelEvaluator.evaluateCondition(condition, context);

        // Condition fails closed and method was never invoked
        assertFalse(passed);
        assertFalse(user.wasDeleted);
    }

    @Test
    public void testSafeMethodsAllowedInEvaluatorAndCondition() {
        Map<String, Object> context = new HashMap<>();
        TestUser user = new TestUser();
        context.put("user", user);
        context.put("items", Arrays.asList("item1", "item2", "item3"));
        context.put("scores", Collections.singletonMap("math", 95));

        // Safe String method
        Object lowerName = MvelEvaluator.evaluateExpression("user.name.toLowerCase()", context);
        assertEquals("arif", lowerName);

        // Safe Collection size
        Object size = MvelEvaluator.evaluateExpression("items.size()", context);
        assertEquals(3, size);

        // Safe Collection condition
        boolean conditionPassed = MvelEvaluator.evaluateCondition("items.size() > 2 && user.name.startsWith('A')", context);
        assertTrue(conditionPassed);

        // Safe Map get and containsKey
        Object mathScore = MvelEvaluator.evaluateExpression("scores.get('math')", context);
        assertEquals(95, mathScore);
        boolean hasMath = MvelEvaluator.evaluateCondition("scores.containsKey('math')", context);
        assertTrue(hasMath);

        // Safe Math static call
        Object maxVal = MvelEvaluator.evaluateExpression("Math.max(10, 20)", context);
        assertEquals(20, maxVal);
    }

    @Test
    public void testMapReplaceAndListReplaceAllBlockedFromMutation() {
        Map<String, Object> context = new HashMap<>();
        Map<String, Object> config = new HashMap<>();
        config.put("timeout", 1000);
        context.put("config", config);

        List<String> items = new ArrayList<>(Arrays.asList("a", "b", "c"));
        context.put("items", items);

        // Attempting map.replace via evaluateExpression
        Object res1 = MvelEvaluator.evaluateExpression("config.replace('timeout', 9999)", context);
        assertNull(res1);
        assertEquals(1000, config.get("timeout"));

        // Attempting map.replace via evaluateCondition
        boolean conditionPassed = MvelEvaluator.evaluateCondition("config.replace('timeout', 9999) != null", context);
        assertFalse(conditionPassed);
        assertEquals(1000, config.get("timeout"));
    }
}
