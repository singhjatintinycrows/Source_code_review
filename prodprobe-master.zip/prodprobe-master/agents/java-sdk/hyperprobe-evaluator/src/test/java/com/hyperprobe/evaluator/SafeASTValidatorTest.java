package com.hyperprobe.evaluator;

import org.junit.Test;

import static org.junit.Assert.fail;

public class SafeASTValidatorTest {

    @Test
    public void testAllowedPropertyAndOperatorExpressions() {
        String[] allowed = {
            "user.name",
            "order.items[0].price",
            "cartTotal > 100",
            "user.active && user.age >= 18",
            "a + b * c == 42",
            "user.role == 'admin'",
            "message != null ? message : 'default'",
            "items[index]"
        };

        for (String expr : allowed) {
            try {
                SafeASTValidator.validate(expr);
            } catch (Exception e) {
                fail("Expression should be allowed: " + expr + ", but failed with: " + e.getMessage());
            }
        }
    }

    @Test
    public void testAllowedSafeStringMethods() {
        String[] allowed = {
            "name.toLowerCase()",
            "name.toUpperCase()",
            "name.toLowerCase().startsWith('admin')",
            "email.endsWith('@company.com')",
            "str.contains('keyword')",
            "str.trim().length() > 0",
            "str.isEmpty()",
            "str.isBlank()",
            "str.substring(0, 5)",
            "str.charAt(0) == 'A'",
            "str.indexOf('abc') >= 0",
            "str.equalsIgnoreCase('ACTIVE')"
        };

        for (String expr : allowed) {
            try {
                SafeASTValidator.validate(expr);
            } catch (Exception e) {
                fail("String method expression should be allowed: " + expr + ", but failed with: " + e.getMessage());
            }
        }
    }

    @Test
    public void testAllowedSafeCollectionAndMapMethods() {
        String[] allowed = {
            "items.size() > 0",
            "items.isEmpty()",
            "items.get(0).price > 10",
            "items.contains(user.id)",
            "users.toArray()",
            "config.containsKey('max_retries')",
            "config.containsValue(100)",
            "config.get('timeout')",
            "config.getOrDefault('env', 'production')",
            "map.keySet().size()",
            "map.values()",
            "userOptional.isPresent()",
            "userOptional.orElse('anonymous')"
        };

        for (String expr : allowed) {
            try {
                SafeASTValidator.validate(expr);
            } catch (Exception e) {
                fail("Collection/Map expression should be allowed: " + expr + ", but failed with: " + e.getMessage());
            }
        }
    }

    @Test
    public void testAllowedSafeMathAndStaticConversions() {
        String[] allowed = {
            "Math.max(10, 20)",
            "Math.min(a, b)",
            "Math.abs(-42.5)",
            "Math.round(3.14159)",
            "Math.sqrt(144)",
            "Math.pow(2, 8)",
            "java.lang.Math.abs(delta)",
            "String.valueOf(user.id)",
            "Integer.parseInt('123')",
            "Double.parseDouble('3.14')",
            "Boolean.parseBoolean('true')",
            "Objects.equals(a, b)"
        };

        for (String expr : allowed) {
            try {
                SafeASTValidator.validate(expr);
            } catch (Exception e) {
                fail("Math/Static expression should be allowed: " + expr + ", but failed with: " + e.getMessage());
            }
        }
    }

    @Test
    public void testAllowedStringsWithSpecialCharactersAndComments() {
        String[] allowed = {
            "message == 'hello (world)'",
            "query == 'SELECT * FROM users WHERE (id = 1)'",
            "path == '/api/v1/delete()'",
            "status == 'a=b'",
            "/* comment with delete() */ user.name == 'admin'",
            "// single line comment with System.exit(0)\n items.size() > 0",
            "\"escaped \\\" quote with (paren)\" == str"
        };

        for (String expr : allowed) {
            try {
                SafeASTValidator.validate(expr);
            } catch (Exception e) {
                fail("Expression with string literals/comments should be allowed: " + expr + ", but failed with: " + e.getMessage());
            }
        }
    }

    @Test
    public void testBlockedMutatingJdkMethodCollisions() {
        String[] dangerous = {
            "config.replace('timeout', 9999)",
            "config.replace('key', 'old', 'new')",
            "items.replaceAll(x -> 'tampered')",
            "map.replaceAll((k, v) -> 'tampered')",
            "str.replace('a', 'b')",
            "str.replaceAll('\\s+', '')",
            "str.replaceFirst('a', 'b')"
        };

        for (String expr : dangerous) {
            try {
                SafeASTValidator.validate(expr);
                fail("Mutating JDK method collision must be blocked: " + expr);
            } catch (SecurityException expected) {
                // Expected
            }
        }
    }

    @Test
    public void testBlockedDangerousApplicationMethods() {
        String[] dangerous = {
            "userDao.deleteById(123)",
            "user.delete()",
            "cart.items.clear()",
            "cart.addItem(item)",
            "paymentService.charge(account, 100)",
            "account.withdraw(500)",
            "database.dropTable('users')",
            "order.cancel()",
            "cache.flush()",
            "file.delete()",
            "order.getPayment().refund()",
            "user.setName('admin')"
        };

        for (String expr : dangerous) {
            try {
                SafeASTValidator.validate(expr);
                fail("Dangerous application method must be blocked: " + expr);
            } catch (SecurityException expected) {
                // Expected
            }
        }
    }

    @Test
    public void testBlockedSystemAndReflectionMethods() {
        String[] dangerous = {
            "System.exit(0)",
            "System.gc()",
            "Runtime.getRuntime().exec('rm -rf /')",
            "user.getClass().getMethod('delete').invoke(user)",
            "Class.forName('java.lang.System').getMethod('exit', int.class).invoke(null, 0)",
            "Thread.sleep(1000)",
            "ProcessBuilder.start()",
            "Paths.get('/tmp')",
            "java.nio.file.Paths.get('/etc/passwd')",
            "Arrays.asList(1, 2, 3)",
            "System.getProperty('user.dir')"
        };

        for (String expr : dangerous) {
            try {
                SafeASTValidator.validate(expr);
                fail("System/Reflection/Static method must be blocked: " + expr);
            } catch (SecurityException expected) {
                // Expected
            }
        }
    }

    @Test
    public void testBlockedConstructors() {
        String[] dangerous = {
            "new java.io.File('/tmp')",
            "new ProcessBuilder('ls')",
            "new Object()",
            "new StringBuilder().append('hack')",
            "new/*comment*/java.io.File('/tmp')",
            "new/*comment*/Object()"
        };

        for (String expr : dangerous) {
            try {
                SafeASTValidator.validate(expr);
                fail("Constructor invocation must be blocked: " + expr);
            } catch (SecurityException expected) {
                // Expected
            }
        }
    }

    @Test
    public void testBlockedImportsAndFunctionDefinitions() {
        String[] dangerous = {
            "import java.io.File",
            "import/*comment*/java.lang.System",
            "def customFunc() { return 1; }",
            "function hack() { System.exit(0); }"
        };

        for (String expr : dangerous) {
            try {
                SafeASTValidator.validate(expr);
                fail("Import/Function definition must be blocked: " + expr);
            } catch (SecurityException expected) {
                // Expected
            }
        }
    }

    @Test
    public void testBlockedMutationsAndAssignments() {
        String[] dangerous = {
            "user.role = 'admin'",
            "user.role += 'admin'",
            "user.role -= 'admin'",
            "user.count++",
            "user.count--",
            "++user.count",
            "--user.count",
            "a = b = c",
            "// comment\nuser.role = 'admin'",
            "user.role = 'admin'\n1 == 1",
            "// comment\nuser.count++",
            "user.active == true;\nuser.role = 'admin'"
        };

        for (String expr : dangerous) {
            try {
                SafeASTValidator.validate(expr);
                fail("Assignment/Mutation must be blocked: " + expr);
            } catch (SecurityException expected) {
                // Expected
            }
        }
    }
}
