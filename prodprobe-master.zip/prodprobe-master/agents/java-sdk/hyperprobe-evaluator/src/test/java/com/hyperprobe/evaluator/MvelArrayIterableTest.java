package com.hyperprobe.evaluator;

import org.junit.Test;
import java.util.HashMap;
import java.util.Map;
import java.util.Collection;

public class MvelArrayIterableTest {

    @Test
    public void testPrimitiveArrayEvaluation() {
        int[] intArray = {10, 20, 30, 40, 50, 60};
        Map<String, Object> context = new HashMap<>();
        context.put("intArray", intArray);

        Object result = MvelEvaluator.evaluateExpression("intArray", context);
        
        System.out.println("MVEL Result Class: " + result.getClass().getName());
        if (result instanceof Collection) {
            System.out.println("It is a Collection. Size: " + ((Collection<?>) result).size());
        }
        if (result instanceof Iterable) {
            System.out.println("It is Iterable.");
            int i = 0;
            for (Object obj : (Iterable<?>) result) {
                System.out.println("  Item " + i + ": " + obj);
                i++;
            }
            System.out.println("Total iterations: " + i);
        }
    }
}
