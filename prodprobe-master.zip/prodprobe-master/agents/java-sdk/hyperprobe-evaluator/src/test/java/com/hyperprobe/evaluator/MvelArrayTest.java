package com.hyperprobe.evaluator;

import org.junit.Test;
import java.util.HashMap;
import java.util.Map;

public class MvelArrayTest {

    @Test
    public void testPrimitiveArrayEvaluation() {
        int[] intArray = {10, 20, 30, 40, 50, 60};
        Map<String, Object> context = new HashMap<>();
        context.put("intArray", intArray);

        Object result = MvelEvaluator.evaluateExpression("intArray", context);
        
        System.out.println("MVEL Result Class: " + result.getClass().getName());
        if (result.getClass().isArray()) {
            System.out.println("It is an array. Length: " + java.lang.reflect.Array.getLength(result));
        } else if (result instanceof java.util.List) {
            System.out.println("It is a list. Size: " + ((java.util.List<?>) result).size());
        }
    }
}
