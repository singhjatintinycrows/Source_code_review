package com.hyperprobe.evaluator;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.util.*;

import static org.junit.Assert.*;

public class SafeEvaluationToggleTest {

    public static class TestUser {
        public String role = "guest";
        public String name = "Arif";
        public boolean wasDeleted = false;

        public void delete() {
            this.wasDeleted = true;
        }

        public String getRole() {
            return role;
        }

        public int calculateCustomScore(int multiplier) {
            return 42 * multiplier;
        }
    }

    @Before
    public void setUp() {
        SafeASTValidator.resetSafeEvaluationOverride();
        System.clearProperty("hyperprobe.disable.safe.evaluation");
        CompiledExpressionCache.clear();
    }

    @After
    public void tearDown() {
        SafeASTValidator.resetSafeEvaluationOverride();
        System.clearProperty("hyperprobe.disable.safe.evaluation");
        CompiledExpressionCache.clear();
    }

    @Test
    public void testSafeEvaluationEnabledByDefault() {
        assertTrue(SafeASTValidator.isSafeEvaluationEnabled());

        Map<String, Object> context = new HashMap<>();
        TestUser user = new TestUser();
        context.put("user", user);

        // Safe methods work
        Object name = MvelEvaluator.evaluateExpression("user.name.toLowerCase()", context);
        assertEquals("arif", name);

        // Dangerous/custom methods are blocked
        Object result = MvelEvaluator.evaluateExpression("user.delete()", context);
        assertNull(result);
        assertFalse(user.wasDeleted);

        // Condition with custom method fails closed
        boolean passed = MvelEvaluator.evaluateCondition("user.delete() == true", context);
        assertFalse(passed);
        assertFalse(user.wasDeleted);
    }

    @Test
    public void testUnsafeEvaluationAllowsCustomAndMutatingMethods() throws Exception {
        SafeASTValidator.setSafeEvaluationEnabled(false);
        assertFalse(SafeASTValidator.isSafeEvaluationEnabled());

        Map<String, Object> context = new HashMap<>();
        TestUser user = new TestUser();
        context.put("user", user);

        // 1. Custom method invocation works in expression evaluation
        Object score = MvelEvaluator.evaluateExpression("user.calculateCustomScore(2)", context);
        assertEquals(84, score);

        // 2. Custom method invocation works in condition evaluation
        boolean conditionPassed = MvelEvaluator.evaluateCondition("user.calculateCustomScore(2) > 80", context);
        assertTrue(conditionPassed);

        // 3. Custom method invocation works in templates
        String templateResult = MvelEvaluator.evaluateTemplate("User score: @{user.calculateCustomScore(2)}", context);
        assertEquals("User score: 84", templateResult);

        // 4. Method execution that modifies state succeeds in unsafe mode
        MvelEvaluator.evaluateExpression("user.delete()", context);
        assertTrue(user.wasDeleted);
    }

    @Test
    public void testSystemPropertyToggle() {
        // Test disabling via primary system property: hyperprobe.disable.safe.evaluation=true
        System.setProperty("hyperprobe.disable.safe.evaluation", "true");
        assertFalse(SafeASTValidator.isSafeEvaluationEnabled());

        Map<String, Object> context = new HashMap<>();
        TestUser user = new TestUser();
        context.put("user", user);

        Object role = MvelEvaluator.evaluateExpression("user.getRole()", context);
        assertEquals("guest", role);

        // In unsafe mode, evaluate custom score and ensure it gets cached
        Object unsafeScore = MvelEvaluator.evaluateExpression("user.calculateCustomScore(2)", context);
        assertEquals(84, unsafeScore);

        // Test re-enabling via system property WITHOUT manual cache clearing
        System.setProperty("hyperprobe.disable.safe.evaluation", "false");
        assertTrue(SafeASTValidator.isSafeEvaluationEnabled());

        // Cache must have been automatically invalidated on mode transition, blocking the cached unsafe expr
        Object blockedResult = MvelEvaluator.evaluateExpression("user.calculateCustomScore(2)", context);
        assertNull(blockedResult);
    }

    @Test
    public void testReEnablingSafeEvaluationRestoresProtection() {
        // Disable first
        SafeASTValidator.setSafeEvaluationEnabled(false);
        assertFalse(SafeASTValidator.isSafeEvaluationEnabled());

        // Re-enable
        SafeASTValidator.setSafeEvaluationEnabled(true);
        assertTrue(SafeASTValidator.isSafeEvaluationEnabled());

        Map<String, Object> context = new HashMap<>();
        TestUser user = new TestUser();
        context.put("user", user);

        // Dangerous method must be blocked again
        Object result = MvelEvaluator.evaluateExpression("user.delete()", context);
        assertNull(result);
        assertFalse(user.wasDeleted);
    }
}
