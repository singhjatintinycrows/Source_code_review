package com.hyperprobe.evaluator;

import org.junit.Test;
import java.util.*;
import static org.junit.Assert.*;

public class TemplateSandboxTest {

    public static class TestUser {
        public String role = "guest";
        public String name = "Arif";
        public boolean wasDeleted = false;

        public void delete() {
            this.wasDeleted = true;
        }
    }

    @Test
    public void testSideEffectsAreBlockedInTemplates() throws Exception {
        Map<String, Object> context = new HashMap<>();
        TestUser user = new TestUser();
        context.put("user", user);

        // Attempting to mutate the state inside a template
        String template = "User role is @{user.role = 'admin'}";

        String result = MvelEvaluator.evaluateTemplate(template, context);
        
        // Assert mutation failed
        assertEquals("guest", user.role);
    }

    @Test
    public void testDangerousMethodBlockedInTemplates() throws Exception {
        Map<String, Object> context = new HashMap<>();
        TestUser user = new TestUser();
        context.put("user", user);

        String template = "User status: @{user.delete()}";

        String result = MvelEvaluator.evaluateTemplate(template, context);

        // Method was blocked at validation time, so wasDeleted is false
        assertFalse(user.wasDeleted);
        assertEquals("", result);
    }

    @Test
    public void testSafeMethodsAllowedInTemplates() throws Exception {
        Map<String, Object> context = new HashMap<>();
        TestUser user = new TestUser();
        context.put("user", user);
        context.put("items", Arrays.asList("apple", "banana"));

        String template = "User @{user.name.toUpperCase()} has @{items.size()} items";

        String result = MvelEvaluator.evaluateTemplate(template, context);
        assertEquals("User ARIF has 2 items", result);
    }

    @Test
    public void testPlaintextAssignmentIsAllowedInTemplates() throws Exception {
        Map<String, Object> context = new HashMap<>();
        context.put("numb", 42);

        // This contains a plain-text '=' outside the expression block.
        // It must NOT trigger the side-effect validation failure.
        String template = "event_id=123 value=@{numb}";

        String result = MvelEvaluator.evaluateTemplate(template, context);
        
        assertEquals("event_id=123 value=42", result);
    }

    @Test
    public void testNestedBraceBlockBlockedInTemplates() throws Exception {
        Map<String, Object> context = new HashMap<>();
        TestUser user = new TestUser();
        context.put("user", user);

        // Attempting to hide dangerous method invocation inside nested braces
        String template = "Attempt: @code{ if (true) { user.delete(); } }";

        String result = MvelEvaluator.evaluateTemplate(template, context);

        // Assert method was blocked and not executed
        assertFalse(user.wasDeleted);
        assertEquals("", result);
    }

    @Test
    public void testNestedBraceSafeExpressionsAllowedInTemplates() throws Exception {
        Map<String, Object> context = new HashMap<>();
        TestUser user = new TestUser();
        context.put("user", user);

        // Safe nested braces e.g., string literal containing braces
        String template = "Formatted: @{user.name.contains('}') ? '{found}' : '{' + user.name + '}'}";

        String result = MvelEvaluator.evaluateTemplate(template, context);
        assertEquals("Formatted: {Arif}", result);
    }
}
