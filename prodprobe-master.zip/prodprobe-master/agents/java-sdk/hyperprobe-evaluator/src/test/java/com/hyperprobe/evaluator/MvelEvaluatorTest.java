package com.hyperprobe.evaluator;

import org.junit.Test;
import java.util.HashMap;
import java.util.Map;
import static org.junit.Assert.*;

public class MvelEvaluatorTest {

    @Test
    public void testEvaluateTemplateWithIntegerResult() throws Exception {
        Map<String, Object> context = new HashMap<>();
        context.put("numb", 3);
        
        // This template returns an Integer when evaluated by MVEL
        String template = "@{numb}";
        
        String result = MvelEvaluator.evaluateTemplate(template, context);
        assertEquals("3", result);
    }

    @Test
    public void testEvaluateTemplateWithMixedContent() throws Exception {
        Map<String, Object> context = new HashMap<>();
        context.put("numb", 3);
        
        String template = "Value is @{numb}";
        
        String result = MvelEvaluator.evaluateTemplate(template, context);
        assertEquals("Value is 3", result);
    }

    @Test
    public void testEvaluateTemplateWithNullResult() throws Exception {
        Map<String, Object> context = new HashMap<>();
        context.put("numb", null);
        
        String template = "@{numb}";
        
        String result = MvelEvaluator.evaluateTemplate(template, context);
        assertEquals("", result);
    }
}
