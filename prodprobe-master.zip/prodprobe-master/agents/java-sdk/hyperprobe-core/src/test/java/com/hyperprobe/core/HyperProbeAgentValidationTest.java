package com.hyperprobe.core;

import org.junit.Test;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

public class HyperProbeAgentValidationTest {
    @Test
    public void acceptsCanonicalUuidV4ServiceIds() {
        assertTrue(HyperProbeAgent.isValidServiceId("87c699ba-a5a4-4ca8-927b-e7b33707cf6d"));
        assertTrue(HyperProbeAgent.isValidServiceId("87C699BA-A5A4-4CA8-B27B-E7B33707CF6D"));
        assertTrue(HyperProbeAgent.isValidServiceId(" 87c699ba-a5a4-4ca8-927b-e7b33707cf6d "));
    }

    @Test
    public void rejectsNonV4AndMalformedServiceIds() {
        assertFalse(HyperProbeAgent.isValidServiceId("87c699ba-a5a4-1ca8-927b-e7b33707cf6d"));
        assertFalse(HyperProbeAgent.isValidServiceId("87c699ba-a5a4-4ca8-727b-e7b33707cf6d"));
        assertFalse(HyperProbeAgent.isValidServiceId("java-demo-service"));
        assertFalse(HyperProbeAgent.isValidServiceId(null));
    }

    @Test
    public void acceptsOnlyYesForTheNonUuidBypass() {
        assertTrue(HyperProbeAgent.isNonUuidAllowed("yes"));
        assertTrue(HyperProbeAgent.isNonUuidAllowed(" YES "));
        assertFalse(HyperProbeAgent.isNonUuidAllowed("true"));
        assertFalse(HyperProbeAgent.isNonUuidAllowed("no"));
        assertFalse(HyperProbeAgent.isNonUuidAllowed(null));
    }
}
