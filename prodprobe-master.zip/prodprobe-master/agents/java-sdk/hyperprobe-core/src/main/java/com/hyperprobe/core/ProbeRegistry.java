package com.hyperprobe.core;

import com.hyperprobe.instrumentation.InstrumentationEngine;
import com.hyperprobe.runtime.ProbeExecutionEngine;
import com.hyperprobe.runtime.domain.ProbeDefinition;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.Collections;

/**
 * Thread-safe registry for active probes.
 * Bridges the gap between the Broker config updates and the runtime/instrumentation engines.
 */
public class ProbeRegistry {

    private volatile Map<String, ProbeDefinition> probes = Collections.emptyMap();
    private boolean isSuspended = false;

    public ProbeRegistry() {
        ProbeExecutionEngine.setProbeExpiryCallback(() -> {
            // When a probe self-expires locally, we must synchronize that state back
            // into the global registry and remove its bytecodes
            synchronized (this) {
                if (!isSuspended) {
                    List<ProbeDefinition> remaining = ProbeExecutionEngine.getActiveProbes();
                    Map<String, ProbeDefinition> newMap = new java.util.HashMap<>();
                    for (ProbeDefinition p : remaining) {
                        newMap.put(p.getId(), p);
                    }
                    this.probes = Collections.unmodifiableMap(newMap);
                    InstrumentationEngine.updateProbeLocations(remaining);
                    InstrumentationEngine.retransformAffectedClasses();
                }
            }
        });
    }

    /**
     * Replaces the currently active probes with a new set from the Broker.
     * Triggers updates to the Execution Engine and Instrumentation pipeline.
     */
    public synchronized void updateProbes(List<ProbeDefinition> newProbes) {
        Map<String, ProbeDefinition> newMap = new java.util.HashMap<>();
        for (ProbeDefinition p : newProbes) {
            newMap.put(p.getId(), p);
        }
        this.probes = Collections.unmodifiableMap(newMap);

        if (!isSuspended) {
            applyToEngines(newProbes);
        }
    }

    public synchronized void suspend() {
        if (isSuspended) return;
        isSuspended = true;
        applyToEngines(Collections.emptyList());
    }

    public synchronized void resume() {
        if (!isSuspended) return;
        isSuspended = false;
        applyToEngines(getAllProbes());
    }

    public synchronized void removeProbes(List<String> ids) {
        boolean changed = false;
        Map<String, ProbeDefinition> newMap = new java.util.HashMap<>(this.probes);
        for (String id : ids) {
            if (newMap.remove(id) != null) {
                changed = true;
            }
        }
        if (changed) {
            this.probes = Collections.unmodifiableMap(newMap);
            if (!isSuspended) {
                applyToEngines(new ArrayList<>(this.probes.values()));
            }
        }
    }

    private void applyToEngines(List<ProbeDefinition> probesToApply) {
        // 1. Update the Runtime Execution Engine mapping
        ProbeExecutionEngine.updateProbes(probesToApply);

        // 2. Pass definitions to the Instrumentation Layer to resolve locations
        InstrumentationEngine.updateProbeLocations(probesToApply);

        // 3. Trigger JVM Retransformation on affected loaded classes
        InstrumentationEngine.retransformAffectedClasses();
    }

    public ProbeDefinition getProbe(String id) {
        return probes.get(id);
    }

    public List<ProbeDefinition> getAllProbes() {
        return new ArrayList<>(probes.values());
    }
}
