package com.hyperprobe.core;

import com.hyperprobe.runtime.domain.TelemetryEvent;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.LinkedBlockingDeque;

/**
 * Thread-safe, bounded buffer for telemetry events.
 * Events are enqueued by high-performance runtime threads and
 * periodically dequeued by a background flushing thread.
 */
public class TelemetryQueue {

    // Bounded queue prevents OutOfMemoryError if the Broker goes down
    // We use a Deque to allow re-queueing failed batches back to the front
    private final LinkedBlockingDeque<TelemetryEvent> queue;
    private final QuotaManager quotaManager;

    public TelemetryQueue(int maxQueueSize, QuotaManager quotaManager) {
        this.queue = new LinkedBlockingDeque<>(maxQueueSize);
        this.quotaManager = quotaManager;
    }

    /**
     * Attempts to add an event to the queue.
     * Non-blocking. If the queue is full, the event is safely dropped.
     */
    public void enqueue(TelemetryEvent event) {
        // Enforce bandwidth limits (rough estimation of JSON payload size based on frames/vars)
        int estimatedBytes = estimateSize(event);
        if (quotaManager.consumeBandwidth(estimatedBytes)) {
            // offer() returns false if full, successfully dropping without blocking
            boolean accepted = queue.offer(event);
            if (!accepted) {
                // Refund the bandwidth since we couldn't actually queue the event
                quotaManager.refundBandwidth(estimatedBytes);
                // TODO: Metric for dropped events due to queue full
            }
        } else {
            // TODO: Metric for dropped events due to bandwidth quota
        }
    }
    
    /**
     * Re-queues a batch of events to the front of the queue, honoring the max queue size.
     * This is used when the telemetry exporter fails to send to the broker.
     */
    public void requeueBatch(List<TelemetryEvent> failedBatch) {
        // We iterate backwards to preserve the original ordering when pushing to the front
        for (int i = failedBatch.size() - 1; i >= 0; i--) {
            // offerFirst returns false if the deque is full. We safely drop the rest.
            if (!queue.offerFirst(failedBatch.get(i))) {
                break; 
            }
        }
    }

    /**
     * Drains all currently buffered events.
     * @return A list of events ready to be sent to the broker.
     */
    public List<TelemetryEvent> flush() {
        List<TelemetryEvent> batch = new ArrayList<>(queue.size());
        queue.drainTo(batch);
        return batch;
    }

    private int estimateSize(TelemetryEvent event) {
        // Simple heuristic: Base size + Object graph estimate + Stack frame estimate
        int size = 100; 
        if (event.getCapturedVars() != null) size += 500; 
        if (event.getStackFrames() != null) size += (event.getStackFrames().length * 100);
        if (event.getEvaluatedLog() != null) size += event.getEvaluatedLog().length();
        return size;
    }
}
