package com.hyperprobe.core;

import com.hyperprobe.core.ProbeRegistry;
import com.hyperprobe.runtime.domain.ProbeDefinition;
import com.hyperprobe.runtime.domain.ProbeType;
import com.hyperprobe.config.logging.HyperProbeLogger;
import hyperprobe.agent.v1.Agent.GetProbesRequest;
import hyperprobe.agent.v1.Agent.GetProbesResponse;
import hyperprobe.agent.v1.Agent.AgentGlobalConfig;
import hyperprobe.agent.v1.Agent.Probe;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

public class ProbeSyncService {

    private static final HyperProbeLogger log = HyperProbeLogger.getLogger(ProbeSyncService.class);

    private final BrokerClient brokerClient;
    private final ProbeRegistry probeRegistry;
    private final GetProbesRequest syncRequest;
    private final long defaultSyncIntervalMs;
    
    private ScheduledExecutorService scheduler;

    public ProbeSyncService(BrokerClient brokerClient, ProbeRegistry probeRegistry, String agentId, String serviceId, String env, String commitSha, String agentVersion, long defaultSyncIntervalMs) {
        this.brokerClient = brokerClient;
        this.probeRegistry = probeRegistry;
        this.defaultSyncIntervalMs = defaultSyncIntervalMs > 0 ? defaultSyncIntervalMs : 60000;
        
        String hostname = "unknown";
        try {
            hostname = java.net.InetAddress.getLocalHost().getHostName();
        } catch (Exception e) {}

        this.syncRequest = GetProbesRequest.newBuilder()
                .setAgentId(agentId)
                .setServiceId(serviceId)
                .setEnvironment(env)
                .setLanguage("java")
                .setCommitSha(commitSha)
                .setAgentVersion(agentVersion)
                .setHostname(hostname)
                .build();
    }

    public void start() {
        if (scheduler != null && !scheduler.isShutdown()) return;

        scheduler = Executors.newSingleThreadScheduledExecutor(r -> {
            Thread t = new Thread(r, "hyperprobe-probe-sync");
            t.setDaemon(true);
            return t;
        });

        scheduler.schedule(this::sync, 0, TimeUnit.MILLISECONDS);
    }

    public void stop() {
        if (scheduler != null) {
            scheduler.shutdownNow();
        }
    }

    private void sync() {
        log.debug("syncWithBroker started");
        long nextSyncMs = defaultSyncIntervalMs;
        try {
            if (brokerClient == null) return;

            log.debug("syncWithBroker: calling brokerClient.getProbes()");
            GetProbesResponse response = brokerClient.syncProbes(syncRequest);
            if (response == null) return;
            
            log.debug("syncWithBroker: got %d probes from broker", response.getProbesCount());

            // Removed nextSyncMs updates from backend
            // if (response.getNextSyncIntervalMs() > 0) {
            //     nextSyncMs = response.getNextSyncIntervalMs();
            // }

            if (response.hasGlobalConfig()) {
                AgentGlobalConfig gc = response.getGlobalConfig();
                com.hyperprobe.serializer.SerializationConfig.updateConfig(
                        gc.getMaxObjectDepth(),
                        gc.getMaxArrayLength(),
                        gc.getMaxObjectProperties(),
                        gc.getMaxStringLength(),
                        gc.getStackFrameDepth(),
                        gc.getRedactKeysList(),
                        gc.getRedactValuesList()
                );
            }

            List<ProbeDefinition> newProbes = new ArrayList<>();
            for (Probe p : response.getProbesList()) {
                newProbes.add(mapProtoToDomain(p));
            }

            log.debug("Found %d probes to apply locally", newProbes.size());
            probeRegistry.updateProbes(newProbes);
            log.debug("Applied probes. Failed: 0");

        } catch (Throwable t) {
            log.error("Error during probe synchronization loop: " + t.getMessage(), t);
        } finally {
            if (scheduler != null && !scheduler.isShutdown()) {
                scheduler.schedule(this::sync, nextSyncMs, TimeUnit.MILLISECONDS);
            }
        }
    }

    private ProbeDefinition mapProtoToDomain(Probe p) {
        ProbeType domainType = mapType(p.getType());
        String secondaryLoc = p.getSecondaryRuntimeLocation().isEmpty() ? null : p.getSecondaryRuntimeLocation();
        Integer secondaryLine = p.getSecondaryRuntimeLine() > 0 ? p.getSecondaryRuntimeLine() : null;

        return new ProbeDefinition(
                p.getId(),
                domainType,
                p.getCondition(),
                p.getRuntimeLocation(),
                p.getRuntimeLine(),
                p.getRuntimeColumn() > 0 ? p.getRuntimeColumn() : null,
                secondaryLoc,
                secondaryLine,
                p.getSecondaryRuntimeColumn() > 0 ? p.getSecondaryRuntimeColumn() : null,
                p.getWatchExpressionsList(),
                Collections.emptyList(),
                p.getTemplate(),
                p.getMetricName(),
                p.getMetricExpression(),
                p.getCorrelationExpression(),
                p.getHitLimit(),
                p.getExpiryTime(),
                p.hasMaxObjectDepth() ? p.getMaxObjectDepth() : null,
                p.hasMaxArrayLength() ? p.getMaxArrayLength() : null,
                p.hasStackFrameDepth() ? p.getStackFrameDepth() : null,
                p.hasMaxObjectProperties() ? p.getMaxObjectProperties() : null,
                p.hasMaxStringLength() ? p.getMaxStringLength() : null,
                p.hasShouldCaptureTraceId() ? p.getShouldCaptureTraceId() : false,
                p.hasLogLevel() && !p.getLogLevel().trim().isEmpty() ? p.getLogLevel().trim() : null,
                p.hasShouldLogToStdout() ? p.getShouldLogToStdout() : false
        );
    }

    private com.hyperprobe.runtime.domain.ProbeType mapType(hyperprobe.agent.v1.Agent.ProbeType protoType) {
        switch (protoType) {
            case PROBE_TYPE_LOG: return com.hyperprobe.runtime.domain.ProbeType.LOG;
            case PROBE_TYPE_METRIC: return com.hyperprobe.runtime.domain.ProbeType.METRIC;
            case PROBE_TYPE_COUNTER: return com.hyperprobe.runtime.domain.ProbeType.COUNTER;
            case PROBE_TYPE_DURATION: return com.hyperprobe.runtime.domain.ProbeType.DURATION;
            case PROBE_TYPE_SNAPSHOT:
            default: return com.hyperprobe.runtime.domain.ProbeType.SNAPSHOT;
        }
    }
}
