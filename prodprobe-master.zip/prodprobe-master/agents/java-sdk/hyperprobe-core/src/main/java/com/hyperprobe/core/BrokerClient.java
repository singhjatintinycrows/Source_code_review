package com.hyperprobe.core;

import io.grpc.ManagedChannel;
import io.grpc.ManagedChannelBuilder;
import io.grpc.Metadata;
import io.grpc.ClientInterceptor;
import io.grpc.stub.MetadataUtils;
import hyperprobe.agent.v1.Agent.GetProbesRequest;
import hyperprobe.agent.v1.Agent.GetProbesResponse;
import hyperprobe.agent.v1.Agent.TelemetryBatch;
import hyperprobe.agent.v1.AgentBrokerGrpc;
import com.hyperprobe.config.logging.HyperProbeLogger;

import java.util.List;
import java.util.concurrent.TimeUnit;

public class BrokerClient {
    private static final HyperProbeLogger log = HyperProbeLogger.getLogger(BrokerClient.class);

    private final AgentBrokerGrpc.AgentBrokerBlockingStub blockingStub;
    private final ManagedChannel channel;

    public BrokerClient(String brokerUrl, String serviceId) {
        ManagedChannelBuilder<?> builder;
        if (brokerUrl != null && brokerUrl.startsWith("https://")) {
            if (log.isDebugEnabled()) {
                log.debug("Using secure https credentials for brokerUrl: " + brokerUrl);
            }
            builder = ManagedChannelBuilder.forTarget(brokerUrl.substring(8)).useTransportSecurity();
        } else if (brokerUrl != null && brokerUrl.startsWith("http://")) {
            if (log.isDebugEnabled()) {
                log.debug("Using insecure http credentials for brokerUrl: " + brokerUrl);
            }
            builder = ManagedChannelBuilder.forTarget(brokerUrl.substring(7)).usePlaintext();
        } else {
            if (log.isDebugEnabled()) {
                log.debug("Using insecure credentials for brokerUrl: " + brokerUrl);
            }
            builder = ManagedChannelBuilder.forTarget(brokerUrl).usePlaintext();
        }

        this.channel = builder.build();

        Metadata extraHeaders = new Metadata();
        Metadata.Key<String> serviceIdKey = Metadata.Key.of("x-hp-service-id", Metadata.ASCII_STRING_MARSHALLER);
        extraHeaders.put(serviceIdKey, serviceId);
        ClientInterceptor interceptor = MetadataUtils.newAttachHeadersInterceptor(extraHeaders);

        this.blockingStub = AgentBrokerGrpc.newBlockingStub(channel).withInterceptors(interceptor);
    }

    public GetProbesResponse syncProbes(GetProbesRequest request) {
        log.debug("Fetching probes for %s...", request.getServiceId());
        GetProbesResponse response = blockingStub.withDeadlineAfter(10, TimeUnit.SECONDS).getProbes(request);
        log.debug("Successfully fetched %d probes", response.getProbesCount());
        return response;
    }

    public List<String> exportTelemetry(TelemetryBatch batch) {
        return blockingStub.withDeadlineAfter(10, TimeUnit.SECONDS).reportTelemetry(batch).getFinishedProbeIdsList();
    }

    public void shutdown() {
        try {
            channel.shutdown().awaitTermination(5, TimeUnit.SECONDS);
        } catch (InterruptedException e) {
            channel.shutdownNow();
            Thread.currentThread().interrupt();
        }
    }
}
