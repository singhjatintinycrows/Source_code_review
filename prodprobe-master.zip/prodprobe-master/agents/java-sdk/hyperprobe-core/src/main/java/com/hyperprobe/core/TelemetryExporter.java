package com.hyperprobe.core;

import com.hyperprobe.core.TelemetryQueue;
import com.hyperprobe.config.logging.HyperProbeLogger;
import hyperprobe.agent.v1.Agent.TelemetryBatch;
import hyperprobe.agent.v1.Agent.TelemetryEvent;
import hyperprobe.agent.v1.Agent.StackFrame;

import java.util.List;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

public class TelemetryExporter {

    private static final HyperProbeLogger log = HyperProbeLogger.getLogger(TelemetryExporter.class);

    private final BrokerClient brokerClient;
    private final TelemetryQueue telemetryQueue;
    private final String agentId;

    private ScheduledExecutorService scheduler;

    public TelemetryExporter(BrokerClient brokerClient, TelemetryQueue telemetryQueue, String agentId) {
        this.brokerClient = brokerClient;
        this.telemetryQueue = telemetryQueue;
        this.agentId = agentId;
    }

    public void start(long intervalMs) {
        if (scheduler != null && !scheduler.isShutdown()) return;

        scheduler = Executors.newSingleThreadScheduledExecutor(r -> {
            Thread t = new Thread(r, "hyperprobe-telemetry-export");
            t.setDaemon(true);
            return t;
        });

        long safeIntervalMs = intervalMs > 0 ? intervalMs : 1000;
        scheduler.scheduleAtFixedRate(this::export, safeIntervalMs, safeIntervalMs, TimeUnit.MILLISECONDS);
    }

    public void stop() {
        if (scheduler != null) {
            scheduler.shutdownNow();
        }
    }

    private void export() {
        List<com.hyperprobe.runtime.domain.TelemetryEvent> domainBatch = null;
        try {
            domainBatch = telemetryQueue.flush();
            if (domainBatch.isEmpty()) return;
            
            log.debug("Flushing %d telemetry events to broker...", domainBatch.size());

            if (brokerClient == null) {
                log.warn("Telemetry flushed but no broker client is configured. Batch dropped.");
                return;
            }

            TelemetryBatch.Builder batchBuilder = TelemetryBatch.newBuilder()
                    .setAgentId(agentId);

            for (com.hyperprobe.runtime.domain.TelemetryEvent domainEvent : domainBatch) {
                batchBuilder.addEvents(mapDomainToProto(domainEvent));
            }

            List<String> finishedProbeIds = brokerClient.exportTelemetry(batchBuilder.build());
            log.debug("Successfully flushed %d telemetry events to broker", domainBatch.size());
            if (finishedProbeIds != null && !finishedProbeIds.isEmpty()) {
                HyperProbeAgent.getInstance().getProbeRegistry().removeProbes(finishedProbeIds);
            }

        } catch (Throwable t) {
            log.error("Error during telemetry export loop: " + t.getMessage(), t);
            if (domainBatch != null && !domainBatch.isEmpty()) {
                telemetryQueue.requeueBatch(domainBatch);
            }
        }
    }

    private TelemetryEvent mapDomainToProto(com.hyperprobe.runtime.domain.TelemetryEvent domainEvent) {
        TelemetryEvent.Builder builder = TelemetryEvent.newBuilder()
                .setProbeId(domainEvent.getProbeId())
                .setTimestampMs(domainEvent.getTimestampMs());

        if (domainEvent.getTraceId() != null) {
            builder.setTraceId(domainEvent.getTraceId());
        }

        if (domainEvent.getEvaluatedLog() != null) {
            builder.setEvaluatedLog(domainEvent.getEvaluatedLog());
        }

        if (domainEvent.getMetricValue() != null) {
            builder.setMetricValue(domainEvent.getMetricValue());
        }

        if (domainEvent.getCaptureError() != null) {
            builder.setCaptureError(domainEvent.getCaptureError());
        }

        if (domainEvent.getCapturedVars() != null) {
            java.util.Map<String, Object> scope = new java.util.HashMap<>();
            scope.put("type", "local");
            scope.put("name", "Local Scope");
            scope.put("vars", domainEvent.getCapturedVars());
            
            java.util.List<Object> frame = new java.util.ArrayList<>();
            frame.add(scope);
            
            java.util.List<Object> allFrames = new java.util.ArrayList<>();
            allFrames.add(frame);
            
            if (domainEvent.getStackFrames() != null && domainEvent.getStackFrames().length > 1) {
                for (int i = 1; i < domainEvent.getStackFrames().length; i++) {
                    allFrames.add(new java.util.ArrayList<>());
                }
            }

            com.hyperprobe.serializer.SerializationConfig global = com.hyperprobe.serializer.SerializationConfig.getInstance();
            builder.setCapturedVarsJson(com.hyperprobe.serializer.SafeJsonSerializer.serializeSanitized(allFrames));
        }

        if (domainEvent.getWatchResults() != null) {
            builder.setWatchResultsJson(com.hyperprobe.serializer.SafeJsonSerializer.serializeSanitized(domainEvent.getWatchResults()));
        }

        if (domainEvent.getStackFrames() != null) {
            for (StackTraceElement elem : domainEvent.getStackFrames()) {
                builder.addStackFrames(StackFrame.newBuilder()
                        .setFileName(elem.getFileName() != null ? elem.getFileName() : "Unknown")
                        .setFunctionName(elem.getMethodName())
                        // Clamp unknown (-1) or negative line numbers to 0
                        .setLineNumber(Math.max(0, elem.getLineNumber()))
                        .setColumnNumber(0)
                        .setClassName(elem.getClassName())
                        .build());
            }
        }

        return builder.build();
    }
}
