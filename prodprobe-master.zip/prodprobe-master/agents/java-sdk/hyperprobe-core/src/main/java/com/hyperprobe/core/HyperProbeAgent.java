package com.hyperprobe.core;

import com.hyperprobe.config.logging.HyperProbeLogger;
import com.hyperprobe.config.util.VersionUtils;

import java.util.List;
import java.util.UUID;
import java.util.regex.Pattern;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;
import java.util.Arrays;

/**
 * Main orchestration layer for the HyperProbe Java SDK 
 * Manages the lifecycle of the safety guardrails, background threads, and probe synchronization.
 */
public class HyperProbeAgent {

    private static final HyperProbeLogger log = HyperProbeLogger.getLogger(HyperProbeAgent.class);
    private static final Pattern UUID_V4_REGEX = Pattern.compile("^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-4[0-9a-fA-F]{3}-[89abAB][0-9a-fA-F]{3}-[0-9a-fA-F]{12}$");

    private static HyperProbeAgent instance;

    private final QuotaManager quotaManager;
    private final SafetyMonitor safetyMonitor;
    private final TelemetryQueue telemetryQueue;
    private final ProbeRegistry probeRegistry;

    private BrokerClient brokerClient;
    private TelemetryExporter telemetryExporter;
    private ProbeSyncService probeSyncService;
    private ScheduledExecutorService maintenanceScheduler;
    private ScheduledExecutorService cooldownScheduler;

    private boolean isRunning = false;

    private HyperProbeAgent(long hitsPerSec, long bandwidthKbPerSec, long cooldownSec) {
        this.quotaManager = new QuotaManager(hitsPerSec, bandwidthKbPerSec);
        
        this.maintenanceScheduler = Executors.newSingleThreadScheduledExecutor(r -> {
            Thread t = new Thread(r, "hyperprobe-maintenance");
            t.setDaemon(true);
            return t;
        });

        this.cooldownScheduler = Executors.newSingleThreadScheduledExecutor(r -> {
            Thread t = new Thread(r, "hyperprobe-cooldown");
            t.setDaemon(true);
            return t;
        });

        this.safetyMonitor = new SafetyMonitor((health, reason) -> this.handleHealthChange(health, reason, cooldownSec));
        
        this.telemetryQueue = new TelemetryQueue(100, quotaManager);
        this.probeRegistry = new ProbeRegistry();
        
        // Wire the runtime engine's telemetry captures straight into the local queue
        com.hyperprobe.runtime.ProbeExecutionEngine.setTelemetryCallback(telemetryQueue::enqueue);
        
        // Wire the quota manager to enforce global hit limits
        com.hyperprobe.runtime.ProbeExecutionEngine.setQuotaCheck(quotaManager::allowExecution);
    }

    public static HyperProbeAgent getInstance() {
        return instance;
    }

    public ProbeRegistry getProbeRegistry() {
        return probeRegistry;
    }

    public TelemetryQueue getTelemetryQueue() {
        return telemetryQueue;
    }

    /**
     * Initializes and starts the agent control plane.
     * Called by the AgentInitializer from the bootstrap layer.
     */
    public static synchronized void start() {
        if (instance != null && instance.isRunning) {
            return;
        }

        String commitSha = System.getenv("GIT_COMMIT");
        
        if (commitSha == null || commitSha.trim().isEmpty() || "unknown".equalsIgnoreCase(commitSha)) {
            log.forceInfo("\u001B[1m\u001B[33m⚠️ [HyperProbe] CRITICAL: Failed to start agent. A valid 'commitSha' is required via the GIT_COMMIT environment variable to ensure accurate coordinate resolution and prevent cross-deployment collisions.\u001B[0m");
            return;
        }

        String serviceId = System.getenv("HYPERPROBE_SERVICE_ID");
        if (serviceId == null || serviceId.trim().isEmpty()) {
            log.forceInfo("\u001B[1m\u001B[33m⚠️ [HyperProbe] CRITICAL: Failed to start agent. HYPERPROBE_SERVICE_ID is required.\u001B[0m");
            return;
        }

        if (!isValidServiceId(serviceId)) {
            String allowNonUuidEnv = System.getenv("HYPERPROBE_ALLOW_NON_UUID");
            boolean allowNonUuid = isNonUuidAllowed(allowNonUuidEnv);

            if (!allowNonUuid) {
                log.forceInfo("\u001B[1m\u001B[33m⚠️ [HyperProbe] CRITICAL: Failed to start agent. HYPERPROBE_SERVICE_ID is not a valid UUIDv4. Set HYPERPROBE_ALLOW_NON_UUID=yes to allow non-UUID identifiers.\u001B[0m");
                return;
            }
            log.warn("\u001B[1m\u001B[33m⚠️ [HyperProbe] WARN: serviceId is not a valid UUIDv4, please check again.\u001B[0m");
        }

        String env = System.getenv("HYPERPROBE_ENVIRONMENT");
        if (env == null || env.trim().isEmpty()) {
            log.forceInfo("\u001B[1m\u001B[33m⚠️ [HyperProbe] CRITICAL: Failed to start agent. HYPERPROBE_ENVIRONMENT is required.\u001B[0m");
            return;
        }

        String brokerUrl = System.getenv("HYPERPROBE_BROKER_URL");
        if (!isValidBrokerUrl(brokerUrl)) {
            log.forceInfo("\u001B[1m\u001B[33m⚠️ [HyperProbe] CRITICAL: Failed to start agent. Invalid brokerUrl \"" + brokerUrl + "\". It must be a valid URL (http:// or https://) or a raw gRPC target (e.g. localhost:60051), with no query parameters and no trailing slash.\u001B[0m");
            return;
        }

        // Configuration
        long hitsPerSec = getEnvLong("HYPERPROBE_HITS_PER_SEC", 20);
        long bandwidthKbPerSec = getEnvLong("HYPERPROBE_BANDWIDTH_KB_PER_SEC", 1024);
        long cooldownSec = getEnvLong("HYPERPROBE_COOLDOWN_SEC", 10);
        long syncIntervalMs = getEnvLong("HYPERPROBE_SYNC_INTERVAL_MS", 60000);
        long flushIntervalMs = getEnvLong("HYPERPROBE_FLUSH_INTERVAL_MS", 1000);

        // Initialize Serialization Config from env
        com.hyperprobe.serializer.SerializationConfig.updateConfig(
            (int) getEnvLong("HYPERPROBE_MAX_OBJECT_DEPTH", 3),
            (int) getEnvLong("HYPERPROBE_MAX_ARRAY_LENGTH", 3),
            (int) getEnvLong("HYPERPROBE_MAX_OBJECT_PROPERTIES", 50),
            (int) getEnvLong("HYPERPROBE_MAX_STRING_LENGTH", 1024),
            (int) getEnvLong("HYPERPROBE_STACK_FRAME_DEPTH", 3),
            getEnvList("HYPERPROBE_REDACT_KEYS"),
            getEnvList("HYPERPROBE_REDACT_VALUES")
        );

        boolean safeEvaluation = com.hyperprobe.evaluator.SafeASTValidator.isSafeEvaluationEnabled();
        if (!safeEvaluation) {
            log.forceInfo("\u001B[1m\u001B[33m⚠️ [HyperProbe] WARN: Safe evaluation is DISABLED via HYPERPROBE_DISABLE_SAFE_EVALUATION. Function and method calls are permitted in probe expressions.\u001B[0m");
        }

        instance = new HyperProbeAgent(hitsPerSec, bandwidthKbPerSec, cooldownSec);
        
        String agentId = UUID.randomUUID().toString();
        String appRoot = System.getenv().getOrDefault("HYPERPROBE_APP_ROOT", "");
        
        String agentVersion = VersionUtils.getVersion();

        instance.startInternal(agentId, serviceId, env, brokerUrl, commitSha, agentVersion, syncIntervalMs, flushIntervalMs, appRoot);
    }

    static boolean isValidServiceId(String serviceId) {
        return serviceId != null && UUID_V4_REGEX.matcher(serviceId.trim()).matches();
    }

    static boolean isNonUuidAllowed(String value) {
        return value != null && "yes".equalsIgnoreCase(value.trim());
    }

    private static long getEnvLong(String key, long defaultValue) {
        String val = System.getenv(key);
        if (val == null || val.trim().isEmpty()) {
            return defaultValue;
        }
        try {
            return Long.parseLong(val.trim());
        } catch (NumberFormatException e) {
            return defaultValue;
        }
    }

    private static List<String> getEnvList(String key) {
        String val = System.getenv(key);
        if (val == null || val.trim().isEmpty()) {
            return null;
        }
        return Arrays.stream(val.split(","))
                .map(String::trim)
                .filter(s -> !s.isEmpty())
                .collect(Collectors.toList());
    }

    private static boolean isValidBrokerUrl(String url) {
        if (url == null || url.trim().isEmpty()) return false;
        
        if (url.startsWith("http://") || url.startsWith("https://")) {
            try {
                java.net.URL u = new java.net.URL(url);
                return !url.endsWith("/") 
                    && (u.getQuery() == null || u.getQuery().isEmpty()) 
                    && (u.getHost() != null && !u.getHost().isEmpty());
            } catch (java.net.MalformedURLException e) {
                return false;
            }
        }
        
        // Raw gRPC targets
        return !url.contains("://") && !url.contains("/") && !url.contains("?");
    }

    /**
     * Shuts down the agent safely.
     */
    public static synchronized void stop() {
        if (instance != null) {
            instance.stopInternal();
        }
    }

    private void handleHealthChange(AgentHealth health, String reason, long cooldownSec) {
        if (!isRunning) return;

        if (health == AgentHealth.RED) {
            log.debug("Safety Shield Triggered: RED Status. " + (reason != null ? reason : ""));
            
            // Suspend instrumentation immediately
            probeRegistry.suspend();
            
            // Schedule the cooldown to resume (matches Node.js setTimeout)
            long cooldownMs = cooldownSec * 1000;
            cooldownScheduler.schedule(() -> {
                log.debug("Cooldown period ended. Attempting to resume instrumentation...");
                probeRegistry.resume();
            }, cooldownMs, TimeUnit.MILLISECONDS);
            
        } else if (health == AgentHealth.YELLOW) {
            log.debug("Safety Warning: YELLOW Status (Moderate Overhead). " + (reason != null ? reason : ""));
        } else if (health == AgentHealth.GREEN) {
            log.debug("Status back to GREEN. " + (reason != null ? reason : ""));
        }
    }

    private void startInternal(String agentId, String serviceId, String env, String brokerUrl, String commitSha, String agentVersion, long syncIntervalMs, long flushIntervalMs, String appRoot) {
        isRunning = true;
        
        // 1. Start Safety Monitor
        safetyMonitor.start();

        // 2. Configure Instrumentation
        com.hyperprobe.instrumentation.InstrumentationEngine.getMatcher().setAppRoot(appRoot);

        // 3. Initialize Transport Layer
        brokerClient = new BrokerClient(brokerUrl, serviceId);

        // 3. Start Telemetry Exporter
        telemetryExporter = new TelemetryExporter(brokerClient, telemetryQueue, agentId);
        telemetryExporter.start(flushIntervalMs);

        // 4. Start Probe Sync Service
        probeSyncService = new ProbeSyncService(brokerClient, probeRegistry, agentId, serviceId, env, commitSha, agentVersion, syncIntervalMs);
        probeSyncService.start();

        // 5. Start Maintenance Tasks (Async Duration Cleanup)
        maintenanceScheduler = Executors.newSingleThreadScheduledExecutor(r -> {
            Thread t = new Thread(r, "hyperprobe-maintenance");
            t.setDaemon(true);
            return t;
        });
        maintenanceScheduler.scheduleAtFixedRate(
            com.hyperprobe.runtime.ProbeExecutionEngine::runMaintenanceTasks, 
            60, 60, TimeUnit.SECONDS
        );

        log.debug("HyperProbe Control Plane Started. Service: " + serviceId + ", Env: " + env + ", Commit: " + commitSha);
    }

    private void stopInternal() {
        isRunning = false;
        
        if (safetyMonitor != null) safetyMonitor.stop();
        if (probeSyncService != null) probeSyncService.stop();
        if (maintenanceScheduler != null) maintenanceScheduler.shutdownNow();
        if (cooldownScheduler != null) cooldownScheduler.shutdownNow();
        if (telemetryExporter != null) telemetryExporter.stop();
        if (brokerClient != null) brokerClient.shutdown();
        
        log.debug("HyperProbe Control Plane Stopped.");
    }
}
