package com.hyperprobe.core;

import java.lang.management.ManagementFactory;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicReference;
import java.util.function.BiConsumer;
import com.hyperprobe.config.logging.HyperProbeLogger;

/**
 * Monitors JVM health (memory) to prevent the agent
 * from negatively impacting the host application.
 */
public class SafetyMonitor {

    private static final HyperProbeLogger log = HyperProbeLogger.getLogger(SafetyMonitor.class);

    private final AtomicReference<AgentHealth> currentHealth = new AtomicReference<>(AgentHealth.GREEN);
    private ScheduledExecutorService scheduler;
    
    private BiConsumer<AgentHealth, String> onStateChange;

    public SafetyMonitor(BiConsumer<AgentHealth, String> onStateChange) {
        this.onStateChange = onStateChange;
    }

    public void start() {
        if (scheduler != null && !scheduler.isShutdown()) return;
        
        scheduler = Executors.newSingleThreadScheduledExecutor(r -> {
            Thread t = new Thread(r, "hyperprobe-safety-monitor");
            t.setDaemon(true);
            return t;
        });

        // Run health check every 5 seconds
        scheduler.scheduleAtFixedRate(this::checkHealth, 5, 5, TimeUnit.SECONDS);
    }

    public void stop() {
        if (scheduler != null) {
            scheduler.shutdownNow();
        }
    }

    public AgentHealth getHealth() {
        return currentHealth.get();
    }

    private void checkHealth() {
        try {
            // Free memory check
            long maxMem = Runtime.getRuntime().maxMemory();
            long freeMem = Runtime.getRuntime().freeMemory() + (maxMem - Runtime.getRuntime().totalMemory());
            double freeMemPercentage = (double) freeMem / maxMem;

            AgentHealth measuredHealth = AgentHealth.GREEN;
            String reason = "System stabilized.";

            if (freeMemPercentage < 0.05) {
                measuredHealth = AgentHealth.RED;
                reason = "Critical impact detected: Low memory limit exceeded.";
            } else if (freeMemPercentage < 0.15) {
                measuredHealth = AgentHealth.YELLOW;
                reason = "Moderate impact detected: approaching memory limits.";
            }

            AgentHealth oldHealth = currentHealth.getAndSet(measuredHealth);
            
            if (oldHealth != measuredHealth) {
                if (onStateChange != null) {
                    onStateChange.accept(measuredHealth, reason);
                }
            }
        } catch (Throwable t) {
            // Never let the monitor crash
        }
    }
}
