package com.hyperprobe.core;

public enum AgentHealth {
    GREEN,  // Normal operation
    YELLOW, // Elevated overhead, logging warnings
    RED     // Critical overhead, suspend instrumentation
}
