package com.hyperprobe.core;

import java.util.concurrent.atomic.AtomicLong;

/**
 * Enforces execution limits using a Token Bucket algorithm.
 * Prevents the agent from consuming too much CPU (hits) or network (bandwidth).
 */
public class QuotaManager {

    private final long hitsPerSec;
    private final long bandwidthBytesPerSec;

    private final AtomicLong hitTokens;
    private final AtomicLong bandwidthTokens;
    private final AtomicLong lastRefillTimestamp;

    public QuotaManager(long hitsPerSec, long bandwidthKbPerSec) {
        this.hitsPerSec = hitsPerSec;
        this.bandwidthBytesPerSec = bandwidthKbPerSec * 1024;

        this.hitTokens = new AtomicLong(this.hitsPerSec);
        this.bandwidthTokens = new AtomicLong(this.bandwidthBytesPerSec);
        this.lastRefillTimestamp = new AtomicLong(System.currentTimeMillis());
    }

    /**
     * Checks if a probe hit is allowed to execute based on current quota.
     */
    public boolean allowExecution() {
        refill();
        
        // Fast optimistic decrement
        long current = hitTokens.get();
        while (current > 0) {
            if (hitTokens.compareAndSet(current, current - 1)) {
                return true;
            }
            current = hitTokens.get();
        }
        return false;
    }

    /**
     * Consumes bandwidth quota. Returns true if allowed.
     */
    public boolean consumeBandwidth(int bytes) {
        refill();
        
        long current = bandwidthTokens.get();
        while (current >= bytes) {
            if (bandwidthTokens.compareAndSet(current, current - bytes)) {
                return true;
            }
            current = bandwidthTokens.get();
        }
        return false;
    }

    /**
     * Refunds previously consumed bandwidth quota if an event was dropped locally.
     */
    public void refundBandwidth(int bytes) {
        long currentBytes;
        long targetBytes;
        do {
            currentBytes = bandwidthTokens.get();
            targetBytes = Math.min(bandwidthBytesPerSec, currentBytes + bytes);
        } while (!bandwidthTokens.compareAndSet(currentBytes, targetBytes));
    }

    private void refill() {
        long now = System.currentTimeMillis();
        long last = lastRefillTimestamp.get();
        
        if (now <= last) return; // Prevent backwards time travel logic

        // Fluid delta-based token refill
        long elapsedMs = now - last;
        
        // Calculate new tokens using pure integer math instead of doubles
        long newHits = (elapsedMs * hitsPerSec) / 1000;
        long newBytes = (elapsedMs * bandwidthBytesPerSec) / 1000;

        if (newHits > 0 || newBytes > 0) {
            if (lastRefillTimestamp.compareAndSet(last, now)) {
                
                // Refill hits
                if (newHits > 0) {
                    long currentHits;
                    long targetHits;
                    do {
                        currentHits = hitTokens.get();
                        targetHits = Math.min(hitsPerSec, currentHits + newHits);
                    } while (!hitTokens.compareAndSet(currentHits, targetHits));
                }

                // Refill bandwidth
                if (newBytes > 0) {
                    long currentBytes;
                    long targetBytes;
                    do {
                        currentBytes = bandwidthTokens.get();
                        targetBytes = Math.min(bandwidthBytesPerSec, currentBytes + newBytes);
                    } while (!bandwidthTokens.compareAndSet(currentBytes, targetBytes));
                }
            }
        }
    }
}
