package com.hyperprobe.config.logging;

import java.lang.management.ManagementFactory;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicLong;
import java.util.regex.Pattern;

public class HyperProbeLogger {

    // --- ANSI Color Codes ---
    private static final String ANSI_RESET = "\u001B[0m";

    // Base colors for namespace and time delta
    private static final String[] BASE_COLORS = {
            "\u001B[32m", // Green
            "\u001B[33m", // Yellow
            "\u001B[34m", // Blue
            "\u001B[35m", // Magenta
            "\u001B[36m", // Cyan
            "\u001B[31m", // Red
            "\u001B[92m", // Bright Green
            "\u001B[93m", // Bright Yellow
            "\u001B[94m", // Bright Blue
            "\u001B[95m", // Bright Magenta
            "\u001B[96m", // Bright Cyan
            "\u001B[91m", // Bright Red
    }; // 12 distinct vibrant colors

    private static final String ANSI_BOLD = "\u001B[1m";

    // For the message text (faded appearance)
    private static final String FADED_TEXT_COLOR = "\u001B[90m"; // Bright Black (Gray)
    private static final String HYPERPROBE_BLUE = "\u001B[34m"; // Blue for "HyperProbe" in print method

    private final String namespace;
    private final String namespaceColor; // Store the chosen color for reuse
    private final String boldColoredNamespace;
    private final boolean enabled;

    private static final Set<String> enabledNamespacesExact;
    private static final Set<Pattern> enabledNamespacesPattern;
    private static final ConcurrentHashMap<String, AtomicLong> lastLogTimePerNamespace = new ConcurrentHashMap<>();
    private static final DateTimeFormatter TIMESTAMP_FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSS");
    private static final long appBootTimeMs;

    static {
        appBootTimeMs = ManagementFactory.getRuntimeMXBean().getStartTime();
        
        String debugEnv = System.getenv("DEBUG");
        if (debugEnv == null || debugEnv.trim().isEmpty()) {
            enabledNamespacesExact = Collections.emptySet();
            enabledNamespacesPattern = Collections.emptySet();
        } else {
            Set<String> exact = new HashSet<>();
            Set<Pattern> patterns = new HashSet<>();
            String[] namespaces = debugEnv.split("[,\\s]+");

            for (String ns : namespaces) {
                if (ns.isEmpty()) continue;
                String trimmedNs = ns.trim().toLowerCase(); // Normalize to lowercase for matching
                if (trimmedNs.equals("*")) {
                    exact.add("*");
                    break;
                } else if (trimmedNs.endsWith("*")) {
                    String regex = "^" + Pattern.quote(trimmedNs.substring(0, trimmedNs.length() - 1)) + ".*$";
                    patterns.add(Pattern.compile(regex, Pattern.CASE_INSENSITIVE));
                } else {
                    exact.add(trimmedNs);
                }
            }
            enabledNamespacesExact = Collections.unmodifiableSet(exact);
            enabledNamespacesPattern = Collections.unmodifiableSet(patterns);
        }
    }

    public static HyperProbeLogger getLogger(Class<?> clazz) {
        String name = clazz.getSimpleName().toLowerCase();
        if (name.startsWith("hyperprobe")) {
            name = name.substring(10);
        }
        return new HyperProbeLogger("hyperprobe:" + name);
    }

    public static HyperProbeLogger getLogger(String namespace) {
        return new HyperProbeLogger(namespace);
    }

    private HyperProbeLogger(String namespace) {
        if (namespace == null || namespace.trim().isEmpty()) {
            this.namespace = "hyperprobe:unknown";
        } else {
            this.namespace = namespace;
        }
        this.namespaceColor = selectBaseColor(this.namespace); // Store the selected color
        this.boldColoredNamespace = ANSI_BOLD + this.namespaceColor + this.namespace + ANSI_RESET;
        this.enabled = checkEnabled(this.namespace);

        lastLogTimePerNamespace.computeIfAbsent(this.namespace, k -> new AtomicLong(appBootTimeMs));
    }

    private String selectBaseColor(String namespace) {
        int hash = namespace.hashCode();
        // Math.floorMod guarantees a positive result from 0 to (BASE_COLORS.length - 1),
        // gracefully avoiding Integer.MIN_VALUE Math.abs overflow bugs.
        int colorIndex = Math.floorMod(hash, BASE_COLORS.length);
        return BASE_COLORS[colorIndex];
    }

    private boolean checkEnabled(String namespace) {
        if (enabledNamespacesExact.contains("*")) return true;
        
        String lowerNamespace = namespace.toLowerCase();
        if (enabledNamespacesExact.contains(lowerNamespace)) return true;
        
        for (Pattern pattern : enabledNamespacesPattern) {
            if (pattern.matcher(lowerNamespace).matches()) return true;
        }
        return false;
    }

    public boolean isDebugEnabled() {
        return enabled;
    }

    private String formatTimeDelta(long currentTimeMillis, String color) { // Pass the color
        long previousTime = lastLogTimePerNamespace.get(this.namespace).getAndSet(currentTimeMillis);
        if (currentTimeMillis == previousTime) return "";
        long delta = currentTimeMillis - previousTime;
        return color + "+" + delta + "ms" + ANSI_RESET; // Use the passed color
    }

    public void debug(String message) {
        if (!enabled) {
            return;
        }

        long currentTime = System.currentTimeMillis();
        // Pass the instance's namespaceColor to formatTimeDelta
        String timeDeltaString = formatTimeDelta(currentTime, this.namespaceColor);

        System.out.println(
                "  " +
                boldColoredNamespace + " " + // Already has reset
                FADED_TEXT_COLOR +
                message +
                ANSI_RESET + " " + // Reset before time delta
                timeDeltaString    // Already has reset
        );
    }

    public void debug(String format, Object... args) {
        if (!enabled) {
            return;
        }
        debug(String.format(format, args));
    }

    public void info(String message) {
        forceInfo(message);
    }

    public void forceInfo(String message) {
        String formattedTimestamp = LocalDateTime.now().format(TIMESTAMP_FORMATTER);

        String logString = formattedTimestamp + " " +
                HYPERPROBE_BLUE + "HyperProbe" + ANSI_RESET +
                " -- [" + this.namespace + "] " +
                message;

        System.out.println(logString);
    }

    public void warn(String message) {
        String formattedTimestamp = LocalDateTime.now().format(TIMESTAMP_FORMATTER);
        String logString = formattedTimestamp + " \u001B[33m[HyperProbe WARN]\u001B[0m [" + this.namespace + "] " + message;
        System.out.println(logString);
    }

    public void error(String message) {
        error(message, null);
    }

    public void error(String message, Throwable t) {
        String formattedTimestamp = LocalDateTime.now().format(TIMESTAMP_FORMATTER);
        System.err.println(formattedTimestamp + " \u001B[31m[HyperProbe ERROR]\u001B[0m [" + this.namespace + "] " + message);
        if (t != null) {
            t.printStackTrace(System.err);
        }
    }
}
