package com.hyperprobe.config.util;

import java.io.InputStream;
import java.util.Properties;

public class VersionUtils {
    private static String version = "unknown";

    static {
        try (InputStream is = VersionUtils.class.getResourceAsStream("/hyperprobe-version.properties")) {
            if (is != null) {
                Properties props = new Properties();
                props.load(is);
                version = props.getProperty("version", "unknown");
            }
        } catch (Exception e) {
            // Fallback to unknown
        }
    }

    public static String getVersion() {
        return version;
    }
}
