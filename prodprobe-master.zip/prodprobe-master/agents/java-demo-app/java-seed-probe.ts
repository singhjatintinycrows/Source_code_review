import {
  initDatabase,
  ProbeStatus,
  ProbeType,
} from '../../packages/database/src/index';

const prisma = initDatabase(
  process.env.DATABASE_URL ||
    'postgres://user:password@localhost:5433/hyperprobe',
);

async function main() {
  const service = await prisma.service.upsert({
    where: { id: 'java-demo-service' },
    update: {},
    create: {
      id: 'java-demo-service',
      name: 'Java Demo Service',
    },
  });

  const commitSha = 'test'; // Matches the default test commit used in README instructions

  const probe = await prisma.probe.create({
    data: {
      type: ProbeType.SNAPSHOT,
      serviceId: service.id,
      environment: 'development',
      commitSha: commitSha,
      status: ProbeStatus.ACTIVE,
      uiFilePath:
        'src/main/java/com/hyperprobe/demo/service/CheckoutService.java',
      uiLineNumber: 29,
      runtimeLocation:
        'src/main/java/com/hyperprobe/demo/service/CheckoutService.java',
      runtimeLine: 29,
      hitLimit: 10,
      expiryTime: BigInt(Date.now() + 1000 * 60 * 60 * 24), // 24 hours
      watchExpressions: [
        'item.price',
        'userSession.flags',
        'userSession.circular',
      ],
    },
  });

  console.log('✅ Injected test snapshot probe:', probe.id);

  const logProbe = await prisma.probe.create({
    data: {
      type: ProbeType.LOG,
      serviceId: service.id,
      environment: 'development',
      commitSha: commitSha,
      status: ProbeStatus.ACTIVE,
      uiFilePath:
        'src/main/java/com/hyperprobe/demo/service/CheckoutService.java',
      uiLineNumber: 29,
      runtimeLocation:
        'src/main/java/com/hyperprobe/demo/service/CheckoutService.java',
      runtimeLine: 29,
      hitLimit: 10,
      expiryTime: BigInt(Date.now() + 1000 * 60 * 60 * 24),
      // biome-ignore lint/suspicious/noTemplateCurlyInString: Template for log probe
      template: '${userSession.password} initiated checkout',
    },
  });

  console.log('✅ Injected test log probe:', logProbe.id);
}

main()
  .catch(console.error)
  .finally(() => prisma.$disconnect());
