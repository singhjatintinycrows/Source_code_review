package com.hyperprobe.demo.service;

import org.springframework.stereotype.Service;

import com.hyperprobe.demo.model.CheckoutRequestDto;
import com.hyperprobe.demo.model.CheckoutResponseDto;
import com.hyperprobe.demo.model.ItemDto;
import com.hyperprobe.demo.model.UserSessionDto;

import java.time.Instant;
import java.util.Arrays;
import java.util.concurrent.atomic.AtomicInteger;

@Service
public class CheckoutService {
    private final AtomicInteger numb = new AtomicInteger(0);

    public CheckoutResponseDto processCheckout(CheckoutRequestDto req) {
        numb.incrementAndGet();
        String userId = req.getUserId();

        double cartTotal = 0;
        UserSessionDto userSession = new UserSessionDto();
        userSession.setId(userId);
        userSession.setAuthenticated(true);
        userSession.setFlags(Arrays.asList("premium", "beta-tester"));
        userSession.setPassword("super-secret-password"); // Should be redacted
        userSession.setCircular(userSession); // Should be detected

        if (req.getItems() != null) {
            for (ItemDto item : req.getItems()) {
                // Loop processing logic where we might want to set a probe
                double itemPrice = (item.getPrice() != null ? item.getPrice() : 0) * (item.getQuantity() != null ? item.getQuantity() : 1);

                // Applying some discount
                double discount = itemPrice > 100 ? 0.1 : 0;
                cartTotal += itemPrice - (itemPrice * discount);
            }
        }

        // Final confirmation logic
        CheckoutResponseDto response = new CheckoutResponseDto();
        response.setStatus("success");
        response.setUser(userSession);
        response.setTotal(cartTotal);
        response.setTimestamp(Instant.now().toString());

        return response;
    }
}
