package com.hyperprobe.demo.model;

import java.util.List;

public class CheckoutRequestDto {
    private String userId;
    private List<ItemDto> items;

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public List<ItemDto> getItems() {
        return items;
    }

    public void setItems(List<ItemDto> items) {
        this.items = items;
    }
}
