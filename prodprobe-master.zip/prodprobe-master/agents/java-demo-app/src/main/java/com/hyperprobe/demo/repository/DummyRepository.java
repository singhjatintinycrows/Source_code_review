package com.hyperprobe.demo.repository;

import org.springframework.stereotype.Repository;

@Repository
public class DummyRepository {
    // Placeholder repository to satisfy structural requirements
}
