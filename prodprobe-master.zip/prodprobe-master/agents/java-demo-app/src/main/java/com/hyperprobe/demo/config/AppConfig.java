package com.hyperprobe.demo.config;

import org.springframework.context.annotation.Configuration;

@Configuration
public class AppConfig {
    // Placeholder configuration to satisfy structural requirements
}
