package com.hyperprobe.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoAppApplication {

    public static void main(String[] args) {
        // Initialize the Agent only if HYPERPROBE_ENABLED is true
        // Note: In Java, agent initialization is done via -javaagent JVM argument.
        // E.g., java -javaagent:path/to/java-sdk.jar -jar demo-app.jar
        SpringApplication.run(DemoAppApplication.class, args);
        System.out.println("Demo app listening on port 8080");
    }
}
