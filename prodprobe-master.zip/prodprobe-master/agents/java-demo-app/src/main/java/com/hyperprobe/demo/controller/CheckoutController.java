package com.hyperprobe.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.hyperprobe.demo.model.CheckoutRequestDto;
import com.hyperprobe.demo.model.CheckoutResponseDto;
import com.hyperprobe.demo.service.CheckoutService;

@RestController
public class CheckoutController {

    private final CheckoutService checkoutService;

    @Autowired
    public CheckoutController(CheckoutService checkoutService) {
        this.checkoutService = checkoutService;
    }

    @PostMapping("/checkout")
    public CheckoutResponseDto checkout(@RequestBody CheckoutRequestDto req) {
        CheckoutResponseDto resp = checkoutService.processCheckout(req);
        System.out.println("[DemoApp] Checkout processed. Status: " + resp.getStatus() + ", UserId: " + req.getUserId());
        return resp;
    }
}
