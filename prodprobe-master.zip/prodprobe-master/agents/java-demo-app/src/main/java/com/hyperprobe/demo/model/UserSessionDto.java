package com.hyperprobe.demo.model;

import java.util.List;
import com.fasterxml.jackson.annotation.JsonIgnore;

public class UserSessionDto {
    private String id;
    private boolean isAuthenticated;
    private List<String> flags;
    private String password;
    
    @JsonIgnore
    private UserSessionDto circular;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public boolean isAuthenticated() {
        return isAuthenticated;
    }

    public void setAuthenticated(boolean authenticated) {
        isAuthenticated = authenticated;
    }

    public List<String> getFlags() {
        return flags;
    }

    public void setFlags(List<String> flags) {
        this.flags = flags;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public UserSessionDto getCircular() {
        return circular;
    }

    public void setCircular(UserSessionDto circular) {
        this.circular = circular;
    }
}
