package com.hyperprobe.demo.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.lang.management.ManagementFactory;
import java.util.HashMap;
import java.util.Map;

@RestController
public class HealthController {

    @GetMapping("/health")
    public Map<String, Object> health() {
        Map<String, Object> response = new HashMap<>();
        response.put("status", "ok");
        // process.uptime() returns seconds
        double uptime = ManagementFactory.getRuntimeMXBean().getUptime() / 1000.0;
        response.put("uptime", uptime);
        return response;
    }
}
