package com.hyperprobe.demo.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import reactor.core.publisher.Mono;
import reactor.core.scheduler.Schedulers;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CompletableFuture;

@RestController
@RequestMapping("/api/async")
public class AsyncTestController {

    // 1. Fire synchronous operations in a different thread and wait on the main thread
    @GetMapping("/thread")
    public Map<String, String> testRawThread() throws InterruptedException {
        Map<String, String> result = new HashMap<>();
        Thread worker = new Thread(() -> {
            // PROBE TARGET: Place a snapshot here to observe the raw thread stack
            String simulatedHttpCallResult = "Data from simulated HTTP call";
            result.put("status", "success");
            result.put("data", simulatedHttpCallResult);
            result.put("context", "raw-thread");
        }, "hyperprobe-simulated-worker");

        worker.start();
        worker.join(); // Main thread waits for completion

        return result;
    }

    // 2. Use CompletableFutures for sync/async operations
    @GetMapping("/future")
    public CompletableFuture<Map<String, String>> testCompletableFuture() {
        return CompletableFuture.supplyAsync(() -> {
            // PROBE TARGET: Place a snapshot here to observe ForkJoinPool stack
            try {
                Thread.sleep(50); // simulate delay
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }

            Map<String, String> result = new HashMap<>();
            result.put("status", "success");
            result.put("data", "Processed via CompletableFuture");
            result.put("context", "fork-join-pool");
            return result;
        });
    }

    // 3. Use Reactor (WebFlux paradigm) to shift execution context
    @GetMapping("/reactor")
    public Mono<Map<String, String>> testReactor() {
        return Mono.fromCallable(() -> {
            // PROBE TARGET: Place a snapshot here to observe Reactor BoundedElastic stack
            Map<String, String> result = new HashMap<>();
            result.put("status", "success");
            result.put("data", "Processed via Reactor Mono");
            result.put("context", "reactor-elastic");
            return result;
        }).subscribeOn(Schedulers.boundedElastic()); // Shifts execution to background thread
    }
}
