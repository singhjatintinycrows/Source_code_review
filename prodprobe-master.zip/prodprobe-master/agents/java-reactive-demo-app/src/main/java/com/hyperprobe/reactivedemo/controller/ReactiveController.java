package com.hyperprobe.reactivedemo.controller;

import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import java.time.Duration;
import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/reactive")
public class ReactiveController {

    // Test Case A: Single Mono chain with asynchronous context
    @GetMapping("/hello")
    public Mono<Map<String, String>> sayHello(@RequestParam(defaultValue = "World") String name) {
        final String prefix = "Demo-";
        return Mono.just(name)
                .map(n -> {
                    // TARGET PROBE: Place a snapshot here to inspect 'n'
                    Map<String, String> result = new HashMap<>();
                    result.put("message", prefix + "Hello " + n + "!");
                    result.put("thread", Thread.currentThread().getName());
                    return result;
                });
    }

    // Test Case B: Asynchronous Flux event stream
    @GetMapping(value = "/ticks", produces = "text/event-stream")
    public Flux<Map<String, Object>> getTicks() {
        return Flux.interval(Duration.ofMillis(400))
                .take(5)
                .map(i -> {
                    // TARGET PROBE: Place a snapshot here to inspect 'i' (current tick)
                    Map<String, Object> tickMap = new HashMap<>();
                    tickMap.put("tick", i);
                    tickMap.put("timestamp", System.currentTimeMillis());
                    tickMap.put("thread", Thread.currentThread().getName());
                    return tickMap;
                });
    }
}
