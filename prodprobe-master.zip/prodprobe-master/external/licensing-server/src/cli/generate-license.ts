import * as crypto from 'crypto';
import * as dotenv from 'dotenv';
import * as admin from 'firebase-admin';
import * as jwt from 'jsonwebtoken';

dotenv.config();

function initFirebase() {
  const serviceAccount = {
    projectId: process.env.FIREBASE_PROJECT_ID,
    clientEmail: process.env.FIREBASE_CLIENT_EMAIL,
    privateKey: process.env.FIREBASE_PRIVATE_KEY?.replace(/\\n/g, '\n'),
  };

  if (
    !serviceAccount.projectId ||
    !serviceAccount.clientEmail ||
    !serviceAccount.privateKey
  ) {
    console.error('Missing Firebase environment variables');
    process.exit(1);
  }

  admin.initializeApp({
    credential: admin.credential.cert(serviceAccount as any),
    databaseURL: process.env.FIREBASE_DATABASE_URL,
  });
}

async function run() {
  const args = process.argv.slice(2);
  const mode = args[0];

  if (mode === '--init') {
    console.log(
      '--init cmd is not available to run locally, please contact @karan or @shreesha',
    );
    process.exit(1);
    initFirebase();
    console.log('Generating global ECDSA (ES256) key pair...');
    const { publicKey, privateKey } = crypto.generateKeyPairSync('ec', {
      namedCurve: 'prime256v1',
      publicKeyEncoding: { type: 'spki', format: 'pem' },
      privateKeyEncoding: { type: 'pkcs8', format: 'pem' },
    });

    console.log(
      'Pushing private key to Firebase RTDB (/system/privateKeyPem)...',
    );
    await admin.database().ref('/system/privateKeyPem').set(privateKey);
    console.log('✅ Private key secured in RTDB.');

    console.log('Pushing public key to Firebase RTDB (/public_key_pem)...');
    await admin.database().ref('/public_key_pem').set(publicKey);
    console.log('✅ Public key secured in RTDB.');

    console.log('\n=========================================');
    console.log('Action Required: Configure Deployment');
    console.log('=========================================');
    console.log(
      'Add the following public key to Consul under the key "LICENSE_PUBLIC_KEY":',
    );

    // Replace actual newlines with double-escaped \\n strings so it survives Docker Compose YAML parsing
    const composePublicKey = publicKey.replace(/\n/g, '\\\\n');
    console.log(
      `\nconsul kv put -cas LICENSE_PUBLIC_KEY '${composePublicKey}'\n`,
    );

    process.exit(0);
  } else if (mode === '--new') {
    if (args.length < 3) {
      console.log(
        'Usage: npx ts-node src/cli/generate-license.ts --new <customerName> <maxAgents> [expiryInDays]',
      );
      process.exit(1);
    }

    initFirebase();
    const customerName = args[1];

    // Strict validation: Only alphanumeric, dashes, and underscores
    const isValidName = /^[a-zA-Z0-9\-_]+$/.test(customerName);
    if (!isValidName) {
      console.error(`Error: Invalid customer name "${customerName}".`);
      console.error(
        'Customer names may ONLY contain letters, numbers, dashes (-), and underscores (_).',
      );
      console.error('Spaces are NOT allowed.');
      process.exit(1);
    }

    const licenseId = `lic_${customerName}`;

    // Uniqueness check
    console.log(`Checking if customer "${customerName}" already exists...`);
    const existingSnap = await admin
      .database()
      .ref(`/licenses/${licenseId}`)
      .once('value');
    if (existingSnap.exists()) {
      console.error(
        `Error: A license for customer "${customerName}" already exists!`,
      );
      console.error(
        `To update this customer, please modify their entry directly in the Firebase Console.`,
      );
      process.exit(1);
    }

    const maxAgents = parseInt(args[2], 10);
    const expiryInDays = args.length >= 4 ? parseInt(args[3], 10) : 365;

    console.log('Fetching global private key from RTDB...');
    const snap = await admin
      .database()
      .ref('/system/privateKeyPem')
      .once('value');
    const privateKey = snap.val();

    if (!privateKey) {
      console.error('Global private key not found! Run --init first.');
      process.exit(1);
    }

    const expiryDateMs = Date.now() + expiryInDays * 24 * 60 * 60 * 1000;

    const payload = {
      licenseId,
      max_agents: maxAgents,
      customerName,
      last_heartbeat_timestamp: Date.now(),
      exp: Math.floor(expiryDateMs / 1000),
    };

    const initialJwt = jwt.sign(payload, privateKey, { algorithm: 'ES256' });

    console.log('Provisioning license in RTDB...');
    await admin.database().ref(`/licenses/${licenseId}`).set({
      customerName,
      maxAgents,
      expiryDate: expiryDateMs,
      isRevoked: false,
      isInitialized: false, // Start uninitialized
      pendingNextToken: null,
      expectedNextToken: null, // No token yet
    });

    console.log(`\n✅ License Provisioned for ${expiryInDays} days!`);
    console.log('=========================================');
    console.log(
      'Provide this JWT to the customer to enter in the Hyperprobe Dashboard:',
    );
    console.log(`\nJWT: ${initialJwt}\n`);

    process.exit(0);
  } else {
    console.log('Usage:');
    console.log(
      '  --init : Generate global key pair and push private key to Firebase',
    );
    console.log(
      '  --new <customerName> <maxAgents> [expiryInDays] : Generate a new license (default: 365 days)',
    );
    process.exit(1);
  }
}

run().catch(console.error);
