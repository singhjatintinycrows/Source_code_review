import * as crypto from 'crypto';
import * as dotenv from 'dotenv';
import * as admin from 'firebase-admin';
import * as jwt from 'jsonwebtoken';

dotenv.config();

export type HpLicenseJwtPayload = {
  licenseId: string;
  max_agents: number;
  last_heartbeat_timestamp: number;
  customerName?: string;
  exp?: number;
  [key: string]: any;
};

// Warm Start Cache
let cachedPrivateKey: string | null = null;
let isFirebaseInitialized = false;

function initFirebase() {
  if (!isFirebaseInitialized) {
    try {
      const serviceAccount = {
        projectId: process.env.FIREBASE_PROJECT_ID,
        clientEmail: process.env.FIREBASE_CLIENT_EMAIL,
        privateKey: process.env.FIREBASE_PRIVATE_KEY?.replace(/\\n/g, '\n'),
      };

      admin.initializeApp({
        credential: admin.credential.cert(serviceAccount as any),
        databaseURL: process.env.FIREBASE_DATABASE_URL,
      });
      isFirebaseInitialized = true;
    } catch (e) {
      console.error('Failed to initialize Firebase', e);
    }
  }
}

export const heartbeat = async (event: any) => {
  try {
    initFirebase();

    const body = JSON.parse(event.body || '{}');
    const { phase, licenseId, jwt: oldJwt, nextToken } = body;

    if (!licenseId || !oldJwt) {
      return {
        statusCode: 400,
        body: JSON.stringify({ error: 'Missing required parameters' }),
      };
    }
    if ((phase === 1 || phase === 2) && !nextToken) {
      return {
        statusCode: 400,
        body: JSON.stringify({
          error: 'Missing required parameter: nextToken',
        }),
      };
    }

    const db = admin.database();

    // 1. Warm Start Check for Private Key
    if (!cachedPrivateKey) {
      console.log('Cold start: Fetching private key from RTDB...');
      const snapshot = await db.ref('/system/privateKeyPem').once('value');
      cachedPrivateKey = snapshot.val();

      if (!cachedPrivateKey) {
        return {
          statusCode: 500,
          body: JSON.stringify({ error: 'System private key not found' }),
        };
      }
    }

    const licenseRef = db.ref(`/licenses/${licenseId}`);

    // Fast rejection check
    const initialSnap = await licenseRef.once('value');
    if (!initialSnap.exists()) {
      return {
        statusCode: 403,
        body: JSON.stringify({ error: 'License not found' }),
      };
    }
    if (initialSnap.val().isRevoked) {
      return {
        statusCode: 403,
        body: JSON.stringify({ error: 'License has been revoked' }),
      };
    }

    let limitUpdated = false;
    let decodedOld: HpLicenseJwtPayload | null;

    try {
      decodedOld = (await jwt.verify(oldJwt, cachedPrivateKey, {
        algorithms: ['ES256'],
      })) as HpLicenseJwtPayload;
    } catch (_e) {
      return {
        statusCode: 403,
        body: JSON.stringify({ error: 'Invalid license token' }),
      };
    }

    if (decodedOld.licenseId !== licenseId) {
      return {
        statusCode: 403,
        body: JSON.stringify({ error: 'License mismatch' }),
      };
    }

    // Phase 1: Request
    if (phase === 1) {
      let statusCode = 200;
      let responseBody: any = null;

      const { snapshot } = await licenseRef.transaction((data) => {
        if (data === null) return data; // force sync if local cache is empty

        if (data.isRevoked) {
          statusCode = 403;
          responseBody = { error: 'License has been revoked' };
          return; // abort
        }

        if (data.isInitialized) {
          if (data.expectedNextToken !== nextToken) {
            if (data.pendingNextToken && data.pendingNextToken === nextToken) {
              console.warn(
                `Retry detected for license ${licenseId}. Client crashed before Phase 2.`,
              );
              return; // abort cleanly, token is already valid
            } else {
              console.warn(
                `Clone detected for license ${licenseId}. Expected ${data.expectedNextToken}, got ${nextToken}`,
              );
              data.isRevoked = true;
              statusCode = 403;
              responseBody = { error: 'Clone detected. License revoked.' };
              return data;
            }
          } else {
            if (data.pendingNextToken) {
              return; // idempotent abort: another courier already started Phase 1
            }
          }
        }

        data.pendingNextToken = crypto.randomUUID();
        data.isInitialized = true;
        return data;
      });

      if (statusCode !== 200) {
        return { statusCode, body: JSON.stringify(responseBody) };
      }

      const finalData = snapshot.val();
      if (!finalData) {
        return {
          statusCode: 500,
          body: JSON.stringify({
            error: 'Transaction failed to read license data',
          }),
        };
      }

      return {
        statusCode: 200,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ nextToken: finalData.pendingNextToken }),
      };
    }

    // Phase 2: Commit
    if (phase === 2) {
      let statusCode = 200;
      let responseBody: any = null;

      const { snapshot } = await licenseRef.transaction((data) => {
        if (data === null) return data; // force sync if local cache is empty

        if (data.isRevoked) {
          statusCode = 403;
          responseBody = { error: 'License has been revoked' };
          return; // abort
        }

        if (!data.pendingNextToken || data.pendingNextToken !== nextToken) {
          if (data.expectedNextToken === nextToken && !data.pendingNextToken) {
            return; // idempotent abort: another courier already committed Phase 2
          } else {
            console.warn(`Phase 2 mismatch for license ${licenseId}.`);
            data.isRevoked = true;
            statusCode = 403;
            responseBody = { error: 'Handshake failed. License revoked.' };
            return data;
          }
        }

        data.expectedNextToken = nextToken;
        data.pendingNextToken = null;
        return data;
      });

      if (statusCode !== 200) {
        return { statusCode, body: JSON.stringify(responseBody) };
      }

      const licenseData = snapshot.val();
      if (!licenseData) {
        return {
          statusCode: 500,
          body: JSON.stringify({
            error: 'Transaction failed to read license data',
          }),
        };
      }

      const oldMaxAgents = decodedOld?.max_agents;
      const oldExp = decodedOld?.exp;
      const newExpSeconds = Math.floor(licenseData.expiryDate / 1000);
      limitUpdated =
        oldMaxAgents !== licenseData.maxAgents || oldExp !== newExpSeconds;

      const payload: HpLicenseJwtPayload = {
        licenseId,
        max_agents: licenseData.maxAgents,
        customerName: licenseData.customerName,
        last_heartbeat_timestamp: Date.now(),
        exp: Math.floor(licenseData.expiryDate / 1000),
      };

      const newJwt = jwt.sign(payload, cachedPrivateKey, {
        algorithm: 'ES256',
      });

      return {
        statusCode: 200,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ jwt: newJwt, limitUpdated }),
      };
    }

    // Fallback for Phase 0 / Provisioning (The original lazy init)
    if (!initialSnap.val().isInitialized && !phase) {
      const newExpSeconds = Math.floor(initialSnap.val().expiryDate / 1000);
      limitUpdated =
        decodedOld?.max_agents !== initialSnap.val().maxAgents ||
        decodedOld?.exp !== newExpSeconds;

      const newNextToken = crypto.randomUUID();
      const payload: HpLicenseJwtPayload = {
        licenseId,
        max_agents: initialSnap.val().maxAgents,
        customerName: initialSnap.val().customerName,
        last_heartbeat_timestamp: Date.now(),
        exp: Math.floor(initialSnap.val().expiryDate / 1000),
      };
      const newJwt = jwt.sign(payload, cachedPrivateKey, {
        algorithm: 'ES256',
      });
      await licenseRef.update({
        isInitialized: true,
        expectedNextToken: newNextToken,
      });
      return {
        statusCode: 200,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          jwt: newJwt,
          nextToken: newNextToken,
          limitUpdated,
        }),
      };
    }

    return {
      statusCode: 400,
      body: JSON.stringify({ error: 'Invalid phase' }),
    };
  } catch (error: any) {
    console.error('Heartbeat Error:', error);
    return {
      statusCode: 400,
      body: JSON.stringify({ error: error.message }),
    };
  }
};
