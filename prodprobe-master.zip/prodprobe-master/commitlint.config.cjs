module.exports = {
  extends: ['@commitlint/config-conventional'],
  rules: {
    'type-enum': [2, 'always', [
      'feat', 'fix', 'docs', 'style', 'refactor', 'test', 'chore', 'revert', 'tmp'
    ]],
    'subject-case': [0],
    'subject-min-length': [2, 'always', 5]
  }
};
