import autocannon from 'autocannon';
import { type ChildProcess, spawn } from 'child_process';
import path from 'path';
import pidusage from 'pidusage';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const DEMO_APP_DIR = path.resolve(__dirname, '../../../apps/demo-app');

interface BenchmarkResult {
  profile: string;
  requestsPerSec: number;
  p99Latency: number;
  cpuAvg: number;
  totalHits: number;
  totalSkips: number;
  suspensions: number;
}

function spawnProcess(
  cmd: string,
  args: string[],
  env: any,
): Promise<ChildProcess> {
  return new Promise((resolve) => {
    const child = spawn(cmd, args, {
      cwd: DEMO_APP_DIR,
      env: { ...process.env, ...env },
      stdio: 'pipe',
    });
    let isReady = false;

    child.stdout?.on('data', (data) => {
      const output = data.toString();
      const lines = output.split('\n');
      for (const line of lines) {
        if (
          line.includes('[MockBroker Stats]') ||
          line.includes('[HyperProbe]') ||
          line.includes('[HyperProbe Stats]')
        ) {
          console.log(`[${cmd}] ${line.trim()}`);
        }
      }
      if (
        output.includes('listening on port') ||
        output.includes('Listening on port')
      ) {
        if (!isReady) {
          isReady = true;
          resolve(child);
        }
      }
    });

    child.stderr?.on('data', (data) => {
      console.error(`[${cmd} ERROR] ${data.toString()}`);
    });

    setTimeout(() => {
      if (!isReady) {
        isReady = true;
        resolve(child);
      }
    }, 5000);
  });
}

function sleep(ms: number) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function runAutocannon(
  durationSecs: number,
  verbose: boolean,
  rate?: number,
): Promise<any> {
  const checkoutBody = {
    userId: '123',
    items: [
      { price: 120, quantity: 2 },
      { price: 50, quantity: 1 },
    ],
  };

  return new Promise((resolve, reject) => {
    const instance = autocannon(
      {
        url: 'http://localhost:3000/checkout',
        method: 'POST',
        body: JSON.stringify(checkoutBody),
        headers: { 'content-type': 'application/json' },
        connections: 10,
        pipelining: 1,
        duration: durationSecs,
        overallRate: rate,
      },
      (err, result) => {
        if (err) return reject(err);
        resolve(result);
      },
    );

    if (verbose) {
      autocannon.track(instance, { renderProgressBar: true });
    }
  });
}

async function runProfile(name: string, env: any): Promise<BenchmarkResult> {
  console.log(`\n================================`);
  console.log(`Starting Profile: ${name}`);
  console.log(`================================`);

  const brokerProcess = await spawnProcess('node', ['dist/mock-broker.js'], {
    HYPERPROBE_SCENARIO: 'ACTIVE',
  });
  const appProcess = await spawnProcess('node', ['dist/index.js'], {
    ...env,
    HYPERPROBE_ENABLED: 'true',
  });

  // Warmup
  await runAutocannon(5, false, 500);
  await sleep(2000);

  const stats: { cpu: number[] } = { cpu: [] };
  let totalHits = 0;
  let totalSkips = 0;
  let suspensions = 0;

  // Track stats from stdout
  appProcess.stdout?.on('data', (data) => {
    const output = data.toString();
    // Match: [HyperProbe Stats] Probes Hit: 3, Probes Skipped: 2
    const statsMatch = output.match(/Probes Hit: (\d+), Probes Skipped: (\d+)/);
    if (statsMatch) {
      totalHits += parseInt(statsMatch[1]);
      totalSkips += parseInt(statsMatch[2]);
    }
    if (output.includes('Suspending instrumentation')) {
      suspensions++;
    }
  });

  const interval = setInterval(async () => {
    if (appProcess.pid) {
      try {
        const usage = await pidusage(appProcess.pid);
        stats.cpu.push(usage.cpu);
      } catch (_err) {}
    }
  }, 1000);

  console.log(`Running load test (30s) at 500 RPS...`);
  const result = await runAutocannon(30, true, 500);

  clearInterval(interval);

  if (appProcess.pid)
    try {
      process.kill(appProcess.pid);
    } catch (_e) {}
  if (brokerProcess && brokerProcess.pid)
    try {
      process.kill(brokerProcess.pid);
    } catch (_e) {}
  await sleep(2000);

  const avgCpu = stats.cpu.reduce((a, b) => a + b, 0) / (stats.cpu.length || 1);

  return {
    profile: name,
    requestsPerSec: result.requests.average,
    p99Latency: result.latency.p99,
    cpuAvg: avgCpu,
    totalHits,
    totalSkips,
    suspensions,
  };
}

async function main() {
  const results: BenchmarkResult[] = [];

  try {
    // 1. HARDENED DEFAULTS
    results.push(
      await runProfile('DEFAULT (Safe)', {
        HYPERPROBE_HITS_PER_SEC: '10',
        HYPERPROBE_BANDWIDTH_KB_PER_SEC: '200',
        HYPERPROBE_PAUSE_BUDGET_MS: '20',
      }),
    );

    // 2. BALANCED (Higher Data)
    results.push(
      await runProfile('BALANCED', {
        HYPERPROBE_HITS_PER_SEC: '20',
        HYPERPROBE_BANDWIDTH_KB_PER_SEC: '500',
        HYPERPROBE_PAUSE_BUDGET_MS: '50',
      }),
    );

    // 3. RELAXED (High Overhead)
    results.push(
      await runProfile('RELAXED', {
        HYPERPROBE_HITS_PER_SEC: '50',
        HYPERPROBE_BANDWIDTH_KB_PER_SEC: '1000',
        HYPERPROBE_PAUSE_BUDGET_MS: '150',
      }),
    );

    console.log(`\n================================`);
    console.log(`Phase 1 Verification Table (at 500 RPS)`);
    console.log(`================================`);
    console.table(results);
  } catch (err) {
    console.error('Benchmark failed:', err);
  }
}

main();
