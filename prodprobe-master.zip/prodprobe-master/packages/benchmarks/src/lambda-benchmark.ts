import { mkdir, writeFile } from 'node:fs/promises';
import path from 'node:path';

type RequestResult = {
  requestId: string;
  responseRequestId: string | null;
  clientResponseMs: number;
  statusCode: number | null;
  error?: string;
};

const requestBody = JSON.stringify({
  items: [
    { price: 120, quantity: 2 },
    { price: 50, quantity: 1 },
  ],
});

function requiredEnvironment(name: string): string {
  const value = process.env[name];
  if (!value) throw new Error(`${name} environment variable is required`);
  return value;
}

function positiveInteger(name: string, fallback: number): number {
  const value = process.env[name];
  if (!value) return fallback;
  const parsed = Number.parseInt(value, 10);
  if (!Number.isInteger(parsed) || parsed < 1) {
    throw new Error(`${name} must be a positive integer`);
  }
  return parsed;
}

function percentile(values: number[], percentileValue: number): number | null {
  if (values.length === 0) return null;
  const sorted = [...values].sort((a, b) => a - b);
  const index = Math.min(
    sorted.length - 1,
    Math.ceil((percentileValue / 100) * sorted.length) - 1,
  );
  return Number(sorted[index]!.toFixed(3));
}

function average(values: number[]): number | null {
  if (values.length === 0) return null;
  const total = values.reduce((sum, value) => sum + value, 0);
  return Number((total / values.length).toFixed(3));
}

async function sendRequest(
  url: string,
  scenario: string,
): Promise<RequestResult> {
  const requestId = crypto.randomUUID();
  const startedAt = performance.now();

  try {
    const response = await fetch(url, {
      method: 'POST',
      headers: {
        'content-type': 'application/json',
        'x-benchmark-request-id': requestId,
        'x-benchmark-scenario': scenario,
      },
      body: requestBody,
    });
    await response.arrayBuffer();

    return {
      requestId,
      responseRequestId: response.headers.get('x-benchmark-request-id'),
      clientResponseMs: Number((performance.now() - startedAt).toFixed(3)),
      statusCode: response.status,
    };
  } catch (error) {
    return {
      requestId,
      responseRequestId: null,
      clientResponseMs: Number((performance.now() - startedAt).toFixed(3)),
      statusCode: null,
      error: error instanceof Error ? error.message : String(error),
    };
  }
}

async function main() {
  const url = requiredEnvironment('BENCHMARK_URL');
  const scenario = requiredEnvironment('BENCHMARK_SCENARIO');
  const requestCount = positiveInteger('BENCHMARK_REQUESTS', 100);
  const concurrency = positiveInteger('BENCHMARK_CONCURRENCY', 1);
  const resultsDir = path.resolve(
    process.env.BENCHMARK_RESULTS_DIR || 'results',
  );
  const results: RequestResult[] = [];
  let nextRequest = 0;

  const worker = async () => {
    while (nextRequest < requestCount) {
      nextRequest++;
      results.push(await sendRequest(url, scenario));
    }
  };

  const startedAt = new Date().toISOString();
  await Promise.all(
    Array.from({ length: Math.min(concurrency, requestCount) }, worker),
  );

  const successfulLatencies = results
    .filter((result) => result.statusCode !== null && result.statusCode < 400)
    .map((result) => result.clientResponseMs);
  const report = {
    scenario,
    url,
    startedAt,
    requestCount,
    concurrency,
    summary: {
      successfulRequests: successfulLatencies.length,
      failedRequests: results.length - successfulLatencies.length,
      averageClientResponseMs: average(successfulLatencies),
      p50ClientResponseMs: percentile(successfulLatencies, 50),
      p95ClientResponseMs: percentile(successfulLatencies, 95),
      p99ClientResponseMs: percentile(successfulLatencies, 99),
    },
    requests: results,
  };

  await mkdir(resultsDir, { recursive: true });
  const outputFile = path.join(
    resultsDir,
    `${scenario}-${startedAt.replaceAll(':', '-')}.json`,
  );
  await writeFile(outputFile, `${JSON.stringify(report, null, 2)}\n`);
  console.log(JSON.stringify({ outputFile, ...report.summary }, null, 2));
}

main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
