import autocannon from 'autocannon';
import inspector from 'inspector';

// import path from 'path';

// Disable console.error to avoid spam from the circular JSON error in demo-app
console.error = () => {};

const session = new inspector.Session();
session.connect();

let breakpointId: string | null = null;
let scriptId = '';

session.post('Debugger.enable', () => {
  session.on('Debugger.scriptParsed', (message) => {
    if (message.params.url.includes('demo-app/dist/index.js')) {
      scriptId = message.params.scriptId;
      console.log(`Found demo-app scriptId: ${scriptId}`);
    }
  });
});

async function sleep(ms: number) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

async function runTest(
  name: string,
  setup: () => Promise<void>,
  teardown: () => Promise<void>,
) {
  console.log(`\n--- Running Test: ${name} ---`);
  await setup();

  const checkoutBody = {
    userId: '123',
    items: [
      { price: 120, quantity: 2 },
      { price: 50, quantity: 1 },
    ],
  };

  const result = await new Promise<any>((resolve, reject) => {
    autocannon(
      {
        url: 'http://localhost:3000/checkout',
        method: 'POST',
        body: JSON.stringify(checkoutBody),
        headers: { 'content-type': 'application/json' },
        connections: 10,
        pipelining: 1,
        duration: 10, // 10 seconds per test for a solid average
      },
      (err, res) => {
        if (err) reject(err);
        else resolve(res);
      },
    );
  });

  console.log(`Results for ${name}:`);
  console.log(`Req/Sec: ${result.requests.average}`);
  console.log(`Latency P99: ${result.latency.p99}`);

  await teardown();
}

async function main() {
  console.log('Starting demo-app...');
  await import('../../../apps/demo-app/dist/index.js');
  await sleep(2000); // give app time to listen

  // Test 0: Baseline (No Breakpoints)
  await runTest(
    '0. Baseline (No Breakpoints)',
    async () => {
      // No setup needed, just ensure no breakpoints exist
    },
    async () => {
      // No teardown needed
    },
  );

  // Test 1: Empty breakpoint (Pause & Resume)
  const onPaused1 = () => {
    session.post('Debugger.resume');
  };
  await runTest(
    '1. Empty Breakpoint (Pause & Resume)',
    async () => {
      session.on('Debugger.paused', onPaused1);
      const res = await new Promise<any>((resolve) => {
        session.post(
          'Debugger.setBreakpointByUrl',
          {
            lineNumber: 27,
            urlRegex: '.*demo-app/dist/index.js.*',
          },
          (_err, r) => resolve(r),
        );
      });
      breakpointId = res.breakpointId;
    },
    async () => {
      session.off('Debugger.paused', onPaused1);
      await new Promise<void>((resolve) => {
        session.post(
          'Debugger.removeBreakpoint',
          { breakpointId: breakpointId! },
          () => resolve(),
        );
      });
    },
  );

  // Test 2: Conditional breakpoint evaluating to false
  await runTest(
    '2. Conditional Breakpoint (false)',
    async () => {
      const res = await new Promise<any>((resolve) => {
        session.post(
          'Debugger.setBreakpointByUrl',
          {
            lineNumber: 27,
            urlRegex: '.*demo-app/dist/index.js.*',
            condition: 'false',
          },
          (_err, r) => resolve(r),
        );
      });
      breakpointId = res.breakpointId;
    },
    async () => {
      await new Promise<void>((resolve) => {
        session.post(
          'Debugger.removeBreakpoint',
          { breakpointId: breakpointId! },
          () => resolve(),
        );
      });
    },
  );

  // Test 3: Evaluate variable in pause handler
  const onPaused3 = (message: any) => {
    const callFrameId = message.params.callFrames[0].callFrameId;
    session.post(
      'Debugger.evaluateOnCallFrame',
      {
        callFrameId,
        expression: '"test_string_evaluation"',
      },
      () => {
        session.post('Debugger.resume');
      },
    );
  };
  await runTest(
    '3. Evaluate Variable on Pause',
    async () => {
      session.on('Debugger.paused', onPaused3);
      const res = await new Promise<any>((resolve) => {
        session.post(
          'Debugger.setBreakpointByUrl',
          {
            lineNumber: 27,
            urlRegex: '.*demo-app/dist/index.js.*',
          },
          (_err, r) => resolve(r),
        );
      });
      breakpointId = res.breakpointId;
    },
    async () => {
      session.off('Debugger.paused', onPaused3);
      await new Promise<void>((resolve) => {
        session.post(
          'Debugger.removeBreakpoint',
          { breakpointId: breakpointId! },
          () => resolve(),
        );
      });
    },
  );

  // Test 4: Evaluate the same expression in the condition of the breakpoint inside console.log() && false
  // Condition: console.log("test_string_evaluation") && false
  // Since it returns false, it will never pause, but we'll see console.log output (we can mock console.log if we don't want spam, or just let it log)
  // Let's mute console.log during this test to avoid massive spam, we just want to know if it executes.
  // Actually, wait, let's capture if console.log was called.
  let consoleLogCalled = 0;
  const originalLog = console.log;

  await runTest(
    '4. Evaluate in Condition (console.log && false)',
    async () => {
      console.log = (msg: any) => {
        if (msg === 'test_string_evaluation') {
          consoleLogCalled++;
          if (consoleLogCalled <= 5) {
            originalLog(
              `\x1b[32m[ACTUAL STDOUT]\x1b[0m ${msg} (print ${consoleLogCalled}/5)`,
            );
          }
        } else {
          originalLog(msg);
        }
      };

      const res = await new Promise<any>((resolve) => {
        session.post(
          'Debugger.setBreakpointByUrl',
          {
            lineNumber: 27,
            urlRegex: '.*demo-app/dist/index.js.*',
            condition: 'console.log("test_string_evaluation") && false',
          },
          (_err, r) => resolve(r),
        );
      });
      breakpointId = res.breakpointId;
    },
    async () => {
      console.log = originalLog;
      console.log(
        `[Validation] console.log was called ${consoleLogCalled} times during Test 4.`,
      );
      await new Promise<void>((resolve) => {
        session.post(
          'Debugger.removeBreakpoint',
          { breakpointId: breakpointId! },
          () => resolve(),
        );
      });
    },
  );

  process.exit(0);
}

main().catch((err) => {
  console.log(err);
  process.exit(1);
});
