import { BrokerClient } from '../core/broker.js';
import {
  SourceMapUploader,
  type UploaderOptions,
} from '../core/source-map-uploader.js';

const POLL_TIMEOUT_MS = 180000;
const POLL_INTERVAL_MS = 2000;

type UploadMapsClient = Pick<
  BrokerClient,
  | 'getSourceMapStatus'
  | 'markSourceMapComplete'
  | 'createUploadStream'
  | 'shutdown'
>;

export interface UploadMapsDependencies {
  createBrokerClient: (
    brokerUrl: string,
    serviceId: string,
    environment: string,
    commitSha: string,
    isEphemeralLambda: boolean,
    enableKeepAlive: boolean,
  ) => UploadMapsClient;
  createUploader: (
    options: UploaderOptions,
  ) => Pick<SourceMapUploader, 'uploadAll'>;
  now: () => number;
  random: () => number;
  sleep: (ms: number) => Promise<void>;
}

const dependencies: UploadMapsDependencies = {
  createBrokerClient: (...args) => new BrokerClient(...args),
  createUploader: (options) => new SourceMapUploader(options),
  now: Date.now,
  random: Math.random,
  sleep: (ms) => new Promise((resolve) => setTimeout(resolve, ms)),
};

function pollDelay(random: () => number): number {
  return POLL_INTERVAL_MS + Math.floor((random() - 0.5) * 400);
}

function isRetryableStatusError(error: unknown): boolean {
  const code =
    typeof error === 'object' && error && 'code' in error
      ? (error as { code?: unknown }).code
      : undefined;

  // gRPC INVALID_ARGUMENT, PERMISSION_DENIED, and UNAUTHENTICATED errors
  // cannot succeed on retry without configuration changes.
  return ![3, 7, 16].includes(code as number);
}

async function waitForUploader(
  brokerClient: UploadMapsClient,
  options: UploadMapsDependencies,
): Promise<'complete' | 'uploader'> {
  const deadline = options.now() + POLL_TIMEOUT_MS;

  while (true) {
    try {
      const { isComplete, isUploader } =
        await brokerClient.getSourceMapStatus();

      if (isComplete) return 'complete';
      if (isUploader) return 'uploader';
    } catch (err: any) {
      if (!isRetryableStatusError(err)) throw err;
      console.warn(
        '[HyperProbe CLI] Failed to check source map status; retrying:',
        err.message || err,
      );
    }

    if (options.now() >= deadline) {
      throw new Error(
        `Timed out after ${POLL_TIMEOUT_MS / 1000}s waiting for source map upload to complete`,
      );
    }

    await options.sleep(pollDelay(options.random));
  }
}

export async function main(
  options: UploadMapsDependencies = dependencies,
): Promise<number> {
  const serviceId = process.env.HYPERPROBE_SERVICE_ID;
  const environment = process.env.HYPERPROBE_ENVIRONMENT || 'production';
  const brokerUrl = process.env.HYPERPROBE_BROKER_URL;
  const appRoot = process.env.HYPERPROBE_APP_ROOT || '';
  const distLocation = process.env.HYPERPROBE_DIST_LOCATION || '';
  const sourceMapDir = process.env.HYPERPROBE_SOURCE_MAP_DIR;
  const commitSha = process.env.GIT_COMMIT || process.env.HYPERPROBE_COMMIT_SHA;
  const isLambda = process.env.IS_LAMBDA
    ? process.env.IS_LAMBDA === 'true'
    : undefined;

  if (!serviceId) {
    console.error(
      'Error: HYPERPROBE_SERVICE_ID environment variable is required',
    );
    return 1;
  }
  if (!brokerUrl) {
    console.error(
      'Error: HYPERPROBE_BROKER_URL environment variable is required',
    );
    return 1;
  }
  if (!commitSha) {
    console.error(
      'Error: GIT_COMMIT (or HYPERPROBE_COMMIT_SHA) environment variable is required',
    );
    return 1;
  }

  console.log(
    `[HyperProbe CLI] Starting source map upload for service ${serviceId}...`,
  );

  const isAwsLambda = !!process.env.AWS_LAMBDA_FUNCTION_NAME;
  const isLocalEmulator =
    process.env.IS_OFFLINE === 'true' || process.env.AWS_SAM_LOCAL === 'true';
  const isEphemeralLambda = (isLambda ?? isAwsLambda) && !isLocalEmulator;
  const enableKeepAlive = process.env.HYPERPROBE_ENABLE_KEEP_ALIVE
    ? process.env.HYPERPROBE_ENABLE_KEEP_ALIVE === 'true'
    : !isEphemeralLambda;
  const brokerClient = options.createBrokerClient(
    brokerUrl,
    serviceId,
    environment,
    commitSha,
    isEphemeralLambda,
    enableKeepAlive,
  );

  try {
    const status = await waitForUploader(brokerClient, options);
    if (status === 'complete') {
      console.log(
        '[HyperProbe CLI] Source maps are already complete in backend.',
      );
      return 0;
    }

    const uploader = options.createUploader({
      serviceId,
      environment,
      commitSha,
      appRoot,
      distLocation,
      sourceMapDir,
      createUploadStream: brokerClient.createUploadStream.bind(brokerClient),
    });
    const uploadedCount = await uploader.uploadAll();

    if (uploadedCount === 0) {
      throw new Error(
        `No source map files found in ${sourceMapDir || process.cwd()}`,
      );
    }

    await brokerClient.markSourceMapComplete();
    console.log('[HyperProbe CLI] Source maps uploaded successfully.');
    return 0;
  } catch (err: any) {
    console.error(
      '[HyperProbe CLI] Failed to upload source maps:',
      err.message || err,
    );
    return 1;
  } finally {
    brokerClient.shutdown();
  }
}

if (
  typeof require !== 'undefined' &&
  typeof module !== 'undefined' &&
  require.main === module
) {
  void main().then((code) => {
    process.exitCode = code;
  });
}
