import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import { main, type UploadMapsDependencies } from './upload-maps.js';

const environment = { ...process.env };

function createDependencies(
  statuses: Array<{ isComplete: boolean; isUploader: boolean }>,
  uploadedCount: number,
) {
  let now = 0;
  const brokerClient = {
    getSourceMapStatus: vi.fn(
      async () => statuses.shift() || { isComplete: false, isUploader: false },
    ),
    markSourceMapComplete: vi.fn(async () => undefined),
    createUploadStream: vi.fn(),
    shutdown: vi.fn(),
  };
  const createUploader = vi.fn(() => ({
    uploadAll: vi.fn(async () => uploadedCount),
  }));
  const dependencies: UploadMapsDependencies = {
    createBrokerClient: vi.fn(() => brokerClient),
    createUploader,
    now: () => now,
    random: () => 0.5,
    sleep: async () => {
      now += 2000;
    },
  };

  return { brokerClient, createUploader, dependencies };
}

beforeEach(() => {
  process.env.HYPERPROBE_SERVICE_ID = 'service';
  process.env.HYPERPROBE_BROKER_URL = 'https://broker.example.com';
  process.env.GIT_COMMIT = 'commit';
  process.env.HYPERPROBE_SOURCE_MAP_DIR = 'dist';
  vi.spyOn(console, 'error').mockImplementation(() => undefined);
  vi.spyOn(console, 'log').mockImplementation(() => undefined);
  vi.spyOn(console, 'warn').mockImplementation(() => undefined);
});

afterEach(() => {
  process.env = { ...environment };
  vi.restoreAllMocks();
});

describe('upload-maps CLI', () => {
  it('does not upload when another uploader completes the map set', async () => {
    const { brokerClient, createUploader, dependencies } = createDependencies(
      [
        { isComplete: false, isUploader: false },
        { isComplete: true, isUploader: false },
      ],
      1,
    );

    await expect(main(dependencies)).resolves.toBe(0);
    expect(createUploader).not.toHaveBeenCalled();
    expect(brokerClient.markSourceMapComplete).not.toHaveBeenCalled();
    expect(brokerClient.shutdown).toHaveBeenCalledOnce();
  });

  it('does not mark maps complete when the uploader finds no maps', async () => {
    const { brokerClient, dependencies } = createDependencies(
      [{ isComplete: false, isUploader: true }],
      0,
    );

    await expect(main(dependencies)).resolves.toBe(1);
    expect(brokerClient.markSourceMapComplete).not.toHaveBeenCalled();
  });

  it('fails when another uploader does not complete before the lock timeout', async () => {
    const { brokerClient, createUploader, dependencies } = createDependencies(
      [],
      1,
    );

    await expect(main(dependencies)).resolves.toBe(1);
    expect(createUploader).not.toHaveBeenCalled();
    expect(brokerClient.markSourceMapComplete).not.toHaveBeenCalled();
  });

  it('fails immediately for a non-retryable status error', async () => {
    const { brokerClient, dependencies } = createDependencies([], 1);
    brokerClient.getSourceMapStatus.mockRejectedValue({ code: 7 });

    await expect(main(dependencies)).resolves.toBe(1);
    expect(brokerClient.getSourceMapStatus).toHaveBeenCalledOnce();
  });

  it('marks maps complete only after a successful non-empty upload', async () => {
    const { brokerClient, dependencies } = createDependencies(
      [{ isComplete: false, isUploader: true }],
      1,
    );

    await expect(main(dependencies)).resolves.toBe(0);
    expect(brokerClient.markSourceMapComplete).toHaveBeenCalledOnce();
  });
});
