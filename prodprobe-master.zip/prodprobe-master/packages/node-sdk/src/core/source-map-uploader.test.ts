import * as fs from 'node:fs/promises';
import * as os from 'node:os';
import * as path from 'node:path';
import { Writable } from 'node:stream';
import { afterEach, describe, expect, it, vi } from 'vitest';
import {
  SourceMapUploader,
  SourcesContentStripper,
} from './source-map-uploader.js';

const tempDirs: string[] = [];

async function makeTempDir(): Promise<string> {
  const dir = await fs.mkdtemp(path.join(os.tmpdir(), 'hyperprobe-maps-'));
  tempDirs.push(dir);
  return dir;
}

async function stripSourceMap(
  input: string,
  chunkSize: number,
): Promise<string> {
  const chunks: string[] = [];
  for (let offset = 0; offset < input.length; offset += chunkSize) {
    chunks.push(input.slice(offset, offset + chunkSize));
  }
  return stripSourceMapChunks(chunks);
}

async function stripSourceMapChunks(
  chunks: readonly string[],
): Promise<string> {
  const stripper = new SourcesContentStripper();
  const output: string[] = [];
  const completed = new Promise<void>((resolve, reject) => {
    stripper.on('data', (chunk: string | Buffer) =>
      output.push(chunk.toString()),
    );
    stripper.once('end', resolve);
    stripper.once('error', reject);
  });

  for (const chunk of chunks) {
    stripper.write(chunk);
  }
  stripper.end();

  await completed;
  return output.join('');
}

afterEach(async () => {
  await Promise.all(
    tempDirs.splice(0).map((dir) => fs.rm(dir, { recursive: true })),
  );
});

describe('SourceMapUploader', () => {
  it('strips sourcesContent without invalidating the source map', async () => {
    const sourceMap = {
      version: 3,
      file: 'main.js',
      mappings: 'AAAA;AACA',
      sources: [
        'webpack:///./src/app/resolvers/Program.ts',
        'webpack:///../../libs/monitors/src/lib/tracing.ts',
      ],
      note: 'sourcesContent',
      sourcesContent: [
        "export class ProgramResolver {\n  getProgram() {\n    return 'program';\n  }\n}\n",
        'export function startTracing(): void {}\n',
      ],
      names: [],
      sourceRoot: '',
    };

    const stripped = await stripSourceMap(JSON.stringify(sourceMap), 7);

    expect(JSON.parse(stripped)).toEqual({
      ...sourceMap,
      sourcesContent: [],
    });
  });

  it('ignores single-quoted source text before a key split across chunks', async () => {
    const sourceMap = {
      version: 3,
      note: "const label = 'sourcesContent';",
      sourcesContent: ['SECRET'],
      sources: ['src/main.ts'],
      mappings: 'AAAA',
    };
    const input = JSON.stringify(sourceMap);
    const key = '"sourcesContent"';
    const rootKeyStart = input.lastIndexOf(key);
    const splitAt = rootKeyStart + key.length - 1;

    const stripped = await stripSourceMapChunks([
      input.slice(0, splitAt),
      input.slice(splitAt),
    ]);

    expect(JSON.parse(stripped)).toEqual({
      ...sourceMap,
      sourcesContent: [],
    });
  });

  it('handles nested sourcesContent with non-array values without leaking root sourcesContent', async () => {
    const sourceMap = {
      version: 3,
      metadata: {
        sourcesContent: 'not an array but a string value',
      },
      sourcesContent: ['SECRET_CODE'],
      sources: ['src/main.ts'],
      mappings: 'AAAA',
    };

    const stripped = await stripSourceMap(JSON.stringify(sourceMap), 10);

    expect(JSON.parse(stripped)).toEqual({
      ...sourceMap,
      sourcesContent: [],
    });
  });

  it('returns zero when the configured directory contains no source maps', async () => {
    const dir = await makeTempDir();
    const uploader = new SourceMapUploader({
      serviceId: 'service',
      environment: 'production',
      commitSha: 'commit',
      appRoot: 'apps/sample',
      distLocation: 'dist',
      sourceMapDir: dir,
      createUploadStream: () =>
        new Writable({
          write(_chunk, _encoding, done) {
            done();
          },
        }),
    });

    await expect(uploader.uploadAll()).resolves.toBe(0);
  });

  it('uploads maps relative to the configured source-map directory', async () => {
    const dir = await makeTempDir();
    await fs.writeFile(path.join(dir, 'handler.js.map'), '{"version":3}');
    const fileNames: string[] = [];
    const uploader = new SourceMapUploader({
      serviceId: 'service',
      environment: 'production',
      commitSha: 'commit',
      appRoot: 'apps/sample',
      distLocation: 'dist',
      sourceMapDir: dir,
      createUploadStream: (fileName) => {
        fileNames.push(fileName);
        return new Writable({
          write(_chunk, _encoding, done) {
            done();
          },
        });
      },
    });

    await expect(uploader.uploadAll()).resolves.toBe(1);
    expect(fileNames).toEqual(['apps/sample/dist/handler.js.map']);
  });

  it('uploads nested maps relative to the source-map directory', async () => {
    const dir = await makeTempDir();
    const sourceMapDir = path.join(dir, 'dist');
    await fs.mkdir(path.join(sourceMapDir, 'services', 'posts'), {
      recursive: true,
    });
    await fs.writeFile(
      path.join(sourceMapDir, 'services', 'posts', 'main.js.map'),
      JSON.stringify({
        version: 3,
        file: 'main.js',
        sources: ['webpack:///services/posts/src/main.ts'],
        mappings: 'AAAA',
      }),
    );
    const fileNames: string[] = [];
    const uploader = new SourceMapUploader({
      serviceId: 'service',
      environment: 'production',
      commitSha: 'commit',
      appRoot: 'services/posts',
      distLocation: '',
      sourceMapDir: path.relative(process.cwd(), sourceMapDir),
      createUploadStream: (fileName) => {
        fileNames.push(fileName);
        return new Writable({
          write(_chunk, _encoding, done) {
            done();
          },
        });
      },
    });

    await expect(uploader.uploadAll()).resolves.toBe(1);
    expect(fileNames).toEqual(['services/posts/main.js.map']);
  });

  it('does not duplicate path segments when both sourceMapDir and distLocation are specified', async () => {
    const dir = await makeTempDir();
    const sourceMapDir = path.join(dir, 'dist');
    await fs.mkdir(path.join(sourceMapDir, 'services', 'posts'), {
      recursive: true,
    });
    await fs.writeFile(
      path.join(sourceMapDir, 'services', 'posts', 'main.js.map'),
      JSON.stringify({
        version: 3,
        file: 'main.js',
        sources: ['webpack:///services/posts/src/main.ts'],
        mappings: 'AAAA',
      }),
    );
    const fileNames: string[] = [];
    const uploader = new SourceMapUploader({
      serviceId: 'service',
      environment: 'production',
      commitSha: 'commit',
      appRoot: 'services/posts',
      distLocation: 'dist',
      sourceMapDir: path.relative(process.cwd(), sourceMapDir),
      createUploadStream: (fileName) => {
        fileNames.push(fileName);
        return new Writable({
          write(_chunk, _encoding, done) {
            done();
          },
        });
      },
    });

    await expect(uploader.uploadAll()).resolves.toBe(1);
    expect(fileNames).toEqual(['services/posts/main.js.map']);
  });

  it('normalizes appRoot with leading dot-segments and does not duplicate paths', async () => {
    const dir = await makeTempDir();
    const sourceMapDir = path.join(dir, 'dist');
    await fs.mkdir(path.join(sourceMapDir, 'services', 'posts'), {
      recursive: true,
    });
    await fs.writeFile(
      path.join(sourceMapDir, 'services', 'posts', 'main.js.map'),
      JSON.stringify({
        version: 3,
        file: 'main.js',
        sources: ['webpack:///services/posts/src/main.ts'],
        mappings: 'AAAA',
      }),
    );
    const fileNames: string[] = [];
    const uploader = new SourceMapUploader({
      serviceId: 'service',
      environment: 'production',
      commitSha: 'commit',
      appRoot: './services/posts',
      distLocation: 'dist',
      sourceMapDir: path.relative(process.cwd(), sourceMapDir),
      createUploadStream: (fileName) => {
        fileNames.push(fileName);
        return new Writable({
          write(_chunk, _encoding, done) {
            done();
          },
        });
      },
    });

    await expect(uploader.uploadAll()).resolves.toBe(1);
    expect(fileNames).toEqual(['services/posts/main.js.map']);
  });

  it('uses process.cwd when sourceMapDir is omitted', async () => {
    const dir = await makeTempDir();
    await fs.writeFile(path.join(dir, 'handler.js.map'), '{"version":3}');
    const fileNames: string[] = [];
    const cwd = vi.spyOn(process, 'cwd').mockReturnValue(dir);

    try {
      const uploader = new SourceMapUploader({
        serviceId: 'service',
        environment: 'production',
        commitSha: 'commit',
        appRoot: 'apps/sample',
        distLocation: 'dist',
        createUploadStream: (fileName) => {
          fileNames.push(fileName);
          return new Writable({
            write(_chunk, _encoding, done) {
              done();
            },
          });
        },
      });

      await expect(uploader.uploadAll()).resolves.toBe(1);
      expect(fileNames).toEqual(['apps/sample/dist/handler.js.map']);
    } finally {
      cwd.mockRestore();
    }
  });

  it('strips Windows drive letters and normalizes absolute Windows appRoot in prefix construction', async () => {
    const dir = await makeTempDir();
    const sourceMapDir = path.join(dir, 'output');
    await fs.mkdir(sourceMapDir, { recursive: true });
    await fs.writeFile(
      path.join(sourceMapDir, 'main.js.map'),
      JSON.stringify({
        version: 3,
        file: 'main.js',
        sources: ['webpack:///services/posts/src/main.ts'],
        mappings: 'AAAA',
      }),
    );
    const fileNames: string[] = [];
    const uploader = new SourceMapUploader({
      serviceId: 'service',
      environment: 'production',
      commitSha: 'commit',
      appRoot: 'C:\\services\\posts',
      distLocation: 'dist',
      sourceMapDir: path.relative(process.cwd(), sourceMapDir),
      createUploadStream: (fileName) => {
        fileNames.push(fileName);
        return new Writable({
          write(_chunk, _encoding, done) {
            done();
          },
        });
      },
    });

    await expect(uploader.uploadAll()).resolves.toBe(1);
    expect(fileNames).toEqual(['services/posts/dist/main.js.map']);
  });

  it('handles case-insensitive path comparisons on Windows environments', async () => {
    const dir = await makeTempDir();
    const sourceMapDir = path.join(dir, 'dist');
    await fs.mkdir(path.join(sourceMapDir, 'Services', 'Posts'), {
      recursive: true,
    });
    await fs.writeFile(
      path.join(sourceMapDir, 'Services', 'Posts', 'main.js.map'),
      JSON.stringify({
        version: 3,
        file: 'main.js',
        sources: ['webpack:///services/posts/src/main.ts'],
        mappings: 'AAAA',
      }),
    );
    const fileNames: string[] = [];
    const uploader = new SourceMapUploader({
      serviceId: 'service',
      environment: 'production',
      commitSha: 'commit',
      appRoot: 'C:\\services\\posts',
      distLocation: 'dist',
      sourceMapDir: path.relative(process.cwd(), sourceMapDir),
      createUploadStream: (fileName) => {
        fileNames.push(fileName);
        return new Writable({
          write(_chunk, _encoding, done) {
            done();
          },
        });
      },
    });

    await expect(uploader.uploadAll()).resolves.toBe(1);
    expect(fileNames).toEqual(['Services/Posts/main.js.map']);
  });
});
