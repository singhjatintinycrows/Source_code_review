import * as fs from 'node:fs';
import * as inspector from 'node:inspector';
import path from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
import * as util from 'node:util';
import {
  type AgentGlobalConfig,
  type Probe,
  ProbeType,
  type TelemetryEvent,
} from '@hyperprobe/protos';
import debug from 'debug';
import { extractTraceContext } from './context-extractor.js';
import {
  prepareLogTemplate,
  wrapExpressionsForEvaluation,
} from './evaluation-utils.js';
import type { QuotaManager } from './quota.js';
import { getSerializationScript } from './serialization-script.js';

const log = debug('hyperprobe:inspector');

const EVAL_OBJECT_GROUP = 'hyperprobe-eval-group';

function normalizePathForComparison(p: string): string {
  let normalized = p.replace(/\\/g, '/');
  if (/^\/[a-zA-Z]:/.test(normalized)) {
    normalized = normalized.slice(1);
  }
  if (/^[a-zA-Z]:/.test(normalized)) {
    return normalized[0].toLowerCase() + normalized.slice(1);
  }
  return normalized;
}

interface ActiveProbeContext {
  probe: Probe;
  isSecondary: boolean;
}

export class InspectorEngine {
  private session?: inspector.Session;
  private scriptIdToUrl = new Map<string, string>();
  private activeProbes = new Map<string, ActiveProbeContext[]>(); // breakpointId -> Contexts
  private activeLocations = new Map<
    string,
    { breakpointId: string; script: string }
  >(); // locationKey -> V8 State
  private probeMap = new Map<string, Probe>(); // lookup for inline handlers
  private inlineNamespaceId = '__HYPERPROBE_INLINE__';
  private onTelemetryCapture: (event: TelemetryEvent) => void;
  private quotaManager: QuotaManager;
  private onPauseDuration: (ms: number) => void;
  private isSuspended: boolean = false;
  private isConnected: boolean = false;
  private disconnectTimeout?: NodeJS.Timeout;
  private currentProbes: Probe[] = [];
  private totalHits: number = 0;
  private totalSkips: number = 0;
  private durationMap = new Map<
    string,
    { startTime: number; timestamp: number }
  >();
  private cleanupInterval?: NodeJS.Timeout;
  private pendingOp: Promise<any> = Promise.resolve();
  private globalConfig!: AgentGlobalConfig;
  private pathCache = new Map<string, string>();
  private appScriptsCache?: { size: number; map: Map<string, string> };
  private customGetTraceId?: () => string | undefined;
  private appRoot?: string;
  constructor(
    quotaManager: QuotaManager,
    onPauseDuration: (ms: number) => void,
    onTelemetryCapture: (event: TelemetryEvent) => void,
    customGetTraceId?: () => string | undefined,
    appRoot?: string,
  ) {
    this.quotaManager = quotaManager;
    this.onPauseDuration = onPauseDuration;
    this.onTelemetryCapture = onTelemetryCapture;
    this.customGetTraceId = customGetTraceId;
    this.appRoot = appRoot;
  }

  public setGlobalConfig(config: AgentGlobalConfig) {
    this.globalConfig = config;
  }

  private registerScriptUrl(scriptId: string, url: string) {
    this.scriptIdToUrl.set(scriptId, url);
    this.appScriptsCache = undefined;
  }

  private setupInlineHandlers() {
    (global as any)[this.inlineNamespaceId] = {
      emitCounter: (probeId: string) => this.handleInlineCounter(probeId),
      emitMetric: (probeId: string, val: any) =>
        this.handleInlineMetric(probeId, val),
      emitLog: (probeId: string, val: any) =>
        this.handleInlineLog(probeId, val),
      startDuration: (probeId: string, corrId: any) =>
        this.handleInlineDurationStart(probeId, corrId),
      endDuration: (probeId: string, corrId: any) =>
        this.handleInlineDurationEnd(probeId, corrId),
      emitError: (probeId: string, err: string) =>
        this.handleInlineError(probeId, err),
    };
  }

  private getTraceId(probeId: string): string | undefined {
    const probe = this.probeMap.get(probeId);
    if (!probe?.shouldCaptureTraceId) return;

    const traceId = extractTraceContext(this.customGetTraceId);
    if (!traceId) {
      log('TraceId not found for probe %s', probeId);
      return;
    }
    return traceId;
  }

  private handleInlineCounter(probeId: string) {
    if (!this.quotaManager.canEvaluate()) {
      this.totalSkips++;
      return;
    }

    const event: TelemetryEvent = {
      probeId,
      traceId: this.getTraceId(probeId),
      timestampMs: BigInt(Date.now()),
      metricValue: 1,
      stackFrames: [],
      capturedVarsJson: '',
      watchResultsJson: '',
      evaluatedLog: '',
      captureError: '',
    };

    const payloadSize = this.getSerializedSize(event);
    if (!this.quotaManager.canSend(payloadSize)) {
      this.totalSkips++;
      return;
    }
    this.totalHits++;
    this.onTelemetryCapture(event);
  }

  private handleInlineMetric(probeId: string, val: any) {
    if (!this.quotaManager.canEvaluate()) {
      this.totalSkips++;
      return;
    }

    const event: TelemetryEvent = {
      probeId,
      traceId: this.getTraceId(probeId),
      timestampMs: BigInt(Date.now()),
      stackFrames: [],
      capturedVarsJson: '',
      watchResultsJson: '',
      evaluatedLog: '',
      metricValue: 0,
      captureError: '',
    };

    const parsed = typeof val === 'number' ? val : parseFloat(val);
    if (Number.isFinite(parsed)) {
      event.metricValue = parsed;
    } else {
      event.captureError = `Metric evaluation failed: ${val}`;
    }

    const payloadSize = this.getSerializedSize(event);
    if (!this.quotaManager.canSend(payloadSize)) {
      this.totalSkips++;
      return;
    }
    this.totalHits++;
    this.onTelemetryCapture(event);
  }

  private handleInlineLog(probeId: string, val: any) {
    if (!this.quotaManager.canEvaluate()) {
      this.totalSkips++;
      return;
    }

    const probe = this.probeMap.get(probeId);
    let logStr =
      typeof val === 'string'
        ? val
        : util.inspect(val, { depth: 3, breakLength: Infinity });

    if (probe) {
      const maxStringLength =
        probe.maxStringLength ?? this.globalConfig.maxStringLength ?? 1024;
      if (logStr.length > maxStringLength) {
        const head = logStr.substring(0, maxStringLength);
        const truncatedHead = head.replace(/\b\w*$/, '').trim();
        logStr =
          truncatedHead +
          '... [Truncated: +' +
          (logStr.length - maxStringLength) +
          ' more chars]';
      }
    }

    if (this.globalConfig.redactValues.length > 0) {
      const re = this.makeSafeRegex(this.globalConfig.redactValues);
      if (re) {
        logStr = logStr.replace(re, '[REDACTED Value]');
      }
    }

    const isStdout = probe?.shouldLogToStdout || false;

    if (isStdout) {
      const level = (probe?.logLevel || 'INFO').toUpperCase();
      const timestamp = new Date().toISOString();

      const LEVEL_COLORS: Record<string, string> = {
        ERROR: '\x1b[31m', // Red
        INFO: '\x1b[32m', // Green
      };
      const COLOR_RESET = '\x1b[0m';
      const COLOR_BOLD = '\x1b[1m';
      const COLOR_GRAY = '\x1b[90m';
      const COLOR_MAGENTA = '\x1b[35m';

      const levelColor = LEVEL_COLORS[level] || '\x1b[37m';
      const outputLine =
        `${COLOR_GRAY}[${timestamp}]${COLOR_RESET} ` +
        `${COLOR_BOLD}${levelColor}[${level}]${COLOR_RESET} ` +
        `${COLOR_BOLD}${COLOR_MAGENTA}[HyperProbe LOG]${COLOR_RESET} ` +
        `${logStr}\n`;

      const outputStream =
        level.toLowerCase() === 'error' ? process.stderr : process.stdout;
      outputStream.write(outputLine);
    }

    const event: TelemetryEvent = {
      probeId,
      traceId: this.getTraceId(probeId),
      timestampMs: BigInt(Date.now()),
      stackFrames: [],
      capturedVarsJson: '',
      watchResultsJson: '',
      evaluatedLog: logStr,
      metricValue: 0,
      captureError: '',
    };

    const payloadSize = this.getSerializedSize(event);
    if (!this.quotaManager.canSend(payloadSize)) {
      this.totalSkips++;
      return;
    }
    this.totalHits++;
    this.onTelemetryCapture(event);
  }

  private handleInlineDurationStart(probeId: string, corrId: any) {
    const correlationId = this.normalizeCorrelationId(corrId);
    if (correlationId instanceof Error) {
      this.handleInlineError(probeId, correlationId.message);
      return;
    }

    const mapKey = `${probeId}:${correlationId}`;
    this.durationMap.set(mapKey, {
      startTime: performance.now(),
      timestamp: Date.now(),
    });
  }

  private handleInlineDurationEnd(probeId: string, corrId: any) {
    const correlationId = this.normalizeCorrelationId(corrId);
    if (correlationId instanceof Error) {
      this.handleInlineError(probeId, correlationId.message);
      return;
    }

    const mapKey = `${probeId}:${correlationId}`;
    const entry = this.durationMap.get(mapKey);
    if (!entry) return;
    this.durationMap.delete(mapKey);

    if (!this.quotaManager.canEvaluate()) {
      this.totalSkips++;
      return;
    }

    const duration = performance.now() - entry.startTime;
    const event: TelemetryEvent = {
      probeId,
      traceId: this.getTraceId(probeId),
      timestampMs: BigInt(Date.now()),
      metricValue: duration,
      stackFrames: [],
      capturedVarsJson: '',
      watchResultsJson: '',
      evaluatedLog: '',
      captureError: '',
    };

    const payloadSize = this.getSerializedSize(event);
    if (!this.quotaManager.canSend(payloadSize)) {
      this.totalSkips++;
      return;
    }
    this.totalHits++;
    this.onTelemetryCapture(event);
  }

  private handleInlineError(probeId: string, err: string) {
    const event: TelemetryEvent = {
      probeId,
      traceId: this.getTraceId(probeId),
      timestampMs: BigInt(Date.now()),
      captureError: err,
      stackFrames: [],
      capturedVarsJson: '',
      watchResultsJson: '',
      evaluatedLog: '',
      metricValue: 0,
    };
    const payloadSize = this.getSerializedSize(event);
    if (this.quotaManager.canSend(payloadSize)) {
      this.totalHits++;
      this.onTelemetryCapture(event);
    } else {
      this.totalSkips++;
    }
  }

  private normalizeCorrelationId(val: any): string | Error {
    if (val === undefined || val === null) return 'static-singleton';
    if (typeof val === 'string' && val.startsWith('Error: '))
      return new Error(val);
    if (typeof val === 'string' || typeof val === 'number') return String(val);
    const typeInfo = typeof val;
    return new Error(
      `Correlation expression must evaluate to a string or number, got ${typeInfo}`,
    );
  }

  private cleanupDurations() {
    const now = Date.now();
    for (const [key, entry] of this.durationMap.entries()) {
      if (now - entry.timestamp > 60000) {
        this.durationMap.delete(key);
      }
    }
  }

  public async connect(): Promise<void> {
    if (this.isConnected) return;
    if (this.session) {
      try {
        this.session.disconnect();
      } catch (_err) {
        // console.log(err);
      }
    }
    const session = new inspector.Session();
    this.session = session;
    session.connect();
    this.setupInlineHandlers();

    if (!this.cleanupInterval) {
      this.cleanupInterval = setInterval(() => this.cleanupDurations(), 60000);
      this.cleanupInterval.unref();
    }

    session.on('Debugger.scriptParsed', (message: any) => {
      const params = message.params || message;
      if (params.url) {
        this.registerScriptUrl(params.scriptId, params.url);
      }
    });

    session.on('Debugger.paused', (message: any) => {
      log('Debugger.paused event received!');
      const startTime = performance.now();
      this.handlePaused(session, message)
        .catch((err) => {
          log('Critical error in handlePaused: %O', err);
        })
        .finally(() => {
          if (this.isConnected && this.session === session) {
            try {
              session.post('Runtime.releaseObjectGroup', {
                objectGroup: EVAL_OBJECT_GROUP,
              });
              session.post('Debugger.resume');
            } catch (err) {
              log('Failed to post session commands after paused: %O', err);
            }
          }
          this.onPauseDuration(performance.now() - startTime);
        });
    });

    return new Promise((resolve, reject) => {
      session.post('Debugger.enable', {}, (err) => {
        if (err) {
          try {
            session.disconnect();
          } catch {}
          return reject(err);
        }
        /**
         * Commenting below code so that Node SDK inspector session initialization will avoid enabling async call stack capture
         * Aiming to optimize debugger pause/resume behavior to avoid added latency in this step
         */
        // const depth = this.globalConfig?.stackFrameDepth ?? 3;
        // session.post(
        //   'Debugger.setAsyncCallStackDepth',
        //   { maxDepth: depth },
        //   (err2) => {
        //     if (err2) {
        //       log(
        //         'Best-effort Debugger.setAsyncCallStackDepth failed: %O',
        //         err2,
        //       );
        //     }
        //     session.post('Runtime.enable', {}, (err3) => {
        //       if (err3) {
        //         try {
        //           session.disconnect();
        //         } catch {}
        //         return reject(err3);
        //       }
        //       this.isConnected = true;
        //       resolve();
        //     });
        //   },
        // );
        session.post('Runtime.enable', {}, (err3) => {
          if (err3) {
            try {
              session.disconnect();
            } catch {}
            return reject(err3);
          }
          this.isConnected = true;
          resolve();
        });
      });
    });
  }

  public async disconnect(): Promise<void> {
    return this.queueOp(async () => {
      if (this.cleanupInterval) {
        clearInterval(this.cleanupInterval);
        this.cleanupInterval = undefined;
      }
      if (this.disconnectTimeout) {
        clearTimeout(this.disconnectTimeout);
        this.disconnectTimeout = undefined;
      }
      if (this.session) {
        try {
          this.session.disconnect();
        } catch {
          // Safe to ignore
        }
        this.session = undefined;
      }
      this.isConnected = false;
      this.activeProbes.clear();
      this.activeLocations.clear();
      this.probeMap.clear();
      this.scriptIdToUrl.clear(); // <-- Clean up script metadata on disconnect
      this.appScriptsCache = undefined;
      this.durationMap.clear(); // <-- Clear stale durations on disconnect
      if (this.inlineNamespaceId in global) {
        delete (global as any)[this.inlineNamespaceId]; // <-- Break retain cycle on disconnect
      }
      log(
        'Inspector fully disconnected. Released native V8 debugging buffers.',
      );
    });
  }

  public async setProbes(probes: Probe[]): Promise<string[]> {
    return this.queueOp(async () => {
      this.currentProbes = probes;

      if (probes.length > 0 && this.disconnectTimeout) {
        clearTimeout(this.disconnectTimeout);
        this.disconnectTimeout = undefined;
        log('Canceled scheduled V8 inspector teardown.');
      }

      if (probes.length === 0) {
        const failed = await this.applyProbes([]);
        if (this.isConnected && !this.disconnectTimeout) {
          log(
            'No active probes. Scheduling lazy V8 inspector teardown in 10s...',
          );
          this.disconnectTimeout = setTimeout(() => {
            this.queueOp(async () => {
              if (this.currentProbes.length === 0 && this.isConnected) {
                log('Actively tearing down idle V8 inspector session...');
                if (this.session) {
                  try {
                    this.session.disconnect();
                  } catch {
                    // Safe to ignore
                  }
                  this.session = undefined;
                }
                this.isConnected = false;
                this.scriptIdToUrl.clear(); // <-- Clean up script metadata on idle disconnect
                this.appScriptsCache = undefined;
                this.durationMap.clear(); // <-- Clear stale durations on idle disconnect
                if (this.inlineNamespaceId in global) {
                  delete (global as any)[this.inlineNamespaceId]; // <-- Break retain cycle on idle disconnect
                }
                if (this.cleanupInterval) {
                  clearInterval(this.cleanupInterval);
                  this.cleanupInterval = undefined;
                }
              }
              this.disconnectTimeout = undefined;
            }).catch((err) => {
              log('Failed to tear down idle session: %O', err);
            });
          }, 10000);
          this.disconnectTimeout.unref();
        }
        return failed;
      }
      if (probes.length > 0 && this.isSuspended) {
        return [];
      }

      if (probes.length > 0 && !this.isConnected) {
        log('First probe detected. Lazily connecting to V8 inspector...');
        await this.connect();
      }
      return this.applyProbes(probes);
    });
  }

  public async suspend() {
    return this.queueOp(async () => {
      if (this.isSuspended) return;
      this.isSuspended = true;
      log('Safety Shield: Suspending instrumentation (detaching breakpoints)');
      for (const bpId of this.activeProbes.keys()) {
        await this.removeBreakpoint(bpId);
      }
      this.activeProbes.clear();
      this.activeLocations.clear();
    });
  }

  public async resume() {
    return this.queueOp(async () => {
      if (!this.isSuspended) return;
      this.isSuspended = false;
      log('Safety Shield: Resuming instrumentation');
      if (this.currentProbes.length > 0 && !this.isConnected) {
        log(
          'First probe detected on resume. Lazily connecting to V8 inspector...',
        );
        await this.connect();
      }
      await this.applyProbes(this.currentProbes);
    });
  }

  private async queueOp<T>(op: () => Promise<T>): Promise<T> {
    const nextOp = this.pendingOp.then(op).catch((err) => {
      log('Error in queued inspector operation: %O', err);
      throw err;
    });
    this.pendingOp = nextOp.catch(() => {}); // Don't let failure block subsequent ops
    return nextOp;
  }

  private getAppScripts(): Map<string, string> {
    if (
      this.appScriptsCache &&
      this.appScriptsCache.size === this.scriptIdToUrl.size
    ) {
      return this.appScriptsCache.map;
    }
    const appScripts = new Map<string, string>();
    for (const scriptUrl of this.scriptIdToUrl.values()) {
      if (scriptUrl.startsWith('file://')) {
        try {
          const rawPath = fileURLToPath(scriptUrl);
          const posixPath = normalizePathForComparison(rawPath);
          const normalizedLower = posixPath.toLowerCase();
          if (!normalizedLower.includes('/node_modules/')) {
            const isWindows =
              process.platform === 'win32' ||
              /^[\\/]?[a-zA-Z]:/.test(posixPath);
            const key = isWindows ? normalizedLower : posixPath;
            appScripts.set(key, rawPath);
          }
        } catch {
          // Ignore invalid URLs
        }
      }
    }
    this.appScriptsCache = { size: this.scriptIdToUrl.size, map: appScripts };
    return appScripts;
  }

  private async resolveDynamicSuffix(runtimeLocation: string): Promise<string> {
    if (this.pathCache.has(runtimeLocation)) {
      return this.pathCache.get(runtimeLocation)!;
    }

    const normalizedTarget = path.posix
      .normalize(runtimeLocation.replace(/\\/g, '/'))
      .replace(/^[\\/]?[a-zA-Z]:[/]+/, '')
      .replace(/^(\.\.?(\/|$))+/, '')
      .replace(/^\/+/, '');

    const cwd = process.cwd();
    if (!normalizedTarget) {
      return path.resolve(cwd, runtimeLocation);
    }

    // 1. Gather all non-node_modules application scripts parsed in V8
    const appScripts = this.getAppScripts();

    // 2. Exact match for full normalizedTarget (e.g. .../dist/services/posts/main.js ends with /services/posts/main.js)
    const exactMatches: string[] = [];
    const isWindowsEnv =
      process.platform === 'win32' ||
      /^[\\/]?[a-zA-Z]:/.test(runtimeLocation) ||
      /^[\\/]?[a-zA-Z]:/.test(cwd) ||
      Boolean(this.appRoot && /^[\\/]?[a-zA-Z]:/.test(this.appRoot));

    const targetPosix = isWindowsEnv
      ? normalizedTarget.toLowerCase()
      : normalizedTarget;
    const targetSuffix = `/${targetPosix}`;

    for (const [posixPath, rawPath] of appScripts.entries()) {
      const scriptMatch = isWindowsEnv ? posixPath.toLowerCase() : posixPath;
      if (scriptMatch.endsWith(targetSuffix)) {
        exactMatches.push(rawPath);
      }
    }
    if (exactMatches.length === 1) {
      this.pathCache.set(runtimeLocation, exactMatches[0]);
      return exactMatches[0];
    }
    if (exactMatches.length > 1) {
      log(
        'Ambiguous exact match for %s matched %d scripts; falling back',
        normalizedTarget,
        exactMatches.length,
      );
    }

    const normCwd = normalizePathForComparison(cwd);
    const isWindowsCwd =
      process.platform === 'win32' || /^[\\/]?[a-zA-Z]:/.test(normCwd);
    const normalizedCwd = isWindowsCwd ? normCwd.toLowerCase() : normCwd;

    // 3. Exact path check on filesystem against cwd
    const fullAttempt = path.resolve(cwd, normalizedTarget);
    try {
      await fs.promises.access(fullAttempt);
      this.pathCache.set(runtimeLocation, fullAttempt);
      return fullAttempt;
    } catch {
      // Continue to suffix matching
    }

    // Direct appRoot-relative check for container deployments
    const normAppRoot = this.appRoot
      ? path.posix
          .normalize(this.appRoot.replace(/\\/g, '/'))
          .replace(/^[\\/]?[a-zA-Z]:[/]+/, '')
          .replace(/^(\.\.?(\/|$))+/, '')
          .replace(/^\/+/, '')
          .replace(/\/+$/, '')
      : '';

    const rootCheck = isWindowsEnv ? normAppRoot.toLowerCase() : normAppRoot;
    const targetCheck = isWindowsEnv ? targetPosix : normalizedTarget;

    if (rootCheck && targetCheck.startsWith(`${rootCheck}/`)) {
      const relToAppRoot = normalizedTarget.slice(normAppRoot.length + 1);
      const candidate = path.posix.join(normalizedCwd, relToAppRoot);
      const key = isWindowsCwd ? candidate.toLowerCase() : candidate;
      const match = appScripts.get(key);
      if (match) {
        this.pathCache.set(runtimeLocation, match);
        return match;
      }

      // Target is explicitly scoped to appRoot; return resolution against cwd without degrading into unrelated files
      return path.resolve(cwd, relToAppRoot);
    }

    // Probe locations can be logical paths with a leading slash, so prefer
    // loaded V8 script and appRoot matches before an absolute filesystem path.
    if (path.isAbsolute(runtimeLocation)) {
      try {
        await fs.promises.access(runtimeLocation);
        this.pathCache.set(runtimeLocation, runtimeLocation);
        return runtimeLocation;
      } catch {
        // Continue to suffix lookup
      }
    }

    const parts = normalizedTarget.split('/').filter(Boolean);

    // 4. Progressive suffix check against loaded V8 scripts for container subfolders
    // Note: Active for targets with 3+ segments (e.g. services/posts/routes/checkout.js).
    // Bare root entrypoints (e.g. /app/main.js) require appRoot to resolve to prevent nested route collisions.
    for (let i = 1; i < parts.length - 1; i++) {
      const degradedSuffix = parts.slice(i).join('/');
      const candidate = path.posix.join(normalizedCwd, degradedSuffix);
      const key = isWindowsCwd ? candidate.toLowerCase() : candidate;
      const match = appScripts.get(key);
      if (match) {
        // Do NOT cache degraded suffix match so lazily loaded modules can bind to live V8 script URL on later syncs
        return match;
      }
    }

    // 5. Progressively check suffixes against cwd on filesystem (do NOT cache so lazily loaded V8 modules can resolve later)
    // Note: Active for targets with 3+ segments; multi-segment targets are protected from bare root filename degradation.
    for (let i = 1; i < parts.length - 1; i++) {
      const suffix = parts.slice(i).join('/');
      const attempt = path.resolve(cwd, suffix);
      try {
        await fs.promises.access(attempt);
        return attempt;
      } catch {
        // Doesn't exist, try next
      }
    }

    // 6. Fallback: resolve against cwd directly (do NOT cache so lazily loaded modules can resolve once parsed)
    return path.resolve(cwd, normalizedTarget);
  }

  private async applyProbes(probes: Probe[]): Promise<string[]> {
    log('Applying %d probes...', probes.length);
    this.probeMap.clear();

    const failedProbes: string[] = [];
    const locationToContexts = new Map<string, ActiveProbeContext[]>();

    for (const probe of probes) {
      this.probeMap.set(probe.id, probe);

      try {
        log(
          'Processing desired state for probe %s at %s:%d',
          probe.id,
          probe.runtimeLocation,
          probe.runtimeLine,
        );
        // 1. Primary Breakpoint
        let url = probe.runtimeLocation;
        if (!url.startsWith('meteor://')) {
          const resolvedPrimary = await this.resolveDynamicSuffix(
            probe.runtimeLocation,
          );
          url = pathToFileURL(resolvedPrimary).href;
        }

        const primaryKey = JSON.stringify({
          url,
          line: probe.runtimeLine,
          col: probe.runtimeColumn || 0,
        });

        const contexts = locationToContexts.get(primaryKey) || [];
        contexts.push({ probe, isSecondary: false });
        locationToContexts.set(primaryKey, contexts);

        // 2. Secondary Breakpoint for Durations
        if (
          probe.type === ProbeType.PROBE_TYPE_DURATION &&
          probe.secondaryRuntimeLine
        ) {
          let sUrl = probe.secondaryRuntimeLocation || probe.runtimeLocation;
          if (!sUrl.startsWith('meteor://')) {
            const resolvedSecondary = await this.resolveDynamicSuffix(
              probe.secondaryRuntimeLocation || probe.runtimeLocation,
            );
            sUrl = pathToFileURL(resolvedSecondary).href;
          }

          const secondaryKey = JSON.stringify({
            url: sUrl,
            line: probe.secondaryRuntimeLine,
            col: probe.secondaryRuntimeColumn || 0,
          });

          const sContexts = locationToContexts.get(secondaryKey) || [];
          sContexts.push({ probe, isSecondary: true });
          locationToContexts.set(secondaryKey, sContexts);
        }
      } catch (err) {
        log('Failed to parse probe %s location: %O', probe.id, err);
        failedProbes.push(probe.id);
      }
    }

    // 1. Remove stale locations that are no longer in desired state
    for (const [
      activeLocationKey,
      activeState,
    ] of this.activeLocations.entries()) {
      if (!locationToContexts.has(activeLocationKey)) {
        await this.removeBreakpoint(activeState.breakpointId);
        this.activeLocations.delete(activeLocationKey);
        this.activeProbes.delete(activeState.breakpointId);
      }
    }

    // 2. Set or update new locations
    for (const [locationKey, contexts] of locationToContexts.entries()) {
      // Sort contexts deterministically by probe ID and secondary status to guarantee stable condition script output
      contexts.sort((a, b) => {
        if (a.probe.id !== b.probe.id) {
          return a.probe.id.localeCompare(b.probe.id);
        }
        return (a.isSecondary ? 1 : 0) - (b.isSecondary ? 1 : 0);
      });

      const { url, line, col } = JSON.parse(locationKey);
      const conditionScript = this.generateInlineConditionScript(contexts);

      const currentState = this.activeLocations.get(locationKey);

      // If already active with the exact same script, skip V8 modification!
      if (currentState && currentState.script === conditionScript) {
        // Just update contexts mapping to ensure handles point to the new Probe references
        this.activeProbes.set(currentState.breakpointId, contexts);
        continue;
      }

      // If exists but script changed, remove the old one first
      if (currentState && currentState.script !== conditionScript) {
        await this.removeBreakpoint(currentState.breakpointId);
        this.activeLocations.delete(locationKey);
        this.activeProbes.delete(currentState.breakpointId);
      }

      try {
        const res = await this.setBreakpointByUrl(
          url,
          line - 1,
          col > 0 ? col - 1 : 0,
          conditionScript,
        );
        const bpId = res.breakpointId;
        if (bpId) {
          log('Breakpoint set with ID %s', bpId);
          this.activeLocations.set(locationKey, {
            breakpointId: bpId,
            script: conditionScript,
          });
          this.activeProbes.set(bpId, contexts);
        } else {
          for (const ctx of contexts) failedProbes.push(ctx.probe.id);
        }
      } catch (err) {
        log('Failed to set breakpoint at %s: %O', locationKey, err);
        for (const ctx of contexts) failedProbes.push(ctx.probe.id);
      }
    }

    return failedProbes;
  }

  private generateInlineConditionScript(
    contexts: ActiveProbeContext[],
  ): string {
    const parts: string[] = [];
    parts.push(`(() => {`);
    parts.push(`  let _pause = false; let _corr = null;`);

    for (const { probe, isSecondary } of contexts) {
      const uCond = probe.condition || 'true';

      parts.push(`  try {`);
      parts.push(`    if (${uCond}) {`);

      if (probe.type === ProbeType.PROBE_TYPE_SNAPSHOT) {
        parts.push(`      _pause = true;`);
      } else if (probe.type === ProbeType.PROBE_TYPE_COUNTER) {
        parts.push(
          `      global.${this.inlineNamespaceId}.emitCounter("${probe.id}");`,
        );
      } else if (probe.type === ProbeType.PROBE_TYPE_METRIC) {
        if (probe.metricExpression) {
          parts.push(
            `      global.${this.inlineNamespaceId}.emitMetric("${probe.id}", ${probe.metricExpression});`,
          );
        }
      } else if (probe.type === ProbeType.PROBE_TYPE_LOG) {
        if (probe.template) {
          const expr = prepareLogTemplate(probe.template);
          parts.push(
            `      global.${this.inlineNamespaceId}.emitLog("${probe.id}", ${expr});`,
          );
        }
      } else if (probe.type === ProbeType.PROBE_TYPE_DURATION) {
        if (probe.correlationExpression) {
          parts.push(
            `      try { _corr = ${probe.correlationExpression}; } catch(e) { _corr = "Error: " + e.message; }`,
          );
        } else {
          parts.push(`      _corr = "static-singleton";`);
        }

        if (!isSecondary) {
          parts.push(
            `      global.${this.inlineNamespaceId}.startDuration("${probe.id}", _corr);`,
          );
        } else {
          parts.push(
            `      global.${this.inlineNamespaceId}.endDuration("${probe.id}", _corr);`,
          );
        }
      }

      parts.push(`    }`);
      parts.push(`  } catch(e) {`);
      if (probe.type !== ProbeType.PROBE_TYPE_SNAPSHOT) {
        parts.push(
          `    global.${this.inlineNamespaceId}.emitError("${probe.id}", e.message);`,
        );
      }
      parts.push(`  }`);
    }

    parts.push(`  return _pause;`);
    parts.push(`})()`);

    return parts.join('\n');
  }

  private async removeBreakpoint(breakpointId: string): Promise<void> {
    if (!this.isConnected || !this.session) return;
    return new Promise((resolve) => {
      try {
        this.session!.post('Debugger.removeBreakpoint', { breakpointId }, () =>
          resolve(),
        );
      } catch (err) {
        log('Failed to post removeBreakpoint: %O', err);
        resolve();
      }
    });
  }

  private async setBreakpointByUrl(
    url: string,
    lineNumber: number,
    columnNumber: number = 0,
    condition?: string,
  ): Promise<{ breakpointId: string; locations: any[] }> {
    if (!this.session) {
      throw new Error('V8 Inspector session is not initialized');
    }
    return new Promise((resolve, reject) => {
      try {
        this.session!.post(
          'Debugger.setBreakpointByUrl',
          {
            url,
            lineNumber,
            columnNumber,
            condition,
          },
          (err, result) => {
            if (err) return reject(err);
            resolve({
              breakpointId: result.breakpointId,
              locations: result.locations || [],
            });
          },
        );
      } catch (err) {
        reject(err);
      }
    });
  }

  private getSerializationScript() {
    return getSerializationScript();
  }

  private async evaluateExpressionsRaw(
    session: inspector.Session,
    callFrameId: string,
    expressions: string[],
  ): Promise<Map<string, inspector.Runtime.RemoteObject>> {
    const results = new Map<string, inspector.Runtime.RemoteObject>();
    if (!expressions || expressions.length === 0) return results;

    const combinedExpr = wrapExpressionsForEvaluation(expressions);

    return new Promise((resolve) => {
      session.post(
        'Debugger.evaluateOnCallFrame',
        {
          callFrameId,
          expression: combinedExpr,
          throwOnSideEffect: true,
          returnByValue: false,
          objectGroup: EVAL_OBJECT_GROUP,
        },
        (err, result) => {
          if (
            err ||
            !result ||
            !result.result ||
            result.result.type !== 'object'
          ) {
            return resolve(results);
          }

          const rootObjectId = result.result.objectId;
          if (!rootObjectId) return resolve(results);

          try {
            session.post(
              'Runtime.getProperties',
              {
                objectId: rootObjectId,
                ownProperties: true,
              },
              (err2, result2) => {
                try {
                  session.post('Runtime.releaseObject', {
                    objectId: rootObjectId,
                  });
                } catch (errRelease) {
                  log('Failed to post Runtime.releaseObject: %O', errRelease);
                }

                if (err2 || !result2 || !result2.result)
                  return resolve(results);

                for (const prop of result2.result) {
                  if (prop.value) {
                    results.set(prop.name, prop.value);
                  }
                }
                resolve(results);
              },
            );
          } catch (errProperties) {
            log('Failed to post Runtime.getProperties: %O', errProperties);
            resolve(results);
          }
        },
      );
    });
  }

  private buildCallArgument(
    obj: inspector.Runtime.RemoteObject,
  ): inspector.Runtime.CallArgument {
    if (obj.objectId) {
      return { objectId: obj.objectId };
    } else if (
      Object.hasOwn(obj, 'unserializableValue') &&
      obj.unserializableValue != null
    ) {
      // Handle values like NaN, Infinity, -0, BigInt, etc.
      return { unserializableValue: obj.unserializableValue as any };
    } else if (obj.type === 'undefined') {
      // According to CDP spec, an empty CallArgument represents undefined
      return {};
    } else if (obj.value !== undefined) {
      // Normal JSON-serializable primitive
      return { value: obj.value };
    } else if (obj.description !== undefined) {
      // Fallback: pass the description string (e.g. for Map/Set summaries)
      return { value: obj.description };
    } else {
      // Last-resort fallback to undefined (empty object in CDP)
      return {};
    }
  }

  private async captureAtomicSnapshot(
    session: inspector.Session,
    objectId: string,
    watches: Map<string, inspector.Runtime.RemoteObject>,
    frames: inspector.Debugger.CallFrame[],
    stackDepth: number,
    config: any,
  ): Promise<any> {
    const script = this.getSerializationScript();

    const limitedFrames = frames.slice(0, stackDepth);
    const captureClosures = config.captureClosures ?? false;

    const frameScopes = limitedFrames.map((f) =>
      f.scopeChain
        .map((s, idx) => ({ type: s.type, index: idx, object: s.object }))
        .filter((s) => {
          if (s.type === 'global' || s.type === 'module') return false;
          if (!captureClosures && s.type === 'closure') return false;
          return true;
        }),
    );

    const manifest = {
      config,
      watchKeys: Array.from(watches.keys()),
      frameScopes: frameScopes.map((f) =>
        f.map((s) => ({ type: s.type, index: s.index })),
      ),
    };

    const args: inspector.Runtime.CallArgument[] = [{ value: manifest }];

    for (const key of manifest.watchKeys) {
      args.push(this.buildCallArgument(watches.get(key)!));
    }

    for (const frame of frameScopes) {
      for (const scope of frame) {
        args.push(this.buildCallArgument(scope.object));
      }
    }

    return new Promise((resolve) => {
      session.post(
        'Runtime.callFunctionOn',
        {
          objectId,
          functionDeclaration: script,
          arguments: args,
          returnByValue: true,
          silent: true,
        },
        (err, result) => {
          if (err || !result || !result.result) {
            log('Atomic capture error: %O', err);
            return resolve({
              watch: {},
              vars: [],
              error: err?.message || 'Capture failed',
            });
          }
          resolve(result.result.value);
        },
      );
    });
  }

  private safeStringify(obj: any): string {
    return JSON.stringify(obj, (_, v) =>
      typeof v === 'bigint' ? `${v.toString()}n` : v,
    );
  }

  private async handlePaused(session: inspector.Session, message: any) {
    const params = message.params || message;
    const { callFrames, hitBreakpoints, asyncStackTrace } = params;

    if (
      !callFrames ||
      callFrames.length === 0 ||
      !hitBreakpoints ||
      hitBreakpoints.length === 0
    ) {
      return;
    }

    const allContexts: ActiveProbeContext[] = [];
    for (const bpId of hitBreakpoints) {
      const contexts = this.activeProbes.get(bpId);
      if (contexts) {
        allContexts.push(...contexts);
      }
    }

    if (allContexts.length === 0) {
      return;
    }

    const topFrame = callFrames[0];

    try {
      for (const { probe } of allContexts) {
        if (probe.type !== ProbeType.PROBE_TYPE_SNAPSHOT) {
          continue; // Handled synchronously by inline script
        }

        const maxDepth =
          probe.maxObjectDepth ?? this.globalConfig.maxObjectDepth ?? 3;
        const maxArrayLength =
          probe.maxArrayLength ?? this.globalConfig.maxArrayLength ?? 3;
        const stackDepth =
          probe.stackFrameDepth ?? this.globalConfig.stackFrameDepth ?? 3;
        const maxObjectProperties =
          probe.maxObjectProperties ??
          this.globalConfig.maxObjectProperties ??
          50;
        const maxStringLength =
          probe.maxStringLength ?? this.globalConfig.maxStringLength ?? 1024;
        const captureClosures =
          probe.captureClosures ?? this.globalConfig.captureClosures ?? false;

        const config = {
          maxDepth,
          maxArrayLength,
          maxObjectProperties,
          maxStringLength,
          redactKeys: this.globalConfig.redactKeys,
          redactValues: this.globalConfig.redactValues,
          captureClosures,
        };

        if (!this.quotaManager.canEvaluate()) {
          this.totalSkips++;
          continue;
        }

        const event: TelemetryEvent = {
          probeId: probe.id,
          traceId: this.getTraceId(probe.id),
          timestampMs: BigInt(Date.now()),
          stackFrames: [],
          capturedVarsJson: '',
          watchResultsJson: '',
          evaluatedLog: '',
          metricValue: 0,
          captureError: '',
        };

        try {
          const localObjectId = topFrame.scopeChain[0]?.object?.objectId;
          if (!localObjectId) {
            event.captureError =
              'Unable to perform snapshot: Local scope object ID missing';
          } else {
            // Priority: Evaluate watches first
            const watchResultsRaw = await this.evaluateExpressionsRaw(
              session,
              topFrame.callFrameId,
              probe.watchExpressions || [],
            );

            // Perform atomic capture
            const atomicResult = await this.captureAtomicSnapshot(
              session,
              localObjectId,
              watchResultsRaw,
              callFrames,
              stackDepth,
              config,
            );

            event.watchResultsJson = this.safeStringify(atomicResult.watch);
            event.capturedVarsJson = this.safeStringify(atomicResult.vars);
          }

          // Populate stack frame metadata
          const framesProcessed = Math.min(callFrames.length, stackDepth);
          for (let i = 0; i < framesProcessed; i++) {
            const frame = callFrames[i];
            const url = this.scriptIdToUrl.get(frame.location.scriptId);
            event.stackFrames.push({
              functionName: frame.functionName || '(anonymous)',
              fileName: url || 'unknown',
              lineNumber: frame.location.lineNumber + 1,
              columnNumber: frame.location.columnNumber || 0,
            });
          }

          let currentAsyncTrace = asyncStackTrace;
          while (currentAsyncTrace && event.stackFrames.length < stackDepth) {
            if (currentAsyncTrace.callFrames) {
              for (
                let i = 0;
                i < currentAsyncTrace.callFrames.length &&
                event.stackFrames.length < stackDepth;
                i++
              ) {
                const frame = currentAsyncTrace.callFrames[i];
                event.stackFrames.push({
                  functionName: frame.functionName || '(anonymous)',
                  fileName:
                    frame.url ||
                    this.scriptIdToUrl.get(frame.scriptId) ||
                    'unknown',
                  lineNumber: frame.lineNumber + 1,
                  columnNumber: frame.columnNumber || 0,
                });
              }
            }
            currentAsyncTrace = currentAsyncTrace.parent;
          }

          const payloadSize = this.getSerializedSize(event);
          if (!this.quotaManager.canSend(payloadSize)) {
            this.totalSkips++;
            continue;
          }

          this.totalHits++;
          this.onTelemetryCapture(event);
        } catch (err: any) {
          event.captureError = err.message;

          const payloadSize = this.getSerializedSize(event);
          if (!this.quotaManager.canSend(payloadSize)) {
            this.totalSkips++;
            continue;
          }

          this.totalHits++;
          this.onTelemetryCapture(event);
        }
      }
    } catch (err: any) {
      log('Error in handlePaused loop: %O', err);
    }
  }

  public getStats() {
    const stats = { hits: this.totalHits, skips: this.totalSkips };
    this.totalHits = 0;
    this.totalSkips = 0;
    return stats;
  }

  private makeSafeRegex(
    patterns: string[],
    flags: string = 'gi',
  ): RegExp | null {
    if (!patterns || patterns.length === 0) return null;
    try {
      return new RegExp(patterns.map((p) => `(?:${p})`).join('|'), flags);
    } catch (e) {
      log('Invalid redaction patterns: %O', e);
      return null;
    }
  }

  private getSerializedSize(event: TelemetryEvent): number {
    return this.safeStringify(event).length;
  }
}
