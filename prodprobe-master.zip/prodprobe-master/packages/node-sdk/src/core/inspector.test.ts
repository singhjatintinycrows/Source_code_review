import * as fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { describe, expect, it, vi } from 'vitest';
import { InspectorEngine as InspectorEngineImpl } from './inspector.js';
import type { QuotaManager } from './quota.js';

interface InspectorEngineTestAccess {
  registerScriptUrl(scriptId: string, url: string): void;
  resolveDynamicSuffix(runtimeLocation: string): Promise<string>;
  pathCache: Map<string, string>;
  scriptIdToUrl: Map<string, string>;
  appScriptsCache?: { size: number; map: Map<string, string> };
}

type InspectorEngine = Omit<
  InspectorEngineImpl,
  keyof InspectorEngineTestAccess
> &
  InspectorEngineTestAccess;

const InspectorEngine = InspectorEngineImpl as unknown as new (
  ...args: ConstructorParameters<typeof InspectorEngineImpl>
) => InspectorEngine;

describe('InspectorEngine.resolveDynamicSuffix', () => {
  const mockQuotaManager = {} as QuotaManager;
  const mockPause = vi.fn();
  const mockTelemetry = vi.fn();

  it('matches exact suffix in active V8 scripts when compiled to a nested output directory', async () => {
    const inspector = new InspectorEngine(
      mockQuotaManager,
      mockPause,
      mockTelemetry,
    );

    // Simulated active script in V8 memory (e.g. Nx local monorepo dist output)
    const runningPath = path.resolve('/workspace/dist/services/posts/main.js');
    const runningUrl = pathToFileURL(runningPath).href;
    inspector.registerScriptUrl('1', runningUrl);

    // Runtime location sent from backend without dist/ prefix
    const resolved = await inspector.resolveDynamicSuffix(
      'services/posts/main.js',
    );

    expect(resolved).toBe(runningPath);
  });

  it('matches suffix when running in a flattened container environment', async () => {
    const inspector = new InspectorEngine(
      mockQuotaManager,
      mockPause,
      mockTelemetry,
      undefined,
      'services/posts',
    );

    // Flattened container where cwd is /app and files are directly in /app
    const cwdSpy = vi.spyOn(process, 'cwd').mockReturnValue('/app');
    try {
      const runningPath = path.resolve('/app/main.js');
      const runningUrl = pathToFileURL(runningPath).href;
      inspector.registerScriptUrl('2', runningUrl);

      const resolved = await inspector.resolveDynamicSuffix(
        'services/posts/main.js',
      );

      expect(resolved).toBe(runningPath);
    } finally {
      cwdSpy.mockRestore();
    }
  });

  it('caches the resolved path for subsequent lookups', async () => {
    const inspector = new InspectorEngine(
      mockQuotaManager,
      mockPause,
      mockTelemetry,
    );

    const runningPath = path.resolve('/workspace/build/handler.js');
    const runningUrl = pathToFileURL(runningPath).href;
    inspector.registerScriptUrl('3', runningUrl);

    const first = await inspector.resolveDynamicSuffix('handler.js');
    expect(first).toBe(runningPath);
    expect(inspector['pathCache'].get('handler.js')).toBe(runningPath);

    // Clear registered scripts to verify subsequent lookup is served from cache
    inspector['scriptIdToUrl'].clear();
    const second = await inspector.resolveDynamicSuffix('handler.js');
    expect(second).toBe(runningPath);
  });

  it('caches successful appRoot container resolutions', async () => {
    const inspector = new InspectorEngine(
      mockQuotaManager,
      mockPause,
      mockTelemetry,
      undefined,
      'services/posts',
    );

    const cwdSpy = vi.spyOn(process, 'cwd').mockReturnValue('/app');
    try {
      const runningPath = path.resolve('/app/main.js');
      inspector.registerScriptUrl('20', pathToFileURL(runningPath).href);

      const resolved = await inspector.resolveDynamicSuffix(
        'services/posts/main.js',
      );
      expect(resolved).toBe(runningPath);
      expect(inspector['pathCache'].get('services/posts/main.js')).toBe(
        runningPath,
      );

      inspector['scriptIdToUrl'].clear();
      const second = await inspector.resolveDynamicSuffix(
        'services/posts/main.js',
      );
      expect(second).toBe(runningPath);
    } finally {
      cwdSpy.mockRestore();
    }
  });

  it('handles targets with leading slashes and dot-segments', async () => {
    const inspector = new InspectorEngine(
      mockQuotaManager,
      mockPause,
      mockTelemetry,
    );

    const runningPath = path.resolve('/workspace/dist/services/posts/main.js');
    const runningUrl = pathToFileURL(runningPath).href;
    inspector.registerScriptUrl('4', runningUrl);

    // Target with leading slash and dot segment
    const resolved = await inspector.resolveDynamicSuffix(
      './services/posts/main.js',
    );
    expect(resolved).toBe(runningPath);

    const resolvedSlash = await inspector.resolveDynamicSuffix(
      '/services/posts/main.js',
    );
    expect(resolvedSlash).toBe(runningPath);

    const resolvedParent = await inspector.resolveDynamicSuffix(
      '../../services/posts/main.js',
    );
    expect(resolvedParent).toBe(runningPath);
  });

  it('prefers a loaded V8 script over a colliding absolute logical path', async () => {
    const inspector = new InspectorEngine(
      mockQuotaManager,
      mockPause,
      mockTelemetry,
      undefined,
      'services/posts',
    );

    const cwdSpy = vi.spyOn(process, 'cwd').mockReturnValue('/app');
    const accessSpy = vi
      .spyOn(fs.promises, 'access')
      .mockImplementation(async (target) => {
        if (target === '/services/posts/main.js') return;
        throw new Error('File not found');
      });
    try {
      const runningPath = path.resolve('/app/main.js');
      inspector.registerScriptUrl('collision', pathToFileURL(runningPath).href);

      const resolved = await inspector.resolveDynamicSuffix(
        '/services/posts/main.js',
      );

      expect(resolved).toBe(runningPath);
      expect(accessSpy).not.toHaveBeenCalledWith('/services/posts/main.js');
    } finally {
      accessSpy.mockRestore();
      cwdSpy.mockRestore();
    }
  });

  it('ignores scripts loaded from node_modules even if filenames match', async () => {
    const inspector = new InspectorEngine(
      mockQuotaManager,
      mockPause,
      mockTelemetry,
    );

    // Dependency script in node_modules
    const depPath = path.resolve('/app/node_modules/express/main.js');
    inspector.registerScriptUrl('5', pathToFileURL(depPath).href);

    // Target not in cwd, should fall back rather than matching node_modules
    const resolved = await inspector.resolveDynamicSuffix(
      'services/posts/main.js',
    );
    expect(resolved).not.toBe(depPath);
    expect(resolved).toBe(
      path.resolve(process.cwd(), 'services/posts/main.js'),
    );
  });

  it('rejects degraded suffixes for scripts outside cwd and falls back to filesystem', async () => {
    const inspector = new InspectorEngine(
      mockQuotaManager,
      mockPause,
      mockTelemetry,
    );

    // Two different services with main.js loaded in V8 (outside cwd)
    const postsPath = path.resolve('/workspace/dist/services/posts/main.js');
    const usersPath = path.resolve('/workspace/dist/services/users/main.js');
    inspector.registerScriptUrl('6', pathToFileURL(postsPath).href);
    inspector.registerScriptUrl('7', pathToFileURL(usersPath).href);

    // Target from a third unknown service; scripts outside cwd must not be matched via degraded suffix
    const ambiguousTarget = 'services/auth/main.js';
    const resolved = await inspector.resolveDynamicSuffix(ambiguousTarget);

    // Must NOT arbitrarily pick postsPath or usersPath
    expect(resolved).not.toBe(postsPath);
    expect(resolved).not.toBe(usersPath);
    expect(resolved).toBe(path.resolve(process.cwd(), ambiguousTarget));
  });

  it('does not trigger false ambiguity when duplicate script URLs are registered in V8', async () => {
    const inspector = new InspectorEngine(
      mockQuotaManager,
      mockPause,
      mockTelemetry,
    );

    const runningPath = path.resolve('/workspace/dist/services/posts/main.js');
    const runningUrl = pathToFileURL(runningPath).href;

    // Same URL registered under multiple V8 script IDs (e.g. vm contexts or multiple evaluations)
    inspector.registerScriptUrl('8', runningUrl);
    inspector.registerScriptUrl('9', runningUrl);

    const resolved = await inspector.resolveDynamicSuffix(
      'services/posts/main.js',
    );
    expect(resolved).toBe(runningPath);
  });

  it('does not cache negative fallback, allowing lazily loaded modules to resolve when parsed later', async () => {
    const inspector = new InspectorEngine(
      mockQuotaManager,
      mockPause,
      mockTelemetry,
    );

    const target = 'services/lazy/route.js';

    // 1. Initial lookup before module is loaded by Node
    const initial = await inspector.resolveDynamicSuffix(target);
    expect(initial).toBe(path.resolve(process.cwd(), target));

    // 2. Node later lazily loads the module
    const runningPath = path.resolve('/workspace/dist/services/lazy/route.js');
    inspector.registerScriptUrl('10', pathToFileURL(runningPath).href);

    // 3. Subsequent probe sync should resolve to the newly loaded script (not stale negative cache)
    const subsequent = await inspector.resolveDynamicSuffix(target);
    expect(subsequent).toBe(runningPath);
  });

  it('does not falsely match a sibling service with the same filename when target module is not yet parsed', async () => {
    const inspector = new InspectorEngine(
      mockQuotaManager,
      mockPause,
      mockTelemetry,
    );

    // Only billing/checkout.js is currently loaded
    const billingPath = path.resolve(
      '/workspace/dist/services/billing/checkout.js',
    );
    inspector.registerScriptUrl('11', pathToFileURL(billingPath).href);

    // Target is cart/checkout.js (not yet loaded)
    const cartTarget = 'services/cart/checkout.js';
    const resolved = await inspector.resolveDynamicSuffix(cartTarget);

    // Must NOT falsely bind to billing/checkout.js
    expect(resolved).not.toBe(billingPath);
    expect(resolved).toBe(path.resolve(process.cwd(), cartTarget));
  });

  it('does not falsely match a sibling service with multi-segment shared suffix when target module is not yet parsed', async () => {
    const inspector = new InspectorEngine(
      mockQuotaManager,
      mockPause,
      mockTelemetry,
    );

    // Only billing/routes/checkout.js is currently loaded
    const billingPath = path.resolve(
      '/workspace/dist/services/billing/routes/checkout.js',
    );
    inspector.registerScriptUrl('21', pathToFileURL(billingPath).href);

    // Target is cart/routes/checkout.js (multi-segment shared suffix /routes/checkout.js)
    const cartTarget = 'services/cart/routes/checkout.js';
    const resolved = await inspector.resolveDynamicSuffix(cartTarget);

    // Must NOT falsely bind to billing/routes/checkout.js
    expect(resolved).not.toBe(billingPath);
    expect(resolved).toBe(path.resolve(process.cwd(), cartTarget));
  });

  it('matches multi-segment suffix in flattened container environment relative to cwd', async () => {
    const inspector = new InspectorEngine(
      mockQuotaManager,
      mockPause,
      mockTelemetry,
    );

    const cwdSpy = vi.spyOn(process, 'cwd').mockReturnValue('/app');
    try {
      const runningPath = path.resolve('/app/routes/checkout.js');
      inspector.registerScriptUrl('22', pathToFileURL(runningPath).href);

      const resolved = await inspector.resolveDynamicSuffix(
        'services/cart/routes/checkout.js',
      );
      expect(resolved).toBe(runningPath);
    } finally {
      cwdSpy.mockRestore();
    }
  });

  it('normalizes Windows drive letter prefixes in runtime locations', async () => {
    const inspector = new InspectorEngine(
      mockQuotaManager,
      mockPause,
      mockTelemetry,
    );

    const runningPath = path.resolve('/workspace/dist/services/posts/main.js');
    inspector.registerScriptUrl('12', pathToFileURL(runningPath).href);

    const resolved = await inspector.resolveDynamicSuffix(
      'C:\\services\\posts\\main.js',
    );
    expect(resolved).toBe(runningPath);

    const resolvedNested = await inspector.resolveDynamicSuffix(
      'C:\\workspace\\dist\\services\\posts\\main.js',
    );
    expect(resolvedNested).toBe(runningPath);

    const resolvedLeadingSlash = await inspector.resolveDynamicSuffix(
      '/C:/services/posts/main.js',
    );
    expect(resolvedLeadingSlash).toBe(runningPath);
  });

  it('handles empty, dot, or directory-only targets without binding to cwd directory', async () => {
    const inspector = new InspectorEngine(
      mockQuotaManager,
      mockPause,
      mockTelemetry,
    );

    const resolvedEmpty = await inspector.resolveDynamicSuffix('');
    expect(resolvedEmpty).toBe(path.resolve(process.cwd(), ''));

    const resolvedDot = await inspector.resolveDynamicSuffix('.');
    expect(resolvedDot).toBe(path.resolve(process.cwd(), '.'));

    const resolvedDotSlash = await inspector.resolveDynamicSuffix('./');
    expect(resolvedDotSlash).toBe(path.resolve(process.cwd(), './'));
  });

  it('matches scripts in cwd even with mismatched Windows drive letter casing', async () => {
    const inspector = new InspectorEngine(
      mockQuotaManager,
      mockPause,
      mockTelemetry,
      undefined,
      'services/posts',
    );

    // Mock cwd with lowercase drive letter
    const cwdSpy = vi.spyOn(process, 'cwd').mockReturnValue('c:/app');
    try {
      // Running URL in V8 with uppercase drive letter
      const runningUrl = 'file:///C:/app/main.js';
      const runningPath = fileURLToPath(runningUrl);
      inspector.registerScriptUrl('23', runningUrl);

      const resolved = await inspector.resolveDynamicSuffix(
        'services/posts/main.js',
      );
      expect(resolved).toBe(runningPath);
    } finally {
      cwdSpy.mockRestore();
    }
  });

  it('matches scripts in cwd even with mixed-case Windows directory path and drive letter', async () => {
    const inspector = new InspectorEngine(
      mockQuotaManager,
      mockPause,
      mockTelemetry,
      undefined,
      'services/posts',
    );

    // Mock cwd with mixed-case path (e.g. C:\Users\MyUser\App)
    const cwdSpy = vi
      .spyOn(process, 'cwd')
      .mockReturnValue('c:/Users/MyUser/App');
    try {
      // Running URL in V8 with uppercase drive letter and different directory casing
      const runningUrl = 'file:///C:/users/myuser/app/main.js';
      const runningPath = fileURLToPath(runningUrl);
      inspector.registerScriptUrl('24', runningUrl);

      const resolved = await inspector.resolveDynamicSuffix(
        'services/posts/main.js',
      );
      expect(resolved).toBe(runningPath);
    } finally {
      cwdSpy.mockRestore();
    }
  });

  it('falls back to resolving against cwd when script is not in V8 memory, including targets with leading slashes', async () => {
    const inspector = new InspectorEngine(
      mockQuotaManager,
      mockPause,
      mockTelemetry,
    );

    const target = 'nonexistent/file.js';
    const resolved = await inspector.resolveDynamicSuffix(target);
    expect(resolved).toBe(path.resolve(process.cwd(), target));

    const slashTarget = '/nonexistent/file.js';
    const resolvedSlash = await inspector.resolveDynamicSuffix(slashTarget);
    expect(resolvedSlash).toBe(
      path.resolve(process.cwd(), 'nonexistent/file.js'),
    );
  });

  it('does not falsely bind unparsed nested routes to root bare filenames in cwd', async () => {
    const inspector = new InspectorEngine(
      mockQuotaManager,
      mockPause,
      mockTelemetry,
    );

    const cwdSpy = vi.spyOn(process, 'cwd').mockReturnValue('/app');
    try {
      // Server starts with root entrypoint loaded in V8
      const rootPath = path.resolve('/app/index.js');
      inspector.registerScriptUrl('25', pathToFileURL(rootPath).href);

      // Probe arrives for unparsed nested route with the same basename
      const nestedTarget = 'services/users/routes/index.js';
      const resolved = await inspector.resolveDynamicSuffix(nestedTarget);

      // Must NOT falsely match /app/index.js
      expect(resolved).not.toBe(rootPath);
      expect(inspector['pathCache'].has(nestedTarget)).toBe(false);

      // Node subsequently loads the nested route
      const routePath = path.resolve('/app/routes/index.js');
      inspector.registerScriptUrl('26', pathToFileURL(routePath).href);

      // Next sync cycle must resolve to the real route script
      const subsequent = await inspector.resolveDynamicSuffix(nestedTarget);
      expect(subsequent).toBe(routePath);
    } finally {
      cwdSpy.mockRestore();
    }
  });

  it('resolves container paths directly without bare filename degradation when appRoot is configured', async () => {
    const inspector = new InspectorEngine(
      mockQuotaManager,
      mockPause,
      mockTelemetry,
      undefined,
      'services/users',
    );

    const cwdSpy = vi.spyOn(process, 'cwd').mockReturnValue('/app');
    try {
      // Root entrypoint loaded
      const rootPath = path.resolve('/app/index.js');
      inspector.registerScriptUrl('27', pathToFileURL(rootPath).href);

      // Route module unparsed
      const target = 'services/users/routes/index.js';
      const initial = await inspector.resolveDynamicSuffix(target);

      // Scoped to appRoot: does not degrade into root /app/index.js
      expect(initial).not.toBe(rootPath);
      expect(initial).toBe(path.resolve('/app', 'routes/index.js'));
      expect(inspector['pathCache'].has(target)).toBe(false);

      // Route module loaded
      const routePath = path.resolve('/app/routes/index.js');
      inspector.registerScriptUrl('28', pathToFileURL(routePath).href);

      const resolved = await inspector.resolveDynamicSuffix(target);
      expect(resolved).toBe(routePath);
      expect(inspector['pathCache'].get(target)).toBe(routePath);
    } finally {
      cwdSpy.mockRestore();
    }
  });

  it('does not cache degraded filesystem matches in pathCache, allowing V8 binding on later parse', async () => {
    const inspector = new InspectorEngine(
      mockQuotaManager,
      mockPause,
      mockTelemetry,
      undefined,
      'services/posts',
    );

    // Unregistered target in cwd
    const target = 'services/posts/main.js';
    const cwdSpy = vi.spyOn(process, 'cwd').mockReturnValue('/app');
    try {
      // Step 4/5 fallback check before V8 evaluation
      const initial = await inspector.resolveDynamicSuffix(target);
      expect(initial).toBe(path.resolve('/app', 'main.js'));
      // PathCache should not be poisoned for unparsed script
      expect(inspector['pathCache'].has(target)).toBe(false);

      // V8 evaluates script
      const runningPath = path.resolve('/app/main.js');
      inspector.registerScriptUrl('29', pathToFileURL(runningPath).href);

      const subsequent = await inspector.resolveDynamicSuffix(target);
      expect(subsequent).toBe(runningPath);
    } finally {
      cwdSpy.mockRestore();
    }
  });

  it('performs strict case-sensitive matching on POSIX systems', async () => {
    const inspector = new InspectorEngine(
      mockQuotaManager,
      mockPause,
      mockTelemetry,
    );

    const tokenPath = path.resolve('/workspace/dist/services/posts/token.js');
    inspector.registerScriptUrl('30', pathToFileURL(tokenPath).href);

    // Exact case match succeeds
    const exact = await inspector.resolveDynamicSuffix(
      'services/posts/token.js',
    );
    expect(exact).toBe(tokenPath);

    // Different case should not match on POSIX
    if (process.platform !== 'win32') {
      const mismatched = await inspector.resolveDynamicSuffix(
        'services/posts/Token.js',
      );
      expect(mismatched).not.toBe(tokenPath);
    }
  });

  it('does not falsely bind unparsed 2-segment routes to root bare filenames in cwd', async () => {
    const inspector = new InspectorEngine(
      mockQuotaManager,
      mockPause,
      mockTelemetry,
    );

    const cwdSpy = vi.spyOn(process, 'cwd').mockReturnValue('/app');
    try {
      // Server starts with root entrypoint loaded in V8
      const rootPath = path.resolve('/app/index.js');
      inspector.registerScriptUrl('31', pathToFileURL(rootPath).href);

      // Probe arrives for unparsed 2-segment route (routes/index.js)
      const routeTarget = 'routes/index.js';
      const resolved = await inspector.resolveDynamicSuffix(routeTarget);

      // Must NOT falsely match /app/index.js
      expect(resolved).not.toBe(rootPath);
      expect(inspector['pathCache'].has(routeTarget)).toBe(false);

      // Node subsequently loads the route
      const routePath = path.resolve('/app/routes/index.js');
      inspector.registerScriptUrl('32', pathToFileURL(routePath).href);

      // Next sync cycle must resolve to the real route script
      const subsequent = await inspector.resolveDynamicSuffix(routeTarget);
      expect(subsequent).toBe(routePath);
    } finally {
      cwdSpy.mockRestore();
    }
  });

  it('does not cache degraded Step 4 suffix matches in pathCache', async () => {
    const inspector = new InspectorEngine(
      mockQuotaManager,
      mockPause,
      mockTelemetry,
    );

    const cwdSpy = vi.spyOn(process, 'cwd').mockReturnValue('/app');
    try {
      const runningPath = path.resolve('/app/routes/checkout.js');
      inspector.registerScriptUrl('33', pathToFileURL(runningPath).href);

      const target = 'services/cart/routes/checkout.js';
      const resolved = await inspector.resolveDynamicSuffix(target);
      expect(resolved).toBe(runningPath);

      // Degraded suffix match in Step 4 must NOT be cached in pathCache
      expect(inspector['pathCache'].has(target)).toBe(false);
    } finally {
      cwdSpy.mockRestore();
    }
  });

  it('matches Windows paths starting with leading slash in isWindowsEnv', async () => {
    const inspector = new InspectorEngine(
      mockQuotaManager,
      mockPause,
      mockTelemetry,
    );

    const runningPath = path.resolve('/workspace/dist/services/posts/main.js');
    inspector.registerScriptUrl('34', pathToFileURL(runningPath).href);

    const resolved = await inspector.resolveDynamicSuffix(
      '/C:/Services/Posts/Main.js',
    );
    expect(resolved).toBe(runningPath);
  });

  it('invalidates appScriptsCache on disconnect', async () => {
    const inspector = new InspectorEngine(
      mockQuotaManager,
      mockPause,
      mockTelemetry,
    );

    const firstPath = path.resolve('/workspace/dist/services/posts/main.js');
    inspector.registerScriptUrl('35', pathToFileURL(firstPath).href);

    // Call resolveDynamicSuffix to populate appScriptsCache
    await inspector.resolveDynamicSuffix('services/posts/main.js');
    expect(inspector['appScriptsCache']).toBeDefined();

    // Disconnect should invalidate appScriptsCache
    await inspector.disconnect();
    expect(inspector['appScriptsCache']).toBeUndefined();
  });

  it('matches appRoot case-insensitively on Windows environments', async () => {
    const inspector = new InspectorEngine(
      mockQuotaManager,
      mockPause,
      mockTelemetry,
      undefined,
      'services/posts',
    );

    const cwdSpy = vi.spyOn(process, 'cwd').mockReturnValue('c:/app');
    try {
      const runningUrl = 'file:///C:/app/main.js';
      const runningPath = fileURLToPath(runningUrl);
      inspector.registerScriptUrl('36', runningUrl);

      // Target with mixed-case matching lowercased appRoot on Windows
      const resolved = await inspector.resolveDynamicSuffix(
        'Services/Posts/main.js',
      );
      expect(resolved).toBe(runningPath);
    } finally {
      cwdSpy.mockRestore();
    }
  });

  it('excludes scripts from mixed-case Node_modules directory', async () => {
    const inspector = new InspectorEngine(
      mockQuotaManager,
      mockPause,
      mockTelemetry,
    );

    // Dependency script in mixed-case Node_modules
    const depPath = path.resolve('/app/Node_modules/express/main.js');
    inspector.registerScriptUrl('38', pathToFileURL(depPath).href);

    const resolved = await inspector.resolveDynamicSuffix(
      'services/posts/main.js',
    );
    expect(resolved).not.toBe(depPath);
    expect(resolved).toBe(
      path.resolve(process.cwd(), 'services/posts/main.js'),
    );
  });

  it('matches Windows paths starting with leading backslash in isWindowsEnv', async () => {
    const inspector = new InspectorEngine(
      mockQuotaManager,
      mockPause,
      mockTelemetry,
    );

    const runningPath = path.resolve('/workspace/dist/services/posts/main.js');
    inspector.registerScriptUrl('39', pathToFileURL(runningPath).href);

    const resolved = await inspector.resolveDynamicSuffix(
      '\\C:\\Services\\Posts\\Main.js',
    );
    expect(resolved).toBe(runningPath);
  });

  it('enables case-insensitive matching when appRoot contains a Windows drive letter', async () => {
    const inspector = new InspectorEngine(
      mockQuotaManager,
      mockPause,
      mockTelemetry,
      undefined,
      'C:\\services\\posts',
    );

    const cwdSpy = vi.spyOn(process, 'cwd').mockReturnValue('/app');
    try {
      const runningPath = path.resolve('/app/main.js');
      inspector.registerScriptUrl('40', pathToFileURL(runningPath).href);

      const resolved = await inspector.resolveDynamicSuffix(
        'Services/Posts/main.js',
      );
      expect(resolved).toBe(runningPath);
    } finally {
      cwdSpy.mockRestore();
    }
  });
});
