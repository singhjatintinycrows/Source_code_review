/**
 * Prepares a log template for evaluation by escaping backticks and backslashes.
 * This allows the template to be safely wrapped in backticks for template literal evaluation.
 */
export function prepareLogTemplate(template: string): string {
  if (!template) return '``';
  const escaped = template.replace(/\\/g, '\\\\').replace(/`/g, '\\`');
  return `\`${escaped}\``;
}

/**
 * Wraps a set of expressions into a single object-literal string for evaluation.
 * Each expression is wrapped in a try/catch block to prevent one failure from breaking the whole set.
 */
export function wrapExpressionsForEvaluation(expressions: string[]): string {
  if (!expressions || expressions.length === 0) return '({})';

  const parts = expressions.map((e) => {
    const key = JSON.stringify(e);
    return `${key}: (() => { 
        try { return ${e}; } catch(e) { return "Error: " + e.message; } 
      })()`;
  });

  return `({
      ${parts.join(',\n    ')}
    })`;
}
