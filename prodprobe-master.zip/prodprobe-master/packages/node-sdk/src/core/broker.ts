import * as fs from 'node:fs';
import { dirname, join } from 'node:path';
import { Writable } from 'node:stream';
import * as grpc from '@grpc/grpc-js';
import {
  AgentBrokerClient,
  type AgentGlobalConfig,
  type Probe,
  type TelemetryEvent,
} from '@hyperprobe/protos';
import crypto from 'crypto';
import debug from 'debug';
import { fileURLToPath } from 'url';

const log = debug('hyperprobe:broker');

const _dirname =
  typeof __dirname !== 'undefined'
    ? __dirname
    : dirname(fileURLToPath(import.meta.url));
const pkgJsonPath = join(_dirname, '../../package.json');

export class BrokerClient {
  private client: AgentBrokerClient;
  private agentId: string;
  private serviceId: string;
  private environment: string;
  private commitSha: string;
  private version: string;
  constructor(
    brokerUrl: string,
    serviceId: string,
    environment: string,
    commitSha: string,
    isEphemeralLambda: boolean,
    enableKeepAlive: boolean,
  ) {
    this.serviceId = serviceId;
    this.environment = environment;
    this.commitSha = commitSha;
    this.agentId = crypto.randomUUID();

    try {
      const pkgJson = JSON.parse(fs.readFileSync(pkgJsonPath, 'utf-8'));
      this.version = pkgJson.version || '1.0.0';
    } catch {
      this.version = '1.0.0';
    }

    const interceptor: grpc.Interceptor = (options, nextCall) => {
      return new grpc.InterceptingCall(nextCall(options), {
        start: (metadata, listener, next) => {
          metadata.set('x-hp-service-id', this.serviceId);
          next(metadata, listener);
        },
      });
    };

    const clientOptions: grpc.ClientOptions = {
      interceptors: [interceptor],
    };

    if (enableKeepAlive) {
      clientOptions['grpc.keepalive_time_ms'] = 60000;
      clientOptions['grpc.keepalive_timeout_ms'] = 20000;
      clientOptions['grpc.keepalive_permit_without_calls'] = 1;
    }

    if (isEphemeralLambda) {
      clientOptions['grpc.initial_reconnect_backoff_ms'] = 1000;
      clientOptions['grpc.dns_min_time_between_resolutions_ms'] = 1000;
    }

    if (brokerUrl.startsWith('https://')) {
      log('Using secure https credentials for brokerUrl: %s', brokerUrl);
      this.client = new AgentBrokerClient(
        brokerUrl.slice(8),
        grpc.credentials.createSsl(),
        clientOptions,
      );
    } else if (brokerUrl.startsWith('http://')) {
      log('Using insecure http credentials for brokerUrl: %s', brokerUrl);
      this.client = new AgentBrokerClient(
        brokerUrl.slice(7),
        grpc.credentials.createInsecure(),
        clientOptions,
      );
    } else {
      log('Using insecure credentials for brokerUrl: %s', brokerUrl);
      this.client = new AgentBrokerClient(
        brokerUrl,
        grpc.credentials.createInsecure(),
        clientOptions,
      );
    }
  }

  public async getProbes(timeoutMs?: number): Promise<{
    probes: Probe[];
    nextSyncMs: number;
    globalConfig?: AgentGlobalConfig;
  }> {
    log('Fetching probes for %s...', this.serviceId);
    return new Promise((resolve, reject) => {
      const request = {
        agentId: this.agentId,
        serviceId: this.serviceId,
        environment: this.environment,
        commitSha: this.commitSha,
        language: 'node',
        agentVersion: this.version,
        hostname: process.env.HOSTNAME || 'unknown',
      };

      const metadata = new grpc.Metadata();
      const options: grpc.CallOptions = {};
      if (timeoutMs && timeoutMs > 0) {
        options.deadline = Date.now() + timeoutMs;
      }

      this.client.getProbes(request, metadata, options, (err, response) => {
        if (err) {
          log('Failed to fetch probes: %s', err.message);
          return reject(err);
        }
        log('Successfully fetched %d probes', response.probes?.length || 0);
        resolve({
          probes: response.probes || [],
          nextSyncMs: response.nextSyncIntervalMs || 60000,
          globalConfig: response.globalConfig,
        });
      });
    });
  }

  public async getSourceMapStatus(): Promise<{
    isUploader: boolean;
    isComplete: boolean;
  }> {
    return new Promise((resolve, reject) => {
      const request = {
        serviceId: this.serviceId,
        environment: this.environment,
        commitSha: this.commitSha,
      };

      this.client.getSourceMapStatus(request, (err, response) => {
        if (err) return reject(err);
        resolve({
          isUploader: !!response?.isUploader,
          isComplete: !!response?.isComplete,
        });
      });
    });
  }

  public async markSourceMapComplete(): Promise<void> {
    return new Promise((resolve, reject) => {
      const request = {
        serviceId: this.serviceId,
        environment: this.environment,
        commitSha: this.commitSha,
      };

      this.client.markSourceMapComplete(request, (err, _response) => {
        if (err) return reject(err);
        resolve();
      });
    });
  }

  public async reportTelemetry(
    events: TelemetryEvent[],
    timeoutMs?: number,
  ): Promise<string[]> {
    return new Promise((resolve, reject) => {
      const batch = {
        agentId: this.agentId,
        events,
      };

      const metadata = new grpc.Metadata();
      const options: grpc.CallOptions = {};
      if (timeoutMs && timeoutMs > 0) {
        options.deadline = Date.now() + timeoutMs;
      }

      this.client.reportTelemetry(batch, metadata, options, (err, response) => {
        if (err) return reject(err);
        resolve(response.finishedProbeIds || []);
      });
    });
  }

  public createUploadStream(fileName: string) {
    let uploadError: Error | null = null;
    let uploadFinished = false;
    let onFinished: ((err?: Error) => void) | null = null;

    const stream = this.client.uploadSourceMap((err, response) => {
      let finalErr: Error | null = err;
      if (!finalErr && response && response.success === false) {
        finalErr = new Error(
          `Server rejected source map upload for ${fileName}`,
        );
      }

      uploadError = finalErr;
      uploadFinished = true;

      if (finalErr) {
        log('Source map upload error for %s: %s', fileName, finalErr.message);
      } else {
        log(
          'Source map upload finished for %s: %s',
          fileName,
          response?.success,
        );
      }

      if (onFinished) {
        onFinished(finalErr || undefined);
        onFinished = null;
      }
    });

    // Wrap the gRPC stream to inject metadata into each chunk
    const { serviceId, environment, commitSha } = this;

    const writable = new Writable({
      write(chunk: Buffer, _encoding: string, callback) {
        if (uploadError) return callback(uploadError);

        const message = {
          serviceId,
          environment,
          commitSha,
          fileName,
          data: chunk,
        };

        const success = stream.write(message);

        if (success === false) {
          if (uploadError) {
            return callback(uploadError);
          }
          const onDrain = () => {
            stream.off('error', onError);
            stream.off('close', onClose);
            callback();
          };
          const onError = (err: Error) => {
            stream.off('drain', onDrain);
            stream.off('close', onClose);
            callback(err);
          };
          const onClose = () => {
            stream.off('drain', onDrain);
            stream.off('error', onError);
            callback(
              new Error('Stream closed unexpectedly during write backpressure'),
            );
          };
          stream.once('drain', onDrain);
          stream.once('error', onError);
          stream.once('close', onClose);
        } else {
          if (uploadError) {
            callback(uploadError);
          } else {
            setImmediate(callback);
          }
        }
      },
      final(callback) {
        if (uploadError) return callback(uploadError);

        stream.end();

        if (uploadFinished) {
          callback(uploadError || undefined);
        } else {
          onFinished = callback;
        }
      },
    });

    stream.on('error', (err) => {
      if (!uploadFinished) {
        uploadError = err;
        writable.destroy(err);
      }
    });

    return writable;
  }

  public shutdown() {
    this.client.close();
  }
}
