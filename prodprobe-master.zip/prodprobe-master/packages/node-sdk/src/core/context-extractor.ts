let otelApiModule: any;
let ddTraceModule: any;
let newRelicModule: any;
let elasticApmModule: any;
let awsXrayModule: any;

function findInCache(pattern: RegExp) {
  // esm fix
  if (typeof require === 'undefined' || !require || !require.cache) {
    return null;
  }
  const key = Object.keys(require.cache).find((k) => pattern.test(k));
  return key ? require.cache[key]?.exports : null;
}

export function extractTraceContext(
  customGetTraceId?: () => string | undefined,
): string | undefined {
  // 1. Give priority to user-defined traceId extraction
  if (customGetTraceId && typeof customGetTraceId === 'function') {
    try {
      const traceId = customGetTraceId();
      return traceId;
    } catch {
      // Safely ignore user errors to prevent crashing the app
    }
  }

  // 2. OpenTelemetry
  try {
    // 2a. Attempt retrieval via require.cache first (standard & fast for CJS)
    if (otelApiModule === undefined) {
      otelApiModule = findInCache(/@opentelemetry\/api\/.*index\.[cm]?js$/);
    }

    if (otelApiModule?.trace?.getSpan && otelApiModule?.context?.active) {
      const activeContext = otelApiModule.context.active();
      const activeSpan = otelApiModule.trace.getSpan(activeContext);
      const traceId = activeSpan?.spanContext?.()?.traceId;
      if (traceId) return traceId;
    }

    // 2b. Fallback to global symbol + public .getValue() (supports ESM, pre-init, & version gap)
    const otelSymbols = Object.getOwnPropertySymbols(global).filter((s) =>
      s.toString().includes('opentelemetry.js.api'),
    );
    if (otelSymbols.length > 0) {
      const otelApi = (global as any)[otelSymbols[0]];
      if (otelApi?.context?.active) {
        const activeContext = otelApi.context.active();
        if (activeContext && typeof activeContext.getValue === 'function') {
          const activeSpan = activeContext.getValue(
            Symbol.for('OpenTelemetry Context Key SPAN'),
          ) as any;
          if (activeSpan && typeof activeSpan.spanContext === 'function') {
            const traceId = activeSpan.spanContext()?.traceId;
            if (traceId) return traceId;
          }
        }
      }
    }
  } catch {
    // Safely ignore OpenTelemetry-related errors
  }

  // 3. APMs
  try {
    // Datadog
    if (ddTraceModule === undefined) {
      ddTraceModule = findInCache(/dd-trace\/index\.js$/);
    }
    if (ddTraceModule?.scope) {
      const traceId = ddTraceModule.scope().active()?.context()?.toTraceId();
      if (traceId) return traceId;
    }

    // New Relic
    if (newRelicModule === undefined) {
      newRelicModule = findInCache(/newrelic\/index\.js$/);
    }
    if (newRelicModule?.getTraceMetadata) {
      const traceId = newRelicModule.getTraceMetadata()?.traceId;
      if (traceId) return traceId;
    }

    // Elastic APM
    if (elasticApmModule === undefined) {
      elasticApmModule = findInCache(/elastic-apm-node\/index\.js$/);
    }
    if (elasticApmModule?.currentTraceIds) {
      const traceId = elasticApmModule.currentTraceIds['trace.id'];
      if (traceId) return traceId;
    }

    // AWS X-Ray
    if (awsXrayModule === undefined) {
      awsXrayModule = findInCache(/aws-xray-sdk-core\/.*\/index\.js$/);
    }
    if (awsXrayModule?.getSegment) {
      const traceId = awsXrayModule.getSegment()?.trace_id;
      if (traceId) return traceId;
    }
  } catch {
    // Silently ignore extraction errors
  }

  return undefined;
}
