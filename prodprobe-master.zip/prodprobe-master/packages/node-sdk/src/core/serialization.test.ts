import { describe, expect, it } from 'vitest';
import { getSerializationScript } from './serialization-script.js';

describe('Atomic Serialization Script', () => {
  const runScript = (data: { watches?: any; frames?: any[] }, config: any) => {
    const script = `(${getSerializationScript()})`;

    const manifest = {
      config,
      watchKeys: data.watches ? Object.keys(data.watches) : [],
      frameScopes: data.frames
        ? data.frames.map((f) =>
            Object.keys(f).map((type, index) => ({ type, index })),
          )
        : [],
    };

    const objs = [
      ...(data.watches ? Object.values(data.watches) : []),
      ...(data.frames ? data.frames.flatMap((f) => Object.values(f)) : []),
    ];

    return eval(script)(manifest, ...objs);
  };

  it('should handle watches and frames in one go', () => {
    const req = { url: '/' };
    const result = runScript(
      {
        watches: { req },
        frames: [{ local: { req } }],
      },
      {},
    );

    expect(result.watch.req).toEqual({ url: '/' });
    const localScope = result.vars[0].find((s: any) => s.type === 'local');
    expect(localScope.vars.req).toBe('[REF - watch["req"]]');
  });

  it('should correctly escape watch expression paths containing quotes', () => {
    const authHeader = { bearer: 'token123' };
    const result = runScript(
      {
        watches: { 'req.headers["authorization"]': authHeader },
        frames: [{ local: { auth: authHeader } }],
      },
      {},
    );

    expect(result.watch['req.headers["authorization"]']).toEqual({
      bearer: 'token123',
    });
    const localScope = result.vars[0].find((s: any) => s.type === 'local');
    expect(localScope.vars.auth).toBe(
      '[REF - watch["req.headers[\\"authorization\\"]"]]',
    );
  });

  it('should handle multiple scopes of the same type without collision', () => {
    const _result = runScript(
      {
        frames: [{ local: { x: 1 }, closure: { y: 2 }, closure_2: { z: 3 } }],
      },
      {},
    );

    // Note: in our runScript helper, we use Object.keys(f) to determine scope types.
    // To simulate V8 duplicate types, we'd need to adjust the manifest.
    // But the script logic now uses an array, so even if manifest says ['closure', 'closure'], it works.

    const manifest = {
      config: {},
      watchKeys: [],
      frameScopes: [
        [
          { type: 'local', index: 0 },
          { type: 'closure', index: 1 },
          { type: 'closure', index: 2 },
        ],
      ],
    };
    const script = `(${getSerializationScript()})`;
    const evaluated = eval(script)(
      manifest as any,
      { x: 1 },
      { y: 2 },
      { z: 3 },
    );

    expect(evaluated.vars[0].length).toBe(3);
    expect(evaluated.vars[0][0].type).toBe('local');
    expect(evaluated.vars[0][1].type).toBe('closure');
    expect(evaluated.vars[0][1].name).toBe('closure (1)');
    expect(evaluated.vars[0][1].vars.y).toBe(2);
    expect(evaluated.vars[0][2].type).toBe('closure');
    expect(evaluated.vars[0][2].name).toBe('closure (2)');
    expect(evaluated.vars[0][2].vars.z).toBe(3);
  });

  it('should respect maxDepth and show summaries at boundary', () => {
    const obj = { a: { b: { c: { d: 1 } } } };
    const result = runScript({ watches: { obj } }, { maxDepth: 2 });

    // Depth 0: root (obj) -> recurse
    // Depth 1: a -> recurse
    // Depth 2: b -> recurse
    // Depth 3: c -> Summarize
    expect(result.watch.obj.a.b.c).toBe('[Obj]');
  });

  it('should show primitives at maxDepth boundary', () => {
    const obj = { a: { b: { val: 123 } } };
    const result = runScript({ watches: { obj } }, { maxDepth: 3 });

    // Depth 0: obj -> recurse
    // Depth 1: a -> recurse
    // Depth 2: b -> recurse
    // Depth 3: b.val (Primitive) -> Show it!
    expect(result.watch.obj.a.b.val).toBe(123);
  });

  it('should handle array truncation with descriptive message', () => {
    const arr = [1, 2, 3, 4, 5];
    const result = runScript({ watches: { arr } }, { maxArrayLength: 2 });

    expect(result.watch.arr).toEqual([1, 2, '[+ 3 more items truncated]']);
  });

  it('should redact multiple matching keys', () => {
    const obj = { secret1: 'v1', secret2: 'v2', other: 'v3' };
    const result = runScript(
      { watches: { obj } },
      {
        redactKeys: ['secret\\d+'],
      },
    );

    expect(result.watch.obj.secret1).toBe('[REDACTED Key]');
    expect(result.watch.obj.secret2).toBe('[REDACTED Key]');
    expect(result.watch.obj.other).toBe('v3');
  });

  it('should redact sensitive keys and values partially and globally', () => {
    const obj = { password: '123', ssn: 'secret-data and another secret-code' };
    const result = runScript(
      { watches: { obj } },
      {
        redactKeys: ['password'],
        redactValues: ['secret-\\w+'],
      },
    );

    expect(result.watch.obj.password).toBe('[REDACTED Key]');
    expect(result.watch.obj.ssn).toBe(
      '[REDACTED Value] and another [REDACTED Value]',
    );
  });

  it('should be resilient to regex injection in redaction patterns', () => {
    const obj = { password: '123', normal: 'safe' };
    // Attempt injection: close the regex and execute code
    const result = runScript(
      { watches: { obj } },
      {
        redactKeys: [')/i; (function(){ globalThis.INJECTED = true; })(); //'],
      },
    );

    expect(result.watch.obj.password).not.toBe('[REDACTED Key]');
    expect((globalThis as any).INJECTED).toBeUndefined();
  });

  it('should handle slashes and Bearer patterns in redaction', () => {
    const obj = {
      'user/id': '123',
      auth: 'Authorization: Bearer mytoken123',
    };
    const result = runScript(
      { watches: { obj } },
      {
        redactKeys: ['user/id'],
        redactValues: ['\\bBearer(\\s|)\\w+\\b'],
      },
    );

    expect(result.watch.obj['user/id']).toBe('[REDACTED Key]');
    expect(result.watch.obj.auth).toBe('Authorization: [REDACTED Value]');
  });

  it('should show long string summaries with configurable limit and word boundary truncation', () => {
    const longStr = 'this is a very long string indeed';
    const result = runScript(
      { watches: { s: longStr } },
      { maxStringLength: 10 },
    );

    // "this is a " -> length 10
    // replace(/\b\w*$/, "") -> "this is a "
    // .trim() -> "this is a"
    expect(result.watch.s).toBe('this is a... [Truncated: +23 more chars]');
  });

  it('should handle complex identities across multiple frames', () => {
    const shared = { id: 1 };
    const result = runScript(
      {
        frames: [{ local: { shared } }, { closure: { shared } }],
      },
      {},
    );

    const frame0Local = result.vars[0].find((s: any) => s.type === 'local');
    const frame1Closure = result.vars[1].find((s: any) => s.type === 'closure');

    expect(frame0Local.vars.shared).toEqual({ id: 1 });
    expect(frame1Closure.vars.shared).toBe('[REF - frame[0].scopes[0].shared]');
  });

  it('should respect maxObjectProperties and show summaries with meta key', () => {
    const obj: any = {};
    for (let i = 0; i < 10; i++) obj[`prop${i}`] = i;
    const result = runScript({ watches: { obj } }, { maxObjectProperties: 5 });

    expect(Object.keys(result.watch.obj).length).toBe(6); // 5 props + __probe_meta
    expect(result.watch.obj.prop0).toBe(0);
    expect(result.watch.obj.prop4).toBe(4);
    expect(result.watch.obj.prop5).toBeUndefined(); // Should be truncated
    expect(result.watch.obj.__probe_meta).toBe('+ 5 more properties truncated');
  });

  it('should handle BigInt, Date, and Error objects', () => {
    const date = new Date('2024-01-01T00:00:00Z');
    const error = new Error('test error');
    const result = runScript(
      {
        watches: {
          b: 123n,
          d: date,
          e: error,
        },
      },
      {},
    );

    expect(result.watch.b).toBe('123n');
    expect(result.watch.d).toBe(date.toISOString());
    expect(result.watch.e.name).toBe('Error');
    expect(result.watch.e.message).toBe('test error');
    expect(result.watch.e.stack).toContain('Error: test error');
  });

  it('should be robust when configuration fields are missing', () => {
    const obj = { a: [1, 2, 3, 4, 5], b: { x: 1, y: 2 } };

    // Pass an empty config {} to exercise the script's internal defaults
    const result = runScript(
      {
        watches: { myVar: obj },
      },
      {},
    );

    // Should use defaults: maxDepth=3, maxArrayLength=3, maxObjectProperties=50
    expect(result.watch.myVar).toEqual({
      a: [1, 2, 3, '[+ 2 more items truncated]'],
      b: { x: 1, y: 2 },
    });
  });

  it('should serialize undefined values explicitly so they are not dropped', () => {
    const obj = { a: undefined, b: [1, undefined, 3] };

    const result = runScript(
      {
        watches: { myVar: obj },
      },
      {},
    );

    expect(result.watch.myVar).toEqual({
      a: '[undefined]',
      b: [1, '[undefined]', 3],
    });
  });

  it('should omit properties that throw ReferenceError (like TDZ) and serialize getters/setters as placeholders', () => {
    const target = {
      valid: 123,
      getter: null,
    };
    Object.defineProperty(target, 'getter', {
      get() {
        return 'val';
      },
      enumerable: true,
      configurable: true,
    });

    const obj = new Proxy(target, {
      ownKeys() {
        return ['valid', 'getter', 'error'];
      },
      getOwnPropertyDescriptor(t, prop) {
        if (prop === 'error') {
          throw new ReferenceError('Cannot access before initialization');
        }
        return Object.getOwnPropertyDescriptor(t, prop);
      },
    });

    const result = runScript(
      {
        watches: { myVar: obj },
      },
      {},
    );

    // 'valid' and 'getter' should be present, while 'error' (throws) should be completely omitted.
    expect(result.watch.myVar).toEqual({
      valid: 123,
      getter: '[Getter]',
    });
  });

  it('should gracefully handle non-Error exceptions (like primitives or null) thrown during serialization', () => {
    const target = {
      valid: 123,
    };
    const obj = new Proxy(target, {
      ownKeys() {
        return ['valid', 'throwNull', 'throwString'];
      },
      getOwnPropertyDescriptor(t, prop) {
        if (prop === 'throwNull') {
          throw null;
        }
        if (prop === 'throwString') {
          throw 'Some error string';
        }
        return Object.getOwnPropertyDescriptor(t, prop);
      },
    });

    const result = runScript(
      {
        watches: { myVar: obj },
      },
      {},
    );

    expect(result.watch.myVar).toEqual({
      valid: 123,
      throwNull: '[Error accessing property: null]',
      throwString: '[Error accessing property: Some error string]',
    });
  });

  it('should gracefully handle double-throwing exceptions (where message access itself throws) during serialization', () => {
    const target = {
      valid: 123,
    };
    const obj = new Proxy(target, {
      ownKeys() {
        return ['valid', 'doubleThrow'];
      },
      getOwnPropertyDescriptor(t, prop) {
        if (prop === 'doubleThrow') {
          const evilErr = new Error('outer');
          Object.defineProperty(evilErr, 'message', {
            get() {
              throw new Error('inner');
            },
          });
          throw evilErr;
        }
        return Object.getOwnPropertyDescriptor(t, prop);
      },
    });

    const result = runScript(
      {
        watches: { myVar: obj },
      },
      {},
    );

    expect(result.watch.myVar).toEqual({
      valid: 123,
      doubleThrow: '[Error accessing property: [unavailable]]',
    });
  });
});
