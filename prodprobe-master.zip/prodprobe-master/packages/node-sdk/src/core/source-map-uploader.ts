import * as fs from 'node:fs';
import * as fsPromises from 'node:fs/promises';
import * as path from 'node:path';
import { Transform, type TransformCallback, type Writable } from 'node:stream';
import { pipeline } from 'node:stream/promises';
import { StringDecoder } from 'node:string_decoder';
import * as zlib from 'node:zlib';
import debug from 'debug';

const log = debug('hyperprobe:sourcemap');

export interface UploaderOptions {
  serviceId: string;
  environment: string;
  commitSha: string;
  appRoot: string;
  distLocation: string;
  sourceMapDir?: string;
  createUploadStream: (fileName: string) => Writable;
}

export class SourcesContentStripper extends Transform {
  private decoder = new StringDecoder('utf-8');
  private state: 'SCANNING' | 'FINDING_VALUE_START' | 'SKIPPING_ARRAY' =
    'SCANNING';
  private carryOver: string = '';
  private bracketDepth: number = 0;
  private inString: boolean = false;
  private escapeNext: boolean = false;
  private out: string = '';

  constructor() {
    super({ decodeStrings: false, encoding: 'utf-8' });
  }

  _transform(chunk: any, _encoding: string, callback: TransformCallback): void {
    try {
      const str = typeof chunk === 'string' ? chunk : this.decoder.write(chunk);
      let combined = str;

      if (this.state === 'SCANNING') {
        combined = this.carryOver + str;
        this.carryOver = '';

        const idx = combined.indexOf('"sourcesContent"');

        if (idx === -1) {
          const pushLen = Math.max(0, combined.length - 15);
          if (pushLen > 0) {
            this.push(combined.slice(0, pushLen));
            this.carryOver = combined.slice(pushLen);
          } else {
            this.carryOver = combined;
          }
          callback();
          return;
        }

        const matchedKey = '"sourcesContent"';
        this.push(combined.slice(0, idx));
        this.push(matchedKey);
        this.state = 'FINDING_VALUE_START';
        combined = combined.slice(idx + matchedKey.length);
      }

      let i = 0;
      let startPushIdx = 0;

      while (i < combined.length) {
        const char = combined[i];

        if (this.state === 'SCANNING') {
          if (this.escapeNext) {
            this.escapeNext = false;
            i++;
          } else if (char === '\\') {
            if (this.inString) this.escapeNext = true;
            i++;
          } else if (char === '"') {
            if (!this.inString) {
              const searchPattern = '"sourcesContent"';
              if (i + searchPattern.length > combined.length) {
                // Not enough characters left to be sure of a match
                if (i > startPushIdx) {
                  this.push(combined.slice(startPushIdx, i));
                }
                this.carryOver = combined.slice(i);
                callback();
                return;
              }

              if (combined.startsWith(searchPattern, i)) {
                // Found the actual key!
                if (i > startPushIdx) {
                  this.push(combined.slice(startPushIdx, i));
                }
                this.push(searchPattern);
                i += searchPattern.length;
                startPushIdx = i;
                this.state = 'FINDING_VALUE_START';
                continue;
              }
            }
            this.inString = !this.inString;
            i++;
          } else {
            i++;
          }
        } else if (this.state === 'FINDING_VALUE_START') {
          if (
            char === ' ' ||
            char === '\n' ||
            char === '\r' ||
            char === '\t' ||
            char === ':'
          ) {
            this.out += char;
            i++;
          } else if (char === '[') {
            this.out += '[]';
            this.state = 'SKIPPING_ARRAY';
            this.bracketDepth = 1;
            this.inString = false;
            this.escapeNext = false;
            i++;
          } else {
            this.state = 'SCANNING';
            if (this.out.length > 0) {
              this.push(this.out);
              this.out = '';
            }
            startPushIdx = i;
          }
        } else if (this.state === 'SKIPPING_ARRAY') {
          if (this.escapeNext) {
            this.escapeNext = false;
          } else if (char === '\\') {
            if (this.inString) this.escapeNext = true;
          } else if (char === '"') {
            this.inString = !this.inString;
          } else if (!this.inString) {
            if (char === '[') {
              this.bracketDepth++;
            } else if (char === ']') {
              this.bracketDepth--;
              if (this.bracketDepth === 0) {
                this.state = 'SCANNING';

                if (this.out.length > 0) {
                  this.push(this.out);
                  this.out = '';
                }

                i++;
                startPushIdx = i;
                continue;
              }
            }
          }
          i++;
        }
      }

      if (this.state === 'SCANNING' && startPushIdx < combined.length) {
        this.push(combined.slice(startPushIdx));
      }

      callback();
    } catch (err: any) {
      callback(err);
    }
  }

  _flush(callback: TransformCallback): void {
    const remaining = this.decoder.end();
    const combined = this.carryOver + remaining;
    if (this.state === 'SCANNING' && combined.length > 0) {
      this.push(combined);
    }
    callback();
  }
}

export class SourceMapUploader {
  constructor(private options: UploaderOptions) {}

  public async uploadAll(): Promise<number> {
    const dir = path.resolve(this.options.sourceMapDir || process.cwd());

    try {
      await fsPromises.access(dir);
    } catch {
      log('Source map directory does not exist: %s', dir);
      return 0;
    }

    const mapFiles = await this.findMapFilesAsync(dir);

    if (mapFiles.length === 0) {
      log('No source map files found in %s. Skipping upload phase.', dir);
      return 0;
    }

    log('Found %d source map files in %s', mapFiles.length, dir);

    for (const filePath of mapFiles) {
      try {
        await this.uploadFile(filePath, dir);
      } catch (err) {
        log('Failed to upload source map %s: %O', filePath, err);
        throw err;
      }
    }

    return mapFiles.length;
  }

  private async findMapFilesAsync(
    dir: string,
    results: string[] = [],
  ): Promise<string[]> {
    const list = await fsPromises.readdir(dir, { withFileTypes: true });

    const tasks = list.map(async (dirent) => {
      const fullPath = path.join(dir, dirent.name);

      if (dirent.isDirectory()) {
        if (dirent.name !== 'node_modules' && !dirent.name.startsWith('.')) {
          await this.findMapFilesAsync(fullPath, results);
        }
      } else if (dirent.name.endsWith('.js.map')) {
        results.push(fullPath);
      }
    });

    await Promise.all(tasks);

    return results;
  }

  private async uploadFile(
    filePath: string,
    sourceMapDir: string,
  ): Promise<void> {
    const relativeToSourceMapDir = path
      .relative(sourceMapDir, filePath)
      .replace(/\\/g, '/');

    const isWindowsEnv =
      process.platform === 'win32' ||
      /^[\\/]?[a-zA-Z]:/.test(filePath) ||
      /^[\\/]?[a-zA-Z]:/.test(sourceMapDir) ||
      Boolean(
        this.options.appRoot && /^[\\/]?[a-zA-Z]:/.test(this.options.appRoot),
      );

    const normAppRoot = this.options.appRoot
      ? path.posix
          .normalize(this.options.appRoot.replace(/\\/g, '/'))
          .replace(/^[\\/]?[a-zA-Z]:[/]+/, '')
          .replace(/^(\.\.?(\/|$))+/, '')
          .replace(/^\/+/, '')
          .replace(/\/+$/, '')
      : '';

    const normDistLocation = this.options.distLocation
      ? path.posix
          .normalize(this.options.distLocation.replace(/\\/g, '/'))
          .replace(/^[\\/]?[a-zA-Z]:[/]+/, '')
          .replace(/^(\.\.?(\/|$))+/, '')
          .replace(/^\/+/, '')
          .replace(/\/+$/, '')
      : '';

    let fileName = relativeToSourceMapDir;

    const relToCheck = isWindowsEnv
      ? relativeToSourceMapDir.toLowerCase()
      : relativeToSourceMapDir;
    const rootToCheck = isWindowsEnv ? normAppRoot.toLowerCase() : normAppRoot;

    // If relative path is already scoped to appRoot, avoid duplicating prefix/distLocation
    if (
      rootToCheck &&
      (relToCheck === rootToCheck || relToCheck.startsWith(`${rootToCheck}/`))
    ) {
      fileName = relativeToSourceMapDir;
    } else {
      let prefix = path.posix.join(normAppRoot, normDistLocation);
      prefix = prefix.replace(/\\/g, '/').replace(/\/+$/, ''); // Safely remove trailing slashes
      if (prefix === '.') prefix = ''; // Prevent empty paths from resolving to '.'

      if (prefix) {
        const prefixParts = prefix.split('/').filter(Boolean);
        const relParts = relativeToSourceMapDir
          .replace(/\\/g, '/')
          .split('/')
          .filter(Boolean);

        let overlapLength = 0;
        for (
          let i = Math.min(prefixParts.length, relParts.length);
          i > 0;
          i--
        ) {
          const endOfPrefix = prefixParts.slice(-i).join('/');
          const startOfRel = relParts.slice(0, i).join('/');
          const endCheck = isWindowsEnv
            ? endOfPrefix.toLowerCase()
            : endOfPrefix;
          const startCheck = isWindowsEnv
            ? startOfRel.toLowerCase()
            : startOfRel;
          if (endCheck === startCheck) {
            overlapLength = i;
            break;
          }
        }

        const isExactPrefix = overlapLength === prefixParts.length;
        if (isExactPrefix) {
          fileName = relativeToSourceMapDir;
        } else {
          fileName = [...prefixParts, ...relParts.slice(overlapLength)].join(
            '/',
          );
        }
      }
    }

    log('Streaming source map (strip sourcesContent): %s', fileName);

    const stripper = new SourcesContentStripper();
    const gzip = zlib.createGzip();

    const readStream = fs.createReadStream(filePath, { encoding: 'utf-8' });

    await pipeline(
      readStream,
      stripper,
      gzip,
      this.options.createUploadStream(fileName),
    );

    log('Finished uploading source map: %s', fileName);
  }
}
