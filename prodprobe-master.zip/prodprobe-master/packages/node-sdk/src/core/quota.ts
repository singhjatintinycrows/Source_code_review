export class TokenBucket {
  private tokens: number;
  private lastRefill: number;
  private readonly capacity: number;
  private readonly refillRate: number; // tokens per ms

  constructor(capacity: number, refillRatePerSec: number) {
    this.capacity = capacity;
    this.refillRate = refillRatePerSec / 1000;
    this.tokens = capacity;
    this.lastRefill = Date.now();
  }

  public tryConsume(count: number = 1): boolean {
    this.refill();
    if (this.tokens >= count) {
      this.tokens -= count;
      return true;
    }
    return false;
  }

  private refill() {
    const now = Date.now();
    const delta = now - this.lastRefill;
    const amount = delta * this.refillRate;
    this.tokens = Math.min(this.capacity, this.tokens + amount);
    this.lastRefill = now;
  }
}

export class QuotaManager {
  private evalBucket: TokenBucket;
  private bandwidthBucket: TokenBucket;

  constructor(hitsPerSec: number = 10, bytesPerSec: number = 200 * 1024) {
    // Burst capacity of hitsPerSec and bytesPerSec (1 second worth)
    this.evalBucket = new TokenBucket(hitsPerSec, hitsPerSec);
    this.bandwidthBucket = new TokenBucket(bytesPerSec, bytesPerSec);
  }

  public canEvaluate(): boolean {
    return this.evalBucket.tryConsume(1);
  }

  public canSend(bytes: number): boolean {
    return this.bandwidthBucket.tryConsume(bytes);
  }
}
