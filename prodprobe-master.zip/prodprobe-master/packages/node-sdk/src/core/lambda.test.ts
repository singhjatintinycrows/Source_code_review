import { describe, expect, it, vi } from 'vitest';

const agent = vi.hoisted(() => ({
  start: vi.fn(),
  getInstance: vi.fn(() => undefined),
}));

vi.mock('../index.js', () => ({ HyperProbeAgent: agent }));

import {
  type LambdaCallback,
  type LambdaContext,
  wrapLambda,
} from './lambda.js';

const options = {
  serviceId: 'service',
  environment: 'test',
  brokerUrl: 'https://broker.example.com',
  isLambda: false,
};

describe('wrapLambda', () => {
  it('supports callback-style handlers', async () => {
    const handler = wrapLambda(
      (
        event: { value: number },
        _context: LambdaContext,
        callback: LambdaCallback<number>,
      ) => {
        callback(null, event.value + 1);
      },
      options,
    );

    await expect(handler({ value: 1 }, {})).resolves.toBe(2);
  });

  it('uses the first completion from a hybrid handler', async () => {
    const handler = wrapLambda(
      (
        _event: unknown,
        _context: LambdaContext,
        callback: LambdaCallback<string>,
      ) => {
        callback(null, 'callback result');
        return Promise.resolve('promise result');
      },
      options,
    );

    await expect(handler({}, {})).resolves.toBe('callback result');
  });
});
