export enum AgentHealth {
  GREEN = 'GREEN', // All good
  YELLOW = 'YELLOW', // Rate limited (Reactive Shedding)
  RED = 'RED', // Critical Lag (Proactive Shedding - Detach)
}

export class SafetyMonitor {
  private health: AgentHealth = AgentHealth.GREEN;
  private lastHeartbeat: number = Date.now();
  private loopLag: number = 0;
  private intervalId?: NodeJS.Timeout;

  private cumulativePauseTime: number = 0;
  private lastWindowReset: number = Date.now();

  private onStateChange: (health: AgentHealth, reason?: string) => void;
  private readonly maxLagMs: number;
  private readonly pauseBudgetMs: number;
  private readonly isEphemeralLambda: boolean;

  constructor(
    onStateChange: (health: AgentHealth, reason?: string) => void,
    maxLagMs: number = 50,
    pauseBudgetMs: number = 15,
    isEphemeralLambda = false,
  ) {
    this.onStateChange = onStateChange;
    this.maxLagMs = maxLagMs;
    this.pauseBudgetMs = pauseBudgetMs;
    this.isEphemeralLambda = isEphemeralLambda;
  }

  public start() {
    this.intervalId = setInterval(() => {
      const now = Date.now();
      this.loopLag = now - this.lastHeartbeat - 100; // Expected 100ms interval
      this.lastHeartbeat = now;

      this.checkHealth();

      // Reset pause budget window every second
      if (now - this.lastWindowReset > 1000) {
        this.cumulativePauseTime = 0;
        this.lastWindowReset = now;
      }
    }, 100);
    this.intervalId.unref();
  }

  public stop() {
    if (this.intervalId) clearInterval(this.intervalId);
  }

  public reportPauseDuration(ms: number) {
    this.cumulativePauseTime += ms;
    this.checkHealth();
  }

  private checkHealth() {
    const prevHealth = this.health;
    let reason: string | undefined;

    if (this.isEphemeralLambda) {
      this.health = AgentHealth.GREEN; // Always GREEN for lambda functions
    } else {
      // RED: Critical impact detected
      if (this.loopLag > this.maxLagMs) {
        this.health = AgentHealth.RED;
        reason = `Event Loop Lag (${this.loopLag.toFixed(1)}ms) exceeded limit (${this.maxLagMs}ms)`;
      } else if (this.cumulativePauseTime > this.pauseBudgetMs) {
        this.health = AgentHealth.RED;
        reason = `Cumulative Pause Budget (${this.cumulativePauseTime.toFixed(1)}ms) exceeded limit (${this.pauseBudgetMs}ms)`;
      }
      // YELLOW: Moderate impact (hardcoded for now as 50% of RED)
      else if (this.loopLag > this.maxLagMs / 2) {
        this.health = AgentHealth.YELLOW;
        reason = `Moderate impact: Event Loop Lag (${this.loopLag.toFixed(1)}ms) reached 50% of limit (${this.maxLagMs}ms)`;
      } else if (this.cumulativePauseTime > this.pauseBudgetMs / 2) {
        this.health = AgentHealth.YELLOW;
        reason = `Moderate impact: Cumulative Pause Budget (${this.cumulativePauseTime.toFixed(1)}ms) reached 50% of limit (${this.pauseBudgetMs}ms)`;
      } else {
        this.health = AgentHealth.GREEN;
        if (prevHealth !== AgentHealth.GREEN) {
          reason = 'System stabilized.';
        }
      }
    }

    if (this.health !== prevHealth) {
      this.onStateChange(this.health, reason);
    }
  }

  public getHealth(): AgentHealth {
    return this.health;
  }
}
