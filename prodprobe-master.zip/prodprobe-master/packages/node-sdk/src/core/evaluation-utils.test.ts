import { describe, expect, it } from 'vitest';
import {
  prepareLogTemplate,
  wrapExpressionsForEvaluation,
} from './evaluation-utils.js';

describe('Evaluation Utils', () => {
  describe('prepareLogTemplate', () => {
    it('should wrap a simple template in backticks', () => {
      expect(prepareLogTemplate('hello world')).toBe('`hello world`');
    });

    it('should escape backticks correctly', () => {
      expect(prepareLogTemplate('hello `world`')).toBe('`hello \\`world\\``');
    });

    it('should escape backslashes correctly', () => {
      expect(prepareLogTemplate('C:\\\\path\\\\to\\\\file')).toBe(
        '`C:\\\\\\\\path\\\\\\\\to\\\\\\\\file`',
      );
    });

    it('should handle templates with expressions', () => {
      // biome-ignore lint/suspicious/noTemplateCurlyInString: testing literal template input string
      expect(prepareLogTemplate('User ${user.name} logged in')).toBe(
        // biome-ignore lint/suspicious/noTemplateCurlyInString: testing literal template input string
        '`User ${user.name} logged in`',
      );
    });

    it('should return an empty template for null or undefined', () => {
      expect(prepareLogTemplate(null as any)).toBe('``');
      expect(prepareLogTemplate(undefined as any)).toBe('``');
    });
  });

  describe('wrapExpressionsForEvaluation', () => {
    it('should wrap expressions in an object literal with try/catch', () => {
      const exprs = ['1 + 1', 'user.name'];
      const result = wrapExpressionsForEvaluation(exprs);

      expect(result).toContain('"1 + 1": (() => {');
      expect(result).toContain(
        'try { return 1 + 1; } catch(e) { return "Error: " + e.message; }',
      );
      expect(result).toContain('"user.name": (() => {');
      expect(result).toContain(
        'try { return user.name; } catch(e) { return "Error: " + e.message; }',
      );
    });

    it('should handle special characters in expressions using JSON.stringify', () => {
      const exprs = ['obj["key with spaces"]'];
      const result = wrapExpressionsForEvaluation(exprs);
      expect(result).toContain('"obj[\\"key with spaces\\"]":');
    });

    it('should return an empty object literal if no expressions are provided', () => {
      expect(wrapExpressionsForEvaluation([])).toBe('({})');
      expect(wrapExpressionsForEvaluation(null as any)).toBe('({})');
    });

    it('should be valid syntax when evaluated', () => {
      const exprs = ['a + b'];
      const result = wrapExpressionsForEvaluation(exprs);

      // Simulate evaluation in a context with a and b
      // biome-ignore lint/correctness/noUnusedVariables: eval is using a and b
      const a = 1,
        // biome-ignore lint/correctness/noUnusedVariables: eval is using a and b
        b = 2;
      const evaluated = eval(result);
      expect(evaluated['a + b']).toBe(3);
    });

    it('should catch errors in individual expressions during evaluation', () => {
      const exprs = ['1 + 1', 'failingExpr'];
      const result = wrapExpressionsForEvaluation(exprs);

      // Simulate evaluation (failingExpr is undefined)
      const evaluated = eval(result);
      expect(evaluated['1 + 1']).toBe(2);
      expect(evaluated['failingExpr']).toMatch(/^Error: /);
    });
  });
});
