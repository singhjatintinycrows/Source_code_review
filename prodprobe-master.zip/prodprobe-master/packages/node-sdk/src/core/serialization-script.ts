export function getSerializationScript(): string {
  return `function(manifest, ...objs) {
      const { 
        maxDepth = 3, 
        maxArrayLength = 3, 
        maxObjectProperties = 50, 
        maxStringLength = 1024, 
        redactKeys, 
        redactValues
      } = manifest.config;

      const makeRegex = (patterns, flags) => {
        if (!patterns || patterns.length === 0) return null;
        try {
          return new RegExp(patterns.map(p => "(?:" + p + ")").join('|'), flags || 'i');
        } catch (e) {
          return null;
        }
      };

      const redactKeysRegex = makeRegex(redactKeys, 'i');
      const redactValuesRegex = makeRegex(redactValues, 'gi');
      const visited = new WeakMap();

      function getSummary(obj) {
        if (obj === null) return "null";
        const type = typeof obj;
        if (type === 'function') return "[Function" + (obj.name ? ": " + obj.name : "") + "]";
        if (Array.isArray(obj)) return "[Arr: " + obj.length + "]";
        if (type === 'object') return "[Obj]";
        if (type === 'string') return "[Str: " + obj.length + "]";
        if (type === 'bigint') return obj.toString() + "n";
        return String(obj);
      }

      function serialize(obj, path, depth) {
        if (obj === null) return null;
        if (obj === undefined) return "[undefined]";
        
        const type = typeof obj;
        if (type !== 'object' && type !== 'function') {
          if (type === 'bigint') return obj.toString() + "n";
          if (type === 'symbol') return obj.toString();
          if (type === 'number') {
            if (!Number.isFinite(obj)) return String(obj);
            return obj;
          }
          if (type === 'string') {
            let str = obj;
            const limit = maxStringLength;
            if (str.length > limit) {
              const head = str.substring(0, limit);
              const truncatedHead = head.replace(/\\b\\w*$/, "").trim();
              str = truncatedHead + "... [Truncated: +" + (str.length - limit) + " more chars]";
            }
            if (redactValuesRegex) {
              str = str.replace(redactValuesRegex, "[REDACTED Value]");
            }
            return str;
          }
          return obj;
        }

        if (type === 'function') {
          return "[Function" + (obj.name ? ": " + obj.name : "") + "]";
        }

        if (visited.has(obj)) {
          return "[REF - " + visited.get(obj) + "]";
        }

        if (obj instanceof Date) return obj.toISOString();
        if (obj instanceof Error) {
          return {
            name: obj.name,
            message: obj.message,
            stack: obj.stack ? (obj.stack.split("\\n").slice(0, 3).join("\\n") + "...") : undefined
          };
        }

        if (depth > maxDepth) {
          return getSummary(obj);
        }

        visited.set(obj, path);

        if (Array.isArray(obj)) {
          const arr = [];
          const len = Math.min(obj.length, maxArrayLength);
          for (let i = 0; i < len; i++) {
            try {
              const desc = Object.getOwnPropertyDescriptor(obj, i);
              if (!desc) {
                arr.push("[Inaccessible]");
              } else if (desc.get || desc.set) {
                const acc = [];
                if (desc.get) acc.push("Getter");
                if (desc.set) acc.push("Setter");
                arr.push("[" + acc.join("/") + "]");
              } else {
                arr.push(serialize(desc.value, path + "[" + i + "]", depth + 1));
              }
            } catch (e) {
              arr.push("[Error]");
            }
          }
          if (obj.length > maxArrayLength) {
            arr.push("[+ " + (obj.length - maxArrayLength) + " more items truncated]");
          }
          return arr;
        }

        const result = {};
        const keys = Object.getOwnPropertyNames(obj);
        const limit = maxObjectProperties;
        const numToProcess = Math.min(keys.length, limit);

        for (let i = 0; i < numToProcess; i++) {
          const key = keys[i];
          if (redactKeysRegex && redactKeysRegex.test(key)) {
            result[key] = "[REDACTED Key]";
            continue;
          }
          
          try {
            const desc = Object.getOwnPropertyDescriptor(obj, key);
            if (!desc) {
              if (depth > 0) {
                result[key] = "[Inaccessible]";
              }
            } else if (desc.get || desc.set) {
              const acc = [];
              if (desc.get) acc.push("Getter");
              if (desc.set) acc.push("Setter");
              result[key] = "[" + acc.join("/") + "]";
            } else {
              result[key] = serialize(desc.value, path + (path ? "." : "") + key, depth + 1);
            }
          } catch (e) {
            // TDZ or optimized-out variables will throw ReferenceError on descriptor or value access.
            // By doing nothing, we completely omit them from the resulting snapshot.
            if (!(e instanceof ReferenceError)) {
              let msg;
              try {
                msg =
                  e && typeof e === 'object' && 'message' in e
                    ? String(e.message)
                    : String(e);
              } catch {
                msg = "[unavailable]";
              }
              result[key] = "[Error accessing property: " + msg + "]";
            }
          }
        }
        
        if (keys.length > numToProcess) {
          result["__probe_meta"] = "+ " + (keys.length - numToProcess) + " more properties truncated";
        }

        return result;
      }

      const roots = { watches: {}, frames: [] };
      let ptr = 0;
      if (manifest.watchKeys) {
        for (const key of manifest.watchKeys) {
          roots.watches[key] = objs[ptr++];
        }
      }
      if (manifest.frameScopes) {
        for (let i = 0; i < manifest.frameScopes.length; i++) {
          const scopeInfos = manifest.frameScopes[i];
          const frame = [];
          for (const info of scopeInfos) {
            frame.push({ 
              type: info.type, 
              name: info.type + (info.index ? " (" + info.index + ")" : ""),
              object: objs[ptr++] 
            });
          }
          roots.frames.push(frame);
        }
      }

      const output = { watch: {}, vars: [] };
      
      for (const key in roots.watches) {
        output.watch[key] = serialize(roots.watches[key], "watch[" + JSON.stringify(key) + "]", 0);
      }

      for (let i = 0; i < roots.frames.length; i++) {
        const scopes = roots.frames[i];
        const frameOutput = [];
        for (let j = 0; j < scopes.length; j++) {
          const scope = scopes[j];
          frameOutput.push({
            type: scope.type,
            name: scope.name,
            vars: serialize(scope.object, "frame[" + i + "].scopes[" + j + "]", 0)
          });
        }
        output.vars.push(frameOutput);
      }

      return output;
    }`;
}
