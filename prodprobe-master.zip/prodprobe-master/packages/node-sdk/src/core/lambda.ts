import { HyperProbeAgent } from '../index.js';
import type { HyperProbeOptions } from '../types/index.js';

/**
 * Lambda execution context type with the subset of properties we use.
 */
export interface LambdaContext {
  getRemainingTimeInMillis?: () => number;
  functionName?: string;
  functionVersion?: string;
  invokedFunctionArn?: string;
  memoryLimitInMB?: string;
  awsRequestId?: string;
  logGroupName?: string;
  logStreamName?: string;
  callbackWaitsForEmptyEventLoop?: boolean;
  [key: string]: unknown;
}

export type LambdaCallback<TResult> = (
  error?: Error | string | null,
  result?: TResult,
) => void;

export type PromiseLambdaHandler<TEvent, TResult> = (
  event: TEvent,
  context: LambdaContext,
) => Promise<TResult> | TResult;

export type CallbackLambdaHandler<TEvent, TResult> = (
  event: TEvent,
  context: LambdaContext,
  callback: LambdaCallback<TResult>,
) => void;

export type WrappedLambdaHandler<TEvent, TResult> = (
  event: TEvent,
  context: LambdaContext,
) => Promise<TResult>;

function invokeHandler<TEvent, TResult>(
  handler:
    | PromiseLambdaHandler<TEvent, TResult>
    | CallbackLambdaHandler<TEvent, TResult>,
  event: TEvent,
  context: LambdaContext,
): Promise<TResult> {
  return new Promise((resolve, reject) => {
    let settled = false;
    const settle = (callback: () => void) => {
      if (settled) return;
      settled = true;
      callback();
    };
    const callback: LambdaCallback<TResult> = (error, result) => {
      settle(() => {
        if (error) reject(error);
        else resolve(result as TResult);
      });
    };

    let returned: unknown;
    try {
      returned = (handler as CallbackLambdaHandler<TEvent, TResult>)(
        event,
        context,
        callback,
      );
    } catch (error) {
      settle(() => reject(error));
      return;
    }

    if (returned && typeof (returned as Promise<TResult>).then === 'function') {
      void Promise.resolve(returned as TResult | PromiseLike<TResult>).then(
        (result) => settle(() => resolve(result)),
        (error) => settle(() => reject(error)),
      );
    } else if (handler.length < 3) {
      settle(() => resolve(returned as TResult));
    }
  });
}

export function wrapLambda<TEvent = Record<string, unknown>, TResult = unknown>(
  handler: (
    event: TEvent,
    context: LambdaContext,
  ) => Promise<TResult> | TResult,
  options: HyperProbeOptions,
): WrappedLambdaHandler<TEvent, TResult>;
export function wrapLambda<TEvent = Record<string, unknown>, TResult = unknown>(
  handler: CallbackLambdaHandler<TEvent, TResult>,
  options: HyperProbeOptions,
): WrappedLambdaHandler<TEvent, TResult>;
export function wrapLambda<TEvent = Record<string, unknown>, TResult = unknown>(
  handler:
    | PromiseLambdaHandler<TEvent, TResult>
    | CallbackLambdaHandler<TEvent, TResult>,
  options: HyperProbeOptions,
): WrappedLambdaHandler<TEvent, TResult> {
  const isAwsLambda = !!process.env.AWS_LAMBDA_FUNCTION_NAME;
  const isLocalEmulator =
    process.env.IS_OFFLINE === 'true' || process.env.AWS_SAM_LOCAL === 'true';

  const isEphemeral = (options.isLambda ?? isAwsLambda) && !isLocalEmulator;

  // Validate broker URL in ephemeral mode
  if (isEphemeral) {
    const brokerUrl = options.brokerUrl || process.env.HYPERPROBE_BROKER_URL;
    if (
      brokerUrl &&
      (brokerUrl.includes('localhost') || brokerUrl.includes('127.0.0.1'))
    ) {
      console.warn(
        '\x1b[1m\x1b[33m⚠️  [HyperProbe Lambda] WARN: brokerUrl points to localhost in ephemeral Lambda mode. ' +
          'Probes will not be fetched from a local server in production. ' +
          'Set brokerUrl to your deployed Logger gRPC endpoint.\x1b[0m',
      );
    }
  }

  // Mode 2: Local Developer Emulator Mode (serverless-offline, SAM local, etc.)
  // We initialize the full VM agent and run standard background async pollers.
  if (!isEphemeral) {
    HyperProbeAgent.start(options);
    return async (event: TEvent, context: LambdaContext): Promise<TResult> => {
      if (context) {
        context.callbackWaitsForEmptyEventLoop = false;
      }
      return invokeHandler(handler, event, context);
    };
  }

  let isStarted = false;
  let coldStartMs = 0;

  // Mode 1: Cloud Ephemeral Production Mode
  // Run a synchronous, sequential, and highly optimized process lifecycle.
  return async (event: TEvent, context: LambdaContext): Promise<TResult> => {
    if (context) {
      context.callbackWaitsForEmptyEventLoop = false;
    }
    if (!isStarted) {
      const t0 = performance.now();
      HyperProbeAgent.start({
        ...options,
        isLambda: true,
      });
      isStarted = true;
      coldStartMs = performance.now() - t0;
      // Use internal log if available or console.log
      console.log(
        `[HyperProbe Lambda] Cold start init completed in ${coldStartMs.toFixed(1)}ms`,
      );
    }

    const agent = HyperProbeAgent.getInstance();

    const isAgentActive = agent && !agent.getIsAgentDisabled();

    if (isAgentActive) {
      // Calculate dynamic sync timeout budget
      const remainingMs = context.getRemainingTimeInMillis?.();
      let syncTimeoutMs = options.lambdaSyncTimeoutMs ?? 2000;

      if (remainingMs !== undefined) {
        // Budget at most 20% of the remaining Lambda execution time to the pre-sync,
        // leaving the remaining 80% entirely for the handler itself and post-flush.
        const dynamicBudgetMs = Math.floor(remainingMs * 0.2);

        if (dynamicBudgetMs < 100) {
          // If 20% of remaining time is less than 100ms, it is too tight; fail open immediately
          console.warn(
            '[HyperProbe Lambda] Skipping probe sync as remaining time budget is too low.',
          );
          syncTimeoutMs = 0;
        } else {
          syncTimeoutMs = Math.min(syncTimeoutMs, dynamicBudgetMs);
        }
      }

      if (syncTimeoutMs > 0) {
        try {
          await agent.forceSync(syncTimeoutMs);
        } catch (err) {
          console.error('[HyperProbe Lambda] Failed to sync probes:', err);
        }
      }
    }

    let result: TResult;
    try {
      result = await invokeHandler(handler, event, context);
    } finally {
      if (isAgentActive) {
        // Use remaining Lambda time minus a 200ms safety margin for the flush
        const remainingMs = context.getRemainingTimeInMillis?.() || 0;
        const flushTimeout =
          remainingMs && remainingMs > 500
            ? Math.min(remainingMs - 200, options.flushTimeoutMs ?? 1500)
            : (options.flushTimeoutMs ?? 1500);

        // Proactive Timeout Protection: Only capture/flush if we have enough time left
        if (remainingMs > 500 || !context.getRemainingTimeInMillis) {
          try {
            await agent!.forceFlush(flushTimeout);
          } catch (err) {
            console.error(
              '[HyperProbe Lambda] Failed to flush telemetry:',
              err,
            );
          }
        } else {
          console.warn(
            '[HyperProbe Lambda] Aborting snapshot flush to prevent Lambda timeout.',
          );
        }
      }
    }

    return result;
  };
}

/**
 * Stops the HyperProbe agent and cleans up resources.
 * Useful for explicit shutdown in Lambda extensions, container-based Lambda (ECS/Fargate), or testing.
 */
export async function stopLambda(): Promise<void> {
  const agent = HyperProbeAgent.getInstance();
  if (agent && !agent.getIsAgentDisabled()) {
    try {
      await agent.forceFlush(1000);
    } catch {
      // Best-effort flush before shutdown
    }
  }
  HyperProbeAgent.shutdown();
}
