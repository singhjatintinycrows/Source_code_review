import type { Probe } from '@hyperprobe/protos';
import { afterEach, describe, expect, it, vi } from 'vitest';
import { InspectorEngine } from './inspector.js';
import { QuotaManager } from './quota.js';

interface InspectorEngineInternals {
  probeMap: Map<string, Probe>;
  handleInlineLog(probeId: string, value: unknown): void;
}

describe('InspectorEngine probe log output', () => {
  afterEach(() => {
    vi.restoreAllMocks();
  });

  function emitLog(logLevel: string, shouldLogToStdout = true) {
    const engine = new InspectorEngine(new QuotaManager(), vi.fn(), vi.fn());
    engine.setGlobalConfig({ redactKeys: [], redactValues: [] });

    const internals = engine as unknown as InspectorEngineInternals;
    internals.probeMap.set('probe-1', {
      id: 'probe-1',
      logLevel,
      shouldLogToStdout,
    } as Probe);
    internals.handleInlineLog('probe-1', 'probe message');
  }

  it('writes INFO logs only to stdout', () => {
    const stdout = vi
      .spyOn(process.stdout, 'write')
      .mockImplementation(() => true);
    const stderr = vi
      .spyOn(process.stderr, 'write')
      .mockImplementation(() => true);

    emitLog('INFO');

    expect(stdout).toHaveBeenCalledOnce();
    expect(stdout).toHaveBeenCalledWith(expect.stringContaining('[INFO]'));
    expect(stderr).not.toHaveBeenCalled();
  });

  it('writes ERROR logs only to stderr', () => {
    const stdout = vi
      .spyOn(process.stdout, 'write')
      .mockImplementation(() => true);
    const stderr = vi
      .spyOn(process.stderr, 'write')
      .mockImplementation(() => true);

    emitLog('eRrOr');

    expect(stderr).toHaveBeenCalledOnce();
    expect(stderr).toHaveBeenCalledWith(expect.stringContaining('[ERROR]'));
    expect(stdout).not.toHaveBeenCalled();
  });

  it('does not write locally when stdout logging is disabled', () => {
    const stdout = vi
      .spyOn(process.stdout, 'write')
      .mockImplementation(() => true);
    const stderr = vi
      .spyOn(process.stderr, 'write')
      .mockImplementation(() => true);

    emitLog('ERROR', false);

    expect(stdout).not.toHaveBeenCalled();
    expect(stderr).not.toHaveBeenCalled();
  });
});
