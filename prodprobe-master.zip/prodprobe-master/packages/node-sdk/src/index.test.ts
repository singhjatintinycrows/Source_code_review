import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';

const mocks = vi.hoisted(() => {
  const uploaderOptions: Array<{
    distLocation: string;
    sourceMapDir?: string;
    appRoot: string;
  }> = [];
  const uploadAll = vi.fn();
  const brokerClient = {
    createUploadStream: vi.fn(),
    getProbes: vi.fn(),
    getSourceMapStatus: vi.fn(),
    markSourceMapComplete: vi.fn(),
    reportTelemetry: vi.fn(),
    shutdown: vi.fn(),
  };
  const inspectorEngine = {
    disconnect: vi.fn(),
    getStats: vi.fn(() => ({ hits: 0, skips: 0 })),
    resume: vi.fn(),
    setGlobalConfig: vi.fn(),
    setProbes: vi.fn(),
    suspend: vi.fn(),
  };

  class MockBrokerClient {
    constructor() {
      Object.assign(this, brokerClient);
    }
  }

  class MockInspectorEngine {
    constructor() {
      Object.assign(this, inspectorEngine);
    }
  }

  class MockQuotaManager {}

  class MockSafetyMonitor {
    start = vi.fn();
    stop = vi.fn();
  }

  class MockSourceMapUploader {
    uploadAll = uploadAll;
    constructor(options: {
      distLocation: string;
      sourceMapDir?: string;
      appRoot: string;
    }) {
      uploaderOptions.push(options);
    }
  }

  return {
    brokerClient,
    inspectorEngine,
    uploadAll,
    uploaderOptions,
    MockBrokerClient,
    MockInspectorEngine,
    MockQuotaManager,
    MockSafetyMonitor,
    MockSourceMapUploader,
  };
});

vi.mock('./core/broker.js', () => ({
  BrokerClient: mocks.MockBrokerClient,
}));

vi.mock('./core/inspector.js', () => ({
  InspectorEngine: mocks.MockInspectorEngine,
}));

vi.mock('./core/quota.js', () => ({
  QuotaManager: mocks.MockQuotaManager,
}));

vi.mock('./core/safety.js', () => ({
  AgentHealth: {
    GREEN: 'GREEN',
    RED: 'RED',
    YELLOW: 'YELLOW',
  },
  SafetyMonitor: mocks.MockSafetyMonitor,
}));

vi.mock('./core/source-map-uploader.js', () => ({
  SourceMapUploader: mocks.MockSourceMapUploader,
}));

import { HyperProbe } from './index.js';

const environment = { ...process.env };
const startOptions = {
  serviceId: '8fad1ef4-75c9-4a07-857f-5e9cd7b07660',
  environment: 'test',
  brokerUrl: 'https://broker.example.com',
  commitSha: 'commit',
  appRoot: 'services/posts',
  distLocation: '',
};

async function startAndGetUploaderOptions(
  options: typeof startOptions & { sourceMapDir?: string },
): Promise<{ distLocation: string; sourceMapDir?: string; appRoot: string }> {
  HyperProbe.start(options);
  await vi.waitFor(() => expect(mocks.uploaderOptions).toHaveLength(1));
  return mocks.uploaderOptions[0];
}

beforeEach(() => {
  mocks.uploaderOptions.length = 0;
  mocks.uploadAll.mockResolvedValue(1);
  mocks.brokerClient.getProbes.mockResolvedValue({
    probes: [],
    nextSyncMs: 60000,
  });
  mocks.brokerClient.getSourceMapStatus.mockResolvedValue({
    isComplete: false,
    isUploader: true,
  });
  mocks.brokerClient.markSourceMapComplete.mockResolvedValue(undefined);
  mocks.inspectorEngine.setProbes.mockResolvedValue([]);
  delete process.env.HYPERPROBE_DISABLED;
  delete process.env.HYPERPROBE_APP_ROOT;
  delete process.env.HYPERPROBE_DIST_LOCATION;
  delete process.env.HYPERPROBE_SOURCE_MAP_DIR;
});

afterEach(() => {
  HyperProbe.shutdown();
  process.env = { ...environment };
  vi.clearAllMocks();
});

describe('HyperProbe source-map upload configuration', () => {
  it('preserves an explicit empty appRoot over the environment value', async () => {
    process.env.HYPERPROBE_APP_ROOT = 'services/ignored';

    const uploaderOptions = await startAndGetUploaderOptions({
      ...startOptions,
      appRoot: '',
    });

    expect(uploaderOptions.appRoot).toBe('');
  });

  it('preserves an explicit empty distLocation over the environment value', async () => {
    process.env.HYPERPROBE_DIST_LOCATION = 'dist';

    const uploaderOptions = await startAndGetUploaderOptions(startOptions);

    expect(uploaderOptions.distLocation).toBe('');
  });

  it('forwards an explicit sourceMapDir over the environment value', async () => {
    process.env.HYPERPROBE_SOURCE_MAP_DIR = '/app/ignored-dist';

    const uploaderOptions = await startAndGetUploaderOptions({
      ...startOptions,
      sourceMapDir: 'dist',
    });

    expect(uploaderOptions.sourceMapDir).toBe('dist');
  });

  it('forwards HYPERPROBE_SOURCE_MAP_DIR when no option is supplied', async () => {
    process.env.HYPERPROBE_SOURCE_MAP_DIR = '/app/dist';

    const uploaderOptions = await startAndGetUploaderOptions(startOptions);

    expect(uploaderOptions.sourceMapDir).toBe('/app/dist');
  });

  it('leaves sourceMapDir undefined when no option or environment value is set', async () => {
    const uploaderOptions = await startAndGetUploaderOptions(startOptions);

    expect(uploaderOptions).toHaveProperty('sourceMapDir', undefined);
  });
});
