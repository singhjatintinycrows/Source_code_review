import * as os from 'node:os';
import type {
  AgentGlobalConfig,
  Probe,
  TelemetryEvent,
} from '@hyperprobe/protos';
import debug from 'debug';
import { BrokerClient } from './core/broker.js';
import { InspectorEngine } from './core/inspector.js';
import { QuotaManager } from './core/quota.js';
import { AgentHealth, SafetyMonitor } from './core/safety.js';
import { SourceMapUploader } from './core/source-map-uploader.js';
import type { HyperProbeOptions } from './types/index.js';

const log = debug('hyperprobe:agent');
const logStats = debug('hyperprobe:stats');
const logSafety = debug('hyperprobe:safety');
const logBroker = debug('hyperprobe:broker');

const parseEnvInt = (
  key: string,
  defaultValue?: number,
): number | undefined => {
  const val = process.env[key];
  if (val === undefined || val === '') return defaultValue;
  const parsed = parseInt(val, 10);
  return Number.isNaN(parsed) ? defaultValue : parsed;
};

const UUID_REGEX =
  /^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;

function isValidBrokerUrl(url: string): boolean {
  if (!url || url.trim() === '') return false;

  if (url.startsWith('http://') || url.startsWith('https://')) {
    try {
      const u = new URL(url);
      return !url.endsWith('/') && u.search === '' && u.hostname !== '';
    } catch {
      return false;
    }
  }

  // Raw gRPC targets should have no schema, no path, and no query parameters
  return !url.includes('://') && !url.includes('/') && !url.includes('?');
}

export class HyperProbeAgent {
  private static instance?: HyperProbeAgent;
  private options!: HyperProbeOptions;
  private brokerClient!: BrokerClient;
  private inspectorEngine!: InspectorEngine;
  private quotaManager!: QuotaManager;
  private safetyMonitor!: SafetyMonitor;
  private globalConfig!: AgentGlobalConfig;
  private telemetryQueue: TelemetryEvent[] = [];
  private activeProbes: Map<string, Probe> = new Map();
  private localHits: Map<string, number> = new Map();
  private syncIntervalId?: NodeJS.Timeout;
  private currentSyncIntervalMs: number = 60000;
  private flushIntervalId?: NodeJS.Timeout;
  private statsIntervalId?: NodeJS.Timeout;
  private cooldownTimeout?: NodeJS.Timeout;
  private sourceMapHandshakeTimer?: NodeJS.Timeout;
  private isShutdown = false;
  private isSourceMapUploaded = false;
  private appRoot = '';
  private distLocation = '';
  private lastSyncTimestamp = 0;
  private hasSyncedSuccessfully = false;
  private isAgentDisabled = false;

  private constructor() {}

  public static start(options: HyperProbeOptions) {
    if (HyperProbeAgent.instance) {
      log('Agent already started.');
      return;
    }

    if (process.env.HYPERPROBE_DISABLED?.trim().toUpperCase() === 'YES') {
      console.log(
        '[HyperProbe] Explicitly disabled via process.env.HYPERPROBE_DISABLED.',
      );
      return;
    }

    const commitSha = options.commitSha || process.env.GIT_COMMIT;
    if (!commitSha || commitSha === 'unknown') {
      console.error(
        '\x1b[1m\x1b[33m⚠️  [HyperProbe] CRITICAL: Failed to start agent. A valid "commitSha" is required via options or the GIT_COMMIT environment variable to ensure accurate source map resolution and prevent cross-deployment collisions.\x1b[0m',
      );
      return;
    }
    options.commitSha = commitSha;

    if (options.serviceId && !UUID_REGEX.test(options.serviceId)) {
      const allowNonUuid =
        options.allowNonUuid ??
        process.env.HYPERPROBE_ALLOW_NON_UUID?.trim().toLowerCase() === 'yes';

      if (!allowNonUuid) {
        console.error(
          '\x1b[1m\x1b[33m⚠️  [HyperProbe] CRITICAL: Failed to start agent. serviceId is not a valid UUIDv4. Set HYPERPROBE_ALLOW_NON_UUID=yes to allow non-UUID identifiers.\x1b[0m',
        );
        return;
      }
      console.warn(
        '\x1b[1m\x1b[33m⚠️  [HyperProbe] WARN: serviceId is not a valid UUIDv4, please check again.\x1b[0m',
      );
    }

    if (options.brokerUrl && !isValidBrokerUrl(options.brokerUrl)) {
      console.error(
        `\x1b[1m\x1b[33m⚠️  [HyperProbe] CRITICAL: Failed to start agent. Invalid brokerUrl "${options.brokerUrl}". It must be a valid URL (http:// or https://) or a raw gRPC target (e.g. localhost:60051), with no query parameters and no trailing slash.\x1b[0m`,
      );
      return;
    }

    // Auto-detection of AWS Lambda environment
    const isAwsLambda = !!process.env.AWS_LAMBDA_FUNCTION_NAME;
    const isLocalEmulator =
      process.env.IS_OFFLINE === 'true' || process.env.AWS_SAM_LOCAL === 'true';
    const isEphemeralLambda =
      (options.isLambda ?? isAwsLambda) && !isLocalEmulator;

    // Pre-flight Memory Fail-Safe for Low-Memory Lambdas
    if (isEphemeralLambda) {
      const freeMemMB = os.freemem() / (1024 * 1024);
      if (freeMemMB < 15) {
        console.warn(
          `\x1b[1m\x1b[33m⚠️  [HyperProbe Lambda] WARN: Container free memory is extremely low (${freeMemMB.toFixed(1)}MB). ` +
            'Disabling debugger agent to prevent Out-of-Memory (OOM) crashes.\x1b[0m',
        );
        HyperProbeAgent.instance = new HyperProbeAgent();
        HyperProbeAgent.instance.isAgentDisabled = true;
        return;
      }
    }

    HyperProbeAgent.instance = new HyperProbeAgent();
    HyperProbeAgent.instance.init(options, isEphemeralLambda);
  }

  private init(options: HyperProbeOptions, isEphemeralLambda = false) {
    this.options = {
      ...options,
      maxQueueSize:
        options.maxQueueSize ?? parseEnvInt('HYPERPROBE_MAX_QUEUE_SIZE') ?? 100,
      flushIntervalMs:
        options.flushIntervalMs ??
        parseEnvInt('HYPERPROBE_FLUSH_INTERVAL_MS') ??
        1000,
      hitsPerSec:
        options.hitsPerSec ?? parseEnvInt('HYPERPROBE_HITS_PER_SEC') ?? 10,
      bandwidthKbPerSec:
        options.bandwidthKbPerSec ??
        parseEnvInt('HYPERPROBE_BANDWIDTH_KB_PER_SEC') ??
        1024,
      maxLagMs: options.maxLagMs ?? parseEnvInt('HYPERPROBE_MAX_LAG_MS') ?? 80,
      pauseBudgetMs:
        options.pauseBudgetMs ??
        parseEnvInt('HYPERPROBE_PAUSE_BUDGET_MS') ??
        30,
      cooldownSec:
        options.cooldownSec ?? parseEnvInt('HYPERPROBE_COOLDOWN_SEC') ?? 10,
      syncIntervalMs:
        options.syncIntervalMs ??
        parseEnvInt('HYPERPROBE_SYNC_INTERVAL_MS') ??
        60000,
      sourceMapDir:
        options.sourceMapDir ?? process.env.HYPERPROBE_SOURCE_MAP_DIR,
    };

    this.appRoot = options.appRoot ?? process.env.HYPERPROBE_APP_ROOT ?? '';
    this.distLocation =
      options.distLocation ?? process.env.HYPERPROBE_DIST_LOCATION ?? '';

    // Initialize Global Config from options or env
    this.globalConfig = {
      // FIXME: multiple regexes cant have comma (,) as of now, we should use a better way to handle this
      redactKeys:
        options.redactKeys ||
        (process.env.HYPERPROBE_REDACT_KEYS
          ? process.env.HYPERPROBE_REDACT_KEYS.split(',')
              .map((k) => k.trim())
              .filter(Boolean)
          : [
              'password',
              'secret',
              'token',
              'authorization',
              'cookie',
              'key',
              'signature',
            ]),
      redactValues:
        options.redactValues ||
        (process.env.HYPERPROBE_REDACT_VALUES
          ? process.env.HYPERPROBE_REDACT_VALUES.split(',')
              .map((v) => v.trim())
              .filter(Boolean)
          : []),
      maxObjectDepth:
        options.maxObjectDepth ??
        parseEnvInt('HYPERPROBE_MAX_OBJECT_DEPTH') ??
        3,
      maxArrayLength:
        options.maxArrayLength ??
        parseEnvInt('HYPERPROBE_MAX_ARRAY_LENGTH') ??
        3,
      stackFrameDepth:
        options.stackFrameDepth ??
        parseEnvInt('HYPERPROBE_STACK_FRAME_DEPTH') ??
        3,
      maxObjectProperties:
        options.maxObjectProperties ??
        parseEnvInt('HYPERPROBE_MAX_OBJECT_PROPERTIES') ??
        50,
      maxStringLength:
        options.maxStringLength ??
        parseEnvInt('HYPERPROBE_MAX_STRING_LENGTH') ??
        1024,
      captureClosures:
        options.captureClosures ??
        (process.env.HYPERPROBE_CAPTURE_CLOSURES
          ? process.env.HYPERPROBE_CAPTURE_CLOSURES === 'true'
          : false),
    };

    this.quotaManager = new QuotaManager(
      this.options.hitsPerSec,
      (this.options.bandwidthKbPerSec || 200) * 1024,
    );

    this.safetyMonitor = new SafetyMonitor(
      this.handleHealthChange.bind(this),
      this.options.maxLagMs,
      this.options.pauseBudgetMs,
      isEphemeralLambda,
    );

    const enableKeepAliveConfig =
      this.options.enableKeepAlive ??
      (process.env.HYPERPROBE_ENABLE_KEEP_ALIVE
        ? process.env.HYPERPROBE_ENABLE_KEEP_ALIVE === 'true'
        : null);
    const enableKeepAlive = enableKeepAliveConfig ?? !isEphemeralLambda;

    this.brokerClient = new BrokerClient(
      this.options.brokerUrl,
      this.options.serviceId,
      this.options.environment,
      this.options.commitSha!,
      isEphemeralLambda,
      enableKeepAlive,
    );

    this.inspectorEngine = new InspectorEngine(
      this.quotaManager,
      (ms) => this.safetyMonitor.reportPauseDuration(ms),
      this.handleCapture.bind(this),
      this.options.setTraceId,
      this.appRoot,
    );
    this.inspectorEngine.setGlobalConfig(this.globalConfig);

    if (isEphemeralLambda) {
      log(
        'Running in Ephemeral AWS Lambda Mode. Status always would be GREEN.',
      );
      // this.safetyMonitor.start();
    } else {
      this.safetyMonitor.start();
      this.startTimers();
      this.syncWithBroker(); // Initial sync
      this.initSourceMapSync(); // One-time source map handshake
    }
    log(
      'Agent started for %s in %s',
      this.options.serviceId,
      this.options.environment,
    );
    if (isEphemeralLambda) {
      log(
        'Safety Guardrails: Hits=%d/s, BW=%dKB/s',
        this.options.hitsPerSec,
        this.options.bandwidthKbPerSec,
      );
    } else {
      log(
        'Safety Guardrails: Hits=%d/s, BW=%dKB/s, Lag=%dms, Budget=%dms/s',
        this.options.hitsPerSec,
        this.options.bandwidthKbPerSec,
        this.options.maxLagMs,
        this.options.pauseBudgetMs,
      );
    }
  }

  private async initSourceMapSync(attempt = 1) {
    if (this.isShutdown || this.isSourceMapUploaded) return;

    try {
      logBroker('Source map handshake attempt %d', attempt);
      const { isUploader, isComplete } =
        await this.brokerClient.getSourceMapStatus();

      if (isComplete) {
        logBroker('Source map is already complete in backend.');
        this.isSourceMapUploaded = true;
        return;
      }

      if (isUploader) {
        logBroker('This instance is designated as the source map uploader.');
        const uploader = new SourceMapUploader({
          serviceId: this.options.serviceId,
          environment: this.options.environment,
          commitSha: this.options.commitSha!,
          appRoot: this.appRoot,
          distLocation: this.distLocation,
          sourceMapDir: this.options.sourceMapDir,
          createUploadStream: this.brokerClient.createUploadStream.bind(
            this.brokerClient,
          ),
        });
        try {
          const uploadedCount = await uploader.uploadAll();
          if (uploadedCount > 0) {
            await this.brokerClient.markSourceMapComplete();
            this.isSourceMapUploaded = true;
            logBroker('Source map upload completed.');
          } else {
            logBroker('No source maps found; leaving upload incomplete.');
          }
        } catch (err) {
          logBroker('Failed to upload source maps: %O', err);
          // If upload fails, we don't set isSourceMapUploaded = true so it can be retried or tried by another instance
        }
        return;
      }

      // If neither complete nor uploader, another instance is uploading.
      // Poll every 20 seconds, max 10 times.
      if (attempt < 10) {
        logBroker(
          'Another instance is uploading source maps. Polling in 20s...',
        );
        this.sourceMapHandshakeTimer = setTimeout(
          () => this.initSourceMapSync(attempt + 1),
          20000,
        );
        this.sourceMapHandshakeTimer.unref();
      } else {
        logBroker('Source map handshake timed out after 10 attempts.');
      }
    } catch (err) {
      logBroker('Error during source map handshake: %O', err);
      // Retry after delay
      if (attempt < 5) {
        this.sourceMapHandshakeTimer = setTimeout(
          () => this.initSourceMapSync(attempt + 1),
          5000,
        );
        this.sourceMapHandshakeTimer.unref();
      }
    }
  }

  private handleHealthChange(health: AgentHealth, reason?: string) {
    if (this.isShutdown) return;

    if (health === AgentHealth.RED) {
      logSafety('Safety Shield Triggered: RED Status. %s', reason || '');
      this.inspectorEngine.suspend().catch(() => {});

      const cooldownMs = (this.options.cooldownSec || 10) * 1000;
      if (this.cooldownTimeout) clearTimeout(this.cooldownTimeout);
      this.cooldownTimeout = setTimeout(() => {
        logSafety(
          'Cooldown period ended. Attempting to resume instrumentation...',
        );
        this.inspectorEngine.resume().catch(() => {});
      }, cooldownMs);
      this.cooldownTimeout.unref();
    } else if (health === AgentHealth.YELLOW) {
      logSafety(
        'Safety Warning: YELLOW Status (Moderate Overhead). %s',
        reason || '',
      );
    } else if (health === AgentHealth.GREEN) {
      logSafety('Status back to GREEN. %s', reason || '');
    }
  }

  private startTimers() {
    this.currentSyncIntervalMs = this.options.syncIntervalMs!;
    this.syncIntervalId = setInterval(
      this.syncWithBroker.bind(this),
      this.currentSyncIntervalMs,
    );
    this.syncIntervalId.unref();
    this.flushIntervalId = setInterval(
      this.flushTelemetry.bind(this),
      this.options.flushIntervalMs,
    );
    this.flushIntervalId.unref();
    this.statsIntervalId = setInterval(() => {
      const stats = this.inspectorEngine.getStats();
      if (stats.hits > 0 || stats.skips > 0) {
        logStats('Probes Hit: %d, Probes Skipped: %d', stats.hits, stats.skips);
      }
    }, 5000);
    this.statsIntervalId.unref();
  }

  private stopTimers() {
    if (this.syncIntervalId) clearInterval(this.syncIntervalId);
    if (this.flushIntervalId) clearInterval(this.flushIntervalId);
    if (this.statsIntervalId) clearInterval(this.statsIntervalId);
    if (this.cooldownTimeout) clearTimeout(this.cooldownTimeout);
    if (this.sourceMapHandshakeTimer)
      clearTimeout(this.sourceMapHandshakeTimer);
    this.safetyMonitor?.stop();
  }

  public static shutdown() {
    const instance = HyperProbeAgent.instance;
    if (!instance) {
      log('Agent not started. Nothing to shut down.');
      return;
    }

    if (instance.isShutdown) {
      log('Agent already shut down.');
      return;
    }

    instance.isShutdown = true;

    if (instance.isAgentDisabled) {
      HyperProbeAgent.instance = undefined;
      log('Disabled agent shut down.');
      return;
    }

    instance.stopTimers();
    instance.inspectorEngine.disconnect();
    instance.brokerClient.shutdown();
    HyperProbeAgent.instance = undefined;
    log('Agent shut down.');
  }

  private async syncWithBroker(timeoutMs?: number): Promise<boolean> {
    logBroker('syncWithBroker started');
    if (this.isShutdown || this.isAgentDisabled) return false;

    try {
      logBroker(
        `syncWithBroker: calling brokerClient.getProbes() ${timeoutMs ? `with timeout ${timeoutMs}` : ''}`,
      );
      const {
        probes,
        nextSyncMs: _nextSyncMs,
        globalConfig,
      } = await this.brokerClient.getProbes(timeoutMs);
      logBroker('syncWithBroker: got %d probes from broker', probes.length);

      if (globalConfig) {
        this.globalConfig = {
          redactKeys:
            globalConfig.redactKeys && globalConfig.redactKeys.length > 0
              ? globalConfig.redactKeys
              : this.globalConfig.redactKeys,
          redactValues:
            globalConfig.redactValues && globalConfig.redactValues.length > 0
              ? globalConfig.redactValues
              : this.globalConfig.redactValues,
          maxObjectDepth:
            globalConfig.maxObjectDepth ?? this.globalConfig.maxObjectDepth,
          maxArrayLength:
            globalConfig.maxArrayLength ?? this.globalConfig.maxArrayLength,
          stackFrameDepth:
            globalConfig.stackFrameDepth ?? this.globalConfig.stackFrameDepth,
          maxObjectProperties:
            globalConfig.maxObjectProperties ??
            this.globalConfig.maxObjectProperties,
          maxStringLength:
            globalConfig.maxStringLength ?? this.globalConfig.maxStringLength,
          captureClosures:
            globalConfig.captureClosures ?? this.globalConfig.captureClosures,
        };
        this.inspectorEngine.setGlobalConfig(this.globalConfig);
      }

      if (this.isShutdown) return false;

      const serverProbeIds = new Set(probes.map((p) => p.id));

      // Cleanup stale local state for probes no longer on server
      for (const id of Array.from(this.activeProbes.keys())) {
        if (!serverProbeIds.has(id)) {
          logBroker('Removing stale probe %s', id);
          this.activeProbes.delete(id);
        }
      }
      for (const id of Array.from(this.localHits.keys())) {
        if (!serverProbeIds.has(id)) {
          this.localHits.delete(id);
        }
      }

      // Update local hit limits
      const toApply: Probe[] = [];
      for (const p of probes) {
        const hits = this.localHits.get(p.id) || 0;
        const now = BigInt(Date.now());
        const isExpired = p.expiryTime <= now;
        logBroker(
          'Checking probe %s: hits=%d/%d, isExpired=%s',
          p.id,
          hits,
          p.hitLimit,
          isExpired,
        );
        if (hits < p.hitLimit && !isExpired) {
          toApply.push(p);
          this.activeProbes.set(p.id, p);
        } else {
          this.activeProbes.delete(p.id);
        }
      }

      logBroker('Found %d probes to apply locally', toApply.length);

      const failed = await this.inspectorEngine.setProbes(toApply);
      logBroker('Applied probes. Failed: %d', failed.length);
      if (this.isShutdown) return false;
      if (failed.length > 0) {
        logBroker('Failed to apply %d probes.', failed.length);
      }

      // Adjust jitter - disabled for now
      // if (nextSyncMs && nextSyncMs !== this.currentSyncIntervalMs && !this.isShutdown) {
      //   if (this.syncIntervalId) clearInterval(this.syncIntervalId);
      //   this.syncIntervalId = setInterval(this.syncWithBroker.bind(this), nextSyncMs);
      //   this.currentSyncIntervalMs = nextSyncMs;
      // }
      return true;
    } catch (err) {
      logBroker('Failed to sync with broker: %O', err);
      return false;
    }
  }

  private handleCapture(event: TelemetryEvent) {
    if (this.isShutdown || this.isAgentDisabled) return;
    log('Captured event for probe %s', event.probeId);
    const probe = this.activeProbes.get(event.probeId);
    if (!probe) return;

    // Always increment hits even if queue is full to ensure hitLimit acts as a safety fuse.
    const hits = (this.localHits.get(event.probeId) || 0) + 1;
    this.localHits.set(event.probeId, hits);

    if (this.telemetryQueue.length < (this.options.maxQueueSize || 100)) {
      this.telemetryQueue.push(event);
    } else {
      log('Telemetry queue full. Dropping event for probe %s.', event.probeId);
    }

    // Always enforce hitLimit to stop overhead.
    // We purposefully skip checking expiryTime here to save computation;
    // it's handled during the periodic syncWithBroker.
    if (hits >= probe.hitLimit) {
      this.activeProbes.delete(event.probeId);
      const remainingProbes = Array.from(this.activeProbes.values());
      this.inspectorEngine.setProbes(remainingProbes).catch(() => {});
    }
  }

  public getTelemetryQueueLength(): number {
    return this.telemetryQueue.length;
  }

  /**
   * Manually fetches and applies active probes from the broker.
   * Employs a cache TTL of 10s by default to protect the broker and request performance.
   */
  public async forceSync(timeoutMs?: number): Promise<void> {
    if (this.isShutdown || this.isAgentDisabled) return;

    const cacheTtlMs = this.options.lambdaSyncCacheTtlMs ?? 10000;
    const now = Date.now();

    if (
      this.hasSyncedSuccessfully &&
      now - this.lastSyncTimestamp < cacheTtlMs
    ) {
      logBroker(
        'Skipping broker sync. Reusing cached active probes (TTL remaining: %dms).',
        cacheTtlMs - (now - this.lastSyncTimestamp),
      );
      return;
    }

    logBroker('Force-syncing probes from broker...');
    const success = await this.syncWithBroker(timeoutMs);
    if (success) {
      this.lastSyncTimestamp = Date.now();
      this.hasSyncedSuccessfully = true;
    } else {
      throw new Error('Failed to sync probes from broker');
    }
  }

  /**
   * Manually flushes any queued telemetry events directly to the broker.
   * Ensures all captured snapshots reach the destination before process freeze.
   * @param timeoutMs Optional timeout in ms. If exceeded, flush is abandoned and events are re-queued.
   */
  public async forceFlush(timeoutMs?: number): Promise<void> {
    if (this.isShutdown || this.isAgentDisabled) return;

    if (this.telemetryQueue.length === 0) {
      logBroker('No queued telemetry events to flush.');
      return;
    }

    logBroker(
      'Force-flushing %d telemetry events to broker%s...',
      this.telemetryQueue.length,
      timeoutMs ? ` (timeout: ${timeoutMs}ms)` : '',
    );
    await this.flushTelemetry(timeoutMs);
  }

  private async flushTelemetry(timeoutMs?: number) {
    if (this.isShutdown || this.telemetryQueue.length === 0) return;

    // Swap queues to allow main thread to keep capturing
    const batch = [...this.telemetryQueue];
    this.telemetryQueue = [];

    logBroker('Flushing %d telemetry events to broker...', batch.length);

    try {
      const finishedProbeIds = await this.brokerClient.reportTelemetry(
        batch,
        timeoutMs,
      );
      if (this.isShutdown) return;
      logBroker(
        'Successfully flushed %d telemetry events to broker',
        batch.length,
      );

      // If broker says they are globally finished, remove them locally
      if (finishedProbeIds && finishedProbeIds.length > 0) {
        let changed = false;
        for (const id of finishedProbeIds) {
          if (this.activeProbes.has(id)) {
            this.activeProbes.delete(id);
            changed = true;
          }
        }
        if (changed) {
          await this.inspectorEngine
            .setProbes(Array.from(this.activeProbes.values()))
            .catch(() => {});
        }
      }
    } catch (err) {
      if (this.isShutdown) return;
      logBroker('Failed to flush telemetry: %O', err);
      // Re-queue the failed batch (rudimentary retry)
      if (
        this.telemetryQueue.length + batch.length <=
        (this.options.maxQueueSize || 100)
      ) {
        this.telemetryQueue.unshift(...batch);
      }
    }
  }

  public static getInstance(): HyperProbeAgent | undefined {
    return HyperProbeAgent.instance;
  }

  public getIsAgentDisabled(): boolean {
    return this.isAgentDisabled;
  }
}

export const HyperProbe = HyperProbeAgent;

// Export lambda support APIs
export {
  stopLambda,
  wrapLambda,
} from './core/lambda.js';
