export interface HyperProbeOptions {
  /** UUIDv4 service identifier provided by the HyperProbe dashboard. */
  serviceId: string;
  /** Allow a legacy non-UUID service ID. The environment equivalent is HYPERPROBE_ALLOW_NON_UUID=yes. */
  allowNonUuid?: boolean;
  environment: string;
  brokerUrl: string;
  commitSha?: string;
  maxQueueSize?: number;
  flushIntervalMs?: number;
  flushTimeoutMs?: number;
  isLambda?: boolean;
  lambdaSyncCacheTtlMs?: number;
  lambdaSyncTimeoutMs?: number;
  enableKeepAlive?: boolean;
  // Safety Guardrails
  hitsPerSec?: number;
  bandwidthKbPerSec?: number;
  maxLagMs?: number;
  pauseBudgetMs?: number;
  cooldownSec?: number;
  syncIntervalMs?: number;
  appRoot?: string;
  distLocation?: string;
  /**
   * Directory to scan for JavaScript source maps. Relative paths are resolved
   * from `process.cwd()`; absolute paths are supported for container layouts.
   *
   * Defaults to `HYPERPROBE_SOURCE_MAP_DIR`, then `process.cwd()`. For an Nx
   * service running from `/app` with maps at
   * `/app/dist/services/posts/main.js.map`, scope `sourceMapDir` to the service
   * output directory (e.g. `dist/services/posts`), set `appRoot: 'services/posts'`,
   * and leave `distLocation` empty.
   */
  sourceMapDir?: string;

  // Snapshot & Log Controls
  redactKeys?: string[];
  redactValues?: string[];
  maxObjectDepth?: number;
  maxArrayLength?: number;
  stackFrameDepth?: number;
  maxObjectProperties?: number;
  maxStringLength?: number;
  captureClosures?: boolean;
  setTraceId?: () => string | undefined;
}
