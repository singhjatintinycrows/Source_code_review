const pkgJson = require("./package.json");
const fs = require("fs");

// delete pkgJson.dependencies;
delete pkgJson.dependencies["stream-json"];
delete pkgJson.dependencies["stream-chain"];
delete pkgJson.dependencies["debug"];
delete pkgJson.dependencies["@hyperprobe/protos"];
delete pkgJson.devDependencies;
delete pkgJson.scripts;

fs.writeFileSync("./package.json", JSON.stringify(pkgJson, null, 2));