import { getConfig } from '@hyperprobe/common';
import { getDatabase, ProbeType } from '@hyperprobe/database';
import { createTRPCProxyClient, httpBatchLink } from '@trpc/client';
import type { AppRouter } from 'backend';
import { type ExecaChildProcess, execa } from 'execa';
import path from 'path';
import { createClient } from 'redis';
import superjson from 'superjson';
import { fileURLToPath } from 'url';
import { afterAll, beforeAll, expect, test } from 'vitest';
import waitOn from 'wait-on';
import { getAdminToken } from './auth-helper.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(__dirname, '../..');
const SERVICE_ID = 'demo-app-redaction';
const COMMIT_SHA = `e2e-redaction-sha-${Date.now()}`;

const trpc = createTRPCProxyClient<AppRouter>({
  transformer: superjson,
  links: [
    httpBatchLink({
      url: 'http://localhost:4001/trpc',
      async headers() {
        const token = await getAdminToken();
        return {
          Authorization: `Bearer ${token}`,
        };
      },
    }),
  ],
});

let demoAppProcess: ExecaChildProcess;

beforeAll(async () => {
  // 1. Reset DB
  console.log('Resetting database...');
  await getDatabase().logEvent.deleteMany();
  await getDatabase().snapshotEvent.deleteMany();
  await getDatabase().metricEvent.deleteMany();
  await getDatabase().probe.deleteMany();
  await (getDatabase() as any).sourceMap.deleteMany();
  await (getDatabase() as any).service.deleteMany();

  console.log('Creating Service...');
  await (getDatabase() as any).service.create({
    data: {
      id: SERVICE_ID,
      name: 'demo-app-redaction',
      sourceMapRequired: true,
    },
  });

  // 2. Reset Redis
  console.log('Resetting Redis...');
  const config = await getConfig();
  const redis = createClient({ url: config.redisUrl });
  await redis.connect();
  await redis.flushDb();
  await redis.quit();

  // 3. Start demo-app with unique service name
  console.log(
    `Starting demo-app for ${SERVICE_ID} with COMMIT_SHA=${COMMIT_SHA}...`,
  );
  demoAppProcess = execa('node', ['index.js'], {
    cwd: path.resolve(ROOT, 'apps/demo-app/dist'),
    env: {
      ...process.env,
      PORT: '4004',
      HYPERPROBE_ENABLED: 'true',
      HYPERPROBE_SERVICE_ID: SERVICE_ID,
      HYPERPROBE_ENVIRONMENT: 'development',
      HYPERPROBE_BROKER_URL: 'localhost:60051',
      HYPERPROBE_SYNC_INTERVAL_MS: '1000',
      HYPERPROBE_APP_ROOT: 'apps/demo-app',
      HYPERPROBE_DIST_LOCATION: 'dist',
      HYPERPROBE_REDACT_KEYS: 'password,userId',
      HYPERPROBE_MAX_LAG_MS: '5000',
      GIT_COMMIT: COMMIT_SHA,
      HYPERPROBE_SOURCE_MAP_DIR: path.resolve(ROOT, 'apps/demo-app/dist'),
    },
  });
  demoAppProcess.stdout?.pipe(process.stdout);
  demoAppProcess.stderr?.pipe(process.stderr);

  await (waitOn as any)({ resources: ['tcp:localhost:4004'], timeout: 10000 });
  console.log('Demo app ready.');
});

afterAll(async () => {
  if (demoAppProcess) {
    demoAppProcess.kill();
    await new Promise((r) => setTimeout(r, 1000));
  }
});

test('E2E Redaction & Truncation Verification', async () => {
  const expiryTime = Date.now() + 1000 * 60;

  console.log('Waiting for source map upload...');
  let sourceMap: any = null;
  for (let i = 0; i < 20; i++) {
    sourceMap = await (getDatabase() as any).sourceMap.findFirst({
      where: { serviceId: SERVICE_ID, commitSha: COMMIT_SHA },
    });
    if (sourceMap) {
      const smf = await getDatabase().sourceMapFile.findFirst({
        where: {
          serviceId: SERVICE_ID,
          commitSha: COMMIT_SHA,
          resolvedPath: 'apps/demo-app/src/index.ts',
        },
      });
      if (smf) {
        break;
      }
    }
    await new Promise((r) => setTimeout(r, 1000));
  }
  expect(sourceMap).not.toBeNull();

  // 1. Create Snapshot Probe
  console.log('Creating snapshot probe...');
  const snapshotProbe = await trpc.createProbe.mutate({
    commitSha: COMMIT_SHA,
    type: ProbeType.SNAPSHOT,
    serviceId: SERVICE_ID,
    environment: 'development',
    uiFilePath: 'apps/demo-app/src/index.ts',
    uiLineNumber: 29,
    hitLimit: 1,
    expiryTime,
    maxObjectDepth: 2,
    maxArrayLength: 2,
    stackFrameDepth: 5,
  });

  expect(snapshotProbe.success).toBe(true);
  await new Promise((r) => setTimeout(r, 4000));

  // 2. Trigger Checkout
  console.log('Triggering checkout...');
  await fetch('http://localhost:4004/checkout', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      userId: 'user_123',

      items: [
        { name: 'A', sourceMapRequired: true, price: 1, quantity: 1 },
        { name: 'B', sourceMapRequired: true, price: 2, quantity: 1 },
        { name: 'C', sourceMapRequired: true, price: 3, quantity: 1 },
        { name: 'D', sourceMapRequired: true, price: 4, quantity: 1 },
      ],
    }),
  });

  // 3. Verify Snapshot
  console.log('Verifying SNAPSHOT redaction...');
  const snapshots = await pollPostgres(
    () =>
      getDatabase().snapshotEvent.findMany({
        where: { probeId: snapshotProbe.id },
      }),
    1,
  );
  expect(snapshots.length).toBe(1);
  const payload = snapshots[0].payload as any;
  const frame0Scopes = payload.vars[0]; // All scopes of first frame
  const localScope = frame0Scopes.find((s: any) => s.type === 'local');
  expect(localScope).toBeDefined();
  const localVars = localScope.vars;

  const userSession = localVars.userSession;
  expect(userSession).toBeDefined();

  // Verify Redaction
  expect(userSession.password).toBe('[REDACTED Key]');
  expect(localVars.userId).toBe('[REDACTED Key]');

  // Verify Circular Detection
  expect(userSession.circular).toBe('[REF - frame[0].scopes[0].userSession]');

  // Verify Array Truncation or Circular Detection
  const items = localVars.items;
  if (Array.isArray(items)) {
    expect(items.length).toBe(3); // 2 items + truncation message
    expect(items[2]).toContain('more items truncated');
  } else {
    expect(items).toContain('[REF -');
  }

  // Verify Depth (Set to 2)
  expect(userSession.flags[0]).toBe('premium');

  expect(localVars.req.url).toBe('/checkout');

  console.log('E2E Redaction & Truncation Verified!');
});

async function pollPostgres<T>(
  fn: () => Promise<T[]>,
  minCount: number,
): Promise<T[]> {
  for (let i = 0; i < 40; i++) {
    const res = await fn();
    if (res.length >= minCount) return res;
    console.log(
      `Polling DB... attempt ${i + 1}/40, found ${res.length}/${minCount}`,
    );
    await new Promise((r) => setTimeout(r, 1000));
  }
  const finalRes = await fn();
  if (finalRes.length < minCount) {
    throw new Error(
      `Polling timeout: expected ${minCount} records, found ${finalRes.length}`,
    );
  }
  return finalRes;
}
