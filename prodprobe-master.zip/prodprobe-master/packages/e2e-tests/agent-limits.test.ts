import {
  getConfig,
  getConsul,
  HP_DEPLOYMENT_KEYS,
  HP_LICENCE_MEMORY_REFRESH_KEY,
} from '@hyperprobe/common';
import { getDatabase } from '@hyperprobe/database';
import { createTRPCProxyClient, httpBatchLink } from '@trpc/client';
import type { AppRouter } from 'backend';
import jwt from 'jsonwebtoken';
import { createClient } from 'redis';
import superjson from 'superjson';
import { afterAll, beforeAll, expect, test } from 'vitest';
import { getAdminToken } from './auth-helper.js';

const SERVICE_INHERIT_ID = 'e2e-service-inherit';
const SERVICE_LIMITED_ID = 'e2e-service-limited';

const trpc = createTRPCProxyClient<AppRouter>({
  transformer: superjson,
  links: [
    httpBatchLink({
      url: 'http://localhost:4001/trpc',
      async headers() {
        const token = await getAdminToken();
        return {
          Authorization: `Bearer ${token}`,
        };
      },
    }),
  ],
});

let nonAdminToken: string;
const nonAdminTrpc = createTRPCProxyClient<AppRouter>({
  transformer: superjson,
  links: [
    httpBatchLink({
      url: 'http://localhost:4001/trpc',
      async headers() {
        return {
          Authorization: `Bearer ${nonAdminToken}`,
        };
      },
    }),
  ],
});

async function getNonAdminToken() {
  const prisma = getDatabase();
  const sysConfig = await prisma.systemConfig.findFirst({
    where: { id: 'singleton' },
  });

  if (!sysConfig) {
    throw new Error(
      'SystemConfig not found. Backend might not have started yet.',
    );
  }

  const token = jwt.sign(
    {
      userId: 'e2e-non-admin-user-id',
      email: 'non-admin@hyperprobe.io',
      permissions: {
        isAdmin: false,
        permissions: {
          [SERVICE_LIMITED_ID]: 50,
          [SERVICE_INHERIT_ID]: 50,
        },
      },
    },
    sysConfig.tokenSecret,
    { expiresIn: '1h' },
  );

  return token;
}

let redis: any;
let testUserTeamId: string;

beforeAll(async () => {
  console.log('Resetting database...');
  await getDatabase().sourceMap.deleteMany();
  await getDatabase().teamService.deleteMany();
  await getDatabase().service.deleteMany();
  await getDatabase().userTeam.deleteMany();
  await getDatabase().team.deleteMany();
  await getDatabase().user.deleteMany();

  console.log('Creating Services...');
  await getDatabase().service.create({
    data: {
      id: SERVICE_INHERIT_ID,
      name: 'Inherit Service',
      sourceMapRequired: false,
    },
  });

  await getDatabase().service.create({
    data: {
      id: SERVICE_LIMITED_ID,
      name: 'Limited Service',
      sourceMapRequired: false,
      agentLimit: 2,
    },
  });

  console.log('Creating non-admin user and assigning teams...');
  const userTeam = await getDatabase().team.create({
    data: {
      name: 'Non Admin Team',
      isAdminTeam: false,
    },
  });
  testUserTeamId = userTeam.id;

  await getDatabase().user.create({
    data: {
      id: 'e2e-non-admin-user-id',
      email: 'non-admin@hyperprobe.io',
      teams: {
        create: {
          teamId: userTeam.id,
        },
      },
    },
  });

  await getDatabase().teamService.createMany({
    data: [
      { teamId: userTeam.id, serviceId: SERVICE_INHERIT_ID, role: 50 },
      { teamId: userTeam.id, serviceId: SERVICE_LIMITED_ID, role: 50 },
    ],
  });

  console.log('Connecting to Redis...');
  const config = await getConfig();
  redis = createClient({ url: config.redisUrl });
  await redis.connect();

  nonAdminToken = await getNonAdminToken();
});

afterAll(async () => {
  if (redis) {
    await redis.quit();
  }
});

test('Agent Limits: Consul soft limit key auto-rewriting', async () => {
  const consul = getConsul();
  const status = await trpc.license.status.query();
  const maxAgents = status.maxAgents;

  console.log(`License max agents is ${maxAgents}`);

  // Write a value larger than license limit into Consul
  const giantValue = maxAgents + 50;
  console.log(`Setting Consul soft limit to giant value: ${giantValue}`);
  await consul.kv.set(
    HP_DEPLOYMENT_KEYS.HP_SOFT_AGENT_LIMIT,
    String(giantValue),
  );

  // Publish to the memory refresh channel to trigger instantaneous backend sync
  await redis.publish(HP_LICENCE_MEMORY_REFRESH_KEY, '1');

  // Poll Consul until the key is successfully auto-rewritten by the backend (timeout: 3 seconds)
  let rewrittenValue = null;
  const startTime = Date.now();
  const TIMEOUT_MS = 3000;
  while (Date.now() - startTime < TIMEOUT_MS) {
    const item: any = await consul.kv.get(
      HP_DEPLOYMENT_KEYS.HP_SOFT_AGENT_LIMIT,
    );
    if (item && Number(item.Value) === maxAgents) {
      rewrittenValue = Number(item.Value);
      break;
    }
    await new Promise((resolve) => setTimeout(resolve, 50));
  }

  expect(rewrittenValue).toBe(maxAgents);
  console.log('Consul soft limit successfully rewritten and verified.');
});

test('Agent Limits: Admin API visibility and service configuration', async () => {
  // Query service list using admin credentials
  const services = await trpc.services.list.query();

  const limitedService = services.find((s) => s.id === SERVICE_LIMITED_ID);
  expect(limitedService).toBeDefined();
  expect(limitedService?.agentLimit).toBe(2);

  const inheritService = services.find((s) => s.id === SERVICE_INHERIT_ID);
  expect(inheritService).toBeDefined();
  expect(inheritService?.agentLimit).toBeNull();

  // Query service list using non-admin credentials
  const nonAdminServices = await nonAdminTrpc.services.list.query();
  const naLimitedService = nonAdminServices.find(
    (s) => s.id === SERVICE_LIMITED_ID,
  );
  expect(naLimitedService).toBeDefined();
  // Non-admins must NOT see the custom service agent limit (it must be mapped to null/omitted)
  expect(naLimitedService?.agentLimit).toBeNull();

  console.log('Admin-only API visibility verified successfully.');
});

test('Agent Limits: Non-admin creation and update rejection', async () => {
  // 1. Try to CREATE a service with custom agent limit as a non-admin
  let creationErr: any = null;
  try {
    await nonAdminTrpc.services.create.mutate({
      name: 'Non Admin Created Limit',
      teamIds: [testUserTeamId],
      sourceMapRequired: false,
      agentLimit: 10,
    });
  } catch (err: any) {
    creationErr = err;
  }
  expect(creationErr).not.toBeNull();
  expect(creationErr.message).toContain(
    'Only admins can configure agent limit',
  );

  // 2. Try to UPDATE a service with custom agent limit as a non-admin
  let updateErr: any = null;
  try {
    await nonAdminTrpc.services.update.mutate({
      serviceId: SERVICE_LIMITED_ID,
      name: 'Attempt Non Admin Update',
      agentLimit: 5,
    });
  } catch (err: any) {
    updateErr = err;
  }
  expect(updateErr).not.toBeNull();
  expect(updateErr.message).toContain('Only admins can configure agent limit');

  console.log('Non-admin TRPC validation rejections verified successfully.');
});
