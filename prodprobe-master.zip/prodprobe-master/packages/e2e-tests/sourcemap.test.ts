import { getConfig } from '@hyperprobe/common';
import { getDatabase } from '@hyperprobe/database';
import { createTRPCProxyClient, httpBatchLink } from '@trpc/client';
import type { AppRouter } from 'backend';
import { type ExecaChildProcess, execa } from 'execa';
import path from 'path';
import { createClient } from 'redis';
import superjson from 'superjson';
import { fileURLToPath } from 'url';
import { afterAll, beforeAll, expect, test } from 'vitest';
import waitOn from 'wait-on';
import { getAdminToken } from './auth-helper.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(__dirname, '../..');
const SERVICE_ID = 'sourcemap-e2e-service';
const COMMIT_SHA = `e2e-test-sha-${Date.now()}`;

const trpc = createTRPCProxyClient<AppRouter>({
  transformer: superjson,
  links: [
    httpBatchLink({
      url: 'http://localhost:4001/trpc',
      async headers() {
        const token = await getAdminToken();
        return {
          Authorization: `Bearer ${token}`,
        };
      },
    }),
  ],
});

let demoAppProcess: ExecaChildProcess;

beforeAll(async () => {
  // 1. Reset DB
  console.log('Resetting database...');
  await (getDatabase() as any).sourceMap.deleteMany();
  await (getDatabase() as any).service.deleteMany();

  console.log('Creating Service...');
  await (getDatabase() as any).service.create({
    data: {
      id: SERVICE_ID,
      name: 'sourcemap-e2e-service',
      sourceMapRequired: true,
    },
  });
  await getDatabase().probe.deleteMany();

  console.log('Resetting Redis...');
  const config = await getConfig();
  const redis = createClient({ url: config.redisUrl });
  await redis.connect();
  await redis.flushDb();
  await redis.quit();

  // 2. Start demo-app (now using actual built index.js and its real source map)
  console.log(`Starting demo-app with COMMIT_SHA=${COMMIT_SHA}...`);
  demoAppProcess = execa('node', ['index.js'], {
    cwd: path.resolve(ROOT, 'apps/demo-app/dist'),
    env: {
      ...process.env,
      PORT: '4006',
      HYPERPROBE_ENABLED: 'true',
      HYPERPROBE_SERVICE_ID: SERVICE_ID,
      HYPERPROBE_ENVIRONMENT: 'development',
      HYPERPROBE_BROKER_URL: 'localhost:60051',
      GIT_COMMIT: COMMIT_SHA,
      HYPERPROBE_APP_ROOT: 'apps/demo-app',
      HYPERPROBE_DIST_LOCATION: 'dist',
      HYPERPROBE_SYNC_INTERVAL_MS: '1000',
      HYPERPROBE_SOURCE_MAP_DIR: path.resolve(ROOT, 'apps/demo-app/dist'),
      DEBUG: 'hyperprobe:*',
    },
  });
  demoAppProcess.stdout?.pipe(process.stdout);
  demoAppProcess.stderr?.pipe(process.stderr);

  await (waitOn as any)({ resources: ['tcp:localhost:4006'], timeout: 20000 });
  console.log('Demo app ready.');
});

afterAll(async () => {
  if (demoAppProcess) {
    demoAppProcess.kill();
  }
});

test('Source Map E2E: SDK should upload and Backend should resolve coordinates accurately', async () => {
  console.log('Waiting for source map upload...');

  let sourceMap: any = null;
  for (let i = 0; i < 20; i++) {
    sourceMap = await (getDatabase() as any).sourceMap.findFirst({
      where: {
        serviceId: SERVICE_ID,
        commitSha: COMMIT_SHA,
        fileName: 'apps/demo-app/dist/index.js.map',
      },
    });
    if (sourceMap) {
      const smf = await getDatabase().sourceMapFile.findFirst({
        where: {
          serviceId: SERVICE_ID,
          commitSha: COMMIT_SHA,
          resolvedPath: 'apps/demo-app/src/index.ts',
        },
      });
      if (smf) {
        break;
      }
    }
    await new Promise((r) => setTimeout(r, 1000));
  }

  expect(sourceMap).not.toBeNull();
  expect(sourceMap.fileName).toBe('apps/demo-app/dist/index.js.map');

  // Verify content was filtered
  const parsed = sourceMap.content;
  expect(
    parsed.sourcesContent === undefined || parsed.sourcesContent.length === 0,
  ).toBe(true);
  expect(parsed.sources).toEqual(['../src/index.ts']);

  console.log('Verifying coordinate resolution via createProbe...');

  // Test resolution: apps/demo-app/src/index.ts Line 21 (BLANK LINE) maps to index.js Line 18 (let cartTotal = 0)
  // This verifies that unmapped lines seamlessly fall forward to the next available generated code
  const probe1Res = await trpc.createProbe.mutate({
    serviceId: SERVICE_ID,
    environment: 'development',
    commitSha: COMMIT_SHA,
    type: 'LOG' as any,
    uiFilePath: 'apps/demo-app/src/index.ts',
    uiLineNumber: 10,
    uiColumnNumber: 1,
    template: 'TEST_LOG_1',
    expiryTime: Date.now() + 60000,
  });

  const probe1 = await (getDatabase() as any).probe.findUnique({
    where: { id: probe1Res.id },
  });

  expect(probe1.runtimeLocation).toBe('apps/demo-app/dist/index.js');
  expect(probe1.runtimeLine).toBe(8);
  expect(probe1.runtimeColumn).toBe(5); // +1 because source-map uses 0-based column, we use 1-based in UI. esbuild emits 'let' at col 4

  // Test resolution: apps/demo-app/src/index.ts Line 41 maps to index.js Line 33 (res.json({ cartTotal ... }))
  const probe2Res = await trpc.createProbe.mutate({
    serviceId: SERVICE_ID,
    environment: 'development',
    commitSha: COMMIT_SHA,
    type: 'LOG' as any,
    uiFilePath: 'apps/demo-app/src/index.ts',
    uiLineNumber: 30,
    uiColumnNumber: 1,
    template: 'TEST_LOG_2',
    expiryTime: Date.now() + 60000,
  });

  expect(probe2Res.success).toBe(true);
  const probe2 = await (getDatabase() as any).probe.findUnique({
    where: { id: probe2Res.id },
  });

  expect(probe2.runtimeLocation).toBe('apps/demo-app/dist/index.js');
  expect(probe2.runtimeLine).toBe(24); // precise mapping with @jridgewell/source-map
  expect(probe2.runtimeColumn).toBe(5);

  // Test Snapshot callstack resolution
  console.log('Verifying call stack resolution via SNAPSHOT...');
  const probe3Res = await trpc.createProbe.mutate({
    serviceId: SERVICE_ID,
    environment: 'development',
    commitSha: COMMIT_SHA,
    type: 'SNAPSHOT' as any,
    uiFilePath: 'apps/demo-app/src/index.ts',
    uiLineNumber: 118, // Inside syncDeepest: total += item.price;
    uiColumnNumber: 1,
    watchExpressions: [],
    expiryTime: Date.now() + 60000,
  });

  expect(probe3Res.success).toBe(true);

  // Trigger the endpoint to hit the probe repeatedly until snapshot is found
  console.log('Hitting endpoint to trigger snapshot...');

  // Wait for snapshot event to be processed
  let snapshotEvent: any = null;
  for (let i = 0; i < 20; i++) {
    await fetch('http://localhost:4006/async-sync-nesting', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ items: [{ price: 10 }] }),
    });

    snapshotEvent = await (getDatabase() as any).snapshotEvent.findFirst({
      where: { probeId: probe3Res.id },
    });
    if (snapshotEvent) break;
    await new Promise((r) => setTimeout(r, 1000));
  }

  expect(snapshotEvent).not.toBeNull();

  const stack = snapshotEvent.payload.stack;
  expect(stack).toBeDefined();
  expect(stack.length).toBeGreaterThan(0);

  // The first frame should be mapped to the original source
  const topFrame = stack[0];
  console.log('Resolved Top Frame:', topFrame);
  expect(topFrame.fileName).toBe('apps/demo-app/src/index.ts');
  expect(topFrame.lineNumber).toBe(118);

  await trpc.deleteProbes.mutate({
    ids: [probe1Res.id, probe2Res.id, probe3Res.id],
  });

  console.log('Source map E2E real coordinate resolution successful!');
});
