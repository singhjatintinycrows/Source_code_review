import { getConfig, getConsul } from '@hyperprobe/common';
import { getDatabase } from '@hyperprobe/database';
import { createTRPCProxyClient, httpBatchLink } from '@trpc/client';
import type { AppRouter } from 'backend';
import superjson from 'superjson';
import { beforeAll, describe, expect, test } from 'vitest';
import { ensureAdminUser } from './auth-helper.js';

const trpc = createTRPCProxyClient<AppRouter>({
  transformer: superjson,
  links: [
    httpBatchLink({
      url: 'http://localhost:4001/trpc',
    }),
  ],
});

beforeAll(async () => {
  // 1. Initialize config/consul connection in this process
  await getConfig();

  // 2. Clear out any non-admin users and teams from previous runs to have a clean state
  const prisma = getDatabase();
  await ensureAdminUser(); // Make sure admin exists so userCount > 0

  // Delete non-admin user-teams and users and teams
  await prisma.userTeam.deleteMany({
    where: {
      user: {
        email: { not: 'e2e-admin@hyperprobe.io' },
      },
    },
  });

  await prisma.user.deleteMany({
    where: {
      email: { not: 'e2e-admin@hyperprobe.io' },
    },
  });

  await prisma.team.deleteMany({
    where: {
      OR: [{ isAdminTeam: false }, { name: 'bad-admin.com' }],
    },
  });
});

describe('Self-Serve User & Team Auto-Creation', () => {
  test('should fail to register if self-serve is disabled in Consul', async () => {
    const consul = getConsul();
    await consul.kv.set('HP_SELF_SERVE_ENABLED', 'no');

    const payload = {
      email: 'john@acme.com',
      ts: Date.now(),
    };

    await expect(
      trpc.verifySso.mutate({
        token: JSON.stringify(payload),
      }),
    ).rejects.toThrowError(
      'Please ask your Admin for permission to login to the Hyper Probe dashboard.',
    );
  });

  test('should successfully register first user of a domain and auto-create team when self-serve is enabled', async () => {
    const consul = getConsul();
    await consul.kv.set('HP_SELF_SERVE_ENABLED', 'yes');

    const email = 'john@acme.com';
    const payload = {
      email,
      ts: Date.now(),
    };

    const response = await trpc.verifySso.mutate({
      token: JSON.stringify(payload),
    });

    expect(response.success).toBe(true);
    expect(response.accessToken).toBeDefined();

    // Verify DB
    const prisma = getDatabase();
    const user = await prisma.user.findUnique({
      where: { email },
      include: {
        teams: {
          include: { team: true },
        },
      },
    });

    expect(user).toBeDefined();
    expect(user?.email).toBe(email);
    expect(user?.teams.length).toBe(1);
    expect(user?.teams[0].team.name).toBe('acme.com');
    expect(user?.teams[0].team.isAdminTeam).toBe(false);
  });

  test('should automatically add next user of the same domain to the existing team', async () => {
    const email = 'alice@acme.com';
    const payload = {
      email,
      ts: Date.now(),
    };

    const response = await trpc.verifySso.mutate({
      token: JSON.stringify(payload),
    });

    expect(response.success).toBe(true);

    // Verify DB
    const prisma = getDatabase();
    const user = await prisma.user.findUnique({
      where: { email },
      include: {
        teams: {
          include: { team: true },
        },
      },
    });

    expect(user).toBeDefined();
    expect(user?.teams.length).toBe(1);
    expect(user?.teams[0].team.name).toBe('acme.com');

    // Verify there is still only one 'acme.com' team
    const teamsCount = await prisma.team.count({
      where: { name: 'acme.com' },
    });
    expect(teamsCount).toBe(1);
  });

  test('should block registration for blacklisted email domains (e.g. gmail, yahoo)', async () => {
    const email = 'spammy@gmail.com';
    const payload = {
      email,
      ts: Date.now(),
    };

    await expect(
      trpc.verifySso.mutate({
        token: JSON.stringify(payload),
      }),
    ).rejects.toThrowError(
      'Self-serve is not available for common email providers. Please sign up using your organization email address.',
    );

    // Verify user was NOT created
    const prisma = getDatabase();
    const user = await prisma.user.findUnique({
      where: { email },
    });
    expect(user).toBeNull();
  });

  test('should block registration for subdomains of blacklisted email domains (e.g. sub.gmail.com)', async () => {
    const email = 'spammy@sub.gmail.com';
    const payload = {
      email,
      ts: Date.now(),
    };

    await expect(
      trpc.verifySso.mutate({
        token: JSON.stringify(payload),
      }),
    ).rejects.toThrowError(
      'Self-serve is not available for common email providers. Please sign up using your organization email address.',
    );

    // Verify user was NOT created
    const prisma = getDatabase();
    const user = await prisma.user.findUnique({
      where: { email },
    });
    expect(user).toBeNull();
  });

  test('should look up and login existing user case-insensitively', async () => {
    // 1. Register user with uppercase domain letters
    const email = 'Jane@Acme.com';
    const payload = {
      email,
      ts: Date.now(),
    };

    const firstResponse = await trpc.verifySso.mutate({
      token: JSON.stringify(payload),
    });
    expect(firstResponse.success).toBe(true);

    // 2. Log in again with lowercase letters
    const lowercasePayload = {
      email: 'jane@acme.com',
      ts: Date.now(),
    };

    const secondResponse = await trpc.verifySso.mutate({
      token: JSON.stringify(lowercasePayload),
    });
    expect(secondResponse.success).toBe(true);

    // Verify only one user exists in DB
    const prisma = getDatabase();
    const count = await prisma.user.count({
      where: {
        email: { in: ['Jane@Acme.com', 'jane@acme.com'] },
      },
    });
    expect(count).toBe(1);
  });

  test('should match pre-existing team case-insensitively during auto-registration', async () => {
    const prisma = getDatabase();
    // 1. Manually create a mixed-case team
    await prisma.team.create({
      data: {
        name: 'CaseMatch.com',
        isAdminTeam: false,
      },
    });

    const email = 'user@casematch.com';
    const payload = {
      email,
      ts: Date.now(),
    };

    const response = await trpc.verifySso.mutate({
      token: JSON.stringify(payload),
    });
    expect(response.success).toBe(true);

    // Verify user was successfully mapped to the existing mixed-case team
    const user = await prisma.user.findUnique({
      where: { email },
      include: {
        teams: {
          include: { team: true },
        },
      },
    });

    expect(user).toBeDefined();
    expect(user?.teams.length).toBe(1);
    expect(user?.teams[0].team.name).toBe('CaseMatch.com');
  });

  test('should fail to register if the domain matches an administrative team', async () => {
    const prisma = getDatabase();
    // Create an admin team with name matching domain 'bad-admin.com'
    await prisma.team.create({
      data: {
        name: 'bad-admin.com',
        isAdminTeam: true,
      },
    });

    const payload = {
      email: 'attacker@bad-admin.com',
      ts: Date.now(),
    };

    await expect(
      trpc.verifySso.mutate({
        token: JSON.stringify(payload),
      }),
    ).rejects.toThrowError(
      'Registration is not permitted under administrative domains.',
    );
  });

  test('should fail to register if sso token has invalid or missing timestamp', async () => {
    const payload = {
      email: 'valid@acme.com',
      ts: 'not-a-number',
    };

    await expect(
      trpc.verifySso.mutate({
        token: JSON.stringify(payload),
      }),
    ).rejects.toThrowError('Access token has expired or is invalid.');
  });
});
