import {
  type AgentInfo,
  getConfig,
  HP_GLOBAL_ACTIVE_AGENTS_KEY,
  HP_SERVICE_LIMIT_REFRESH_KEY,
  stableStringify,
} from '@hyperprobe/common';
import { getDatabase } from '@hyperprobe/database';
import { createTRPCProxyClient, httpBatchLink } from '@trpc/client';
import type { AppRouter } from 'backend';
import { type ExecaChildProcess, execa } from 'execa';
import path from 'path';
import { createClient } from 'redis';
import superjson from 'superjson';
import { fileURLToPath } from 'url';
import { afterAll, beforeAll, expect, test, vi } from 'vitest';
import waitOn from 'wait-on';
import { getAdminToken } from './auth-helper.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(__dirname, '../..');
const SERVICE_ID = 'active-agents-e2e-service';
const COMMIT_SHA = `e2e-agents-sha-${Date.now()}`;

const trpc = createTRPCProxyClient<AppRouter>({
  transformer: superjson,
  links: [
    httpBatchLink({
      url: 'http://localhost:4001/trpc',
      async headers() {
        const token = await getAdminToken();
        return {
          Authorization: `Bearer ${token}`,
        };
      },
    }),
  ],
});

let redis: any;
let demoAppProcess: ExecaChildProcess;

beforeAll(async () => {
  console.log('Resetting database...');
  await getDatabase().sourceMap.deleteMany();
  await getDatabase().service.deleteMany();

  console.log('Creating Service...');
  await getDatabase().service.create({
    data: {
      id: SERVICE_ID,
      name: 'active-agents-e2e-service',
      sourceMapRequired: true,
      agentLimit: 1,
    },
  });

  console.log('Connecting to Redis...');
  const config = await getConfig();
  redis = createClient({ url: config.redisUrl });
  await redis.connect();
  await redis.publish(
    HP_SERVICE_LIMIT_REFRESH_KEY,
    JSON.stringify({ serviceId: SERVICE_ID, agentLimit: 1 }),
  );

  console.log(`Starting demo-app with COMMIT_SHA=${COMMIT_SHA}...`);
  demoAppProcess = execa('node', ['apps/demo-app/dist/index.js'], {
    cwd: ROOT,
    env: {
      ...process.env,
      PORT: '4005',
      HYPERPROBE_ENABLED: 'true',
      HYPERPROBE_SERVICE_ID: SERVICE_ID,
      HYPERPROBE_ALLOW_NON_UUID: 'yes',
      HYPERPROBE_ENVIRONMENT: 'development',
      HYPERPROBE_BROKER_URL: 'localhost:60051',
      GIT_COMMIT: COMMIT_SHA,
      HYPERPROBE_APP_ROOT: 'apps/demo-app',
      HYPERPROBE_DIST_LOCATION: 'dist',
      HYPERPROBE_SYNC_INTERVAL_MS: '1000',
      HYPERPROBE_SOURCE_MAP_DIR: path.resolve(ROOT, 'apps/demo-app/dist'),
    },
  });

  await (waitOn as any)({ resources: ['tcp:localhost:4005'], timeout: 20000 });
  console.log('Demo app ready.');
});

afterAll(async () => {
  if (demoAppProcess) {
    demoAppProcess.kill();
  }
  if (redis) {
    await redis.quit();
  }
});

test('Active Agents: master-compatible heartbeat storage and backend reads', async () => {
  console.log('Waiting for agent registration to propagate...');

  // 1. Wait for agent to hit the broker and register itself in Redis
  let agents: any[] = [];
  for (let i = 0; i < 10; i++) {
    agents = await trpc.listActiveAgents.query({ serviceIds: [SERVICE_ID] });
    if (agents.length > 0) break;
    await new Promise((r) => setTimeout(r, 1000));
  }

  expect(agents.length).toBe(1);
  const registeredAgent = agents[0];

  expect(registeredAgent).toHaveProperty('agentId');
  expect(registeredAgent.serviceId).toBe(SERVICE_ID);
  expect(registeredAgent.environment).toBe('development');
  expect(registeredAgent.commitSha).toBe(COMMIT_SHA);
  expect(registeredAgent.sdkVersion).toEqual(expect.any(String));
  expect(registeredAgent.sdkVersion).not.toBe('');

  const expectedInfo: AgentInfo = {
    agentId: registeredAgent.agentId,
    serviceId: SERVICE_ID,
    environment: 'development',
    commitSha: COMMIT_SHA,
    sdkVersion: registeredAgent.sdkVersion,
  };
  const member = stableStringify(expectedInfo)!;
  const serviceKey = `active_agents:${SERVICE_ID}`;
  const members: string[] = await redis.zRange(serviceKey, 0, -1);
  expect(members).toEqual([member]);
  // The master backend parses every member directly, without sidecar reads.
  expect(members.map((value) => JSON.parse(value))).toEqual([expectedInfo]);
  expect(
    await redis.exists(
      `active_agent_info:${SERVICE_ID}:${registeredAgent.agentId}`,
    ),
  ).toBe(0);

  // Seed the exact master member at capacity; the next SDK heartbeat must
  // refresh it without replacing it or admitting a second service member.
  const previousScore = Date.now() - 1000;
  await redis.zAdd(serviceKey, [{ score: previousScore, value: member }]);
  await vi.waitFor(
    async () => {
      expect(await redis.zScore(serviceKey, member)).toBeGreaterThan(
        previousScore,
      );
    },
    { timeout: 10000, interval: 100 },
  );
  expect(await redis.zRange(serviceKey, 0, -1)).toEqual([member]);
  expect(
    await redis.zScore(HP_GLOBAL_ACTIVE_AGENTS_KEY, registeredAgent.agentId),
  ).toBeGreaterThan(previousScore);
  expect(await redis.zScore(HP_GLOBAL_ACTIVE_AGENTS_KEY, member)).toBeNull();
  expect(
    await redis.exists(
      `active_agent_info:${SERVICE_ID}:${registeredAgent.agentId}`,
    ),
  ).toBe(0);

  console.log('Successfully registered active agent:', registeredAgent.agentId);

  // 2. Kill demo-app to stop it from pinging
  demoAppProcess.kill();
  await new Promise((r) => setTimeout(r, 1000)); // allow it to die

  // 3. Manually insert a stale agent to verify `zRemRangeByScore` cleanup works via backend
  const staleAgentId = 'stale-uuid-1234';
  const staleAgentInfo = stableStringify({
    ...expectedInfo,
    agentId: staleAgentId,
  })!;
  // Set score to 105 seconds ago (past the 100s threshold)
  const staleTimestamp = Date.now() - 105000;
  await redis.zAdd(`active_agents:${SERVICE_ID}`, [
    { score: staleTimestamp, value: staleAgentInfo },
    { score: staleTimestamp, value: staleAgentId },
  ]);

  // Restored JSON must take precedence over stale branch sidecar metadata.
  const freshAgentId = 'fresh-uuid-5678';
  const freshAgentInfo = {
    agentId: freshAgentId,
    serviceId: SERVICE_ID,
    environment: 'development',
    commitSha: COMMIT_SHA,
    sdkVersion: '1.2.27',
  };
  const freshMember = stableStringify(freshAgentInfo)!;
  const freshTimestamp = Date.now();

  await redis.zAdd(`active_agents:${SERVICE_ID}`, [
    { score: freshTimestamp, value: freshMember },
    { score: freshTimestamp, value: freshAgentId },
  ]);
  await redis.set(
    `active_agent_info:${SERVICE_ID}:${freshAgentId}`,
    JSON.stringify({ ...freshAgentInfo, sdkVersion: '1.0.0' }),
    {
      EX: 120,
    },
  );

  // 4. Query tRPC listActiveAgents
  const finalAgents = await trpc.listActiveAgents.query({
    serviceIds: [SERVICE_ID],
  });

  // Expect to see the originally registered one (from demo-app) and the fresh one, but NOT the stale one
  const agentIds = finalAgents.map((a) => a.agentId);

  expect(agentIds).toContain(registeredAgent.agentId);
  expect(agentIds).toContain(freshAgentId);
  expect(agentIds).not.toContain(staleAgentId);
  expect(finalAgents.find((agent) => agent.agentId === freshAgentId)).toEqual(
    freshAgentInfo,
  );
  expect(await redis.zScore(`active_agents:${SERVICE_ID}`, freshMember)).toBe(
    freshTimestamp,
  );
  expect(
    await redis.zScore(`active_agents:${SERVICE_ID}`, staleAgentInfo),
  ).toBeNull();
  expect(
    await redis.zScore(`active_agents:${SERVICE_ID}`, staleAgentId),
  ).toBeNull();

  // The length should be exactly 2
  expect(finalAgents.length).toBe(2);

  console.log('Cleanup logic verified successfully.');
});
