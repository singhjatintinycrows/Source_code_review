import jwt from 'jsonwebtoken';
import {
  HP_LICENSE_SYNC_STATUS,
  type HpLicenseJwtPayload,
  type LicensePublicationTicket,
  type LicenseRecoveryContext,
  type LicenseSnapshot,
} from '../types/license.js';
import { HP_DEPLOYMENT_KEYS } from './snapshot.js';

export class LicenseManager {
  private static instance: LicenseManager;
  private licensePublicKey: string | null = null;

  private currentRawJwt: string | null = null;
  private currentNextToken: string | null = null;
  private currentHintStatus: HP_LICENSE_SYNC_STATUS =
    HP_LICENSE_SYNC_STATUS.SYNCED;
  private decodedPayload: HpLicenseJwtPayload | null = null;
  private isInitializing: boolean = true;
  private softAgentLimit: number | null = null;
  private publicationGeneration = 0;
  private recoveryGeneration = 0;
  private lastVerifiedGeneration = 0;
  private localRevocations = new Set<string | null>();
  // A null entry has not established its source; a null source stays fail-closed.
  private pendingRevocations = new Map<
    number,
    readonly (string | null)[] | null
  >();
  private observedRevocationIndex: number | null = null;
  private bootstrapPublicKey: string | null = null;
  private snapshotPublicKey: string | null = null;

  private constructor() {}

  public static getInstance(): LicenseManager {
    if (!LicenseManager.instance) {
      LicenseManager.instance = new LicenseManager();
    }
    return LicenseManager.instance;
  }

  // Synchronous input only; async bootstrap/reloads use setBootstrapPublicKey.
  public setPublicKey(publicKey: string | null) {
    this.invalidatePublications();
    this.bootstrapPublicKey = publicKey;
    this.licensePublicKey = publicKey;
    if (this.currentRawJwt) {
      this.decodeAndVerify();
    } else {
      this.isInitializing = false;
    }
  }

  public getPublicKey(): string | null {
    return this.licensePublicKey;
  }

  public updateState(rawJwt: string | null, nextToken: string | null) {
    this.invalidatePublications();
    this.currentRawJwt = rawJwt;
    this.currentNextToken = nextToken;
    this.decodeAndVerify();
  }

  public setHintStatus(status: HP_LICENSE_SYNC_STATUS) {
    this.invalidatePublications();
    if (status === HP_LICENSE_SYNC_STATUS.REVOKED) {
      const revocation = this.beginRevocation()!;
      this.bindRevocation(revocation, this.currentRawJwt);
      this.recordLocalRevocation(revocation);
      this.endRevocation(revocation);
      return;
    }
    this.currentHintStatus = status;
  }

  public getHintStatus(): HP_LICENSE_SYNC_STATUS {
    return this.localRevocations.size > 0 || this.pendingRevocations.size > 0
      ? HP_LICENSE_SYNC_STATUS.REVOKED
      : this.currentHintStatus;
  }

  public capturePublication(): LicensePublicationTicket {
    return {
      generation: this.publicationGeneration,
      fallbackPublicKey: this.bootstrapPublicKey ?? this.licensePublicKey,
    };
  }

  public invalidatePublications() {
    this.publicationGeneration++;
  }

  // Capture the ticket before an async environment/database key load. Bootstrap
  // input is a fallback, never a replacement for a coherently hydrated key.
  public setBootstrapPublicKey(
    publicKey: string | null,
    ticket: LicensePublicationTicket,
  ): boolean {
    if (ticket.generation !== this.publicationGeneration) return false;
    this.invalidatePublications();
    this.bootstrapPublicKey = publicKey;
    if (!this.snapshotPublicKey) {
      this.licensePublicKey = publicKey;
      this.decodeAndVerify();
    }
    return true;
  }

  private getLocalRevocationSources(): (string | null)[] {
    return [
      ...this.localRevocations,
      ...[...this.pendingRevocations.values()].flatMap(
        (sources) => sources ?? [null],
      ),
    ];
  }

  public captureRecoveryContext(): LicenseRecoveryContext {
    const sources = this.getLocalRevocationSources();
    if (this.currentHintStatus === HP_LICENSE_SYNC_STATUS.REVOKED) {
      const licenseId = this.getLicenseId();
      sources.push(
        typeof licenseId === 'string' && licenseId.trim() ? licenseId : null,
      );
    }
    return {
      generation: this.recoveryGeneration,
      revoked: this.getHintStatus() === HP_LICENSE_SYNC_STATUS.REVOKED,
      revocationSources: [...new Set(sources)],
    };
  }

  public isRecoveryCurrent(context: LicenseRecoveryContext): boolean {
    return context.generation === this.recoveryGeneration;
  }

  public recordLocalRevocation(
    context: LicenseRecoveryContext,
    revocationSources?: LicenseRecoveryContext['revocationSources'],
  ): boolean {
    // Observing durable R during the attempt is not a verified recovery. Only a
    // newer verified outcome can supersede this attempt's unpersisted barrier.
    if (
      !this.pendingRevocations.has(context.generation) ||
      this.lastVerifiedGeneration > context.generation
    ) {
      return false;
    }
    this.invalidatePublications();
    const sources = revocationSources ??
      this.pendingRevocations.get(context.generation) ?? [null];
    for (const source of sources.length ? sources : [null]) {
      this.localRevocations.add(source);
    }
    return true;
  }

  // Fence older verifications immediately, without awaiting revocation I/O.
  public beginRevocation(
    source = this.captureRecoveryContext(),
  ): LicenseRecoveryContext | null {
    if (!this.isRecoveryCurrent(source)) return null;
    this.invalidatePublications();
    this.recoveryGeneration++;
    this.pendingRevocations.set(this.recoveryGeneration, null);
    return this.captureRecoveryContext();
  }

  public bindRevocation(
    context: LicenseRecoveryContext,
    sourceJwt: string | null,
  ): boolean {
    if (
      !this.pendingRevocations.has(context.generation) ||
      this.lastVerifiedGeneration > context.generation
    ) {
      return false;
    }
    if (this.pendingRevocations.get(context.generation) !== null) return true;
    let licenseId: string | null = null;
    try {
      const source = sourceJwt ? jwt.decode(sourceJwt) : null;
      if (
        source &&
        typeof source === 'object' &&
        typeof source.licenseId === 'string' &&
        source.licenseId.trim()
      ) {
        licenseId = source.licenseId;
      }
    } catch (_) {}
    this.invalidatePublications();
    this.pendingRevocations.set(context.generation, [licenseId]);
    return true;
  }

  public endRevocation(context: LicenseRecoveryContext | null) {
    if (context && this.pendingRevocations.delete(context.generation)) {
      this.invalidatePublications();
    }
  }

  // A recovery context is supplied only for a verified, matching confirmation,
  // and must originate before verification/async mutation work, not at apply time.
  public publishSnapshot(
    state: LicenseSnapshot,
    ticket: LicensePublicationTicket,
    recoveryContext?: LicenseRecoveryContext,
  ): boolean {
    if (
      ticket.generation !== this.publicationGeneration ||
      (recoveryContext && !this.isRecoveryCurrent(recoveryContext))
    ) {
      return false;
    }
    this.invalidatePublications();
    this.snapshotPublicKey = state.publicKey;
    this.licensePublicKey = state.verificationKey;
    this.currentRawJwt = state.jwt;
    this.currentNextToken = state.nextToken;
    this.currentHintStatus = state.hintStatus;
    this.decodeAndVerify();

    const target = this.decodedPayload;
    const sources = this.getLocalRevocationSources();
    const now = Date.now();
    // Only a complete, verified different-license installation can discharge
    // known old sources without this process performing the replacement itself.
    const replacement =
      !recoveryContext &&
      sources.length > 0 &&
      (state.hintStatus === HP_LICENSE_SYNC_STATUS.SYNCED ||
        state.hintStatus === HP_LICENSE_SYNC_STATUS.COURIER_REQUIRED) &&
      state.publicKey !== null &&
      target !== null &&
      typeof target.licenseId === 'string' &&
      target.licenseId.trim().length > 0 &&
      target.licenseId === state.licenseId &&
      (target.exp === undefined ||
        (Number.isFinite(target.exp) && now < target.exp * 1000)) &&
      typeof target.last_heartbeat_timestamp === 'number' &&
      Number.isFinite(target.last_heartbeat_timestamp) &&
      target.last_heartbeat_timestamp >= 0 &&
      now - target.last_heartbeat_timestamp <= 7 * 24 * 60 * 60 * 1000 &&
      [
        HP_DEPLOYMENT_KEYS.HP_LICENSE_JWT,
        HP_DEPLOYMENT_KEYS.NEXT_TOKEN,
        HP_DEPLOYMENT_KEYS.HP_LICENSE_ID,
        HP_DEPLOYMENT_KEYS.HP_LICENSE_SYNC_STATUS,
        'LICENSE_PUBLIC_KEY',
      ].every((key) => state.indices[key] > 0) &&
      sources.every((source) => source !== null && source !== target.licenseId);
    if (state.hintStatus === HP_LICENSE_SYNC_STATUS.REVOKED) {
      const index = state.indices[HP_DEPLOYMENT_KEYS.HP_LICENSE_SYNC_STATUS];
      if (this.observedRevocationIndex !== index) {
        this.observedRevocationIndex = index;
        this.recoveryGeneration++;
      }
    } else if (recoveryContext || replacement) {
      this.localRevocations.clear();
      if (replacement) this.pendingRevocations.clear();
      this.recoveryGeneration++;
      this.lastVerifiedGeneration = this.recoveryGeneration;
    }
    return true;
  }

  private decodeAndVerify() {
    this.isInitializing = false;
    if (!this.currentRawJwt || !this.licensePublicKey) {
      this.decodedPayload = null;
      return;
    }

    try {
      this.decodedPayload = jwt.verify(
        this.currentRawJwt,
        this.licensePublicKey,
        { algorithms: ['ES256'], ignoreExpiration: true },
      ) as unknown as HpLicenseJwtPayload;
    } catch (e) {
      console.error(
        'Failed to decode license, please verify your JWT/publicKey:',
        e,
      );
      this.decodedPayload = null;
    }
  }

  public getStatus(): HP_LICENSE_SYNC_STATUS {
    if (this.getHintStatus() === HP_LICENSE_SYNC_STATUS.REVOKED)
      return HP_LICENSE_SYNC_STATUS.REVOKED;
    if (this.isInitializing) return HP_LICENSE_SYNC_STATUS.LOCKED; // Fail Closed during boot
    if (!this.decodedPayload) {
      return HP_LICENSE_SYNC_STATUS.LOCKED;
    }

    const now = Date.now();
    const lastHeartbeat = this.decodedPayload.last_heartbeat_timestamp;

    if (typeof lastHeartbeat !== 'number' || Number.isNaN(lastHeartbeat)) {
      return HP_LICENSE_SYNC_STATUS.LOCKED;
    }

    const GRACE_PERIOD_MS = 7 * 24 * 60 * 60 * 1000; // 7 days

    if (now - lastHeartbeat > GRACE_PERIOD_MS) {
      return HP_LICENSE_SYNC_STATUS.LOCKED;
    }

    if (this.decodedPayload.exp) {
      if (now > this.decodedPayload.exp * 1000) {
        return HP_LICENSE_SYNC_STATUS.LOCKED;
      }
    }

    return HP_LICENSE_SYNC_STATUS.SYNCED; // Local in-memory state is valid
  }

  public getMaxAgents(): number {
    if (
      this.decodedPayload?.max_agents !== undefined &&
      this.decodedPayload?.max_agents !== null
    ) {
      return Number(this.decodedPayload.max_agents);
    }
    return 0;
  }

  public setSoftAgentLimit(limit: number | null) {
    this.softAgentLimit = limit;
  }

  public getSoftAgentLimit(): number {
    return this.softAgentLimit !== null
      ? this.softAgentLimit
      : this.getMaxAgents();
  }

  public getLicenseId(): string | null {
    return this.decodedPayload?.licenseId || null;
  }

  public getCustomerName(): string | null {
    return this.decodedPayload?.customerName || null;
  }

  public getExpiryDate(): number | null {
    return this.decodedPayload?.exp ? this.decodedPayload.exp * 1000 : null; // Return in ms
  }

  public getRawJwt(): string | null {
    return this.currentRawJwt;
  }

  public getNextToken(): string | null {
    return this.currentNextToken;
  }
}
