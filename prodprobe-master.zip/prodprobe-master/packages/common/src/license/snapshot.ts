import {
  HP_LICENSE_SYNC_STATUS,
  type LicenseSnapshot,
} from '../types/license.js';
import type { LicenseManager } from './LicenseManager.js';

export const HP_DEPLOYMENT_KEYS = {
  HP_LICENSE_JWT: 'DEPLOYMENT/HP_LICENSE_JWT',
  NEXT_TOKEN: 'DEPLOYMENT/NEXT_TOKEN',
  HP_LICENSE_SYNC_STATUS: 'DEPLOYMENT/HP_LICENSE_SYNC_STATUS',
  HP_LICENSE_ID: 'DEPLOYMENT/HP_LICENSE_ID',
  HP_SOFT_AGENT_LIMIT: 'DEPLOYMENT/HP_SERVICE_AGENT_SOFT_LIMIT',
};

const keys = {
  jwt: HP_DEPLOYMENT_KEYS.HP_LICENSE_JWT,
  nextToken: HP_DEPLOYMENT_KEYS.NEXT_TOKEN,
  publicKey: 'LICENSE_PUBLIC_KEY',
  hintStatus: HP_DEPLOYMENT_KEYS.HP_LICENSE_SYNC_STATUS,
  licenseId: HP_DEPLOYMENT_KEYS.HP_LICENSE_ID,
};

export async function readLicenseSnapshot(
  consul: { transaction: unknown },
  manager?: LicenseManager,
  options: { hydrate?: boolean } = {},
): Promise<LicenseSnapshot> {
  // consul@2 forwards the uppercase wire format despite declaring a different API.
  const transaction = consul.transaction as {
    create(
      operations: { KV: { Verb: 'get-or-empty'; Key: string } }[],
      options: { consistent: boolean },
    ): Promise<{
      Results?: {
        KV: {
          Key: string;
          ModifyIndex: number;
          Value: string | null;
          Flags?: number;
        };
      }[];
      Errors?: unknown[] | null;
    }>;
  };
  for (;;) {
    const publication = manager?.capturePublication() ?? null;
    const recoveryContext = manager?.captureRecoveryContext() ?? null;
    const result = await transaction.create(
      Object.values(keys).map((Key) => ({ KV: { Verb: 'get-or-empty', Key } })),
      { consistent: true },
    );
    if (
      result.Errors?.length ||
      result.Results?.length !== Object.keys(keys).length
    ) {
      throw new Error('Unable to read a complete license snapshot from Consul');
    }
    const entries = new Map(result.Results.map(({ KV }) => [KV.Key, KV]));
    const hintFlags =
      entries.get(HP_DEPLOYMENT_KEYS.HP_LICENSE_SYNC_STATUS)?.Flags ?? 0;
    if (!Number.isSafeInteger(hintFlags) || hintFlags < 0) {
      throw new Error('Invalid sync-status flags returned by Consul');
    }
    const values = Object.fromEntries(
      Object.entries(keys).map(([field, key]) => {
        const entry = entries.get(key);
        if (
          !entry ||
          !Number.isSafeInteger(entry.ModifyIndex) ||
          entry.ModifyIndex < 0
        ) {
          throw new Error('Invalid license snapshot returned by Consul');
        }
        return [
          field,
          entry.Value === null
            ? null
            : Buffer.from(entry.Value, 'base64').toString('utf8') || null,
        ];
      }),
    ) as Record<keyof typeof keys, string | null>;
    const state: LicenseSnapshot = {
      ...values,
      nextToken: values.nextToken?.trim() ? values.nextToken : null,
      hintStatus: (values.hintStatus ??
        HP_LICENSE_SYNC_STATUS.COURIER_REQUIRED) as HP_LICENSE_SYNC_STATUS,
      verificationKey: values.publicKey
        ? values.publicKey.replace(/\\n/g, '\n').replace(/^['"]|['"]$/g, '')
        : (publication?.fallbackPublicKey ?? null),
      hintFlags,
      indices: Object.fromEntries(
        [...entries].map(([key, entry]) => [key, entry.ModifyIndex]),
      ),
      publication,
      recoveryContext,
    };
    if (!manager || options.hydrate === false) return state;
    if (manager.publishSnapshot(state, publication!)) {
      return { ...state, recoveryContext: manager.captureRecoveryContext() };
    }
    // A crossed publication says nothing about Consul read ordering. Re-read,
    // rather than sorting ModifyIndices (deletions are zero) or reticketing data.
  }
}
