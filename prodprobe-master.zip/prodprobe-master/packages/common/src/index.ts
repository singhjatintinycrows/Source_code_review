import * as fs from 'node:fs';
import * as path from 'node:path';
import Consul from 'consul';
import * as dotenv from 'dotenv';
import * as dotenvExpand from 'dotenv-expand';
import pino from 'pino';
import stringify from 'safe-stable-stringify';
import type { LicenseManager } from './license/LicenseManager.js';
import { HP_DEPLOYMENT_KEYS, readLicenseSnapshot } from './license/snapshot.js';

export const stableStringify = stringify;

let globalLogger: pino.Logger | null = null;
let consulInstance: Consul | null = null;
const CONSUL_REQUEST_TIMEOUT_MS = 10_000;

function withConsulRequestTimeout<T>(
  request: Promise<T>,
  key: string,
): Promise<T> {
  return new Promise((resolve, reject) => {
    const timeout = setTimeout(() => {
      reject(new Error(`Timed out reading Consul key '${key}'.`));
    }, CONSUL_REQUEST_TIMEOUT_MS);
    void request.then(
      (value) => {
        clearTimeout(timeout);
        resolve(value);
      },
      (error) => {
        clearTimeout(timeout);
        reject(error);
      },
    );
  });
}

/**
 * Returns a singleton logger instance. Initializes it if it doesn't exist.
 */
export function getLogger(): pino.Logger {
  if (!globalLogger) {
    globalLogger = pino({
      level: process.env.LOG_LEVEL || 'info',
    });
  }
  return globalLogger;
}

/**
 * Watches the LOG_LEVEL key in Consul and dynamically updates the logger level.
 */
export function watchLogLevel(consul: Consul) {
  const logger = getLogger();
  const watcher = consul.watch({
    method: consul.kv.get,
    options: { key: 'LOG_LEVEL' },
  });

  watcher.on('change', (data: any) => {
    if (data && data.Value) {
      const newLevel = data.Value;
      if (logger.level !== newLevel) {
        logger.info(
          `[Bootstrap] Dynamically changing log level from ${logger.level} to ${newLevel}`,
        );
        logger.level = newLevel;
      }
    }
  });

  watcher.on('error', (err) => {
    logger.error({ err }, '[Bootstrap] Error watching LOG_LEVEL in Consul');
  });
}

/**
 * Recursively find the .env-hp file by traversing up the directory tree
 */
function findEnvFile(currentDir: string): string | null {
  const envPath = path.join(currentDir, '.env-hp');
  if (fs.existsSync(envPath)) {
    return envPath;
  }

  const parentDir = path.dirname(currentDir);
  if (parentDir === currentDir) {
    return null; // reached root
  }

  return findEnvFile(parentDir);
}

/**
 * Load the local .env-hp file
 */
export function loadLocalEnv() {
  const envPath = findEnvFile(process.cwd());
  if (envPath) {
    console.log(`[Bootstrap] Loading env from: ${envPath}`);
    const myEnv = dotenv.config({ path: envPath });
    dotenvExpand.expand(myEnv);
  } else {
    console.warn(
      `[Bootstrap] Warning: .env-hp file not found up the directory tree from ${process.cwd()}`,
    );
  }
}

export interface Config {
  databaseUrl: string;
  redisUrl: string;
  natsUrl: string;
}

/**
 * Resolves a final source path by safely merging any overlapping directories
 * between the source-map baseDir and the clean source file path, preserving absolute contexts.
 */
export function resolvePathWithOverlap(
  baseDir: string,
  cleanPath: string,
  sourceRoot = '',
): string {
  const isAbsolute = baseDir.startsWith('/');
  const baseParts = baseDir.split('/').filter((p) => p !== '.' && p !== '');
  const cleanParts = cleanPath.split('/').filter(Boolean);
  let maxOverlap = 0;

  for (let i = 1; i <= Math.min(baseParts.length, cleanParts.length); i++) {
    const endOfBase = baseParts.slice(-i).join('/');
    const startOfClean = cleanParts.slice(0, i).join('/');
    if (endOfBase === startOfClean) {
      maxOverlap = i;
    }
  }

  let resolvedPath: string;
  if (maxOverlap > 0) {
    const adjustedCleanParts = cleanParts.slice(maxOverlap);
    resolvedPath = [...baseParts, ...adjustedCleanParts].join('/');
    if (isAbsolute) {
      resolvedPath = `/${resolvedPath}`;
    }
    resolvedPath = path.posix.join(resolvedPath);
  } else {
    resolvedPath = path.posix.join(baseDir, sourceRoot, cleanPath);
  }

  return resolvedPath;
}

/**
 * Connect to Consul and fetch the configuration
 */
export async function fetchConfig(): Promise<Config> {
  if (!process.env.CONSUL_HOST || !process.env.CONSUL_HTTP_PORT) {
    throw new Error(
      'CONSUL_HOST or CONSUL_HTTP_PORT is not set in env. Cannot start.',
    );
  }

  const host = process.env.CONSUL_HOST!;
  const port = parseInt(process.env.CONSUL_HTTP_PORT!, 10);

  console.log(`[Bootstrap] Connecting to Consul at ${host}:${port}...`);
  consulInstance = new Consul({ host, port });

  const DB_KEY = 'HP_DB_URL';
  const REDIS_KEY = 'REDIS_URL';
  const NATS_KEY = 'NATS_CONN_URL';

  try {
    const [dbUrlItem, redisUrlItem, natsUrlItem]: any[] = await Promise.all([
      withConsulRequestTimeout(consulInstance.kv.get(DB_KEY), DB_KEY),
      withConsulRequestTimeout(consulInstance.kv.get(REDIS_KEY), REDIS_KEY),
      withConsulRequestTimeout(consulInstance.kv.get(NATS_KEY), NATS_KEY),
    ]);

    if (!dbUrlItem)
      throw new Error(`Consul key '${DB_KEY}' is missing. Cannot start.`);
    if (!redisUrlItem)
      throw new Error(`Consul key '${REDIS_KEY}' is missing. Cannot start.`);
    if (!natsUrlItem)
      throw new Error(`Consul key '${NATS_KEY}' is missing. Cannot start.`);

    let databaseUrl = dbUrlItem.Value;
    let redisUrl = redisUrlItem.Value;
    const natsUrl = natsUrlItem.Value;

    if (process.env.HYPERPROBE_ENV === 'e2e') {
      databaseUrl = databaseUrl.replace(/\/[^/]+$/, '/e2e-db');
      redisUrl = `${redisUrl}/1`; // slot 1 for e2e
      console.log(
        `[Bootstrap] E2E Mode: Using isolated database, redis (derived from Consul)`,
      );
    } else {
      console.log(
        `[Bootstrap] Successfully fetched database configuration from Consul.`,
      );
    }

    return { databaseUrl, redisUrl, natsUrl };
  } catch (error) {
    console.error(
      '[Bootstrap] Fatal error fetching configuration from Consul:',
      error,
    );
    throw error;
  }
}

export async function getConfig(): Promise<Config> {
  loadLocalEnv();
  return await fetchConfig();
}

export function getConsul(): Consul {
  if (!consulInstance) {
    throw new Error(
      'Consul has not been initialized. Call fetchConfig() first.',
    );
  }
  return consulInstance;
}

export const HP_GLOBAL_ACTIVE_AGENTS_KEY = 'hp_license:global_active_agents';
export const HP_LICENSE_UPGRADE_KEY = 'hp_license:upgrade_required';
export const HP_LICENCE_MEMORY_REFRESH_KEY = 'hp_license:memory_refresh';
export const HP_SERVICE_LIMIT_REFRESH_KEY = 'hp_service:limit_refresh';

export async function syncLicenseAndSoftLimit(
  consul: any,
  licenseManager: LicenseManager,
) {
  await readLicenseSnapshot(consul, licenseManager);
  const softLimitItem: any = await consul.kv.get(
    HP_DEPLOYMENT_KEYS.HP_SOFT_AGENT_LIMIT,
  );

  const maxAgents = licenseManager.getMaxAgents();
  let softLimit =
    softLimitItem && softLimitItem.Value
      ? parseInt(softLimitItem.Value, 10)
      : null;

  if (softLimit !== null && !Number.isNaN(softLimit) && softLimit >= 0) {
    if (softLimit > maxAgents) {
      softLimit = maxAgents;
      await consul.kv.set(
        HP_DEPLOYMENT_KEYS.HP_SOFT_AGENT_LIMIT,
        String(maxAgents),
      );
    }
    licenseManager.setSoftAgentLimit(
      Math.min(softLimit, licenseManager.getMaxAgents()),
    );
  } else {
    // Only write back to Consul if the key exists but contains an invalid/negative value
    if (
      softLimitItem &&
      softLimitItem.Value &&
      (softLimit === null || Number.isNaN(softLimit) || softLimit < 0)
    ) {
      await consul.kv.set(
        HP_DEPLOYMENT_KEYS.HP_SOFT_AGENT_LIMIT,
        String(maxAgents),
      );
    }
    licenseManager.setSoftAgentLimit(licenseManager.getMaxAgents());
  }
}

export * from './license/LicenseManager.js';
export * from './license/snapshot.js';
export * from './types/agent.js';
export * from './types/license.js';
