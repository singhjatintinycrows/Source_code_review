export type AgentInfo = {
  agentId: string;
  serviceId: string;
  environment: string;
  commitSha: string;
  sdkVersion?: string;
};
