export enum HP_LICENSE_SYNC_STATUS {
  SYNCED = 'SYNCED',
  COURIER_REQUIRED = 'COURIER_REQUIRED',
  REVOKED = 'REVOKED', // REVOKED is we have set isRevoked to true in the firebase db for this license
  LOCKED = 'LOCKED', // LOCKED is that it has failed to get a heartbeat in the stipulated time and the grace period put together.
}

export type HpLicenseJwtPayload = {
  licenseId: string;
  max_agents: number;
  last_heartbeat_timestamp: number;
  customerName?: string;
  exp?: number;
  [key: string]: unknown;
};

export type HpLicenseState = {
  status: HP_LICENSE_SYNC_STATUS;
  jwtPayload: HpLicenseJwtPayload | null;
  rawJwt: string | null;
  nextToken: string | null;
};

export type LicensePublicationTicket = Readonly<{
  generation: number;
  fallbackPublicKey: string | null;
}>;

export type LicenseRecoveryContext = Readonly<{
  generation: number;
  revoked: boolean;
  revocationSources: readonly (string | null)[];
}>;

export type LicenseSnapshot = {
  jwt: string | null;
  nextToken: string | null;
  publicKey: string | null;
  verificationKey: string | null;
  hintStatus: HP_LICENSE_SYNC_STATUS;
  hintFlags: number;
  licenseId: string | null;
  indices: Record<string, number>;
  publication: LicensePublicationTicket | null;
  recoveryContext: LicenseRecoveryContext | null;
};
