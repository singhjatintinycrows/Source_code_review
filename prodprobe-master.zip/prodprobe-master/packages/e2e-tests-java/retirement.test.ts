import { getConfig } from '@hyperprobe/common';
import { getDatabase, ProbeStatus, ProbeType } from '@hyperprobe/database';
import { createTRPCProxyClient, httpBatchLink } from '@trpc/client';
import type { AppRouter } from 'backend';
import { type ExecaChildProcess, execa } from 'execa';
import fs from 'fs';
import path from 'path';
import { createClient } from 'redis';
import superjson from 'superjson';
import { fileURLToPath } from 'url';
import { afterAll, beforeAll, expect, test } from 'vitest';
import waitOn from 'wait-on';
import { getAdminToken } from './auth-helper.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(__dirname, '../..');
const SERVICE_ID = 'java-demo-app-retirement';
const COMMIT_SHA = `java-e2e-retirement-sha-${Date.now()}`;

const trpc = createTRPCProxyClient<AppRouter>({
  transformer: superjson,
  links: [
    httpBatchLink({
      url: 'http://localhost:4001/trpc',
      async headers() {
        const token = await getAdminToken();
        return {
          Authorization: `Bearer ${token}`,
        };
      },
    }),
  ],
});

let demoAppProcess: ExecaChildProcess;

function findJar(dir: string, prefix: string): string {
  if (!fs.existsSync(dir)) {
    throw new Error(`Directory not found: ${dir}`);
  }
  const files = fs.readdirSync(dir);
  const jar = files.find(
    (f) =>
      f.startsWith(prefix) &&
      f.endsWith('.jar') &&
      !f.endsWith('.original') &&
      !f.endsWith('-sources.jar') &&
      !f.endsWith('-javadoc.jar'),
  );
  if (!jar)
    throw new Error(`Could not find jar with prefix ${prefix} in ${dir}`);
  return path.join(dir, jar);
}

beforeAll(async () => {
  // 1. Reset DB
  console.log('Resetting database...');
  await getDatabase().logEvent.deleteMany();
  await getDatabase().snapshotEvent.deleteMany();
  await getDatabase().metricEvent.deleteMany();
  await getDatabase().probe.deleteMany();
  await getDatabase().sourceMap.deleteMany();
  await getDatabase().service.deleteMany();

  console.log('Creating Service...');
  await getDatabase().service.create({
    data: {
      id: SERVICE_ID,
      name: 'java-demo-app-retirement',
      sourceMapRequired: false,
    },
  });

  // 2. Reset Redis
  console.log('Resetting Redis...');
  const config = await getConfig();
  const redis = createClient({ url: config.redisUrl });
  await redis.connect();
  await redis.flushDb();
  await redis.quit();

  // 3. Find Jars
  const agentTarget = path.resolve(
    ROOT,
    'agents/java-sdk/hyperprobe-agent/target',
  );
  const demoTarget = path.resolve(ROOT, 'agents/java-demo-app/target');
  const agentJar = findJar(agentTarget, 'hyperprobe-agent-');
  const demoAppJar = findJar(demoTarget, 'java-demo-app-');

  // 4. Start demo-app with unique service name
  console.log(
    `Starting java-demo-app for ${SERVICE_ID} with COMMIT_SHA=${COMMIT_SHA}...`,
  );
  demoAppProcess = execa(
    'java',
    [`-javaagent:${agentJar}`, '-jar', demoAppJar],
    {
      cwd: path.resolve(ROOT),
      env: {
        ...process.env,
        SERVER_PORT: '4005',
        HYPERPROBE_ENABLED: 'true',
        HYPERPROBE_SERVICE_ID: SERVICE_ID,
        HYPERPROBE_ENVIRONMENT: 'development',
        HYPERPROBE_BROKER_URL: 'localhost:60051',
        GIT_COMMIT: COMMIT_SHA,
        HYPERPROBE_SYNC_INTERVAL_MS: '1000',
      },
    },
  );
  demoAppProcess.stdout?.pipe(process.stdout);
  demoAppProcess.stderr?.pipe(process.stderr);

  await (waitOn as any)({ resources: ['tcp:localhost:4005'], timeout: 30000 });
  console.log('Demo app ready.');
}, 60000);

afterAll(async () => {
  if (demoAppProcess) {
    demoAppProcess.kill('SIGTERM');
    await new Promise((r) => setTimeout(r, 1000));
  }
});

test('E2E Java Retirement Verification', async () => {
  const expiryTime = Date.now() + 1000 * 60;

  // 1. Create a LOG Probe with a high hit limit so it stays ACTIVE
  console.log('Creating log probe...');
  const logProbe = await trpc.createProbe.mutate({
    commitSha: COMMIT_SHA,
    type: ProbeType.LOG,
    serviceId: SERVICE_ID,
    environment: 'development',
    uiFilePath:
      'src/main/java/com/hyperprobe/demo/service/CheckoutService.java',
    uiLineNumber: 37,
    // biome-ignore lint/suspicious/noTemplateCurlyInString: test template
    template: 'Retirement Check: ${itemPrice}',
    hitLimit: 100, // High limit
    expiryTime,
  });

  expect(logProbe.success).toBe(true);

  // Wait for agent to sync (sync interval is 1s, wait a bit longer to ensure it applied)
  await new Promise((r) => setTimeout(r, 4000));

  // 2. Trigger Checkout (First Time)
  console.log('Triggering checkout (First Time)...');
  await fetch('http://localhost:4005/checkout', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      userId: 'user_123',
      items: [{ price: 10.0, quantity: 1 }],
    }),
  });

  // Verify first log was recorded
  const logs1 = await pollPostgres(
    () => getDatabase().logEvent.findMany({ where: { probeId: logProbe.id } }),
    1,
  );
  expect(logs1.length).toBe(1);

  // 3. Mark Probe as INACTIVE directly in DB (simulating user toggling it off)
  console.log('Marking probe as INACTIVE...');
  await getDatabase().probe.update({
    where: { id: logProbe.id },
    data: { status: ProbeStatus.INACTIVE },
  });

  // Wait for agent to sync and retire the probe
  await new Promise((r) => setTimeout(r, 4000));

  // 4. Trigger Checkout (Second Time)
  console.log('Triggering checkout (Second Time)...');
  await fetch('http://localhost:4005/checkout', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      userId: 'user_123',
      items: [{ price: 20.0, quantity: 1 }],
    }),
  });

  // Wait a few seconds to see if any unexpected telemetry arrives
  await new Promise((r) => setTimeout(r, 3000));

  // Verify no new log was recorded (should still be exactly 1)
  console.log('Verifying no new logs were recorded...');
  const logs2 = await getDatabase().logEvent.findMany({
    where: { probeId: logProbe.id },
  });

  expect(logs2.length).toBe(1); // Still 1

  console.log('E2E Java Retirement Verified!');
});

async function pollPostgres<T>(
  fn: () => Promise<T[]>,
  minCount: number,
): Promise<T[]> {
  for (let i = 0; i < 40; i++) {
    const res = await fn();
    if (res.length >= minCount) return res;
    console.log(
      `Polling DB... attempt ${i + 1}/40, found ${res.length}/${minCount}`,
    );
    await new Promise((r) => setTimeout(r, 1000));
  }
  const finalRes = await fn();
  if (finalRes.length < minCount) {
    throw new Error(
      `Polling timeout: expected ${minCount} records, found ${finalRes.length}`,
    );
  }
  return finalRes;
}
