import { getConfig } from '@hyperprobe/common';
import { getDatabase, ProbeStatus, ProbeType } from '@hyperprobe/database';
import { createTRPCProxyClient, httpBatchLink } from '@trpc/client';
import type { AppRouter } from 'backend';
import { type ExecaChildProcess, execa } from 'execa';
import fs from 'fs';
import path from 'path';
import { createClient } from 'redis';
import superjson from 'superjson';
import { fileURLToPath } from 'url';
import { afterAll, beforeAll, expect, test } from 'vitest';
import waitOn from 'wait-on';
import { getAdminToken } from './auth-helper.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(__dirname, '../..');
const SERVICE_ID = 'java-demo-app-pipeline';
const COMMIT_SHA = `java-e2e-pipeline-sha-${Date.now()}`;

const trpc = createTRPCProxyClient<AppRouter>({
  transformer: superjson,
  links: [
    httpBatchLink({
      url: 'http://localhost:4001/trpc',
      async headers() {
        const token = await getAdminToken();
        return {
          Authorization: `Bearer ${token}`,
        };
      },
    }),
  ],
});

let demoAppProcess: ExecaChildProcess;

function findJar(dir: string, prefix: string): string {
  if (!fs.existsSync(dir)) {
    throw new Error(`Directory not found: ${dir}`);
  }
  const files = fs.readdirSync(dir);
  const jar = files.find(
    (f) =>
      f.startsWith(prefix) &&
      f.endsWith('.jar') &&
      !f.endsWith('.original') &&
      !f.endsWith('-sources.jar') &&
      !f.endsWith('-javadoc.jar'),
  );
  if (!jar)
    throw new Error(`Could not find jar with prefix ${prefix} in ${dir}`);
  return path.join(dir, jar);
}

beforeAll(async () => {
  // 1. Reset DB
  console.log('Resetting database...');
  await getDatabase().logEvent.deleteMany();
  await getDatabase().snapshotEvent.deleteMany();
  await getDatabase().metricEvent.deleteMany();
  await getDatabase().probe.deleteMany();
  await getDatabase().sourceMap.deleteMany();
  await getDatabase().service.deleteMany();

  console.log('Creating Service...');
  await getDatabase().service.create({
    data: {
      id: SERVICE_ID,
      name: 'java-demo-app-pipeline',
      sourceMapRequired: false,
    },
  });

  // 2. Reset Redis
  console.log('Resetting Redis...');
  const config = await getConfig();
  const redis = createClient({ url: config.redisUrl });
  await redis.connect();
  await redis.flushDb();
  await redis.quit();

  // 3. Find Jars
  const agentTarget = path.resolve(
    ROOT,
    'agents/java-sdk/hyperprobe-agent/target',
  );
  const demoTarget = path.resolve(ROOT, 'agents/java-demo-app/target');
  const agentJar = findJar(agentTarget, 'hyperprobe-agent-');
  const demoAppJar = findJar(demoTarget, 'java-demo-app-');

  // 4. Start demo-app with unique service name
  console.log(
    `Starting java-demo-app for ${SERVICE_ID} with COMMIT_SHA=${COMMIT_SHA}...`,
  );
  demoAppProcess = execa(
    'java',
    [`-javaagent:${agentJar}`, '-jar', demoAppJar],
    {
      cwd: path.resolve(ROOT),
      env: {
        ...process.env,
        SERVER_PORT: '4003',
        HYPERPROBE_ENABLED: 'true',
        HYPERPROBE_SERVICE_ID: SERVICE_ID,
        HYPERPROBE_ENVIRONMENT: 'development',
        HYPERPROBE_BROKER_URL: 'localhost:60051',
        GIT_COMMIT: COMMIT_SHA,
        HYPERPROBE_SYNC_INTERVAL_MS: '1000',
      },
    },
  );
  demoAppProcess.stdout?.pipe(process.stdout);
  demoAppProcess.stderr?.pipe(process.stderr);

  await (waitOn as any)({ resources: ['tcp:localhost:4003'], timeout: 30000 });
  console.log('Demo app ready.');
}, 60000);

afterAll(async () => {
  if (demoAppProcess) {
    demoAppProcess.kill('SIGTERM');
    await new Promise((r) => setTimeout(r, 1000));
  }
});

test('E2E Pipeline Java: Multi-Probe Verification', async () => {
  const expiryTime = Date.now() + 1000 * 60;

  console.log('Creating probes using resolved coordinates...');

  const logProbe = await trpc.createProbe.mutate({
    commitSha: COMMIT_SHA,
    type: ProbeType.LOG,
    serviceId: SERVICE_ID,
    environment: 'development',
    uiFilePath:
      'src/main/java/com/hyperprobe/demo/service/CheckoutService.java',
    uiLineNumber: 37,
    // biome-ignore lint/suspicious/noTemplateCurlyInString: vitest template string
    template: 'LOG: ${itemPrice}',
    hitLimit: 2,
    expiryTime,
  });

  const counterProbe = await trpc.createProbe.mutate({
    commitSha: COMMIT_SHA,
    type: ProbeType.COUNTER,
    serviceId: SERVICE_ID,
    environment: 'development',
    uiFilePath:
      'src/main/java/com/hyperprobe/demo/service/CheckoutService.java',
    uiLineNumber: 37,
    metricName: 'items_processed_total',
    hitLimit: 2,
    expiryTime,
  });

  const snapshotProbe = await trpc.createProbe.mutate({
    commitSha: COMMIT_SHA,
    type: ProbeType.SNAPSHOT,
    serviceId: SERVICE_ID,
    environment: 'development',
    uiFilePath:
      'src/main/java/com/hyperprobe/demo/service/CheckoutService.java',
    uiLineNumber: 42,
    watchExpressions: ['cartTotal', 'discount', 'userSession.id'],
    hitLimit: 1,
    expiryTime,
  });

  const durationProbe = await trpc.createProbe.mutate({
    commitSha: COMMIT_SHA,
    type: ProbeType.DURATION,
    serviceId: SERVICE_ID,
    environment: 'development',
    uiFilePath:
      'src/main/java/com/hyperprobe/demo/service/CheckoutService.java',
    uiLineNumber: 18,
    secondaryUiFilePath:
      'src/main/java/com/hyperprobe/demo/service/CheckoutService.java',
    secondaryUiLineNumber: 48,
    metricName: 'checkout_loop_duration',
    hitLimit: 1,
    expiryTime,
  });

  expect(logProbe.success).toBe(true);
  expect(counterProbe.success).toBe(true);
  expect(snapshotProbe.success).toBe(true);
  expect(durationProbe.success).toBe(true);

  // Wait for agent to sync (sync interval is 1s, wait a bit longer to ensure it applied)
  await new Promise((r) => setTimeout(r, 4000));

  console.log('Triggering checkout...');
  const res = await fetch('http://localhost:4003/checkout', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      userId: 'user_123',
      items: [
        { price: 10.0, quantity: 1 },
        { price: 200.0, quantity: 1 },
      ],
    }),
  });
  expect(res.status).toBe(200);

  console.log('Verifying LOGs...');
  const logs = await pollPostgres(
    () => getDatabase().logEvent.findMany({ where: { probeId: logProbe.id } }),
    2,
  );
  expect(logs.length).toBe(2);
  expect(logs.map((l) => l.message)).toContain('LOG: 10.0');
  expect(logs.map((l) => l.message)).toContain('LOG: 200.0');

  console.log('Verifying COUNTER...');
  const counters = await pollPostgres(
    () =>
      getDatabase().metricEvent.findMany({
        where: { probeId: counterProbe.id },
      }),
    2,
  );
  expect(counters.length).toBe(2);
  expect(counters[0].value).toBe(1);

  console.log('Verifying SNAPSHOT...');
  const snapshots = await pollPostgres(
    () =>
      getDatabase().snapshotEvent.findMany({
        where: { probeId: snapshotProbe.id },
      }),
    1,
  );
  expect(snapshots.length).toBe(1);
  const payload = snapshots[0].payload as any;
  console.log('SNAPSHOT VARS:', JSON.stringify(payload.vars, null, 2));
  expect(payload.watch['cartTotal']).toBeDefined();
  expect(payload.watch['userSession.id']).toBe('user_123');

  const topFrameScopes = payload.vars[0];
  const localScope = topFrameScopes.find((s: any) => s.type === 'local');
  expect(localScope).toBeDefined();
  expect(localScope.vars).toBeDefined();

  console.log('Verifying DURATION...');
  const durations = await pollPostgres(
    () =>
      getDatabase().metricEvent.findMany({
        where: { probeId: durationProbe.id },
      }),
    1,
  );
  expect(durations.length).toBe(1);
  expect(durations[0].value).toBeGreaterThan(0);

  // Verify all completed
  const probeIds = [
    logProbe.id,
    counterProbe.id,
    snapshotProbe.id,
    durationProbe.id,
  ];
  const completedProbes = await pollPostgres(
    () =>
      getDatabase().probe.findMany({
        where: { id: { in: probeIds }, status: ProbeStatus.COMPLETED },
      }),
    4,
  );
  expect(completedProbes.length).toBe(4);
});

async function pollPostgres<T>(
  fn: () => Promise<T[]>,
  minCount: number,
): Promise<T[]> {
  for (let i = 0; i < 40; i++) {
    const res = await fn();
    if (res.length >= minCount) return res;
    console.log(
      `Polling DB... attempt ${i + 1}/40, found ${res.length}/${minCount}`,
    );
    await new Promise((r) => setTimeout(r, 1000));
  }
  const finalRes = await fn();
  if (finalRes.length < minCount) {
    throw new Error(
      `Polling timeout: expected ${minCount} records, found ${finalRes.length}`,
    );
  }
  return finalRes;
}
