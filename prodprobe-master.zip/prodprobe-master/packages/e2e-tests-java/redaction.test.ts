import { getConfig } from '@hyperprobe/common';
import { getDatabase, ProbeType } from '@hyperprobe/database';
import { createTRPCProxyClient, httpBatchLink } from '@trpc/client';
import type { AppRouter } from 'backend';
import { type ExecaChildProcess, execa } from 'execa';
import fs from 'fs';
import path from 'path';
import { createClient } from 'redis';
import superjson from 'superjson';
import { fileURLToPath } from 'url';
import { afterAll, beforeAll, expect, test } from 'vitest';
import waitOn from 'wait-on';
import { getAdminToken } from './auth-helper.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(__dirname, '../..');
const SERVICE_ID = 'java-demo-app-redaction';
const COMMIT_SHA = `java-e2e-redaction-sha-${Date.now()}`;

const trpc = createTRPCProxyClient<AppRouter>({
  transformer: superjson,
  links: [
    httpBatchLink({
      url: 'http://localhost:4001/trpc',
      async headers() {
        const token = await getAdminToken();
        return {
          Authorization: `Bearer ${token}`,
        };
      },
    }),
  ],
});

let demoAppProcess: ExecaChildProcess;

function findJar(dir: string, prefix: string): string {
  if (!fs.existsSync(dir)) {
    throw new Error(`Directory not found: ${dir}`);
  }
  const files = fs.readdirSync(dir);
  const jar = files.find(
    (f) =>
      f.startsWith(prefix) &&
      f.endsWith('.jar') &&
      !f.endsWith('.original') &&
      !f.endsWith('-sources.jar') &&
      !f.endsWith('-javadoc.jar'),
  );
  if (!jar)
    throw new Error(`Could not find jar with prefix ${prefix} in ${dir}`);
  return path.join(dir, jar);
}

beforeAll(async () => {
  // 1. Reset DB
  console.log('Resetting database...');
  await getDatabase().logEvent.deleteMany();
  await getDatabase().snapshotEvent.deleteMany();
  await getDatabase().metricEvent.deleteMany();
  await getDatabase().probe.deleteMany();
  await getDatabase().sourceMap.deleteMany();
  await getDatabase().service.deleteMany();

  console.log('Creating Service...');
  await getDatabase().service.create({
    data: {
      id: SERVICE_ID,
      name: 'java-demo-app-redaction',
      sourceMapRequired: false,
    },
  });

  // 2. Reset Redis
  console.log('Resetting Redis...');
  const config = await getConfig();
  const redis = createClient({ url: config.redisUrl });
  await redis.connect();
  await redis.flushDb();
  await redis.quit();

  // 3. Find Jars
  const agentTarget = path.resolve(
    ROOT,
    'agents/java-sdk/hyperprobe-agent/target',
  );
  const demoTarget = path.resolve(ROOT, 'agents/java-demo-app/target');
  const agentJar = findJar(agentTarget, 'hyperprobe-agent-');
  const demoAppJar = findJar(demoTarget, 'java-demo-app-');

  // 4. Start demo-app with unique service name
  console.log(
    `Starting java-demo-app for ${SERVICE_ID} with COMMIT_SHA=${COMMIT_SHA}...`,
  );
  demoAppProcess = execa(
    'java',
    [`-javaagent:${agentJar}`, '-jar', demoAppJar],
    {
      cwd: path.resolve(ROOT),
      env: {
        ...process.env,
        SERVER_PORT: '4004',
        HYPERPROBE_ENABLED: 'true',
        HYPERPROBE_SERVICE_ID: SERVICE_ID,
        HYPERPROBE_ENVIRONMENT: 'development',
        HYPERPROBE_BROKER_URL: 'localhost:60051',
        GIT_COMMIT: COMMIT_SHA,
        HYPERPROBE_SYNC_INTERVAL_MS: '1000',
        HYPERPROBE_REDACT_KEYS: 'password,userId',
      },
    },
  );
  demoAppProcess.stdout?.pipe(process.stdout);
  demoAppProcess.stderr?.pipe(process.stderr);

  await (waitOn as any)({ resources: ['tcp:localhost:4004'], timeout: 30000 });
  console.log('Demo app ready.');
}, 60000);

afterAll(async () => {
  if (demoAppProcess) {
    demoAppProcess.kill('SIGTERM');
    await new Promise((r) => setTimeout(r, 1000));
  }
});

test('E2E Java Redaction & Truncation Verification', async () => {
  const expiryTime = Date.now() + 1000 * 60;

  // 1. Create Snapshot Probe
  console.log('Creating snapshot probe...');
  const snapshotProbe = await trpc.createProbe.mutate({
    commitSha: COMMIT_SHA,
    type: ProbeType.SNAPSHOT,
    serviceId: SERVICE_ID,
    environment: 'development',
    uiFilePath:
      'src/main/java/com/hyperprobe/demo/service/CheckoutService.java',
    uiLineNumber: 29, // Inside processCheckout, after userSession is built
    hitLimit: 1,
    expiryTime,
    maxObjectDepth: 2,
    maxArrayLength: 2,
    stackFrameDepth: 5,
  });

  expect(snapshotProbe.success).toBe(true);

  // Wait for agent to sync (sync interval is 1s, wait a bit longer to ensure it applied)
  await new Promise((r) => setTimeout(r, 4000));

  // 2. Trigger Checkout
  console.log('Triggering checkout...');
  await fetch('http://localhost:4004/checkout', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      userId: 'user_123',
      items: [
        { price: 1.0, quantity: 1 },
        { price: 2.0, quantity: 1 },
        { price: 3.0, quantity: 1 },
        { price: 4.0, quantity: 1 },
      ],
    }),
  });

  // 3. Verify Snapshot
  console.log('Verifying SNAPSHOT redaction...');
  const snapshots = await pollPostgres(
    () =>
      getDatabase().snapshotEvent.findMany({
        where: { probeId: snapshotProbe.id },
      }),
    1,
  );
  expect(snapshots.length).toBe(1);
  const payload = snapshots[0].payload as any;
  const frame0Scopes = payload.vars[0]; // All scopes of first frame
  const localScope = frame0Scopes.find((s: any) => s.type === 'local');
  expect(localScope).toBeDefined();
  const localVars = localScope.vars;

  const userSession = localVars.userSession;
  expect(userSession).toBeDefined();

  // Verify Redaction
  expect(userSession.password).toBe('[REDACTED Key]');
  expect(localVars.userId).toBe('[REDACTED Key]');

  // Verify Circular Detection
  expect(userSession.circular).toBe('[REF - frame[0].scopes[0].userSession]');

  // Verify Array Truncation or Circular Detection
  // In Java, req.items is a List which serialize to Array
  const req = localVars.req;
  const items = req.items;
  if (Array.isArray(items)) {
    expect(items.length).toBe(3); // 2 items + truncation message
    expect(items[2]).toContain('more items truncated');
  }

  // Verify Depth (Set to 2)
  expect(userSession.flags[0]).toBe('premium');

  console.log('E2E Java Redaction & Truncation Verified!');
});

async function pollPostgres<T>(
  fn: () => Promise<T[]>,
  minCount: number,
): Promise<T[]> {
  for (let i = 0; i < 40; i++) {
    const res = await fn();
    if (res.length >= minCount) return res;
    console.log(
      `Polling DB... attempt ${i + 1}/40, found ${res.length}/${minCount}`,
    );
    await new Promise((r) => setTimeout(r, 1000));
  }
  const finalRes = await fn();
  if (finalRes.length < minCount) {
    throw new Error(
      `Polling timeout: expected ${minCount} records, found ${finalRes.length}`,
    );
  }
  return finalRes;
}
