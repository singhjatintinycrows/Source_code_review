import { getDatabase } from '@hyperprobe/database';
import { createTRPCProxyClient, httpBatchLink } from '@trpc/client';
import type { AppRouter } from 'backend';
import jwt from 'jsonwebtoken';
import superjson from 'superjson';

export const ADMIN_EMAIL = 'e2e-admin@hyperprobe.io';

export async function ensureAdminUser() {
  const prisma = getDatabase();

  // 1. Ensure Admin Team exists
  let adminTeam = await prisma.team.findFirst({
    where: { isAdminTeam: true },
  });

  if (!adminTeam) {
    adminTeam = await prisma.team.create({
      data: {
        name: 'Admin Team',
        isAdminTeam: true,
      },
    });
  }

  // 2. Ensure Admin User exists
  let adminUser = await prisma.user.findUnique({
    where: { email: ADMIN_EMAIL },
    include: { teams: true },
  });

  if (!adminUser) {
    adminUser = await prisma.user.create({
      data: {
        email: ADMIN_EMAIL,
      },
      include: { teams: true },
    });
  }

  // 3. Ensure User is in Admin Team
  const isInAdminTeam = adminUser.teams.some(
    (ut) => ut.teamId === adminTeam!.id,
  );
  if (!isInAdminTeam) {
    await prisma.userTeam.create({
      data: {
        userId: adminUser.id,
        teamId: adminTeam!.id,
      },
    });
  }

  return adminUser;
}

export async function getAdminToken() {
  const prisma = getDatabase();
  const adminUser = await ensureAdminUser();

  const sysConfig = await prisma.systemConfig.findFirst({
    where: { id: 'singleton' },
  });

  if (!sysConfig) {
    throw new Error(
      'SystemConfig not found. Backend might not have started yet.',
    );
  }

  const token = jwt.sign(
    {
      userId: adminUser.id,
      email: adminUser.email,
      permissions: {
        isAdmin: true,
        permissions: {},
      },
    },
    sysConfig.tokenSecret,
    { expiresIn: '1h' },
  );

  return token;
}

export async function getAuthenticatedTRPCClient() {
  const token = await getAdminToken();

  return createTRPCProxyClient<AppRouter>({
    transformer: superjson,
    links: [
      httpBatchLink({
        url: 'http://localhost:4001/trpc',
        headers: {
          Authorization: `Bearer ${token}`,
        },
      }),
    ],
  });
}
