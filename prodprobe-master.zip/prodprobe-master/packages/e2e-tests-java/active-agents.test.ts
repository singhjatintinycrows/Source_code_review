import { getConfig } from '@hyperprobe/common';
import { getDatabase } from '@hyperprobe/database';
import { createTRPCProxyClient, httpBatchLink } from '@trpc/client';
import type { AppRouter } from 'backend';
import { type ExecaChildProcess, execa } from 'execa';
import fs from 'fs';
import path from 'path';
import { createClient } from 'redis';
import superjson from 'superjson';
import { fileURLToPath } from 'url';
import { afterAll, beforeAll, expect, test } from 'vitest';
import waitOn from 'wait-on';
import { getAdminToken } from './auth-helper.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(__dirname, '../..');
const SERVICE_ID = 'java-demo-app-active-agents';
const COMMIT_SHA = `java-e2e-active-agents-sha-${Date.now()}`;

const trpc = createTRPCProxyClient<AppRouter>({
  transformer: superjson,
  links: [
    httpBatchLink({
      url: 'http://localhost:4001/trpc',
      async headers() {
        const token = await getAdminToken();
        return {
          Authorization: `Bearer ${token}`,
        };
      },
    }),
  ],
});

let demoAppProcess: ExecaChildProcess;
let redisClient: ReturnType<typeof createClient>;

function findJar(dir: string, prefix: string): string {
  if (!fs.existsSync(dir)) {
    throw new Error(`Directory not found: ${dir}`);
  }
  const files = fs.readdirSync(dir);
  const jar = files.find(
    (f) =>
      f.startsWith(prefix) &&
      f.endsWith('.jar') &&
      !f.endsWith('.original') &&
      !f.endsWith('-sources.jar') &&
      !f.endsWith('-javadoc.jar'),
  );
  if (!jar)
    throw new Error(`Could not find jar with prefix ${prefix} in ${dir}`);
  return path.join(dir, jar);
}

beforeAll(async () => {
  // 1. Reset DB
  console.log('Resetting database...');
  await getDatabase().service.deleteMany();

  console.log('Creating Service...');
  await getDatabase().service.create({
    data: {
      id: SERVICE_ID,
      name: 'java-demo-app-active-agents',
      sourceMapRequired: false,
    },
  });

  // 2. Reset Redis
  console.log('Resetting Redis...');
  const config = await getConfig();
  redisClient = createClient({ url: config.redisUrl });
  await redisClient.connect();

  // 3. Find Jars
  const agentTarget = path.resolve(
    ROOT,
    'agents/java-sdk/hyperprobe-agent/target',
  );
  const demoTarget = path.resolve(ROOT, 'agents/java-demo-app/target');
  const agentJar = findJar(agentTarget, 'hyperprobe-agent-');
  const demoAppJar = findJar(demoTarget, 'java-demo-app-');

  // 4. Start demo-app with unique service name
  console.log(
    `Starting java-demo-app for ${SERVICE_ID} with COMMIT_SHA=${COMMIT_SHA}...`,
  );
  demoAppProcess = execa(
    'java',
    [`-javaagent:${agentJar}`, '-jar', demoAppJar],
    {
      cwd: path.resolve(ROOT),
      env: {
        ...process.env,
        SERVER_PORT: '4006',
        HYPERPROBE_ENABLED: 'true',
        HYPERPROBE_SERVICE_ID: SERVICE_ID,
        HYPERPROBE_ENVIRONMENT: 'development',
        HYPERPROBE_BROKER_URL: 'localhost:60051',
        GIT_COMMIT: COMMIT_SHA,
        HYPERPROBE_SYNC_INTERVAL_MS: '1000',
      },
    },
  );
  demoAppProcess.stdout?.pipe(process.stdout);
  demoAppProcess.stderr?.pipe(process.stderr);

  await (waitOn as any)({ resources: ['tcp:localhost:4006'], timeout: 30000 });
  console.log('Demo app ready.');
}, 60000);

afterAll(async () => {
  if (demoAppProcess) {
    demoAppProcess.kill('SIGTERM');
    await new Promise((r) => setTimeout(r, 1000));
  }
  if (redisClient) {
    await redisClient.quit();
  }
});

test('E2E Java Active Agents: SDK registers and Backend lists accurately', async () => {
  console.log('Waiting for active agent heartbeat to reach database...');

  // 1. Wait for agent to hit the broker and register itself in Redis via TRPC
  let agents: any[] = [];
  for (let i = 0; i < 15; i++) {
    agents = await trpc.listActiveAgents.query({ serviceIds: [SERVICE_ID] });
    if (agents.length > 0) break;
    await new Promise((r) => setTimeout(r, 1000));
  }

  expect(agents.length).toBe(1);
  const registeredAgent = agents[0];

  expect(registeredAgent).toHaveProperty('agentId');
  expect(registeredAgent.serviceId).toBe(SERVICE_ID);
  expect(registeredAgent.environment).toBe('development');
  expect(registeredAgent.commitSha).toBe(COMMIT_SHA);

  console.log('E2E Java Active Agents Verified:', registeredAgent);
});
