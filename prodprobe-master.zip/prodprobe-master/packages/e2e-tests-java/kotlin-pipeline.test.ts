import { getConfig } from '@hyperprobe/common';
import { getDatabase, ProbeStatus, ProbeType } from '@hyperprobe/database';
import { createTRPCProxyClient, httpBatchLink } from '@trpc/client';
import type { AppRouter } from 'backend';
import { type ExecaChildProcess, execa } from 'execa';
import fs from 'fs';
import path from 'path';
import { createClient } from 'redis';
import superjson from 'superjson';
import { fileURLToPath } from 'url';
import { afterAll, beforeAll, expect, test } from 'vitest';
import waitOn from 'wait-on';
import { getAdminToken } from './auth-helper.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(__dirname, '../..');
const SERVICE_ID = 'f74259ba-f7a0-4973-9d37-024a19cbee10';
const COMMIT_SHA = `kotlin-e2e-pipeline-sha-${Date.now()}`;
const APP_PORT = 4004;

const trpc = createTRPCProxyClient<AppRouter>({
  transformer: superjson,
  links: [
    httpBatchLink({
      url: 'http://localhost:4001/trpc',
      async headers() {
        const token = await getAdminToken();
        return { Authorization: `Bearer ${token}` };
      },
    }),
  ],
});

let demoAppProcess: ExecaChildProcess;

function findJar(dir: string, prefix: string): string {
  const jar = fs
    .readdirSync(dir)
    .find(
      (file) =>
        file.startsWith(prefix) &&
        file.endsWith('.jar') &&
        !file.endsWith('.original') &&
        !file.endsWith('-sources.jar') &&
        !file.endsWith('-javadoc.jar'),
    );
  if (!jar) throw new Error(`Could not find ${prefix} JAR in ${dir}`);
  return path.join(dir, jar);
}

beforeAll(async () => {
  // Build the exact agent and Kotlin application under test so a stale local
  // JAR cannot make this regression test pass or fail incorrectly.
  await execa(
    'mvn',
    ['-pl', 'hyperprobe-agent', '-am', 'package', '-DskipTests'],
    {
      cwd: path.resolve(ROOT, 'agents/java-sdk'),
      stdio: 'inherit',
    },
  );
  await execa('mvn', ['package', '-DskipTests'], {
    cwd: path.resolve(ROOT, 'agents/kotlin-demo-app'),
    stdio: 'inherit',
  });

  await getDatabase().logEvent.deleteMany();
  await getDatabase().snapshotEvent.deleteMany();
  await getDatabase().metricEvent.deleteMany();
  await getDatabase().probe.deleteMany();
  await getDatabase().sourceMap.deleteMany();
  await getDatabase().service.deleteMany();

  await getDatabase().service.create({
    data: {
      id: SERVICE_ID,
      name: SERVICE_ID,
      sourceMapRequired: false,
    },
  });

  const config = await getConfig();
  const redis = createClient({ url: config.redisUrl });
  await redis.connect();
  await redis.flushDb();
  await redis.quit();

  const agentJar = findJar(
    path.resolve(ROOT, 'agents/java-sdk/hyperprobe-agent/target'),
    'hyperprobe-agent-',
  );
  const demoAppJar = findJar(
    path.resolve(ROOT, 'agents/kotlin-demo-app/target'),
    'kotlin-demo-app-',
  );

  demoAppProcess = execa(
    'java',
    [`-javaagent:${agentJar}`, '-jar', demoAppJar],
    {
      cwd: ROOT,
      env: {
        ...process.env,
        SERVER_PORT: String(APP_PORT),
        HYPERPROBE_ENABLED: 'true',
        HYPERPROBE_SERVICE_ID: SERVICE_ID,
        HYPERPROBE_ENVIRONMENT: 'development',
        HYPERPROBE_BROKER_URL: 'localhost:60051',
        GIT_COMMIT: COMMIT_SHA,
        HYPERPROBE_SYNC_INTERVAL_MS: '1000',
      },
    },
  );
  demoAppProcess.stdout?.pipe(process.stdout);
  demoAppProcess.stderr?.pipe(process.stderr);

  await (waitOn as any)({
    resources: [`http-get://localhost:${APP_PORT}/health`],
    timeout: 30000,
  });
}, 120000);

afterAll(async () => {
  if (demoAppProcess) {
    demoAppProcess.kill('SIGTERM');
    await new Promise((resolve) => setTimeout(resolve, 1000));
  }
});

test('Kotlin: VS Code payload reaches a class whose name differs from its source file', async () => {
  // This is the exact payload mapping used by actionStore.insertAction in the
  // VS Code webview. Dtos.kt deliberately contains several top-level classes.
  const vscodePayload: any = {
    serviceId: SERVICE_ID,
    environment: 'development',
    commitSha: COMMIT_SHA,
    type: ProbeType.LOG,
    uiFilePath: 'src/main/kotlin/com/hyperprobe/demo/model/Dtos.kt',
    uiLineNumber: 28,
    // biome-ignore lint/suspicious/noTemplateCurlyInString: agent log expression syntax
    template: 'KOTLIN DTO total: ${total}',
    hitLimit: 1,
    expiryTime: Date.now() + 60_000,
  };

  const probe = await trpc.createProbe.mutate(vscodePayload);
  expect(probe.success).toBe(true);

  const storedProbe = await getDatabase().probe.findUniqueOrThrow({
    where: { id: probe.id },
  });
  expect(storedProbe.runtimeLocation).toBe(
    'src/main/kotlin/com/hyperprobe/demo/model/Dtos.kt',
  );
  expect(storedProbe.runtimeLine).toBe(28);

  await new Promise((resolve) => setTimeout(resolve, 4000));

  const response = await fetch(`http://localhost:${APP_PORT}/checkout`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      userId: 'kotlin_user',
      items: [
        { price: 10, quantity: 1 },
        { price: 200, quantity: 1 },
      ],
    }),
  });
  expect(response.status).toBe(200);

  const logs = await pollPostgres(
    () => getDatabase().logEvent.findMany({ where: { probeId: probe.id } }),
    1,
  );
  expect(logs).toHaveLength(1);
  expect(logs[0].message).toBe('KOTLIN DTO total: 190.0');

  const completedProbe = await pollPostgres(
    () =>
      getDatabase().probe.findMany({
        where: { id: probe.id, status: ProbeStatus.COMPLETED },
      }),
    1,
  );
  expect(completedProbe).toHaveLength(1);
});

async function pollPostgres<T>(
  query: () => Promise<T[]>,
  minimumCount: number,
): Promise<T[]> {
  for (let attempt = 0; attempt < 40; attempt++) {
    const result = await query();
    if (result.length >= minimumCount) return result;
    await new Promise((resolve) => setTimeout(resolve, 1000));
  }
  return query();
}
