// Force E2E mode for this setup script
process.env.HYPERPROBE_ENV = 'e2e';

import path from 'path';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(__dirname, '../..');

import { getConfig } from '@hyperprobe/common';
import { NATS_TELEMETRY_STREAM } from '@hyperprobe/constants';
import { initDatabase } from '@hyperprobe/database';
import { execa } from 'execa';
import { connect } from 'nats';
import { createClient } from 'redis';
import waitOn from 'wait-on';
import { ensureAdminUser } from './auth-helper';

const services: any[] = [];

export default async function () {
  console.log('Global Setup: Starting E2E services...');

  const config = await getConfig();
  const prisma = initDatabase(config.databaseUrl);

  // 1. Build workspace (Done once)
  console.log('Building workspace...');
  await execa('pnpm', ['build', '--parallel=10', '--output-style=static'], {
    cwd: ROOT,
    stdio: 'inherit',
  });

  // 2. Provision and Reset Database
  console.log('Provisioning e2e-db schema...');
  await execa('pnpm', ['prisma', 'db', 'push', '--accept-data-loss'], {
    cwd: path.resolve(ROOT, 'packages/database'),
    env: { ...process.env, HP_DB_URL: config.databaseUrl },
  });

  console.log('Resetting database...');
  try {
    await prisma.logEvent.deleteMany();
    await prisma.snapshotEvent.deleteMany();
    await prisma.metricEvent.deleteMany();
    await prisma.probe.deleteMany();
  } catch (e) {
    console.error('Error resetting database:', e);
  }

  console.log('Resetting NATS...');
  try {
    const nc = await connect({ servers: config.natsUrl });
    const jm = await nc.jetstreamManager();
    await jm.streams.delete(NATS_TELEMETRY_STREAM);
    await nc.close();
  } catch (_e) {
    // Stream might not exist
  }

  console.log('Resetting Redis...');
  try {
    const redis = createClient({ url: config.redisUrl });
    await redis.connect();
    await redis.flushDb();
    await redis.quit();
  } catch (e) {
    console.error('Error resetting Redis:', e);
  }

  // 3. Start Services (Except demo-app which is handled per test)
  const startService = (_name: string, dir: string, env: any = {}) => {
    const proc = execa('node', ['dist/index.cjs'], {
      cwd: path.resolve(ROOT, dir),
      env: {
        ...process.env,
        HYPERPROBE_ENV: 'e2e',
        ...env,
      },
    });
    proc.stdout?.pipe(process.stdout);
    proc.stderr?.pipe(process.stderr);
    return proc;
  };

  services.push(
    startService('backend', 'apps/backend', {
      HTTP_PORT: '4001',
    }),
  );
  services.push(
    startService('logger', 'apps/logger', {
      GRPC_PORT: '60051',
      HYPERPROBE_SYNC_INTERVAL_MS: '1000',
      HYPERPROBE_REDACT_KEYS: 'password,userId',
    }),
  );
  services.push(startService('logger-consumer', 'apps/logger-consumer', {}));

  console.log('Waiting for services to be ready...');
  try {
    await (waitOn as any)({
      resources: [
        'tcp:localhost:4001', // backend (E2E)
        'tcp:localhost:60051', // logger (E2E)
      ],
      timeout: 30000,
    });
  } catch (e) {
    console.error('Timeout waiting for services:', e);
    throw e;
  }

  // Give consumer a moment to start
  await new Promise((r) => setTimeout(r, 2000));

  console.log('Ensuring admin user exists...');
  await ensureAdminUser();

  return async () => {
    console.log('Global Teardown: Shutting down services...');
    for (const proc of services) {
      console.log(`Killing process ${proc.pid}...`);
      proc.kill('SIGTERM', {
        forceKillAfterTimeout: 5000,
      });
    }
    // Wait a bit for processes to actually die
    await new Promise((r) => setTimeout(r, 2000));
  };
}
