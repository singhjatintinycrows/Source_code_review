// Force E2E mode for this setup script
process.env.HYPERPROBE_ENV = 'e2e';

import { getConfig } from '@hyperprobe/common';
import { initDatabase } from '@hyperprobe/database';

const config = await getConfig();
initDatabase(config.databaseUrl);
