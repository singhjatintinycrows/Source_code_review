import childProcess from 'node:child_process';
import { constants, existsSync } from 'node:fs';
import fs from 'node:fs/promises';
import path from 'node:path';
import { promisify } from 'node:util';

const GIT_DISCOVERY_TIMEOUT_MS = 10_000;
const MAX_GIT_OUTPUT_BYTES = 1024 * 1024;
const MAX_CONFIG_READS = 256;
const MAX_CONFIG_BYTES = 64 * 1024;

/** Finds the nearest ancestor .hprc with a usable service ID, regardless of Git tracking. */
async function findNearestAncestorHprcConfig(
  filePath: string,
): Promise<{ serviceId: string; baseDir: string } | null> {
  let currentDir = path.dirname(filePath);
  while (true) {
    const hprcPath = path.join(currentDir, '.hprc');
    if (existsSync(hprcPath)) {
      try {
        let content = await fs.readFile(hprcPath, 'utf-8');

        // Strip hidden BOM often added by Windows PowerShell/Notepad to prevent JSON.parse errors
        if (content.charCodeAt(0) === 0xfeff) {
          content = content.slice(1);
        }
        const parsed = JSON.parse(content);
        if (parsed && typeof parsed.serviceId === 'string') {
          return { serviceId: parsed.serviceId, baseDir: currentDir };
        }
      } catch (err) {
        console.error(`Failed to parse ${hprcPath}:`, err);
      }
    }
    const parentDir = path.dirname(currentDir);
    if (parentDir === currentDir) {
      break;
    }
    currentDir = parentDir;
  }
  return null;
}

/** Finds the nearest Git working-tree root, recognizing both .git directories and files. */
async function findGitWorkingTreeRoot(
  filePath: string,
): Promise<string | null> {
  let currentDir = path.dirname(filePath);
  while (true) {
    if (existsSync(path.join(currentDir, '.git'))) {
      return currentDir;
    }
    const parentDir = path.dirname(currentDir);
    if (parentDir === currentDir) break;
    currentDir = parentDir;
  }
  return null;
}

/** Lists unique .hprc paths from this working tree's index without scanning untracked files. */
async function listTrackedHprcPaths(gitRoot: string): Promise<string[]> {
  try {
    const { stdout } = await promisify(childProcess.execFile)(
      'git',
      [
        '--no-optional-locks',
        '-c',
        'core.fsmonitor=false',
        '-C',
        gitRoot,
        'ls-files',
        '--cached',
        '-z',
        '--',
        '.hprc',
        ':(glob)**/.hprc',
      ],
      {
        encoding: 'utf8',
        timeout: GIT_DISCOVERY_TIMEOUT_MS,
        maxBuffer: MAX_GIT_OUTPUT_BYTES,
        // A launcher or Git hook must not redirect the repository, index, or pathspecs.
        env: Object.fromEntries(
          Object.entries(process.env).filter(
            ([key]) => !key.startsWith('GIT_'),
          ),
        ),
      },
    );
    // A literal Git pathspec also matches children of a directory named .hprc.
    return [
      ...new Set(
        stdout
          .split('\0')
          .filter((configPath) => path.posix.basename(configPath) === '.hprc'),
      ),
    ];
  } catch (error) {
    throw new Error(
      `Validation Error: Cannot discover Git-tracked .hprc files in '${gitRoot}'. Ensure Git is installed and this working tree is accessible. Git discovery is limited to ${GIT_DISCOVERY_TIMEOUT_MS} ms and ${MAX_GIT_OUTPUT_BYTES} output bytes. ${error instanceof Error ? error.message : String(error)}`,
      { cause: error },
    );
  }
}

/** Checks a Git-listed config for regular files without crossing symlinks or nested repositories. */
async function isRegularConfigInWorkingTree(
  gitRoot: string,
  relativeConfig: string,
): Promise<boolean> {
  // The index may still list a path whose parents were replaced in the working tree.
  let directory = gitRoot;
  for (const part of relativeConfig.split('/').slice(0, -1)) {
    directory = path.join(directory, part);
    if (!(await fs.lstat(directory)).isDirectory()) return false;
    try {
      await fs.lstat(path.join(directory, '.git'));
      return false;
    } catch (error) {
      if ((error as NodeJS.ErrnoException).code !== 'ENOENT') throw error;
    }
  }
  return (await fs.lstat(path.join(gitRoot, relativeConfig))).isFile();
}

/** Reads at most the config limit plus one byte; skips non-regular files and always closes the handle. */
async function readBoundedHprcFile(configPath: string): Promise<Buffer | null> {
  const file = await fs.open(
    configPath,
    constants.O_RDONLY | constants.O_NOFOLLOW | constants.O_NONBLOCK,
  );
  try {
    if (!(await file.stat()).isFile()) return null;
    // The extra byte detects oversized files; repeated reads handle short reads and growth.
    const buffer = Buffer.alloc(MAX_CONFIG_BYTES + 1);
    let length = 0;
    while (length < buffer.length) {
      const { bytesRead } = await file.read(
        buffer,
        length,
        buffer.length - length,
        length,
      );
      if (bytesRead === 0) break;
      length += bytesRead;
    }
    return buffer.subarray(0, length);
  } finally {
    await file.close();
  }
}

/** Validates the target service and returns the base directory for backend-relative source paths. */
export async function resolveProbeBaseDir(
  filePath: string,
  serviceId: string,
): Promise<string> {
  // An ancestor config is authoritative; only a miss enables shared-source discovery.
  const config = await findNearestAncestorHprcConfig(filePath);
  if (config) {
    if (config.serviceId !== serviceId) {
      throw new Error(
        `Validation Error: You attempted to create a probe for service ID '${serviceId}', but the file belongs to service ID '${config.serviceId}' (based on its .hprc configuration). Please correct the serviceId.`,
      );
    }
    return (await findGitWorkingTreeRoot(filePath)) || config.baseDir;
  }

  const gitRoot = await findGitWorkingTreeRoot(filePath);
  if (!gitRoot) {
    throw new Error(
      `Validation Error: The file '${filePath}' does not belong to any configured Hyperprobe service. No .hprc file found in its ancestor directories, and no Git working-tree root is available for shared-source discovery.`,
    );
  }

  // Shared-source fallback must stay in the source's actual working tree.
  let canonicalRoot: string;
  let canonicalSource: string;
  try {
    canonicalRoot = await fs.realpath(gitRoot);
    canonicalSource = await fs.realpath(filePath);
  } catch (error) {
    throw new Error(
      `Validation Error: Cannot resolve the source '${filePath}' in Git working tree '${gitRoot}'. Check the source path and filesystem permissions.`,
      { cause: error },
    );
  }
  const relativeSource = path.relative(canonicalRoot, canonicalSource);
  if (
    relativeSource === '..' ||
    relativeSource.startsWith(`..${path.sep}`) ||
    path.isAbsolute(relativeSource) ||
    (await findGitWorkingTreeRoot(canonicalSource)) !== canonicalRoot
  ) {
    throw new Error(
      `Validation Error: The source '${filePath}' must resolve within the same Git working tree '${gitRoot}'. Symlink targets outside this working tree or in a nested repository cannot use shared-source .hprc discovery.`,
    );
  }

  // Git supplies candidates; service IDs come from current working-tree contents.
  const trackedConfigs = await listTrackedHprcPaths(canonicalRoot);
  let configReads = 0;
  let incompleteReason: string | undefined;

  for (const relativeConfig of trackedConfigs) {
    const configPath = path.join(canonicalRoot, relativeConfig);
    let content: string;
    try {
      if (
        !(await isRegularConfigInWorkingTree(canonicalRoot, relativeConfig))
      ) {
        continue;
      }
      if (configReads === MAX_CONFIG_READS) {
        incompleteReason ??= `config read limit (${MAX_CONFIG_READS})`;
        break;
      }
      configReads++;
      const buffer = await readBoundedHprcFile(configPath);
      if (buffer === null) continue;
      if (buffer.length > MAX_CONFIG_BYTES) {
        incompleteReason ??= `config byte limit (${MAX_CONFIG_BYTES}) at '${configPath}'`;
        continue;
      }
      content = buffer.toString('utf-8');
    } catch (error) {
      const code = (error as NodeJS.ErrnoException).code;
      if (code === 'ENOENT' || code === 'ENOTDIR') continue;
      incompleteReason ??= `unreadable configuration '${configPath}'`;
      console.error(`Failed to read ${configPath}:`, error);
      continue;
    }

    try {
      if (content.charCodeAt(0) === 0xfeff) content = content.slice(1);
      const parsed = JSON.parse(content);
      if (
        parsed &&
        typeof parsed.serviceId === 'string' &&
        parsed.serviceId === serviceId
      ) {
        // Preserve the original root alias when the caller builds the backend path.
        return gitRoot;
      }
    } catch (error) {
      console.error(`Failed to parse ${configPath}:`, error);
    }
  }

  // Failed reads or exhausted limits do not prove that a configuration is absent.
  if (incompleteReason) {
    throw new Error(
      `Validation Error: .hprc discovery for service ID '${serviceId}' in Git working tree '${gitRoot}' was incomplete (${incompleteReason}). Check the reported path/limit and verify the service's .hprc configuration.`,
    );
  }
  throw new Error(
    `Validation Error: No .hprc configuration for service ID '${serviceId}' was found in Git working tree '${gitRoot}'. Verify serviceId and ensure its .hprc is Git-tracked and present in an accessible directory in this working tree.`,
  );
}
