#!/usr/bin/env node

import { existsSync, readFileSync, realpathSync } from 'node:fs';
import path from 'node:path';
import { Server } from '@modelcontextprotocol/sdk/server/index.js';
import { StdioServerTransport } from '@modelcontextprotocol/sdk/server/stdio.js';
import {
  CallToolRequestSchema,
  ListToolsRequestSchema,
} from '@modelcontextprotocol/sdk/types.js';
import { createTRPCProxyClient, httpBatchLink } from '@trpc/client';
import type { AppRouter } from 'backend';
import superjson from 'superjson';

import { AuthManager } from './auth.js';
import {
  isAgenticEnabled,
  MAX_WATCH_EXPRESSION_BYTES,
  MAX_WATCH_EXPRESSIONS,
} from './config.js';
import { resolveProbeBaseDir } from './service-config.js';
import {
  AGENTIC_APM_SUPPLEMENT,
  getDebuggingPlaybook,
  // JVM_INSTALL_PLAYBOOK,
  // NODEJS_INSTALL_PLAYBOOK,
} from './skills.js';

export const AGENTIC_APM_TOOL_NAMES = [
  'rca_discover_observability_context',
  'rca_get_observability_capabilities',
  'rca_query_errors',
  'rca_query_logs',
  'rca_query_traces',
  'rca_query_metrics',
  'rca_query_alerts',
] as const;

const agenticApmToolNames = new Set<string>(AGENTIC_APM_TOOL_NAMES);

// These flags are intentionally evaluated once when the MCP process starts.
export const AGENTIC_ENABLED = isAgenticEnabled();
const ALLOW_CONDITIONAL_PROBE =
  process.env.HYPERPROBE_ALLOW_CONDITIONAL_PROBE === 'true';
const ALLOW_WATCH_EXPR = process.env.HYPERPROBE_ALLOW_WATCH_EXPR === 'true';

type McpTrpcClient = ReturnType<typeof createTRPCProxyClient<AppRouter>>;

interface McpAuthManager {
  getAccessToken(): string | null;
  getLoginUrl(): string | null;
}

export interface McpRuntime {
  authManager: McpAuthManager;
  trpc: McpTrpcClient;
}

function optString(val: unknown): string | undefined {
  return typeof val === 'string' && val.trim().length > 0
    ? val.trim()
    : undefined;
}

const MAX_OBSERVABILITY_ROWS = 25;
const MIN_METRIC_INTERVAL_SECONDS = 60;
const MAX_METRIC_INTERVAL_SECONDS = 3_600;

function optInteger(
  val: unknown,
  minBound = 1,
  maxBound?: number,
): number | undefined {
  let num: number | undefined;
  if (typeof val === 'number' && Number.isFinite(val)) {
    num = Math.floor(val);
  } else if (typeof val === 'string' && val.trim().length > 0) {
    const parsed = Number(val.trim());
    if (Number.isFinite(parsed)) num = Math.floor(parsed);
  }
  if (num === undefined) return undefined;
  if (num < minBound) return minBound;
  if (maxBound !== undefined && num > maxBound) return maxBound;
  return num;
}

const bigIntReplacer = (_key: string, value: any) => {
  if (typeof value === 'bigint') {
    return value.toString();
  }
  return value;
};

const jsonStringifyWithBigInt = (obj: any) => {
  return JSON.stringify(obj, bigIntReplacer, 2);
};

// // @ts-expect-error toJSON override
// BigInt.prototype.toJSON = function () {
//   return this.toString();
// };

export function createMcpHandlers(runtime: McpRuntime) {
  const { authManager, trpc } = runtime;
  const agenticEnabled = AGENTIC_ENABLED;

  const listTools = async () => {
    const tools = [
      {
        name: 'list_services',
        description: 'List all microservices connected to Hyperprobe.',
        inputSchema: {
          type: 'object',
          properties: {},
        },
      },
      {
        name: 'list_active_agents',
        description:
          'List active agents for specific service IDs. Note: ONLY required when attaching a new live probe to a running process daemon. Do not call when inspecting historical APM incidents or existing snapshots. ' +
          "CRITICAL RULE: After calling this tool, you MUST compare your local repository's current commit SHA against the active deployment SHAs. If your local commit does not match the target deployment, ask the user before creating a detached worktree at the live commit. Do NOT create probes or guess line numbers on a mismatched commit.",
        inputSchema: {
          type: 'object',
          properties: {
            serviceIds: {
              type: 'array',
              items: { type: 'string' },
              description: 'Array of service IDs',
            },
          },
          required: ['serviceIds'],
        },
      },
      {
        name: 'create_probe',
        description:
          (ALLOW_CONDITIONAL_PROBE
            ? 'Create a snapshot probe at a specific file and line number. Supports conditional probing (condition) to isolate specific traffic and APM trace ID correlation (shouldCaptureTraceId).'
            : 'Create an unconditional snapshot probe at a specific file and line number. Conditional probing is not available on this MCP server. Supports APM trace ID correlation (shouldCaptureTraceId).') +
          (ALLOW_WATCH_EXPR
            ? ` Supports optional watchExpressions (up to ${MAX_WATCH_EXPRESSIONS} expressions, ${MAX_WATCH_EXPRESSION_BYTES} UTF-8 bytes each).`
            : ''),
        inputSchema: {
          type: 'object',
          properties: {
            serviceId: {
              type: 'string',
              description:
                'Target service UUID retained from incident context, including shared source; ask if ambiguous.',
            },
            environment: { type: 'string' },
            commitSha: {
              type: 'string',
              description:
                'full commitSha for the deployment where probe needs to be set',
            },
            uiFilePath: {
              type: 'string',
              description:
                'Absolute local source file path. MCP resolves the service configuration and repository-relative coordinate.',
            },
            uiLineNumber: {
              type: 'number',
              description: '1-based line number',
            },
            uiColumnNumber: {
              type: 'number',
              description: '1-based column number, default 1',
            },
            hitLimit: {
              type: 'number',
              description: 'Max number of hits, default 1',
            },
            expiryTime: {
              type: 'number',
              description: 'Unix timestamp in ms when probe expires.',
            },
            ...(ALLOW_CONDITIONAL_PROBE
              ? {
                  condition: {
                    type: 'string',
                    description:
                      'Optional boolean expression evaluated at runtime in probe scope. The probe will ONLY capture when this condition evaluates to true. ' +
                      'Crucial for high-traffic endpoints or isolating specific tenants/users. ' +
                      'Syntax is runtime-specific: ' +
                      'JS/TS: e.g. "userId === \'usr_123\'", "cart.total > 500", "items.length > 0"; ' +
                      'JVM (MVEL): e.g. "userId.equals(\'usr_123\')", "items.size() > 5", "user.name.startsWith(\'A\')"; ' +
                      'Python: e.g. "user_id == \'usr_123\'", "len(items) > 5". ' +
                      'Variables referenced must already be declared and in scope at uiLineNumber.',
                  },
                }
              : {}),
            ...(ALLOW_WATCH_EXPR
              ? {
                  watchExpressions: {
                    type: 'array',
                    items: { type: 'string' },
                    maxItems: MAX_WATCH_EXPRESSIONS,
                    description: `Optional user-requested, pure runtime expressions valid in scope at uiLineNumber. At most ${MAX_WATCH_EXPRESSIONS} expressions per probe, each nonblank and at most ${MAX_WATCH_EXPRESSION_BYTES} UTF-8 bytes of expression text (not characters or the returned value).`,
                  },
                }
              : {}),
            shouldCaptureTraceId: {
              type: 'boolean',
              description:
                'Whether to extract and capture the active distributed tracing trace ID from APM context ' +
                '(OpenTelemetry, Datadog, New Relic, SkyWalking, AWS X-Ray, etc.) when the snapshot is taken. Default false.',
            },
            captureClosures: {
              type: 'boolean',
              description:
                'Whether to capture closures in snapshots, default false',
            },
          },
          required: [
            'serviceId',
            'environment',
            'commitSha',
            'uiFilePath',
            'uiLineNumber',
            'hitLimit',
          ],
        },
      },
      {
        name: 'wait_for_probe_ready',
        description:
          'Wait until a newly created probe is confirmed to be LIVE in the remote environment. This confirms installation only; choose whether to wait for a snapshot based on expected traffic.',
        inputSchema: {
          type: 'object',
          properties: {
            probeId: { type: 'string' },
            serviceId: {
              type: 'string',
              description: 'The service ID the probe belongs to.',
            },
          },
          required: ['probeId', 'serviceId'],
        },
      },
      {
        name: 'wait_for_snapshot',
        description:
          'Wait for a snapshot to be captured for a specific probe ID. Blocks until a snapshot is hit or a timeout occurs. Returns snapshot data including captured variables, call stack frames, and traceId when capture was enabled and a trace ID was available.',
        inputSchema: {
          type: 'object',
          properties: {
            probeId: { type: 'string' },
            serviceId: {
              type: 'string',
              description: 'The service ID the probe belongs to.',
            },
          },
          required: ['probeId', 'serviceId'],
        },
      },
      {
        name: 'list_snapshots',
        description:
          'List all snapshots captured for a specific probe, including captured variables, call stack frames, and traceId when available. Use this to inspect empirical runtime values without guessing.',
        inputSchema: {
          type: 'object',
          properties: {
            probeId: { type: 'string' },
          },
          required: ['probeId'],
        },
      },
      {
        name: 'list_probes',
        description:
          'List all probes and completed hits for specific service IDs. Call early during incident triage to discover pre-existing probes and captured runtime snapshots.',
        inputSchema: {
          type: 'object',
          properties: {
            serviceIds: {
              type: 'array',
              items: { type: 'string' },
              description: 'Array of service IDs',
            },
          },
          required: ['serviceIds'],
        },
      },
      {
        name: 'rca_discover_observability_context',
        description:
          "Discover bounded environment candidates, recent releases, tag keys, and the service's configured capability sources. Scope investigation strictly to the target environment (e.g. production); avoid querying non-incident environments unless needed.",
        inputSchema: {
          type: 'object',
          properties: {
            serviceId: { type: 'string' },
          },
          required: ['serviceId'],
        },
      },
      {
        name: 'rca_get_observability_capabilities',
        description:
          'Check which enabled observability capabilities can be retrieved for a selected service and provider environment. A capability disabled in the service integration is returned as UNAVAILABLE and must not be queried.',
        inputSchema: {
          type: 'object',
          properties: {
            serviceId: { type: 'string' },
            environment: {
              type: 'string',
              description:
                'Hyperprobe runtime environment used for agents and probes.',
            },
            providerEnvironment: {
              type: 'string',
              description:
                'Provider environment selected from discovery. Defaults to environment.',
            },
            release: {
              type: 'string',
              description:
                'Optional literal provider release selected from discovery.',
            },
          },
          required: ['serviceId', 'environment'],
        },
      },
      {
        name: 'rca_query_errors',
        description:
          'Query a bounded window of normalized application errors from configured observability sources. When an error provides a file path and line number, anchor directly on that source location and its snapshots; do not wander into broad repo scans.',
        inputSchema: {
          type: 'object',
          properties: {
            serviceId: { type: 'string' },
            environment: { type: 'string' },
            providerEnvironment: {
              type: 'string',
              description:
                'Provider environment selected from discovery. Defaults to environment.',
            },
            release: {
              type: 'string',
              description:
                'Optional literal provider release selected from discovery.',
            },
            start: { type: 'string', description: 'ISO-8601 start time.' },
            end: { type: 'string', description: 'ISO-8601 end time.' },
            filter: { type: 'string' },
            traceId: { type: 'string' },
            traceFormat: {
              type: 'string',
              description: 'Optional provider-specific trace ID format.',
            },
            purpose: {
              type: 'string',
              description: 'Concise reason for this read-only evidence query.',
            },
            limit: { type: 'number', minimum: 1, maximum: 25, default: 20 },
            cursor: {
              type: 'string',
              description: 'Opaque cursor from a prior result.',
            },
          },
          required: ['serviceId', 'environment', 'start', 'end', 'purpose'],
        },
      },
      {
        name: 'rca_query_logs',
        description:
          'Query a bounded window of normalized application logs from configured observability sources. Use traceId or a semantic filter to narrow a follow-up query.',
        inputSchema: {
          type: 'object',
          properties: {
            serviceId: { type: 'string' },
            environment: { type: 'string' },
            providerEnvironment: {
              type: 'string',
              description:
                'Provider environment selected from discovery. Defaults to environment.',
            },
            release: {
              type: 'string',
              description:
                'Optional literal provider release selected from discovery.',
            },
            start: { type: 'string', description: 'ISO-8601 start time.' },
            end: { type: 'string', description: 'ISO-8601 end time.' },
            filter: { type: 'string' },
            traceId: { type: 'string' },
            traceFormat: {
              type: 'string',
              description: 'Optional provider-specific trace ID format.',
            },
            purpose: {
              type: 'string',
              description: 'Concise reason for this read-only evidence query.',
            },
            limit: { type: 'number', minimum: 1, maximum: 25, default: 20 },
            cursor: {
              type: 'string',
              description: 'Opaque cursor from a prior result.',
            },
          },
          required: ['serviceId', 'environment', 'start', 'end', 'purpose'],
        },
      },
      {
        name: 'rca_query_traces',
        description:
          'Query bounded normalized spans from configured observability sources. Prefer a traceId returned by errors or logs over a broad trace search.',
        inputSchema: {
          type: 'object',
          properties: {
            serviceId: { type: 'string' },
            environment: { type: 'string' },
            providerEnvironment: {
              type: 'string',
              description:
                'Provider environment selected from discovery. Defaults to environment.',
            },
            release: {
              type: 'string',
              description:
                'Optional literal provider release selected from discovery.',
            },
            start: { type: 'string', description: 'ISO-8601 start time.' },
            end: { type: 'string', description: 'ISO-8601 end time.' },
            filter: { type: 'string' },
            traceId: { type: 'string' },
            traceFormat: {
              type: 'string',
              description: 'Optional provider-specific trace ID format.',
            },
            purpose: {
              type: 'string',
              description: 'Concise reason for this read-only evidence query.',
            },
            limit: { type: 'number', minimum: 1, maximum: 25, default: 20 },
            cursor: {
              type: 'string',
              description: 'Opaque cursor from a prior result.',
            },
          },
          required: ['serviceId', 'environment', 'start', 'end', 'purpose'],
        },
      },
      {
        name: 'rca_query_metrics',
        description:
          'Query a bounded normalized metric time series from configured observability sources for throughput or failure rate in the incident window.',
        inputSchema: {
          type: 'object',
          properties: {
            serviceId: { type: 'string' },
            environment: { type: 'string' },
            providerEnvironment: {
              type: 'string',
              description:
                'Provider environment selected from discovery. Defaults to environment.',
            },
            release: {
              type: 'string',
              description:
                'Optional literal provider release selected from discovery.',
            },
            start: { type: 'string', description: 'ISO-8601 start time.' },
            end: { type: 'string', description: 'ISO-8601 end time.' },
            filter: { type: 'string' },
            metric: { type: 'string', enum: ['THROUGHPUT', 'FAILURE_RATE'] },
            intervalSeconds: {
              type: 'number',
              minimum: 60,
              maximum: 3600,
              description:
                'Requested minimum bucket width in seconds. Rounded up to a supported interval when needed; the response reports the effective interval.',
            },
            purpose: {
              type: 'string',
              description: 'Concise reason for this read-only evidence query.',
            },
          },
          required: ['serviceId', 'environment', 'start', 'end', 'purpose'],
        },
      },
      {
        name: 'rca_query_alerts',
        description:
          'Query a bounded window of normalized alert evidence from configured observability sources. This is read-only and cannot acknowledge, resolve, or create alerts.',
        inputSchema: {
          type: 'object',
          properties: {
            serviceId: { type: 'string' },
            environment: { type: 'string' },
            providerEnvironment: {
              type: 'string',
              description:
                'Source environment selected from discovery. Defaults to environment.',
            },
            release: {
              type: 'string',
              description:
                'Optional literal source release selected from discovery.',
            },
            start: { type: 'string', description: 'ISO-8601 start time.' },
            end: { type: 'string', description: 'ISO-8601 end time.' },
            filter: { type: 'string' },
            purpose: {
              type: 'string',
              description: 'Concise reason for this read-only evidence query.',
            },
            limit: { type: 'number', minimum: 1, maximum: 25, default: 20 },
            cursor: {
              type: 'string',
              description: 'Opaque cursor from a prior result.',
            },
          },
          required: ['serviceId', 'environment', 'start', 'end', 'purpose'],
        },
      },
      // {
      //   name: 'get_installation_playbook',
      //   description:
      //     'Retrieve the step-by-step expert installation guide/playbook for a specific runtime language. ' +
      //     'Call this tool immediately when the user asks to setup, install, or add Hyperprobe to their application.',
      //   inputSchema: {
      //     type: 'object',
      //     properties: {
      //       language: {
      //         type: 'string',
      //         enum: ['nodejs', 'jvm'],
      //         description:
      //           'The programming language/runtime of the target repository.',
      //       },
      //     },
      //     required: ['language'],
      //   },
      // },
      {
        name: 'get_debugging_playbook',
        description:
          'REQUIRED FIRST TOOL for every Hyperprobe RCA or live-production debugging request. Returns the source/probe debugging workflow, probe rules, and evidence standards for this MCP connection.',
        inputSchema: {
          type: 'object',
          properties: {},
        },
      },
      // {
      //   name: 'list_teams',
      //   description:
      //     'List all teams the authenticated user belongs to. Use this to find the team ID to associate with a new service.',
      //   inputSchema: {
      //     type: 'object',
      //     properties: {},
      //   },
      // },
      // {
      //   name: 'create_service',
      //   description:
      //     'Create a new service in Hyperprobe and return its serviceId. To ensure accuracy, especially if the user is in multiple teams, double-confirm that the correct teamId and team_name are selected.',
      //   inputSchema: {
      //     type: 'object',
      //     properties: {
      //       name: {
      //         type: 'string',
      //         description:
      //           'The name of the new service (usually the project folder name or package.json name).',
      //       },
      //       teamId: {
      //         type: 'string',
      //         description: 'The UUID of the team that will own this service.',
      //       },
      //       team_name: {
      //         type: 'string',
      //         description:
      //           'The name of the team, used to double-confirm correct team association.',
      //       },
      //       sourceMapRequired: {
      //         type: 'boolean',
      //         description:
      //           'Whether JS source maps are required (e.g. true for TypeScript, Babel, or compiled projects).',
      //       },
      //     },
      //     required: ['name', 'teamId', 'team_name', 'sourceMapRequired'],
      //   },
      // },
    ];

    return {
      tools: agenticEnabled
        ? tools
        : tools.filter((tool) => !agenticApmToolNames.has(tool.name)),
    };
  };

  const callTool = async (request: any) => {
    if (!authManager.getAccessToken()) {
      const loginUrl = authManager.getLoginUrl();
      const loginMessage = loginUrl
        ? `Please log in by clicking this link:\n${loginUrl}\n\nOnce you have logged in, wait a few seconds and try running your request again.`
        : `Authentication is temporarily unavailable. The server is retrying your saved session automatically; no new login is needed.\n\nPlease try your request again later.`;

      return {
        content: [
          {
            type: 'text',
            text: `Error: Hyperprobe MCP Server is not authenticated.\n\n${loginMessage}`,
          },
        ],
        isError: true,
      };
    }

    if (!agenticEnabled && agenticApmToolNames.has(request.params.name)) {
      return {
        content: [
          {
            type: 'text',
            text: 'Error: Agentic APM tools are disabled for this MCP server.',
          },
        ],
        isError: true,
      };
    }

    try {
      switch (request.params.name) {
        // case 'get_installation_playbook': {
        //   const { language } = request.params.arguments as any;
        //   const content =
        //     language === 'nodejs'
        //       ? NODEJS_INSTALL_PLAYBOOK
        //       : JVM_INSTALL_PLAYBOOK;
        //   return {
        //     content: [{ type: 'text', text: content }],
        //   };
        // }
        case 'rca_discover_observability_context': {
          const args = request.params.arguments as any;
          const result = await trpc.rca.discoverObservabilityContext.query({
            serviceId: args.serviceId,
          });
          return {
            content: [{ type: 'text', text: jsonStringifyWithBigInt(result) }],
          };
        }
        case 'rca_get_observability_capabilities': {
          const args = request.params.arguments as any;
          const providerEnvironment = optString(args.providerEnvironment);
          const release = optString(args.release);
          const result = await trpc.rca.getCapabilities.query({
            serviceId: args.serviceId,
            environment: args.environment,
            ...(providerEnvironment ? { providerEnvironment } : {}),
            ...(release ? { release } : {}),
          });
          return {
            content: [{ type: 'text', text: jsonStringifyWithBigInt(result) }],
          };
        }
        case 'rca_query_errors':
        case 'rca_query_logs':
        case 'rca_query_traces':
        case 'rca_query_alerts': {
          const args = request.params.arguments as any;
          const providerEnvironment = optString(args.providerEnvironment);
          const release = optString(args.release);
          const filter = optString(args.filter);
          const traceId = optString(args.traceId);
          const traceFormat = optString(args.traceFormat);
          const cursor = optString(args.cursor);
          const purpose = optString(args.purpose);
          if (!purpose)
            throw new Error('purpose is required for RCA evidence queries.');
          const limit = optInteger(args.limit, 1, MAX_OBSERVABILITY_ROWS);
          const query = {
            serviceId: args.serviceId,
            environment: args.environment,
            ...(providerEnvironment ? { providerEnvironment } : {}),
            ...(release ? { release } : {}),
            timeRange: { start: args.start, end: args.end },
            ...(filter ? { filter } : {}),
            ...(traceId ? { traceId } : {}),
            ...(traceFormat ? { traceFormat } : {}),
            ...(limit !== undefined ? { limit } : {}),
            ...(cursor ? { cursor } : {}),
            purpose,
          };
          const result =
            request.params.name === 'rca_query_errors'
              ? await trpc.rca.queryErrors.mutate(query)
              : request.params.name === 'rca_query_logs'
                ? await trpc.rca.queryLogs.mutate(query)
                : request.params.name === 'rca_query_traces'
                  ? await trpc.rca.queryTraces.mutate(query)
                  : await trpc.rca.queryAlerts.mutate(query);
          return {
            content: [{ type: 'text', text: jsonStringifyWithBigInt(result) }],
          };
        }
        case 'rca_query_metrics': {
          const args = request.params.arguments as any;
          const providerEnvironment = optString(args.providerEnvironment);
          const release = optString(args.release);
          const filter = optString(args.filter);
          const purpose = optString(args.purpose);
          if (!purpose)
            throw new Error('purpose is required for RCA evidence queries.');
          const metric = optString(args.metric) as
            | 'THROUGHPUT'
            | 'FAILURE_RATE'
            | undefined;
          const intervalSeconds = optInteger(
            args.intervalSeconds,
            MIN_METRIC_INTERVAL_SECONDS,
            MAX_METRIC_INTERVAL_SECONDS,
          );
          const query = {
            serviceId: args.serviceId,
            environment: args.environment,
            ...(providerEnvironment ? { providerEnvironment } : {}),
            ...(release ? { release } : {}),
            timeRange: { start: args.start, end: args.end },
            ...(filter ? { filter } : {}),
            ...(metric ? { metric } : {}),
            ...(intervalSeconds !== undefined ? { intervalSeconds } : {}),
            purpose,
          };
          const result = await trpc.rca.queryMetrics.mutate(query);
          return {
            content: [{ type: 'text', text: jsonStringifyWithBigInt(result) }],
          };
        }
        case 'get_debugging_playbook': {
          const sourceGuide = getDebuggingPlaybook(
            ALLOW_CONDITIONAL_PROBE,
            ALLOW_WATCH_EXPR,
          );
          return {
            content: [
              {
                type: 'text',
                text: agenticEnabled
                  ? `${sourceGuide}\n${AGENTIC_APM_SUPPLEMENT}`
                  : sourceGuide,
              },
            ],
          };
        }
        // case 'list_teams': {
        //   const teams = await trpc.teams.list.query();
        //   const retVal = teams.map((t) => ({ id: t.id, name: t.name }));
        //   return {
        //     content: [{ type: 'text', text: jsonStringifyWithBigInt(retVal) }],
        //   };
        // }
        // case 'create_service': {
        //   const { name, teamId, team_name, sourceMapRequired } = request.params
        //     .arguments as any;

        //   // Double-check if the team exists and matches the provided team_name to confirm correctness
        //   const teams = await trpc.teams.list.query();
        //   const matchingTeam = teams.find((t) => t.id === teamId);
        //   if (!matchingTeam) {
        //     throw new Error(
        //       `Validation Error: Team ID '${teamId}' was not found in your authenticated teams list. ` +
        //         'Please call list_teams to find your valid team IDs.',
        //     );
        //   }

        //   if (matchingTeam.name.toLowerCase() !== team_name.toLowerCase()) {
        //     throw new Error(
        //       `Validation Error: Team name mismatch! The team ID '${teamId}' actually belongs to the team named '${matchingTeam.name}', ` +
        //         `but you provided '${team_name}'. Please double-confirm and call again with correct parameters.`,
        //     );
        //   }

        //   const result = await trpc.services.create.mutate({
        //     name,
        //     teamIds: [teamId],
        //     sourceMapRequired: !!sourceMapRequired,
        //   });

        //   return {
        //     content: [
        //       {
        //         type: 'text',
        //         text: jsonStringifyWithBigInt({
        //           serviceId: result.id,
        //           name: result.name,
        //           team: matchingTeam.name,
        //         }),
        //       },
        //     ],
        //   };
        // }
        case 'list_services': {
          const services = await trpc.services.list.query();
          const retVal = services.map((x) => ({
            id: x.id,
            name: x.name,
            jsSourceMapsRequired: x.sourceMapRequired,
          }));
          return {
            content: [{ type: 'text', text: jsonStringifyWithBigInt(retVal) }],
          };
        }
        case 'list_active_agents': {
          const { serviceIds } = request.params.arguments as any;
          const agents = await trpc.listActiveAgents.query({ serviceIds });
          return {
            content: [{ type: 'text', text: jsonStringifyWithBigInt(agents) }],
          };
        }
        case 'list_probes': {
          const { serviceIds } = request.params.arguments as any;
          const probes = await trpc.listProbes.query({ serviceIds });
          return {
            content: [{ type: 'text', text: jsonStringifyWithBigInt(probes) }],
          };
        }
        case 'create_probe': {
          const { watchExpressions, ...args } = request.params.arguments as any;
          if (
            args.condition !== undefined &&
            typeof args.condition !== 'string'
          ) {
            throw new Error('Validation Error: condition must be a string.');
          }
          const condition = optString(args.condition);
          if (!ALLOW_CONDITIONAL_PROBE && condition) {
            throw new Error(
              'Conditional probing is not available on this Hyperprobe MCP server. The probe was not created.',
            );
          }
          if (ALLOW_WATCH_EXPR && watchExpressions !== undefined) {
            if (!Array.isArray(watchExpressions)) {
              throw new Error(
                `Validation Error: watchExpressions must be an array of strings (at most ${MAX_WATCH_EXPRESSIONS} expressions, ${MAX_WATCH_EXPRESSION_BYTES} UTF-8 bytes each). The probe was not created.`,
              );
            }
            if (watchExpressions.length > MAX_WATCH_EXPRESSIONS) {
              throw new Error(
                `Validation Error: watchExpressions has ${watchExpressions.length} expressions; maximum is ${MAX_WATCH_EXPRESSIONS} per probe. The probe was not created.`,
              );
            }
            for (let index = 0; index < watchExpressions.length; index++) {
              const expression = watchExpressions[index];
              if (typeof expression !== 'string') {
                throw new Error(
                  `Validation Error: watchExpressions at zero-based index ${index} must be a string (UTF-8 byte count unavailable). The probe was not created.`,
                );
              }
              const byteCount = Buffer.byteLength(expression, 'utf8');
              if (byteCount > MAX_WATCH_EXPRESSION_BYTES) {
                throw new Error(
                  `Validation Error: watchExpressions at zero-based index ${index} has ${byteCount} UTF-8 bytes; maximum is ${MAX_WATCH_EXPRESSION_BYTES} bytes per expression. The probe was not created.`,
                );
              }
              if (expression.trim().length === 0) {
                throw new Error(
                  `Validation Error: watchExpressions at zero-based index ${index} is blank (${byteCount} UTF-8 bytes). The probe was not created.`,
                );
              }
            }
          }
          if (!existsSync(args.uiFilePath)) {
            throw new Error(
              `Validation Error: The file '${args.uiFilePath}' does not exist on your local disk. Please check for typos in the file path.`,
            );
          }
          const baseDir = await resolveProbeBaseDir(
            args.uiFilePath,
            args.serviceId,
          );

          const activeAgents = await trpc.listActiveAgents.query({
            serviceIds: [args.serviceId],
          });
          const matchingAgents = activeAgents.filter(
            (a: any) =>
              a.environment === args.environment &&
              a.commitSha === args.commitSha,
          );
          if (matchingAgents.length === 0) {
            throw new Error(
              `Cannot create probe. There are no active agents running commit '${args.commitSha}' in environment '${args.environment}'. Please verify the deployment state using list_active_agents.`,
            );
          }

          const relativePath = path
            .relative(baseDir, args.uiFilePath)
            .replace(/\\/g, '/');

          const now = Date.now();
          let expiryTime: number;
          if (
            args.expiryTime === undefined ||
            Number.isNaN(Number(args.expiryTime))
          ) {
            expiryTime = now + 60 * 60 * 1000; // Default to 1 hour if not specified
          } else {
            expiryTime = Math.floor(Number(args.expiryTime));
            const minExpiry = now + 10 * 60 * 1000; // 10-minute safety bound
            if (expiryTime < minExpiry) {
              expiryTime = minExpiry;
            }
          }
          const shouldCaptureTraceId =
            args.shouldCaptureTraceId === true ||
            args.shouldCaptureTraceId === 'true';
          const captureClosures =
            args.captureClosures === true || args.captureClosures === 'true';

          const result = await trpc.createProbe.mutate({
            ...args,
            ...(ALLOW_WATCH_EXPR && watchExpressions !== undefined
              ? { watchExpressions }
              : {}),
            uiFilePath: relativePath,
            expiryTime,
            type: 'SNAPSHOT',
            condition,
            shouldCaptureTraceId,
            captureClosures,
          });
          return {
            content: [{ type: 'text', text: jsonStringifyWithBigInt(result) }],
          };
        }
        case 'wait_for_probe_ready': {
          const { probeId, serviceId } = request.params.arguments as any;
          const timeoutMs = 90000;
          const intervalMs = 3000;
          const startTime = Date.now();

          while (Date.now() - startTime < timeoutMs) {
            const probes = await trpc.listProbes.query({
              serviceIds: [serviceId],
            });
            const probe = probes.find((p) => p.id === probeId);
            if (!probe) {
              return {
                content: [
                  {
                    type: 'text',
                    text: `Error: Probe ${probeId} not found. It may have expired, been deleted, or the probeId/serviceId parameters may contain a typo.`,
                  },
                ],
                isError: true,
              };
            }

            if (probe && probe.status === 'COMPLETED') {
              return {
                content: [
                  {
                    type: 'text',
                    text: `Success: The probe is already complete`,
                  },
                ],
              };
            }

            if (probe && probe.isLive) {
              return {
                content: [
                  {
                    type: 'text',
                    text: `Success: The probe is now LIVE and installed in the remote environment.`,
                  },
                ],
              };
            }
            await new Promise((resolve) => setTimeout(resolve, intervalMs));
          }

          return {
            content: [
              {
                type: 'text',
                text: `Warning: The probe did not become LIVE within 90 seconds. It might still be syncing, or the agent may be disconnected.`,
              },
            ],
          };
        }

        case 'wait_for_snapshot': {
          const { probeId, serviceId } = request.params.arguments as any;

          // 1. Initial Guardrail Check
          const probes = await trpc.listProbes.query({
            serviceIds: [serviceId],
          });
          const probe = probes.find((p: any) => p.id === probeId);

          if (!probe) {
            return {
              content: [
                {
                  type: 'text',
                  text: `Error: Probe ${probeId} not found. It may have expired or been deleted.`,
                },
              ],
              isError: true,
            };
          }

          if (!probe.isLive && probe.status === 'ACTIVE') {
            return {
              content: [
                {
                  type: 'text',
                  text: `Error: Probe ${probeId} is NOT LIVE. You must call 'wait_for_probe_ready' first to ensure the probe is installed before waiting for snapshots.`,
                },
              ],
              isError: true,
            };
          }

          // 2. Proceed with normal polling loop if it IS live
          const timeoutMs = 30000;
          const intervalMs = 2000;
          const startTime = Date.now();

          while (Date.now() - startTime < timeoutMs) {
            const snapshots = await trpc.listSnapshots.query({ probeId });
            if (snapshots && snapshots.length > 0) {
              return {
                content: [
                  { type: 'text', text: jsonStringifyWithBigInt(snapshots) },
                ],
              };
            }
            await new Promise((resolve) => setTimeout(resolve, intervalMs));
          }

          return {
            content: [
              {
                type: 'text',
                text: `No snapshot was captured within 30 seconds. The probe remains active; traffic may arrive naturally, or the user can choose to trigger the relevant flow. Use list_snapshots later to check again.`,
              },
            ],
          };
        }
        case 'list_snapshots': {
          const { probeId } = request.params.arguments as any;
          const snapshots = await trpc.listSnapshots.query({ probeId });
          // snapshots = snapshots.map(s => {
          //   s.payload.vars = [s.payload.vars[0][0]]
          //   return s
          // })
          return {
            content: [
              { type: 'text', text: jsonStringifyWithBigInt(snapshots) },
            ],
          };
        }
        default:
          throw new Error(`Unknown tool: ${request.params.name}`);
      }
    } catch (error: any) {
      const retryAt = error?.data?.retryAt;
      return {
        content: [
          {
            type: 'text',
            text: retryAt
              ? jsonStringifyWithBigInt({
                  error: 'RATE_LIMITED',
                  message: error.message,
                  retryAt,
                })
              : `Error: ${error.message}`,
          },
        ],
        isError: true,
      };
    }
  };

  return { callTool, listTools };
}

export function createMcpServer(runtime: McpRuntime) {
  const pkgPath = new URL('../package.json', import.meta.url);
  const pkg = JSON.parse(readFileSync(pkgPath, 'utf-8')) as { version: string };
  const server = new Server(
    {
      name: 'hyperprobe-mcp',
      version: pkg.version,
    },
    {
      capabilities: {
        tools: {},
      },
    },
  );
  const { callTool, listTools } = createMcpHandlers(runtime);

  server.setRequestHandler(ListToolsRequestSchema, listTools);
  server.setRequestHandler(CallToolRequestSchema, callTool);

  return server;
}

async function run() {
  try {
    const rawBackendUrl = process.env.BACKEND_URL;
    if (!rawBackendUrl) {
      throw new Error('BACKEND_URL is not defined');
    }
    const backendUrl = rawBackendUrl.trim().replace(/\/+$/, '');

    const authManager = new AuthManager(backendUrl);
    const trpc = createTRPCProxyClient<AppRouter>({
      transformer: superjson,
      links: [
        httpBatchLink({
          url: `${backendUrl}/trpc`,
          headers: () => {
            const token = authManager.getAccessToken();
            return token ? { authorization: `Bearer ${token}` } : {};
          },
        }),
      ],
    });
    const server = createMcpServer({ authManager, trpc });

    await authManager.init();
    console.error('Hyperprobe MCP server running on stdio');
    const transport = new StdioServerTransport();
    await server.connect(transport);
  } catch (err) {
    console.error('Failed to initialize authentication:', err);
  }
}

function isMainModule(): boolean {
  const entryPoint = process.argv[1];
  if (!entryPoint) return false;
  try {
    // npm/npx can launch a symlink while Node resolves the module URL.
    return realpathSync(entryPoint) === realpathSync(new URL(import.meta.url));
  } catch {
    return false;
  }
}

if (isMainModule()) {
  void run();
}
