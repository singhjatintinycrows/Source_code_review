export const AGENTIC_ENABLED_ENV = 'HYPERPROBE_AGENTIC_ENABLED';
export const MAX_WATCH_EXPRESSIONS = 10;
export const MAX_WATCH_EXPRESSION_BYTES = 256;

export function isAgenticEnabled(
  environment: NodeJS.ProcessEnv = process.env,
): boolean {
  return environment[AGENTIC_ENABLED_ENV] === 'true';
}
