import crypto from 'node:crypto';
import { existsSync } from 'node:fs';
import fs from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import {
  createTRPCProxyClient,
  httpBatchLink,
  TRPCClientError,
} from '@trpc/client';
import type { AppRouter } from 'backend';
import open from 'open';
import superjson from 'superjson';

type RefreshResult = 'success' | 'invalid' | 'unavailable';

export class AuthManager {
  private configDir: string;
  private configFile: string;
  private refreshToken: string | null = null;
  private accessToken: string | null = null;
  private backendUrl: string;
  private loginIdentifier: string | null = null;
  private loginUrl: string | null = null;
  private isAuthInProgress = false;
  private refreshInterval: NodeJS.Timeout | null = null;

  constructor(backendUrl: string) {
    this.backendUrl = backendUrl.replace(/\/+$/, '');
    this.configDir = path.join(os.homedir(), '.hyperprobe');
    this.configFile = path.join(this.configDir, 'auth.json');
    this.accessToken = process.env.HYPERPROBE_ACCESS_TOKEN?.trim() || null;
  }

  public async init() {
    if (this.accessToken) {
      console.error(
        'Using the injected Hyperprobe access token for this MCP process.',
      );
      return;
    }

    try {
      await fs.mkdir(this.configDir, { recursive: true, mode: 0o700 });
    } catch (err) {
      console.error(`Failed to create directory ${this.configDir}:`, err);
    }

    const loaded = await this.loadToken();
    if (loaded) {
      const result = await this.refreshAccessToken();
      if (result === 'success') {
        console.error('Successfully authenticated using cached refresh token.');
        this.startBackgroundRefresh();
        return;
      }
      if (result === 'unavailable') {
        this.startBackgroundRefresh(60 * 1000);
        return;
      }
      this.refreshToken = null;
      await this.deleteToken();
      console.error(
        'Cached refresh token is invalid or expired. Initiating login flow...',
      );
    }

    await this.startLoginFlow();
  }

  private async loadToken(): Promise<boolean> {
    try {
      if (existsSync(this.configFile)) {
        const dataStr = await fs.readFile(this.configFile, 'utf-8');
        const data = JSON.parse(dataStr);
        if (
          data &&
          data.sessions &&
          typeof data.sessions[this.backendUrl] === 'string'
        ) {
          this.refreshToken = data.sessions[this.backendUrl];
          return true;
        }
      }
    } catch (_err) {
      console.error('Failed to read auth file:', _err);
    }
    return false;
  }

  private async saveToken(refreshToken: string) {
    try {
      this.refreshToken = refreshToken;

      let data: any = { sessions: {} };
      if (existsSync(this.configFile)) {
        try {
          const dataStr = await fs.readFile(this.configFile, 'utf-8');
          data = JSON.parse(dataStr);
          if (!data.sessions) {
            data.sessions = {};
          }
        } catch (_err) {
          // Reset if corrupted
          data = { sessions: {} };
        }
      }

      data.sessions[this.backendUrl] = refreshToken;

      await fs.writeFile(this.configFile, JSON.stringify(data, null, 2), {
        encoding: 'utf-8',
        mode: 0o600,
      });
    } catch (err) {
      console.error('Failed to save refresh token to disk:', err);
    }
  }

  private async deleteToken() {
    try {
      if (existsSync(this.configFile)) {
        const dataStr = await fs.readFile(this.configFile, 'utf-8');
        const data = JSON.parse(dataStr);
        if (data && data.sessions && data.sessions[this.backendUrl]) {
          delete data.sessions[this.backendUrl];
          await fs.writeFile(this.configFile, JSON.stringify(data, null, 2), {
            encoding: 'utf-8',
            mode: 0o600,
          });
        }
      }
    } catch (_err) {}
  }

  private async refreshAccessToken(): Promise<RefreshResult> {
    if (!this.refreshToken) return 'invalid';
    try {
      const tempTrpc = createTRPCProxyClient<AppRouter>({
        transformer: superjson,
        links: [httpBatchLink({ url: `${this.backendUrl}/trpc` })],
      });

      const res = await tempTrpc.refreshAuthToken.mutate({
        refreshToken: this.refreshToken,
      });

      if (res && res.accessToken) {
        this.accessToken = res.accessToken;
        return 'success';
      }
    } catch (err) {
      console.error('Error refreshing access token:', err);
      if (err instanceof TRPCClientError && err.data?.code === 'UNAUTHORIZED') {
        return 'invalid';
      }
    }
    // Network/server failures do not invalidate the saved session.
    return 'unavailable';
  }

  private startBackgroundRefresh(intervalMs = 10 * 60 * 1000) {
    if (this.refreshInterval) clearInterval(this.refreshInterval);

    // Refresh access token every 10 minutes (expires in 15m)
    this.refreshInterval = setInterval(async () => {
      console.error('Refreshing access token in background...');
      const result = await this.refreshAccessToken();
      if (result === 'unavailable') {
        // Keep the cached access token; the backend enforces its expiry.
        this.startBackgroundRefresh(60 * 1000);
        return;
      }
      if (result === 'success' && intervalMs !== 10 * 60 * 1000) {
        this.startBackgroundRefresh();
      }
      if (result === 'invalid') {
        console.error(
          'Background token refresh failed. Restoring login flow...',
        );
        this.accessToken = null;
        this.refreshToken = null;
        if (this.refreshInterval) {
          clearInterval(this.refreshInterval);
          this.refreshInterval = null;
        }
        await this.deleteToken();
        await this.startLoginFlow();
      }
    }, intervalMs);
    this.refreshInterval.unref();
  }

  private async startLoginFlow() {
    if (this.isAuthInProgress) return;
    this.isAuthInProgress = true;

    // Resuming a timed-out poll should not open another login tab.
    const shouldOpenBrowser = !this.loginIdentifier;
    this.loginIdentifier ??= crypto.randomUUID();
    this.loginUrl = `${this.backendUrl}/dashboard/#/login?identifier=${this.loginIdentifier}&client=mcp`;

    console.error('\n======================================================');
    console.error('HYPERPROBE MCP SERVER AUTHENTICATION REQUIRED');
    console.error('Please log in using the following URL:');
    console.error(this.loginUrl);
    console.error('======================================================\n');

    if (shouldOpenBrowser) void this.openBrowser(this.loginUrl);
    void this.pollLogin();
  }

  private async openBrowser(url: string) {
    try {
      await open(url);
      console.error('Successfully opened login page in your browser.');
    } catch (err) {
      console.error(`Could not open browser automatically: ${err}`);
    }
  }

  private async pollLogin() {
    if (!this.loginIdentifier) return;

    const tempTrpc = createTRPCProxyClient<AppRouter>({
      transformer: superjson,
      links: [httpBatchLink({ url: `${this.backendUrl}/trpc` })],
    });

    const startTime = Date.now();
    const timeoutMs = 5 * 60 * 1000; // 5 minutes

    while (Date.now() - startTime < timeoutMs) {
      if (!this.loginIdentifier) break;
      try {
        const res = await tempTrpc.pollLogin.query({
          identifier: this.loginIdentifier,
        });
        if (
          res &&
          res.status === 'success' &&
          res.accessToken &&
          res.refreshToken
        ) {
          console.error('Successfully logged in!');
          await this.saveToken(res.refreshToken);
          this.accessToken = res.accessToken;
          this.isAuthInProgress = false;
          this.loginIdentifier = null;
          this.loginUrl = null;
          this.startBackgroundRefresh();
          return;
        }
      } catch (_err) {
        // Just suppress, maybe network issue
      }
      await new Promise((resolve) => setTimeout(resolve, 5000));
    }

    console.error(
      'Login polling timed out. Retry your request to resume the existing login.',
    );
    this.isAuthInProgress = false;
  }

  public getAccessToken(): string | null {
    return this.accessToken;
  }

  public getLoginUrl(): string | null {
    if (!this.accessToken && !this.isAuthInProgress && !this.refreshToken) {
      void this.startLoginFlow();
    }
    return this.loginUrl;
  }
}
