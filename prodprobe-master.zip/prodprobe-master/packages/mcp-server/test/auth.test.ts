import { TRPCClientError } from '@trpc/client';
import { afterEach, beforeEach, expect, test, vi } from 'vitest';
import { AuthManager } from '../src/auth.js';

const state = vi.hoisted(() => ({
  file: null as string | null,
  refresh: vi.fn(),
  poll: vi.fn(),
  open: vi.fn(),
}));
vi.mock('open', () => ({ default: state.open }));
vi.mock('node:fs', () => ({ existsSync: () => state.file !== null }));
vi.mock('node:fs/promises', () => ({
  default: {
    mkdir: vi.fn(),
    readFile: vi.fn(async () => state.file),
    writeFile: vi.fn(async (_path: string, contents: string) => {
      state.file = contents;
    }),
  },
}));
vi.mock('@trpc/client', async (importOriginal) => ({
  ...(await importOriginal<typeof import('@trpc/client')>()),
  createTRPCProxyClient: () => ({
    refreshAuthToken: { mutate: state.refresh },
    pollLogin: { query: state.poll },
  }),
}));

const BACKEND = 'https://customer.example';
const MINUTE = 60 * 1000;
const CACHED = JSON.stringify({
  sessions: {
    [BACKEND]: 'saved-refresh',
    'https://other.example': 'other-refresh',
  },
});

function rpcError(code: string) {
  return TRPCClientError.from({
    error: { code: -32001, message: code, data: { code } },
  });
}

beforeEach(() => {
  vi.useFakeTimers();
  vi.spyOn(console, 'error').mockImplementation(() => {});
  state.file = CACHED;
  state.refresh.mockReset().mockResolvedValue({ accessToken: 'access' });
  state.poll.mockReset().mockResolvedValue({ status: 'pending' });
  state.open.mockReset().mockResolvedValue(undefined);
});

afterEach(() => {
  vi.clearAllTimers();
  vi.useRealTimers();
  vi.restoreAllMocks();
});

test.each([
  ['startup', new Error('offline')],
  ['startup', rpcError('INTERNAL_SERVER_ERROR')],
  ['startup', rpcError('TOO_MANY_REQUESTS')],
  ['background', new Error('offline')],
  ['background', rpcError('INTERNAL_SERVER_ERROR')],
  ['background', rpcError('TOO_MANY_REQUESTS')],
])('%s refresh failure %s retries the saved session without opening a browser', async (stage, error) => {
  const auth = new AuthManager(BACKEND);
  if (stage === 'startup') state.refresh.mockRejectedValueOnce(error);
  await auth.init();
  if (stage === 'background') {
    state.refresh.mockRejectedValueOnce(error);
    await vi.advanceTimersByTimeAsync(10 * MINUTE);
  }
  expect(auth.getAccessToken()).toBe(stage === 'startup' ? null : 'access');
  for (let i = 0; i < 20; i++) expect(auth.getLoginUrl()).toBeNull();
  expect(state.file).toBe(CACHED);
  expect(state.open).not.toHaveBeenCalled();
  expect(state.poll).not.toHaveBeenCalled();

  const calls = state.refresh.mock.calls.length;
  state.refresh.mockResolvedValue({ accessToken: 'refreshed-access' });
  await vi.advanceTimersByTimeAsync(MINUTE);
  expect(auth.getAccessToken()).toBe('refreshed-access');
  expect(state.refresh).toHaveBeenLastCalledWith({
    refreshToken: 'saved-refresh',
  });
  expect(state.refresh).toHaveBeenCalledTimes(calls + 1);
  await vi.advanceTimersByTimeAsync(9 * MINUTE);
  expect(state.refresh).toHaveBeenCalledTimes(calls + 1);
  await vi.advanceTimersByTimeAsync(MINUTE);
  expect(state.refresh).toHaveBeenCalledTimes(calls + 2);
  expect(state.open).not.toHaveBeenCalled();
});

test.each([
  'startup',
  'background',
])('%s disconnection survives repeated failed refreshes and reconnects without a browser', async (stage) => {
  const offline = TRPCClientError.from(new TypeError('fetch failed'));
  if (stage === 'startup') state.refresh.mockRejectedValue(offline);
  const auth = new AuthManager(BACKEND);
  await auth.init();
  if (stage === 'background') {
    state.refresh.mockRejectedValue(offline);
    await vi.advanceTimersByTimeAsync(10 * MINUTE);
  }

  // Stay offline beyond the old five-minute login timeout, with tools retrying.
  for (let i = 0; i < 6; i++) {
    await vi.advanceTimersByTimeAsync(MINUTE);
    expect(auth.getAccessToken()).toBe(stage === 'startup' ? null : 'access');
    expect(auth.getLoginUrl()).toBeNull();
    expect(state.file).toBe(CACHED);
    expect(state.open).not.toHaveBeenCalled();
    expect(state.poll).not.toHaveBeenCalled();
  }
  expect(state.refresh.mock.calls.length).toBeGreaterThanOrEqual(7);

  // Reconnection allows the next scheduled refresh to use the original token.
  state.refresh.mockResolvedValue({ accessToken: 'reconnected-access' });
  await vi.advanceTimersByTimeAsync(MINUTE);
  expect(auth.getAccessToken()).toBe('reconnected-access');
  expect(state.refresh).toHaveBeenLastCalledWith({
    refreshToken: 'saved-refresh',
  });
  expect(state.file).toBe(CACHED);
  expect(state.open).not.toHaveBeenCalled();

  // A second disconnect/reconnect cycle must also stay silent.
  state.refresh.mockRejectedValue(offline);
  await vi.advanceTimersByTimeAsync(10 * MINUTE);
  expect(auth.getAccessToken()).toBe('reconnected-access');
  expect(auth.getLoginUrl()).toBeNull();
  state.refresh.mockResolvedValue({ accessToken: 'reconnected-again' });
  await vi.advanceTimersByTimeAsync(MINUTE);
  expect(auth.getAccessToken()).toBe('reconnected-again');
  expect(state.open).not.toHaveBeenCalled();
  expect(state.poll).not.toHaveBeenCalled();
});

test.each([
  'startup',
  'background',
  'retry',
])('%s UNAUTHORIZED still opens automatic login and removes only the rejected session', async (stage) => {
  const auth = new AuthManager(BACKEND);
  if (stage === 'startup')
    state.refresh.mockRejectedValueOnce(rpcError('UNAUTHORIZED'));
  await auth.init();
  if (stage === 'retry') {
    state.refresh.mockRejectedValueOnce(new Error('offline'));
    await vi.advanceTimersByTimeAsync(10 * MINUTE);
    expect(auth.getAccessToken()).toBe('access');
    expect(state.file).toBe(CACHED);
    expect(state.open).not.toHaveBeenCalled();
  }
  if (stage !== 'startup') {
    state.refresh.mockRejectedValueOnce(rpcError('UNAUTHORIZED'));
    await vi.advanceTimersByTimeAsync(stage === 'retry' ? MINUTE : 10 * MINUTE);
  }
  expect(auth.getAccessToken()).toBeNull();
  expect(JSON.parse(state.file!).sessions).toEqual({
    'https://other.example': 'other-refresh',
  });
  expect(auth.getLoginUrl()).toBeTruthy();
  expect(state.open).toHaveBeenCalledExactlyOnceWith(auth.getLoginUrl());
});

test('initial login opens automatically; requests after polling timeout reuse it and complete login', async () => {
  state.file = null;
  const auth = new AuthManager(BACKEND);
  await auth.init();
  const link = auth.getLoginUrl();
  expect(link).toContain('/dashboard/#/login?identifier=');
  expect(state.open).toHaveBeenCalledExactlyOnceWith(link);
  for (let i = 0; i < 20; i++) expect(auth.getLoginUrl()).toBe(link);
  expect(state.poll).toHaveBeenCalledTimes(1);
  await vi.advanceTimersByTimeAsync(5 * MINUTE);
  expect(vi.getTimerCount()).toBe(0);
  expect(auth.getLoginUrl()).toBe(link);
  expect(state.open).toHaveBeenCalledTimes(1);
  expect(
    new Set(state.poll.mock.calls.map(([input]) => input.identifier)).size,
  ).toBe(1);

  state.poll.mockResolvedValueOnce({
    status: 'success',
    accessToken: 'access',
    refreshToken: 'new-refresh',
  });
  await vi.advanceTimersByTimeAsync(5000);
  expect(auth.getAccessToken()).toBe('access');
  expect(auth.getLoginUrl()).toBeNull();
  expect(JSON.parse(state.file!).sessions[BACKEND]).toBe('new-refresh');
  await new AuthManager(BACKEND).init();
  expect(state.open).toHaveBeenCalledTimes(1);
});
