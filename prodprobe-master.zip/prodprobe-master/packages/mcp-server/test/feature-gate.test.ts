import { existsSync } from 'node:fs';
import fs from 'node:fs/promises';
import { afterEach, describe, expect, it, vi } from 'vitest';
import {
  MAX_WATCH_EXPRESSION_BYTES,
  MAX_WATCH_EXPRESSIONS,
} from '../src/config.js';
import type { McpRuntime } from '../src/index.js';

vi.mock('node:fs', async (importOriginal) => ({
  ...(await importOriginal<typeof import('node:fs')>()),
  existsSync: vi.fn(),
}));

vi.mock('node:fs/promises', async (importOriginal) => {
  const actual = await importOriginal<typeof import('node:fs/promises')>();
  return { ...actual, default: { ...actual.default, readFile: vi.fn() } };
});

const flagName = 'HYPERPROBE_AGENTIC_ENABLED';
const conditionalFlagName = 'HYPERPROBE_ALLOW_CONDITIONAL_PROBE';
const watchFlagName = 'HYPERPROBE_ALLOW_WATCH_EXPR';
const flagCombinations = [
  ['false', 'false', 'false'],
  ['false', 'false', 'true'],
  ['false', 'true', 'false'],
  ['false', 'true', 'true'],
  ['true', 'false', 'false'],
  ['true', 'false', 'true'],
  ['true', 'true', 'false'],
  ['true', 'true', 'true'],
] as const;
const agenticApmToolNames = [
  'rca_discover_observability_context',
  'rca_get_observability_capabilities',
  'rca_query_errors',
  'rca_query_logs',
  'rca_query_traces',
  'rca_query_metrics',
  'rca_query_alerts',
];

const baselineToolNames = [
  'list_services',
  'list_active_agents',
  'create_probe',
  'wait_for_probe_ready',
  'wait_for_snapshot',
  'list_snapshots',
  'list_probes',
  'get_debugging_playbook',
];

async function loadMcpModule(
  value: string | undefined,
  conditionalValue: string | undefined = undefined,
  watchValue: string | undefined = undefined,
) {
  vi.stubEnv(flagName, value);
  vi.stubEnv(conditionalFlagName, conditionalValue);
  vi.stubEnv(watchFlagName, watchValue);
  vi.resetModules();
  return import('../src/index.js');
}

function createRuntime(trpc: any = {}): McpRuntime {
  return {
    authManager: {
      getAccessToken: () => 'access-token',
      getLoginUrl: () => null,
    },
    trpc,
  };
}

function createRcaClient() {
  return {
    discoverObservabilityContext: { query: vi.fn().mockResolvedValue({}) },
    getCapabilities: { query: vi.fn().mockResolvedValue({}) },
    queryErrors: { mutate: vi.fn().mockResolvedValue({}) },
    queryLogs: { mutate: vi.fn().mockResolvedValue({}) },
    queryTraces: { mutate: vi.fn().mockResolvedValue({}) },
    queryMetrics: { mutate: vi.fn().mockResolvedValue({}) },
    queryAlerts: { mutate: vi.fn().mockResolvedValue({}) },
  };
}

const probeArgs = {
  serviceId: 'service-id',
  environment: 'production',
  commitSha: 'a'.repeat(40),
  uiFilePath: '/virtual/repo/services/api/src/handler.ts',
  uiLineNumber: 12,
  hitLimit: 1,
};

function createProbeClient() {
  // The service config is below the Git root, as in a monorepo.
  vi.mocked(existsSync).mockImplementation((file) =>
    [
      probeArgs.uiFilePath,
      '/virtual/repo/services/api/.hprc',
      '/virtual/repo/.git',
    ].includes(String(file)),
  );
  vi.mocked(fs.readFile).mockResolvedValue(
    JSON.stringify({ serviceId: probeArgs.serviceId }),
  );
  return {
    listActiveAgents: {
      query: vi.fn().mockResolvedValue([
        {
          environment: probeArgs.environment,
          commitSha: probeArgs.commitSha,
        },
      ]),
    },
    createProbe: { mutate: vi.fn().mockResolvedValue({ id: 'probe-id' }) },
  };
}

afterEach(() => {
  vi.useRealTimers();
  vi.unstubAllEnvs();
  vi.restoreAllMocks();
  vi.resetAllMocks();
  vi.resetModules();
});

describe('MCP startup flags', () => {
  it.each([
    ['missing', undefined, false],
    ['empty', '', false],
    ['false', 'false', false],
    ['uppercase', 'TRUE', false],
    ['numeric', '1', false],
    ['other value', 'yes', false],
    ['leading whitespace', ' true', false],
    ['trailing whitespace', 'true ', false],
    ['literal true', 'true', true],
  ])('parses all flags exactly: %s (%j)', async (_description, value, expected) => {
    const trpc = createProbeClient();
    const module = await loadMcpModule(value, value, value);
    const handlers = module.createMcpHandlers(createRuntime(trpc));
    const { tools } = await handlers.listTools();
    const probe = tools.find((tool) => tool.name === 'create_probe')!;

    expect(module.AGENTIC_ENABLED).toBe(expected);
    expect(tools).toHaveLength(expected ? 15 : 8);
    expect('condition' in probe.inputSchema.properties).toBe(expected);
    expect('watchExpressions' in probe.inputSchema.properties).toBe(expected);

    const guide = await handlers.callTool({
      params: { name: 'get_debugging_playbook', arguments: {} },
    });
    expect(
      guide.content[0].text.includes('## Agentic APM and alert workflow'),
    ).toBe(expected);
    expect(
      guide.content[0].text.includes('Conditional probing is NOT AVAILABLE'),
    ).toBe(!expected);
    expect(
      guide.content[0].text.includes('Watch expressions are NOT AVAILABLE'),
    ).toBe(!expected);

    const watchExpressions = ['items.length'];
    const result = await handlers.callTool({
      params: {
        name: 'create_probe',
        arguments: { ...probeArgs, watchExpressions },
      },
    });
    expect(result.isError).not.toBe(true);
    expect(trpc.createProbe.mutate).toHaveBeenCalledOnce();
    const payload = trpc.createProbe.mutate.mock.calls[0][0];
    expect(Object.hasOwn(payload, 'watchExpressions')).toBe(expected);
    if (expected) expect(payload.watchExpressions).toEqual(watchExpressions);
  });

  it.each(
    flagCombinations,
  )('keeps flags fixed after startup: agentic=%s, conditional=%s, watch=%s', async (agentic, conditional, watch) => {
    const trpc = createProbeClient();
    const module = await loadMcpModule(agentic, conditional, watch);
    const handlers = module.createMcpHandlers(createRuntime(trpc));
    const initialTools = await handlers.listTools();
    const guideRequest = {
      params: { name: 'get_debugging_playbook', arguments: {} },
    };
    const initialGuide = await handlers.callTool(guideRequest);
    process.env[flagName] = agentic === 'true' ? 'false' : 'true';
    process.env[conditionalFlagName] =
      conditional === 'true' ? 'false' : 'true';
    process.env[watchFlagName] = watch === 'true' ? 'false' : 'true';

    expect(module.AGENTIC_ENABLED).toBe(agentic === 'true');
    for (const fixedHandlers of [
      handlers,
      module.createMcpHandlers(createRuntime(trpc)),
    ]) {
      expect(await fixedHandlers.listTools()).toEqual(initialTools);
      expect(await fixedHandlers.callTool(guideRequest)).toEqual(initialGuide);
      trpc.createProbe.mutate.mockClear();
      const watchExpressions = ['items.length'];
      const result = await fixedHandlers.callTool({
        params: {
          name: 'create_probe',
          arguments: { ...probeArgs, watchExpressions },
        },
      });
      expect(result.isError).not.toBe(true);
      expect(trpc.createProbe.mutate).toHaveBeenCalledOnce();
      const payload = trpc.createProbe.mutate.mock.calls[0][0];
      expect(Object.hasOwn(payload, 'watchExpressions')).toBe(watch === 'true');
      if (watch === 'true') {
        expect(payload.watchExpressions).toEqual(watchExpressions);
      }

      trpc.createProbe.mutate.mockClear();
      const conditionalResult = await fixedHandlers.callTool({
        params: {
          name: 'create_probe',
          arguments: {
            ...probeArgs,
            condition: 'items.length > 0',
            watchExpressions,
          },
        },
      });
      if (conditional === 'true') {
        expect(conditionalResult.isError).not.toBe(true);
        expect(trpc.createProbe.mutate).toHaveBeenCalledOnce();
      } else {
        expect(conditionalResult.isError).toBe(true);
        expect(conditionalResult.content[0].text).toContain(
          'Conditional probing is not available',
        );
        expect(trpc.createProbe.mutate).not.toHaveBeenCalled();
      }
    }
  });
});

describe('agentic MCP tool gate', () => {
  it.each(
    flagCombinations,
  )('advertises independent gates: agentic=%s, conditional=%s, watch=%s', async (agentic, conditional, watch) => {
    const { AGENTIC_APM_TOOL_NAMES, createMcpHandlers } = await loadMcpModule(
      agentic,
      conditional,
      watch,
    );
    const { listTools } = createMcpHandlers(createRuntime());
    const { tools } = await listTools();
    const probe = tools.find((tool) => tool.name === 'create_probe')!;

    expect(AGENTIC_APM_TOOL_NAMES).toEqual(agenticApmToolNames);
    expect(tools).toHaveLength(agentic === 'true' ? 15 : 8);
    expect(tools.map((tool) => tool.name)).toEqual(
      agentic === 'true'
        ? [
            ...baselineToolNames.slice(0, -1),
            ...agenticApmToolNames,
            'get_debugging_playbook',
          ]
        : baselineToolNames,
    );
    expect(probe.inputSchema.properties).toHaveProperty(
      'shouldCaptureTraceId.type',
      'boolean',
    );
    if (conditional === 'true') {
      expect(probe.inputSchema.properties).toHaveProperty(
        'condition.type',
        'string',
      );
      expect(probe.description).toMatch(/\bcondition\b/);
    } else {
      expect(probe.inputSchema.properties).not.toHaveProperty('condition');
      expect(probe.description).toMatch(
        /conditional probing.*(?:not available|unavailable|disabled)/i,
      );
      expect(probe.description).not.toMatch(/supports? conditional/i);
    }
    if (watch === 'true') {
      expect(probe.inputSchema.properties.watchExpressions).toEqual({
        type: 'array',
        items: { type: 'string' },
        maxItems: MAX_WATCH_EXPRESSIONS,
        description: expect.stringContaining(
          `${MAX_WATCH_EXPRESSION_BYTES} UTF-8 bytes`,
        ),
      });
      expect(
        probe.inputSchema.properties.watchExpressions?.description,
      ).toContain(`${MAX_WATCH_EXPRESSIONS} expressions per probe`);
      expect(probe.inputSchema.required).not.toContain('watchExpressions');
      expect(probe.description).toContain('watchExpressions');
      expect(probe.description).toContain(
        `${MAX_WATCH_EXPRESSIONS} expressions`,
      );
      expect(probe.description).toContain(
        `${MAX_WATCH_EXPRESSION_BYTES} UTF-8 bytes`,
      );
    } else {
      expect(probe.inputSchema.properties).not.toHaveProperty(
        'watchExpressions',
      );
      expect(probe.description).not.toContain('watchExpressions');
    }
  });

  it.each([
    'false',
    'true',
  ])('rejects direct APM calls when disabled, regardless of conditional=%s and watches enabled', async (conditional) => {
    const rca = createRcaClient();
    const { createMcpHandlers } = await loadMcpModule(
      'false',
      conditional,
      'true',
    );
    const { callTool } = createMcpHandlers(createRuntime({ rca }));

    for (const name of agenticApmToolNames) {
      const result = await callTool({ params: { name, arguments: {} } });
      expect(result.isError).toBe(true);
      expect(result.content[0].text).toContain('disabled');
    }

    for (const procedure of Object.values(rca)) {
      expect(procedure.query ?? procedure.mutate).not.toHaveBeenCalled();
    }
  });

  it.each([
    [
      'rca_discover_observability_context',
      { serviceId: 'service-id' },
      'discoverObservabilityContext',
      'query',
    ],
    [
      'rca_get_observability_capabilities',
      { serviceId: 'service-id', environment: 'production' },
      'getCapabilities',
      'query',
    ],
    [
      'rca_query_errors',
      {
        serviceId: 'service-id',
        environment: 'production',
        start: '2026-01-01T00:00:00.000Z',
        end: '2026-01-01T01:00:00.000Z',
        purpose: 'test routing',
      },
      'queryErrors',
      'mutate',
    ],
    [
      'rca_query_logs',
      {
        serviceId: 'service-id',
        environment: 'production',
        start: '2026-01-01T00:00:00.000Z',
        end: '2026-01-01T01:00:00.000Z',
        purpose: 'test routing',
      },
      'queryLogs',
      'mutate',
    ],
    [
      'rca_query_traces',
      {
        serviceId: 'service-id',
        environment: 'production',
        start: '2026-01-01T00:00:00.000Z',
        end: '2026-01-01T01:00:00.000Z',
        purpose: 'test routing',
      },
      'queryTraces',
      'mutate',
    ],
    [
      'rca_query_metrics',
      {
        serviceId: 'service-id',
        environment: 'production',
        start: '2026-01-01T00:00:00.000Z',
        end: '2026-01-01T01:00:00.000Z',
        purpose: 'test routing',
      },
      'queryMetrics',
      'mutate',
    ],
    [
      'rca_query_alerts',
      {
        serviceId: 'service-id',
        environment: 'production',
        start: '2026-01-01T00:00:00.000Z',
        end: '2026-01-01T01:00:00.000Z',
        purpose: 'test routing',
      },
      'queryAlerts',
      'mutate',
    ],
  ])('routes %s to its tRPC procedure when enabled', async (name, args, procedure, method) => {
    const rca = createRcaClient();
    const { createMcpHandlers } = await loadMcpModule('true');
    const { callTool } = createMcpHandlers(createRuntime({ rca }));

    const result = await callTool({ params: { name, arguments: args } });

    expect(result.isError).not.toBe(true);
    expect(rca[procedure][method]).toHaveBeenCalledOnce();
  });

  it('clamps table query limit to 25 and metric intervalSeconds to [60, 3600]', async () => {
    const rca = createRcaClient();
    const { createMcpHandlers } = await loadMcpModule('true');
    const { callTool } = createMcpHandlers(createRuntime({ rca }));

    await callTool({
      params: {
        name: 'rca_query_errors',
        arguments: {
          serviceId: 'service-id',
          environment: 'production',
          start: '2026-01-01T00:00:00.000Z',
          end: '2026-01-01T01:00:00.000Z',
          purpose: 'test limit clamp',
          limit: 100,
        },
      },
    });
    expect(rca.queryErrors.mutate).toHaveBeenCalledWith(
      expect.objectContaining({ limit: 25 }),
    );

    await callTool({
      params: {
        name: 'rca_query_logs',
        arguments: {
          serviceId: 'service-id',
          environment: 'production',
          start: '2026-01-01T00:00:00.000Z',
          end: '2026-01-01T01:00:00.000Z',
          purpose: 'test float limit',
          limit: 15.9,
        },
      },
    });
    expect(rca.queryLogs.mutate).toHaveBeenCalledWith(
      expect.objectContaining({ limit: 15 }),
    );

    await callTool({
      params: {
        name: 'rca_query_metrics',
        arguments: {
          serviceId: 'service-id',
          environment: 'production',
          start: '2026-01-01T00:00:00.000Z',
          end: '2026-01-01T01:00:00.000Z',
          purpose: 'test metric interval clamp',
          intervalSeconds: 10000,
        },
      },
    });
    expect(rca.queryMetrics.mutate).toHaveBeenCalledWith(
      expect.objectContaining({ intervalSeconds: 3600 }),
    );

    await callTool({
      params: {
        name: 'rca_query_metrics',
        arguments: {
          serviceId: 'service-id',
          environment: 'production',
          start: '2026-01-01T00:00:00.000Z',
          end: '2026-01-01T01:00:00.000Z',
          purpose: 'test metric interval min clamp',
          intervalSeconds: 10,
        },
      },
    });
    expect(rca.queryMetrics.mutate).toHaveBeenCalledWith(
      expect.objectContaining({ intervalSeconds: 60 }),
    );
  });

  it.each([
    ['rca_query_logs', 'queryLogs'],
    ['rca_query_traces', 'queryTraces'],
  ] as const)('forwards sanitized scalar evidence and redaction counts through %s', async (name, procedure) => {
    const rca = createRcaClient();
    const response = {
      rows: [
        {
          id: 'event-1',
          message: '[REDACTED]',
          errorType: 'TypeError, HttpError',
          traceId: 'a'.repeat(32),
        },
      ],
      sources: [
        {
          connectionId: 'sentry-main',
          provider: 'SENTRY',
          resultCount: 1,
          redactionCount: 1,
        },
      ],
      delivery: { providerRowCount: 1, returnedRowCount: 1 },
      warnings: [],
    };
    rca[procedure].mutate.mockResolvedValue(response);
    const { createMcpHandlers } = await loadMcpModule('true');
    const result = await createMcpHandlers(createRuntime({ rca })).callTool({
      params: {
        name,
        arguments: {
          serviceId: 'service-id',
          environment: 'production',
          purpose: 'Investigate failures',
          start: '2026-01-01T00:00:00.000Z',
          end: '2026-01-01T01:00:00.000Z',
        },
      },
    });
    expect(result.isError).not.toBe(true);
    expect(JSON.parse(result.content[0].text)).toEqual(response);
    expect(rca[procedure].mutate).toHaveBeenCalledOnce();
  });

  it('preserves structured rate-limit retry information', async () => {
    const rca = createRcaClient();
    const retryAt = '2026-01-01T01:05:00.000Z';
    rca.queryLogs.mutate.mockRejectedValue(
      Object.assign(new Error('Provider rate limit'), { data: { retryAt } }),
    );
    const { createMcpHandlers } = await loadMcpModule('true');
    const { callTool } = createMcpHandlers(createRuntime({ rca }));
    const result = await callTool({
      params: {
        name: 'rca_query_logs',
        arguments: {
          serviceId: 'service-id',
          environment: 'production',
          start: '2026-01-01T00:00:00.000Z',
          end: '2026-01-01T01:00:00.000Z',
          purpose: 'test retry metadata',
        },
      },
    });

    expect(result.isError).toBe(true);
    expect(JSON.parse(result.content[0].text)).toEqual({
      error: 'RATE_LIMITED',
      message: 'Provider rate limit',
      retryAt,
    });
    expect(rca.queryLogs.mutate).toHaveBeenCalledOnce();
  });

  it('returns a full discovery 429 as an error with retryAt without retrying', async () => {
    const rca = createRcaClient();
    const retryAt = '2026-09-16T12:00:30.000Z';
    rca.discoverObservabilityContext.query.mockRejectedValue(
      Object.assign(new Error('Provider discovery rate limit'), {
        data: { code: 'TOO_MANY_REQUESTS', httpStatus: 429, retryAt },
      }),
    );
    const { createMcpHandlers } = await loadMcpModule('true');
    vi.useFakeTimers();
    const result = await createMcpHandlers(createRuntime({ rca })).callTool({
      params: {
        name: 'rca_discover_observability_context',
        arguments: { serviceId: 'service-id' },
      },
    });

    expect(result.isError).toBe(true);
    expect(JSON.parse(result.content[0].text)).toEqual({
      error: 'RATE_LIMITED',
      message: 'Provider discovery rate limit',
      retryAt,
    });
    expect(vi.getTimerCount()).toBe(0);
    await vi.advanceTimersByTimeAsync(60_000);
    expect(
      rca.discoverObservabilityContext.query,
    ).toHaveBeenCalledExactlyOnceWith({ serviceId: 'service-id' });
  });

  it.each([
    false,
    true,
  ])('forwards discovery values and partial 429 failures, including complementary sections = %s', async (allAvailable) => {
    const rca = createRcaClient();
    const failure = {
      connectionId: 'sentry-main',
      connectionName: 'Sentry main',
      provider: 'SENTRY',
      section: 'alerts',
      code: 'RATE_LIMITED',
      reason: 'Alert discovery rate limit',
    };
    const response = {
      provider: allAvailable ? 'MULTIPLE' : 'SENTRY',
      alerts: allAvailable
        ? { availability: 'AVAILABLE', values: [] }
        : {
            availability: 'UNAVAILABLE',
            code: failure.code,
            reason: failure.reason,
          },
      environments: { availability: 'AVAILABLE', values: ['production'] },
      releases: {
        availability: 'AVAILABLE',
        values: [{ version: 'checkout@1.2.3' }],
      },
      tags: { availability: 'AVAILABLE', values: [{ key: 'region' }] },
      sources: [
        { connectionId: failure.connectionId, provider: failure.provider },
        ...(allAvailable
          ? [{ connectionId: 'sentry-alerts', provider: 'SENTRY' }]
          : []),
      ],
      failures: [{ ...failure, retryAt: '2026-09-16T12:00:30.000Z' }],
      warnings: [
        'Sentry main (SENTRY) alerts discovery failed: Alert discovery rate limit',
      ],
    };
    rca.discoverObservabilityContext.query.mockResolvedValue(response);
    const { createMcpHandlers } = await loadMcpModule('true');
    vi.useFakeTimers();
    const result = await createMcpHandlers(createRuntime({ rca })).callTool({
      params: {
        name: 'rca_discover_observability_context',
        arguments: { serviceId: 'service-id' },
      },
    });

    expect(result.isError).not.toBe(true);
    expect(JSON.parse(result.content[0].text)).toEqual(response);
    expect(vi.getTimerCount()).toBe(0);
    await vi.advanceTimersByTimeAsync(60_000);
    expect(
      rca.discoverObservabilityContext.query,
    ).toHaveBeenCalledExactlyOnceWith({ serviceId: 'service-id' });
  });

  it('forwards metric intervals, complete points, and incomplete-point warnings/counts', async () => {
    const rca = createRcaClient();
    const response = {
      metric: 'THROUGHPUT',
      requestedIntervalSeconds: 90,
      intervalSeconds: 300,
      points: [{ timestamp: '2026-09-16T12:00:00.000Z', value: 42 }],
      delivery: {
        providerPointCount: 2,
        returnedPointCount: 1,
        omittedIncompletePointCount: 1,
        downsampled: false,
      },
      sources: [
        {
          connectionId: 'sentry-main',
          points: [{ timestamp: '2026-09-16T12:00:00.000Z', value: 42 }],
          resultCount: 1,
          providerPointCount: 2,
          omittedIncompletePointCount: 1,
        },
      ],
      warnings: [
        'Metric interval automatically increased from 90 seconds to 300 seconds.',
        'Omitted 1 metric point marked incomplete by the provider; missing buckets are not zero.',
      ],
    };
    rca.queryMetrics.mutate.mockResolvedValue(response);
    const { createMcpHandlers } = await loadMcpModule('true');
    const result = await createMcpHandlers(createRuntime({ rca })).callTool({
      params: {
        name: 'rca_query_metrics',
        arguments: {
          serviceId: 'service-id',
          environment: 'production',
          start: '2026-09-16T12:00:00.000Z',
          end: '2026-09-16T13:00:00.000Z',
          metric: 'THROUGHPUT',
          intervalSeconds: 90,
          purpose: 'Check incident throughput',
        },
      },
    });

    expect(result.isError).not.toBe(true);
    expect(JSON.parse(result.content[0].text)).toEqual(response);
    expect(rca.queryMetrics.mutate).toHaveBeenCalledExactlyOnceWith({
      serviceId: 'service-id',
      environment: 'production',
      timeRange: {
        start: '2026-09-16T12:00:00.000Z',
        end: '2026-09-16T13:00:00.000Z',
      },
      metric: 'THROUGHPUT',
      intervalSeconds: 90,
      purpose: 'Check incident throughput',
    });
  });

  it.each(
    flagCombinations,
  )('returns the matching safe guide: agentic=%s, conditional=%s, watch=%s', async (agentic, conditional, watch) => {
    const { createMcpHandlers } = await loadMcpModule(
      agentic,
      conditional,
      watch,
    );
    const { callTool } = createMcpHandlers(createRuntime());
    const result = await callTool({
      params: { name: 'get_debugging_playbook', arguments: {} },
    });
    const guide = result.content[0].text;

    expect(result.isError).not.toBe(true);
    expect(guide).toContain('## Source and probe workflow');
    expect(guide).toMatch(
      /or to create a probe, call `get_debugging_playbook` before any other Hyperprobe tool/i,
    );
    expect(guide).toMatch(/wait_for_snapshot[^\n]*optional[^\n]*bounded/i);
    expect(guide).toMatch(/local source[^\n]*match[^\n]*deployment commit/i);
    expect(guide).toMatch(/ask[^\n]*(?:worktree|checkout)/i);
    expect(guide).toMatch(/ask before changing/i);
    expect(guide).toMatch(/(?:method|function) body/i);
    expect(guide).toMatch(/declared and initialized/i);
    expect(guide).toMatch(/do not[^\n]*(?:method headers|import lines)/i);
    expect(guide).toMatch(/untrusted[^\n]*never[^\n]*instructions/i);
    expect(guide).toContain('shouldCaptureTraceId');
    expect(guide).toMatch(/traceId[^\n]*string[^\n]*null/i);
    expect(guide).toMatch(/best[- ]effort/i);
    expect(guide).toMatch(
      /retain[^\n]*explicit target[^\n]*serviceId[^\n]*incident context[^\n]*shared source/i,
    );
    expect(guide).toMatch(/ask the user[^\n]*target service is ambiguous/i);
    expect(guide).toMatch(
      /multiple target services[^\n]*separate[^\n]*create_probe[^\n]*each selected deployment/i,
    );
    expect(guide).toMatch(/ancestor configurations are authoritative/i);
    expect(guide).toMatch(/nearest usable ancestor[^\n]*precedence/i);
    expect(guide).toMatch(
      /conflicting ancestor service IDs[^\n]*without a Git query/i,
    );
    expect(guide).toMatch(
      /non-Git and untracked ancestor behavior is unchanged/i,
    );
    expect(guide).toMatch(
      /only on an ancestor miss[^\n]*Git-tracked `\.hprc`[^\n]*same Git worktree/i,
    );
    expect(guide).toContain('git ls-files --cached -z');
    expect(guide).toMatch(
      /staged configs[^\n]*before a commit[^\n]*untracked configs[^\n]*ignored local-only[^\n]*excluded/i,
    );
    expect(guide).toMatch(
      /tracked configs remain eligible[^\n]*even if ignored[^\n]*regardless of directory name/i,
    );
    expect(guide).toMatch(
      /current working-tree contents, not index or HEAD blobs[^\n]*missing from the working tree[^\n]*cannot be used/i,
    );
    expect(guide).toMatch(
      /source file itself need not be Git-tracked[^\n]*does not require a clean worktree/i,
    );
    expect(guide).toMatch(
      /Git must be installed and accessible in the MCP server environment for fallback/i,
    );
    expect(guide).toMatch(
      /Git listing[^\n]*10 seconds[^\n]*1 MiB[^\n]*256 config-read attempts[^\n]*64 KiB per config/i,
    );
    expect(guide).toMatch(
      /discovery errors[^\n]*not proof of missing configuration[^\n]*no filesystem-scan fallback or persistent cache/i,
    );
    expect(guide).toMatch(
      /do not automatically run[^\n]*git add[^\n]*git commit[^\n]*Git trust settings/i,
    );
    expect(guide).toMatch(
      /do not create[^\n]*repository-root[^\n]*libs\/[^\n]*bypass/i,
    );
    expect(guide).toMatch(
      /runtime-neutral[^\n]*not gated on JS source-map flags/i,
    );
    expect(guide).toMatch(
      /uiFilePath[^\n]*absolute local[^\n]*MCP[^\n]*repository-relative/i,
    );
    expect(guide).toMatch(
      /membership does not prove[^\n]*included[^\n]*build/i,
    );
    expect(guide).toMatch(
      /compiled TypeScript[^\n]*correct source maps[^\n]*selected deployment/i,
    );
    expect(guide).toMatch(
      /target file matches the deployment[^\n]*staged and unstaged/i,
    );
    expect(guide).toMatch(
      /unrelated dirty files are not a reason to reject[^\n]*do not invent a hard Git/i,
    );
    if (agentic === 'true') {
      expect(guide).toContain('## Agentic APM and alert workflow');
      expect(guide).toContain('rca_query_alerts');
    } else {
      expect(guide).not.toContain('## Agentic APM and alert workflow');
      expect(guide).not.toContain('rca_');
      expect(guide).not.toContain('provider observability');
    }
    const conditionalGuide = guide
      .split('## Conditional probing')[1]
      .split('\n## ')[0];
    if (conditional === 'true') {
      expect(conditionalGuide).toMatch(/(?:TypeScript|JS\/TS)[\s\S]*===/);
      expect(conditionalGuide).toMatch(/JVM[\s\S]*(?:>=|\.equals\()/);
      expect(conditionalGuide).toMatch(/Python[\s\S]*(?:==|\blen\()/);
    } else {
      expect(conditionalGuide).toMatch(
        /conditional probing[^\n]*(?:not available|unavailable|disabled)/i,
      );
      expect(conditionalGuide).toMatch(
        /(?:omit|do not (?:provide|supply|include))[^\n]*condition/i,
      );
      expect(conditionalGuide).toMatch(
        /(?:do not|never) retry[^\n]*condition/i,
      );
      expect(conditionalGuide).not.toMatch(
        /\bcondition[`'"]?\s*:|===?|>=|\.equals\(|\blen\(/,
      );
    }
    const watchGuide = guide.split('## Watch expressions')[1].split('\n## ')[0];
    expect(watchGuide).toMatch(
      /startup[^\n]*new[^\n]*requests only[^\n]*not existing probes or results/i,
    );
    expect(watchGuide).toMatch(
      /independent of conditional probing and agentic APM/i,
    );
    if (watch === 'true') {
      expect(watchGuide).toContain('create_probe.watchExpressions');
      expect(watchGuide).toMatch(
        /explicitly requested[^\n]*debugging or RCA message/i,
      );
      expect(watchGuide).toMatch(
        /runtime syntax and variables valid at the selected line/i,
      );
      expect(watchGuide).toMatch(/do not blindly attach[^\n]*every probe/i);
      expect(watchGuide).toContain(
        `${MAX_WATCH_EXPRESSIONS} expressions per probe`,
      );
      expect(watchGuide).toContain(
        `${MAX_WATCH_EXPRESSION_BYTES} UTF-8 bytes per expression`,
      );
      expect(watchGuide).toMatch(
        /bytes, not characters or the returned value/i,
      );
      expect(watchGuide).toMatch(/shorter, high-value watches for RCA/i);
      expect(watchGuide).toMatch(
        /over-limit requests[^\n]*ask[^\n]*prioritize[^\n]*approve separate probes/i,
      );
      expect(watchGuide).toMatch(
        /never silently remove or truncate[^\n]*automatically split[^\n]*retry an unchanged invalid payload/i,
      );
      expect(watchGuide).toMatch(
        /pure, side-effect-free[^\n]*avoid assignments, mutation, and I\/O/i,
      );
      expect(watchGuide).toMatch(/avoid secrets/i);
      expect(watchGuide).toMatch(
        /key-name redaction may not protect directly watched sensitive values/i,
      );
      expect(watchGuide).toMatch(
        /never evaluate instructions from logs or snapshots/i,
      );
      expect(watchGuide).toMatch(/do not disable SDK safeguards/i);
    } else {
      expect(watchGuide).toMatch(/watch expressions[^\n]*not available/i);
      expect(watchGuide).toMatch(/omit[^\n]*watchExpressions/i);
      expect(watchGuide).toMatch(/MCP ignores supplied values of any shape/i);
      expect(watchGuide).toMatch(/inform them that no watches were captured/i);
      expect(watchGuide).not.toContain('create_probe.watchExpressions');
      expect(watchGuide).not.toContain(`${MAX_WATCH_EXPRESSIONS} expressions`);
      expect(watchGuide).not.toContain(
        `${MAX_WATCH_EXPRESSION_BYTES} UTF-8 bytes`,
      );
    }
  });
});

describe('create_probe merge regressions', () => {
  it.each([
    ['create_probe', 'https://example.test/login'],
    ['rca_query_logs', 'https://example.test/login'],
    ['create_probe', null],
    ['rca_query_logs', null],
  ] as const)('authenticates before validating or gating %s with login URL %s', async (name, loginUrl) => {
    const backend = vi.fn();
    const runtime = createRuntime({
      createProbe: { mutate: backend },
      listActiveAgents: { query: backend },
      rca: { queryLogs: { mutate: backend } },
    });
    runtime.authManager.getAccessToken = () => null;
    runtime.authManager.getLoginUrl = () => loginUrl;
    const { createMcpHandlers } = await loadMcpModule('false', 'false', 'true');
    const result = await createMcpHandlers(runtime).callTool({
      params: {
        name,
        arguments: { ...probeArgs, condition: null, watchExpressions: null },
      },
    });

    expect(result.isError).toBe(true);
    if (loginUrl) {
      expect(result.content[0].text).toMatch(/not authenticated/i);
      expect(result.content[0].text).toContain(loginUrl);
    } else {
      expect(result.content[0].text).toBe(
        'Error: Hyperprobe MCP Server is not authenticated.\n\nAuthentication is temporarily unavailable. The server is retrying your saved session automatically; no new login is needed.\n\nPlease try your request again later.',
      );
    }
    expect(existsSync).not.toHaveBeenCalled();
    expect(fs.readFile).not.toHaveBeenCalled();
    expect(backend).not.toHaveBeenCalled();
  });

  it.each([
    '  cart.total > 500  ',
    'false',
  ])('rejects disabled condition %j before filesystem or backend access', async (condition) => {
    const trpc = createProbeClient();
    const { createMcpHandlers } = await loadMcpModule('true', 'false', 'true');
    const result = await createMcpHandlers(createRuntime(trpc)).callTool({
      params: {
        name: 'create_probe',
        arguments: {
          ...probeArgs,
          condition,
          watchExpressions: ['items.length'],
        },
      },
    });

    expect(result.isError).toBe(true);
    expect(result.content[0].text).toMatch(
      /conditional probing.*(?:not available|unavailable|disabled)/i,
    );
    expect(existsSync).not.toHaveBeenCalled();
    expect(fs.readFile).not.toHaveBeenCalled();
    expect(trpc.listActiveAgents.query).not.toHaveBeenCalled();
    expect(trpc.createProbe.mutate).not.toHaveBeenCalled();
  });

  it.each([
    'false',
    'true',
  ])('rejects malformed conditions before I/O with conditional=%s', async (conditional) => {
    const trpc = createProbeClient();
    const { createMcpHandlers } = await loadMcpModule(
      'false',
      conditional,
      'true',
    );
    const { callTool } = createMcpHandlers(createRuntime(trpc));
    for (const condition of [null, false, 42, {}]) {
      const result = await callTool({
        params: {
          name: 'create_probe',
          arguments: { ...probeArgs, condition, watchExpressions: null },
        },
      });
      expect(result.isError).toBe(true);
      expect(result.content[0].text).toMatch(/condition.*string/i);
    }
    expect(existsSync).not.toHaveBeenCalled();
    expect(fs.readFile).not.toHaveBeenCalled();
    expect(trpc.listActiveAgents.query).not.toHaveBeenCalled();
    expect(trpc.createProbe.mutate).not.toHaveBeenCalled();
  });

  it.each([
    [true, 'false', true, false],
    ['true', false, true, false],
    [false, 'true', false, true],
    ['false', true, false, true],
    [undefined, undefined, false, false],
    ['TRUE', ' true ', false, false],
    [1, {}, false, false],
    [null, null, false, false],
  ])('normalizes trace=%j and closures=%j after raw arguments', async (shouldCaptureTraceId, captureClosures, expectedTrace, expectedClosures) => {
    const trpc = createProbeClient();
    const { createMcpHandlers } = await loadMcpModule('false', 'true');
    const now = Date.parse('2026-01-01T00:00:00.000Z');
    vi.spyOn(Date, 'now').mockReturnValue(now);
    const result = await createMcpHandlers(createRuntime(trpc)).callTool({
      params: {
        name: 'create_probe',
        arguments: {
          ...probeArgs,
          condition: '  cart.total > 500 \n',
          shouldCaptureTraceId,
          captureClosures,
          expiryTime: String(now - 1),
          type: 'LOG',
        },
      },
    });

    expect(result.isError).not.toBe(true);
    expect(JSON.parse(result.content[0].text)).toEqual({ id: 'probe-id' });
    expect(fs.readFile).toHaveBeenCalledWith(
      '/virtual/repo/services/api/.hprc',
      'utf-8',
    );
    expect(trpc.listActiveAgents.query).toHaveBeenCalledExactlyOnceWith({
      serviceIds: [probeArgs.serviceId],
    });
    expect(trpc.createProbe.mutate).toHaveBeenCalledExactlyOnceWith({
      ...probeArgs,
      uiFilePath: 'services/api/src/handler.ts',
      expiryTime: now + 10 * 60 * 1000,
      type: 'SNAPSHOT',
      condition: 'cart.total > 500',
      shouldCaptureTraceId: expectedTrace,
      captureClosures: expectedClosures,
    });
  });

  it.each([
    ['false', undefined, undefined],
    ['false', ' \t\n', undefined],
    ['true', '', undefined],
    ['true', 'false', 'false'],
  ])('allows trace capture independently of conditional=%s, condition=%j', async (conditional, condition, expected) => {
    const trpc = createProbeClient();
    const { createMcpHandlers } = await loadMcpModule('false', conditional);
    const now = Date.parse('2026-01-01T00:00:00.000Z');
    vi.spyOn(Date, 'now').mockReturnValue(now);
    const result = await createMcpHandlers(createRuntime(trpc)).callTool({
      params: {
        name: 'create_probe',
        arguments: {
          ...probeArgs,
          ...(condition === undefined ? {} : { condition }),
          shouldCaptureTraceId: true,
        },
      },
    });

    expect(result.isError).not.toBe(true);
    expect(trpc.createProbe.mutate).toHaveBeenCalledExactlyOnceWith({
      ...probeArgs,
      uiFilePath: 'services/api/src/handler.ts',
      expiryTime: now + 60 * 60 * 1000,
      type: 'SNAPSHOT',
      condition: expected,
      shouldCaptureTraceId: true,
      captureClosures: false,
    });
  });

  it.each([
    ['file', { uiFilePath: '/virtual/missing.ts' }, /does not exist/i],
    ['service', { serviceId: 'wrong-service' }, /service ID/i],
    ['environment', { environment: 'staging' }, /no active agents/i],
    ['commit', { commitSha: 'b'.repeat(40) }, /no active agents/i],
  ])('preserves %s validation before mutation', async (_name, overrides, message) => {
    const trpc = createProbeClient();
    const { createMcpHandlers } = await loadMcpModule('false', 'true');
    const result = await createMcpHandlers(createRuntime(trpc)).callTool({
      params: {
        name: 'create_probe',
        arguments: { ...probeArgs, ...overrides },
      },
    });

    expect(result.isError).toBe(true);
    expect(result.content[0].text).toMatch(message);
    expect(trpc.createProbe.mutate).not.toHaveBeenCalled();
  });
});

describe('create_probe watch-expression gate', () => {
  it.each([
    ['valid', [' items.length ', 'cart.total']],
    ['empty array', []],
    ['string', 'sensitive-watch'],
    ['null', null],
    ['number', 42],
    ['boolean', false],
    ['object', { expression: 'sensitive-watch' }],
    ['non-string elements', [null, false, 42, {}, []]],
    ['blank', [' \t\n']],
    ['over count', Array(11).fill('sensitive-watch')],
    ['over bytes', [`${'\u00e9'.repeat(128)}x`]],
    ['undefined', undefined],
  ])('ignores disabled watches: %s, without forwarding or mutating them', async (_name, watchExpressions) => {
    const trpc = createProbeClient();
    const { createMcpHandlers } = await loadMcpModule('true', 'true', 'false');
    const args = Object.freeze({ ...probeArgs, watchExpressions });
    const original = structuredClone(args);
    const result = await createMcpHandlers(createRuntime(trpc)).callTool({
      params: { name: 'create_probe', arguments: args },
    });

    expect(result.isError).not.toBe(true);
    expect(JSON.parse(result.content[0].text)).toEqual({ id: 'probe-id' });
    expect(trpc.createProbe.mutate).toHaveBeenCalledOnce();
    expect(
      Object.hasOwn(
        trpc.createProbe.mutate.mock.calls[0][0],
        'watchExpressions',
      ),
    ).toBe(false);
    expect(args).toStrictEqual(original);
  });

  it.each([
    [
      'source text, order, and duplicates',
      ['  cart.total \n', 'items[0]?.price', '  cart.total \n'],
    ],
    ['explicit empty array', []],
    [
      'ten expressions',
      Array.from({ length: 10 }, (_, index) => `items[${index}]`),
    ],
    ['256 ASCII bytes', ['x'.repeat(256)]],
    ['256 UTF-8 bytes in 128 characters', ['\u00e9'.repeat(128)]],
  ])('forwards enabled watches preserving %s', async (_name, watchExpressions) => {
    const trpc = createProbeClient();
    const { createMcpHandlers } = await loadMcpModule('false', 'false', 'true');
    const args = Object.freeze({
      ...probeArgs,
      watchExpressions: Object.freeze(watchExpressions),
      backendOption: 'preserved',
    });
    const original = structuredClone(args);
    const result = await createMcpHandlers(createRuntime(trpc)).callTool({
      params: { name: 'create_probe', arguments: args },
    });

    expect(result.isError).not.toBe(true);
    expect(JSON.parse(result.content[0].text)).toEqual({ id: 'probe-id' });
    expect(trpc.createProbe.mutate).toHaveBeenCalledOnce();
    const payload = trpc.createProbe.mutate.mock.calls[0][0];
    expect(Object.hasOwn(payload, 'watchExpressions')).toBe(true);
    expect(payload.watchExpressions).toStrictEqual(original.watchExpressions);
    expect(payload.backendOption).toBe('preserved');
    expect(args).toStrictEqual(original);
  });

  it.each([
    ['omitted', {}],
    ['undefined', { watchExpressions: undefined }],
  ])('leaves enabled watches absent when %s', async (_name, overrides) => {
    const trpc = createProbeClient();
    const { createMcpHandlers } = await loadMcpModule('false', 'false', 'true');
    const args = Object.freeze({ ...probeArgs, ...overrides });
    const original = structuredClone(args);
    const result = await createMcpHandlers(createRuntime(trpc)).callTool({
      params: { name: 'create_probe', arguments: args },
    });

    expect(result.isError).not.toBe(true);
    expect(trpc.createProbe.mutate).toHaveBeenCalledOnce();
    expect(
      Object.hasOwn(
        trpc.createProbe.mutate.mock.calls[0][0],
        'watchExpressions',
      ),
    ).toBe(false);
    expect(args).toStrictEqual(original);
  });

  it.each([
    ['string', 'sensitive-watch', /must be an array of strings/i],
    ['null', null, /must be an array of strings/i],
    ['number', 42, /must be an array of strings/i],
    ['boolean', false, /must be an array of strings/i],
    [
      'object',
      { expression: 'sensitive-watch' },
      /must be an array of strings/i,
    ],
    [
      'null element',
      ['sensitive-watch', null],
      /zero-based index 1 must be a string/i,
    ],
    [
      'number element',
      ['sensitive-watch', 42],
      /zero-based index 1 must be a string/i,
    ],
    [
      'boolean element',
      ['sensitive-watch', false],
      /zero-based index 1 must be a string/i,
    ],
    [
      'object element',
      ['sensitive-watch', {}],
      /zero-based index 1 must be a string/i,
    ],
    [
      'array element',
      ['sensitive-watch', []],
      /zero-based index 1 must be a string/i,
    ],
    [
      'undefined element',
      ['sensitive-watch', undefined],
      /zero-based index 1 must be a string/i,
    ],
    [
      'empty string',
      ['sensitive-watch', ''],
      /zero-based index 1 is blank \(0 UTF-8 bytes\)/i,
    ],
    [
      'whitespace',
      ['sensitive-watch', ' \t\n'],
      /zero-based index 1 is blank \(3 UTF-8 bytes\)/i,
    ],
    [
      'Unicode whitespace',
      ['sensitive-watch', '\u00a0'],
      /zero-based index 1 is blank \(2 UTF-8 bytes\)/i,
    ],
    [
      'eleven expressions',
      Array(11).fill('sensitive-watch'),
      /has 11 expressions; maximum is 10 per probe/i,
    ],
    [
      'count before element validation',
      [
        null,
        'sensitive-watch'.padEnd(257, 'x'),
        ...Array(9).fill('sensitive-watch'),
      ],
      /has 11 expressions; maximum is 10 per probe/i,
    ],
    [
      '257 ASCII bytes',
      ['sensitive-watch', 'sensitive-watch'.padEnd(257, 'x')],
      /zero-based index 1 has 257 UTF-8 bytes; maximum is 256 bytes/i,
    ],
    [
      '257 UTF-8 bytes in 129 characters',
      ['sensitive-watch', `${'\u00e9'.repeat(128)}x`],
      /zero-based index 1 has 257 UTF-8 bytes; maximum is 256 bytes/i,
    ],
    [
      '257 bytes before trimming',
      ['sensitive-watch', `${'\u00e9'.repeat(128)} `],
      /zero-based index 1 has 257 UTF-8 bytes; maximum is 256 bytes/i,
    ],
  ])('rejects enabled watches before I/O: %s', async (_name, watchExpressions, message) => {
    const trpc = createProbeClient();
    const { createMcpHandlers } = await loadMcpModule('false', 'false', 'true');
    const args = Object.freeze({ ...probeArgs, watchExpressions });
    const original = structuredClone(args);
    const result = await createMcpHandlers(createRuntime(trpc)).callTool({
      params: { name: 'create_probe', arguments: args },
    });

    expect(result.isError).toBe(true);
    expect(result.content[0].text).toMatch(message);
    expect(result.content[0].text).toContain('The probe was not created.');
    expect(result.content[0].text).not.toContain('sensitive-watch');
    expect(args).toStrictEqual(original);
    expect(existsSync).not.toHaveBeenCalled();
    expect(fs.readFile).not.toHaveBeenCalled();
    expect(trpc.listActiveAgents.query).not.toHaveBeenCalled();
    expect(trpc.createProbe.mutate).not.toHaveBeenCalled();
  });
});

describe('snapshot trace ID passthrough', () => {
  it.each([
    'list_snapshots',
    'wait_for_snapshot',
  ])('preserves nullable trace IDs and BigInt payloads through %s', async (name) => {
    const traceIds = [null, '4bf92f3577b34da6a3ce929d0e0e4736'];
    const frames = [{ functionName: 'handler', line: 12 }];
    const snapshots = traceIds.map((traceId) => ({
      traceId,
      payload: { vars: { count: 9007199254740993n }, frames },
    }));
    const trpc = {
      listSnapshots: { query: vi.fn().mockResolvedValue(snapshots) },
      listProbes: {
        query: vi
          .fn()
          .mockResolvedValue([
            { id: 'probe-id', isLive: true, status: 'ACTIVE' },
          ]),
      },
    };
    const { createMcpHandlers } = await loadMcpModule('false', 'false');
    const result = await createMcpHandlers(createRuntime(trpc)).callTool({
      params: {
        name,
        arguments: { probeId: 'probe-id', serviceId: 'service-id' },
      },
    });

    expect(result.isError).not.toBe(true);
    expect(JSON.parse(result.content[0].text)).toEqual(
      traceIds.map((traceId) => ({
        traceId,
        payload: { vars: { count: '9007199254740993' }, frames },
      })),
    );
    expect(trpc.listSnapshots.query).toHaveBeenCalledExactlyOnceWith({
      probeId: 'probe-id',
    });
    if (name === 'wait_for_snapshot') {
      expect(trpc.listProbes.query).toHaveBeenCalledExactlyOnceWith({
        serviceIds: ['service-id'],
      });
    } else {
      expect(trpc.listProbes.query).not.toHaveBeenCalled();
    }
  });
});
