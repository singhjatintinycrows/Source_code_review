import { spawnSync } from 'node:child_process';
import { mkdtempSync, rmSync, symlinkSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join, relative } from 'node:path';
import { fileURLToPath } from 'node:url';
import { afterAll, beforeAll, describe, expect, it } from 'vitest';

const moduleUrl = new URL('../src/index.ts', import.meta.url);
const packageDir = fileURLToPath(new URL('..', import.meta.url));
let fixtureDir: string;

beforeAll(() => {
  fixtureDir = mkdtempSync(join(tmpdir(), 'hyperprobe-mcp-startup-'));
});

afterAll(() => {
  if (fixtureDir) rmSync(fixtureDir, { recursive: true, force: true });
});

function runNode(args: string[]) {
  const result = spawnSync(process.execPath, ['--import', 'tsx', ...args], {
    cwd: packageDir,
    env: {
      ...process.env,
      BACKEND_URL: 'http://127.0.0.1:1',
      // An injected token skips browser login, cached credentials, and refreshes.
      HYPERPROBE_ACCESS_TOKEN: 'mcp-startup-test-token',
    },
    input: `${JSON.stringify({
      jsonrpc: '2.0',
      id: 1,
      method: 'initialize',
      params: {
        protocolVersion: '2025-11-25',
        capabilities: {},
        clientInfo: { name: 'startup-test', version: '1.0.0' },
      },
    })}\n`,
    encoding: 'utf8',
    timeout: 5000,
  });

  expect(result.error).toBeUndefined();
  expect(result.status, result.stderr).toBe(0);
  return result;
}

describe('MCP executable startup', () => {
  it.each(['direct', 'symlink'])('bootstraps a %s executable', (mode) => {
    let entryPoint = fileURLToPath(moduleUrl);
    if (mode === 'symlink') {
      entryPoint = join(fixtureDir, 'hyperprobe-mcp');
      symlinkSync(relative(fixtureDir, fileURLToPath(moduleUrl)), entryPoint);
    }

    const { stdout, stderr } = runNode([entryPoint]);

    expect(stderr).toContain('Hyperprobe MCP server running on stdio');
    expect(JSON.parse(stdout)).toMatchObject({
      jsonrpc: '2.0',
      id: 1,
      result: {
        capabilities: { tools: {} },
        serverInfo: { name: 'hyperprobe-mcp' },
      },
    });
  });

  it('does not bootstrap when imported by another module', () => {
    const importer = join(fixtureDir, 'importer.mjs');
    writeFileSync(
      importer,
      `await import(${JSON.stringify(moduleUrl.href)});\n`,
    );

    const { stdout, stderr } = runNode([importer]);

    expect(stdout).toBe('');
    expect(stderr).toBe('');
  });

  it.each([
    ['no entry point', false],
    ['a nonexistent entry point', true],
  ])('does not bootstrap on import with %s', (_description, hasEntryPoint) => {
    const args = [
      '--input-type=module',
      '--eval',
      `await import(${JSON.stringify(moduleUrl.href)});`,
    ];
    if (hasEntryPoint) args.push(join(fixtureDir, 'missing-main.mjs'));

    const { stdout, stderr } = runNode(args);

    expect(stdout).toBe('');
    expect(stderr).toBe('');
  });
});
