import childProcess from 'node:child_process';
import fs, { type FileHandle } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import path from 'node:path';
import { promisify } from 'node:util';
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import type { McpRuntime } from '../src/index.js';
import { resolveProbeBaseDir } from '../src/service-config.js';

let fixtureDir: string;
const execFile = promisify(childProcess.execFile);
const noMatch = /No \.hprc configuration for service ID/;
const denied = Object.assign(new Error('permission denied'), {
  code: 'EACCES',
});

beforeEach(async () => {
  fixtureDir = await fs.realpath(
    await fs.mkdtemp(path.join(tmpdir(), 'hyperprobe-hprc-')),
  );
  vi.spyOn(console, 'error').mockImplementation(() => {});
});

afterEach(async () => {
  vi.restoreAllMocks();
  vi.unstubAllEnvs();
  await fs.rm(fixtureDir, { recursive: true, force: true });
});

async function write(relativePath: string, content = '') {
  const file = path.join(fixtureDir, relativePath);
  await fs.mkdir(path.dirname(file), { recursive: true });
  await fs.writeFile(file, content);
  return file;
}

async function configure(directory: string, serviceId: unknown) {
  return write(path.join(directory, '.hprc'), JSON.stringify({ serviceId }));
}

async function git(root: string, ...args: string[]) {
  return execFile(
    'git',
    ['--no-optional-locks', '-c', 'core.fsmonitor=false', '-C', root, ...args],
    {
      env: Object.fromEntries(
        Object.entries(process.env).filter(([key]) => !key.startsWith('GIT_')),
      ),
      timeout: 10_000,
    },
  );
}

async function trackConfigs(root: string) {
  await git(root, 'add', '--force', '--', ':(glob)**/.hprc');
}

function mockGit() {
  const run = vi.fn<typeof execFile>();
  // execFile's promisified API returns both streams rather than only stdout.
  Object.defineProperty(vi.spyOn(childProcess, 'execFile'), promisify.custom, {
    configurable: true,
    value: run,
  });
  return run;
}

async function makeRepo(
  directory = 'repo',
  marker: 'directory' | 'file' = 'directory',
) {
  const root = path.join(fixtureDir, directory);
  await fs.mkdir(root, { recursive: true });
  await git(
    root,
    'init',
    '--quiet',
    ...(marker === 'file'
      ? ['--separate-git-dir', path.join(fixtureDir, `${directory}.git`)]
      : []),
  );
  return root;
}

describe('legacy ancestor .hprc resolution', () => {
  it('uses the nearest usable non-Git ancestor and rejects mismatched service IDs', async () => {
    await configure('workspace', 'outer');
    const config = await configure('workspace/service', 'api');
    const source = await write('workspace/service/src/handler.ts');
    const opendir = vi.spyOn(fs, 'opendir');

    await expect(resolveProbeBaseDir(source, 'api')).resolves.toBe(
      path.dirname(config),
    );
    await expect(resolveProbeBaseDir(source, 'outer')).rejects.toThrow(
      /file belongs to service ID 'api'/,
    );
    expect(opendir).not.toHaveBeenCalled();
  });

  it('accepts untracked ancestors and returns the Git root for wire paths', async () => {
    const root = await makeRepo();
    await configure('repo/services/api', 'api');
    const source = await write('repo/services/api/src/handler.ts');
    const run = mockGit().mockRejectedValue(new Error('Git must not run'));

    const base = await resolveProbeBaseDir(source, 'api');

    expect(base).toBe(root);
    expect(path.relative(base, source)).toBe(
      path.join('services', 'api', 'src', 'handler.ts'),
    );
    expect(run).not.toHaveBeenCalled();
  });

  it('still accepts ancestor configs above the Git root', async () => {
    await configure('', 'outer');
    const root = await makeRepo();
    const source = await write('repo/libs/console.ts');

    await expect(resolveProbeBaseDir(source, 'outer')).resolves.toBe(root);
    await expect(resolveProbeBaseDir(source, 'api')).rejects.toThrow(
      /file belongs to service ID 'outer'/,
    );
  });

  it('does not discover siblings without a Git root', async () => {
    await configure('workspace/services/api', 'api');
    const source = await write('workspace/libs/console.ts');
    const opendir = vi.spyOn(fs, 'opendir');

    await expect(resolveProbeBaseDir(source, 'api')).rejects.toThrow(
      /No \.hprc file found.*no Git working-tree root.*shared-source discovery/,
    );
    expect(opendir).not.toHaveBeenCalled();
  });

  it('strips BOMs and skips malformed and wrong-type ancestors', async () => {
    const root = await makeRepo();
    await write('repo/.hprc', '\ufeff{"serviceId":"api"}');
    const malformed = await write('repo/services/api/.hprc', '{broken');
    await configure('repo/services/api/src', 123);
    const source = await write('repo/services/api/src/handler.ts');

    await expect(resolveProbeBaseDir(source, 'api')).resolves.toBe(root);
    expect(console.error).toHaveBeenCalledWith(
      `Failed to parse ${malformed}:`,
      expect.any(SyntaxError),
    );
  });

  it('logs unreadable ancestors and continues upward', async () => {
    const root = await makeRepo();
    await configure('repo', 'api');
    const blocked = await configure('repo/services/api', 'other');
    const source = await write('repo/services/api/src/handler.ts');
    const readFile = fs.readFile;
    vi.spyOn(fs, 'readFile').mockImplementation((file, options) =>
      String(file) === blocked
        ? Promise.reject(denied)
        : readFile(file, options),
    );

    await expect(resolveProbeBaseDir(source, 'api')).resolves.toBe(root);
    expect(console.error).toHaveBeenCalledWith(
      `Failed to parse ${blocked}:`,
      denied,
    );
  });

  it.each([
    '',
    ' api-id ',
  ])('accepts exact string service IDs without normalization: %j', async (serviceId) => {
    const root = await makeRepo();
    await configure('repo/services/api', serviceId);
    const local = await write('repo/services/api/src/handler.ts');
    const shared = await write('repo/libs/console.ts');

    await expect(resolveProbeBaseDir(local, serviceId)).resolves.toBe(root);
    await trackConfigs(root);
    await expect(resolveProbeBaseDir(shared, serviceId)).resolves.toBe(root);
    await expect(resolveProbeBaseDir(local, 'api-id')).rejects.toThrow(
      /service ID/,
    );
    await expect(resolveProbeBaseDir(shared, 'api-id')).rejects.toThrow(
      noMatch,
    );
  });

  it('does not apply fallback symlink or byte restrictions to legacy ancestors', async () => {
    const root = await makeRepo();
    const external = await write('outside/console.ts');
    const config = await configure('outside', 'api');
    await fs.appendFile(config, ' '.repeat(64 * 1024));
    const source = path.join(root, 'console.ts');
    await fs.symlink(external, source);
    await fs.symlink(config, path.join(root, '.hprc'));
    const realpath = vi.spyOn(fs, 'realpath');

    await expect(resolveProbeBaseDir(source, 'api')).resolves.toBe(root);
    expect(realpath).not.toHaveBeenCalled();
  });
});

describe('repository-local shared-source discovery', () => {
  it('resolves staged, uncommitted sibling configs, but never an unknown ID', async () => {
    const root = await makeRepo();
    await configure('repo/services/api', 'api');
    await configure('repo/services/worker', 'worker');
    await trackConfigs(root);
    const source = await write('repo/libs/console.ts');
    const readFile = vi.spyOn(fs, 'readFile');
    const opendir = vi.spyOn(fs, 'opendir');

    await expect(
      git(root, 'rev-parse', '--verify', 'HEAD'),
    ).rejects.toMatchObject({
      code: 128,
    });

    for (const serviceId of ['api', 'worker']) {
      const base = await resolveProbeBaseDir(source, serviceId);
      expect(base).toBe(root);
      expect(path.relative(base, source)).toBe(path.join('libs', 'console.ts'));
    }
    await expect(resolveProbeBaseDir(source, 'missing')).rejects.toThrow(
      /No \.hprc configuration for service ID 'missing'.*Git-tracked/,
    );
    expect(readFile).not.toHaveBeenCalled();
    expect(opendir).not.toHaveBeenCalled();
  });

  it.each([
    false,
    true,
  ])('requires tracking for sibling configs, including ignored=%s', async (ignored) => {
    const root = await makeRepo();
    await configure('repo/.local/service', 'api');
    if (ignored) await write('repo/.gitignore', '.local/\n');
    const source = await write('repo/libs/console.ts');
    const open = vi.spyOn(fs, 'open');

    await expect(resolveProbeBaseDir(source, 'api')).rejects.toThrow(noMatch);
    expect(open).not.toHaveBeenCalled();

    await trackConfigs(root);
    await expect(resolveProbeBaseDir(source, 'api')).resolves.toBe(root);
  });

  it('does not change source tracking, the index, or working-tree status', async () => {
    const root = await makeRepo();
    await configure('repo/services/api', 'api');
    await trackConfigs(root);
    const source = await write('repo/libs/console.ts');
    const statusArgs = [
      'status',
      '--porcelain=v1',
      '-z',
      '--untracked-files=all',
    ];
    const before = await git(root, ...statusArgs);
    const index = path.join(root, '.git/index');
    const indexBefore = await fs.readFile(index);

    await expect(resolveProbeBaseDir(source, 'api')).resolves.toBe(root);
    await expect(resolveProbeBaseDir(source, 'missing')).rejects.toThrow(
      noMatch,
    );

    expect((await git(root, ...statusArgs)).stdout).toBe(before.stdout);
    expect(await fs.readFile(index)).toEqual(indexBefore);
    expect((await git(root, 'ls-files', '--', 'libs/console.ts')).stdout).toBe(
      '',
    );
  });

  it('rejects an ancestor conflict without looking for a matching sibling', async () => {
    const root = await makeRepo();
    await configure('repo/libs', 'owner');
    await configure('repo/services/api', 'api');
    await trackConfigs(root);
    const source = await write('repo/libs/console.ts');
    const opendir = vi.spyOn(fs, 'opendir');
    const run = mockGit().mockRejectedValue(new Error('Git must not run'));

    await expect(resolveProbeBaseDir(source, 'api')).rejects.toThrow(
      /service ID 'api'.*file belongs to service ID 'owner'/,
    );
    expect(opendir).not.toHaveBeenCalled();
    expect(run).not.toHaveBeenCalled();
  });

  it('finds BOM configs after malformed ancestors and wrong-type candidates', async () => {
    const root = await makeRepo();
    const malformed = await write('repo/.hprc', '{broken');
    await configure('repo/services/0-wrong-type', ['api']);
    const malformedSibling = await write(
      'repo/services/1-malformed/.hprc',
      '{broken',
    );
    const config = await write(
      'repo/services/api/.hprc',
      '\ufeff{"serviceId":"api"}',
    );
    await trackConfigs(root);
    const source = await write('repo/libs/console.ts');

    await expect(resolveProbeBaseDir(source, 'api')).resolves.toBe(root);
    expect(console.error).toHaveBeenCalledWith(
      `Failed to parse ${malformed}:`,
      expect.any(SyntaxError),
    );
    expect(console.error).toHaveBeenCalledWith(
      `Failed to parse ${malformedSibling}:`,
      expect.any(SyntaxError),
    );
    await fs.rm(config);
    await expect(resolveProbeBaseDir(source, 'api')).rejects.toThrow(noMatch);
  });

  it('accepts duplicate IDs, exits on the first match, and closes all handles', async () => {
    const root = await makeRepo();
    await configure('repo/services/api', 'api');
    await configure('repo/services/copy', 'api');
    await trackConfigs(root);
    const source = await write('repo/libs/console.ts');
    const open = vi.spyOn(fs, 'open');
    const opendir = vi.spyOn(fs, 'opendir');

    await expect(resolveProbeBaseDir(source, 'api')).resolves.toBe(root);

    expect(open).toHaveBeenCalledTimes(1);
    expect((await open.mock.results[0].value).fd).toBe(-1);
    expect(opendir).not.toHaveBeenCalled();
  });

  it('observes unstaged edits, deletion, and removal from the index between calls', async () => {
    const root = await makeRepo();
    const config = await configure('repo/services/api', 'api');
    await trackConfigs(root);
    const source = await write('repo/libs/console.ts');
    await expect(resolveProbeBaseDir(source, 'api')).resolves.toBe(root);

    await configure('repo/services/api', 'worker');

    await expect(resolveProbeBaseDir(source, 'api')).rejects.toThrow(noMatch);
    await expect(resolveProbeBaseDir(source, 'worker')).resolves.toBe(root);

    await fs.rm(config);
    await expect(resolveProbeBaseDir(source, 'worker')).rejects.toThrow(
      noMatch,
    );

    await configure('repo/services/api', 'api');
    await expect(resolveProbeBaseDir(source, 'api')).resolves.toBe(root);
    await git(root, 'rm', '--cached', '--', 'services/api/.hprc');
    await expect(resolveProbeBaseDir(source, 'api')).rejects.toThrow(noMatch);
    expect(await fs.readFile(config, 'utf-8')).toBe('{"serviceId":"api"}');
  });

  it.each([
    'directory',
    'file',
  ] as const)('skips nested .git %s markers even when configs remain in the parent index', async (marker) => {
    const root = await makeRepo();
    await configure('repo/nested/services/api', 'api');
    await trackConfigs(root);
    await makeRepo('repo/nested', marker);
    const source = await write('repo/libs/console.ts');
    const open = vi.spyOn(fs, 'open');
    const opendir = vi.spyOn(fs, 'opendir');
    const lstat = vi.spyOn(fs, 'lstat');

    await expect(resolveProbeBaseDir(source, 'api')).rejects.toThrow(noMatch);

    expect(open).not.toHaveBeenCalled();
    expect(opendir).not.toHaveBeenCalled();
    expect(lstat).not.toHaveBeenCalledWith(path.join(root, 'nested/services'));
  });

  it('uses a linked worktree root without discovering the main tree or gitdir', async () => {
    const main = await makeRepo('main');
    await configure('main/services/api', 'api');
    await trackConfigs(main);
    const gitdirConfig = await configure('main/.git/worktrees/linked', 'api');
    const linked = path.join(fixtureDir, 'linked');
    // An unborn worktree has its own HEAD/index and shares only main's metadata.
    await write('main/.git/worktrees/linked/HEAD', 'ref: refs/heads/linked\n');
    await write('main/.git/worktrees/linked/commondir', '../..\n');
    await write('main/.git/worktrees/linked/gitdir', `${linked}/.git\n`);
    await write('linked/.git', `gitdir: ${path.dirname(gitdirConfig)}\n`);
    await configure('linked/services/api', 'api');
    const source = await write('linked/libs/console.ts');
    const open = vi.spyOn(fs, 'open');

    expect(
      (await git(linked, 'rev-parse', '--show-toplevel')).stdout.trim(),
    ).toBe(linked);

    await expect(resolveProbeBaseDir(source, 'api')).rejects.toThrow(noMatch);
    expect(open).not.toHaveBeenCalled();

    await configure('linked/services/local', 'api');
    await git(linked, 'add', '--', 'services/local/.hprc');
    await expect(resolveProbeBaseDir(source, 'api')).resolves.toBe(linked);
    expect(open.mock.calls.map(([file]) => String(file))).toEqual([
      path.join(linked, 'services/local/.hprc'),
    ]);
  });

  it('preserves lexical source and working-tree aliases for wire path calculation', async () => {
    const root = await makeRepo();
    await configure('repo/services/api', 'api');
    await trackConfigs(root);
    const target = await write('repo/src/console.ts');
    await fs.mkdir(path.join(root, 'libs'));
    await fs.symlink(target, path.join(root, 'libs/console.ts'));
    const alias = path.join(fixtureDir, 'alias');
    await fs.symlink(root, alias);
    const source = path.join(alias, 'libs/console.ts');

    const base = await resolveProbeBaseDir(source, 'api');

    expect(base).toBe(alias);
    expect(path.relative(base, source)).toBe(path.join('libs', 'console.ts'));
  });

  it('rejects outside source symlinks, including path-prefix collisions', async () => {
    const root = await makeRepo();
    await configure('repo/services/api', 'api');
    await trackConfigs(root);
    const external = await write('repo-other/console.ts');
    const source = path.join(root, 'console.ts');
    await fs.symlink(external, source);
    const opendir = vi.spyOn(fs, 'opendir');

    await expect(resolveProbeBaseDir(source, 'api')).rejects.toThrow(
      /must resolve within the same Git working tree/,
    );
    expect(opendir).not.toHaveBeenCalled();
  });

  it('rejects source aliases targeting a nested repository within the root', async () => {
    const root = await makeRepo();
    await configure('repo/services/api', 'api');
    await trackConfigs(root);
    await makeRepo('repo/nested', 'file');
    const nestedSource = await write('repo/nested/src/console.ts');
    const source = path.join(root, 'console.ts');
    await fs.symlink(nestedSource, source);
    const opendir = vi.spyOn(fs, 'opendir');

    await expect(resolveProbeBaseDir(source, 'api')).rejects.toThrow(
      /must resolve within the same Git working tree/,
    );
    expect(opendir).not.toHaveBeenCalled();
  });

  it('never follows discovered config or directory symlinks, even internal ones', async () => {
    const root = await makeRepo();
    const external = await configure('outside', 'api');
    const internal = await write('repo/config.json', '{"serviceId":"api"}');
    const untracked = await configure('repo/local-config', 'api');
    const replaced = await configure('repo/services/replaced', 'api');
    await fs.mkdir(path.join(root, 'services/internal'), { recursive: true });
    await fs.mkdir(path.join(root, 'services/external'));
    await fs.symlink(internal, path.join(root, 'services/internal/.hprc'));
    await fs.symlink(external, path.join(root, 'services/external/.hprc'));
    await fs.symlink(path.dirname(external), path.join(root, 'external-link'));
    await fs.symlink(path.dirname(untracked), path.join(root, 'internal-link'));
    await git(
      root,
      'add',
      '--force',
      '--',
      'services/internal/.hprc',
      'services/external/.hprc',
      'services/replaced/.hprc',
      'external-link',
      'internal-link',
    );
    await fs.rm(replaced);
    await fs.symlink(internal, replaced);
    const source = await write('repo/libs/console.ts');
    const open = vi.spyOn(fs, 'open');

    await expect(resolveProbeBaseDir(source, 'api')).rejects.toThrow(noMatch);
    expect(open).not.toHaveBeenCalled();
  });

  it.each([
    'internal',
    'external',
  ])('skips tracked directories replaced with %s symlinks', async (target) => {
    const root = await makeRepo();
    const targetDir =
      target === 'internal' ? 'repo/local-configs' : 'outside/services';
    await configure(path.join(targetDir, 'api'), 'api');
    await configure('repo/services/api', 'api');
    await git(root, 'add', '--', 'services/api/.hprc');
    await fs.rm(path.join(root, 'services'), { recursive: true });
    await fs.symlink(
      path.join(fixtureDir, targetDir),
      path.join(root, 'services'),
    );
    const source = await write('repo/libs/console.ts');
    const open = vi.spyOn(fs, 'open');
    const lstat = vi.spyOn(fs, 'lstat');

    await expect(resolveProbeBaseDir(source, 'api')).rejects.toThrow(noMatch);
    expect(open).not.toHaveBeenCalled();
    expect(lstat).not.toHaveBeenCalledWith(path.join(root, 'services/api'));
  });

  it('accepts tracked configs regardless of generated, dependency, or cache directory names', async () => {
    const root = await makeRepo();
    const directoryNames = [
      'node_modules',
      'dist',
      'build',
      'out',
      'coverage',
      'target',
      '.nx',
      '.cache',
      '.next',
      '.nuxt',
      '.turbo',
      '.venv',
      'venv',
      '__pycache__',
      '.yarn',
      '.pnpm-store',
    ];
    const configDirectories = directoryNames.flatMap((name) => [
      name,
      `packages/${name}/service`,
    ]);
    for (const directory of configDirectories) {
      await configure(`repo/${directory}`, directory);
    }
    await trackConfigs(root);
    const source = await write('repo/libs/console.ts');
    const opendir = vi.spyOn(fs, 'opendir');

    for (const directory of configDirectories) {
      await expect(resolveProbeBaseDir(source, directory)).resolves.toBe(root);
    }
    expect(opendir).not.toHaveBeenCalled();
  });
});

describe('Git-tracked path enumeration', () => {
  it.each([
    '.hprc',
    'services/api/.hprc',
  ])('does not treat children of the %s directory as configs', async (directory) => {
    const root = await makeRepo();
    const relativeFile = `${directory}/settings.json`;
    await write(`repo/${relativeFile}`, '{"serviceId":"api"}');
    await git(root, 'add', '--', relativeFile);
    const source = await write('repo/libs/console.ts');
    const open = vi.spyOn(fs, 'open');

    await expect(resolveProbeBaseDir(source, 'api')).rejects.toThrow(noMatch);
    expect(open).not.toHaveBeenCalled();
  });

  it('finds tracked configs beyond the former directory depth limit', async () => {
    const root = await makeRepo();
    await configure(
      path.join('repo', ...Array<string>(33).fill('level')),
      'api',
    );
    await trackConfigs(root);
    const source = await write('repo/libs/console.ts');
    const opendir = vi.spyOn(fs, 'opendir');

    await expect(resolveProbeBaseDir(source, 'api')).resolves.toBe(root);
    expect(opendir).not.toHaveBeenCalled();
  });

  it.each([
    ' service with spaces ',
    '\nservice\n',
  ])('preserves literal path whitespace: %j', async (directory) => {
    const repo = 'repo with spaces\nand newline';
    const root = await makeRepo(repo);
    await configure(path.join(repo, directory), 'api');
    await trackConfigs(root);
    const source = await write(path.join(repo, 'libs/console.ts'));

    await expect(resolveProbeBaseDir(source, 'api')).resolves.toBe(root);
  });

  it('uses the canonical worktree, bounded execFile arguments, and a copied environment without any GIT_* variables', async () => {
    const root = await makeRepo();
    await configure('repo/services/api', 'api');
    await trackConfigs(root);
    const foreign = await makeRepo('foreign');
    await configure('foreign/services/other', 'other');
    await trackConfigs(foreign);
    await write('repo/libs/console.ts');
    const alias = path.join(fixtureDir, 'alias');
    await fs.symlink(root, alias);
    for (const [key, value] of Object.entries({
      GIT_DIR: path.join(foreign, '.git'),
      GIT_WORK_TREE: foreign,
      GIT_INDEX_FILE: path.join(foreign, '.git/index'),
      GIT_COMMON_DIR: path.join(foreign, '.git'),
      GIT_LITERAL_PATHSPECS: '1',
      GIT_GLOB_PATHSPECS: '1',
      GIT_NOGLOB_PATHSPECS: '1',
      GIT_ICASE_PATHSPECS: '1',
      GIT_CONFIG_COUNT: '1',
      GIT_CONFIG_KEY_0: 'core.bare',
      GIT_CONFIG_VALUE_0: 'true',
      GIT_TEST_SENTINEL: 'must not reach Git',
      HPRC_TEST_SENTINEL: 'preserved',
    })) {
      vi.stubEnv(key, value);
    }
    const inherited = { ...process.env };
    const run = mockGit().mockImplementation(execFile);

    await expect(
      resolveProbeBaseDir(path.join(alias, 'libs/console.ts'), 'api'),
    ).resolves.toBe(alias);

    expect(run).toHaveBeenCalledExactlyOnceWith(
      'git',
      [
        '--no-optional-locks',
        '-c',
        'core.fsmonitor=false',
        '-C',
        root,
        'ls-files',
        '--cached',
        '-z',
        '--',
        '.hprc',
        ':(glob)**/.hprc',
      ],
      expect.objectContaining({
        timeout: 10_000,
        maxBuffer: 1024 * 1024,
        env: Object.fromEntries(
          Object.entries(inherited).filter(([key]) => !key.startsWith('GIT_')),
        ),
      }),
    );
    expect(run.mock.calls[0][2]?.env).not.toBe(process.env);
    expect(run.mock.calls[0][2]?.shell ?? false).toBe(false);
    expect(process.env).toEqual(inherited);
  });

  it('deduplicates NUL-delimited paths before applying the config read budget', async () => {
    const root = await makeRepo();
    await configure('repo/services/other', 'other');
    await trackConfigs(root);
    const source = await write('repo/libs/console.ts');
    const run = mockGit().mockResolvedValue({
      stdout: ['', ...Array<string>(257).fill('services/other/.hprc'), ''].join(
        '\0',
      ),
      stderr: '',
    });
    const open = vi.spyOn(fs, 'open');

    await expect(resolveProbeBaseDir(source, 'api')).rejects.toThrow(noMatch);
    expect(run).toHaveBeenCalledTimes(1);
    expect(open).toHaveBeenCalledTimes(1);
    expect((await open.mock.results[0].value).fd).toBe(-1);
  });

  it.each([
    { kind: 'missing executable', message: 'spawn git ENOENT', code: 'ENOENT' },
    { kind: 'nonzero exit', message: 'fatal: invalid Git index', code: 128 },
    {
      kind: 'timeout',
      message: 'Command failed: git (timed out)',
      killed: true,
      signal: 'SIGTERM',
    },
    {
      kind: 'output cap',
      message: 'stdout maxBuffer length exceeded',
      code: 'ERR_CHILD_PROCESS_STDIO_MAXBUFFER',
    },
  ])('reports Git $kind failures without filesystem fallback', async (failure) => {
    const root = await makeRepo();
    await configure('repo/services/api', 'api');
    await trackConfigs(root);
    const source = await write('repo/libs/console.ts');
    const error = Object.assign(new Error(failure.message), failure);
    const run = mockGit().mockRejectedValue(error);
    const open = vi.spyOn(fs, 'open');
    const opendir = vi.spyOn(fs, 'opendir');
    const result = resolveProbeBaseDir(source, 'api');

    await expect(result).rejects.toThrow(/git/i);
    await expect(result).rejects.not.toThrow(noMatch);
    expect(run).toHaveBeenCalledTimes(1);
    expect(open).not.toHaveBeenCalled();
    expect(opendir).not.toHaveBeenCalled();
  });
});

describe('bounded discovery and I/O failures', () => {
  it('skips and closes a config that is no longer regular when opened', async () => {
    const root = await makeRepo();
    const config = await configure('repo/service', 'api');
    await trackConfigs(root);
    const source = await write('repo/libs/console.ts');
    const directoryStat = await fs.stat(path.dirname(config));
    const realOpen = fs.open;
    let file: FileHandle | undefined;
    vi.spyOn(fs, 'open').mockImplementation(async (...args) => {
      file = await realOpen(...args);
      vi.spyOn(file, 'stat').mockResolvedValue(directoryStat);
      return file;
    });

    await expect(resolveProbeBaseDir(source, 'api')).rejects.toThrow(noMatch);
    expect(file?.fd).toBe(-1);
  });

  it('accepts the 256th config but caps reads before the 257th, closing every handle', async () => {
    const root = await makeRepo();
    await Promise.all(
      Array.from({ length: 257 }, (_, index) =>
        configure(
          `repo/services/${String(index).padStart(3, '0')}`,
          index === 255 ? 'at-limit' : index === 256 ? 'beyond-limit' : 'other',
        ),
      ),
    );
    await trackConfigs(root);
    const source = await write('repo/libs/console.ts');
    const open = vi.spyOn(fs, 'open');

    await expect(resolveProbeBaseDir(source, 'at-limit')).resolves.toBe(root);
    expect(open).toHaveBeenCalledTimes(256);
    for (const result of open.mock.results) {
      expect((await result.value).fd).toBe(-1);
    }
    open.mockClear();

    await expect(resolveProbeBaseDir(source, 'beyond-limit')).rejects.toThrow(
      /incomplete.*config read limit \(256\)/,
    );
    expect(open).toHaveBeenCalledTimes(256);
    for (const result of open.mock.results) {
      expect((await result.value).fd).toBe(-1);
    }
  });

  it('accepts 64 KiB configs and reads at most limit + 1 bytes even with short reads', async () => {
    const root = await makeRepo();
    const limit = 64 * 1024;
    const content = JSON.stringify({ serviceId: 'api' }).padEnd(limit, ' ');
    const config = await write('repo/service/.hprc', content);
    await trackConfigs(root);
    const source = await write('repo/libs/console.ts');
    await expect(resolveProbeBaseDir(source, 'api')).resolves.toBe(root);
    await fs.appendFile(config, 'more than one extra byte');
    const realOpen = fs.open;
    let bytesRead = 0;
    let file: FileHandle | undefined;
    vi.spyOn(fs, 'open').mockImplementation(async (...args) => {
      file = await realOpen(...args);
      const read = file.read.bind(file);
      vi.spyOn(file, 'read').mockImplementation((async (
        buffer: Buffer,
        offset: number,
        length: number,
        position: number,
      ) => {
        expect(offset + length).toBe(limit + 1);
        const result = await read(
          buffer,
          offset,
          Math.min(length, 4096),
          position,
        );
        bytesRead += result.bytesRead;
        return result;
      }) as FileHandle['read']);
      return file;
    });

    await expect(resolveProbeBaseDir(source, 'api')).rejects.toThrow(
      /incomplete.*config byte limit \(65536\)/,
    );
    expect(bytesRead).toBe(limit + 1);
    expect(file?.fd).toBe(-1);
  });

  it('can find a valid config after an oversized malformed ancestor', async () => {
    const root = await makeRepo();
    await write('repo/.hprc', 'x'.repeat(64 * 1024 + 2));
    await configure('repo/services/api', 'api');
    await trackConfigs(root);
    const source = await write('repo/libs/console.ts');
    const open = vi.spyOn(fs, 'open');

    await expect(resolveProbeBaseDir(source, 'api')).resolves.toBe(root);

    expect(open).toHaveBeenCalledTimes(2);
    for (const result of open.mock.results) {
      expect((await result.value).fd).toBe(-1);
    }
  });

  it.each([
    'open',
    'stat',
    'read',
  ] as const)('reports incomplete discovery on config %s failure, closes handles, and can still find other matches', async (failure) => {
    const root = await makeRepo();
    const blocked = await configure('repo/blocked', 'api');
    await trackConfigs(root);
    const source = await write('repo/libs/console.ts');
    const realOpen = fs.open;
    const files: FileHandle[] = [];
    vi.spyOn(fs, 'open').mockImplementation(async (...args) => {
      if (String(args[0]) === blocked && failure === 'open') throw denied;
      const file = await realOpen(...args);
      files.push(file);
      if (String(args[0]) === blocked && failure !== 'open') {
        vi.spyOn(file, failure).mockRejectedValue(denied);
      }
      return file;
    });

    await expect(resolveProbeBaseDir(source, 'api')).rejects.toThrow(
      /incomplete.*unreadable configuration/,
    );
    expect(console.error).toHaveBeenCalledWith(
      `Failed to read ${blocked}:`,
      denied,
    );
    expect(files.every((file) => file.fd === -1)).toBe(true);

    await configure('repo/z-accessible', 'api');
    await trackConfigs(root);
    await expect(resolveProbeBaseDir(source, 'api')).resolves.toBe(root);
    expect(files.every((file) => file.fd === -1)).toBe(true);
  });

  it.each([
    'directory',
    'configuration',
  ] as const)('reports unreadable %s lstat failures unless a later config matches', async (failure) => {
    const root = await makeRepo();
    const config = await configure('repo/blocked/service', 'api');
    await trackConfigs(root);
    const blocked =
      failure === 'directory' ? path.join(root, 'blocked') : config;
    const source = await write('repo/libs/console.ts');
    const realLstat = fs.lstat;
    vi.spyOn(fs, 'lstat').mockImplementation((file) =>
      String(file) === blocked ? Promise.reject(denied) : realLstat(file),
    );
    const open = vi.spyOn(fs, 'open');

    await expect(resolveProbeBaseDir(source, 'api')).rejects.toThrow(
      /incomplete.*unreadable configuration/,
    );
    expect(console.error).toHaveBeenCalledWith(
      expect.stringContaining(blocked),
      denied,
    );
    expect(open).not.toHaveBeenCalled();

    await configure('repo/z-accessible', 'api');
    await trackConfigs(root);
    await expect(resolveProbeBaseDir(source, 'api')).resolves.toBe(root);
    expect(open).toHaveBeenCalledTimes(1);
    expect((await open.mock.results[0].value).fd).toBe(-1);
  });

  it.each([
    'missing',
    'a regular file',
  ])('skips tracked configs whose parent is %s', async (replacement) => {
    const root = await makeRepo();
    await configure('repo/services/api', 'api');
    await trackConfigs(root);
    await fs.rm(path.join(root, 'services'), { recursive: true });
    if (replacement === 'a regular file') {
      await write('repo/services', 'not a directory');
    }
    const source = await write('repo/libs/console.ts');
    const open = vi.spyOn(fs, 'open');

    await expect(resolveProbeBaseDir(source, 'api')).rejects.toThrow(noMatch);
    expect(open).not.toHaveBeenCalled();
  });

  it.each([
    'ENOENT',
    'ENOTDIR',
  ])('treats configs disappearing during inspection or open as absent: %s', async (code) => {
    const root = await makeRepo();
    const config = await configure('repo/services/api', 'api');
    await trackConfigs(root);
    const source = await write('repo/libs/console.ts');
    const absent = Object.assign(new Error('config disappeared'), { code });
    const realLstat = fs.lstat;
    const lstat = vi
      .spyOn(fs, 'lstat')
      .mockImplementation((file) =>
        String(file) === config ? Promise.reject(absent) : realLstat(file),
      );

    await expect(resolveProbeBaseDir(source, 'api')).rejects.toThrow(noMatch);
    lstat.mockRestore();

    const realOpen = fs.open;
    vi.spyOn(fs, 'open').mockImplementation((...args) =>
      String(args[0]) === config ? Promise.reject(absent) : realOpen(...args),
    );

    await expect(resolveProbeBaseDir(source, 'api')).rejects.toThrow(noMatch);
  });

  it('does not inspect configs when the nested-repository marker cannot be checked', async () => {
    const root = await makeRepo();
    const config = await configure('repo/blocked', 'api');
    await trackConfigs(root);
    const source = await write('repo/libs/console.ts');
    const realLstat = fs.lstat;
    vi.spyOn(fs, 'lstat').mockImplementation((file) =>
      String(file) === path.join(path.dirname(config), '.git')
        ? Promise.reject(denied)
        : realLstat(file),
    );
    const open = vi.spyOn(fs, 'open');

    await expect(resolveProbeBaseDir(source, 'api')).rejects.toThrow(
      /incomplete.*unreadable configuration/,
    );
    expect(open).not.toHaveBeenCalled();
  });

  it('reports canonical-source failures before enumerating Git-tracked paths', async () => {
    const root = await makeRepo();
    await configure('repo/services/api', 'api');
    await trackConfigs(root);
    const source = await write('repo/libs/console.ts');
    vi.spyOn(fs, 'realpath').mockRejectedValue(denied);
    const opendir = vi.spyOn(fs, 'opendir');
    const run = mockGit().mockRejectedValue(new Error('Git must not run'));

    await expect(resolveProbeBaseDir(source, 'api')).rejects.toThrow(
      /Cannot resolve the source.*Check the source path and filesystem permissions/,
    );
    expect(opendir).not.toHaveBeenCalled();
    expect(run).not.toHaveBeenCalled();
  });
});

describe('shared-source create_probe integration', () => {
  async function probeFixture(watchFlag = 'false') {
    const root = await makeRepo();
    await configure('repo/services/api', 'api');
    await configure('repo/services/worker', 'worker');
    await trackConfigs(root);
    const args = {
      serviceId: 'worker',
      environment: 'production',
      commitSha: 'a'.repeat(40),
      uiFilePath: await write('repo/libs/console.ts'),
      uiLineNumber: 12,
      hitLimit: 1,
    };
    const trpc = {
      listActiveAgents: {
        query: vi
          .fn()
          .mockResolvedValue([
            { environment: args.environment, commitSha: args.commitSha },
          ]),
      },
      createProbe: { mutate: vi.fn().mockResolvedValue({ id: 'probe-id' }) },
    };
    vi.stubEnv('HYPERPROBE_AGENTIC_ENABLED', 'false');
    vi.stubEnv('HYPERPROBE_ALLOW_CONDITIONAL_PROBE', 'false');
    vi.stubEnv('HYPERPROBE_ALLOW_WATCH_EXPR', watchFlag);
    vi.resetModules();
    const { createMcpHandlers } = await import('../src/index.js');
    const { callTool } = createMcpHandlers({
      authManager: {
        getAccessToken: () => 'test-token',
        getLoginUrl: () => null,
      },
      trpc: trpc as unknown as McpRuntime['trpc'],
    });
    return { root, args, trpc, callTool };
  }

  it.each([
    'false',
    'true',
  ])('forwards one root-relative probe to the selected service with watches=%s', async (watchFlag) => {
    const { args, trpc, callTool } = await probeFixture(watchFlag);
    const watchExpressions =
      watchFlag === 'true'
        ? [' request.id ', 'request.id']
        : { ignored: 'even invalid shapes are omitted when disabled' };

    const result = await callTool({
      params: {
        name: 'create_probe',
        arguments: { ...args, watchExpressions },
      },
    });

    expect(result.isError).not.toBe(true);
    expect(trpc.listActiveAgents.query).toHaveBeenCalledExactlyOnceWith({
      serviceIds: ['worker'],
    });
    expect(trpc.createProbe.mutate).toHaveBeenCalledExactlyOnceWith(
      expect.objectContaining({
        ...args,
        uiFilePath: 'libs/console.ts',
        type: 'SNAPSHOT',
      }),
    );
    const payload = trpc.createProbe.mutate.mock.calls[0][0];
    if (watchFlag === 'true') {
      expect(payload.watchExpressions).toEqual(watchExpressions);
    } else {
      expect(payload).not.toHaveProperty('watchExpressions');
    }
  });

  it.each([
    'environment',
    'commitSha',
  ] as const)('preserves the active-agent %s check', async (field) => {
    const { args, trpc, callTool } = await probeFixture();
    const result = await callTool({
      params: {
        name: 'create_probe',
        arguments: {
          ...args,
          [field]: field === 'environment' ? 'staging' : 'b'.repeat(40),
        },
      },
    });

    expect(result.isError).toBe(true);
    expect(result.content[0].text).toContain('no active agents running commit');
    expect(trpc.listActiveAgents.query).toHaveBeenCalledExactlyOnceWith({
      serviceIds: ['worker'],
    });
    expect(trpc.createProbe.mutate).not.toHaveBeenCalled();
  });

  it('preserves backend errors without retries or service fanout', async () => {
    const { args, trpc, callTool } = await probeFixture();
    trpc.createProbe.mutate.mockRejectedValue(new Error('backend unavailable'));

    const result = await callTool({
      params: { name: 'create_probe', arguments: args },
    });

    expect(result.isError).toBe(true);
    expect(result.content[0].text).toBe('Error: backend unavailable');
    expect(trpc.createProbe.mutate).toHaveBeenCalledTimes(1);
    expect(trpc.listActiveAgents.query).toHaveBeenCalledTimes(1);
  });

  it.each([
    'missing',
    'untracked',
  ])('rejects %s shared-source configurations before any backend call', async (configuration) => {
    const { root, args, trpc, callTool } = await probeFixture();
    if (configuration === 'untracked') {
      await git(root, 'rm', '--cached', '--', 'services/worker/.hprc');
    }

    const result = await callTool({
      params: {
        name: 'create_probe',
        arguments: {
          ...args,
          serviceId: configuration === 'missing' ? 'missing' : args.serviceId,
        },
      },
    });

    expect(result.isError).toBe(true);
    expect(result.content[0].text).toMatch(noMatch);
    expect(trpc.listActiveAgents.query).not.toHaveBeenCalled();
    expect(trpc.createProbe.mutate).not.toHaveBeenCalled();
  });
});
