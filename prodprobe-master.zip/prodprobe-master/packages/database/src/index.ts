import { PrismaPg } from '@prisma/adapter-pg';
import pg from 'pg';
import { PrismaClient } from './generated/client/index.js';

let prismaInstance: PrismaClient | null = null;

export function initDatabase(connectionString: string): PrismaClient {
  if (prismaInstance) {
    return prismaInstance;
  }

  if (!connectionString) {
    throw new Error('Database connection string must be provided');
  }

  const pool = new pg.Pool({ connectionString });
  const adapter = new PrismaPg(pool);
  const client = new PrismaClient({
    adapter,
    log: [{ emit: 'event', level: 'query' as const }],
  });

  prismaInstance = client;

  return prismaInstance;
}

export function getDatabase(): PrismaClient {
  if (!prismaInstance) {
    throw new Error(
      'Database has not been initialized. Call initDatabase() first.',
    );
  }
  return prismaInstance;
}

export * from './generated/client/index.js';
