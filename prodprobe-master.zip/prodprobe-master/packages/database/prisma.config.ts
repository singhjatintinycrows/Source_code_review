import { getConfig } from '@hyperprobe/common';
import { defineConfig } from 'prisma/config';

let dbUrl = '';

if (process.env.HP_BUILD_MODE !== 'yes') {
  const config = await getConfig();
  dbUrl = config.databaseUrl;
}

export default defineConfig({
  schema: 'schema.prisma',
  datasource: {
    url: dbUrl,
  },
});
