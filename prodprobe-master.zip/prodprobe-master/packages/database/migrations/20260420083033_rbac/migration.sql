/*
  Warnings:

  - You are about to drop the column `creatorEmail` on the `Service` table. All the data in the column will be lost.
  - You are about to drop the column `name` on the `User` table. All the data in the column will be lost.
  - You are about to drop the `RefreshToken` table. If the table is not empty, all the data it contains will be lost.

*/
-- DropForeignKey
ALTER TABLE "RefreshToken" DROP CONSTRAINT "RefreshToken_userId_fkey";

-- DropIndex
DROP INDEX "Probe_serviceId_environment_status_idx";

-- AlterTable
ALTER TABLE "Service" DROP COLUMN "creatorEmail";

-- AlterTable
ALTER TABLE "User" DROP COLUMN "name",
ADD COLUMN     "permissionVersion" INTEGER NOT NULL DEFAULT 0,
ADD COLUMN     "tokenVersion" INTEGER NOT NULL DEFAULT 0;

-- DropTable
DROP TABLE "RefreshToken";

-- CreateIndex
CREATE INDEX "Probe_serviceId_environment_commitSha_status_idx" ON "Probe"("serviceId", "environment", "commitSha", "status");
