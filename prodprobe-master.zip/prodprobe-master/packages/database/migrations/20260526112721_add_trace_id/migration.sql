ALTER TABLE "LogEvent" ADD COLUMN "traceId" TEXT;

ALTER TABLE "SnapshotEvent" ADD COLUMN "traceId" TEXT;

ALTER TABLE "MetricEvent" ADD COLUMN "traceId" TEXT;
