-- AlterEnum
ALTER TYPE "ProbeStatus" ADD VALUE 'INACTIVE';
