-- CreateEnum
CREATE TYPE "ProbeType" AS ENUM ('SNAPSHOT', 'LOG', 'COUNTER', 'METRIC', 'DURATION');

-- CreateEnum
CREATE TYPE "ProbeStatus" AS ENUM ('ACTIVE', 'EXPIRED', 'COMPLETED', 'ERROR');

-- CreateTable
CREATE TABLE "Service" (
    "id" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "repoName" TEXT NOT NULL,

    CONSTRAINT "Service_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "Probe" (
    "id" TEXT NOT NULL,
    "type" "ProbeType" NOT NULL,
    "serviceId" TEXT NOT NULL,
    "environment" TEXT NOT NULL,
    "status" "ProbeStatus" NOT NULL DEFAULT 'ACTIVE',
    "uiFilePath" TEXT NOT NULL,
    "uiLineNumber" INTEGER NOT NULL,
    "uiColumnNumber" INTEGER,
    "runtimeLocation" TEXT NOT NULL,
    "runtimeLine" INTEGER NOT NULL,
    "runtimeColumn" INTEGER,
    "secondaryUiFilePath" TEXT,
    "secondaryUiLineNumber" INTEGER,
    "secondaryUiColumnNumber" INTEGER,
    "secondaryRuntimeLocation" TEXT,
    "secondaryRuntimeLine" INTEGER,
    "secondaryRuntimeColumn" INTEGER,
    "template" TEXT,
    "metricName" TEXT,
    "metricExpression" TEXT,
    "watchExpressions" TEXT[],
    "correlationExpression" TEXT,
    "hitLimit" INTEGER NOT NULL DEFAULT 1,
    "hitCount" INTEGER NOT NULL DEFAULT 0,
    "expiryTime" BIGINT NOT NULL,
    "condition" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "maxObjectDepth" INTEGER,
    "maxArrayLength" INTEGER,
    "stackFrameDepth" INTEGER,
    "maxObjectProperties" INTEGER,
    "maxStringLength" INTEGER,

    CONSTRAINT "Probe_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "SourceMap" (
    "id" TEXT NOT NULL,
    "serviceId" TEXT NOT NULL,
    "environment" TEXT NOT NULL,
    "commitSha" TEXT NOT NULL,
    "fileName" TEXT NOT NULL,
    "sources" TEXT[],
    "content" JSONB NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "SourceMap_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "SourceMapFile" (
    "id" TEXT NOT NULL,
    "sourceMapId" TEXT NOT NULL,
    "serviceId" TEXT NOT NULL,
    "environment" TEXT NOT NULL,
    "commitSha" TEXT NOT NULL,
    "resolvedPath" TEXT NOT NULL,
    "rawPath" TEXT NOT NULL,

    CONSTRAINT "SourceMapFile_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "SourceMapCommit" (
    "serviceId" TEXT NOT NULL,
    "environment" TEXT NOT NULL,
    "commitSha" TEXT NOT NULL,
    "isComplete" BOOLEAN NOT NULL DEFAULT false,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "SourceMapCommit_pkey" PRIMARY KEY ("serviceId","environment","commitSha")
);

-- CreateTable
CREATE TABLE "SnapshotEvent" (
    "id" TEXT NOT NULL,
    "probeId" TEXT NOT NULL,
    "serviceId" TEXT NOT NULL,
    "capturedAt" TIMESTAMP(3) NOT NULL,
    "agentId" TEXT NOT NULL,
    "payload" JSONB NOT NULL,

    CONSTRAINT "SnapshotEvent_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "LogEvent" (
    "id" TEXT NOT NULL,
    "probeId" TEXT NOT NULL,
    "serviceId" TEXT NOT NULL,
    "capturedAt" TIMESTAMP(3) NOT NULL,
    "agentId" TEXT NOT NULL,
    "message" TEXT NOT NULL,

    CONSTRAINT "LogEvent_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "MetricEvent" (
    "id" TEXT NOT NULL,
    "probeId" TEXT NOT NULL,
    "serviceId" TEXT NOT NULL,
    "capturedAt" TIMESTAMP(3) NOT NULL,
    "agentId" TEXT NOT NULL,
    "value" DOUBLE PRECISION NOT NULL,

    CONSTRAINT "MetricEvent_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE INDEX "Probe_serviceId_environment_status_idx" ON "Probe"("serviceId", "environment", "status");

-- CreateIndex
CREATE INDEX "SourceMap_serviceId_environment_commitSha_idx" ON "SourceMap"("serviceId", "environment", "commitSha");

-- CreateIndex
CREATE UNIQUE INDEX "SourceMap_serviceId_environment_commitSha_fileName_key" ON "SourceMap"("serviceId", "environment", "commitSha", "fileName");

-- CreateIndex
CREATE INDEX "SourceMapFile_sourceMapId_idx" ON "SourceMapFile"("sourceMapId");

-- CreateIndex
CREATE UNIQUE INDEX "SourceMapFile_serviceId_environment_commitSha_resolvedPath_key" ON "SourceMapFile"("serviceId", "environment", "commitSha", "resolvedPath");

-- CreateIndex
CREATE INDEX "SnapshotEvent_probeId_idx" ON "SnapshotEvent"("probeId");

-- CreateIndex
CREATE INDEX "SnapshotEvent_serviceId_idx" ON "SnapshotEvent"("serviceId");

-- CreateIndex
CREATE INDEX "SnapshotEvent_capturedAt_idx" ON "SnapshotEvent"("capturedAt");

-- CreateIndex
CREATE INDEX "LogEvent_probeId_idx" ON "LogEvent"("probeId");

-- CreateIndex
CREATE INDEX "LogEvent_serviceId_idx" ON "LogEvent"("serviceId");

-- CreateIndex
CREATE INDEX "LogEvent_capturedAt_idx" ON "LogEvent"("capturedAt");

-- CreateIndex
CREATE INDEX "MetricEvent_probeId_idx" ON "MetricEvent"("probeId");

-- CreateIndex
CREATE INDEX "MetricEvent_serviceId_idx" ON "MetricEvent"("serviceId");

-- CreateIndex
CREATE INDEX "MetricEvent_capturedAt_idx" ON "MetricEvent"("capturedAt");

-- AddForeignKey
ALTER TABLE "Probe" ADD CONSTRAINT "Probe_serviceId_fkey" FOREIGN KEY ("serviceId") REFERENCES "Service"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "SourceMap" ADD CONSTRAINT "SourceMap_serviceId_fkey" FOREIGN KEY ("serviceId") REFERENCES "Service"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "SourceMapFile" ADD CONSTRAINT "SourceMapFile_sourceMapId_fkey" FOREIGN KEY ("sourceMapId") REFERENCES "SourceMap"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "SourceMapFile" ADD CONSTRAINT "SourceMapFile_serviceId_fkey" FOREIGN KEY ("serviceId") REFERENCES "Service"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "SourceMapCommit" ADD CONSTRAINT "SourceMapCommit_serviceId_fkey" FOREIGN KEY ("serviceId") REFERENCES "Service"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "SnapshotEvent" ADD CONSTRAINT "SnapshotEvent_probeId_fkey" FOREIGN KEY ("probeId") REFERENCES "Probe"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "SnapshotEvent" ADD CONSTRAINT "SnapshotEvent_serviceId_fkey" FOREIGN KEY ("serviceId") REFERENCES "Service"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "LogEvent" ADD CONSTRAINT "LogEvent_probeId_fkey" FOREIGN KEY ("probeId") REFERENCES "Probe"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "LogEvent" ADD CONSTRAINT "LogEvent_serviceId_fkey" FOREIGN KEY ("serviceId") REFERENCES "Service"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "MetricEvent" ADD CONSTRAINT "MetricEvent_probeId_fkey" FOREIGN KEY ("probeId") REFERENCES "Probe"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "MetricEvent" ADD CONSTRAINT "MetricEvent_serviceId_fkey" FOREIGN KEY ("serviceId") REFERENCES "Service"("id") ON DELETE CASCADE ON UPDATE CASCADE;
