-- CreateEnum
CREATE TYPE "ObservabilityProvider" AS ENUM ('SENTRY');

-- CreateEnum
CREATE TYPE "ObservabilitySignal" AS ENUM ('ERRORS', 'LOGS', 'TRACES', 'METRICS', 'ALERTS');

-- CreateEnum
CREATE TYPE "ObservabilityEvidenceAuditOutcome" AS ENUM ('SUCCESS', 'PARTIAL', 'FAILURE');

-- CreateTable
CREATE TABLE "ObservabilityConnection" (
    "id" TEXT NOT NULL,
    "serviceId" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "provider" "ObservabilityProvider" NOT NULL,
    "publicConfig" JSONB NOT NULL,
    "configVersion" INTEGER NOT NULL DEFAULT 1,
    "credentialCiphertext" BYTEA NOT NULL,
    "credentialNonce" BYTEA NOT NULL,
    "credentialAuthTag" BYTEA NOT NULL,
    "credentialKeyVersion" TEXT NOT NULL,
    "credentialFormat" TEXT NOT NULL,
    "enabled" BOOLEAN NOT NULL DEFAULT false,
    "createdBy" TEXT NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "ObservabilityConnection_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "ObservabilityCapabilityBinding" (
    "id" TEXT NOT NULL,
    "serviceId" TEXT NOT NULL,
    "signal" "ObservabilitySignal" NOT NULL,
    "connectionId" TEXT NOT NULL,
    "selectorKey" TEXT NOT NULL,
    "scopeSelector" JSONB NOT NULL,
    "priority" INTEGER NOT NULL DEFAULT 100,
    "enabled" BOOLEAN NOT NULL DEFAULT true,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "ObservabilityCapabilityBinding_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "ObservabilityEvidenceAuditEvent" (
    "id" TEXT NOT NULL,
    "serviceId" TEXT NOT NULL,
    "connectionId" TEXT NOT NULL,
    "connectionName" TEXT NOT NULL,
    "provider" "ObservabilityProvider" NOT NULL,
    "actorId" TEXT,
    "signal" "ObservabilitySignal" NOT NULL,
    "purpose" TEXT,
    "queryFingerprint" TEXT NOT NULL,
    "timeRangeStart" TIMESTAMP(3),
    "timeRangeEnd" TIMESTAMP(3),
    "resultCount" INTEGER NOT NULL DEFAULT 0,
    "redactionCount" INTEGER NOT NULL DEFAULT 0,
    "outcome" "ObservabilityEvidenceAuditOutcome" NOT NULL,
    "sourceFailures" INTEGER NOT NULL DEFAULT 0,
    "startedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "completedAt" TIMESTAMP(3),

    CONSTRAINT "ObservabilityEvidenceAuditEvent_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE UNIQUE INDEX "ObservabilityConnection_id_serviceId_key" ON "ObservabilityConnection"("id", "serviceId");
CREATE UNIQUE INDEX "ObservabilityConnection_serviceId_name_key" ON "ObservabilityConnection"("serviceId", "name");
CREATE INDEX "ObservabilityConnection_serviceId_provider_enabled_idx" ON "ObservabilityConnection"("serviceId", "provider", "enabled");
CREATE UNIQUE INDEX "ObservabilityCapabilityBinding_serviceId_signal_connectionId_selectorKey_key" ON "ObservabilityCapabilityBinding"("serviceId", "signal", "connectionId", "selectorKey");
CREATE INDEX "ObservabilityCapabilityBinding_serviceId_signal_enabled_priority_idx" ON "ObservabilityCapabilityBinding"("serviceId", "signal", "enabled", "priority");
CREATE INDEX "ObservabilityCapabilityBinding_connectionId_serviceId_idx" ON "ObservabilityCapabilityBinding"("connectionId", "serviceId");
CREATE INDEX "ObservabilityEvidenceAuditEvent_serviceId_startedAt_idx" ON "ObservabilityEvidenceAuditEvent"("serviceId", "startedAt" DESC);
CREATE INDEX "ObservabilityEvidenceAuditEvent_connectionId_startedAt_idx" ON "ObservabilityEvidenceAuditEvent"("connectionId", "startedAt" DESC);

-- AddForeignKey
ALTER TABLE "ObservabilityConnection" ADD CONSTRAINT "ObservabilityConnection_serviceId_fkey" FOREIGN KEY ("serviceId") REFERENCES "Service"("id") ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE "ObservabilityCapabilityBinding" ADD CONSTRAINT "ObservabilityCapabilityBinding_serviceId_fkey" FOREIGN KEY ("serviceId") REFERENCES "Service"("id") ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE "ObservabilityCapabilityBinding" ADD CONSTRAINT "ObservabilityCapabilityBinding_connectionId_serviceId_fkey" FOREIGN KEY ("connectionId", "serviceId") REFERENCES "ObservabilityConnection"("id", "serviceId") ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE "ObservabilityEvidenceAuditEvent" ADD CONSTRAINT "ObservabilityEvidenceAuditEvent_serviceId_fkey" FOREIGN KEY ("serviceId") REFERENCES "Service"("id") ON DELETE CASCADE ON UPDATE CASCADE;
