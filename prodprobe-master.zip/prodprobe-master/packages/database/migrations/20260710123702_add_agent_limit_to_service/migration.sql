-- AlterTable
ALTER TABLE "Service" ADD COLUMN     "agentLimit" INTEGER;
