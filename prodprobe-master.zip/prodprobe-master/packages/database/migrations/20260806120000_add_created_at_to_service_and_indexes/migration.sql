ALTER TABLE "Service" ADD COLUMN "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP;

-- DropIndex
DROP INDEX "User_createdAt_idx";

-- CreateIndex
CREATE INDEX "Service_createdAt_id_idx" ON "Service"("createdAt" DESC, "id" DESC);

-- CreateIndex
CREATE INDEX "Team_createdAt_id_idx" ON "Team"("createdAt" DESC, "id" DESC);

-- CreateIndex
CREATE INDEX "User_createdAt_id_idx" ON "User"("createdAt" DESC, "id" DESC);
