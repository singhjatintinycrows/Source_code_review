/*
  Warnings:

  - You are about to drop the column `repoName` on the `Service` table. All the data in the column will be lost.
  - Added the required column `commitSha` to the `Probe` table without a default value. This is not possible if the table is not empty.

*/
-- AlterTable
ALTER TABLE "Probe" ADD COLUMN     "commitSha" TEXT NOT NULL;

-- AlterTable
ALTER TABLE "Service" DROP COLUMN "repoName";
