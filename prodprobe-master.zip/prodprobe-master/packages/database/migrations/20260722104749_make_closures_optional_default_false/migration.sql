-- AlterTable
ALTER TABLE "Probe" ADD COLUMN     "captureClosures" BOOLEAN NOT NULL DEFAULT false;

-- Migrate existing SNAPSHOT probes to have captureClosures as true
UPDATE "Probe" SET "captureClosures" = true WHERE "type" = 'SNAPSHOT';
