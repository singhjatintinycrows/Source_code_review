-- AlterTable
ALTER TABLE "Probe" ADD COLUMN "createdBy" TEXT NOT NULL DEFAULT 'you@example.com';

ALTER TABLE "Probe" ALTER COLUMN "createdBy" DROP DEFAULT;
