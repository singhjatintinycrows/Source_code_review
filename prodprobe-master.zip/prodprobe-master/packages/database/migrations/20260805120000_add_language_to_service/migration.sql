CREATE TYPE "ServiceLanguage" AS ENUM ('JAVA', 'NODE', 'PYTHON');

ALTER TABLE "Service" ADD COLUMN "language" "ServiceLanguage" NOT NULL DEFAULT 'NODE';
