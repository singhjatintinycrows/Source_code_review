-- DropIndex
DROP INDEX "Probe_serviceId_environment_status_idx";

-- CreateIndex
CREATE INDEX "Probe_serviceId_environment_commitSha_status_idx" ON "Probe"("serviceId", "environment", "commitSha", "status");
