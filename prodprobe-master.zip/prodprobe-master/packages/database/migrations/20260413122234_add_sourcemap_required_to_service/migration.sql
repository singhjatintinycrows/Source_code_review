-- AlterTable
ALTER TABLE "Service" ADD COLUMN "sourceMapRequired" BOOLEAN NOT NULL DEFAULT false;
