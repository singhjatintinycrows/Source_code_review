-- Advanced routing is intentionally replaced by one selected connection per capability.
DELETE FROM "ObservabilityCapabilityBinding";

DROP INDEX "ObservabilityCapabilityBinding_serviceId_signal_connectionId_selectorKey_key";
DROP INDEX "ObservabilityCapabilityBinding_serviceId_signal_enabled_priority_idx";

ALTER TABLE "ObservabilityCapabilityBinding"
  DROP COLUMN "selectorKey",
  DROP COLUMN "scopeSelector",
  DROP COLUMN "priority",
  DROP COLUMN "enabled";

CREATE UNIQUE INDEX "ObservabilityCapabilityBinding_serviceId_signal_key"
  ON "ObservabilityCapabilityBinding"("serviceId", "signal");
