-- DropIndex
DROP INDEX "Probe_serviceId_environment_commitSha_status_idx";

-- AlterTable
ALTER TABLE "Service" ADD COLUMN     "creatorEmail" TEXT;

-- CreateTable
CREATE TABLE "User" (
    "id" TEXT NOT NULL,
    "email" TEXT NOT NULL,
    "name" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "User_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "Team" (
    "id" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "isAdminTeam" BOOLEAN NOT NULL DEFAULT false,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "Team_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "UserTeam" (
    "userId" TEXT NOT NULL,
    "teamId" TEXT NOT NULL,

    CONSTRAINT "UserTeam_pkey" PRIMARY KEY ("userId","teamId")
);

-- CreateTable
CREATE TABLE "TeamService" (
    "teamId" TEXT NOT NULL,
    "serviceId" TEXT NOT NULL,
    "role" INTEGER NOT NULL,

    CONSTRAINT "TeamService_pkey" PRIMARY KEY ("teamId","serviceId")
);

-- CreateTable
CREATE TABLE "AuditLog" (
    "id" TEXT NOT NULL,
    "actorEmail" TEXT NOT NULL,
    "action" TEXT NOT NULL,
    "entityType" TEXT NOT NULL,
    "entityId" TEXT NOT NULL,
    "oldData" JSONB,
    "newData" JSONB,
    "ipAddress" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "AuditLog_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE UNIQUE INDEX "User_email_key" ON "User"("email");

-- CreateIndex
CREATE UNIQUE INDEX "Team_name_key" ON "Team"("name");

-- CreateIndex
CREATE INDEX "UserTeam_userId_idx" ON "UserTeam"("userId");

-- CreateIndex
CREATE INDEX "UserTeam_teamId_idx" ON "UserTeam"("teamId");

-- CreateIndex
CREATE INDEX "TeamService_teamId_idx" ON "TeamService"("teamId");

-- CreateIndex
CREATE INDEX "TeamService_serviceId_idx" ON "TeamService"("serviceId");

-- CreateIndex
CREATE INDEX "AuditLog_entityType_entityId_idx" ON "AuditLog"("entityType", "entityId");

-- CreateIndex
CREATE INDEX "AuditLog_actorEmail_idx" ON "AuditLog"("actorEmail");

-- CreateIndex
CREATE INDEX "AuditLog_createdAt_idx" ON "AuditLog"("createdAt");

-- CreateIndex
CREATE INDEX "Probe_serviceId_environment_status_idx" ON "Probe"("serviceId", "environment", "status");

-- AddForeignKey
ALTER TABLE "UserTeam" ADD CONSTRAINT "UserTeam_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "UserTeam" ADD CONSTRAINT "UserTeam_teamId_fkey" FOREIGN KEY ("teamId") REFERENCES "Team"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "TeamService" ADD CONSTRAINT "TeamService_teamId_fkey" FOREIGN KEY ("teamId") REFERENCES "Team"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "TeamService" ADD CONSTRAINT "TeamService_serviceId_fkey" FOREIGN KEY ("serviceId") REFERENCES "Service"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- 1. Prevent the Admin Team from being deleted entirely
CREATE OR REPLACE FUNCTION protect_admin_team() RETURNS TRIGGER AS $$
BEGIN
    IF OLD."isAdminTeam" = true THEN
        RAISE EXCEPTION 'The global admin team cannot be deleted.';
    END IF;
    RETURN OLD;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER prevent_admin_team_deletion
BEFORE DELETE ON "Team"
FOR EACH ROW EXECUTE FUNCTION protect_admin_team();


-- 2. Prevent the Admin Team from being explicitly mapped to a Service
CREATE OR REPLACE FUNCTION prevent_admin_team_service_mapping() RETURNS TRIGGER AS $$
BEGIN
    IF EXISTS (SELECT 1 FROM "Team" WHERE id = NEW."teamId" AND "isAdminTeam" = true) THEN
        RAISE EXCEPTION 'The global admin team inherently has access to all services and cannot be explicitly mapped.';
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER enforce_admin_team_mapping_rule
BEFORE INSERT OR UPDATE ON "TeamService"
FOR EACH ROW EXECUTE FUNCTION prevent_admin_team_service_mapping();


-- 3. Ensure a user always belongs to at least one team
CREATE OR REPLACE FUNCTION check_user_team_removal() RETURNS TRIGGER AS $$
BEGIN
    -- Only check if this is a direct delete (not a cascade from deleting the User)
    IF pg_trigger_depth() = 0 THEN
        IF NOT EXISTS (
            SELECT 1 FROM "UserTeam"
            WHERE "userId" = OLD."userId" AND "teamId" != OLD."teamId"
        ) THEN
            RAISE EXCEPTION 'Cannot remove user from team: A user must belong to at least one team.';
        END IF;
    END IF;
    RETURN OLD;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER prevent_user_team_removal
BEFORE DELETE ON "UserTeam"
FOR EACH ROW EXECUTE FUNCTION check_user_team_removal();


-- 4. Ensure the Admin Team always has at least one member
CREATE OR REPLACE FUNCTION protect_last_admin() RETURNS TRIGGER AS $$
BEGIN
    -- Only check if this is a direct delete
    IF pg_trigger_depth() = 0 THEN
        IF EXISTS (SELECT 1 FROM "Team" WHERE id = OLD."teamId" AND "isAdminTeam" = true) THEN
            IF (SELECT COUNT(*) FROM "UserTeam" WHERE "teamId" = OLD."teamId") <= 1 THEN
                RAISE EXCEPTION 'Cannot remove the last user from the Admin team.';
            END IF;
        END IF;
    END IF;
    RETURN OLD;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER prevent_last_admin_removal
BEFORE DELETE ON "UserTeam"
FOR EACH ROW EXECUTE FUNCTION protect_last_admin();


-- 5. Ensure a service always has at least one team associated with it
CREATE OR REPLACE FUNCTION check_service_team_removal() RETURNS TRIGGER AS $$
BEGIN
    -- Only check if this is a direct delete (not a cascade from deleting the Service)
    IF pg_trigger_depth() = 0 THEN
        IF NOT EXISTS (
            SELECT 1 FROM "TeamService"
            WHERE "serviceId" = OLD."serviceId" AND "teamId" != OLD."teamId"
        ) THEN
            RAISE EXCEPTION 'Cannot remove team from service: A service must be associated with at least one team.';
        END IF;
    END IF;
    RETURN OLD;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER prevent_service_team_removal
BEFORE DELETE ON "TeamService"
FOR EACH ROW EXECUTE FUNCTION check_service_team_removal();


-- 6. Ensure team deletion doesn't leave users orphaned (without any team)
CREATE OR REPLACE FUNCTION check_team_deletion() RETURNS TRIGGER AS $$
BEGIN
    IF EXISTS (
        SELECT 1 FROM "UserTeam" ut
        WHERE ut."teamId" = OLD.id
        AND NOT EXISTS (
            SELECT 1 FROM "UserTeam" ut2
            WHERE ut2."userId" = ut."userId" AND ut2."teamId" != OLD.id
        )
    ) THEN
        RAISE EXCEPTION 'Cannot delete team: One or more users would be left without any team.';
    END IF;
    RETURN OLD;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER prevent_team_deletion
BEFORE DELETE ON "Team"
FOR EACH ROW EXECUTE FUNCTION check_team_deletion();
