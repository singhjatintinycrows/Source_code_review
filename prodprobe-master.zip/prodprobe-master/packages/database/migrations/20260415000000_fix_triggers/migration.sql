-- 3. Ensure a user always belongs to at least one team
CREATE OR REPLACE FUNCTION check_user_team_removal() RETURNS TRIGGER AS $$
BEGIN
    -- Only block direct UserTeam removal. Cascade deletes from User will have depth > 1.
    IF pg_trigger_depth() = 1 THEN
        IF NOT EXISTS (
            SELECT 1 FROM "UserTeam"
            WHERE "userId" = OLD."userId" AND "teamId" != OLD."teamId"
        ) THEN
            RAISE EXCEPTION 'Cannot remove user from team: A user must belong to at least one team.';
        END IF;
    END IF;
    RETURN OLD;
END;
$$ LANGUAGE plpgsql;

-- 4. Ensure the Admin Team always has at least one member
CREATE OR REPLACE FUNCTION protect_last_admin() RETURNS TRIGGER AS $$
BEGIN
    -- Protect the last admin from ANY deletion (including User.delete, which is depth > 1)
    IF EXISTS (SELECT 1 FROM "Team" WHERE id = OLD."teamId" AND "isAdminTeam" = true) THEN
        IF (SELECT COUNT(*) FROM "UserTeam" WHERE "teamId" = OLD."teamId") <= 1 THEN
            RAISE EXCEPTION 'Cannot remove the last user from the Admin team.';
        END IF;
    END IF;
    RETURN OLD;
END;
$$ LANGUAGE plpgsql;

-- 5. Ensure a service always has at least one team associated with it
CREATE OR REPLACE FUNCTION check_service_team_removal() RETURNS TRIGGER AS $$
BEGIN
    -- Only block direct TeamService removal. Cascade deletes from Service will have depth > 1.
    IF pg_trigger_depth() = 1 THEN
        IF NOT EXISTS (
            SELECT 1 FROM "TeamService"
            WHERE "serviceId" = OLD."serviceId" AND "teamId" != OLD."teamId"
        ) THEN
            RAISE EXCEPTION 'Cannot remove team from service: A service must be associated with at least one team.';
        END IF;
    END IF;
    RETURN OLD;
END;
$$ LANGUAGE plpgsql;
