-- Legacy Sentry connections lack the required stable project ID. Their encrypted
-- credentials prevent resolving slug-only configurations during SQL migration.
-- Deleting these rows also cascades their capability assignments.
DELETE FROM "ObservabilityConnection"
WHERE "provider" = 'SENTRY'::"ObservabilityProvider"
  AND (
    NOT ("publicConfig" ? 'projectId')
    OR jsonb_typeof("publicConfig" -> 'projectId') <> 'string'
    OR NOT ("publicConfig" ->> 'projectId' ~ '^[0-9]{1,32}$')
  );
