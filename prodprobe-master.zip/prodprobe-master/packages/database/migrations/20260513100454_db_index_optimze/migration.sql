-- DropIndex
DROP INDEX "LogEvent_capturedAt_idx";

-- DropIndex
DROP INDEX "LogEvent_probeId_idx";

-- DropIndex
DROP INDEX "MetricEvent_capturedAt_idx";

-- DropIndex
DROP INDEX "MetricEvent_probeId_idx";

-- DropIndex
DROP INDEX "SnapshotEvent_capturedAt_idx";

-- DropIndex
DROP INDEX "SnapshotEvent_probeId_idx";

-- DropIndex
DROP INDEX "SourceMap_serviceId_environment_commitSha_idx";

-- DropIndex
DROP INDEX "TeamService_teamId_idx";

-- DropIndex
DROP INDEX "UserTeam_userId_idx";

-- CreateIndex
CREATE INDEX "LogEvent_probeId_capturedAt_idx" ON "LogEvent"("probeId", "capturedAt" DESC);

-- CreateIndex
CREATE INDEX "MetricEvent_probeId_capturedAt_idx" ON "MetricEvent"("probeId", "capturedAt" DESC);

-- CreateIndex
CREATE INDEX "Probe_status_expiryTime_idx" ON "Probe"("status", "expiryTime" DESC);

-- CreateIndex
CREATE INDEX "Probe_serviceId_createdAt_idx" ON "Probe"("serviceId", "createdAt" DESC);

-- CreateIndex
CREATE INDEX "SnapshotEvent_probeId_capturedAt_idx" ON "SnapshotEvent"("probeId", "capturedAt" DESC);

-- CreateIndex
CREATE INDEX "SourceMapCommit_serviceId_environment_isComplete_createdAt_idx" ON "SourceMapCommit"("serviceId", "environment", "isComplete", "createdAt" DESC);

-- CreateIndex
CREATE INDEX "Team_isAdminTeam_idx" ON "Team"("isAdminTeam");

-- CreateIndex
CREATE INDEX "User_createdAt_idx" ON "User"("createdAt" DESC);
