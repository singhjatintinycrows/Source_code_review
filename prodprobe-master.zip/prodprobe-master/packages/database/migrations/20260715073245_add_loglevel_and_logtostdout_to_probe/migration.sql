-- AlterTable
ALTER TABLE "Probe"
ADD COLUMN "logLevel" TEXT,
ADD COLUMN "shouldLogToStdout" BOOLEAN NOT NULL DEFAULT false;