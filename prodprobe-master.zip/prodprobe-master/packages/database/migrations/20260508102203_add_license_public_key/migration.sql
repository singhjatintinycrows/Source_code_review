-- AlterTable
ALTER TABLE "SystemConfig" ADD COLUMN     "licensePublicKey" TEXT;
