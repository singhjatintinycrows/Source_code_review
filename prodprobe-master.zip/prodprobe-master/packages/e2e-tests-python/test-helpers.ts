import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { getConfig } from '@hyperprobe/common';
import { createTRPCProxyClient, httpBatchLink } from '@trpc/client';
import type { AppRouter } from 'backend';
import { type ExecaChildProcess, execa } from 'execa';
import { createClient } from 'redis';
import superjson from 'superjson';
import waitOn from 'wait-on';
import { getAdminToken } from './auth-helper.js';
import { getDatabase } from './database.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
export const ROOT = path.resolve(__dirname, '../..');
const PYTHON_DEMO_DIR = path.resolve(ROOT, 'agents/python-demo-app');
const PYTHON_DEMO_FILE = path.resolve(PYTHON_DEMO_DIR, 'app.py');

export const PYTHON_EXECUTABLE = process.env.HYPERPROBE_E2E_PYTHON || 'python3';

export const trpc = createTRPCProxyClient<AppRouter>({
  transformer: superjson,
  links: [
    httpBatchLink({
      url: 'http://localhost:4001/trpc',
      async headers() {
        const token = await getAdminToken();
        return { Authorization: `Bearer ${token}` };
      },
    }),
  ],
});

export const DEMO_LINES = {
  durationStart: markerLine('HP_E2E_DURATION_START'),
  item: markerLine('HP_E2E_ITEM'),
  snapshotAndDurationEnd: markerLine('HP_E2E_SNAPSHOT_AND_DURATION_END'),
} as const;

export const DEMO_FILE = 'agents/python-demo-app/app.py';

export interface PythonDemoApp {
  process: ExecaChildProcess<string>;
}

export async function resetE2EState(serviceId: string, serviceName: string) {
  const database = getDatabase();
  await database.logEvent.deleteMany();
  await database.snapshotEvent.deleteMany();
  await database.metricEvent.deleteMany();
  await database.probe.deleteMany();
  await database.sourceMap.deleteMany();
  await database.service.deleteMany();

  await database.service.create({
    data: {
      id: serviceId,
      name: serviceName,
      sourceMapRequired: false,
    },
  });

  const config = await getConfig();
  const redis = createClient({ url: config.redisUrl });
  await redis.connect();
  await redis.flushDb();
  await redis.quit();
}

export async function startPythonDemoApp(options: {
  serviceId: string;
  commitSha: string;
  port: number;
}) {
  const sdkPath = path.resolve(ROOT, 'agents/python-sdk');
  const pythonPath = [sdkPath, process.env.PYTHONPATH]
    .filter(Boolean)
    .join(path.delimiter);

  const demoProcess = execa(PYTHON_EXECUTABLE, ['app.py'], {
    cwd: PYTHON_DEMO_DIR,
    reject: false,
    env: {
      ...process.env,
      PYTHONPATH: pythonPath,
      PORT: String(options.port),
      HYPERPROBE_SERVICE_ID: options.serviceId,
      HYPERPROBE_ENVIRONMENT: 'development',
      HYPERPROBE_BROKER_URL: 'localhost:60051',
      HYPERPROBE_FORK_MODE: 'none',
      HYPERPROBE_SYNC_INTERVAL_MS: '1000',
      HYPERPROBE_FLUSH_INTERVAL_MS: '250',
      HYPERPROBE_PENDING_PROBE_TIMEOUT_SEC: '30',
      HYPERPROBE_TRACE_HOOK: 'tracer:get_trace_id',
      GIT_COMMIT: options.commitSha,
    },
  });

  demoProcess.stdout?.pipe(process.stdout);
  demoProcess.stderr?.pipe(process.stderr);

  try {
    await waitOn({
      resources: [`http-get://127.0.0.1:${options.port}/health`],
      interval: 250,
      timeout: 20000,
    });
  } catch (error) {
    await stopPythonDemoApp({ process: demoProcess });
    throw error;
  }

  return { process: demoProcess };
}

export async function stopPythonDemoApp(demoApp: PythonDemoApp | undefined) {
  const demoProcess = demoApp?.process;
  if (!demoProcess || demoProcess.exitCode !== null) return;
  demoProcess.kill('SIGTERM', { forceKillAfterTimeout: 5000 });
  await demoProcess;
}

export async function waitForProbesToBeLive(probeIds: string[]) {
  const config = await getConfig();
  const redis = createClient({ url: config.redisUrl });
  await redis.connect();
  try {
    await pollUntil(
      `probes ${probeIds.join(', ')} to become live`,
      () => redis.mGet(probeIds.map((id) => `probe:live:${id}`)),
      (values) => values.every((value) => value === '1'),
      20000,
    );
  } finally {
    await redis.quit();
  }
}

export async function waitForAgentHeartbeatAfter(
  serviceId: string,
  minimumTimestamp: number,
) {
  const config = await getConfig();
  const redis = createClient({ url: config.redisUrl });
  await redis.connect();
  try {
    await pollUntil(
      `an agent heartbeat after ${minimumTimestamp}`,
      () => redis.zRangeWithScores(`active_agents:${serviceId}`, 0, -1),
      (entries) =>
        entries.some((entry) => Number(entry.score) > minimumTimestamp),
      10000,
    );
  } finally {
    await redis.quit();
  }
}

export async function pollRows<T>(
  description: string,
  read: () => Promise<T[]>,
  minimumCount: number,
) {
  return pollUntil(
    description,
    read,
    (rows) => rows.length >= minimumCount,
    30000,
  );
}

export async function assertRowCountRemains(
  description: string,
  readCount: () => Promise<number>,
  expectedCount: number,
  durationMs = 2500,
) {
  const deadline = Date.now() + durationMs;
  while (Date.now() < deadline) {
    const count = await readCount();
    if (count !== expectedCount) {
      throw new Error(
        `${description}: expected ${expectedCount} rows, found ${count}`,
      );
    }
    await new Promise((resolve) => setTimeout(resolve, 200));
  }
}

export async function pollUntil<T>(
  description: string,
  read: () => Promise<T>,
  predicate: (value: T) => boolean,
  timeoutMs: number,
  intervalMs = 250,
): Promise<T> {
  const deadline = Date.now() + timeoutMs;
  let latest = await read();
  while (!predicate(latest) && Date.now() < deadline) {
    await new Promise((resolve) => setTimeout(resolve, intervalMs));
    latest = await read();
  }
  if (!predicate(latest)) {
    throw new Error(`Timed out waiting for ${description}`);
  }
  return latest;
}

function markerLine(marker: string) {
  const lines = fs.readFileSync(PYTHON_DEMO_FILE, 'utf8').split(/\r?\n/);
  const index = lines.findIndex((line) => line.includes(marker));
  if (index === -1) {
    throw new Error(`Missing Python E2E source marker: ${marker}`);
  }
  return index + 1;
}
