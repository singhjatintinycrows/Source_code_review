process.env.HYPERPROBE_ENV = 'e2e';

import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { getConfig } from '@hyperprobe/common';
import { NATS_TELEMETRY_STREAM } from '@hyperprobe/constants';
import { type ExecaChildProcess, execa } from 'execa';
import { connect } from 'nats';
import { createClient } from 'redis';
import waitOn from 'wait-on';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(__dirname, '../..');
const PYTHON_EXECUTABLE = process.env.HYPERPROBE_E2E_PYTHON || 'python3';
const services: ExecaChildProcess<string>[] = [];

export default async function setup() {
  console.log('Global Setup: Starting Python SDK E2E services...');

  await execa(
    PYTHON_EXECUTABLE,
    [
      '-c',
      [
        'import sys',
        'assert sys.version_info >= (3, 12), "Python 3.12+ is required"',
        'assert hasattr(sys, "monitoring"), "sys.monitoring is required"',
        'import fastapi, uvicorn, grpc, google.protobuf',
      ].join('; '),
    ],
    { cwd: ROOT },
  );

  const config = await getConfig();

  console.log('Building services required by the Python E2E suite...');
  await execa(
    'pnpm',
    [
      'nx',
      'run-many',
      '--target=build',
      '--projects=@hyperprobe/constants,@hyperprobe/common,@hyperprobe/protos,@hyperprobe/database,logger,logger-consumer',
      '--parallel=6',
      '--output-style=static',
    ],
    { cwd: ROOT, stdio: 'inherit' },
  );

  // The backend's full build also packages the Nuxt dashboard. The E2E suite
  // only starts the API server, so building that bundle would be unrelated work.
  await fs.rm(path.resolve(ROOT, 'apps/backend/dist'), {
    recursive: true,
    force: true,
  });
  await execa('pnpm', ['--filter', 'backend', 'run', 'build:cjs'], {
    cwd: ROOT,
    stdio: 'inherit',
  });

  const { initDatabase } = await import('./database.js');
  const prisma = initDatabase(config.databaseUrl);

  console.log('Provisioning e2e-db schema...');
  await execa('pnpm', ['prisma', 'db', 'push', '--accept-data-loss'], {
    cwd: path.resolve(ROOT, 'packages/database'),
    env: { ...process.env, HP_DB_URL: config.databaseUrl },
  });

  console.log('Resetting database...');
  await prisma.logEvent.deleteMany();
  await prisma.snapshotEvent.deleteMany();
  await prisma.metricEvent.deleteMany();
  await prisma.probe.deleteMany();
  await prisma.service.deleteMany();

  console.log('Resetting NATS...');
  try {
    const nc = await connect({ servers: config.natsUrl });
    const manager = await nc.jetstreamManager();
    await manager.streams.delete(NATS_TELEMETRY_STREAM);
    await nc.close();
  } catch (_error) {
    // The stream may not exist before the first E2E run.
  }

  console.log('Resetting Redis...');
  const redis = createClient({ url: config.redisUrl });
  await redis.connect();
  await redis.flushDb();
  await redis.quit();

  const startService = (dir: string, env: NodeJS.ProcessEnv = {}) => {
    const service = execa('node', ['dist/index.cjs'], {
      cwd: path.resolve(ROOT, dir),
      env: {
        ...process.env,
        HYPERPROBE_ENV: 'e2e',
        ...env,
      },
    });
    service.stdout?.pipe(process.stdout);
    service.stderr?.pipe(process.stderr);
    return service;
  };

  services.push(startService('apps/backend', { HTTP_PORT: '4001' }));
  services.push(
    startService('apps/logger', {
      GRPC_PORT: '60051',
      HYPERPROBE_SYNC_INTERVAL_MS: '1000',
      HYPERPROBE_REDACT_KEYS: 'password,userId,user_id',
    }),
  );
  services.push(startService('apps/logger-consumer'));

  await waitOn({
    resources: ['tcp:localhost:4001', 'tcp:localhost:60051'],
    timeout: 30000,
  });

  await new Promise((resolve) => setTimeout(resolve, 2000));
  const { ensureAdminUser } = await import('./auth-helper.js');
  await ensureAdminUser();

  return async () => {
    console.log('Global Teardown: Shutting down Python SDK E2E services...');
    for (const service of services) {
      service.kill('SIGTERM', { forceKillAfterTimeout: 5000 });
    }
    await Promise.allSettled(services);
  };
}
