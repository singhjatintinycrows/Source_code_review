import { afterAll, beforeAll, expect, test } from 'vitest';
import { getDatabase, ProbeStatus, ProbeType } from './database.js';
import {
  assertRowCountRemains,
  DEMO_FILE,
  DEMO_LINES,
  type PythonDemoApp,
  pollRows,
  resetE2EState,
  startPythonDemoApp,
  stopPythonDemoApp,
  trpc,
  waitForAgentHeartbeatAfter,
  waitForProbesToBeLive,
} from './test-helpers.js';

const SERVICE_ID = '00000000-0000-4000-8000-000000000105';
const COMMIT_SHA = 'python-e2e-retirement-sha';
const PORT = 4105;

let demoApp: PythonDemoApp | undefined;

beforeAll(async () => {
  await resetE2EState(SERVICE_ID, 'python-demo-app-retirement');
  demoApp = await startPythonDemoApp({
    serviceId: SERVICE_ID,
    commitSha: COMMIT_SHA,
    port: PORT,
  });
});

afterAll(async () => {
  await stopPythonDemoApp(demoApp);
});

test('E2E Python Retirement Verification', async () => {
  const logProbe = await trpc.createProbe.mutate({
    commitSha: COMMIT_SHA,
    type: ProbeType.LOG,
    serviceId: SERVICE_ID,
    environment: 'development',
    uiFilePath: DEMO_FILE,
    uiLineNumber: DEMO_LINES.item,
    // biome-ignore lint/suspicious/noTemplateCurlyInString: SDK log-template syntax
    template: 'Retirement Check: ${item_price}',
    hitLimit: 100,
    expiryTime: Date.now() + 60000,
  });
  expect(logProbe.success).toBe(true);
  await waitForProbesToBeLive([logProbe.id]);

  const firstResponse = await checkout(10.0);
  expect(firstResponse.status).toBe(200);

  const firstLogs = await pollRows(
    'the first Python retirement log',
    () => getDatabase().logEvent.findMany({ where: { probeId: logProbe.id } }),
    1,
  );
  expect(firstLogs).toHaveLength(1);
  expect(firstLogs[0].message).toBe('Retirement Check: 10');

  const toggled = await trpc.toggleProbeStatus.mutate({
    id: logProbe.id,
    status: ProbeStatus.INACTIVE,
  });
  expect(toggled.success).toBe(true);

  // Waiting for a heartbeat more than one full sync interval after the toggle
  // proves the agent has fetched the inactive probe set before the next hit.
  await waitForAgentHeartbeatAfter(SERVICE_ID, Date.now() + 1000);

  const secondResponse = await checkout(20.0);
  expect(secondResponse.status).toBe(200);

  await assertRowCountRemains(
    'retired Python probe telemetry',
    () =>
      getDatabase().logEvent.count({
        where: { probeId: logProbe.id },
      }),
    1,
  );
});

function checkout(price: number) {
  return fetch(`http://127.0.0.1:${PORT}/checkout`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      userId: 'user_123',
      items: [{ price, quantity: 1 }],
    }),
  });
}
