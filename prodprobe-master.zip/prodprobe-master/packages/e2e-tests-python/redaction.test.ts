import { afterAll, beforeAll, expect, test } from 'vitest';
import { getDatabase, ProbeType } from './database.js';
import {
  DEMO_FILE,
  DEMO_LINES,
  type PythonDemoApp,
  pollRows,
  resetE2EState,
  startPythonDemoApp,
  stopPythonDemoApp,
  trpc,
  waitForProbesToBeLive,
} from './test-helpers.js';

const SERVICE_ID = '00000000-0000-4000-8000-000000000104';
const COMMIT_SHA = 'python-e2e-redaction-sha';
const PORT = 4104;

let demoApp: PythonDemoApp | undefined;

beforeAll(async () => {
  await resetE2EState(SERVICE_ID, 'python-demo-app-redaction');
  demoApp = await startPythonDemoApp({
    serviceId: SERVICE_ID,
    commitSha: COMMIT_SHA,
    port: PORT,
  });
});

afterAll(async () => {
  await stopPythonDemoApp(demoApp);
});

test('E2E Python Redaction & Truncation Verification', async () => {
  const snapshotProbe = await trpc.createProbe.mutate({
    commitSha: COMMIT_SHA,
    type: ProbeType.SNAPSHOT,
    serviceId: SERVICE_ID,
    environment: 'development',
    uiFilePath: DEMO_FILE,
    uiLineNumber: DEMO_LINES.snapshotAndDurationEnd,
    hitLimit: 1,
    expiryTime: Date.now() + 60000,
    maxObjectDepth: 2,
    maxArrayLength: 2,
    stackFrameDepth: 5,
  });
  expect(snapshotProbe.success).toBe(true);
  await waitForProbesToBeLive([snapshotProbe.id]);

  const response = await fetch(`http://127.0.0.1:${PORT}/checkout`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      userId: 'user_123',
      items: [
        { price: 1.0, quantity: 1 },
        { price: 2.0, quantity: 1 },
        { price: 3.0, quantity: 1 },
        { price: 4.0, quantity: 1 },
      ],
    }),
  });
  expect(response.status).toBe(200);

  const snapshots = await pollRows(
    'the Python redaction snapshot',
    () =>
      getDatabase().snapshotEvent.findMany({
        where: { probeId: snapshotProbe.id },
      }),
    1,
  );
  expect(snapshots).toHaveLength(1);

  const payload = snapshots[0].payload as any;
  const localScope = payload.vars[0].find(
    (scope: any) => scope.type === 'local',
  );
  expect(localScope).toBeDefined();

  const localVars = localScope.vars;
  const userSession = localVars.user_session;
  expect(userSession).toBeDefined();
  expect(userSession.password).toBe('[REDACTED Key]');
  expect(localVars.user_id).toBe('[REDACTED Key]');
  expect(userSession.circular).toBe('[REF - frame[0].scopes[0].user_session]');

  expect(localVars.items).toHaveLength(3);
  expect(localVars.items[2]).toContain('more items truncated');
  expect(userSession.flags[0]).toBe('premium');
});
