import { createTRPCProxyClient, httpBatchLink } from '@trpc/client';
import type { AppRouter } from 'backend';
import jwt from 'jsonwebtoken';
import superjson from 'superjson';
import { getDatabase } from './database.js';

export const ADMIN_EMAIL = 'e2e-admin@hyperprobe.io';

export async function ensureAdminUser() {
  const prisma = getDatabase();
  let adminTeam = await prisma.team.findFirst({
    where: { isAdminTeam: true },
  });
  if (!adminTeam) {
    adminTeam = await prisma.team.create({
      data: { name: 'Admin Team', isAdminTeam: true },
    });
  }

  let adminUser = await prisma.user.findUnique({
    where: { email: ADMIN_EMAIL },
    include: { teams: true },
  });
  if (!adminUser) {
    adminUser = await prisma.user.create({
      data: { email: ADMIN_EMAIL },
      include: { teams: true },
    });
  }

  if (!adminUser.teams.some((team) => team.teamId === adminTeam.id)) {
    await prisma.userTeam.create({
      data: { userId: adminUser.id, teamId: adminTeam.id },
    });
  }
  return adminUser;
}

export async function getAdminToken() {
  const prisma = getDatabase();
  const adminUser = await ensureAdminUser();
  const systemConfig = await prisma.systemConfig.findFirst({
    where: { id: 'singleton' },
  });
  if (!systemConfig) {
    throw new Error(
      'SystemConfig not found. Backend might not have started yet.',
    );
  }

  return jwt.sign(
    {
      userId: adminUser.id,
      email: adminUser.email,
      permissions: { isAdmin: true, permissions: {} },
    },
    systemConfig.tokenSecret,
    { expiresIn: '1h' },
  );
}

export async function getAuthenticatedTRPCClient() {
  const token = await getAdminToken();
  return createTRPCProxyClient<AppRouter>({
    transformer: superjson,
    links: [
      httpBatchLink({
        url: 'http://localhost:4001/trpc',
        headers: { Authorization: `Bearer ${token}` },
      }),
    ],
  });
}
