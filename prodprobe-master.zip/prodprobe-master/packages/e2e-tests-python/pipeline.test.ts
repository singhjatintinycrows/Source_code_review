import { afterAll, beforeAll, expect, test } from 'vitest';
import { getDatabase, ProbeStatus, ProbeType } from './database.js';
import {
  DEMO_FILE,
  DEMO_LINES,
  type PythonDemoApp,
  pollRows,
  resetE2EState,
  startPythonDemoApp,
  stopPythonDemoApp,
  trpc,
  waitForProbesToBeLive,
} from './test-helpers.js';

const SERVICE_ID = '00000000-0000-4000-8000-000000000103';
const COMMIT_SHA = 'python-e2e-pipeline-sha';
const PORT = 4103;

let demoApp: PythonDemoApp | undefined;

beforeAll(async () => {
  await resetE2EState(SERVICE_ID, 'python-demo-app-pipeline');
  demoApp = await startPythonDemoApp({
    serviceId: SERVICE_ID,
    commitSha: COMMIT_SHA,
    port: PORT,
  });
});

afterAll(async () => {
  await stopPythonDemoApp(demoApp);
});

test('E2E Pipeline Python: Multi-Probe Verification', async () => {
  const expiryTime = Date.now() + 60000;

  const logProbe = await trpc.createProbe.mutate({
    commitSha: COMMIT_SHA,
    type: ProbeType.LOG,
    serviceId: SERVICE_ID,
    environment: 'development',
    uiFilePath: DEMO_FILE,
    uiLineNumber: DEMO_LINES.item,
    // biome-ignore lint/suspicious/noTemplateCurlyInString: SDK log-template syntax
    template: 'LOG: ${item_price}',
    hitLimit: 2,
    expiryTime,
  });

  const counterProbe = await trpc.createProbe.mutate({
    commitSha: COMMIT_SHA,
    type: ProbeType.COUNTER,
    serviceId: SERVICE_ID,
    environment: 'development',
    uiFilePath: DEMO_FILE,
    uiLineNumber: DEMO_LINES.item,
    metricName: 'items_processed_total',
    hitLimit: 2,
    expiryTime,
  });

  const snapshotProbe = await trpc.createProbe.mutate({
    commitSha: COMMIT_SHA,
    type: ProbeType.SNAPSHOT,
    serviceId: SERVICE_ID,
    environment: 'development',
    uiFilePath: DEMO_FILE,
    uiLineNumber: DEMO_LINES.snapshotAndDurationEnd,
    watchExpressions: ['cart_total', 'discount', 'user_session.get("id")'],
    hitLimit: 1,
    expiryTime,
  });

  const durationProbe = await trpc.createProbe.mutate({
    commitSha: COMMIT_SHA,
    type: ProbeType.DURATION,
    serviceId: SERVICE_ID,
    environment: 'development',
    uiFilePath: DEMO_FILE,
    uiLineNumber: DEMO_LINES.durationStart,
    secondaryUiFilePath: DEMO_FILE,
    secondaryUiLineNumber: DEMO_LINES.snapshotAndDurationEnd,
    metricName: 'checkout_loop_duration',
    hitLimit: 1,
    expiryTime,
  });

  expect(logProbe.success).toBe(true);
  expect(counterProbe.success).toBe(true);
  expect(snapshotProbe.success).toBe(true);
  expect(durationProbe.success).toBe(true);

  const probeIds = [
    logProbe.id,
    counterProbe.id,
    snapshotProbe.id,
    durationProbe.id,
  ];
  await waitForProbesToBeLive(probeIds);

  const response = await fetch(`http://127.0.0.1:${PORT}/checkout`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      userId: 'user_123',
      items: [
        { price: 10.0, quantity: 1 },
        { price: 200.0, quantity: 1 },
      ],
    }),
  });
  expect(response.status).toBe(200);

  const logs = await pollRows(
    'two Python log events',
    () => getDatabase().logEvent.findMany({ where: { probeId: logProbe.id } }),
    2,
  );
  expect(logs).toHaveLength(2);
  expect(logs.map((log) => log.message)).toEqual(
    expect.arrayContaining(['LOG: 10', 'LOG: 200']),
  );

  const counters = await pollRows(
    'two Python counter events',
    () =>
      getDatabase().metricEvent.findMany({
        where: { probeId: counterProbe.id },
      }),
    2,
  );
  expect(counters).toHaveLength(2);
  expect(counters.every((counter) => counter.value === 1)).toBe(true);

  const snapshots = await pollRows(
    'one Python snapshot event',
    () =>
      getDatabase().snapshotEvent.findMany({
        where: { probeId: snapshotProbe.id },
      }),
    1,
  );
  expect(snapshots).toHaveLength(1);

  const payload = snapshots[0].payload as any;
  expect(payload.watch.cart_total).toBeDefined();
  expect(payload.watch['user_session.get("id")']).toBe('user_123');
  const localScope = payload.vars[0].find(
    (scope: any) => scope.type === 'local',
  );
  expect(localScope).toBeDefined();
  expect(localScope.vars).toBeDefined();

  const durations = await pollRows(
    'one Python duration event',
    () =>
      getDatabase().metricEvent.findMany({
        where: { probeId: durationProbe.id },
      }),
    1,
  );
  expect(durations).toHaveLength(1);
  expect(durations[0].value).toBeGreaterThan(0);

  const completedProbes = await pollRows(
    'all Python pipeline probes to complete',
    () =>
      getDatabase().probe.findMany({
        where: {
          id: { in: probeIds },
          status: ProbeStatus.COMPLETED,
        },
      }),
    4,
  );
  expect(completedProbes).toHaveLength(4);
});
