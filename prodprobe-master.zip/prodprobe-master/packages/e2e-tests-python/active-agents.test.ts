import { getConfig } from '@hyperprobe/common';
import { createClient } from 'redis';
import { afterAll, beforeAll, expect, test } from 'vitest';
import {
  type PythonDemoApp,
  pollUntil,
  resetE2EState,
  startPythonDemoApp,
  stopPythonDemoApp,
  trpc,
} from './test-helpers.js';

const SERVICE_ID = '00000000-0000-4000-8000-000000000106';
const COMMIT_SHA = 'python-e2e-active-agents-sha';
const PORT = 4106;

let demoApp: PythonDemoApp | undefined;

beforeAll(async () => {
  await resetE2EState(SERVICE_ID, 'python-demo-app-active-agents');
  demoApp = await startPythonDemoApp({
    serviceId: SERVICE_ID,
    commitSha: COMMIT_SHA,
    port: PORT,
  });
});

afterAll(async () => {
  await stopPythonDemoApp(demoApp);
});

test('E2E Python Active Agents: SDK registers and Backend lists accurately', async () => {
  const agents = await pollUntil(
    'the Python agent registration',
    () => trpc.listActiveAgents.query({ serviceIds: [SERVICE_ID] }),
    (registeredAgents) => registeredAgents.length === 1,
    15000,
  );

  const registeredAgent = agents[0];
  expect(registeredAgent.agentId).toMatch(/^py-/);
  expect(registeredAgent.serviceId).toBe(SERVICE_ID);
  expect(registeredAgent.environment).toBe('development');
  expect(registeredAgent.commitSha).toBe(COMMIT_SHA);

  await stopPythonDemoApp(demoApp);
  demoApp = undefined;

  const config = await getConfig();
  const redis = createClient({ url: config.redisUrl });
  await redis.connect();
  try {
    const staleAgentId = 'stale-python-agent';
    const freshAgentId = 'fresh-python-agent';
    await redis.zAdd(`active_agents:${SERVICE_ID}`, [
      {
        score: Date.now() - 105000,
        value: JSON.stringify({
          agentId: staleAgentId,
          serviceId: SERVICE_ID,
          environment: 'development',
          commitSha: COMMIT_SHA,
        }),
      },
      {
        score: Date.now(),
        value: JSON.stringify({
          agentId: freshAgentId,
          serviceId: SERVICE_ID,
          environment: 'development',
          commitSha: COMMIT_SHA,
        }),
      },
    ]);

    const finalAgents = await trpc.listActiveAgents.query({
      serviceIds: [SERVICE_ID],
    });
    const agentIds = finalAgents.map((agent) => agent.agentId);

    expect(agentIds).toContain(registeredAgent.agentId);
    expect(agentIds).toContain(freshAgentId);
    expect(agentIds).not.toContain(staleAgentId);
    expect(finalAgents).toHaveLength(2);
  } finally {
    await redis.quit();
  }
});
