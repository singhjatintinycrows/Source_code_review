process.env.HYPERPROBE_ENV = 'e2e';

import { getConfig } from '@hyperprobe/common';
import { initDatabase } from './database.js';

const config = await getConfig();
initDatabase(config.databaseUrl);
