import { createRequire } from 'node:module';

const require = createRequire(import.meta.url);
const database =
  require('@hyperprobe/database') as typeof import('@hyperprobe/database');

export const { getDatabase, initDatabase, ProbeStatus, ProbeType } = database;
