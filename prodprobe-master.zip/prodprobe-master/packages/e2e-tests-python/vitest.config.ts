process.env.HYPERPROBE_ENV = 'e2e';

import { defineConfig } from 'vitest/config';

export default defineConfig({
  test: {
    testTimeout: 90000,
    hookTimeout: 120000,
    globalSetup: './vitest.setup.ts',
    setupFiles: ['./vitest.worker-setup.ts'],
    fileParallelism: false,
    maxWorkers: 1,
    minWorkers: 1,
    env: {
      HYPERPROBE_ENV: 'e2e',
    },
  },
});
