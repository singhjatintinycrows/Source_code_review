import {
  type SpawnSyncOptionsWithStringEncoding,
  spawnSync,
} from 'node:child_process';
import { createHash } from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const packageDir = path.dirname(fileURLToPath(import.meta.url));
const root = path.resolve(packageDir, '../..');
const requirementsFile = path.resolve(
  root,
  'agents/python-demo-app/requirements.txt',
);
const sdkSetupFile = path.resolve(root, 'agents/python-sdk/setup.py');

function run(
  command: string,
  args: string[],
  options: SpawnSyncOptionsWithStringEncoding = {},
) {
  const result = spawnSync(command, args, {
    cwd: packageDir,
    encoding: 'utf8',
    ...options,
  });

  if (result.error) throw result.error;
  if (result.status !== 0) {
    if (result.stdout) process.stdout.write(result.stdout);
    if (result.stderr) process.stderr.write(result.stderr);
    throw new Error(`Command failed (${result.status}): ${command}`);
  }
  return result;
}

function resolvePython(command: string) {
  const result = run(command, [
    '-c',
    [
      'import sys',
      'assert sys.version_info >= (3, 12), "Python 3.12+ is required"',
      'assert hasattr(sys, "monitoring"), "sys.monitoring is required"',
      'print(sys.executable)',
    ].join('; '),
  ]);
  return result.stdout.trim();
}

function preparePython() {
  if (process.env.HYPERPROBE_E2E_PYTHON) {
    return resolvePython(process.env.HYPERPROBE_E2E_PYTHON);
  }

  const basePython = resolvePython('python3');
  const venvDir = path.resolve(packageDir, '.venv');
  const venvPython = path.resolve(
    venvDir,
    process.platform === 'win32' ? 'Scripts/python.exe' : 'bin/python',
  );

  if (!fs.existsSync(venvPython)) {
    console.log(`Creating Python E2E environment with ${basePython}...`);
    run(basePython, ['-m', 'venv', venvDir], { stdio: 'inherit' });
  }

  const dependencyHash = createHash('sha256')
    .update(fs.readFileSync(requirementsFile))
    .update(fs.readFileSync(sdkSetupFile))
    .digest('hex');
  const stampFile = path.resolve(venvDir, '.requirements.sha256');
  const installedHash = fs.existsSync(stampFile)
    ? fs.readFileSync(stampFile, 'utf8').trim()
    : '';

  if (installedHash !== dependencyHash) {
    console.log('Installing Python E2E dependencies...');
    run(
      venvPython,
      [
        '-m',
        'pip',
        'install',
        '--disable-pip-version-check',
        '-r',
        requirementsFile,
      ],
      {
        cwd: path.dirname(requirementsFile),
        stdio: 'inherit',
      },
    );
    fs.writeFileSync(stampFile, `${dependencyHash}\n`);
  }

  run(venvPython, ['-c', 'import fastapi, uvicorn, grpc, google.protobuf']);
  return venvPython;
}

try {
  const pythonExecutable = preparePython();
  const result = spawnSync(
    'pnpm',
    ['exec', 'vitest', 'run', ...process.argv.slice(2)],
    {
      cwd: packageDir,
      env: {
        ...process.env,
        HYPERPROBE_E2E_PYTHON: pythonExecutable,
      },
      stdio: 'inherit',
    },
  );

  if (result.error) throw result.error;
  process.exitCode = result.status ?? 1;
} catch (error) {
  const message = error instanceof Error ? error.message : String(error);
  console.error(`Python E2E setup failed: ${message}`);
  process.exitCode = 1;
}
