export const MAX_SNAPSHOT_SIZE = 2 * 1024 * 1024; // 2MB
export const MAX_DEPTH = 5;
export const MAX_ARRAY = 10;
export const CPU_LIMIT_MS = 5;

export const REDIS_AGENT_TTL = 60; // 1 minute
export const NATS_SNAPSHOT_SUBJECT = 'snapshots.v1';
const isE2E =
  typeof process !== 'undefined' &&
  process.env &&
  process.env.HYPERPROBE_ENV === 'e2e';
export const CONSUL_URL =
  (typeof process !== 'undefined' && process.env && process.env.CONSUL_URL) ||
  'http://localhost:8500';
export const NATS_TELEMETRY_STREAM = isE2E
  ? 'PROBE_TELEMETRY_E2E'
  : 'PROBE_TELEMETRY';
export const NATS_TELEMETRY_SUBJECT = isE2E
  ? 'PROBE.telemetry.ingest.E2E'
  : 'PROBE.telemetry.ingest';
export const HYPERPROBE_LICENSING_DB_URL =
  'https://hyperprobe-a1055-default-rtdb.firebaseio.com/licensing_url.json';
export const HYPERPROBE_LICENSING_PUBLIC_KEY_URL =
  'https://hyperprobe-a1055-default-rtdb.firebaseio.com/public_key_pem.json';

let licensingServerUrl: string | null = null;
export const getLicensingServerUrl = async () => {
  if (licensingServerUrl) {
    return licensingServerUrl;
  }
  const response = await fetch(HYPERPROBE_LICENSING_DB_URL);
  if (!response.ok) {
    throw new Error('Failed to fetch licensing URL');
  }
  licensingServerUrl = await response.json();
  if (!licensingServerUrl) {
    throw new Error('Licensing server URL not found');
  }
  return licensingServerUrl;
};

export function unescapeWatchKey(
  rawKey: string,
  isDoubleQuoted: boolean,
  isSingleQuoted: boolean,
): string {
  if (isDoubleQuoted) {
    try {
      return JSON.parse(
        `"${rawKey.replace(/\n/g, '\\n').replace(/\r/g, '\\r').replace(/\t/g, '\\t')}"`,
      );
    } catch {
      return rawKey.replace(/\\(.)/gs, '$1');
    }
  }
  if (isSingleQuoted) {
    return rawKey.replace(/\\(.)/gs, '$1');
  }
  return rawKey;
}

// Resolve path from the payload. On-the-fly reference resolution handles deep nested paths correctly.
export function resolvePath(
  payload: any,
  path: string,
  visited: Set<string> = new Set(),
): any {
  if (!payload || visited.has(path)) return undefined;
  visited.add(path);

  let current: any;
  let remaining = '';

  const watchMatch = path.match(
    /^watch\[(?:"((?:[^"\\]|\\.)*)"|'((?:[^'\\]|\\.)*)'|([^\]]+))\]/,
  );
  const frameMatch = path.match(/^frame\[(\d+)\]\.scopes\[(\d+)\]/);

  if (watchMatch) {
    const rawKey = watchMatch[1] ?? watchMatch[2] ?? watchMatch[3];
    const key = unescapeWatchKey(
      rawKey,
      watchMatch[1] !== undefined,
      watchMatch[2] !== undefined,
    );
    if (payload.watch && typeof payload.watch === 'object') {
      if (Object.hasOwn(payload.watch, key)) {
        current = payload.watch[key];
      } else if (Object.hasOwn(payload.watch, rawKey)) {
        current = payload.watch[rawKey];
      }
    }
    remaining = path.slice(watchMatch[0].length);
  } else if (frameMatch) {
    const frameIndex = parseInt(frameMatch[1], 10);
    const scopeIndex = parseInt(frameMatch[2], 10);
    if (
      payload.vars &&
      Array.isArray(payload.vars) &&
      payload.vars[frameIndex] &&
      Array.isArray(payload.vars[frameIndex]) &&
      payload.vars[frameIndex][scopeIndex]
    ) {
      current = payload.vars[frameIndex][scopeIndex].vars;
    }
    remaining = path.slice(frameMatch[0].length);
  } else {
    return undefined;
  }

  const propRegex = /^(?:\.([^.[]+)|\[(\d+)\])/;
  while (current !== undefined && current !== null) {
    if (typeof current === 'string') {
      const refMatch = current.match(/^\[REF - (.+)\]$/);
      if (refMatch) {
        const resolved = resolvePath(payload, refMatch[1], visited);
        if (resolved !== undefined) {
          current = resolved;
          continue;
        }
      }
    }

    if (remaining.length === 0) {
      break;
    }

    const match = remaining.match(propRegex);
    if (!match) {
      break;
    }
    if (match[1] !== undefined) {
      const key = match[1];
      current = current[key];
    } else if (match[2] !== undefined) {
      const index = parseInt(match[2], 10);
      current = current[index];
    }
    remaining = remaining.slice(match[0].length);
  }

  return current;
}
