import { describe, expect, it } from 'vitest';
import { resolvePath, unescapeWatchKey } from './index.js';

describe('unescapeWatchKey', () => {
  it('should unescape simple double quoted keys', () => {
    expect(unescapeWatchKey('userSession', true, false)).toBe('userSession');
  });

  it('should unescape double quoted keys containing escaped double quotes', () => {
    expect(
      unescapeWatchKey('req.headers[\\"authorization\\"]', true, false),
    ).toBe('req.headers["authorization"]');
  });

  it('should unescape single quoted keys containing escaped single quotes', () => {
    expect(
      unescapeWatchKey("req.headers[\\'authorization\\']", false, true),
    ).toBe("req.headers['authorization']");
  });

  it('should handle unquoted keys', () => {
    expect(unescapeWatchKey('userSession', false, false)).toBe('userSession');
  });
});

describe('resolvePath', () => {
  const payload = {
    watch: {
      userSession: { id: 'usr_1', email: 'test@example.com' },
      'req.headers["authorization"]': {
        token: 'bearer_123',
        meta: { valid: true },
      },
      "map.get('key')": { value: 42 },
    },
    vars: [
      [
        {
          type: 'local',
          name: 'local',
          vars: {
            sessionRef: '[REF - watch["userSession"]]',
            authRef: '[REF - watch["req.headers[\\"authorization\\"]"]]',
            nestedTokenRef:
              '[REF - watch["req.headers[\\"authorization\\"]"].token]',
            userEmailRef: '[REF - watch["userSession"].email]',
            circularLocal: '[REF - frame[0].scopes[0]]',
          },
        },
      ],
    ],
  };

  it('should resolve simple watch expressions', () => {
    expect(resolvePath(payload, 'watch["userSession"]')).toEqual({
      id: 'usr_1',
      email: 'test@example.com',
    });
  });

  it('should resolve watch expressions with nested quotes', () => {
    expect(
      resolvePath(payload, 'watch["req.headers[\\"authorization\\"]"]'),
    ).toEqual({
      token: 'bearer_123',
      meta: { valid: true },
    });
  });

  it('should resolve properties on watch expressions with nested quotes', () => {
    expect(
      resolvePath(payload, 'watch["req.headers[\\"authorization\\"]"].token'),
    ).toBe('bearer_123');
    expect(
      resolvePath(
        payload,
        'watch["req.headers[\\"authorization\\"]"].meta.valid',
      ),
    ).toBe(true);
  });

  it('should resolve frame variables', () => {
    expect(resolvePath(payload, 'frame[0].scopes[0]')).toBeDefined();
    expect(resolvePath(payload, 'frame[0].scopes[0].userEmailRef')).toBe(
      'test@example.com',
    );
    expect(resolvePath(payload, 'frame[0].scopes[0].nestedTokenRef')).toBe(
      'bearer_123',
    );
  });

  it('should not resolve prototype properties from watch or objects', () => {
    expect(resolvePath(payload, 'watch["toString"]')).toBeUndefined();
    expect(resolvePath(payload, 'watch["valueOf"]')).toBeUndefined();
    expect(resolvePath(payload, 'watch["constructor"]')).toBeUndefined();
  });
});
