import crypto from 'node:crypto';
import * as vscode from 'vscode';
import { createTrpcClientForMainExtension } from './trpc';
import { TokenManager } from './utils/TokenManager';

export function isTokenExpired(token: string): boolean {
  try {
    const payloadB64 = token.split('.')[1];
    const decoded = Buffer.from(payloadB64, 'base64url').toString('utf8');
    const payload = JSON.parse(decoded);
    if (!payload || typeof payload.exp !== 'number') {
      return true;
    }
    return payload.exp * 1000 <= Date.now();
  } catch {
    return true;
  }
}

export async function setupAuthentication(
  context: vscode.ExtensionContext,
  viewProvider?: any,
) {
  const tokenManager = new TokenManager(context.secrets);

  // Register the login command
  context.subscriptions.push(
    vscode.commands.registerCommand('hyperprobe.login', async () => {
      const serverUrl = tokenManager.serverUrl;
      if (!serverUrl) {
        vscode.window.showErrorMessage(
          'Server URL not configured. Please configure it in the settings.',
        );
        return;
      }

      const trpc = createTrpcClientForMainExtension(serverUrl);
      const identifier = crypto.randomUUID();
      const loginUrl = `${serverUrl}/dashboard/#/login?identifier=${identifier}&client=vsc`;

      // Open the browser for SSO
      vscode.env.openExternal(vscode.Uri.parse(loginUrl));

      vscode.window.showInformationMessage(
        'Waiting for authentication to complete in the browser...',
      );

      const startTime = Date.now();
      const timeoutMs = 5 * 60 * 1000; // 5 minutes
      let loggedIn = false;

      while (Date.now() - startTime < timeoutMs) {
        try {
          const res = await trpc.pollLogin.query({ identifier });

          if (res.status === 'success' && res.accessToken && res.refreshToken) {
            // Save tokens securely
            await tokenManager.storeTokens(res.accessToken, res.refreshToken);

            vscode.window.showInformationMessage('Successfully logged in!');

            // Notify the Webview Provider that we are now logged in
            if (viewProvider) {
              viewProvider.updateAuthStatus(true);
            }

            // Focus the extension view
            vscode.commands.executeCommand('hyperprobe-main.focus');

            loggedIn = true;
            break;
          }
        } catch (error) {
          console.error('Error polling for login', error);
        }

        // Wait for 5 seconds before polling again
        await new Promise((resolve) => setTimeout(resolve, 5000));
      }

      // If loop finished and we haven't logged in, it timed out
      if (!loggedIn) {
        vscode.window.showErrorMessage('Login timed out. Please try again.');
        if (viewProvider) {
          viewProvider.updateAuthStatus(false);
        }
      }
    }),
  );

  // Check initial token state
  const { accessToken, refreshToken } = await tokenManager.getTokens();

  if (refreshToken && isTokenExpired(refreshToken)) {
    await tokenManager.clearTokens();
    if (viewProvider) {
      viewProvider.updateAuthStatus(false);
    }
    vscode.window
      .showInformationMessage(
        'HyperProbe: Session expired. Please log in to connect.',
        'Log In',
      )
      .then((selection) => {
        if (selection === 'Log In') {
          vscode.commands.executeCommand('hyperprobe.login');
        }
      });
    return false; // Return false indicating not authenticated
  }

  if (!accessToken) {
    vscode.window
      .showInformationMessage(
        'HyperProbe: Please log in to connect to the backend.',
        'Log In',
      )
      .then((selection) => {
        if (selection === 'Log In') {
          vscode.commands.executeCommand('hyperprobe.login');
        }
      });
    return false; // Return false indicating not authenticated
  }
  return true; // Return true indicating authenticated
}

// Function to handle logging out the user
export async function logout(
  context: vscode.ExtensionContext,
  viewProvider?: any,
) {
  const tokenManager = new TokenManager(context.secrets);

  try {
    // 3. Delete secrets locally regardless of backend success to ensure local state resets
    await tokenManager.clearTokens();

    // 4. Show success message
    vscode.window.showInformationMessage(
      'Successfully signed out of Hyper Probe.',
    );

    // 5. Update UI State (Hide sources, show login view)
    if (viewProvider) {
      viewProvider.updateAuthStatus(false);
    }

    // 6. Prompt to log in again
    const selection = await vscode.window.showInformationMessage(
      'Do you want to log in again?',
      'Yes',
      'No',
    );
    if (selection === 'Yes') {
      vscode.commands.executeCommand('hyperprobe.login');
    }
  } catch (error) {
    console.error('Logout error:', error);
    vscode.window.showErrorMessage(
      'An error occurred while signing out. Local session cleared.',
    );

    // Fallback: Ensure local secrets are wiped even if the network call failed
    await tokenManager.clearTokens();

    if (viewProvider) {
      viewProvider.updateAuthStatus(false);
    }
  }
}
