import * as vscode from 'vscode';

export class TokenManager {
  private static migrationLocks = new Map<
    string,
    Promise<{
      accessToken?: string;
      refreshToken?: string;
    }>
  >();

  constructor(private readonly secrets: vscode.SecretStorage) {}

  get serverUrl(): string {
    const config = vscode.workspace.getConfiguration('hyperprobe');
    const rawUrl = config.get<string>('serverUrl');
    const finalUrl = rawUrl?.trim() || '';
    return finalUrl.replace(/\/+$/, '');
  }

  getTokens(): Promise<{ accessToken?: string; refreshToken?: string }> {
    const serverUrl = this.serverUrl;
    if (!TokenManager.migrationLocks.has(serverUrl)) {
      const promise = this._getTokens().finally(() => {
        TokenManager.migrationLocks.delete(serverUrl);
      });
      TokenManager.migrationLocks.set(serverUrl, promise);
    }
    return TokenManager.migrationLocks.get(serverUrl)!;
  }

  private async _getTokens(): Promise<{
    accessToken?: string;
    refreshToken?: string;
  }> {
    const serverUrl = this.serverUrl;
    let accessToken = await this.secrets.get(`accessToken:${serverUrl}`);
    let refreshToken = await this.secrets.get(`refreshToken:${serverUrl}`);

    // Centralized Migration logic
    if (!accessToken) {
      accessToken = await this.secrets.get('accessToken');
      if (accessToken) {
        refreshToken = await this.secrets.get('refreshToken');
        await this.storeTokens(accessToken, refreshToken);

        // Safely purge legacy state to prevent duplicate migrations
        await this.secrets.delete('accessToken');
        await this.secrets.delete('refreshToken');
      }
    }

    return { accessToken, refreshToken };
  }

  async storeTokens(accessToken: string, refreshToken?: string): Promise<void> {
    const serverUrl = this.serverUrl;
    await this.secrets.store(`accessToken:${serverUrl}`, accessToken);
    if (refreshToken) {
      await this.secrets.store(`refreshToken:${serverUrl}`, refreshToken);
    }
  }

  async clearTokens(): Promise<void> {
    const serverUrl = this.serverUrl;
    await this.secrets.delete(`accessToken:${serverUrl}`);
    await this.secrets.delete(`refreshToken:${serverUrl}`);
    // Clear legacy tokens as well
    await this.secrets.delete('accessToken');
    await this.secrets.delete('refreshToken');
  }
}
