import { createTRPCProxyClient, httpBatchLink } from '@trpc/client';
import type { AppRouter } from 'backend/src/index';
import fetchPonyfill from 'fetch-ponyfill';
import superjson from 'superjson';

const customFetch = fetchPonyfill().fetch;

export function createTrpcClientForMainExtension(serverUrl: string) {
  return createTRPCProxyClient<AppRouter>({
    transformer: superjson,
    links: [
      httpBatchLink({
        url: `${serverUrl}/trpc`,
        fetch: customFetch,
      }),
    ],
  });
}
