import { exec } from 'child_process';
import fetchPonyfill from 'fetch-ponyfill';
import { promisify } from 'util';
import * as vscode from 'vscode';
import { isTokenExpired, logout, setupAuthentication } from './auth';
import { TokenManager } from './utils/TokenManager';

interface GitRepository {
  rootUri: vscode.Uri;
  state: {
    HEAD?: { commit?: string };
    onDidChange: vscode.Event<void>;
  };
}

const customFetch = fetchPonyfill().fetch;
const execAsync = promisify(exec);

import {
  HYPERPROBE_LICENSING_DB_URL,
  HYPERPROBE_LICENSING_PUBLIC_KEY_URL,
} from '@hyperprobe/constants';

export async function activate(context: vscode.ExtensionContext) {
  console.log('HyperProbe Extension activating...');

  const vueProvider = new VueViewProvider(context.extensionUri, context);

  // Pass the view provider to setupAuthentication so it can be notified when login completes
  const isAuthenticated = await setupAuthentication(context, vueProvider);

  // Set the initial authentication status
  vueProvider.updateAuthStatus(isAuthenticated);

  context.subscriptions.push(
    vscode.window.registerWebviewViewProvider('hyperprobe-main', vueProvider),
  );

  // Register Sign Out Command
  context.subscriptions.push(
    vscode.commands.registerCommand('hyperprobe.signOut', async () => {
      await logout(context, vueProvider);
    }),
  );

  context.subscriptions.push(
    vscode.commands.registerCommand('hyperprobe.openSettings', async () => {
      vscode.commands.executeCommand(
        'workbench.action.openSettings',
        'hyperprobe.serverUrl',
      );
    }),
  );

  const handleEditorContextAction = (type: 'log' | 'snapshot') => {
    const editor = vscode.window.activeTextEditor;
    if (editor) {
      const document = editor.document;
      const selection = editor.selection;

      // Get workspace folder for the file to determine relative path
      const workspaceFolder = vscode.workspace.getWorkspaceFolder(document.uri);
      let relativePath = document.uri.fsPath;

      if (workspaceFolder) {
        relativePath = vscode.workspace.asRelativePath(document.uri, false);
      } else {
        // Fallback for files outside workspace or single file workspaces
        relativePath = vscode.workspace.asRelativePath(document.uri);
      }

      // Line numbers in VS Code are 0-based, our UI expects 1-based
      const lineNumber = selection.active.line + 1;

      // Open the HyperProbe view first
      vscode.commands.executeCommand('hyperprobe-main.focus').then(() => {
        // Send navigation message to webview
        vueProvider.navigateTo(
          `/insert/${type}?filePath=${encodeURIComponent(relativePath)}&lineNumber=${lineNumber}`,
        );
      });
    }
  };

  context.subscriptions.push(
    vscode.commands.registerCommand('hyperprobe.createLog', () => {
      handleEditorContextAction('log');
    }),
  );

  context.subscriptions.push(
    vscode.commands.registerCommand('hyperprobe.createSnapshot', () => {
      handleEditorContextAction('snapshot');
    }),
  );
}

class VueViewProvider implements vscode.WebviewViewProvider {
  private view?: vscode.WebviewView;
  private serviceIds: string[] = [];
  private isAuthenticated: boolean = false;
  private isWebviewReady: boolean = false;
  private pendingNavigation: string | null = null;
  private currentCommitSha: string | null = null;
  private repoListeners = new Map<string, vscode.Disposable>();
  private decorationDebounceTimer: NodeJS.Timeout | null = null;

  // Probe Decoration State
  private probesByFile = new Map<string, any[]>();
  private snapshotActiveDecoration: vscode.TextEditorDecorationType;
  private snapshotInactiveDecoration: vscode.TextEditorDecorationType;
  private snapshotErrorDecoration: vscode.TextEditorDecorationType;
  private snapshotCompletedDecoration: vscode.TextEditorDecorationType;

  private logActiveDecoration: vscode.TextEditorDecorationType;
  private logInactiveDecoration: vscode.TextEditorDecorationType;
  private logErrorDecoration: vscode.TextEditorDecorationType;
  private logCompletedDecoration: vscode.TextEditorDecorationType;
  // private outputChannel: vscode.OutputChannel;

  private tokenManager: TokenManager;

  constructor(
    private readonly extensionUri: vscode.Uri,
    private readonly context: vscode.ExtensionContext,
  ) {
    this.tokenManager = new TokenManager(context.secrets);
    // Create Gutter Icons using highly robust URL-encoded SVG Data URIs
    const createSnapshotIcon = (color: string) => {
      const svg = `<svg width="16" height="16" viewBox="-2 -2 20 20" xmlns="http://www.w3.org/2000/svg" fill="${color}"><path d="M11 8C11 9.65685 9.65685 11 8 11C6.34315 11 5 9.65685 5 8C5 6.34315 6.34315 5 8 5C9.65685 5 11 6.34315 11 8ZM10 8C10 6.89543 9.10457 6 8 6C6.89543 6 6 6.89543 6 8C6 9.10457 6.89543 10 8 10C9.10457 10 10 9.10457 10 8ZM6.61803 2C6.04988 2 5.53048 2.321 5.27639 2.82918L4.69098 4H4C2.89543 4 2 4.89543 2 6V11C2 12.1046 2.89543 13 4 13H12C13.1046 13 14 12.1046 14 11V6C14 4.89543 13.1046 4 12 4H11.309L10.7236 2.82918C10.4695 2.321 9.95012 2 9.38197 2H6.61803ZM6.17082 3.27639C6.25552 3.107 6.42865 3 6.61803 3H9.38197C9.57135 3 9.74448 3.107 9.82918 3.27639L10.5528 4.72361C10.6375 4.893 10.8106 5 11 5H12C12.5523 5 13 5.44772 13 6V11C13 11.5523 12.5523 12 12 12H4C3.44772 12 3 11.5523 3 11V6C3 5.44772 3.44772 5 4 5H5C5.18939 5 5.36252 4.893 5.44721 4.72361L6.17082 3.27639Z"/></svg>`;
      return vscode.Uri.parse(
        `data:image/svg+xml;utf8,${encodeURIComponent(svg)}`,
      );
    };

    const createLogIcon = (color: string) => {
      const svg = `<svg width="16" height="16" viewBox="-2 -2 20 20" xmlns="http://www.w3.org/2000/svg" fill="${color}"><path d="M2 3.5C2 3.224 2.224 3 2.5 3H10.5C10.776 3 11 3.224 11 3.5C11 3.776 10.776 4 10.5 4H2.5C2.224 4 2 3.776 2 3.5ZM13.5 6H2.5C2.224 6 2 6.224 2 6.5C2 6.776 2.224 7 2.5 7H13.5C13.776 7 14 6.776 14 6.5C14 6.224 13.776 6 13.5 6ZM9.5 9H2.5C2.224 9 2 9.224 2 9.5C2 9.776 2.224 10 2.5 10H9.5C9.776 10 10 9.776 10 9.5C10 9.224 9.776 9 9.5 9Z"/><path d="M2.5 12H11.5C11.776 12 12 12.224 12 12.5C12 12.776 11.776 13 11.5 13H2.5C2.224 13 2 12.776 2 12.5C2 12.224 2.224 12 2.5 12Z"/></svg>`;
      return vscode.Uri.parse(
        `data:image/svg+xml;utf8,${encodeURIComponent(svg)}`,
      );
    };

    // Snapshot Decorations (Camera)
    this.snapshotActiveDecoration =
      vscode.window.createTextEditorDecorationType({
        gutterIconPath: createSnapshotIcon('#89d185'),
        gutterIconSize: 'contain',
      });
    this.snapshotInactiveDecoration =
      vscode.window.createTextEditorDecorationType({
        gutterIconPath: createSnapshotIcon('#ffffff'),
        gutterIconSize: 'contain',
      });
    this.snapshotErrorDecoration = vscode.window.createTextEditorDecorationType(
      {
        gutterIconPath: createSnapshotIcon('#f14c4c'),
        gutterIconSize: 'contain',
      },
    );
    this.snapshotCompletedDecoration =
      vscode.window.createTextEditorDecorationType({
        gutterIconPath: createSnapshotIcon('#f08c3a'),
        gutterIconSize: 'contain',
      });

    // Log Decorations (Document)
    this.logActiveDecoration = vscode.window.createTextEditorDecorationType({
      gutterIconPath: createLogIcon('#89d185'),
      gutterIconSize: 'contain',
    });
    this.logInactiveDecoration = vscode.window.createTextEditorDecorationType({
      gutterIconPath: createLogIcon('#ffffff'),
      gutterIconSize: 'contain',
    });
    this.logErrorDecoration = vscode.window.createTextEditorDecorationType({
      gutterIconPath: createLogIcon('#f14c4c'),
      gutterIconSize: 'contain',
    });
    this.logCompletedDecoration = vscode.window.createTextEditorDecorationType({
      gutterIconPath: createLogIcon('#f08c3a'),
      gutterIconSize: 'contain',
    });

    this.context.subscriptions.push(
      this.snapshotActiveDecoration,
      this.snapshotInactiveDecoration,
      this.snapshotErrorDecoration,
      this.snapshotCompletedDecoration,
      this.logActiveDecoration,
      this.logInactiveDecoration,
      this.logErrorDecoration,
      this.logCompletedDecoration,
    );

    this.scanForHprcFiles();
    this.setupHprcWatcher();
    this.setupGitWatcher();
    this.setupEditorListeners();
  }

  private setupEditorListeners() {
    this.context.subscriptions.push({
      dispose: () => {
        if (this.decorationDebounceTimer) {
          clearTimeout(this.decorationDebounceTimer);
        }
      },
    });

    this.context.subscriptions.push(
      vscode.window.onDidChangeActiveTextEditor((editor) => {
        if (editor && editor.document.uri.scheme === 'file') {
          this.updateDecorations(editor);
        }
      }),
      vscode.workspace.onDidChangeTextDocument((event) => {
        const activeEditor = vscode.window.activeTextEditor;
        if (
          activeEditor &&
          event.document === activeEditor.document &&
          event.document.uri.scheme === 'file'
        ) {
          // Clear the previous timer on every keystroke
          if (this.decorationDebounceTimer) {
            clearTimeout(this.decorationDebounceTimer);
          }
          // Set a new timer to update decorations only after typing pauses for 300ms
          this.decorationDebounceTimer = setTimeout(() => {
            this.updateDecorations(activeEditor);
          }, 300);
        }
      }),
    );
  }

  private updateDecorations(editor: vscode.TextEditor) {
    if (!editor || editor.document.uri.scheme !== 'file') return;

    const documentUri = editor.document.uri;
    const workspaceFolder = vscode.workspace.getWorkspaceFolder(documentUri);
    let relativePath = documentUri.fsPath;

    if (workspaceFolder) {
      relativePath = documentUri.fsPath
        .slice(workspaceFolder.uri.fsPath.length)
        .replace(/\\/g, '/');
      if (relativePath.startsWith('/')) {
        relativePath = relativePath.slice(1);
      }
    } else {
      relativePath = vscode.workspace
        .asRelativePath(documentUri)
        .replace(/\\/g, '/');
    }

    const activeRanges = {
      SNAPSHOT: [] as vscode.Range[],
      LOG: [] as vscode.Range[],
    };

    const fileProbes = this.probesByFile.get(relativePath) || [];
    const lineWinners = new Map<number, any>();

    for (const probe of fileProbes) {
      if (probe.status !== 'ACTIVE') continue;

      const pCommit = (probe.commitSha || '').trim().toLowerCase();
      const lCommit = (this.currentCommitSha || '').trim().toLowerCase();

      const isCommitMatch =
        !pCommit ||
        !lCommit ||
        pCommit === lCommit ||
        lCommit.startsWith(pCommit) ||
        pCommit.startsWith(lCommit);

      if (probe.uiFilePath === relativePath && isCommitMatch) {
        const line = Math.max(0, parseInt(probe.uiLineNumber, 10) - 1);
        if (line < editor.document.lineCount) {
          if (lineWinners.has(line)) {
            const existing = lineWinners.get(line);
            if (probe.type === 'SNAPSHOT' && existing.type !== 'SNAPSHOT') {
              lineWinners.set(line, probe);
            }
          } else {
            lineWinners.set(line, probe);
          }
        }
      }
    }

    for (const [line, probe] of lineWinners.entries()) {
      const range = new vscode.Range(line, 0, line, 0);
      activeRanges[probe.type === 'SNAPSHOT' ? 'SNAPSHOT' : 'LOG'].push(range);
    }

    editor.setDecorations(this.snapshotActiveDecoration, activeRanges.SNAPSHOT);
    editor.setDecorations(this.logActiveDecoration, activeRanges.LOG);

    // Clear unused/dead decorations
    editor.setDecorations(this.snapshotInactiveDecoration, []);
    editor.setDecorations(this.snapshotErrorDecoration, []);
    editor.setDecorations(this.snapshotCompletedDecoration, []);
    editor.setDecorations(this.logInactiveDecoration, []);
    editor.setDecorations(this.logErrorDecoration, []);
    editor.setDecorations(this.logCompletedDecoration, []);
  }

  public updateAuthStatus(status: boolean) {
    this.isAuthenticated = status;
    vscode.commands.executeCommand(
      'setContext',
      'hyperprobe.isSignedIn',
      status,
    );
    this.sendConfig();
  }

  private async handleServerUrlChange() {
    const { accessToken } = await this.tokenManager.getTokens();

    this.isAuthenticated = !!accessToken;

    vscode.commands.executeCommand(
      'setContext',
      'hyperprobe.isSignedIn',
      this.isAuthenticated,
    );

    this.sendConfig();
    this.performHealthCheck();
  }

  public navigateTo(path: string) {
    if (this.view && this.isWebviewReady) {
      this.view.webview.postMessage({
        type: 'navigate',
        path: path,
      });
    } else {
      this.pendingNavigation = path;
    }
  }

  private async scanForHprcFiles() {
    try {
      const files = await vscode.workspace.findFiles('**/.hprc');
      const foundIds = new Set<string>();

      for (const file of files) {
        try {
          const document = await vscode.workspace.openTextDocument(file);
          const content = document.getText();
          const parsed = JSON.parse(content);
          if (parsed && typeof parsed.serviceId === 'string') {
            foundIds.add(parsed.serviceId);
          }
        } catch (err) {
          console.error(`HyperProbe: Failed to parse ${file.fsPath}:`, err);
        }
      }

      this.serviceIds = Array.from(foundIds);
      console.log('HyperProbe: Found serviceIds from .hprc:', this.serviceIds);
      this.sendConfig();
    } catch (err) {
      console.error('HyperProbe: Error scanning for .hprc files:', err);
    }
  }

  private setupHprcWatcher() {
    const watcher = vscode.workspace.createFileSystemWatcher('**/.hprc');

    this.context.subscriptions.push(watcher);

    watcher.onDidCreate(() => this.scanForHprcFiles());
    watcher.onDidChange(() => this.scanForHprcFiles());
    watcher.onDidDelete(() => this.scanForHprcFiles());
  }

  private async setupGitWatcher() {
    try {
      const gitExtension = vscode.extensions.getExtension('vscode.git');
      if (!gitExtension) return;

      const git = gitExtension.isActive
        ? gitExtension.exports
        : await gitExtension.activate();
      const api = git.getAPI(1);

      const handleRepository = (repo: GitRepository) => {
        const uriString = repo.rootUri.toString();
        if (this.repoListeners.has(uriString)) return;

        const disposable = repo.state.onDidChange(() => {
          const workspaceFolders = vscode.workspace.workspaceFolders;
          if (!workspaceFolders || workspaceFolders.length === 0) return;

          // Only react if this repo is the primary workspace folder
          if (repo.rootUri.fsPath !== workspaceFolders[0].uri.fsPath) return;

          const newCommit = repo.state.HEAD?.commit;
          if (newCommit && newCommit !== this.currentCommitSha) {
            this.currentCommitSha = newCommit;
            this.sendConfig();
          }
        });

        this.repoListeners.set(uriString, disposable);
        this.context.subscriptions.push(disposable);
      };

      // Watch existing repositories
      api.repositories.forEach(handleRepository);

      // Watch for new repositories being opened
      this.context.subscriptions.push(
        api.onDidOpenRepository(handleRepository),
      );

      // Clean up disposables for closed repositories
      this.context.subscriptions.push(
        api.onDidCloseRepository((repo: GitRepository) => {
          const uriString = repo.rootUri.toString();
          const disposable = this.repoListeners.get(uriString);
          if (disposable) {
            disposable.dispose();
            this.repoListeners.delete(uriString);
          }
        }),
      );
    } catch (e) {
      console.warn('HyperProbe: Failed to setup Git watcher', e);
    }
  }

  resolveWebviewView(webviewView: vscode.WebviewView): void {
    this.view = webviewView;
    this.isWebviewReady = false;
    webviewView.webview.options = {
      enableScripts: true,
      localResourceRoots: [this.extensionUri],
    };
    webviewView.webview.html = this.getHtmlForWebview(webviewView.webview);

    // Send initial config
    this.sendConfig();

    // Listen for config changes
    this.context.subscriptions.push(
      vscode.workspace.onDidChangeConfiguration((e) => {
        (async () => {
          if (e.affectsConfiguration('hyperprobe')) {
            if (e.affectsConfiguration('hyperprobe.serverUrl')) {
              await this.handleServerUrlChange();
            } else {
              this.sendConfig();
            }
            // Also update the HTML to inject the new serverUrl into the CSP
            if (this.view) {
              this.view.webview.html = this.getHtmlForWebview(
                this.view.webview,
              );
            }
          }
        })().catch((err) =>
          console.error('Error handling configuration change:', err),
        );
      }),
    );

    webviewView.webview.onDidReceiveMessage(async (data) => {
      console.log('HyperProbe: Received message:', data.type);
      switch (data.type) {
        case 'openSettings':
          vscode.commands.executeCommand('hyperprobe.openSettings');
          break;
        case 'openDocumentation':
          vscode.env.openExternal(
            vscode.Uri.parse('https://docs.hyperprobe.co'),
          );
          break;
        case 'openManagementPortal': {
          const currentServerUrl = this.tokenManager.serverUrl;
          vscode.env.openExternal(vscode.Uri.parse(currentServerUrl));
          break;
        }
        case 'login':
          vscode.commands.executeCommand('hyperprobe.login');
          break;
        case 'logout':
          vscode.commands.executeCommand('hyperprobe.signOut');
          break;
        case 'updateTokens': {
          const { accessToken } = data;
          if (accessToken) {
            await this.tokenManager.storeTokens(accessToken);
          }
          break;
        }
        case 'showError':
          vscode.window.showErrorMessage(`HyperProbe Error: ${data.message}`);
          break;
        case 'updateProbes': {
          // this.outputChannel.appendLine(`\n[onDidReceiveMessage] Received 'updateProbes' event. Total probes received: ${data.probes?.length || 0}`);
          this.probesByFile.clear();
          const incomingProbes = data.probes || [];
          for (const probe of incomingProbes) {
            const uiFilePath = String(probe.uiFilePath || '').replace(
              /\\/g,
              '/',
            );
            if (!uiFilePath) continue;

            const normalizedProbe = { ...probe, uiFilePath };

            let fileProbes = this.probesByFile.get(uiFilePath);
            if (!fileProbes) {
              fileProbes = [];
              this.probesByFile.set(uiFilePath, fileProbes);
            }
            fileProbes.push(normalizedProbe);
          }
          if (vscode.window.activeTextEditor) {
            this.updateDecorations(vscode.window.activeTextEditor);
          } else {
            // this.outputChannel.appendLine("[onDidReceiveMessage] No active text editor to update decorations on.");
          }
          break;
        }
        case 'revealLine': {
          let { filePath, lineNumber } = data;
          if (filePath && lineNumber) {
            if (!filePath.trim()) return; // Prevent empty-string glob vulnerability

            try {
              // Prevent glob injection
              if (/[*?[\]]/.test(filePath)) {
                vscode.window.showErrorMessage(
                  'HyperProbe: Invalid file path containing glob characters.',
                );
                break;
              }

              // Normalize backslashes to forward slashes for Windows
              filePath = filePath.replace(/\\/g, '/');

              const workspaceFolders = vscode.workspace.workspaceFolders;
              let targetUri: vscode.Uri | undefined;

              if (workspaceFolders) {
                // Fast path: Check all workspace roots directly
                for (const folder of workspaceFolders) {
                  const potentialUri = vscode.Uri.joinPath(
                    folder.uri,
                    filePath,
                  );
                  try {
                    await vscode.workspace.fs.stat(potentialUri);
                    targetUri = potentialUri;
                    break;
                  } catch (_e) {
                    // Not found in this root
                  }
                }
              }

              // Slow path fallback: findFiles with strict limits and common exclusions
              if (!targetUri) {
                const files = await vscode.workspace.findFiles(
                  `**/${filePath}`,
                  '{**/node_modules/**,**/dist/**,**/.git/**,**/target/**,**/build/**,**/.idea/**,**/.vscode/**}',
                  1,
                );
                if (files.length > 0) {
                  targetUri = files[0];
                }
              }

              if (targetUri) {
                const document =
                  await vscode.workspace.openTextDocument(targetUri);
                const editor = await vscode.window.showTextDocument(document);

                // Parse 1-based line number requested by webview
                const requestedLine =
                  Number.parseInt(String(lineNumber), 10) || 1;

                // Clamp line to [0, document.lineCount - 1] for VS Code API (0-based)
                const line = Math.min(
                  Math.max(0, document.lineCount - 1),
                  Math.max(0, requestedLine - 1),
                );

                // Create a range for the target line
                const targetRange = document.lineAt(line).range;

                // Select the line and scroll to it
                editor.selection = new vscode.Selection(
                  targetRange.start,
                  targetRange.end,
                );
                editor.revealRange(
                  targetRange,
                  vscode.TextEditorRevealType.InCenter,
                );
              } else {
                vscode.window.showErrorMessage(
                  `HyperProbe: Could not find file ${filePath} in workspace.`,
                );
              }
            } catch (err) {
              console.error('Failed to reveal line:', err);
              vscode.window.showErrorMessage(
                `HyperProbe Error: Failed to open file ${filePath}`,
              );
            }
          }
          break;
        }
        case 'ready':
          // Webview is ready to receive messages
          this.isWebviewReady = true;
          this.sendConfig();

          if (this.pendingNavigation) {
            this.navigateTo(this.pendingNavigation);
            this.pendingNavigation = null;
          }
          break;
        case 'confirmDelete': {
          const selection = await vscode.window.showWarningMessage(
            data.message,
            { modal: true },
            data.confirmText || 'Delete',
          );
          this.view?.webview.postMessage({
            type: 'confirmDeleteResponse',
            confirmed: selection === (data.confirmText || 'Delete'),
            msgId: data.msgId,
          });
          break;
        }
        // handle messages from webview
      }
    });
  }

  private async getLocalCommitSha(): Promise<string> {
    if (this.currentCommitSha) {
      return this.currentCommitSha;
    }

    try {
      const workspaceFolders = vscode.workspace.workspaceFolders;
      if (!workspaceFolders || workspaceFolders.length === 0) return '';
      const cwd = workspaceFolders[0].uri.fsPath;

      // 1. Attempt to use VS Code's native Git API (Fast, non-blocking)
      try {
        const gitExtension = vscode.extensions.getExtension('vscode.git');
        if (gitExtension) {
          const git = gitExtension.isActive
            ? gitExtension.exports
            : await gitExtension.activate();
          const api = git.getAPI(1);

          // Find repo matching the workspace folder, or fallback to the first available repo
          const repo =
            api.repositories.find(
              (r: GitRepository) => r.rootUri.fsPath === cwd,
            ) || (api.repositories.length > 0 ? api.repositories[0] : null);

          if (repo && repo.state.HEAD && repo.state.HEAD.commit) {
            this.currentCommitSha = repo.state.HEAD.commit;
            return repo.state.HEAD.commit;
          }
        }
      } catch (e) {
        console.warn(
          'HyperProbe: Failed to use VS Code Git API, falling back to exec',
          e,
        );
      }

      // 2. Fallback to child_process (Slower, blocking)
      const { stdout } = await execAsync('git rev-parse HEAD', { cwd });
      const commit = stdout.trim();
      this.currentCommitSha = commit;
      return commit;
    } catch (_err) {
      return ''; // Not a git repo or git not installed
    }
  }

  public async sendConfig() {
    if (!this.view) return;

    let accessToken = '';
    let refreshToken = '';
    let userEmail = '';
    if (this.isAuthenticated) {
      try {
        const tokens = await this.tokenManager.getTokens();
        const accessToken1 = tokens.accessToken;
        const refreshToken1 = tokens.refreshToken;

        if (refreshToken1 && isTokenExpired(refreshToken1)) {
          throw new Error('Session expired');
        }

        if (accessToken1) {
          const parts = accessToken1.split('.');
          if (parts.length !== 3) throw new Error('Malformed JWT');

          const payloadB64 = parts[1];
          const decoded = Buffer.from(payloadB64, 'base64url').toString(
            'utf-8',
          );
          const parsed = JSON.parse(decoded);
          userEmail = parsed.email || '';
          accessToken = accessToken1;
          refreshToken = refreshToken1 || '';
        } else {
          // If no token exists, the user is not authenticated for this URL
          this.isAuthenticated = false;
          vscode.commands.executeCommand(
            'setContext',
            'hyperprobe.isSignedIn',
            false,
          );
        }
      } catch (err) {
        console.error('Failed to decode user email from token', err);
        // Reset corrupted authentication state
        await this.tokenManager.clearTokens();
        this.isAuthenticated = false;
        vscode.commands.executeCommand(
          'setContext',
          'hyperprobe.isSignedIn',
          false,
        );
        accessToken = '';
        refreshToken = '';
      }
    }

    const localCommitSha = await this.getLocalCommitSha();

    this.view.webview.postMessage({
      type: 'configUpdated',
      serverUrl: this.tokenManager.serverUrl,
      serviceIds: this.serviceIds,
      isAuthenticated: this.isAuthenticated,
      userEmail,
      accessToken,
      refreshToken,
      localCommitSha,
    });
  }

  private getHtmlForWebview(webview: vscode.Webview): string {
    const isProduction =
      this.context.extensionMode === vscode.ExtensionMode.Production;
    const nonce = getNonce();
    const serverUrl = this.tokenManager.serverUrl;

    let serverOrigin = serverUrl;
    try {
      serverOrigin = new URL(serverUrl).origin;
    } catch (_e) {
      // Fallback to raw string
    }

    if (!isProduction) {
      return `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="Content-Security-Policy" content="default-src 'none'; style-src ${webview.cspSource} 'unsafe-inline' http://localhost:5173; script-src 'nonce-${nonce}' ${webview.cspSource} 'unsafe-eval' http://localhost:5173; img-src ${webview.cspSource} https: data: http://localhost:5173; font-src ${webview.cspSource} https: data: http://localhost:5173; connect-src ws://localhost:5173 http://localhost:5173 ${serverOrigin} ${HYPERPROBE_LICENSING_DB_URL} ${HYPERPROBE_LICENSING_PUBLIC_KEY_URL} https://*.amazonaws.com;">
</head>
<body>
    <link rel="stylesheet" id="vscode-codicon-stylesheet" href="http://localhost:5173/node_modules/@vscode/codicons/dist/codicon.css?direct">
    <div id="app"></div>
    <script type="module" src="http://localhost:5173/@vite/client"></script>
    <script type="module" src="http://localhost:5173/src/main.ts"></script>
</body>
</html>`;
    }

    const scriptUri = webview.asWebviewUri(
      vscode.Uri.joinPath(
        this.extensionUri,
        'webview-ui',
        'dist',
        'assets',
        'index.js',
      ),
    );
    const styleUri = webview.asWebviewUri(
      vscode.Uri.joinPath(
        this.extensionUri,
        'webview-ui',
        'dist',
        'assets',
        'index.css',
      ),
    );

    return `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="Content-Security-Policy" content="default-src 'none'; style-src ${webview.cspSource} 'unsafe-inline'; script-src 'nonce-${nonce}'; img-src ${webview.cspSource} https: data:; font-src ${webview.cspSource} https: data:; connect-src ${serverOrigin} ${HYPERPROBE_LICENSING_DB_URL} ${HYPERPROBE_LICENSING_PUBLIC_KEY_URL};">
    <link rel="stylesheet" type="text/css" href="${styleUri}" id="vscode-codicon-stylesheet">
</head>
<body>
    <div id="app"></div>
    <script type="module" nonce="${nonce}" src="${scriptUri}"></script>
</body>
</html>`;
  }

  private async performHealthCheck() {
    const serverUrl = this.tokenManager.serverUrl;
    if (!serverUrl) return;

    try {
      const response = await customFetch(`${serverUrl}/health`);
      if (response.ok) {
        vscode.window.showInformationMessage(
          `✅ Successfully connected to HyperProbe server at ${serverUrl}`,
        );
      } else {
        vscode.window.showErrorMessage(
          `⚠️ HyperProbe server returned status ${response.status} at ${serverUrl}`,
        );
      }
    } catch (error: any) {
      vscode.window.showErrorMessage(
        `❌ Failed to connect to HyperProbe server at ${serverUrl}: ${error.message}`,
      );
    }
  }
}

function getNonce() {
  let text = '';
  const possible =
    'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
  for (let i = 0; i < 32; i++) {
    text += possible.charAt(Math.floor(Math.random() * possible.length));
  }
  return text;
}

export function deactivate() {}
