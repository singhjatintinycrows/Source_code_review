import * as assert from 'assert';
import * as vscode from 'vscode';

suite('Extension Test Suite', () => {
  vscode.window.showInformationMessage('Start all tests.');

  test('Extension should be present', () => {
    assert.ok(
      vscode.extensions.getExtension('hyperprobe.hyperprobe-extension'),
    );
  });

  test('should activate', async () => {
    const ext = vscode.extensions.getExtension(
      'hyperprobe.hyperprobe-extension',
    )!;
    await ext.activate();
    assert.ok(ext.isActive);
  });
});
