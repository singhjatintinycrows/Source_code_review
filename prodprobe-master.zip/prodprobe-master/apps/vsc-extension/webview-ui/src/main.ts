import { createPinia } from 'pinia';
import { createApp } from 'vue';
import '@vscode-elements/elements';
import '@vscode/codicons/dist/codicon.css';
import './style.css';
import App from './App.vue';
import { router } from './router';

const pinia = createPinia();
const app = createApp(App);

app.use(pinia);
app.use(router);
app.mount('#app');
