import { createMemoryHistory, createRouter } from 'vue-router';
import ActionDetailsView from '../views/ActionDetailsView.vue';
import ActionsView from '../views/ActionsView.vue';
import InsertActionView from '../views/InsertActionView.vue';
import LogInspectorView from '../views/LogInspectorView.vue';
import LoginView from '../views/LoginView.vue';
import SettingsView from '../views/SettingsView.vue';
import SnapshotHitsView from '../views/SnapshotHitsView.vue';
import SnapshotInspectorView from '../views/SnapshotInspectorView.vue';
import SourcesView from '../views/SourcesView.vue';

const routes = [
  { path: '/', component: SourcesView },
  { path: '/actions', component: ActionsView },
  { path: '/actions/:id', component: ActionDetailsView },
  { path: '/hits', component: SnapshotHitsView },
  { path: '/hits/:id', component: SnapshotInspectorView },
  { path: '/logs/:id', component: LogInspectorView },
  { path: '/insert/:type', component: InsertActionView },
  { path: '/edit/:type/:id', component: InsertActionView },
  { path: '/settings', component: SettingsView },
  { path: '/login', component: LoginView },
];

export const router = createRouter({
  history: createMemoryHistory(),
  routes,
});
