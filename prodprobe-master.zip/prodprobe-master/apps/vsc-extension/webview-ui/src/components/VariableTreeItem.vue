<template>
  <vscode-tree-item ref="treeItemRef" :branch="isExpandable ? true : undefined">
    <div class="tree-item-content">
      <span class="var-icon" v-if="isWatchExpr">∞</span>
      <span class="var-key">{{ name }}</span>
      <span class="var-sep">&nbsp;:&nbsp;</span>
      <span class="var-type">{{ displayType }}</span>
      <span class="var-ref-label" v-if="refPath">&nbsp;[REF -> {{ refPath }}]</span>

      <span class="var-description" v-if="!(isOpen && isExpandable) && displayValue !== ''">
        <span class="var-sep">&nbsp;=&nbsp;</span>
        <span class="var-value" :class="valueClass">{{ displayValue }}</span>
      </span>
      <vscode-button
        appearance="icon"
        class="copy-btn"
        @click.stop="copyValue"
        :title="'Copy ' + name"
      >
        <span class="codicon" :class="copied ? 'codicon-check' : 'codicon-copy'"></span>
      </vscode-button>
    </div>

    <template v-if="isExpandable">
      <template v-if="isOpen">
        <VariableTreeItem v-for="(val, key) in resolvedValue" :key="key" :name="key" :value="val" :ancestorPaths="nextAncestorPaths" />
      </template>
    </template>
  </vscode-tree-item>
</template>

<script setup lang="ts">
import { resolvePath } from '@hyperprobe/constants';
import {
  computed,
  inject,
  nextTick,
  onMounted,
  onUnmounted,
  ref,
  watch,
} from 'vue';

const props = defineProps({
  name: { type: [String, Number], required: true },
  value: { type: null, required: true },
  isWatchExpr: { type: Boolean, default: false },
  ancestorPaths: { type: Array as () => string[], default: () => [] },
});

const hitPayload = inject<any>('hitPayload', null);
const resolutionCache = inject<WeakMap<any, Map<string, any>> | null>(
  'resolutionCache',
  null,
);

const treeItemRef = ref<HTMLElement | null>(null);
const isOpen = ref(false);
const copied = ref(false);

watch(isOpen, async (newVal) => {
  if (!newVal && isExpandable.value) {
    await nextTick();
    if (treeItemRef.value) {
      (treeItemRef.value as any).branch = true;
    }
  }
});
let copiedResetTimeoutId: number | null = null;
let observer: MutationObserver | null = null;

function getResolvedPath(payload: any, path: string): any {
  if (!payload || typeof payload !== 'object') return undefined;

  const cache = resolutionCache;
  if (cache) {
    let payloadCache = cache.get(payload);
    if (!payloadCache) {
      payloadCache = new Map<string, any>();
      cache.set(payload, payloadCache);
    }
    if (payloadCache.has(path)) {
      return payloadCache.get(path);
    }
    const resolved = resolvePath(payload, path);
    payloadCache.set(path, resolved);
    return resolved;
  }
  return resolvePath(payload, path);
}

// Compute if this node is a reference string
const refPath = computed(() => {
  if (typeof props.value === 'string') {
    const match = props.value.match(/^\[REF - (.+)\]$/);
    if (match) {
      return match[1];
    }
  }
  return null;
});

// Resolve reference with cycle/loop protection
const resolvedValueResult = computed(() => {
  if (!refPath.value) {
    return { value: props.value, resolved: false };
  }

  if (props.ancestorPaths.includes(refPath.value)) {
    return { value: props.value, resolved: false, cyclic: true };
  }

  const resolved = getResolvedPath(hitPayload?.value, refPath.value);
  if (resolved !== undefined) {
    return { value: resolved, resolved: true };
  }

  return { value: props.value, resolved: false };
});

const resolvedValue = computed(() => resolvedValueResult.value.value);

const nextAncestorPaths = computed(() => {
  if (refPath.value) {
    return [...props.ancestorPaths, refPath.value];
  }
  return props.ancestorPaths;
});

const copyValue = async () => {
  let textToCopy = '';

  if (resolvedValue.value === undefined) {
    textToCopy = 'undefined';
  } else if (resolvedValue.value === null) {
    textToCopy = 'null';
  } else if (
    typeof resolvedValue.value === 'string' ||
    typeof resolvedValue.value === 'number' ||
    typeof resolvedValue.value === 'boolean'
  ) {
    textToCopy = String(resolvedValue.value);
  } else if (typeof resolvedValue.value === 'object') {
    try {
      textToCopy = JSON.stringify(resolvedValue.value, null, 2);
    } catch (e) {
      textToCopy = String(resolvedValue.value);
    }
  } else {
    textToCopy = String(resolvedValue.value);
  }

  try {
    if (navigator.clipboard && navigator.clipboard.writeText) {
      await navigator.clipboard.writeText(textToCopy);
    } else {
      // Fallback for strict VS Code Webview sandboxes
      const textArea = document.createElement('textarea');
      textArea.value = textToCopy;
      textArea.style.position = 'fixed';
      textArea.style.left = '-999999px';
      textArea.style.top = '-999999px';
      document.body.appendChild(textArea);
      try {
        textArea.focus();
        textArea.select();

        const successful = document.execCommand('copy');
        if (!successful) throw new Error('execCommand copy failed');
      } finally {
        document.body.removeChild(textArea);
      }
    }

    copied.value = true;
    if (copiedResetTimeoutId !== null) {
      window.clearTimeout(copiedResetTimeoutId);
    }
    copiedResetTimeoutId = window.setTimeout(() => {
      copied.value = false;
      copiedResetTimeoutId = null;
    }, 2000);
  } catch (err) {
    console.error('Failed to copy text: ', err);
  }
};

onMounted(() => {
  if (treeItemRef.value) {
    observer = new MutationObserver((mutations) => {
      for (const mutation of mutations) {
        if (
          mutation.type === 'attributes' &&
          mutation.attributeName === 'open'
        ) {
          isOpen.value = treeItemRef.value?.hasAttribute('open') || false;
        }
      }
    });

    observer.observe(treeItemRef.value, {
      attributes: true,
      attributeFilter: ['open'],
    });

    isOpen.value = treeItemRef.value.hasAttribute('open');
  }
});

onUnmounted(() => {
  if (observer) {
    observer.disconnect();
  }
  if (copiedResetTimeoutId !== null) {
    window.clearTimeout(copiedResetTimeoutId);
  }
});

const isExpandable = computed(() => {
  return (
    typeof resolvedValue.value === 'object' &&
    resolvedValue.value !== null &&
    Object.keys(resolvedValue.value).length > 0
  );
});

const displayType = computed(() => {
  if (resolvedValue.value === undefined) return 'undefined';
  if (resolvedValue.value === null) return 'object';
  if (Array.isArray(resolvedValue.value)) return 'object';
  return typeof resolvedValue.value;
});

const displayValue = computed(() => {
  if (resolvedValue.value === undefined) return 'undefined';
  if (resolvedValue.value === null) return 'null';
  if (typeof resolvedValue.value === 'string') return resolvedValue.value;
  if (
    typeof resolvedValue.value === 'number' ||
    typeof resolvedValue.value === 'boolean'
  )
    return String(resolvedValue.value);
  if (typeof resolvedValue.value === 'object') {
    try {
      let str = JSON.stringify(resolvedValue.value);
      if (str.length > 50) return `${str.substring(0, 47)}...`;
      return str;
    } catch (e) {
      return 'Object';
    }
  }
  return String(resolvedValue.value);
});

const valueClass = computed(() => {
  if (resolvedValue.value === undefined) return 'val-undefined';
  if (typeof resolvedValue.value === 'string') return 'val-string';
  if (typeof resolvedValue.value === 'number') return 'val-number';
  if (typeof resolvedValue.value === 'boolean') return 'val-boolean';
  return 'val-string';
});
</script>

<style scoped>
.tree-item-content {
  display: flex;
  align-items: baseline;
  width: 100%;
  overflow: hidden;
  white-space: nowrap;
}

.var-icon {
  color: var(--vscode-foreground);
  margin-right: 6px;
  font-size: 14px;
  flex-shrink: 0;
}

.var-key {
  color: var(--vscode-symbolIcon-propertyForeground);
  flex-shrink: 0;
}

.var-sep {
  color: var(--vscode-foreground);
  flex-shrink: 0;
}

.var-type {
  color: var(--vscode-symbolIcon-classForeground);
  flex-shrink: 0;
}

.var-ref-label {
  color: var(--vscode-descriptionForeground);
  font-size: 11px;
  opacity: 0.8;
  margin-left: 6px;
  font-style: italic;
}

.var-description {
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  min-width: 0;
}

.val-string {
  color: var(--vscode-debugTokenExpression-string);
}

.val-number {
  color: var(--vscode-debugTokenExpression-number);
}

.val-boolean {
  color: var(--vscode-debugTokenExpression-boolean);
}

.val-undefined {
  color: var(--vscode-debugTokenExpression-value);
  opacity: 0.8;
}

.copy-btn {
  opacity: 0;
  transition: opacity 0.2s ease-in-out;
  margin-left: auto;
  padding: 0 4px;
}

.tree-item-content:hover .copy-btn,
.copy-btn:focus-visible {
  opacity: 1;
}

vscode-tree-item {
  --vscode-list-hoverBackground: transparent;
}
</style>
