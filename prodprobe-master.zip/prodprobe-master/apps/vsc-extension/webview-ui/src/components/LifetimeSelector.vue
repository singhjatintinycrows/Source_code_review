<template>
  <div class="lifetime-widget" :class="{ 'zero-error': hours === 0 && minutes === 0 }">
    <!-- Left Side: Presets Container -->
    <div class="presets-container">
      <button type="button" class="preset-btn" :class="{ active: isPresetActive(0, 10) }" @click="selectPreset(0, 10)">10m</button>
      <button type="button" class="preset-btn" :class="{ active: isPresetActive(1, 0) }" @click="selectPreset(1, 0)">1h</button>
      <button type="button" class="preset-btn" :class="{ active: isPresetActive(24, 0) }" @click="selectPreset(24, 0)">1d</button>
      <button type="button" class="preset-btn" :class="{ active: isPresetActive(168, 0) }" @click="selectPreset(168, 0)">7d</button>
      <button type="button" class="preset-btn" :class="{ active: isPresetActive(720, 0) }" @click="selectPreset(720, 0)">30d</button>
    </div>

    <!-- Vertical Separator -->
    <div class="vertical-divider"></div>

    <!-- Right Side: Large Digital Inputs -->
    <div class="digital-display">
      <div class="time-input-group">
        <input type="number" min="0" max="720" class="digital-input" :value="hours" @input="onHoursInput" :disabled="disabled" />
        <span class="time-unit">h</span>
      </div>
      <div class="display-divider"></div>
      <div class="time-input-group">
        <input type="number" min="0" max="59" class="digital-input" :value="formatMinutes(minutes)" @input="onMinutesInputDirect" :disabled="disabled || hours === 720" />
        <span class="time-unit">m</span>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
const props = defineProps<{
  hours: number;
  minutes: number;
  disabled?: boolean;
}>();

const emit = defineEmits<{
  (e: 'update:hours', val: number): void;
  (e: 'update:minutes', val: number): void;
}>();

function onHoursInput(e: any) {
  let val = parseInt(e.target.value, 10);
  if (Number.isNaN(val)) {
    emit('update:hours', 0);
    e.target.value = '0';
    return;
  }
  if (val > 720) val = 720;
  if (val < 0) val = 0;
  emit('update:hours', val);
  if (val === 720) {
    emit('update:minutes', 0);
  }
  e.target.value = val.toString();
}

function onMinutesInputDirect(e: any) {
  let val = parseInt(e.target.value, 10);
  if (Number.isNaN(val)) {
    emit('update:minutes', 0);
    e.target.value = '00';
    return;
  }
  if (props.hours === 720) {
    emit('update:minutes', 0);
    e.target.value = '00';
    return;
  }
  if (val > 59) val = 59;
  if (val < 0) val = 0;
  emit('update:minutes', val);
  e.target.value = formatMinutes(val);
}

function isPresetActive(h: number, m: number): boolean {
  return props.hours === h && props.minutes === m;
}

function selectPreset(h: number, m: number) {
  emit('update:hours', h);
  emit('update:minutes', m);
}

function formatMinutes(val: number): string {
  return val < 10 ? `0${val}` : val.toString();
}
</script>

<style scoped>
.lifetime-widget {
  display: flex;
  background-color: var(--vscode-sideBar-background, #1e1e1e);
  border: 1px solid var(--vscode-widget-border, #3c3c3c);
  border-radius: 8px;
  overflow: hidden;
  align-items: stretch;
  transition: all 0.2s ease;
}

.lifetime-widget.zero-error {
  border-color: var(--vscode-errorForeground, #f48771);
  box-shadow: 0 0 4px var(--vscode-errorForeground, #f48771);
}

.presets-container {
  flex: 1.2;
  display: flex;
  flex-direction: row;
  gap: 6px;
  padding: 8px 12px;
  align-items: center;
}

.preset-btn {
  flex: 1;
  background-color: var(--vscode-button-secondaryBackground, #2d2d2d);
  border: 1px solid var(--vscode-button-secondaryBorder, #3c3c3c);
  color: var(--vscode-button-secondaryForeground, #cccccc);
  padding: 6px 12px;
  border-radius: 4px;
  font-size: 11px;
  font-weight: 500;
  cursor: pointer;
  text-align: center;
  transition: all 0.15s ease;
  user-select: none;
}

.preset-btn:hover {
  background-color: var(--vscode-button-secondaryHoverBackground, #3c3c3c);
  color: #ffffff;
}

.preset-btn.active {
  border-color: var(--vscode-focusBorder, #007acc);
  background-color: var(--vscode-button-background, #007acc);
  color: var(--vscode-button-foreground, #ffffff);
  box-shadow: 0 0 4px var(--vscode-focusBorder, #007acc);
}

.vertical-divider {
  width: 1px;
  background-color: var(--vscode-widget-border, #3c3c3c);
  align-self: stretch;
}

.digital-display {
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 8px 16px 8px 0;
  gap: 8px;
}

.time-input-group {
  display: flex;
  align-items: flex-end;
  gap: 2px;
}

.digital-input {
  font-size: 20px;
  font-weight: bold;
  color: var(--vscode-settings-headerForeground, #ffffff);
  background: transparent;
  border: none;
  outline: none;
  max-width: 42px;
  text-align: right;
  font-family: monospace;
}

/* Remove spin buttons from number inputs */
.digital-input::-webkit-outer-spin-button,
.digital-input::-webkit-inner-spin-button {
  -webkit-appearance: none;
  margin: 0;
}
.digital-input {
  -moz-appearance: textfield;
}

.time-unit {
  font-size: 12px;
  font-weight: 500;
  color: var(--vscode-descriptionForeground, #858585);
  padding-bottom: 6px;
  user-select: none;
}

.display-divider {
  width: 1px;
  height: 24px;
  background-color: var(--vscode-widget-border, #3c3c3c);
}

@media (max-width: 400px) {
  .lifetime-widget {
    flex-direction: column;
    align-items: stretch;
  }

  .vertical-divider {
    width: auto;
    height: 1px;
    align-self: stretch;
  }

  .presets-container {
    flex: none;
    padding: 8px;
    gap: 4px;
  }

  .preset-btn {
    padding: 6px 4px;
    font-size: 10px;
  }

  .digital-display {
    padding: 8px;
    justify-content: center;
  }
}
</style>