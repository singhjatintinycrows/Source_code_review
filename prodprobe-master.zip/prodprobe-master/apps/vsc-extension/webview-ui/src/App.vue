<template>
  <div class="app-shell">
    <template v-if="agentStore.isAuthenticated">
      <!-- Linear Loader (Positioned absolutely or immediately below the context header) -->
      <vscode-progress-bar class="loader-bar" v-if="isLoading"></vscode-progress-bar>

      <!-- Main Brand Header -->
      <header class="app-header">
        <div class="brand">
          <span class="logo">
            <img :src="htLogoUrl" alt="HyperProbe Logo" style="width: 24px; height: 24px; margin-right: 2px;">
          </span>
          <span class="title">HyperProbe</span>
        </div>
        <div class="actions" style="position: relative;">
          <vscode-button appearance="icon" icon="add" title="Add Action" @click.stop="toggleAddMenu"></vscode-button>

          <div v-if="showAddMenu" class="popup-menu add-menu">
            <div class="menu-group">ACTIONS</div>
            <div class="menu-item" @click="goInsert('log')"><span class="codicon codicon-list-flat log-color"></span>
              Log
            </div>
            <div class="menu-item" @click="goInsert('snapshot')"><span
                class="codicon codicon-device-camera snap-color"></span>
              Snapshot</div>
            <div class="menu-divider"></div>
            <div class="menu-group">METRICS</div>
            <div class="menu-item disabled" title="Coming soon"><span
                class="codicon codicon-symbol-number metric-color"></span> Counter</div>
            <div class="menu-item disabled" title="Coming soon"><span class="codicon codicon-watch metric-color"></span>
              Tic & Toc</div>
            <div class="menu-item disabled" title="Coming soon"><span
                class="codicon codicon-graph-line metric-color"></span> Custom Metric</div>
          </div>

        <vscode-button appearance="icon" icon="filter" title="Filter" @click.stop="toggleFilterMenu"></vscode-button>
        <div v-if="showFilterMenu" class="popup-menu add-menu">
          <div class="menu-group">FILTER BY CREATOR</div>
          <div class="menu-item" style="padding: 2px 14px" @click.stop="toggleCreatedByMe">
            <vscode-checkbox :checked="createdByMe"></vscode-checkbox>
            Created by me
          </div>
        </div>

        <vscode-button appearance="icon" icon="ellipsis" title="More Actions"
          @click.stop="toggleSettingsMenu"></vscode-button>

        <div v-if="showSettingsMenu" class="popup-menu settings-menu">
          <div class="menu-item" @click="goSettings"><span class="codicon codicon-settings"></span> Settings</div>
          <div class="menu-item" @click="openDocumentation"><span class="codicon codicon-book"></span> Documentation</div>
          <!-- <div class="menu-item"><span class="codicon codicon-comment-discussion"></span> Feedback</div> -->
          <div class="menu-item" @click="openManagementPortal"><span class="codicon codicon-link-external"></span> Management portal</div>
        </div>

          <!-- <div class="status-badge" @mouseenter="onServerInfoEnter" @mouseleave="onServerInfoLeave">
          FL <span class="codicon codicon-pass-filled status-ok"></span>
        </div> -->
        </div>

        <!-- Server Info Tooltip -->
      <div v-if="showServerInfo" class="server-info-tooltip">
        <div class="info-row"><strong>v{{ extensionVersion }}</strong></div>
        <div class="info-row">Server URL: https://app.hyperprobe.com</div>
        <div class="info-row">Company: default-tenant</div>
        <div class="info-row">Licensed Agents: 2</div>
        <div class="info-row">License Expiry: 2030-01-01</div>
      </div>
    </header>

    <!-- License Banners -->
    <div v-if="licenseStore.status === 'LOCKED'" class="license-banner error">
      License Expired. The system is currently locked. Please update your license in the Dashboard.
    </div>
    <div v-else-if="licenseStore.status === 'REVOKED'" class="license-banner error">
      Cloning Detected - Contact Support immediately. The system is locked.
    </div>
    <div v-else-if="licenseStore.upgradeRequired" class="license-banner warning">
      Upgrade Required: Agent limit ({{ licenseStore.maxAgents }}) reached. New agents will be rejected.
    </div>

    <div class="main-content" v-if="isInsertRoute || isHitRoute || isSettingsRoute || isActionDetailsRoute">
      <router-view></router-view>
    </div>

      <div v-else class="tab-container">
        <!-- Universal Filter Bar -->
        <div class="universal-filter-bar">
          <div class="search-container">
            <vscode-textfield
              placeholder="Filter agents, actions, or hits... (e.g. 'staging' or 'environment: staging')"
              class="universal-search-input" :value="filterStore.searchQuery" @input="onSearchInput"
              @keydown.enter="onSearchEnter" @click.stop="showAutocomplete = true">
              <span slot="content-before" class="codicon codicon-search"></span>
              <span slot="content-after" class="codicon codicon-close clear-search" v-if="filterStore.searchQuery"
                @click="clearSearch" style="cursor: pointer;"></span>
            </vscode-textfield>

            <!-- Autocomplete Suggestions -->
            <div class="autocomplete-dropdown"
              v-if="showAutocomplete && suggestedTags.length > 0 && filterStore.searchQuery" @click.stop>
              <div class="suggestion-item" v-for="tag in suggestedTags" :key="tag.type + tag.value"
                @click="addTag(tag)">
                <span class="tag-type">{{ tag.type }}:</span> <span class="tag-value">{{ tag.value }}</span>
              </div>
            </div>
          </div>

          <!-- Active Tags -->
          <div class="active-tags" v-if="filterStore.activeTags.length > 0">
            <div class="filter-tag" v-for="tag in filterStore.activeTags" :key="tag.type + tag.value">
              <span class="tag-label"><b>{{ tag.type }}:</b> {{ tag.value }}</span>
              <span class="codicon codicon-close remove-tag" @click="filterStore.removeTag(tag.type, tag.value)"></span>
            </div>
            <span class="clear-all-tags" @click="filterStore.clearAllTags()">Clear all</span>
          </div>
        </div>

        <vscode-tabs :selected-index="activeTabIndex" @vsc-tabs-select="onTabSelect" class="main-tabs">
          <vscode-tab-header slot="header">Live Agents</vscode-tab-header>
          <vscode-tab-panel>
            <router-view v-if="currentTab === 'sources'"></router-view>
          </vscode-tab-panel>

          <vscode-tab-header slot="header">Actions</vscode-tab-header>
          <vscode-tab-panel>
            <router-view v-if="currentTab === 'actions'"></router-view>
          </vscode-tab-panel>

          <vscode-tab-header slot="header">Snapshot Hits</vscode-tab-header>
          <vscode-tab-panel>
            <router-view v-if="currentTab === 'hits'"></router-view>
          </vscode-tab-panel>
        </vscode-tabs>
      </div>

      <!-- Bottom Bar -->
      <div class="bottom-bar">
        <div class="user-info">
          <span class="codicon codicon-account"></span> {{ agentStore.userEmail }}
        </div>
        <span>v{{ extensionVersion }}</span>
      </div>
    </template>

    <template v-else>
      <router-view></router-view>
    </template>
  </div>
</template>

<script setup lang="ts">
import { storeToRefs } from 'pinia';
import { computed, onMounted, onUnmounted, ref, watch } from 'vue';
import { useRoute, useRouter } from 'vue-router';
import { useActionStore } from './stores/actionStore';
import { useAgentStore } from './stores/agentStore';
import { type FilterTag, useFilterStore } from './stores/filterStore';
import { useLicenseStore } from './stores/licenseStore';
import type { Config } from './utils/types';
import { vscode } from './utils/vscode';

const htLogoUrl = new URL('../../images/ht-logo.png', import.meta.url).href;

const router = useRouter();
const route = useRoute();
const agentStore = useAgentStore();
const actionStore = useActionStore();
const licenseStore = useLicenseStore();
const filterStore = useFilterStore();

const extensionVersion = import.meta.env.VITE_EXTENSION_VERSION || 'unknown';

const currentTab = ref('sources');
const showAddMenu = ref(false);
const showFilterMenu = ref(false);
const showSettingsMenu = ref(false);
const showServerInfo = ref(false);
const showAutocomplete = ref(false);
const isLoading = computed(() => agentStore.isLoading || actionStore.isLoading);

const { createdByMe } = storeToRefs(filterStore);

const isStandaloneSettings = ref(false);

const isInsertRoute = computed(
  () => route.path.startsWith('/insert') || route.path.startsWith('/edit'),
);
const isHitRoute = computed(
  () =>
    (route.path.startsWith('/hits/') || route.path.startsWith('/logs/')) &&
    route.params.id,
);
const isSettingsRoute = computed(() => route.path.startsWith('/settings'));
const isActionDetailsRoute = computed(() => route.path.startsWith('/actions/'));

watch(
  () => route.path,
  (newPath) => {
    if (newPath === '/') {
      currentTab.value = 'sources';
    } else if (newPath.startsWith('/actions')) {
      currentTab.value = 'actions';
    } else if (newPath.startsWith('/hits')) {
      currentTab.value = 'hits';
    }
  },
);

const activeTabIndex = computed(() => {
  if (currentTab.value === 'sources') return 0;
  if (currentTab.value === 'actions') return 1;
  if (currentTab.value === 'hits') return 2;
  return 0;
});

const onTabSelect = (event: any) => {
  const index = event.detail.selectedIndex;
  if (index === 0) {
    currentTab.value = 'sources';
    router.push('/');
  } else if (index === 1) {
    currentTab.value = 'actions';
    router.push('/actions');
  } else if (index === 2) {
    currentTab.value = 'hits';
    router.push('/hits');
  }
};

function toggleAddMenu() {
  showAddMenu.value = !showAddMenu.value;
  showSettingsMenu.value = false;
  showFilterMenu.value = false;
  showServerInfo.value = false;
}

function toggleFilterMenu() {
  showFilterMenu.value = !showFilterMenu.value;
  showAddMenu.value = false;
  showSettingsMenu.value = false;
  showServerInfo.value = false;
}

function toggleSettingsMenu() {
  showSettingsMenu.value = !showSettingsMenu.value;
  showAddMenu.value = false;
  showFilterMenu.value = false;
  showServerInfo.value = false;
}

function goInsert(type: string) {
  showAddMenu.value = false;
  router.push(`/insert/${type}`);
}

function goSettings() {
  showSettingsMenu.value = false;
  if (vscode.isAvailable) {
    vscode.postMessage({ type: 'openSettings' });
  } else {
    router.push('/settings');
  }
}

function openDocumentation() {
  showSettingsMenu.value = false;
  if (vscode.isAvailable) {
    vscode.postMessage({ type: 'openDocumentation' });
  } else {
    window.open('https://docs.hyperprobe.co', '_blank');
  }
}

function openManagementPortal() {
  showSettingsMenu.value = false;
  if (vscode.isAvailable) {
    vscode.postMessage({ type: 'openManagementPortal' });
  } else {
    window.open(agentStore.serverUrl, '_blank');
  }
}

function closeMenus(e: Event) {
  const target = e.target as HTMLElement;
  if (!target.closest('.actions')) {
    showAddMenu.value = false;
    showSettingsMenu.value = false;
    showFilterMenu.value = false;
  }
  if (!target.closest('.search-container')) {
    showAutocomplete.value = false;
  }
}

// let hoverTimer: number | null = null;

// function onServerInfoEnter() {
//   if (hoverTimer) clearTimeout(hoverTimer);
//   hoverTimer = window.setTimeout(() => {
//     if (!showAddMenu.value && !showSettingsMenu.value) {
//       showServerInfo.value = true;
//     }
//   }, 1000);
// }

// function onServerInfoLeave() {
//   if (hoverTimer) {
//     clearTimeout(hoverTimer);
//     hoverTimer = null;
//   }
//   showServerInfo.value = false;
// }

onMounted(() => {
  document.addEventListener('click', closeMenus);

  if (document.body.getAttribute('data-mode') === 'settings') {
    isStandaloneSettings.value = true;
    router.push('/settings');
  }

  // Handle messages from the extension
  window.addEventListener('message', (event) => {
    const message = event.data as Config & { type: string; path?: string };
    if (message.type === 'configUpdated') {
      agentStore.setConfig({
        serverUrl: message.serverUrl,
        serviceIds: message.serviceIds,
        isAuthenticated: message.isAuthenticated,
        userEmail: message.userEmail,
        accessToken: message.accessToken,
        refreshToken: message.refreshToken,
        localCommitSha: message.localCommitSha,
      });

      // Probes are fetched via polling and reactive watchers (serviceIds/localCommitSha); avoid duplicating fetches here.
    } else if (message.type === 'navigate' && message.path) {
      router.push(message.path);
    }
  });

  watch(
    () => agentStore.isAuthenticated,
    (newVal) => {
      if (newVal) {
        if (route.path === '/login') {
          router.push('/');
        }
        agentStore.startPolling();
        actionStore.startPolling();
        licenseStore.startPolling();
      } else {
        router.push('/login');
        agentStore.stopPolling();
        actionStore.stopPolling();
        licenseStore.stopPolling();
      }
    },
    { immediate: true },
  );

  watch(
    () => agentStore.serviceIds,
    (newIds) => {
      if (newIds && newIds.length > 0 && agentStore.isAuthenticated) {
        actionStore.fetchActions();
      }
    },
    { deep: true },
  );

  watch(
    () => agentStore.localCommitSha,
    (newSha, oldSha) => {
      // If the local branch changes, re-fetch to update status flags
      if (newSha !== oldSha && agentStore.isAuthenticated) {
        actionStore.fetchActions();
      }
    },
  );

  // Signal ready to extension to receive initial config
  if (vscode.isAvailable) {
    vscode.postMessage({ type: 'ready' });
  } else {
    // For local web testing without VSCode
    console.error(
      'VSCode is not available, please open the extension in VSCode to use it.',
    );
  }
});

// Search and Tag Logic
const suggestedTags = computed(() => {
  const query = filterStore.searchQuery.toLowerCase().trim();
  if (!query) return [];

  // If query is formatted like "type: value"
  if (query.includes(':')) {
    const [type, ...valParts] = query.split(':');
    const val = valParts.join(':').trim();
    if (type && val) {
      return [{ type: type.trim(), value: val }];
    }
  }

  const matches: FilterTag[] = [];
  const uniqueValues = new Set<string>();

  // Helper to add if unique
  const addMatch = (type: string, value: string) => {
    const key = `${type}:${value}`;
    if (!uniqueValues.has(key) && value.toLowerCase().includes(query)) {
      uniqueValues.add(key);
      matches.push({ type, value });
    }
  };

  // Scan currently known agents for suggestions
  agentStore.agents.forEach((a) => {
    addMatch('environment', a.environment);
    addMatch('serviceId', a.serviceId);

    const serviceName = agentStore.serviceNames[a.serviceId];
    if (serviceName && serviceName !== a.serviceId) {
      addMatch('serviceName', serviceName);
    }

    addMatch('commitSha', a.commitSha);
  });

  return matches.slice(0, 10); // Max 10 suggestions
});

function onSearchInput(e: any) {
  filterStore.setSearchQuery(e.target.value);
  showAutocomplete.value = true;
}

function toggleCreatedByMe() {
  filterStore.setCreatedByMe(!createdByMe.value);
}

function clearSearch() {
  filterStore.setSearchQuery('');
  showAutocomplete.value = false;
}

function onSearchEnter(_e: any) {
  const query = filterStore.searchQuery.trim();
  if (!query) return;

  // If there's an exact match in suggestions, pick the first one
  if (suggestedTags.value.length > 0) {
    addTag(suggestedTags.value[0]);
  } else if (query.includes(':')) {
    const [type, ...valParts] = query.split(':');
    const val = valParts.join(':').trim();
    addTag({ type: type.trim(), value: val });
  }
}

function addTag(tag: FilterTag) {
  filterStore.addTag(tag.type, tag.value);
  showAutocomplete.value = false;
}

onUnmounted(() => {
  document.removeEventListener('click', closeMenus);
  agentStore.stopPolling();
  actionStore.stopPolling();
  licenseStore.stopPolling();
});
</script>

<style scoped>
.app-shell {
  display: flex;
  flex-direction: column;
  height: 100vh;
  width: 100vw;
  overflow: hidden;
}

/* License Banners */
.license-banner {
  padding: 6px 12px;
  font-size: 12px;
  text-align: center;
  font-weight: 600;
  width: 100%;
}
.license-banner.error {
  background-color: var(--vscode-errorForeground);
  color: white;
}
.license-banner.warning {
  background-color: var(--vscode-charts-orange);
  color: white;
}

/* Top Context Header */
.top-context-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 6px 12px;
  background-color: var(--vscode-editorWidget-background);
  font-size: 11px;
}

.data-delay {
  display: flex;
  align-items: center;
  gap: 6px;
  color: var(--vscode-descriptionForeground);
}

.delay-icon {
  font-size: 14px;
}

.refresh-btn {
  height: 22px;
  padding: 0 8px;
  font-size: 11px;
  display: flex;
  align-items: center;
  gap: 4px;
}

.refresh-btn .codicon {
  font-size: 12px;
}

/* Loader Bar */
.loader-bar {
  width: 100%;
}

/* Main Header */
.app-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 10px 12px;
  border-bottom: 1px solid var(--vscode-panel-border);
  position: relative;
  background-color: var(--vscode-editor-background);
}

.brand {
  display: flex;
  align-items: center;
  gap: 8px;
  font-weight: 600;
  font-size: 16px;
}

.logo {
  color: var(--vscode-charts-blue);
  font-size: 18px;
}

.actions {
  display: flex;
  align-items: center;
  gap: 4px;
}

.status-badge {
  display: flex;
  align-items: center;
  gap: 4px;
  background-color: var(--vscode-badge-background);
  padding: 2px 6px;
  border-radius: 4px;
  font-size: 11px;
  font-weight: bold;
  margin-left: 4px;
}

.status-ok {
  color: var(--vscode-testing-iconPassed);
  font-size: 12px;
}

/* Menus & Tooltips */
.popup-menu {
  position: absolute;
  top: 30px;
  background-color: var(--vscode-editorWidget-background);
  border: 1px solid var(--vscode-widget-border);
  box-shadow: 0 4px 8px var(--vscode-widget-shadow);
  border-radius: 4px;
  z-index: 100;
  min-width: 160px;
  padding: 4px 0;
}

.add-menu {
  right: 70px;
}

.settings-menu {
  right: 40px;
}

.menu-group {
  font-size: 10px;
  font-weight: bold;
  color: var(--vscode-descriptionForeground);
  padding: 4px 12px;
  margin-top: 4px;
}

.menu-item {
  padding: 6px 12px;
  cursor: pointer;
  display: flex;
  align-items: center;
  gap: 8px;
  font-size: 12px;
}

.menu-item:hover:not(.disabled) {
  background-color: var(--vscode-list-hoverBackground);
}

.menu-item.disabled {
  opacity: 0.5;
  cursor: not-allowed;
}

.menu-divider {
  height: 1px;
  background-color: var(--vscode-menu-separatorBackground);
  margin: 4px 0;
}

.server-info-tooltip {
  position: absolute;
  top: 100%;
  right: 12px;
  background-color: var(--vscode-editorWidget-background);
  border: 1px solid var(--vscode-widget-border);
  box-shadow: 0 4px 8px var(--vscode-widget-shadow);
  padding: 8px 12px;
  border-radius: 4px;
  z-index: 200;
  font-size: 12px;
  min-width: 250px;
}

.info-row {
  margin-bottom: 4px;
}

.log-color {
  color: var(--vscode-charts-orange);
}

.snap-color {
  color: var(--vscode-charts-blue);
}

.metric-color {
  color: var(--vscode-charts-green);
}

/* Layout components */
vscode-tabs {
  flex: 1;
  display: flex;
  flex-direction: column;
  min-height: 0;
}

vscode-tab-panel {
  flex: 1;
  padding: 0;
  overflow: hidden;
  height: 100%;
}

.main-content {
  display: flex;
  flex-direction: column;
  flex: 1;
  min-height: 0;
  overflow: hidden;
}

/* Universal Filter UI */
.tab-container {
  display: flex;
  flex-direction: column;
  flex: 1;
  overflow: hidden;
}

.universal-filter-bar {
  padding: 10px 12px;
  background-color: var(--vscode-editor-background);
  border-bottom: 1px solid var(--vscode-panel-border);
  display: flex;
  flex-direction: column;
  gap: 8px;
}

.search-container {
  position: relative;
  width: 100%;
}

.universal-search-input {
  width: 100%;
}

.clear-search:hover {
  color: var(--vscode-errorForeground);
}

.autocomplete-dropdown {
  position: absolute;
  top: calc(100% + 4px);
  left: 0;
  right: 0;
  background-color: var(--vscode-dropdown-background);
  border: 1px solid var(--vscode-dropdown-border);
  border-radius: 4px;
  z-index: 100;
  max-height: 200px;
  overflow-y: auto;
  box-shadow: 0 4px 8px var(--vscode-widget-shadow);
}

.suggestion-item {
  padding: 6px 12px;
  cursor: pointer;
  display: flex;
  gap: 8px;
  font-size: 12px;
  color: var(--vscode-dropdown-foreground);
}

.suggestion-item:hover {
  background-color: var(--vscode-list-hoverBackground);
}

.tag-type {
  color: var(--vscode-charts-orange);
  font-weight: 600;
}

.active-tags {
  display: flex;
  flex-wrap: wrap;
  gap: 6px;
  align-items: center;
}

.filter-tag {
  display: flex;
  align-items: center;
  gap: 6px;
  background-color: var(--vscode-badge-background);
  color: var(--vscode-badge-foreground);
  padding: 2px 8px;
  border-radius: 12px;
  font-size: 11px;
}

.tag-label b {
  font-weight: 600;
  opacity: 0.8;
}

.remove-tag {
  font-size: 10px;
  cursor: pointer;
  opacity: 0.7;
}

.remove-tag:hover {
  opacity: 1;
}

.clear-all-tags {
  font-size: 10px;
  color: var(--vscode-textLink-foreground);
  cursor: pointer;
  margin-left: 4px;
}

.clear-all-tags:hover {
  text-decoration: underline;
}

/* Bottom Bar */
.bottom-bar {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 2px 8px;
  background-color: var(--vscode-statusBar-background);
  color: var(--vscode-statusBar-foreground);
  font-size: 14px;
  border-top: 1px solid var(--vscode-statusBar-border, transparent);
  flex-shrink: 0;
}

.user-info {
  display: flex;
  align-items: center;
  gap: 4px;
}
</style>
