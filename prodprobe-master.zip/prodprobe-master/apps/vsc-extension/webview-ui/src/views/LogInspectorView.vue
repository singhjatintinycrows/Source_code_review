<template>
  <div class="inspector-container">
    <div v-if="loading" class="not-found">
      <div class="header-left">
        <vscode-button appearance="icon" @click="goBack" class="back-btn">
          <span class="codicon codicon-chevron-left"></span>
        </vscode-button>
      </div>
      <div>Loading logs...</div>
    </div>
    <div v-else-if="allActionHits.length === 0" class="not-found">
      <div class="header-left">
        <vscode-button appearance="icon" @click="goBack" class="back-btn">
          <span class="codicon codicon-chevron-left"></span>
        </vscode-button>
      </div>
      <div>No logs found for this probe.</div>
    </div>
    <div v-else class="inspector-content">

      <!-- Header -->
      <div class="inspector-header">
        <div class="header-left">
          <vscode-button appearance="icon" @click="goBack" class="back-btn">
            <span class="codicon codicon-chevron-left"></span>
          </vscode-button>
          <span class="codicon codicon-list-flat log-color hit-icon"></span>
          <span class="hit-title">{{ probeDetails?.uiFilePath || 'Unknown' }}:{{ probeDetails?.uiLineNumber || 0
            }}</span>
          <span class="codicon codicon-pass-filled status-active"></span>
        </div>
        <div class="header-meta">
          <span class="meta-label">Source</span>
          <span class="meta-value agent-name" :title="agentName">{{ agentName }}</span>
        </div>

        <div v-if="showMoreInfo && probeDetails" class="extended-meta">
          <div class="meta-row">
            <span class="meta-label">Action ID</span>
            <span class="meta-value">{{ route.params.id }}</span>
          </div>
          <div class="meta-row">
            <span class="meta-label">Created by</span>
            <span class="meta-value">you@example.com</span>
          </div>
          <div class="meta-row">
            <span class="meta-label">Hit limit</span>
            <span class="meta-value">{{ probeDetails?.hitLimit || 0 }}</span>
          </div>
          <div class="meta-row">
            <span class="meta-label">Status</span>
            <span class="meta-value">{{ displayStatus }}</span>
          </div>
          <div class="meta-row">
            <span class="meta-label">Expiry</span>
            <span class="meta-value">{{ getFormattedExpiry(probeDetails.createdAt, probeDetails.expiryTime) }}</span>
          </div>
          <div class="meta-row">
            <span class="meta-label">Log to Stdout</span>
            <span class="meta-value">{{ probeDetails?.shouldLogToStdout ? 'Enabled' : 'Disabled' }} ({{ probeDetails?.logLevel || 'INFO' }})</span>
          </div>
          <div class="meta-row">
            <span class="meta-label">Condition</span>
            <span class="meta-value">{{ probeDetails?.condition || 'N/A' }}</span>
          </div>
          <div class="meta-row">
            <span class="meta-label">Commit SHA</span>
            <span class="meta-value">{{ probeDetails?.commitSha || 'N/A' }}</span>
          </div>
          <div class="meta-row">
            <span class="meta-label">Action created at</span>
            <span class="meta-value">{{ formatDateTime(probeDetails?.createdAt) || 'N/A' }}</span>
          </div>
        </div>

        <div class="header-action">
          <a href="#" class="show-more-link" @click.prevent="showMoreInfo = !showMoreInfo">
            {{ showMoreInfo ? 'Show less' : 'Show more' }}
          </a>
        </div>
      </div>

      <!-- The Log Feed -->
      <div class="log-feed">
        <div class="log-feed-header">
          <span class="feed-title">LOG STREAM ({{ allActionHits.length }})</span>
          <!-- <vscode-button appearance="secondary" class="clear-btn">
            <span class="codicon codicon-clear-all"></span> Clear
          </vscode-button> -->
        </div>
        <div class="log-entries-container" ref="logContainerRef">
          <div v-for="log in sortedLogs" :key="log.id" class="log-entry">
            <div class="log-timestamp">{{ formatTime(log.capturedAt) }}</div>
            <div class="log-message" :class="{ 'log-error': log.message?.startsWith('[Error') }">{{ log.message }}</div>
          </div>
        </div>
      </div>

    </div>
  </div>
</template>

<script setup lang="ts">
import {
  computed,
  nextTick,
  onMounted,
  onUnmounted,
  ref,
  shallowRef,
} from 'vue';
import { useRoute, useRouter } from 'vue-router';
import { useActionStore } from '../stores/actionStore';
import { useAgentStore } from '../stores/agentStore';
import { formatDateTime, getEffectiveStatus } from '../utils/dateFormatter';
import getFormattedExpiry from '../utils/getFormattedExpiry';
import { getAppTrpcClient } from '../utils/trpc';

const router = useRouter();
const route = useRoute();
const agentStore = useAgentStore();
const actionStore = useActionStore();

const allActionHits = shallowRef<any[]>([]);
const loading = ref(true);
const showMoreInfo = ref(false);
let pollTimeout: any = null;
let isMounted = false;

const logContainerRef = ref<HTMLElement | null>(null);

const probeDetails = computed(() => {
  return actionStore.actions.find((a: any) => a.id === route.params.id) || null;
});

const displayStatus = computed(() => {
  if (!probeDetails.value) return 'Unknown';
  return getEffectiveStatus(
    probeDetails.value.status,
    probeDetails.value.expiryTime,
  );
});

const agentName = computed(() => {
  const serviceId =
    probeDetails.value?.serviceId || allActionHits.value[0]?.serviceId;
  if (!serviceId) return 'Unknown';
  return agentStore.serviceNames[serviceId] || serviceId;
});

const sortedLogs = computed(() => {
  // Reverse the array so the oldest is at the top, and newest appends at the bottom (like a terminal)
  return [...allActionHits.value].reverse();
});

async function fetchLogs() {
  const probeId = route.params.id as string;
  if (!probeId) return;
  const client = getAppTrpcClient(agentStore.serverUrl);
  try {
    const newLogs = await client.listLogs.query({ probeId });

    if (!isMounted) return;

    // Check if user is near bottom BEFORE replacing array
    let isNearBottom = false;
    if (logContainerRef.value) {
      const el = logContainerRef.value;
      isNearBottom =
        Math.abs(el.scrollHeight - el.scrollTop - el.clientHeight) < 30;
    }

    const wasEmpty = allActionHits.value.length === 0;
    allActionHits.value = newLogs;

    // Only auto-scroll if it was empty (initial load) OR if user was already near the bottom
    if (wasEmpty || isNearBottom) {
      nextTick(() => {
        if (logContainerRef.value) {
          logContainerRef.value.scrollTop = logContainerRef.value.scrollHeight;
        }
      });
    }
  } catch (err) {
    console.error('Failed to fetch logs:', err);
  }
}

async function pollLogs() {
  await fetchLogs();
  if (isMounted) {
    pollTimeout = setTimeout(pollLogs, 2000);
  }
}

onMounted(async () => {
  isMounted = true;
  await pollLogs();
  if (isMounted) {
    loading.value = false;
  }
});

onUnmounted(() => {
  isMounted = false;
  if (pollTimeout) clearTimeout(pollTimeout);
});

function formatTime(isoString: string) {
  try {
    const d = new Date(isoString);
    return (
      d.toLocaleTimeString([], {
        hour12: false,
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit',
      }) +
      '.' +
      String(d.getMilliseconds()).padStart(3, '0')
    );
  } catch (e) {
    return '00:00:00.000';
  }
}

function goBack() {
  router.push('/hits');
}
</script>

<style scoped>
.inspector-container {
  display: flex;
  flex-direction: column;
  height: 100%;
  min-height: 0;
  background-color: var(--vscode-editor-background);
}

.not-found {
  padding: 20px;
  text-align: center;
  color: var(--vscode-errorForeground);
}

.inspector-content {
  display: flex;
  flex-direction: column;
  flex: 1;
  min-height: 0;
}

.inspector-header {
  padding: 12px;
  background-color: var(--vscode-editorWidget-background);
  border-bottom: 1px solid var(--vscode-panel-border);
  flex-shrink: 0;
}

.header-left {
  display: flex;
  align-items: center;
  gap: 8px;
  margin-bottom: 8px;
}

.hit-icon.log-color {
  color: var(--vscode-charts-orange);
}

.hit-title {
  font-family: var(--vscode-editor-font-family);
  font-size: 14px;
  font-weight: 600;
  color: var(--vscode-textLink-foreground);
}

.status-active {
  color: var(--vscode-charts-blue);
  font-size: 12px;
}

.header-meta {
  display: flex;
  align-items: center;
  gap: 8px;
  padding-left: 32px;
  margin-bottom: 8px;
}

.show-more-link {
  padding-left: 32px;
  color: var(--vscode-textLink-foreground);
  text-decoration: none;
  font-size: 12px;
}

.extended-meta {
  display: flex;
  flex-direction: column;
  gap: 4px;
  padding-left: 32px;
  margin-bottom: 8px;
}

.extended-meta .meta-row {
  display: flex;
  gap: 8px;
  justify-content: flex-start;
}

.extended-meta .meta-label {
  width: 100px;
  color: var(--vscode-descriptionForeground);
}

.meta-value {
  color: var(--vscode-foreground);
}

.agent-name {
  max-width: 250px;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

.log-feed {
  display: flex;
  flex-direction: column;
  flex-grow: 1;
  overflow: hidden;
}

.log-feed-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 6px 12px;
  background-color: var(--vscode-sideBarSectionHeader-background);
  border-bottom: 1px solid var(--vscode-sideBarSectionHeader-border);
}

.feed-title {
  font-weight: 600;
  font-size: 11px;
  text-transform: uppercase;
  color: var(--vscode-sideBarTitle-foreground);
}

/* .clear-btn {
  height: 22px;
} */

.log-entries-container {
  flex-grow: 1;
  overflow-y: auto;
  padding: 8px 0;
  background-color: var(--vscode-editor-background);
  font-family: var(--vscode-editor-font-family);
  font-size: 12px;
}

.log-entry {
  display: flex;
  padding: 2px 12px;
  line-height: 1.5;
}

.log-entry:hover {
  background-color: var(--vscode-list-hoverBackground);
}

.log-timestamp {
  color: var(--vscode-descriptionForeground);
  margin-right: 12px;
  user-select: none;
  flex-shrink: 0;
}

.log-message {
  color: var(--vscode-foreground);
  white-space: pre-wrap;
  word-break: break-all;
}

.log-error {
  color: var(--vscode-errorForeground);
  font-weight: bold;
}
</style>
