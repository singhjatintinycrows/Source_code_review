<template>
  <div class="view-container">
    <div class="toolbar">
      <vscode-button appearance="icon" title="Refresh" @click="agentStore.refreshAll()">
        <span class="codicon codicon-refresh"></span>
      </vscode-button>
      <vscode-button appearance="icon" :title="allExpanded ? 'Collapse All' : 'Expand All'" @click="toggleAll">
        <span class="codicon" :class="allExpanded ? 'codicon-collapse-all' : 'codicon-expand-all'"></span>
      </vscode-button>
    </div>

    <div class="agent-count" v-if="agentStore.serviceIds.length > 0">
      {{ filteredAgents.length }} agent{{ filteredAgents.length !== 1 ? 's' : '' }}
    </div>

    <div class="tree-container" v-if="agentStore.serviceIds.length > 0">
      <vscode-tree ref="treeRef">
        <vscode-tree-item v-for="(envs, serviceId) in deepGroupedFiltered" :key="serviceId" open class="env-item">
          <span slot="decorations" class="env-decorations">
            <span class="env-badge">{{ serviceId }}</span>
          </span>
          {{ agentStore.serviceNames[serviceId] }} - {{ serviceId }}

          <vscode-tree-item v-for="(commits, envName) in envs" :key="envName" open class="agents-folder">
            ENVIRONMENT: {{ envName }}

            <vscode-tree-item v-for="(agents, commitSha) in commits" :key="commitSha" open>
              COMMIT: {{ commitSha.substring(0, 8) }}

              <vscode-tree-item class="agents-folder" open>
                AGENTS ({{ agents.length }})

                <vscode-tree-item v-for="agent in agents" :key="agent.agentId" class="agent-item">
                  <span slot="decorations">
                    <vscode-button appearance="icon" title="Open in portal"><span
                        class="codicon codicon-link-external"></span></vscode-button>
                  </span>
                  <span class="agent-name">{{ agent.agentId.split('-')[0] }}</span>
                </vscode-tree-item>
              </vscode-tree-item>

            </vscode-tree-item>
          </vscode-tree-item>

        </vscode-tree-item>
      </vscode-tree>
    </div>

    <div v-else class="empty-state">
      <span class="codicon codicon-search-stop empty-icon"></span>
      <h3>No Services Found</h3>
      <p>We couldn't find any <code>.hprc</code> files in your workspace.</p>
      <p>Create a <code>.hprc</code> file in your project root containing your Service ID to start monitoring.</p>
      <pre><code>{ "serviceId": "[service-uuid]" }</code></pre>
    </div>
  </div>
</template>

<script setup lang="ts">
import { computed, ref } from 'vue';
import { type ActiveAgent, useAgentStore } from '../stores/agentStore';
import { useFilterStore } from '../stores/filterStore';

const agentStore = useAgentStore();
const filterStore = useFilterStore();

const allExpanded = ref(true);
const treeRef = ref<any>(null);

function toggleAll() {
  if (!treeRef.value) return;
  if (allExpanded.value) {
    treeRef.value.collapseAll();
    allExpanded.value = false;
  } else {
    treeRef.value.expandAll();
    allExpanded.value = true;
  }
}

const filteredAgents = computed(() => {
  return agentStore.agents.filter((agent) => {
    // 1. Tag Filtering (Strict)
    for (const tag of filterStore.activeTags) {
      if (tag.type === 'environment' && agent.environment !== tag.value)
        return false;
      if (tag.type === 'serviceId' && agent.serviceId !== tag.value)
        return false;

      // Allow partial match on commitSha in case they only typed the first 8 chars
      if (tag.type === 'commitSha' && !agent.commitSha.startsWith(tag.value))
        return false;

      // Add serviceName tag filter support
      if (tag.type === 'serviceName') {
        const name =
          agentStore.serviceNames[agent.serviceId] || agent.serviceId;
        if (name !== tag.value) return false;
      }
    }

    // 2. We DO NOT perform fuzzy search here anymore while typing.
    // Fuzzy search is only for suggestions in App.vue,
    // or if you want it, it should be an explicit text search tag.
    // Let's just remove the fuzzy stringify filter so data doesn't disappear while typing.

    return true;
  });
});

const deepGroupedFiltered = computed(() => {
  const grouped: Record<
    string,
    Record<string, Record<string, ActiveAgent[]>>
  > = {};

  for (const agent of filteredAgents.value) {
    if (!grouped[agent.serviceId]) {
      grouped[agent.serviceId] = {};
    }
    if (!grouped[agent.serviceId][agent.environment]) {
      grouped[agent.serviceId][agent.environment] = {};
    }
    if (!grouped[agent.serviceId][agent.environment][agent.commitSha]) {
      grouped[agent.serviceId][agent.environment][agent.commitSha] = [];
    }
    grouped[agent.serviceId][agent.environment][agent.commitSha].push(agent);
  }
  return grouped;
});
</script>

<style scoped>
.view-container {
  display: flex;
  flex-direction: column;
  height: 100%;
  overflow: hidden;
}

.toolbar {
  display: flex;
  gap: 8px;
  padding: 8px;
  align-items: center;
  border-bottom: 1px solid var(--vscode-panel-border);
}

.search-input {
  flex: 1;
}

.sort-select {
  width: 120px;
}

.agent-count {
  padding: 8px 12px;
  font-size: 11px;
  color: var(--vscode-descriptionForeground);
  font-weight: 600;
  text-transform: uppercase;
  letter-spacing: 0.5px;
}

.tree-container {
  flex: 1;
  overflow: auto;
  padding: 0 8px;
}

.env-decorations {
  display: flex;
  align-items: center;
  gap: 4px;
}

.env-badge {
  background-color: var(--vscode-badge-background);
  color: var(--vscode-badge-foreground);
  padding: 2px 6px;
  border-radius: 4px;
  font-size: 10px;
  font-weight: bold;
}

.agent-name {
  color: var(--vscode-foreground);
  font-family: var(--vscode-editor-font-family);
  font-size: 12px;
}

.empty-state {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  padding: 40px 20px;
  text-align: center;
  color: var(--vscode-descriptionForeground);
  flex: 1;
}

.empty-icon {
  font-size: 48px;
  margin-bottom: 16px;
  color: var(--vscode-disabledForeground);
}

.empty-state h3 {
  margin: 0 0 8px 0;
  color: var(--vscode-foreground);
}

.empty-state p {
  margin: 4px 0;
  font-size: 12px;
}

.empty-state pre {
  background-color: var(--vscode-textCodeBlock-background);
  padding: 8px 12px;
  border-radius: 4px;
  margin-top: 12px;
  font-size: 11px;
}
</style>
