<template>
  <div class="insert-container">
    <div class="insert-header">
      <vscode-button appearance="icon" @click="goBack" class="back-btn">
        <span class="codicon codicon-chevron-left"></span>
      </vscode-button>
      <span class="action-icon codicon" :class="iconClass"></span>
      <span class="action-title">{{ isEdit ? 'Edit a' : 'Insert a' }} {{ actionName }}</span>
    </div>
    <div class="action-description">{{ actionDescription }}</div>

    <div class="form-content">
      <!-- Source -->
      <div class="form-group" style="position: relative;">
        <label>SOURCE*</label>
        <div class="flex-row">
          <vscode-button appearance="secondary" class="flex-1 source-dropdown-btn"
            @click="showSourceDropdown = !showSourceDropdown" :disabled="isSubmitting"
            :title="getSourceLabel(selectedSource) || 'Choose a source...'">
            <span class="btn-text">
              {{ getSourceLabel(selectedSource) || 'Choose a source...' }}
            </span>
            <span slot="end" class="codicon codicon-chevron-down"></span>
          </vscode-button>
          <vscode-button appearance="icon" title="Refresh live agents" @click="agentStore.fetchAgents()"
            :disabled="agentStore.isLoading || isSubmitting">
            <span class="codicon codicon-refresh" :class="{ 'codicon-modifier-spin': agentStore.isLoading }"></span>
          </vscode-button>
        </div>
        <div v-if="formErrors.source" class="error-text">{{ formErrors.source }}</div>

        <!-- Source Selection Dropdown Panel -->
        <div v-if="showSourceDropdown && !isSubmitting" class="source-panel">
          <vscode-textfield placeholder="Search" class="w-full mb-2" :value="sourceSearchQuery"
            @input="sourceSearchQuery = ($event.target as any).value">
            <span slot="content-after" class="codicon codicon-close cursor-pointer"
              @click="sourceSearchQuery ? sourceSearchQuery = '' : showSourceDropdown = false"></span>
          </vscode-textfield>

          <div class="source-section">
            <div class="source-section-header">AVAILABLE LIVE AGENTS <span class="count">{{ uniqueSources.length
                }}</span>
            </div>
            <div class="source-item" v-for="source in uniqueSources"
              :key="source.serviceId + source.environment + source.commitSha" @click="selectSource(source)"
              :title="getSourceLabel(source)">
              <span class="codicon"
                :class="selectedSource?.commitSha === source.commitSha && selectedSource?.serviceId === source.serviceId ? 'codicon-check' : 'codicon-blank'"></span>
              <span class="source-item-text">
                {{ getSourceLabel(source) }}
              </span>
            </div>
          </div>
        </div>
      </div>

      <!-- Filename & Line -->
      <div class="form-group">
        <label>FILENAME & LINE*</label>
        <div class="flex-row">
          <vscode-textfield :value="uiFilePath"
            @input="uiFilePath = ($event.target as any).value; delete formErrors.uiFilePath"
            placeholder="apps/demo-app/src/index.ts" class="flex-1" :class="{ 'has-error': formErrors.uiFilePath }"
            :disabled="isSubmitting" title="The relative path to the source code file"></vscode-textfield>
          <vscode-textfield :value="uiLineNumber.toString()"
            @input="uiLineNumber = parseInt(($event.target as any).value, 10) || 1; delete formErrors.uiLineNumber"
            type="number" min="1" max="10000" class="line-input" :class="{ 'has-error': formErrors.uiLineNumber }"
            :disabled="isSubmitting" title="The line number where the action will be inserted"></vscode-textfield>
          <vscode-button appearance="icon" @click="goToFileLocation" :disabled="isSubmitting"><span
              class="codicon codicon-location"></span></vscode-button>
        </div>
        <div v-if="formErrors.uiFilePath || formErrors.uiLineNumber" class="error-text">
          {{ formErrors.uiFilePath || formErrors.uiLineNumber }}
        </div>
      </div>

      <!-- Specific Fields -->

      <!-- Snapshot -->
      <template v-if="type === 'snapshot'">
        <div class="form-row">
          <div class="form-group flex-1">
            <label>HIT LIMIT <span class="codicon codicon-info info-icon"
                title="Maximum number of times this snapshot will be captured"></span></label>
            <vscode-textfield class="w-full" :value="hitLimit.toString()"
              @input="hitLimit = parseInt(($event.target as any).value, 10) || 1" type="number" min="1" max="50"
              :disabled="isSubmitting"
              title="Maximum number of times this snapshot will be captured"></vscode-textfield>
          </div>
        </div>

        <div class="form-group">
          <label>Expiry (Max 30days) <span class="codicon codicon-info info-icon"
              title="How long the snapshot will remain active"></span></label>
          <LifetimeSelector v-model:hours="customHours" v-model:minutes="customMinutes" :disabled="isSubmitting" />
        </div>

        <div class="form-group">
          <label title="Expressions to evaluate and capture when the action triggers">WATCH EXPRESSIONS</label>
          <div class="watch-expressions-list">
            <div class="watch-expr-item" v-for="(expr, i) in watchExpressions" :key="i">
              <vscode-textfield :value="expr" placeholder="Enter a variable or method result" class="w-full"
                @input="updateWatchExpr(i, ($event.target as any).value)"
                @keyup.enter="i === watchExpressions.length - 1 && canAddWatchExpr ? addWatchExpr() : null"
                :disabled="isSubmitting" title="Expression to evaluate (e.g. user.name)"></vscode-textfield>
              <vscode-button appearance="icon" @click="removeWatchExpr(i)"
                v-if="watchExpressions.length > 1 || expr.trim() !== ''" title="Remove Expression"
                :disabled="isSubmitting">
                <span class="codicon codicon-close"></span>
              </vscode-button>
              <vscode-button appearance="icon" class="hidden-btn" v-else>
                <span class="codicon codicon-close"></span>
              </vscode-button>
            </div>
          </div>
          <vscode-button appearance="secondary" class="w-full mt-2" @click="addWatchExpr"
            :disabled="!canAddWatchExpr || isSubmitting">
            <span class="codicon codicon-add"></span>
          </vscode-button>
        </div>

        <!-- <div class="form-group checkbox-group">
          <vscode-checkbox :checked="captureClosures"
            @change="captureClosures = ($event.target as any).checked" :disabled="isSubmitting">
            <span class="checkbox-label">Capture Closures</span>
          </vscode-checkbox>
          <div class="checkbox-hint">If enabled, variables from parent closure scopes will be captured in the snapshot.</div>
        </div> -->
      </template>

      <!-- Log -->
      <template v-if="type === 'log'">
        <div class="form-group">
          <label>HIT LIMIT <span class="codicon codicon-info info-icon"
              title="Maximum number of times this log will be emitted"></span></label>
          <vscode-textfield class="w-full" :value="hitLimit.toString()"
            @input="hitLimit = parseInt(($event.target as any).value, 10) || 1" type="number" min="1" max="1000"
            :disabled="isSubmitting" title="Maximum number of times this log will be emitted"></vscode-textfield>
        </div>
        <div class="form-group">
          <label>LOG MESSAGE*</label>
          <vscode-textfield :value="logMessage"
            @input="logMessage = ($event.target as any).value; delete formErrors.logMessage"
            placeholder="Hello world ${expression}" class="w-full" :class="{ 'has-error': formErrors.logMessage }"
            :disabled="isSubmitting"
            title="The log template string to output. Use ${expr} to interpolate variables."></vscode-textfield>
          <div v-if="formErrors.logMessage" class="error-text">{{ formErrors.logMessage }}</div>
        </div>
        <div class="form-row">
          <div class="form-group flex-1">
            <label>LOG LEVEL</label>
            <vscode-single-select class="w-full" title="The severity level of the log message" :value="logLevel"
              @change="logLevel = ($event.target as any).value" :disabled="isSubmitting">
              <vscode-option value="INFO">INFO</vscode-option>
              <vscode-option value="ERROR">ERROR</vscode-option>
            </vscode-single-select>
          </div>
          <div class="form-group flex-1">
            <div 
              class="log-output-tile" 
            >
              <div class="tile-content">
                <vscode-checkbox :checked="shouldLogToStdout" class="stdout-log-checkbox"
                  @change="shouldLogToStdout = ($event.target as any).checked" :disabled="isSubmitting">
                  <span class="checkbox-label">Also Log to STDOUT</span>
                </vscode-checkbox>
              </div>
            </div>
          </div>
        </div>
      </template>

      <!-- Metrics -->
      <template v-if="['counter', 'tic-toc', 'custom-metric'].includes(type as string)">
        <div class="form-group">
          <label>NAME*</label>
          <vscode-textfield :value="metricName"
            @input="metricName = ($event.target as any).value; delete formErrors.metricName" placeholder="MetricName"
            class="w-full" :class="{ 'has-error': formErrors.metricName }" :disabled="isSubmitting"
            title="The name of the metric to be captured"></vscode-textfield>
          <div v-if="formErrors.metricName" class="error-text">{{ formErrors.metricName }}</div>
        </div>
      </template>

      <template v-if="type === 'custom-metric'">
        <div class="form-group">
          <label>WATCH EXPRESSIONS</label>
          <div class="watch-expressions-list">
            <div class="watch-expr-item" v-for="(expr, i) in watchExpressions" :key="i">
              <vscode-textfield :value="expr" placeholder="Enter a variable or method result" class="w-full"
                @input="updateWatchExpr(i, ($event.target as any).value)" :disabled="isSubmitting"
                @keyup.enter="i === watchExpressions.length - 1 && canAddWatchExpr ? addWatchExpr() : null"></vscode-textfield>
              <vscode-button appearance="icon" @click="removeWatchExpr(i)"
                v-if="watchExpressions.length > 1 || expr.trim() !== ''" :disabled="isSubmitting">
                <span class="codicon codicon-close"></span>
              </vscode-button>
              <vscode-button appearance="icon" class="hidden-btn" v-else>
                <span class="codicon codicon-close"></span>
              </vscode-button>
            </div>
          </div>
          <vscode-button appearance="secondary" class="w-full mt-2" @click="addWatchExpr"
            :disabled="!canAddWatchExpr || isSubmitting">
            <span class="codicon codicon-add"></span>
          </vscode-button>
        </div>
      </template>

      <template v-if="type !== 'snapshot'">
        <div class="form-group">
          <label>Expiry (Max 30days) <span class="codicon codicon-info info-icon"
              title="How long the action will remain active"></span></label>
          <LifetimeSelector v-model:hours="customHours" v-model:minutes="customMinutes" :disabled="isSubmitting" />
        </div>
      </template>

      <!-- Condition (Common) -->
      <div class="form-group">
        <label>CONDITION <span class="codicon codicon-info info-icon"
            title="A boolean expression to determine if the action should execute (e.g. user.id === 123)"></span></label>
        <vscode-textfield :value="condition" @input="condition = ($event.target as any).value"
          placeholder="Insert a boolean expression" class="w-full" :disabled="isSubmitting"
          title="A boolean expression to determine if the action should execute (e.g. user.id === 123)"></vscode-textfield>
      </div>

      <!-- Capture Trace ID -->
      <template v-if="['snapshot', 'log'].includes(type as string)">
        <div class="form-group checkbox-group">
          <vscode-checkbox :checked="shouldCaptureTraceId"
            @change="shouldCaptureTraceId = ($event.target as any).checked" :disabled="isSubmitting">
            <span class="checkbox-label">Capture Trace ID</span>
          </vscode-checkbox>
          <div class="checkbox-hint">If enabled, the trace ID will be extracted from your APM.</div>
        </div>
      </template>

      <!-- Thread Aggregation (Counter) -->
      <template v-if="type === 'counter'">
        <div class="form-group">
          <label>AGGREGATED BY THREAD <span class="codicon codicon-info info-icon"
              title="How the metric should be aggregated across threads"></span></label>
          <vscode-textfield placeholder="*" class="w-full" :disabled="isSubmitting"
            title="How the metric should be aggregated across threads"></vscode-textfield>
        </div>
      </template>

      <div class="form-actions">
        <vscode-button appearance="primary" class="w-full submit-btn" @click="createAction"
          :disabled="(isEdit && !isDirty || (customHours === 0 && customMinutes === 0)) || isSubmitting">
          <span v-if="isSubmitting" class="codicon codicon-loading codicon-modifier-spin"></span>
          {{ isSubmitting ? (isEdit ? 'Applying Changes...' : 'Creating...') : (isEdit ? 'Apply Changes' : 'Create') }}
        </vscode-button>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { computed, onMounted, ref, watch } from 'vue';
import { useRoute, useRouter } from 'vue-router';
import LifetimeSelector from '../components/LifetimeSelector.vue';
import { useActionStore } from '../stores/actionStore';
import { type ActiveAgent, useAgentStore } from '../stores/agentStore';
import { vscode } from '../utils/vscode';

const route = useRoute();
const router = useRouter();
const agentStore = useAgentStore();
const actionStore = useActionStore();

const showSourceDropdown = ref(false);
const selectedSource = ref<ActiveAgent | null>(null);
const sourceSearchQuery = ref('');

const uiFilePath = ref('');
const uiLineNumber = ref<number>(1);
const logMessage = ref('');
const metricName = ref('');
const condition = ref('');
const hitLimit = ref<number>(1);
const shouldCaptureTraceId = ref(false);
const captureClosures = ref(false);
const logLevel = ref('INFO');
const shouldLogToStdout = ref<boolean>(false);

const customHours = ref(1);
const customMinutes = ref(0);

const watchExpressions = ref<string[]>(['']);
const editId = computed(() => route.params.id as string);
const isEdit = computed(() => route.path.startsWith('/edit'));

const initialState = ref<any>(null);
const formErrors = ref<Record<string, string>>({});
const isSubmitting = ref(false);

const isDirty = computed(() => {
  if (!isEdit.value || !initialState.value) return false;

  if (uiFilePath.value !== initialState.value.uiFilePath) return true;
  if (uiLineNumber.value !== initialState.value.uiLineNumber) return true;
  if (condition.value !== initialState.value.condition) return true;
  if (shouldCaptureTraceId.value !== initialState.value.shouldCaptureTraceId)
    return true;
  if (
    customHours.value !== initialState.value.customHours ||
    customMinutes.value !== initialState.value.customMinutes
  )
    return true;
  if (
    selectedSource.value?.serviceId !== initialState.value.serviceId ||
    selectedSource.value?.environment !== initialState.value.environment ||
    selectedSource.value?.commitSha !== initialState.value.commitSha
  )
    return true;

  const currentType = type.value.toLowerCase();
  if (currentType === 'snapshot') {
    if (hitLimit.value !== initialState.value.hitLimit) return true;
    if (captureClosures.value !== initialState.value.captureClosures)
      return true;
    if (
      JSON.stringify(watchExpressions.value) !==
      JSON.stringify(initialState.value.watchExpressions)
    )
      return true;
  } else if (currentType === 'log') {
    if (logMessage.value !== initialState.value.logMessage) return true;
    if (hitLimit.value !== initialState.value.hitLimit) return true;
    if (logLevel.value !== initialState.value.logLevel) return true;
    if (shouldLogToStdout.value !== initialState.value.shouldLogToStdout)
      return true;
  } else if (['counter', 'tic-toc', 'custom-metric'].includes(currentType)) {
    if (metricName.value !== initialState.value.metricName) return true;
    if (
      currentType === 'custom-metric' &&
      JSON.stringify(watchExpressions.value) !==
        JSON.stringify(initialState.value.watchExpressions)
    )
      return true;
  }

  return false;
});

function asyncConfirm(
  message: string,
  confirmText: string = 'Proceed',
): Promise<boolean> {
  return new Promise((resolve) => {
    if (vscode.isAvailable) {
      const msgId = Date.now().toString() + Math.random().toString();
      const handler = (event: MessageEvent) => {
        const data = event.data;
        if (data.type === 'confirmDeleteResponse' && data.msgId === msgId) {
          window.removeEventListener('message', handler);
          resolve(data.confirmed);
        }
      };
      window.addEventListener('message', handler);
      vscode.postMessage({
        type: 'confirmDelete',
        message,
        msgId,
        confirmText,
      });
    } else {
      resolve(window.confirm(message));
    }
  });
}

watch(
  () => route.query,
  (newQuery) => {
    uiFilePath.value = (newQuery.filePath as string) || '';

    uiLineNumber.value = newQuery.lineNumber
      ? Number.parseInt(newQuery.lineNumber as string, 10) || 1
      : 1;
  },
  { immediate: true },
);

onMounted(() => {
  if (isEdit.value && editId.value) {
    const existingAction = actionStore.actions.find(
      (a) => a.id === editId.value,
    );
    if (existingAction) {
      uiFilePath.value = existingAction.uiFilePath || '';
      uiLineNumber.value = existingAction.uiLineNumber || 1;
      condition.value = existingAction.condition || '';
      shouldCaptureTraceId.value = existingAction.shouldCaptureTraceId || false;

      const source = agentStore.agents.find(
        (a) =>
          a.serviceId === existingAction.serviceId &&
          a.environment === existingAction.environment &&
          a.commitSha === existingAction.commitSha,
      );
      if (source) selectedSource.value = source;

      if (existingAction.expiryTime) {
        const expiry = Number(existingAction.expiryTime);
        const createdAt = existingAction.createdAt
          ? new Date(existingAction.createdAt).getTime()
          : Date.now();
        const diffMs = expiry - createdAt;
        const totalMinutes = Math.max(0, Math.ceil(diffMs / (60 * 1000)));
        const cappedMinutes = Math.min(totalMinutes, 720 * 60);
        customHours.value = Math.floor(cappedMinutes / 60);
        customMinutes.value =
          customHours.value === 720 ? 0 : cappedMinutes % 60;
      }

      if (existingAction.type === 'SNAPSHOT') {
        hitLimit.value = existingAction.hitLimit || 1;
        captureClosures.value = existingAction.captureClosures ?? false;
        if (
          existingAction.watchExpressions &&
          existingAction.watchExpressions.length > 0
        ) {
          watchExpressions.value = [...existingAction.watchExpressions];
        }
      } else if (existingAction.type === 'LOG') {
        logMessage.value = existingAction.template || '';
        hitLimit.value = existingAction.hitLimit || 100;
        logLevel.value = existingAction.logLevel || 'INFO';
        shouldLogToStdout.value = existingAction.shouldLogToStdout || false;
      } else if (
        existingAction.type === 'COUNTER' ||
        existingAction.type === 'METRIC' ||
        existingAction.type === 'DURATION'
      ) {
        metricName.value = existingAction.metricName || '';
        if (existingAction.type === 'METRIC') {
          watchExpressions.value = [existingAction.metricExpression || '1'];
        }
      }

      initialState.value = {
        uiFilePath: uiFilePath.value,
        uiLineNumber: uiLineNumber.value,
        condition: condition.value,
        serviceId: source?.serviceId,
        environment: source?.environment,
        commitSha: source?.commitSha,
        shouldCaptureTraceId: shouldCaptureTraceId.value,
        captureClosures: captureClosures.value,
        hitLimit: hitLimit.value,
        watchExpressions: [...watchExpressions.value],
        logMessage: logMessage.value,
        metricName: metricName.value,
        customHours: customHours.value,
        customMinutes: customMinutes.value,
        logLevel: logLevel.value,
        shouldLogToStdout: shouldLogToStdout.value,
      };
    }
  } else {
    if (type.value === 'log') {
      hitLimit.value = 100;
    }
  }
});

const canAddWatchExpr = computed(() => {
  if (watchExpressions.value.length === 0) return true;
  const last = watchExpressions.value[watchExpressions.value.length - 1];
  return last.trim().length > 0;
});

function addWatchExpr() {
  if (canAddWatchExpr.value) {
    watchExpressions.value.push('');
  }
}

function updateWatchExpr(index: number, value: string) {
  watchExpressions.value[index] = value;
}

function removeWatchExpr(index: number) {
  watchExpressions.value.splice(index, 1);
  if (watchExpressions.value.length === 0) {
    watchExpressions.value.push('');
  }
}

const type = computed(() => route.params.type as string);

const uniqueSources = computed(() => {
  const sources: ActiveAgent[] = [];
  const seen = new Set<string>();

  for (const agent of agentStore.agents) {
    const key = `${agent.serviceId}-${agent.environment}-${agent.commitSha}`;
    if (!seen.has(key)) {
      seen.add(key);
      sources.push(agent);
    }
  }

  const query = sourceSearchQuery.value.toLowerCase().trim();
  if (!query) return sources;

  return sources.filter((source) => {
    const label = getSourceLabel(source).toLowerCase();
    return label.includes(query);
  });
});

function getSourceLabel(source: ActiveAgent | null) {
  if (!source) return '';
  const serviceName =
    agentStore.serviceNames[source.serviceId] || source.serviceId;
  return `Service: ${serviceName} | Env: ${source.environment} | Commit: ${source.commitSha.substring(0, 7)}`;
}

function selectSource(source: ActiveAgent) {
  selectedSource.value = source;
  showSourceDropdown.value = false;
  delete formErrors.value.source;
}

const actionName = computed(() => {
  switch (type.value) {
    case 'log':
      return 'Log';
    case 'snapshot':
      return 'Snapshot';
    case 'counter':
      return 'Counter';
    case 'tic-toc':
      return 'Tic & Toc';
    case 'custom-metric':
      return 'Custom Metric';
    default:
      return 'Action';
  }
});

const actionDescription = computed(() => {
  switch (type.value) {
    case 'log':
      return 'Adds a log line before the chosen line of code without interrupting the application.';
    case 'snapshot':
      return 'Captures local variables, expressions and the call stack without interrupting the application.';
    case 'counter':
      return 'Counts the number of times a line is reached.';
    case 'tic-toc':
      return 'Measures the elapsed time between two chosen lines of code.';
    case 'custom-metric':
      return 'Creates a metric for any specified numerical expression. The metric will be outputted continuously every few seconds.';
    default:
      return '';
  }
});

const iconClass = computed(() => {
  switch (type.value) {
    case 'log':
      return 'codicon-list-flat log-color';
    case 'snapshot':
      return 'codicon-device-camera snap-color';
    case 'counter':
      return 'codicon-symbol-number metric-color';
    case 'tic-toc':
      return 'codicon-watch metric-color';
    case 'custom-metric':
      return 'codicon-graph-line metric-color';
    default:
      return '';
  }
});

function goBack() {
  router.push('/actions');
}

function goToFileLocation() {
  if (uiFilePath.value && uiLineNumber.value) {
    vscode.postMessage({
      type: 'revealLine',
      filePath: uiFilePath.value,
      lineNumber: uiLineNumber.value,
    });
  }
}

async function createAction() {
  if (isSubmitting.value) return;
  formErrors.value = {};

  if (!selectedSource.value) {
    formErrors.value.source = 'Source is required';
  }

  if (!uiFilePath.value) {
    formErrors.value.uiFilePath = 'File path is required';
  }

  if (!uiLineNumber.value || uiLineNumber.value < 1) {
    formErrors.value.uiLineNumber = 'Line number must be a positive integer';
  }

  let mappedType = type.value.toUpperCase();
  if (mappedType === 'TIC-TOC') mappedType = 'DURATION';
  if (mappedType === 'CUSTOM-METRIC') mappedType = 'METRIC';

  if (mappedType === 'LOG' && !logMessage.value) {
    formErrors.value.logMessage = 'Log message is required';
  }

  if (
    ['COUNTER', 'DURATION', 'METRIC'].includes(mappedType) &&
    !metricName.value
  ) {
    formErrors.value.metricName = 'Metric name is required';
  }

  if (Object.keys(formErrors.value).length > 0) {
    return;
  }

  // 1. Lock submission immediately on entry to prevent multiple rapid clicks
  isSubmitting.value = true;

  // 2. Ask for confirmation FIRST before locking inputs
  if (isEdit.value && editId.value) {
    const confirmed = await asyncConfirm(
      'Applying these changes will delete the original probe and its snapshots, and create a new probe in its place. Proceed?',
    );
    if (!confirmed) {
      isSubmitting.value = false; // <-- Reset lockout if user cancels
      return;
    }
  }

  let durationMs = (customHours.value * 60 + customMinutes.value) * 60 * 1000;
  if (durationMs === 0) {
    durationMs = 1 * 60 * 1000; // Minimum 1 minute
  }
  const expiryTime = Date.now() + durationMs;

  const payload: any = {
    serviceId: selectedSource.value!.serviceId,
    environment: selectedSource.value!.environment,
    commitSha: selectedSource.value!.commitSha,
    type: mappedType,
    uiFilePath: uiFilePath.value,
    uiLineNumber: uiLineNumber.value,
    condition: condition.value || undefined,
    shouldCaptureTraceId: shouldCaptureTraceId.value,
    expiryTime,
  };

  if (mappedType === 'SNAPSHOT') {
    payload.hitLimit = hitLimit.value;
    payload.captureClosures = captureClosures.value;
    payload.watchExpressions = watchExpressions.value.filter(
      (e) => e.trim().length > 0,
    );
  } else if (mappedType === 'LOG') {
    payload.template = logMessage.value;
    payload.hitLimit = hitLimit.value;
    payload.logLevel = logLevel.value;
    payload.shouldLogToStdout = shouldLogToStdout.value;
  } else if (mappedType === 'COUNTER') {
    payload.metricName = metricName.value;
  } else if (mappedType === 'METRIC') {
    payload.metricName = metricName.value;
    // In our UI we just put watch expressions, but backend needs metricExpression
    payload.metricExpression = watchExpressions.value[0] || '1';
  } else if (mappedType === 'DURATION') {
    payload.metricName = metricName.value;
    // TODO: TicToc requires a secondary location. For now just mock it to test creation
    payload.secondaryUiFilePath = uiFilePath.value;
    payload.secondaryUiLineNumber = uiLineNumber.value + 1;
  }

  try {
    if (isEdit.value && editId.value) {
      await actionStore.insertAction(payload);
      await actionStore.deleteActions([editId.value]);
    } else {
      await actionStore.insertAction(payload);
    }
    router.push('/actions');
  } catch (err) {
    console.error('Failed to create action:', err);
    // Errors are automatically displayed to the user globally via tRPC errorLink middleware notification
    isSubmitting.value = false;
  }
}
</script>

<style scoped>
.insert-container {
  display: flex;
  flex-direction: column;
  height: 100%;
  overflow-y: auto;
  background-color: var(--vscode-editor-background);
}

.insert-header {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 12px 12px 4px 12px;
}

.checkbox-group {
  margin-top: 16px;
  background-color: var(--vscode-editorWidget-background);
  border: 1px solid var(--vscode-widget-border);
  border-radius: 4px;
  padding: 8px 12px;
}

.checkbox-label {
  font-family: var(--vscode-editor-font-family);
  font-weight: 500;
  color: var(--vscode-editor-foreground);
}

.checkbox-hint {
  font-size: 12px;
  line-height: 1.4;
  color: var(--vscode-descriptionForeground);
  margin-top: 0;
  margin-left: 28px;
  opacity: 0.85;
}

.action-icon {
  font-size: 16px;
}

.log-color {
  color: var(--vscode-charts-orange);
}

.snap-color {
  color: var(--vscode-charts-blue);
}

.metric-color {
  color: var(--vscode-charts-green);
}

.action-title {
  font-family: var(--vscode-editor-font-family);
  font-size: 16px;
  font-weight: bold;
}

.action-description {
  padding: 0 16px 16px 44px;
  font-size: 12px;
  color: var(--vscode-descriptionForeground);
  line-height: 1.4;
  border-bottom: 1px solid var(--vscode-panel-border);
}

.form-content {
  padding: 16px;
  display: flex;
  flex-direction: column;
  gap: 16px;
}

.form-group {
  display: flex;
  flex-direction: column;
  gap: 6px;
}

.form-group label {
  font-size: 10px;
  font-weight: bold;
  color: var(--vscode-descriptionForeground);
  text-transform: uppercase;
  display: flex;
  align-items: center;
  gap: 4px;
}

.info-icon {
  font-size: 12px;
  cursor: help;
}

.flex-row {
  display: flex;
  gap: 4px;
  align-items: center;
}

.form-row {
  display: flex;
  gap: 12px;
}

.flex-1 {
  flex: 1;
}

.w-full {
  width: 100%;
}

.mt-2 {
  margin-top: 8px;
}

.line-input {
  min-width: 15%;
  max-width: 25%;
}

.source-dropdown-btn {
  text-align: left;
  justify-content: flex-start;
  min-width: 0;
  height: auto !important;
}

.source-dropdown-btn::part(control) {
  display: flex;
  justify-content: flex-start;
  align-items: center;
  min-width: 0;
  height: auto !important;
  min-height: 24px;
  padding: 4px 0;
}

.btn-text {
  flex: 1;
  min-width: 0;
  white-space: normal;
  word-break: break-word;
  overflow-wrap: anywhere;
  text-align: left;
  line-height: 1.4;
}

.source-dropdown-btn [slot="end"] {
  margin-left: 8px;
  flex-shrink: 0;
  align-self: center;
}

.source-options-menu {
  position: absolute;
  top: 60px;
  right: 0;
  background-color: var(--vscode-editorWidget-background);
  border: 1px solid var(--vscode-widget-border);
  box-shadow: 0 4px 8px var(--vscode-widget-shadow);
  border-radius: 4px;
  z-index: 100;
  min-width: 220px;
  padding: 4px 0;
}

.source-panel {
  position: absolute;
  top: 60px;
  left: 0;
  width: 100%;
  background-color: var(--vscode-editorWidget-background);
  border: 1px solid var(--vscode-widget-border);
  box-shadow: 0 4px 8px var(--vscode-widget-shadow);
  border-radius: 4px;
  z-index: 99;
  padding: 8px;
  box-sizing: border-box;
}

.source-section {
  margin-top: 8px;
}

.source-section-header {
  font-size: 10px;
  color: var(--vscode-descriptionForeground);
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding-bottom: 4px;
  border-bottom: 1px solid var(--vscode-panel-border);
  margin-bottom: 4px;
}

.source-item {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 4px;
  cursor: pointer;
  font-size: 12px;
  min-width: 0;
}

.source-item-text {
  flex: 1;
  min-width: 0;
  white-space: normal;
  word-break: break-word;
  overflow-wrap: anywhere;
}

.source-item:hover {
  background-color: var(--vscode-list-hoverBackground);
}

.menu-item {
  padding: 6px 12px;
  cursor: pointer;
  display: flex;
  align-items: center;
  gap: 8px;
  font-size: 12px;
}

.menu-item:hover:not(.disabled-text) {
  background-color: var(--vscode-list-hoverBackground);
}

.menu-divider {
  height: 1px;
  background-color: var(--vscode-menu-separatorBackground);
  margin: 4px 0;
}

.disabled-text {
  color: var(--vscode-descriptionForeground);
  cursor: default;
}

.ml-auto {
  margin-left: auto;
}

.mb-2 {
  margin-bottom: 8px;
}

.mt-sm {
  margin-top: 8px;
}

.cursor-pointer {
  cursor: pointer;
}

.codicon-blank {
  visibility: hidden;
}

.watch-expressions-list {
  display: flex;
  flex-direction: column;
  gap: 8px;
}

.watch-expr-item {
  display: flex;
  align-items: center;
  gap: 4px;
}

.hidden-btn {
  visibility: hidden;
}

.form-actions {
  margin-top: 16px;
  padding-bottom: 32px;
}

.submit-btn {
  font-weight: bold;
}

.submit-btn .codicon-loading {
  margin-right: 6px;
}

.error-text {
  color: var(--vscode-errorForeground);
  font-size: 11px;
  margin-top: 2px;
}

.has-error {
  border: 1px solid var(--vscode-errorForeground);
  border-radius: 2px;
}

.custom-lifetime-container {
  background-color: var(--vscode-editor-background);
  border: 1px solid var(--vscode-widget-border, #454545);
  border-radius: 4px;
  padding: 8px 12px;
  margin-top: 6px;
}

.sub-label {
  font-size: 9px !important;
  font-weight: bold;
  opacity: 0.8;
  letter-spacing: 0.5px;
  margin-bottom: 2px !important;
}
.log-output-tile {
  display: flex;
  align-items: center;
  padding: 2px 14px 2px 0;
  gap: 12px;
  cursor: pointer;
  user-select: none;
  transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
  margin-top: 18px;
  margin-left: 6px;
  height: 22px;
}

.tile-content {
  flex: 1;
  display: flex;
  flex-direction: column;
  justify-content: center;
}

.tile-desc {
  font-size: 9px;
  color: var(--vscode-descriptionForeground, #858585);
  margin-top: 1px;
}

.stdout-log-checkbox .icon {
  height: 22px;
  width: 22px;
}
</style>
