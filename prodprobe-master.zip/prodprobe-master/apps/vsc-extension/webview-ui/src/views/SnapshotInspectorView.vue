<template>
  <div class="inspector-container">
    <div v-if="loading && !probeDetails" class="not-found">
      <div class="header-left">
        <vscode-button appearance="icon" @click="goBack" class="back-btn">
          <span class="codicon codicon-chevron-left"></span>
        </vscode-button>
      </div>
      <div>Loading snapshots...</div>
    </div>
    <div v-else-if="!probeDetails && !hit" class="not-found">
      <div class="header-left">
        <vscode-button appearance="icon" @click="goBack" class="back-btn">
          <span class="codicon codicon-chevron-left"></span>
        </vscode-button>
      </div>
      <div>Snapshot not found</div>
    </div>
    <div v-else class="inspector-content">

      <!-- Header -->
      <div class="inspector-header">
        <div class="header-left">
          <vscode-button appearance="icon" @click="goBack" class="back-btn">
            <span class="codicon codicon-chevron-left"></span>
          </vscode-button>
          <span class="codicon hit-icon"
            :class="displayType === 'LOG' ? 'codicon-list-flat log-color' : 'codicon-device-camera snap-color'"></span>
          <span class="hit-title">{{ displayFile }}:{{ displayLine }}</span>
          <span class="codicon codicon-pass-filled status-active" v-if="displayStatus === 'ACTIVE'"></span>
        </div>
        <div class="header-meta">
          <span class="meta-label">Source</span>
          <span class="meta-value agent-name" :title="agentName">{{ agentName }}</span>
        </div>

        <div v-if="showMoreInfo && probeDetails" class="extended-meta">
          <div class="meta-row">
            <span class="meta-label">Action ID</span>
            <span class="meta-value">{{ route.params.id }}</span>
          </div>
          <div class="meta-row">
            <span class="meta-label">Created by</span>
            <span class="meta-value">{{ probeDetails.createdBy || 'N/A' }}</span>
          </div>
          <div class="meta-row">
            <span class="meta-label">Hit limit</span>
            <span class="meta-value">{{ probeDetails.hitLimit || hit?.hitLimit || 'N/A' }}</span>
          </div>
          <div class="meta-row">
            <span class="meta-label">Status</span>
            <span class="meta-value">{{ displayStatus }}</span>
          </div>
          <div class="meta-row">
            <span class="meta-label">Expiry</span>
            <span class="meta-value">{{ getFormattedExpiry(probeDetails.createdAt, probeDetails.expiryTime) }}</span>
          </div>
          <div class="meta-row">
            <span class="meta-label">Condition</span>
            <span class="meta-value">{{ probeDetails.condition || 'N/A' }}</span>
          </div>
          <!-- <div class="meta-row" v-if="displayType === 'SNAPSHOT'">
            <span class="meta-label">Capture closures</span>
            <span class="meta-value">{{ probeDetails.captureClosures ? 'Enabled' : 'Disabled' }}</span>
          </div> -->
          <div class="meta-row">
            <span class="meta-label">Commit SHA</span>
            <span class="meta-value">{{ probeDetails?.commitSha || 'N/A' }}</span>
          </div>
          <div class="meta-row">
            <span class="meta-label">Action created at</span>
            <span class="meta-value">{{ formatDateTime(probeDetails?.createdAt) || 'N/A' }}</span>
          </div>
        </div>

        <div class="header-action">
          <a href="#" class="show-more-link" @click.prevent="showMoreInfo = !showMoreInfo">
            {{ showMoreInfo ? 'Show less' : 'Show more' }}
          </a>
        </div>
      </div>

      <div v-if="loading" class="not-found"
        style="flex: 1; display: flex; align-items: center; justify-content: center;">
        <div>Loading snapshots...</div>
      </div>
      <div v-else-if="!hit" class="not-found"
        style="flex: 1; display: flex; align-items: center; justify-content: center;">
        <div>No snapshots captured yet.</div>
      </div>
      <template v-else>
        <div class="hit-pagination-bar">
          <div class="pagination-controls">
            <vscode-button appearance="icon" :disabled="currentHitIndex === totalHits - 1" @click="goPrevHit"><span
                class="codicon codicon-arrow-left"></span></vscode-button>
            <span class="hit-text">HIT</span>
            <div class="hit-input-container">
              <input type="text" class="hit-current-input" :value="totalHits - currentHitIndex"
                @keydown.enter="jumpToHit" @blur="jumpToHit" />
            </div>
            <span class="hit-total">/{{ totalHits }}</span>
            <vscode-button appearance="icon" :disabled="currentHitIndex === 0" @click="goNextHit"><span
                class="codicon codicon-arrow-right"></span></vscode-button>
          </div>
        </div>

        <div class="metadata-box">
          <div class="agent-title">Agent</div>
          <div class="agent-id">{{ agentName }}</div>
          <div class="timestamp">{{ hit.timestamp }}</div>
        </div>

        <div v-if="hit.type === 'LOG'" class="log-message-box">
          <div class="log-message" :class="{ 'log-error': hit.message?.startsWith('[Error') }">{{ hit.message }}</div>
        </div>

        <template v-if="hit.type === 'SNAPSHOT'">
          <vscode-collapsible title="WATCH EXPRESSIONS" open v-if="hit.watch && Object.keys(hit.watch).length > 0">
            <div class="variables-tree-container">
              <vscode-tree>
                <VariableTreeItem v-for="(val, key) in hit.watch" :key="key" :name="key" :value="val" />
              </vscode-tree>
            </div>
          </vscode-collapsible>

          <vscode-collapsible title="VARIABLES" open>
            <div class="section-actions" slot="actions">
              <vscode-textfield placeholder="" class="variables-search">
                <span slot="content-before" class="codicon codicon-search"></span>
                <span slot="content-after" class="codicon codicon-close"></span>
              </vscode-textfield>
            </div>
            <div class="variables-tree-container">
              <vscode-tree>
                <VariableTreeItem v-for="scope in currentFrameVariables" :key="scope.name" :name="scope.name"
                  :value="scope.vars" />
              </vscode-tree>
            </div>
          </vscode-collapsible>

          <!-- Call Stack Section -->
          <vscode-collapsible title="CALL STACK" open>
            <div class="call-stack-list">
              <div v-for="(frame, index) in (hit.payload?.stack || [])" :key="index" class="stack-frame"
                :class="{ 'active-frame': index === activeFrameIndex }" @click="selectFrame(Number(index))">
                <span class="frame-func">{{ frame.functionName }}</span>
                <span class="frame-loc">{{ frame.file?.split('/').pop() || frame.fileName?.split('/').pop() }} <span
                    class="frame-line">{{ frame.line || frame.lineNumber }}</span></span>
              </div>
            </div>
          </vscode-collapsible>
        </template>
      </template>
    </div>
  </div>
</template>

<script setup lang="ts">
import {
  computed,
  onMounted,
  onUnmounted,
  provide,
  ref,
  shallowRef,
} from 'vue';
import { useRoute, useRouter } from 'vue-router';
import VariableTreeItem from '../components/VariableTreeItem.vue';
import { useActionStore } from '../stores/actionStore';
import { useAgentStore } from '../stores/agentStore';
import { formatDateTime, getEffectiveStatus } from '../utils/dateFormatter';
import getFormattedExpiry from '../utils/getFormattedExpiry';
import { getAppTrpcClient } from '../utils/trpc';

const router = useRouter();
const route = useRoute();
const agentStore = useAgentStore();
const actionStore = useActionStore();

const allActionHits = shallowRef<any[]>([]);
const currentHitIndex = ref(0);
const loading = ref(true);
let isMounted = false;

const hit = computed(() => {
  if (allActionHits.value.length === 0) return null;
  const rawHit = allActionHits.value[currentHitIndex.value];
  return {
    ...rawHit,
    file: rawHit.probe?.uiFilePath || 'Unknown',
    line: rawHit.probe?.uiLineNumber || 0,
    type: rawHit.probe?.type || 'SNAPSHOT',
    timestamp: new Date(rawHit.capturedAt).toLocaleString(),
    variables: rawHit.payload?.vars || [],
    watch: rawHit.payload?.watch || {},
    payload: rawHit.payload || null,
  };
});

const resolutionCache = new WeakMap<any, Map<string, any>>();
provide('resolutionCache', resolutionCache);

provide(
  'hitPayload',
  computed(() => hit.value?.payload || null),
);

const probeDetails = computed(() => {
  return actionStore.actions.find((a: any) => a.id === route.params.id) || null;
});

const displayFile = computed(
  () => probeDetails.value?.uiFilePath || hit.value?.file || 'Unknown',
);
const displayLine = computed(
  () => probeDetails.value?.uiLineNumber || hit.value?.line || 0,
);
const displayType = computed(
  () => probeDetails.value?.type || hit.value?.type || 'SNAPSHOT',
);
const displayStatus = computed(() => {
  if (!probeDetails.value) return 'Unknown';
  return getEffectiveStatus(
    probeDetails.value.status,
    probeDetails.value.expiryTime,
  );
});

const agentName = computed(() => {
  const serviceId = probeDetails.value?.serviceId || hit.value?.serviceId;
  if (!serviceId) return 'Unknown';
  return agentStore.serviceNames[serviceId] || serviceId;
});

const activeFrameIndex = ref(0);

const currentFrameVariables = computed(() => {
  if (!hit.value || !Array.isArray(hit.value.variables)) return [];
  const frameVars = hit.value.variables[activeFrameIndex.value] || [];
  return frameVars;
});

function selectFrame(index: number) {
  activeFrameIndex.value = index;
}

const showMoreInfo = ref(false);

const totalHits = computed(() => allActionHits.value.length);

onMounted(async () => {
  isMounted = true;
  const probeId = route.params.id as string;
  if (probeId) {
    const client = getAppTrpcClient(agentStore.serverUrl);
    try {
      const hits = await client.listSnapshots.query({ probeId });
      if (isMounted) {
        allActionHits.value = hits;
        currentHitIndex.value = 0;
        activeFrameIndex.value = 0;
      }
    } catch (err) {
      console.error('Failed to fetch snapshots:', err);
    } finally {
      if (isMounted) {
        loading.value = false;
      }
    }
  }
});

onUnmounted(() => {
  isMounted = false;
});

function goNextHit() {
  if (currentHitIndex.value > 0) {
    currentHitIndex.value--;
    activeFrameIndex.value = 0;
  }
}

function goPrevHit() {
  if (currentHitIndex.value < totalHits.value - 1) {
    currentHitIndex.value++;
    activeFrameIndex.value = 0;
  }
}

function jumpToHit(event: Event) {
  const target = event.target as HTMLInputElement;
  const val = parseInt(target.value, 10);
  if (!Number.isNaN(val) && val >= 1 && val <= totalHits.value) {
    // Math: The user wants hit #val (where 1 is the oldest hit, and totalHits is the newest hit)
    // In our array, index 0 is the newest hit, index totalHits - 1 is the oldest hit.
    // If val = totalHits, user wants the newest, which is index 0.
    // So index = totalHits - val
    currentHitIndex.value = totalHits.value - val;
    activeFrameIndex.value = 0;
  } else {
    // Revert back if invalid
    target.value = String(totalHits.value - currentHitIndex.value);
  }
}

function goBack() {
  router.push('/hits');
}
</script>

<style scoped>
.inspector-container {
  display: flex;
  flex-direction: column;
  height: 100%;
  overflow-y: auto;
  background-color: var(--vscode-editor-background);
}

.not-found {
  padding: 20px;
  text-align: center;
  color: var(--vscode-errorForeground);
}

.inspector-content {
  display: flex;
  flex-direction: column;
}

.inspector-header {
  padding: 12px;
  background-color: var(--vscode-editorWidget-background);
  border-bottom: 1px solid var(--vscode-panel-border);
  margin-bottom: 8px;
}

.header-left {
  display: flex;
  align-items: center;
  gap: 8px;
  margin-bottom: 8px;
}

.header-meta {
  display: flex;
  align-items: center;
  gap: 8px;
  padding-left: 32px;
  margin-bottom: 8px;
}

.show-more-link {
  padding-left: 32px;
  color: var(--vscode-textLink-foreground);
  text-decoration: none;
  font-size: 12px;
}

.extended-meta {
  display: flex;
  flex-direction: column;
  gap: 4px;
  padding-left: 32px;
  margin-bottom: 8px;
}

.extended-meta .meta-row {
  display: flex;
  gap: 8px;
  justify-content: flex-start;
}

.extended-meta .meta-label {
  width: 100px;
}

.hit-pagination-bar {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 8px 12px;
  background-color: var(--vscode-editorWidget-background);
  margin-bottom: 12px;
}

.pagination-controls {
  display: flex;
  align-items: center;
  gap: 4px;
}

.hit-text {
  font-size: 11px;
  font-weight: bold;
  color: var(--vscode-descriptionForeground);
  margin: 0 4px;
}

.hit-input-container {
  display: flex;
  align-items: center;
}

.hit-current-input {
  background-color: var(--vscode-input-background);
  color: var(--vscode-foreground);
  border: 1px solid var(--vscode-input-border);
  padding: 2px 4px;
  border-radius: 2px;
  font-size: 12px;
  font-weight: bold;
  width: 24px;
  text-align: center;
}

.hit-current-input:focus {
  outline: 1px solid var(--vscode-focusBorder);
  border-color: transparent;
}

.hit-total {
  font-size: 12px;
  color: var(--vscode-descriptionForeground);
}

.back-btn {
  margin-right: 4px;
}

.hit-icon.snap-color {
  color: var(--vscode-charts-blue);
}

.hit-icon.log-color {
  color: var(--vscode-charts-orange);
}

.log-message-box {
  padding: 16px;
  background-color: var(--vscode-editorWidget-background);
  border-bottom: 1px solid var(--vscode-panel-border);
  margin-bottom: 8px;
}

.log-message {
  font-family: var(--vscode-editor-font-family);
  font-size: 13px;
  line-height: 1.4;
  white-space: pre-wrap;
  word-break: break-word;
}

.log-error {
  color: var(--vscode-errorForeground);
  font-weight: bold;
}

.hit-title {
  font-family: var(--vscode-editor-font-family);
  font-size: 14px;
  font-weight: 600;
  color: var(--vscode-textLink-foreground);
}

.status-active {
  color: var(--vscode-charts-blue);
  font-size: 12px;
}

.metadata {
  padding: 12px;
  border-bottom: 1px solid var(--vscode-panel-border);
  font-size: 12px;
}

.meta-row {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.mt-sm {
  margin-top: 8px;
}

.mt-md {
  margin-top: 16px;
}

.meta-label {
  color: var(--vscode-descriptionForeground);
}

.meta-value {
  color: var(--vscode-foreground);
}

.agent-name {
  max-width: 250px;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

.metadata-box {
  padding: 12px;
}

.agent-title {
  font-size: 11px;
  color: var(--vscode-descriptionForeground);
  margin-bottom: 4px;
}

.agent-id {
  font-family: var(--vscode-editor-font-family);
  font-size: 12px;
  font-weight: bold;
  word-break: break-all;
  margin-bottom: 8px;
}

.timestamp {
  font-size: 12px;
  font-weight: bold;
}

.section-header {
  display: flex;
  align-items: center;
  gap: 6px;
  padding: 6px 12px;
  background-color: var(--vscode-sideBarSectionHeader-background);
  font-weight: 600;
  font-size: 11px;
  text-transform: uppercase;
  border-top: 1px solid var(--vscode-sideBarSectionHeader-border);
  border-bottom: 1px solid var(--vscode-sideBarSectionHeader-border);
}

.section-actions {
  margin-left: auto;
}

.variables-search {
  width: 100px;
}

.variables-tree-container {
  padding: 4px 0;
  max-height: 400px;
  overflow-y: auto;
  font-family: var(--vscode-editor-font-family);
  font-size: 13px;
  line-height: 22px;
}

.var-key {
  color: var(--vscode-symbolIcon-propertyForeground);
}

.var-type {
  color: var(--vscode-symbolIcon-classForeground);
}

.var-value {
  color: var(--vscode-debugTokenExpression-string);
}

vscode-tree-item {
  --vscode-list-hoverBackground: transparent;
  /* Remove row hover so it looks like raw code */
}

.call-stack-list {
  display: flex;
  flex-direction: column;
}

.stack-frame {
  display: flex;
  justify-content: space-between;
  padding: 4px 12px 4px 24px;
  font-family: var(--vscode-editor-font-family);
  font-size: 13px;
  cursor: pointer;
  color: var(--vscode-foreground);
}

.stack-frame:hover {
  background-color: var(--vscode-list-hoverBackground);
}

.stack-frame.active-frame {
  background-color: var(--vscode-list-activeSelectionBackground);
  color: var(--vscode-list-activeSelectionForeground);
}

.frame-func {
  font-weight: normal;
}

.frame-loc {
  opacity: 0.8;
  color: var(--vscode-textPreformat-foreground);
}

.frame-line {
  color: var(--vscode-foreground);
  background-color: var(--vscode-badge-background);
  padding: 0 6px;
  border-radius: 4px;
  margin-left: 6px;
}
</style>
