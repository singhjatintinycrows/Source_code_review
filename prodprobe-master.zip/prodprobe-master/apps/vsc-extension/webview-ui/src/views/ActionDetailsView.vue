<template>
  <div class="details-container">
    <div v-if="!action" class="not-found">Action not found</div>
    <div v-else class="details-content">

      <!-- Header -->
      <div class="details-header">
        <div class="header-left">
          <vscode-button appearance="icon" @click="goBack" class="back-btn">
            <span class="codicon codicon-chevron-left"></span>
          </vscode-button>
          <span class="action-icon codicon" :class="iconClass"></span>
          <span class="action-title">{{ actionName }} details</span>
        </div>
      </div>

      <!-- Metadata Section -->
      <div class="section-header mt-sm">
        <span class="codicon codicon-info"></span>
        Metadata
      </div>

      <div class="info-group">
        <div class="info-label">ID</div>
        <div class="info-value flex-row-between">
          {{ action.id }}
          <vscode-button appearance="icon" title="Copy"><span class="codicon codicon-copy"></span></vscode-button>
        </div>
      </div>

      <div class="info-group">
        <div class="info-label">CREATION TIME</div>
        <div class="info-value">{{ action.createdAt }}</div>
      </div>

      <div class="info-group">
        <div class="info-label">OWNER</div>
        <div class="info-value">{{ action.createdBy }}</div>
      </div>

      <!-- Details Section -->
      <div class="section-header mt-md flex-row-between">
        <div>
          <span class="codicon codicon-info"></span>
          Details
        </div>
        <vscode-button appearance="icon" title="Edit" @click="goEdit"><span
            class="codicon codicon-edit"></span></vscode-button>
      </div>

      <div class="info-group">
        <div class="info-label">SOURCE</div>
        <div class="info-value agent-name">{{ agentName }} (pid 1)</div>
      </div>

      <div class="info-group">
        <div class="info-label">FILENAME & LINE</div>
        <div class="info-value">{{ action.uiFilePath }}:{{ action.uiLineNumber }}</div>
      </div>

      <div class="info-group" v-if="action && action.type === 'LOG'">
        <div class="info-label">Log to Stdout</div>
        <div class="info-value">{{ action.shouldLogToStdout ? 'Enabled' : 'Disabled' }} ({{ action.logLevel || 'INFO' }})</div>
      </div>

      <div class="info-group" v-if="action.type === 'LOG'">
        <div class="info-label">LOG MESSAGE</div>
        <div class="info-value">{{ action.template || 'Hello world ${expression}' }}</div>
      </div>

      <div class="info-group">
        <div class="info-label">CONDITION</div>
        <div class="info-value">N/A</div>
      </div>

      <div class="info-group">
        <div class="info-label">Expiry</div>
        <div class="info-value">{{ getFormattedExpiry(action.createdAt, action.expiryTime) }}</div>
      </div>

      <div class="info-group" v-if="action.type !== 'SNAPSHOT'">
        <div class="info-label">IGNORE QUOTA</div>
        <div class="info-value">No</div>
      </div>

    </div>
  </div>
</template>

<script setup lang="ts">
import { computed } from 'vue';
import { useRoute, useRouter } from 'vue-router';
import { useActionStore } from '../stores/actionStore';
import getFormattedExpiry from '../utils/getFormattedExpiry';

const route = useRoute();
const router = useRouter();
const actionStore = useActionStore();

const actionId = route.params.id as string;
const action = computed(() =>
  actionStore.actions.find((a: any) => a.id === actionId),
);

const agentName = computed(() => {
  if (!action.value) return 'Unknown';
  // Simplified for now without mockStore
  return action.value.serviceId || 'Unknown';
});

const actionName = computed(() => {
  if (!action.value) return 'Action';
  switch (action.value.type) {
    case 'LOG':
      return 'Log';
    case 'SNAPSHOT':
      return 'Snapshot';
    case 'COUNTER':
      return 'Counter';
    case 'DURATION':
      return 'Tic & Toc';
    case 'METRIC':
      return 'Custom Metric';
    default:
      return 'Action';
  }
});

const iconClass = computed(() => {
  if (!action.value) return '';
  switch (action.value.type) {
    case 'LOG':
      return 'codicon-list-flat log-color';
    case 'SNAPSHOT':
      return 'codicon-device-camera snap-color';
    case 'COUNTER':
      return 'codicon-symbol-number metric-color';
    case 'DURATION':
      return 'codicon-watch metric-color';
    case 'METRIC':
      return 'codicon-graph-line metric-color';
    default:
      return '';
  }
});

function goBack() {
  router.push('/actions');
}

function goEdit() {
  if (action.value) {
    router.push(`/edit/${action.value.type.toLowerCase()}/${action.value.id}`);
  }
}
</script>

<style scoped>
.details-container {
  display: flex;
  flex-direction: column;
  height: 100%;
  overflow-y: auto;
  background-color: var(--vscode-editor-background);
}

.not-found {
  padding: 20px;
  text-align: center;
  color: var(--vscode-errorForeground);
}

.details-content {
  display: flex;
  flex-direction: column;
}

.details-header {
  padding: 12px;
  border-bottom: 1px solid var(--vscode-panel-border);
}

.header-left {
  display: flex;
  align-items: center;
  gap: 8px;
}

.log-color {
  color: var(--vscode-charts-orange);
}

.snap-color {
  color: var(--vscode-charts-blue);
}

.metric-color {
  color: var(--vscode-charts-green);
}

.action-title {
  font-family: var(--vscode-editor-font-family);
  font-size: 14px;
  font-weight: bold;
}

.section-header {
  display: flex;
  align-items: center;
  gap: 6px;
  padding: 8px 16px;
  font-weight: bold;
  font-size: 14px;
  color: var(--vscode-foreground);
}

.flex-row-between {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.mt-sm {
  margin-top: 8px;
}

.mt-md {
  margin-top: 16px;
}

.info-group {
  padding: 8px 16px;
  display: flex;
  flex-direction: column;
  gap: 4px;
}

.info-label {
  font-size: 10px;
  font-weight: bold;
  color: var(--vscode-descriptionForeground);
  text-transform: uppercase;
}

.info-value {
  font-size: 12px;
  color: var(--vscode-foreground);
  font-family: var(--vscode-editor-font-family);
  font-weight: 500;
  word-break: break-all;
}

.agent-name {
  max-width: 100%;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}
</style>
