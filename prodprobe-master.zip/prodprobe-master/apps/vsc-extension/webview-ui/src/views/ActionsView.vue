<template>
  <div class="view-container">
    <div class="toolbar">
      <vscode-single-select class="sort-select" :value="sortBy" @change="sortBy = ($event.target as any).value">
        <vscode-option value="filename">File name</vscode-option>
        <vscode-option value="creation">Creation time</vscode-option>
      </vscode-single-select>

      <div style="position: relative; margin-left: auto; display: flex;">
        <vscode-button appearance="icon" title="Filter Actions" @click.stop="showActionsFilter = !showActionsFilter">
          <div style="position: relative; display: flex; align-items: center; justify-content: center;">
            <span class="codicon codicon-filter"></span>
            <vscode-badge v-if="selectedStatuses.length > 0" class="filter-badge" variant="counter">{{
              selectedStatuses.length
              }}</vscode-badge>
          </div>
        </vscode-button>

        <div v-if="showActionsFilter" class="action-menu status-menu" @click.stop>

          <!-- STATUS FILTER -->
          <div class="menu-group">FILTER BY STATUS</div>
          <div class="menu-item" style="padding: 2px 14px"
            v-for="st in ['ACTIVE', 'INACTIVE', 'EXPIRED', 'COMPLETED', 'ERROR']" :key="st"
            @click="toggleStatusFilter(st)">
            <vscode-checkbox :checked="selectedStatuses.includes(st)"></vscode-checkbox>
            {{ st }}
          </div>
        </div>
      </div>

      <vscode-button appearance="icon" title="Refresh Actions" @click="actionStore.fetchActions()"><span
          class="codicon codicon-sync"></span></vscode-button>
    </div>

    <div class="actions-header">
      <span class="actions-count">{{ filteredActions.length }} Action{{ filteredActions.length !== 1 ? 's' : ''
        }}</span>
      <vscode-button appearance="icon" title="Delete All" @click="deleteAllActions"><span
          class="codicon codicon-trash"></span></vscode-button>
    </div>

    <div v-if="filteredActions.length === 0" class="empty-state">
      <div class="empty-icon"><span class="codicon codicon-list-flat"></span></div>
      <div class="empty-text">No actions added yet.</div>
    </div>

    <div v-else class="actions-list">
      <div v-for="action in filteredActions" :key="action.id" class="action-item" :title="action.isLive ? 'Probe is live.' : getEffectiveStatus(action) === 'ACTIVE' ? 'Probe is initializing. Refresh to check status. A green tick indicates it is live.' :''" >
        <div class="action-main">
          <span class="action-icon codicon" :class="getIconForType(action.type)"></span>
          <div class="action-details">
            <div class="action-name">
              <span class="action-path">{{ action.uiFilePath }}:{{ action.uiLineNumber }}</span>
              <template v-if="getEffectiveStatus(action) === 'ACTIVE'">
                <span v-if="action.isLive" class="codicon codicon-pass-filled status-live" title="Probe is live"></span>
                <span v-else class="codicon codicon-loading codicon-modifier-spin status-pending"
                  title="Probe is initializing. Refresh to check status. A green tick indicates it is live."></span>
              </template>

              <span v-if="isCommitMismatch(action.commitSha, agentStore.localCommitSha)"
                class="codicon codicon-git-commit status-commit-mismatch"
                :title="`Probe is on a different commit (${(action.commitSha || '').trim().substring(0, 7)}). Local workspace: ${(agentStore.localCommitSha || '').trim().substring(0, 7)}`">
              </span>
            </div>
            <div class="action-id">{{ action.id }}</div>
            <div class="action-time" v-if="action.createdAt">
              Created at: {{ new Date(action.createdAt).toLocaleString() }}   
              &middot;<span :class="`status-text-${getEffectiveStatus(action).toLowerCase()}`">{{ getEffectiveStatus(action) }}</span>
            </div>
            <div class="action-time" v-if="action.expiryTime && (getEffectiveStatus(action) === 'ACTIVE' || getEffectiveStatus(action) === 'INACTIVE')">
              {{ formatExpiresIn(action.expiryTime) }}
            </div>
          </div>
        </div>
        <div class="action-controls" style="position: relative;">
          <vscode-checkbox v-if="getEffectiveStatus(action) === 'ACTIVE' || getEffectiveStatus(action) === 'INACTIVE'"
            :checked="getEffectiveStatus(action) === 'ACTIVE'" @change="actionStore.toggleProbeStatus(action.id, action.status)"
            :title="getEffectiveStatus(action) === 'ACTIVE' ? 'Active: Click to deactivate' : 'Inactive: Click to activate'"></vscode-checkbox>
          <vscode-button appearance="icon"
            @click.stop="activeMenuId = activeMenuId === action.id ? null : action.id"><span
              class="codicon codicon-ellipsis"></span></vscode-button>

          <div v-if="activeMenuId === action.id" class="action-menu" @click.stop>
            <div class="menu-group">ACTION OPTIONS</div>
            <div class="menu-item" @click="editAction(action)"><span class="codicon codicon-edit"></span> View/Edit
            </div>
            <div class="menu-item" @click="infoAction(action)"><span class="codicon codicon-info"></span> Info</div>
            <div class="menu-item" @click.stop="goToAction(action)"><span class="codicon codicon-target"></span> Go to</div>
            <div class="menu-item" @click.stop="deleteSingleAction(action)"><span class="codicon codicon-trash"></span>
              Delete</div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { storeToRefs } from 'pinia';
import { computed, onMounted, onUnmounted, ref, watch } from 'vue';
import { useRouter } from 'vue-router';
import { useActionStore } from '../stores/actionStore';
import { useAgentStore } from '../stores/agentStore';
import { useFilterStore } from '../stores/filterStore';
import {
  formatExpiresIn,
  getEffectiveStatus as getEffectiveStatusShared,
} from '../utils/dateFormatter';
import { vscode } from '../utils/vscode';

const actionStore = useActionStore();
const filterStore = useFilterStore();
const agentStore = useAgentStore();
const router = useRouter();

const { createdByMe } = storeToRefs(filterStore);

const activeMenuId = ref<string | null>(null);
const showActionsFilter = ref(false);

const sortBy = ref<string>('creation');
const selectedStatuses = ref<string[]>([]);
const currentUserEmail = computed(() => agentStore.userEmail);

onMounted(() => {
  document.addEventListener('click', closeMenus);

  const savedStatuses = localStorage.getItem('hyperprobe_status_filter');
  if (savedStatuses) {
    try {
      selectedStatuses.value = JSON.parse(savedStatuses);
    } catch (e) {
      selectedStatuses.value = ['ACTIVE', 'COMPLETED', 'EXPIRED'];
    }
  } else {
    selectedStatuses.value = ['ACTIVE', 'COMPLETED', 'EXPIRED'];
  }
});

watch(
  selectedStatuses,
  (newVal) => {
    localStorage.setItem('hyperprobe_status_filter', JSON.stringify(newVal));
  },
  { deep: true },
);

function asyncConfirm(
  message: string,
  confirmText: string = 'Delete',
): Promise<boolean> {
  return new Promise((resolve) => {
    const msgId = Date.now().toString() + Math.random().toString();

    // Setup a one-time listener for the extension's response
    const handler = (event: MessageEvent) => {
      const data = event.data;
      if (data.type === 'confirmDeleteResponse' && data.msgId === msgId) {
        window.removeEventListener('message', handler);
        resolve(data.confirmed);
      }
    };
    window.addEventListener('message', handler);

    if (vscode.isAvailable) {
      vscode.postMessage({
        type: 'confirmDelete',
        message,
        msgId,
        confirmText,
      });
    } else {
      // Fallback for browser dev mode
      resolve(window.confirm(message));
    }
  });
}

function closeMenus() {
  showActionsFilter.value = false;
  activeMenuId.value = null;
}

onUnmounted(() => {
  document.removeEventListener('click', closeMenus);
});

function toggleStatusFilter(st: string) {
  if (selectedStatuses.value.includes(st)) {
    selectedStatuses.value = selectedStatuses.value.filter((s) => s !== st);
  } else {
    selectedStatuses.value.push(st);
  }
}

const filteredActions = computed(() => {
  let actions = [...actionStore.actions];
  actions = actions.filter((action) => {
    // status filter
    const effectiveStatus = getEffectiveStatus(action);
    if (
      selectedStatuses.value.length &&
      !selectedStatuses.value.includes(effectiveStatus)
    ) {
      return false;
    }

    // created by me filter
    if (createdByMe.value && action.createdBy !== currentUserEmail.value) {
      return false;
    }

    return true;
  });

  // Global strict tag filtering
  if (filterStore.activeTags.length > 0) {
    actions = actions.filter((action) => {
      // Must match ALL active tags
      return filterStore.activeTags.every((tag) => {
        if (tag.type === 'serviceName') {
          const name =
            agentStore.serviceNames[action.serviceId] || action.serviceId;
          return name.toLowerCase() === tag.value.toLowerCase();
        }
        const val = tag.value.toLowerCase();
        const actionVal = String(action[tag.type] || '').toLowerCase();
        return actionVal === val;
      });
    });
  }

  // Global fuzzy text filtering
  const query = filterStore.searchQuery.toLowerCase().trim();
  if (query && !query.includes(':')) {
    actions = actions.filter((action) => {
      return JSON.stringify(action).toLowerCase().includes(query);
    });
  }

  // Sorting
  if (sortBy.value === 'filename') {
    actions.sort((a, b) =>
      (a.uiFilePath || '').localeCompare(b.uiFilePath || ''),
    );
  } else {
    // creation time (descending by default)
    actions.sort((a, b) => {
      const timeA = a.createdAt ? new Date(a.createdAt).getTime() : 0;
      const timeB = b.createdAt ? new Date(b.createdAt).getTime() : 0;
      return timeB - timeA;
    });
  }

  return actions;
});

function getIconForType(type: string) {
  switch (type) {
    case 'SNAPSHOT':
      return 'codicon-device-camera';
    case 'LOG':
      return 'codicon-list-flat';
    case 'COUNTER':
      return 'codicon-symbol-number';
    case 'DURATION':
      return 'codicon-watch';
    case 'METRIC':
      return 'codicon-graph-line';
    default:
      return 'codicon-symbol-event';
  }
}

async function editAction(action: any) {
  activeMenuId.value = null;
  router.push(`/edit/${action.type.toLowerCase()}/${action.id}`);
}

function goToAction(action: any) {
  activeMenuId.value = null;
  if (action.uiFilePath && action.uiLineNumber) {
    vscode.postMessage({
      type: 'revealLine',
      filePath: action.uiFilePath,
      lineNumber: action.uiLineNumber,
    });
  }
}

function infoAction(action: any) {
  activeMenuId.value = null;
  router.push(`/actions/${action.id}`);
}

async function deleteSingleAction(action: any) {
  activeMenuId.value = null;
  if (await asyncConfirm(`Are you sure you want to delete this action?`)) {
    try {
      await actionStore.deleteActions([action.id]);
    } catch (e) {
      console.error('Failed to delete action', e);
    }
  }
}

async function deleteAllActions() {
  const ids = filteredActions.value.map((a) => a.id);
  if (ids.length === 0) return;

  if (
    await asyncConfirm(
      `Are you sure you want to delete ${ids.length} action(s)?`,
    )
  ) {
    try {
      await actionStore.deleteActions(ids);
    } catch (e) {
      console.error('Failed to delete actions', e);
    }
  }
}

function isCommitMismatch(
  actionCommit: string | undefined,
  localCommit: string | undefined,
) {
  if (!actionCommit || !localCommit) return false;
  const a = actionCommit.trim().toLowerCase();
  const b = localCommit.trim().toLowerCase();
  // Treat short SHAs as matches when one is a prefix of the other.
  if (a === b || a.startsWith(b) || b.startsWith(a)) return false;
  return true;
}

function getEffectiveStatus(action: any): string {
  return getEffectiveStatusShared(action.status, action.expiryTime);
}
</script>

<style scoped>
.view-container {
  display: flex;
  flex-direction: column;
  height: 100%;
  overflow: hidden;
}

.toolbar {
  display: flex;
  gap: 8px;
  padding: 8px;
  align-items: center;
  border-bottom: 1px solid var(--vscode-panel-border);
}

.search-input {
  flex: 1;
}

.sort-select {
  width: 110px;
}

.actions-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 8px 12px;
  border-bottom: 1px solid var(--vscode-panel-border);
}

.actions-count {
  font-size: 11px;
  color: var(--vscode-descriptionForeground);
  font-weight: 600;
  text-transform: uppercase;
  letter-spacing: 0.5px;
}

.empty-state {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  flex: 1;
  color: var(--vscode-descriptionForeground);
  opacity: 0.6;
}

.empty-icon .codicon {
  font-size: 48px;
  margin-bottom: 16px;
}

.actions-list {
  flex: 1;
  overflow-y: auto;
}

.action-item {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 8px 12px;
  border-bottom: 1px solid var(--vscode-panel-border);
}

.action-item:hover {
  background-color: var(--vscode-list-hoverBackground);
}

.action-main {
  display: flex;
  align-items: flex-start;
  gap: 8px;
  flex: 1;
  min-width: 0;
}

.action-icon {
  color: var(--vscode-symbolIcon-methodForeground);
  margin-top: 2px;
  flex-shrink: 0;
}

.action-icon.codicon-device-camera {
  color: var(--vscode-charts-blue);
}

.action-icon.codicon-list-flat {
  color: var(--vscode-charts-orange);
}

.action-details {
  display: flex;
  flex-direction: column;
  min-width: 0;
}

.action-name {
  font-family: var(--vscode-editor-font-family);
  font-size: 12px;
  color: var(--vscode-textLink-foreground);
  display: flex;
  align-items: flex-start;
  gap: 6px;
}

.action-path {
  word-break: break-all;
  overflow-wrap: anywhere;
}

.action-id {
  font-size: 10px;
  color: var(--vscode-descriptionForeground);
  font-family: var(--vscode-editor-font-family);
  margin-top: 2px;
}

.status-live {
  color: var(--vscode-testing-iconPassed);
  font-size: 12px;
  flex-shrink: 0;
  /* margin-top: 2px; */
}

.status-pending {
  color: var(--vscode-charts-orange);
  font-size: 12px;
  flex-shrink: 0;
  /* margin-top: 2px; */
}

.status-commit-mismatch {
  color: var(--vscode-editorWarning-foreground, #cca700);
  font-size: 14px;
  flex-shrink: 0;
  /* margin-top: 2px; */
  /* cursor: help; */
}

.status-disabled {
  color: var(--vscode-descriptionForeground);
  font-size: 12px;
}

.status-text-active,
.status-text-inactive {
  color: var(--vscode-textLink-foreground);
}

.status-text-completed {
  color: var(--vscode-testing-iconPassed);
}

.status-text-expired,
.status-text-error {
  color: var(--vscode-errorForeground);
}

.action-controls {
  display: flex;
  align-items: center;
  gap: 4px;
}

.action-menu {
  position: absolute;
  top: 30px;
  right: 0;
  background-color: var(--vscode-editorWidget-background);
  border: 1px solid var(--vscode-widget-border);
  box-shadow: 0 4px 8px var(--vscode-widget-shadow);
  border-radius: 4px;
  z-index: 100;
  min-width: 148px;
  padding: 4px 0;
}

.status-menu {
  right: 0;
  top: 30px;
}

.menu-group {
  font-size: 10px;
  font-weight: bold;
  color: var(--vscode-descriptionForeground);
  padding: 4px 12px;
  margin-top: 4px;
}

.menu-item {
  padding: 6px 12px;
  cursor: pointer;
  display: flex;
  align-items: center;
  gap: 4px;
  font-size: 12px;
}

.menu-item:hover {
  background-color: var(--vscode-list-hoverBackground);
}

.filter-badge {
  position: absolute;
  top: -4px;
  right: -16px;
  transform: scale(0.75);
  pointer-events: none;
}
</style>
