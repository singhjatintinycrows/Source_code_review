<template>
  <div class="view-container">
    <div class="toolbar">
      <vscode-textfield placeholder="Filter snapshot hits" class="search-input" :value="searchQuery"
        @input="searchQuery = ($event.target as any).value">
        <span slot="content-before" class="codicon codicon-search"></span>
        <span slot="content-after" class="codicon codicon-close" style="cursor: pointer;" v-if="searchQuery"
          @click="searchQuery = ''"></span>
      </vscode-textfield>
      <vscode-single-select class="sort-select" :value="sortBy" @change="sortBy = ($event.target as any).value">
        <vscode-option value="recent">Recently hit</vscode-option>
        <vscode-option value="filename">File name</vscode-option>
      </vscode-single-select>
      <vscode-button appearance="icon" title="Refresh Hits" @click="actionStore.fetchActions()"><span
          class="codicon codicon-sync"></span></vscode-button>
    </div>

    <div v-if="groupedHits.length === 0" class="empty-state">
      <div class="empty-icon"><span class="codicon codicon-device-camera"></span></div>
      <div class="empty-text">No snapshots captured yet.</div>
    </div>

    <div v-else class="hits-list">
      <div v-for="group in groupedHits" :key="group.latestHit.actionId" class="hit-item"
        @click="openInspector(group.latestHit)">
        <div class="hit-header">
          <span class="hit-icon codicon"
            :class="group.latestHit.type === 'LOG' ? 'codicon-list-flat' : 'codicon-device-camera'"></span>
          <span class="hit-name overflow-fix">{{ group.latestHit.file }}:{{ group.latestHit.line }}</span>
        </div>

        <!-- Add a log preview right here -->
        <!-- <div v-if="group.latestHit.type === 'LOG'" class="hit-log-preview">
          View latest log entries...
        </div> -->

        <div class="hit-meta-group">
          <div class="hit-meta-row">
            <span class="meta-label">Action ID</span>
            <span class="meta-value overflow-fix">{{ group.latestHit.id }}</span>
          </div>
          <div class="hit-meta-row" style="align-items: flex-start; margin-top: 4px; margin-bottom: 4px;">
            <span class="meta-label" style="margin-top: 2px;">Source</span>
            <span class="meta-value agent-name" :title="formatSource(group.latestHit)">{{
              formatSource(group.latestHit) }}</span>
          </div>
          <div class="hit-meta-row" v-if="group.latestHit.createdAt">
            <span class="meta-label">Action created at</span>
            <span class="meta-value overflow-fix">{{ formatDateTime(group.latestHit.createdAt) }}</span>
          </div>
          <div class="hit-meta-row">
            <span class="meta-label">HIT {{ group.count }} / {{ group.latestHit.hitLimit || '∞' }}</span>
            <!-- <vscode-button appearance="secondary">Share</vscode-button> -->
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { storeToRefs } from 'pinia';
import { computed, ref } from 'vue';
import { useRouter } from 'vue-router';
import { useActionStore } from '../stores/actionStore';
import { useAgentStore } from '../stores/agentStore';
import { useFilterStore } from '../stores/filterStore';
import { formatDateTime } from '../utils/dateFormatter';

const router = useRouter();
const actionStore = useActionStore();
const agentStore = useAgentStore();
const filterStore = useFilterStore();

const searchQuery = ref('');
const sortBy = ref('recent');

const { createdByMe } = storeToRefs(filterStore);
const currentUserEmail = computed(() => agentStore.userEmail);

const groupedHits = computed(() => {
  let actions = actionStore.actions.filter(
    (action: any) => action.hitCount > 0,
  );

  // Local filtering by file path
  const query = searchQuery.value.toLowerCase().trim();
  if (query) {
    actions = actions.filter((action: any) => {
      const filePath = action.uiFilePath || '';
      return filePath.toLowerCase().includes(query);
    });
  }

  // created by me filter
  if (createdByMe.value) {
    actions = actions.filter(
      (action: any) => action.createdBy === currentUserEmail.value,
    );
  }

  // Global strict tag filtering
  if (filterStore.activeTags.length > 0) {
    actions = actions.filter((action) => {
      return filterStore.activeTags.every((tag) => {
        if (tag.type === 'serviceName') {
          const name =
            agentStore.serviceNames[action.serviceId] || action.serviceId;
          return name.toLowerCase() === tag.value.toLowerCase();
        }
        const actionVal = String(action[tag.type] || '').toLowerCase();
        return actionVal === tag.value.toLowerCase();
      });
    });
  }

  // Global fuzzy text filtering
  const filterQuery = filterStore.searchQuery.toLowerCase().trim();
  if (filterQuery && !filterQuery.includes(':')) {
    actions = actions.filter((action) => {
      return JSON.stringify(action).toLowerCase().includes(filterQuery);
    });
  }

  const results = actions.map((action: any) => ({
    count: action.hitCount,
    latestHit: {
      id: action.id, // Keep id as it is used by the router template
      actionId: action.id,
      timestampMs: action.latestHitAt
        ? new Date(action.latestHitAt).getTime()
        : 0,
      timestamp: action.latestHitAt,
      file: action.uiFilePath,
      line: action.uiLineNumber,
      type: action.type,
      serviceId: action.serviceId,
      environment: action.environment,
      commitSha: action.commitSha,
      hitLimit: action.hitLimit,
      createdAt: action.createdAt,
    },
  }));

  if (sortBy.value === 'recent') {
    results.sort(
      (a: any, b: any) => b.latestHit.timestampMs - a.latestHit.timestampMs,
    );
  } else {
    // Sort by filename
    results.sort((a: any, b: any) =>
      (a.latestHit.file || '').localeCompare(b.latestHit.file || ''),
    );
  }

  return results;
});

function openInspector(hit: any) {
  if (hit.type === 'LOG') {
    router.push(`/logs/${hit.id}`);
  } else {
    router.push(`/hits/${hit.id}`);
  }
}

function formatSource(hit: any) {
  const serviceName = agentStore.serviceNames[hit.serviceId] || hit.serviceId;
  return `Service: ${serviceName} | Env: ${hit.environment} | Commit: ${hit.commitSha ? hit.commitSha.substring(0, 7) : 'N/A'}`;
}
</script>

<style scoped>
.view-container {
  display: flex;
  flex-direction: column;
  height: 100%;
  overflow: hidden;
}

.toolbar {
  display: flex;
  gap: 8px;
  padding: 8px;
  align-items: center;
  border-bottom: 1px solid var(--vscode-panel-border);
}

.search-input {
  flex: 1;
}

.sort-select {
  width: 120px;
}

.empty-state {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  flex: 1;
  color: var(--vscode-descriptionForeground);
  opacity: 0.6;
}

.overflow-fix {
  word-break: break-all;
  overflow-wrap: anywhere;
}

.empty-icon .codicon {
  font-size: 48px;
  margin-bottom: 16px;
}

.hits-list {
  flex: 1;
  overflow-y: auto;
  padding: 8px;
}

.hit-item {
  position: relative;
  display: flex;
  flex-direction: column;
  gap: 4px;
  padding: 10px 12px;
  margin-bottom: 8px;
  background-color: var(--vscode-editorWidget-background);
  border: 1px solid var(--vscode-widget-border);
  border-radius: 4px;
  cursor: pointer;
  transition: border-color 0.1s;
}

.hit-item:hover {
  border-color: var(--vscode-focusBorder);
}

.hit-header {
  display: flex;
  align-items: center;
  gap: 8px;
  margin-bottom: 8px;
}

.hit-icon.codicon-device-camera {
  color: var(--vscode-charts-blue);
}

.hit-icon.codicon-list-flat {
  color: var(--vscode-charts-orange);
}

.hit-name {
  font-family: var(--vscode-editor-font-family);
  font-size: 13px;
  font-weight: 600;
  color: var(--vscode-textLink-foreground);
}

.hit-meta-group {
  display: flex;
  flex-direction: column;
  gap: 8px;
}

.hit-meta-row {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.meta-label {
  font-size: 11px;
  color: var(--vscode-descriptionForeground);
}

.meta-value {
  font-size: 12px;
  color: var(--vscode-foreground);
  font-family: var(--vscode-editor-font-family);
}

.agent-name {
  max-width: 85%;
  text-align: right;
  line-height: 1.4;
  font-size: 11px;
  color: var(--vscode-descriptionForeground);
  word-break: break-all;
}

/* .hit-log-preview {
  font-family: var(--vscode-editor-font-family);
  font-size: 11px;
  color: var(--vscode-descriptionForeground);
  margin-bottom: 8px;
  background-color: var(--vscode-textCodeBlock-background);
  padding: 4px;
  border-radius: 2px;
  overflow: hidden;
  text-overflow: ellipsis;
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
} */
</style>
