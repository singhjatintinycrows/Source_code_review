<template>
  <div class="settings-container">
    <div class="settings-header">
      <vscode-button appearance="icon" @click="goBack" class="back-btn">
        <span class="codicon codicon-chevron-left"></span>
      </vscode-button>
      <span class="settings-title">Settings</span>
    </div>

    <div class="settings-content">

      <!-- Extension Settings -->
      <div class="settings-section">
        <h3>HyperProbe: Certificate Pinning List (Applies to all profiles)</h3>
        <div class="setting-desc">Server certificates</div>
        <vscode-textfield placeholder="ee80811b38e7e6c..." class="w-full"></vscode-textfield>
        <vscode-button appearance="secondary" class="mt-sm">Add Item</vscode-button>
      </div>

      <div class="settings-section">
        <h3>HyperProbe: Send Source Full Path (Applies to all profiles)</h3>
        <vscode-checkbox>Send source full path</vscode-checkbox>
      </div>

      <div class="settings-section">
        <h3>HyperProbe: Server URL (Applies to all profiles)</h3>
        <div class="setting-desc">HyperProbe server URL</div>
        <vscode-textfield value="https://app.hyperprobe.com" class="w-full"></vscode-textfield>
      </div>

    </div>
  </div>
</template>

<script setup lang="ts">
import { useRouter } from 'vue-router';

const router = useRouter();

function goBack() {
  router.push('/');
}
</script>

<style scoped>
.settings-container {
  display: flex;
  flex-direction: column;
  height: 100%;
  overflow-y: auto;
  background-color: var(--vscode-editor-background);
}

.settings-header {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 12px;
  border-bottom: 1px solid var(--vscode-panel-border);
}

.settings-title {
  font-family: var(--vscode-editor-font-family);
  font-size: 16px;
  font-weight: bold;
}

.settings-content {
  padding: 16px;
  display: flex;
  flex-direction: column;
  gap: 24px;
}

.settings-section h3 {
  margin: 0 0 4px 0;
  font-size: 13px;
  font-weight: 600;
  color: var(--vscode-foreground);
}

.setting-desc {
  font-size: 12px;
  color: var(--vscode-descriptionForeground);
  margin-bottom: 8px;
}

.w-full {
  width: 100%;
}

.mt-sm {
  margin-top: 8px;
}
</style>
