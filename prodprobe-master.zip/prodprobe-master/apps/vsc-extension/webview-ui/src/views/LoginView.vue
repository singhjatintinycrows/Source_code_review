<template>
  <div class="login-container">
    <div class="main-content">
      <h2>Authentication Required</h2>
      <p>Please log in to the HyperProbe backend and start debugging.</p>
      <button class="login-btn" @click="login">Log In</button>
    </div>
    <div class="bottom-bar">
      <span>v{{ extensionVersion }}</span>
    </div>
  </div>
</template>

<script setup lang="ts">
import { vscode } from '../utils/vscode';

const extensionVersion = import.meta.env.VITE_EXTENSION_VERSION || 'unknown';

function login() {
  if (vscode.isAvailable) {
    vscode.postMessage({ type: 'login' });
  } else {
    console.log('Login clicked (mock)');
  }
}
</script>

<style scoped>
.login-container {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  height: 100vh;
  width: 100vw;
  margin: 0;
  padding: 20px;
  text-align: center;
  box-sizing: border-box;
}

.main-content {
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  width: 100%;
}

.login-btn {
  background-color: var(--vscode-button-background);
  color: var(--vscode-button-foreground);
  border: none;
  padding: 10px 20px;
  font-size: 14px;
  cursor: pointer;
  margin-top: 15px;
  border-radius: 2px;
}

.login-btn:hover {
  background-color: var(--vscode-button-hoverBackground);
}

.bottom-bar {
  display: flex;
  justify-content: flex-end;
  align-items: center;
  padding: 2px 8px;
  background-color: var(--vscode-statusBar-background);
  color: var(--vscode-statusBar-foreground);
  font-size: 14px;
  border-top: 1px solid var(--vscode-statusBar-border, transparent);
  width: 100%;
  position: absolute;
  bottom: 0;
  left: 0;
  box-sizing: border-box;
}
</style>
