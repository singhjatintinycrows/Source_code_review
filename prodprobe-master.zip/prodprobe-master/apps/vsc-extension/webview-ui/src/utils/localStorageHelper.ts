function jsonParseIfNotNull(val: string | null): boolean | null {
  if (val === null) {
    return null;
  }

  try {
    const parsed = JSON.parse(val);
    return typeof parsed === 'boolean' ? parsed : null;
  } catch {
    return null;
  }
}

function setCreatedByMeFilter(createdByMe: boolean) {
  localStorage.setItem(
    'hyperprobe_created_by_me_filter',
    JSON.stringify(createdByMe),
  );
}

function getCreatedByMeFilter(): boolean | null {
  const l = localStorage.getItem('hyperprobe_created_by_me_filter');
  return jsonParseIfNotNull(l);
}

export { getCreatedByMeFilter, setCreatedByMeFilter };
