function formatDateTime(val: string | Date | null | undefined): string {
  if (!val) return 'N/A';
  const parsedDate = new Date(val);
  return Number.isNaN(parsedDate.getTime())
    ? 'N/A'
    : parsedDate.toLocaleString();
}

function formatExpiresIn(
  expiryTime: string | number | bigint | null | undefined,
): string {
  if (!expiryTime) return 'N/A';

  let expiryMs = Number(expiryTime);
  if (Number.isNaN(expiryMs)) {
    expiryMs = new Date(expiryTime as any).getTime();
  }
  if (Number.isNaN(expiryMs)) return 'N/A';

  const now = Date.now();
  const diffMs = expiryMs - now;

  if (diffMs <= 0) {
    return 'Expired';
  }

  const diffMins = Math.ceil(diffMs / 60000);
  if (diffMins < 60) {
    return `Expires in: ${diffMins} ${diffMins === 1 ? 'minute' : 'minutes'}`;
  }

  const diffHours = Math.floor(diffMins / 60);
  const remainingMins = diffMins % 60;
  if (remainingMins === 0) {
    return `Expires in: ${diffHours} ${diffHours === 1 ? 'hour' : 'hours'}`;
  }
  return `Expires in: ${diffHours} ${diffHours === 1 ? 'hour' : 'hours'}, ${remainingMins} ${remainingMins === 1 ? 'minute' : 'minutes'}`;
}

function isExpired(expiryTime: any): boolean {
  if (!expiryTime || (typeof expiryTime === 'string' && !expiryTime.trim()))
    return false;

  let expiryMs = Number(expiryTime);
  if (Number.isNaN(expiryMs)) {
    expiryMs = new Date(expiryTime).getTime();
  }
  if (Number.isNaN(expiryMs)) return true; // Treat invalid/unparseable expiry as expired

  return expiryMs <= Date.now();
}

function getEffectiveStatus(
  status: string | undefined,
  expiryTime: any,
): string {
  const currentStatus = status || 'ACTIVE';
  const isTerminal =
    currentStatus === 'COMPLETED' ||
    currentStatus === 'ERROR' ||
    currentStatus === 'EXPIRED';
  if (!isTerminal && isExpired(expiryTime)) {
    return 'EXPIRED';
  }
  return currentStatus;
}

export { formatDateTime, formatExpiresIn, getEffectiveStatus, isExpired };
