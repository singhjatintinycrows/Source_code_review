import type { TRPCLink } from '@trpc/client';
import {
  createTRPCProxyClient,
  httpBatchLink,
  TRPCClientError,
} from '@trpc/client';
import { observable } from '@trpc/server/observable';
import type { AppRouter } from 'backend';
import superjson from 'superjson';
import { useAgentStore } from '../stores/agentStore';
import { vscode } from './vscode';

const errorLink: TRPCLink<AppRouter> = () => {
  return ({ next, op }) => {
    return observable((observer) => {
      const unsubscribe = next(op).subscribe({
        next(value) {
          observer.next(value);
        },
        error(err) {
          if (
            !(err instanceof TRPCClientError) ||
            err.data?.code !== 'UNAUTHORIZED'
          ) {
            vscode.postMessage({
              type: 'showError',
              message: err instanceof Error ? err.message : String(err),
            });
          }
          observer.error(err);
        },
        complete() {
          observer.complete();
        },
      });
      return unsubscribe;
    });
  };
};

function isTokenExpiringSoon(token: string, bufferMinutes = 1) {
  try {
    const base64Url = token.split('.')[1];
    const base64 = base64Url.replace(/-/g, '+').replace(/_/g, '/');
    const pad = base64.length % 4;
    const padded = pad ? base64 + '='.repeat(4 - pad) : base64;
    const payload = JSON.parse(atob(padded));

    const exp = payload.exp; // seconds
    const now = Math.floor(Date.now() / 1000);

    const buffer = bufferMinutes * 60;

    return exp - now <= buffer;
  } catch {
    return true;
  }
}

let cachedClient: ReturnType<typeof createTRPCProxyClient<AppRouter>> | null =
  null;
let cachedServerUrl: string | null = null;
let cachedAuthClient: ReturnType<
  typeof createTRPCProxyClient<AppRouter>
> | null = null;

let renewAccessTokenPromise: Promise<{
  accessToken: string;
  isNew: boolean;
}> | null = null;
async function ensureValidAccessToken(
  accessToken: string,
  refreshToken: string,
) {
  if (isTokenExpiringSoon(accessToken)) {
    if (!renewAccessTokenPromise) {
      renewAccessTokenPromise = (async () => {
        try {
          const { accessToken: newSecret } =
            await cachedAuthClient!.refreshAuthToken.mutate({ refreshToken });
          return { accessToken: newSecret, isNew: true };
        } catch (e) {
          vscode.postMessage({ type: 'logout' });
          vscode.postMessage({
            type: 'showError',
            message: 'Session expired. Please login again.',
          });
          throw e;
        } finally {
          renewAccessTokenPromise = null;
        }
      })();
    }
    return renewAccessTokenPromise;
  }
  return { accessToken, isNew: false };
}

export function getAppTrpcClient(serverUrl: string) {
  if (cachedClient && cachedServerUrl === serverUrl) {
    return cachedClient;
  }

  cachedAuthClient = createTRPCProxyClient<AppRouter>({
    transformer: superjson,
    links: [
      httpBatchLink({
        url: `${serverUrl}/trpc`,
      }),
    ],
  });

  cachedClient = createTRPCProxyClient<AppRouter>({
    transformer: superjson,
    links: [
      errorLink,
      // refreshLink,
      httpBatchLink({
        url: `${serverUrl}/trpc`,
        headers: async () => {
          const agentStore = useAgentStore();
          const { accessToken: accessTokenOld, refreshToken } = agentStore;

          if (!accessTokenOld || !refreshToken) {
            return {};
          }

          const { accessToken: newAccessToken, isNew } =
            await ensureValidAccessToken(accessTokenOld, refreshToken);
          if (isNew) {
            // updating token in vscode secrets
            vscode.postMessage({
              type: 'updateTokens',
              accessToken: newAccessToken,
            });

            const { serviceIds, userEmail } = agentStore;

            // updating config in agent store
            agentStore.setConfig({
              serverUrl,
              serviceIds,
              isAuthenticated: true,
              accessToken: newAccessToken,
              refreshToken,
              userEmail,
            });
          }
          return {
            authorization: `Bearer ${newAccessToken}`,
          };
        },
      }),
    ],
  });

  cachedServerUrl = serverUrl;

  return cachedClient;
}
