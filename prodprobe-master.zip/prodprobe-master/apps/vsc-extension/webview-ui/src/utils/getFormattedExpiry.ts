function formattedExpiry(createdAt: string, expiryTime?: bigint) {
  if (!expiryTime) return 'Unknown';
  const expiry = Number(expiryTime);
  const created = createdAt ? new Date(createdAt).getTime() : Date.now();
  const diffMs = expiry - created;
  if (diffMs <= 0) return 'Expired';

  const totalMinutes = Math.max(1, Math.ceil(diffMs / (60 * 1000)));
  if (totalMinutes < 60) {
    return `${totalMinutes} minute${totalMinutes > 1 ? 's' : ''}`;
  }

  const hours = Math.floor(totalMinutes / 60);
  const minutes = totalMinutes % 60;
  if (minutes === 0) {
    return `${hours} hour${hours > 1 ? 's' : ''}`;
  }
  return `${hours} hour${hours > 1 ? 's' : ''} ${minutes} minute${minutes > 1 ? 's' : ''}`;
}

export default formattedExpiry;
