export type Config = {
  serverUrl: string;
  serviceIds: string[];
  isAuthenticated: boolean;
  accessToken: string;
  refreshToken: string;
  userEmail: string;
  localCommitSha?: string;
};
