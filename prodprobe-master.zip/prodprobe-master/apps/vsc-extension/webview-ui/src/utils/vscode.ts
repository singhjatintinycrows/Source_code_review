declare const acquireVsCodeApi: any;

class VSCodeAPIWrapper {
  private readonly vsCodeApi: any | undefined;

  constructor() {
    if (typeof acquireVsCodeApi === 'function') {
      this.vsCodeApi = acquireVsCodeApi();
    }
  }

  public postMessage(message: unknown) {
    if (this.vsCodeApi) {
      this.vsCodeApi.postMessage(message);
    } else {
      console.log('Mock message to VS Code:', message);
    }
  }

  public get isAvailable(): boolean {
    return !!this.vsCodeApi;
  }
}

export const vscode = new VSCodeAPIWrapper();
