import { defineStore } from 'pinia';
import { getAppTrpcClient } from '../utils/trpc';
import { vscode } from '../utils/vscode';
import { useAgentStore } from './agentStore';

export const useActionStore = defineStore('action', {
  state: () => ({
    actions: [] as any[],
    isLoading: false,
    pollingIntervalId: null as number | null,
  }),
  actions: {
    async fetchActions() {
      const agentStore = useAgentStore();
      if (agentStore.serviceIds.length === 0) {
        this.actions = [];
        vscode.postMessage({ type: 'updateProbes', probes: [] });
        return;
      }

      this.isLoading = true;
      try {
        const client = getAppTrpcClient(agentStore.serverUrl);
        const probes = await client.listProbes.query({
          serviceIds: agentStore.serviceIds,
          limit: 200,
        });

        this.actions = probes;

        // Cleanly map only the primitive fields required by the Extension Host to avoid BigInt serialization crashes
        const cleanProbes = this.actions.map((p: any) => ({
          id: p.id,
          uiFilePath: p.uiFilePath,
          uiLineNumber: p.uiLineNumber,
          commitSha: p.commitSha,
          status: p.status,
          type: p.type,
        }));

        vscode.postMessage({
          type: 'updateProbes',
          probes: cleanProbes,
        });
      } catch (err) {
        console.error('Failed to fetch actions (probes):', err);
      } finally {
        this.isLoading = false;
      }
    },
    async insertAction(payload: any) {
      try {
        const agentStore = useAgentStore();
        const client = getAppTrpcClient(agentStore.serverUrl);

        // Build the correct payload based on type
        // Base fields
        const createPayload: any = {
          serviceId: payload.serviceId,
          environment: payload.environment,
          commitSha: payload.commitSha,
          type: payload.type,
          uiFilePath: payload.uiFilePath,
          uiLineNumber: payload.uiLineNumber,
          hitLimit: payload.hitLimit || 1,
          expiryTime: payload.expiryTime || Date.now() + 60 * 60 * 1000, // default 1 hour
          condition: payload.condition,
          shouldCaptureTraceId: payload.shouldCaptureTraceId,
        };

        if (payload.type === 'SNAPSHOT') {
          createPayload.watchExpressions = payload.watchExpressions || [];
          createPayload.captureClosures = payload.captureClosures ?? false;
        } else if (payload.type === 'LOG') {
          createPayload.template = payload.template || 'Default log template';
          createPayload.logLevel = payload.logLevel || 'INFO';
          createPayload.shouldLogToStdout = payload.shouldLogToStdout || false;
        } else if (payload.type === 'COUNTER') {
          createPayload.metricName = payload.metricName || 'counter_metric';
        } else if (payload.type === 'METRIC') {
          createPayload.metricName = payload.metricName || 'custom_metric';
          createPayload.metricExpression = payload.metricExpression || '1';
        } else if (payload.type === 'DURATION') {
          createPayload.metricName = payload.metricName || 'duration_metric';
          createPayload.secondaryUiFilePath = payload.secondaryUiFilePath;
          createPayload.secondaryUiLineNumber = payload.secondaryUiLineNumber;
        }

        await client.createProbe.mutate(createPayload);

        // Optimistically fetch
        this.fetchActions();
      } catch (err) {
        console.error('Failed to insert action:', err);
        throw err;
      }
    },
    async deleteActions(ids: string[]) {
      if (ids.length === 0) return;

      try {
        const agentStore = useAgentStore();
        const client = getAppTrpcClient(agentStore.serverUrl);
        await client.deleteProbes.mutate({ ids });

        // Optimistically remove from state
        this.actions = this.actions.filter(
          (action) => !ids.includes(action.id),
        );

        // Background sync to ensure accuracy
        this.fetchActions();
      } catch (err) {
        console.error('Failed to delete actions:', err);
        throw err;
      }
    },
    async toggleProbeStatus(id: string, currentStatus: string) {
      try {
        const agentStore = useAgentStore();
        const client = getAppTrpcClient(agentStore.serverUrl);
        const newStatus = currentStatus === 'ACTIVE' ? 'INACTIVE' : 'ACTIVE';
        await client.toggleProbeStatus.mutate({ id, status: newStatus });

        // Optimistically update
        const action = this.actions.find((a) => a.id === id);
        if (action) {
          action.status = newStatus;
          if (newStatus === 'INACTIVE') {
            action.isLive = false; // Cannot be live if inactive
          }
        }
      } catch (err) {
        console.error('Failed to toggle probe status:', err);
        throw err;
      }
    },
    startPolling(intervalMs = 10000) {
      if (this.pollingIntervalId !== null) return;
      this.fetchActions();
      this.pollingIntervalId = window.setInterval(() => {
        this.fetchActions();
      }, intervalMs);
    },
    stopPolling() {
      if (this.pollingIntervalId !== null) {
        window.clearInterval(this.pollingIntervalId);
        this.pollingIntervalId = null;
      }
    },
  },
});
