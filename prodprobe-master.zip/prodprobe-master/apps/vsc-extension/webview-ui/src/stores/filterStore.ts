import { defineStore } from 'pinia';
import {
  getCreatedByMeFilter,
  setCreatedByMeFilter,
} from '../utils/localStorageHelper';

export interface FilterTag {
  type: string; // 'environment', 'serviceId', 'commitSha', 'file', 'line', etc.
  value: string;
}

export const useFilterStore = defineStore('filter', {
  state: () => ({
    searchQuery: '',
    createdByMe: getCreatedByMeFilter() ?? false,
    activeTags: [] as FilterTag[],
  }),
  getters: {
    // Utility to easily check if a specific tag type is active
    hasTagType: (state) => (type: string) => {
      return state.activeTags.some((t) => t.type === type);
    },
    // Utility to get all values for a specific tag type
    getTagValues: (state) => (type: string) => {
      return state.activeTags
        .filter((t) => t.type === type)
        .map((t) => t.value);
    },
  },
  actions: {
    setSearchQuery(query: string) {
      this.searchQuery = query;
    },
    setCreatedByMe(createdByMe: boolean) {
      this.createdByMe = createdByMe;
      setCreatedByMeFilter(createdByMe);
    },
    addTag(type: string, value: string) {
      // Prevent duplicates
      if (!this.activeTags.some((t) => t.type === type && t.value === value)) {
        this.activeTags.push({ type, value });
      }
      this.searchQuery = ''; // Clear search when a tag is selected
    },
    removeTag(type: string, value: string) {
      this.activeTags = this.activeTags.filter(
        (t) => !(t.type === type && t.value === value),
      );
    },
    clearAllTags() {
      this.activeTags = [];
      this.searchQuery = '';
    },
  },
});
