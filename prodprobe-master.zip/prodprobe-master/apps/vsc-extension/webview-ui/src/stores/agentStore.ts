import { defineStore } from 'pinia';
import { getAppTrpcClient } from '../utils/trpc';
import type { Config } from '../utils/types';

export interface ActiveAgent {
  agentId: string;
  serviceId: string;
  environment: string;
  commitSha: string;
}

export const useAgentStore = defineStore('agent', {
  state: () => ({
    agents: [] as ActiveAgent[],
    isLoading: false,
    serverUrl: 'http://localhost:3001',
    serviceIds: [] as string[],
    serviceNames: {} as Record<string, string>,
    pollingIntervalId: null as number | null,
    isAuthenticated: false,
    userEmail: '',
    accessToken: '',
    refreshToken: '',
    localCommitSha: '',
  }),
  getters: {
    agentsDeepGrouped: (state) => {
      // Structure: Record<serviceId, Record<environment, Record<commitSha, ActiveAgent[]>>>
      const grouped: Record<
        string,
        Record<string, Record<string, ActiveAgent[]>>
      > = {};

      for (const agent of state.agents) {
        if (!grouped[agent.serviceId]) {
          grouped[agent.serviceId] = {};
        }
        if (!grouped[agent.serviceId][agent.environment]) {
          grouped[agent.serviceId][agent.environment] = {};
        }
        if (!grouped[agent.serviceId][agent.environment][agent.commitSha]) {
          grouped[agent.serviceId][agent.environment][agent.commitSha] = [];
        }
        grouped[agent.serviceId][agent.environment][agent.commitSha].push(
          agent,
        );
      }
      return grouped;
    },
  },
  actions: {
    setConfig({
      serverUrl,
      serviceIds,
      isAuthenticated,
      accessToken,
      refreshToken,
      userEmail,
      localCommitSha,
    }: Config) {
      const idsChanged =
        JSON.stringify(this.serviceIds) !== JSON.stringify(serviceIds);
      this.serverUrl = serverUrl;
      this.serviceIds = serviceIds;
      this.isAuthenticated = isAuthenticated;
      this.userEmail = userEmail;
      this.accessToken = accessToken;
      this.refreshToken = refreshToken;

      if (localCommitSha !== undefined) {
        this.localCommitSha = localCommitSha;
      }

      if (this.isAuthenticated && idsChanged && serviceIds.length > 0) {
        this.fetchServiceNames();
      }

      if (this.pollingIntervalId && this.isAuthenticated) {
        this.fetchAgents(); // immediately fetch with new config
      }
    },
    async fetchServiceNames() {
      if (this.serviceIds.length === 0) return;
      try {
        const client = getAppTrpcClient(this.serverUrl);
        const names = await client.getServiceNames.query({
          serviceIds: this.serviceIds,
        });
        this.serviceNames = { ...this.serviceNames, ...names };
      } catch (err) {
        console.error('Failed to fetch service names:', err);
      }
    },
    async fetchAgents() {
      if (this.serviceIds.length === 0) {
        this.agents = [];
        return;
      }

      this.isLoading = true;
      try {
        const client = getAppTrpcClient(this.serverUrl);
        const activeAgents = await client.listActiveAgents.query({
          serviceIds: this.serviceIds,
        });
        this.agents = activeAgents;
      } catch (err) {
        console.error('Failed to fetch active agents:', err);
      } finally {
        this.isLoading = false;
      }
    },
    startPolling(intervalMs = 10000) {
      if (this.pollingIntervalId !== null) return;
      this.fetchAgents();
      this.pollingIntervalId = window.setInterval(() => {
        this.fetchAgents();
      }, intervalMs);
    },
    stopPolling() {
      if (this.pollingIntervalId !== null) {
        window.clearInterval(this.pollingIntervalId);
        this.pollingIntervalId = null;
      }
    },
    refreshAll() {
      this.fetchServiceNames();
      this.fetchAgents();
    },
  },
});
