import {
  getLicensingServerUrl,
  HYPERPROBE_LICENSING_PUBLIC_KEY_URL,
} from '@hyperprobe/constants';
import { defineStore } from 'pinia';
import { getAppTrpcClient } from '../utils/trpc';
import { useAgentStore } from './agentStore';

export const useLicenseStore = defineStore('license', {
  state: () => ({
    status: null as string | null,
    hintStatus: null as string | null,
    maxAgents: 0,
    licenseId: null as string | null,
    isProvisioned: false,
    upgradeRequired: false,
    isCourierRunning: false,
    pollingIntervalId: null as any,
    cachedPublicKey: null as string | null,
  }),
  actions: {
    async fetchStatus() {
      const agentStore = useAgentStore();
      if (!agentStore.isAuthenticated) return;
      try {
        const client = getAppTrpcClient(agentStore.serverUrl);
        const res = await client.license.status.query();
        this.status = res.status;
        this.hintStatus = res.hintStatus;
        this.maxAgents = res.maxAgents;
        this.licenseId = res.licenseId;
        this.isProvisioned = res.isProvisioned;
        this.upgradeRequired = res.upgradeRequired;

        if (this.hintStatus === 'COURIER_REQUIRED' && !this.isCourierRunning) {
          this.runCourierRelay();
        }
      } catch (err) {
        console.error('Failed to fetch license status', err);
      }
    },
    async runCourierRelay() {
      const agentStore = useAgentStore();
      if (!agentStore.isAuthenticated) return;
      const client = getAppTrpcClient(agentStore.serverUrl);

      const lockRes = await client.license.acquireCourierLock.mutate();
      if (!lockRes.success) return;

      this.isCourierRunning = true;
      try {
        const challenge = await client.license.getDeploymentConfig.query();
        const { jwt, licenseId, nextToken, syncStatusIndex } = challenge;
        if (jwt && licenseId) {
          const syncPrecondition =
            syncStatusIndex === undefined ? {} : { syncStatusIndex };
          const licensingServerUrl = await getLicensingServerUrl();

          const submitRelayOnDemand = async (
            jwtVal: string,
            tokenVal: string,
          ) => {
            try {
              // Attempt 1: Fast Sync (No outbound Firebase query!)
              await client.license.submitRelay.mutate({
                jwt: jwtVal,
                nextToken: tokenVal,
                ...(nextToken
                  ? { preparedFrom: jwt, ...syncPrecondition }
                  : {}),
                publicKey: this.cachedPublicKey || undefined,
              });
            } catch (err) {
              const errorMsg =
                err instanceof Error ? err.message : String(err || '');
              if (
                errorMsg.includes('No public key available for verification') ||
                errorMsg.includes('Invalid, forged, or expired license token')
              ) {
                // Key rotation detected! Fetch fresh public key on-demand
                let fetchedKey: string | undefined;
                const controller = new AbortController();
                const id = setTimeout(() => controller.abort(), 5000);
                try {
                  const pubKeyRes = await fetch(
                    HYPERPROBE_LICENSING_PUBLIC_KEY_URL,
                    { signal: controller.signal },
                  );
                  if (pubKeyRes.ok) {
                    const parsed = await pubKeyRes.json();
                    if (parsed && typeof parsed === 'string') {
                      fetchedKey = parsed;
                      this.cachedPublicKey = parsed;
                    }
                  }
                } catch (fetchErr) {
                  console.error(
                    'Failed to fetch public key on-demand:',
                    fetchErr,
                  );
                } finally {
                  clearTimeout(id);
                }

                if (fetchedKey) {
                  // Retry submitting with the rotated public key
                  await client.license.submitRelay.mutate({
                    jwt: jwtVal,
                    nextToken: tokenVal,
                    ...(nextToken
                      ? { preparedFrom: jwt, ...syncPrecondition }
                      : {}),
                    publicKey: fetchedKey,
                  });
                } else {
                  throw err;
                }
              } else {
                throw err;
              }
            }
          };

          if (!nextToken) {
            const controller0 = new AbortController();
            const id0 = setTimeout(() => controller0.abort(), 10000);
            try {
              const response = await fetch(
                `${licensingServerUrl}/api/heartbeat`,
                {
                  method: 'POST',
                  headers: { 'Content-Type': 'application/json' },
                  body: JSON.stringify({
                    licenseId,
                    jwt,
                    nextToken: null,
                  }),
                  signal: controller0.signal,
                },
              );
              if (response.status === 403 || response.status === 401) {
                await client.license.reportRevocation.mutate();
                await this.fetchStatus();
                return;
              }
              if (response.ok) {
                const data = await response.json();
                await submitRelayOnDemand(data.jwt, data.nextToken);
                await this.fetchStatus();
              }
            } finally {
              clearTimeout(id0);
            }
          } else {
            const controller1 = new AbortController();
            const id1 = setTimeout(() => controller1.abort(), 10000);
            let res1: Response;
            try {
              res1 = await fetch(`${licensingServerUrl}/api/heartbeat`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                  phase: 1,
                  licenseId,
                  jwt,
                  nextToken,
                }),
                signal: controller1.signal,
              });
            } finally {
              clearTimeout(id1);
            }
            if (res1.status === 403 || res1.status === 401) {
              await client.license.reportRevocation.mutate();
              await this.fetchStatus();
              return;
            }
            if (res1.ok) {
              const data1 = await res1.json();
              await client.license.prepareRelay.mutate({
                jwt,
                previousNextToken: nextToken,
                nextToken: data1.nextToken,
                ...syncPrecondition,
              });
              const controller2 = new AbortController();
              const id2 = setTimeout(() => controller2.abort(), 10000);
              let res2: Response;
              try {
                res2 = await fetch(`${licensingServerUrl}/api/heartbeat`, {
                  method: 'POST',
                  headers: { 'Content-Type': 'application/json' },
                  body: JSON.stringify({
                    phase: 2,
                    licenseId,
                    jwt,
                    nextToken: data1.nextToken,
                  }),
                  signal: controller2.signal,
                });
              } finally {
                clearTimeout(id2);
              }
              if (res2.status === 403 || res2.status === 401) {
                await client.license.reportRevocation.mutate();
                await this.fetchStatus();
                return;
              }
              if (res2.ok) {
                const data2 = await res2.json();
                await submitRelayOnDemand(data2.jwt, data1.nextToken);
                await this.fetchStatus();
              }
            }
          }
        } else {
          throw new Error(
            'Deployment configuration is incomplete. Retry loading status.',
          );
        }
      } catch (e) {
        console.error('Courier relay failed', e);
      } finally {
        try {
          const agentStore = useAgentStore();
          const client = getAppTrpcClient(agentStore.serverUrl);
          await client.license.releaseCourierLock.mutate();
        } catch (e) {
          console.error('Failed to release courier lock', e);
        }
        this.isCourierRunning = false;
      }
    },
    startPolling() {
      if (!this.pollingIntervalId) {
        this.fetchStatus();
        this.pollingIntervalId = setInterval(
          () => this.fetchStatus(),
          import.meta.env.PROD ? 1000 * 60 * 120 : 1000 * 60,
        );
      }
    },
    stopPolling() {
      if (this.pollingIntervalId) {
        clearInterval(this.pollingIntervalId);
        this.pollingIntervalId = null;
      }
    },
  },
});
