import vue from '@vitejs/plugin-vue';
import { defineConfig } from 'vite';
import pkg from '../../../package.json';

// https://vitejs.dev/config/
export default defineConfig({
  define: {
    'import.meta.env.VITE_EXTENSION_VERSION': JSON.stringify(pkg.version),
    'import.meta.env.PROD': JSON.stringify(
      !!process.env.VITE_EXTENSION_VERSION,
    ),
  },
  server: {
    port: 5173,
    strictPort: true,
    cors: true,
    hmr: {
      protocol: 'ws',
      host: 'localhost',
    },
  },
  plugins: [
    vue({
      template: {
        compilerOptions: {
          // treat all tags with a dash that start with 'vscode-' as custom elements
          isCustomElement: (tag) => tag.startsWith('vscode-'),
        },
      },
    }),
  ],
  build: {
    outDir: 'dist',
    emptyOutDir: true,
    assetsInlineLimit: 200000,
    rollupOptions: {
      output: {
        entryFileNames: 'assets/index.js',
        chunkFileNames: 'assets/[name].js',
        assetFileNames: 'assets/[name].[ext]',
      },
    },
  },
});
