import { TRPCClientError } from '@trpc/client';
import { createPinia } from 'pinia';
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import { useLicenseStore } from '../src/stores/licenseStore';

const { client, licensingUrl } = vi.hoisted(() => ({
  licensingUrl: 'https://licensing.example.test',
  client: {
    license: {
      status: { query: vi.fn() },
      getDeploymentConfig: { query: vi.fn() },
      acquireCourierLock: { mutate: vi.fn() },
      releaseCourierLock: { mutate: vi.fn() },
      prepareRelay: { mutate: vi.fn() },
      submitRelay: { mutate: vi.fn() },
      reportRevocation: { mutate: vi.fn() },
    },
  },
}));

vi.mock('../src/utils/trpc', () => ({
  getAppTrpcClient: () => client,
}));
vi.mock('../src/stores/agentStore', () => ({
  useAgentStore: () => ({
    isAuthenticated: true,
    serverUrl: 'https://deployment.example.test',
  }),
}));
vi.mock('@hyperprobe/constants', () => ({
  getLicensingServerUrl: async () => licensingUrl,
  HYPERPROBE_LICENSING_PUBLIC_KEY_URL: `${licensingUrl}/public-key`,
}));

const cachedStatus = {
  status: 'SYNCED',
  hintStatus: 'SYNCED',
  licenseId: 'license-a',
  maxAgents: 5,
  isProvisioned: true,
  upgradeRequired: false,
};
const fetchMock = vi.fn();
const publicKeyUrl = `${licensingUrl}/public-key`;
let store: ReturnType<typeof useLicenseStore>;

beforeEach(() => {
  vi.resetAllMocks();
  vi.useFakeTimers();
  client.license.status.query.mockResolvedValue(cachedStatus);
  client.license.acquireCourierLock.mutate.mockResolvedValue({ success: true });
  client.license.releaseCourierLock.mutate.mockResolvedValue({ success: true });
  client.license.prepareRelay.mutate.mockResolvedValue({ success: true });
  client.license.submitRelay.mutate.mockResolvedValue({ success: true });
  fetchMock.mockRejectedValue(new Error('Unexpected external request'));
  vi.stubGlobal('fetch', fetchMock);
  vi.spyOn(console, 'error').mockImplementation(() => undefined);
  store = useLicenseStore(createPinia());
  store.$patch(cachedStatus);
});

afterEach(() => {
  store.$dispose();
  vi.clearAllTimers();
  vi.useRealTimers();
  vi.unstubAllGlobals();
  vi.restoreAllMocks();
});

describe('VSCode courier deployment configuration', () => {
  it.each(
    [undefined, 0, 41].flatMap((syncStatusIndex) =>
      [false, true].map((publicKeyRetry) => ({
        syncStatusIndex,
        publicKeyRetry,
      })),
    ),
  )('completes both phases with config B rather than cached license A (index: $syncStatusIndex, key retry: $publicKeyRetry)', async ({
    syncStatusIndex,
    publicKeyRetry,
  }) => {
    const precondition =
      syncStatusIndex === undefined ? {} : { syncStatusIndex };
    const config = Object.freeze({
      licenseId: 'license-b',
      jwt: 'durable-jwt-b',
      nextToken: 'durable-token-b',
      ...precondition,
    });
    client.license.getDeploymentConfig.query.mockResolvedValue(config);
    client.license.status.query.mockResolvedValue({
      ...cachedStatus,
      licenseId: config.licenseId,
    });
    if (publicKeyRetry) {
      client.license.submitRelay.mutate.mockRejectedValueOnce(
        new Error('No public key available for verification'),
      );
    }
    fetchMock.mockImplementation(async (url, init) => {
      if (url === publicKeyUrl) return Response.json('rotated-public-key');
      expect(url).toBe(`${licensingUrl}/api/heartbeat`);
      const body = JSON.parse(init.body);
      if (body.licenseId !== config.licenseId || body.jwt !== config.jwt) {
        return Response.json({ error: 'LicenseMismatch' }, { status: 403 });
      }
      if (body.phase === 1)
        return Response.json({ nextToken: 'prepared-token-b' });
      if (body.phase === 2) return Response.json({ jwt: 'renewed-jwt-b' });
      throw new Error('Unexpected heartbeat phase');
    });

    expect(store.licenseId).toBe(cachedStatus.licenseId);
    await store.runCourierRelay();

    expect(fetchMock).toHaveBeenCalledTimes(publicKeyRetry ? 3 : 2);
    expect(
      fetchMock.mock.calls
        .filter(([url]) => url !== publicKeyUrl)
        .map(([, init]) => JSON.parse(init.body)),
    ).toStrictEqual([
      {
        phase: 1,
        licenseId: config.licenseId,
        jwt: config.jwt,
        nextToken: config.nextToken,
      },
      {
        phase: 2,
        licenseId: config.licenseId,
        jwt: config.jwt,
        nextToken: 'prepared-token-b',
      },
    ]);
    expect(client.license.prepareRelay.mutate.mock.calls).toStrictEqual([
      [
        {
          jwt: config.jwt,
          previousNextToken: config.nextToken,
          nextToken: 'prepared-token-b',
          ...precondition,
        },
      ],
    ]);
    expect(client.license.submitRelay.mutate.mock.calls).toStrictEqual(
      (publicKeyRetry ? [undefined, 'rotated-public-key'] : [undefined]).map(
        (publicKey) => [
          {
            jwt: 'renewed-jwt-b',
            nextToken: 'prepared-token-b',
            preparedFrom: config.jwt,
            publicKey,
            ...precondition,
          },
        ],
      ),
    );
    expect(client.license.acquireCourierLock.mutate).toHaveBeenCalledTimes(1);
    expect(client.license.getDeploymentConfig.query).toHaveBeenCalledTimes(1);
    expect(client.license.releaseCourierLock.mutate).toHaveBeenCalledTimes(1);
    expect(client.license.reportRevocation.mutate).not.toHaveBeenCalled();
    expect(client.license.status.query).toHaveBeenCalledTimes(1);
    expect(store.licenseId).toBe(config.licenseId);
    expect(store.isCourierRunning).toBe(false);
    expect(vi.getTimerCount()).toBe(0);
  });

  it.each([
    'Phase 1',
    'Phase 2',
    'public-key retry',
  ] as const)('keeps the captured tuple on a late %s conflict without clearing newer REVOKED status', async (wait) => {
    let resume!: (response: Response) => void;
    const pending = new Promise<Response>((resolve) => {
      resume = resolve;
    });
    const config = {
      licenseId: cachedStatus.licenseId,
      jwt: 'captured-jwt',
      nextToken: 'captured-token',
      syncStatusIndex: 41,
    };
    const captured = { ...config };
    const revoked = {
      ...cachedStatus,
      licenseId: 'newer-revoked-license',
      status: 'REVOKED',
      hintStatus: 'REVOKED',
      maxAgents: 99,
    };
    const conflict = Object.assign(
      new TRPCClientError(
        'License state changed; reload the deployment configuration before retrying',
      ),
      { data: { code: 'CONFLICT', httpStatus: 409 } },
    );
    const response = () =>
      Response.json(
        wait === 'Phase 1'
          ? { nextToken: 'prepared-token' }
          : wait === 'Phase 2'
            ? { jwt: 'renewed-jwt' }
            : 'rotated-public-key',
      );
    client.license.getDeploymentConfig.query.mockResolvedValue(config);
    if (wait === 'public-key retry') {
      client.license.submitRelay.mutate.mockRejectedValueOnce(
        new Error('No public key available for verification'),
      );
    }
    fetchMock.mockImplementation(async (url, init) => {
      if (url === publicKeyUrl) return pending;
      expect(url).toBe(`${licensingUrl}/api/heartbeat`);
      const { phase } = JSON.parse(init.body);
      if (wait === `Phase ${phase}`) return pending;
      return Response.json(
        phase === 1 ? { nextToken: 'prepared-token' } : { jwt: 'renewed-jwt' },
      );
    });

    const action = store.runCourierRelay();
    try {
      await vi.advanceTimersByTimeAsync(0);
      const requests = wait === 'Phase 1' ? 1 : wait === 'Phase 2' ? 2 : 3;
      expect(fetchMock).toHaveBeenCalledTimes(requests);
      expect(store.isCourierRunning).toBe(true);

      // Change the cached config object too, not just the next query result.
      Object.assign(config, {
        licenseId: revoked.licenseId,
        jwt: 'newer-jwt',
        nextToken: 'newer-token',
        syncStatusIndex: captured.syncStatusIndex + 1,
      });
      client.license.status.query.mockResolvedValue(revoked);
      await store.fetchStatus();
      expect(store.$state).toMatchObject(revoked);
      const rejectedMutation =
        wait === 'Phase 1'
          ? client.license.prepareRelay.mutate
          : client.license.submitRelay.mutate;
      rejectedMutation.mockRejectedValueOnce(conflict);
      resume(response());
      await action;

      expect(fetchMock).toHaveBeenCalledTimes(requests);
      expect(
        fetchMock.mock.calls
          .filter(([url]) => url !== publicKeyUrl)
          .map(([, init]) => JSON.parse(init.body)),
      ).toStrictEqual([
        {
          phase: 1,
          licenseId: captured.licenseId,
          jwt: captured.jwt,
          nextToken: captured.nextToken,
        },
        ...(wait === 'Phase 1'
          ? []
          : [
              {
                phase: 2,
                licenseId: captured.licenseId,
                jwt: captured.jwt,
                nextToken: 'prepared-token',
              },
            ]),
      ]);
      expect(client.license.prepareRelay.mutate.mock.calls).toStrictEqual([
        [
          {
            jwt: captured.jwt,
            previousNextToken: captured.nextToken,
            nextToken: 'prepared-token',
            syncStatusIndex: captured.syncStatusIndex,
          },
        ],
      ]);
      expect(client.license.submitRelay.mutate.mock.calls).toStrictEqual(
        (wait === 'Phase 1'
          ? []
          : wait === 'Phase 2'
            ? [undefined]
            : [undefined, 'rotated-public-key']
        ).map((publicKey) => [
          {
            jwt: 'renewed-jwt',
            nextToken: 'prepared-token',
            preparedFrom: captured.jwt,
            syncStatusIndex: captured.syncStatusIndex,
            publicKey,
          },
        ]),
      );
      expect(console.error).toHaveBeenCalledWith(
        'Courier relay failed',
        conflict,
      );
      expect(client.license.getDeploymentConfig.query).toHaveBeenCalledTimes(1);
      expect(client.license.acquireCourierLock.mutate).toHaveBeenCalledTimes(1);
      expect(client.license.releaseCourierLock.mutate).toHaveBeenCalledTimes(1);
      expect(client.license.reportRevocation.mutate).not.toHaveBeenCalled();
      expect(client.license.status.query).toHaveBeenCalledTimes(1);
      expect(store.$state).toMatchObject(revoked);
      expect(store.isCourierRunning).toBe(false);
      expect(vi.getTimerCount()).toBe(0);
    } finally {
      resume(response());
      await action;
    }
  });

  it.each([
    undefined,
    0,
    41,
  ])('omits backend-only index %s from Phase 0 and legacy submissions, including key retry', async (syncStatusIndex) => {
    const config = Object.freeze({
      licenseId: 'license-b',
      jwt: 'initial-jwt-b',
      nextToken: null,
      ...(syncStatusIndex === undefined ? {} : { syncStatusIndex }),
    });
    const relay = {
      jwt: 'initialized-jwt-b',
      nextToken: 'initialized-token-b',
    };
    client.license.getDeploymentConfig.query.mockResolvedValue(config);
    client.license.submitRelay.mutate.mockRejectedValueOnce(
      new Error('No public key available for verification'),
    );
    fetchMock.mockImplementation(async (url) =>
      Response.json(url === publicKeyUrl ? 'rotated-public-key' : relay),
    );

    await store.runCourierRelay();

    expect(fetchMock).toHaveBeenCalledTimes(2);
    expect(fetchMock.mock.calls.map(([url]) => url)).toEqual([
      `${licensingUrl}/api/heartbeat`,
      publicKeyUrl,
    ]);
    expect(JSON.parse(fetchMock.mock.calls[0]![1].body)).toStrictEqual({
      licenseId: config.licenseId,
      jwt: config.jwt,
      nextToken: null,
    });
    expect(client.license.submitRelay.mutate.mock.calls).toStrictEqual(
      [undefined, 'rotated-public-key'].map((publicKey) => [
        { ...relay, publicKey },
      ]),
    );
    expect(client.license.prepareRelay.mutate).not.toHaveBeenCalled();
    expect(client.license.reportRevocation.mutate).not.toHaveBeenCalled();
    expect(client.license.getDeploymentConfig.query).toHaveBeenCalledTimes(1);
    expect(client.license.acquireCourierLock.mutate).toHaveBeenCalledTimes(1);
    expect(client.license.releaseCourierLock.mutate).toHaveBeenCalledTimes(1);
    expect(client.license.status.query).toHaveBeenCalledTimes(1);
    expect(store.isCourierRunning).toBe(false);
    expect(vi.getTimerCount()).toBe(0);
    for (const [, init] of fetchMock.mock.calls) {
      expect(init.signal.aborted).toBe(false);
    }
  });

  it('keeps automatic REVOKED polls status-only, including the initial poll', async () => {
    const revoked = {
      ...cachedStatus,
      status: 'REVOKED',
      hintStatus: 'REVOKED',
    };
    client.license.status.query.mockResolvedValue(revoked);

    store.startPolling();
    await vi.advanceTimersByTimeAsync(0);
    expect(client.license.status.query).toHaveBeenCalledTimes(1);
    expect(store.$state).toMatchObject(revoked);
    await vi.advanceTimersByTimeAsync(120_000);
    expect(client.license.status.query).toHaveBeenCalledTimes(3);
    expect(store.$state).toMatchObject(revoked);
    expect(store.isCourierRunning).toBe(false);
    for (const mock of [
      client.license.getDeploymentConfig.query,
      client.license.acquireCourierLock.mutate,
      client.license.prepareRelay.mutate,
      client.license.submitRelay.mutate,
      client.license.reportRevocation.mutate,
      client.license.releaseCourierLock.mutate,
      fetchMock,
    ]) {
      expect(mock).not.toHaveBeenCalled();
    }
    expect(vi.getTimerCount()).toBe(1);
    store.stopPolling();
    expect(store.pollingIntervalId).toBeNull();
    expect(vi.getTimerCount()).toBe(0);
  });

  it('rejects a missing config ID without falling back to cached A or blocking status reload', async () => {
    client.license.getDeploymentConfig.query.mockResolvedValue({
      jwt: 'durable-jwt-b',
      nextToken: 'durable-token-b',
    });

    await store.runCourierRelay();

    expect(console.error).toHaveBeenCalledWith(
      'Courier relay failed',
      new Error(
        'Deployment configuration is incomplete. Retry loading status.',
      ),
    );
    expect(store.isCourierRunning).toBe(false);
    expect(client.license.status.query).not.toHaveBeenCalled();
    await store.fetchStatus();
    expect(client.license.status.query).toHaveBeenCalledTimes(1);
    expect(store.licenseId).toBe(cachedStatus.licenseId);
    expect(client.license.acquireCourierLock.mutate).toHaveBeenCalledTimes(1);
    expect(client.license.getDeploymentConfig.query).toHaveBeenCalledTimes(1);
    expect(client.license.releaseCourierLock.mutate).toHaveBeenCalledTimes(1);
    expect(fetchMock).not.toHaveBeenCalled();
    expect(client.license.prepareRelay.mutate).not.toHaveBeenCalled();
    expect(client.license.submitRelay.mutate).not.toHaveBeenCalled();
    expect(client.license.reportRevocation.mutate).not.toHaveBeenCalled();
    expect(vi.getTimerCount()).toBe(0);
  });
});
