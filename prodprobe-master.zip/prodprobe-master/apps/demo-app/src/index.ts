import './hyperprobe.js';
import express from 'express';

const app = express();
app.use(express.json());

// A simulated complex endpoint to test snapshots
app.post('/checkout', (req, res) => {
  const { userId, items } = req.body;

  let cartTotal = 0;
  const userSession: any = {
    id: userId,
    isAuthenticated: true,
    flags: ['premium', 'beta-tester'],
    password: 'super-secret-password', // Should be redacted
  };
  userSession.circular = userSession; // Should be detected

  for (const item of items) {
    // Loop processing logic where we might want to set a probe
    const itemPrice = item.price * (item.quantity || 1);

    // Applying some discount
    const discount = itemPrice > 100 ? 0.1 : 0;
    cartTotal += itemPrice - itemPrice * discount;
  }

  // Final confirmation logic
  const response = {
    status: 'success',
    user: userSession,
    total: cartTotal,
    timestamp: new Date().toISOString(),
  };

  res.json(response);
});

// A simple high-throughput endpoint for benchmarking overhead
app.get('/health', (_req, res) => {
  res.json({ status: 'ok', uptime: process.uptime() });
});

const sleep = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms));

function calculateTotalSync(items: any[]) {
  let cartTotal = 0;
  for (const item of items) {
    const itemPrice = item.price * (item.quantity || 1);
    const discount = itemPrice > 100 ? 0.1 : 0;
    cartTotal += itemPrice - itemPrice * discount;
  }
  return cartTotal;
}

async function calculateTotalAsync(items: any[]) {
  let cartTotal = 0;
  for (const item of items) {
    const itemPrice = item.price * (item.quantity || 1);
    const discount = itemPrice > 100 ? 0.1 : 0;
    cartTotal += itemPrice - itemPrice * discount;
    await sleep(10);
  }
  return cartTotal;
}

app.post('/checkout-sync', (req, res) => {
  const { userId, items } = req.body;

  const userSession: any = {
    id: userId,
    isAuthenticated: true,
    flags: ['premium', 'beta-tester'],
    password: 'super-secret-password', // Should be redacted
  };
  userSession.circular = userSession; // Should be detected

  const cartTotal = calculateTotalSync(items || []);

  const response = {
    status: 'success',
    user: userSession,
    total: cartTotal,
    timestamp: new Date().toISOString(),
  };

  res.json(response);
});

app.post('/checkout-async', async (req, res) => {
  const { userId, items } = req.body;

  const userSession: any = {
    id: userId,
    isAuthenticated: true,
    flags: ['premium', 'beta-tester'],
    password: 'super-secret-password', // Should be redacted
  };
  userSession.circular = userSession; // Should be detected

  const cartTotal = await calculateTotalAsync(items || []);

  const response = {
    status: 'success',
    user: userSession,
    total: cartTotal,
    timestamp: new Date().toISOString(),
  };

  res.json(response);
});

// deeply nested sync/async code
function syncDeepest(items: any[]) {
  let total = 0;
  for (const item of items) {
    total += item.price; // PROBE HERE to see complex stack
  }
  return total;
}

async function asyncDeeper(items: any[]) {
  await sleep(2);
  return syncDeepest(items);
}

function syncMiddle(items: any[]) {
  // Returns a promise
  return asyncDeeper(items);
}

async function asyncOuter(items: any[]) {
  await sleep(5);
  const result = await syncMiddle(items);
  return result;
}

app.post('/async-sync-nesting', async (req, res) => {
  const { items } = req.body || { items: [] };
  const result = await asyncOuter(items);
  res.json({ status: 'nested-success', total: result });
});

const PORT = parseInt(process.env.PORT || '3000', 10);
app.listen(PORT, () => {
  console.log(`Demo app listening on port ${PORT}`);
});
