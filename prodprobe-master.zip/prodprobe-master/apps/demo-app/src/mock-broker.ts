import * as grpc from '@grpc/grpc-js';
import {
  AgentBrokerClient,
  type AgentBrokerServer,
  // type GetProbesRequest,
  // type GetProbesResponse,
  ProbeType,
  // type TelemetryBatch,
  // type TelemetryResponse,
} from '@hyperprobe/protos';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const envRuntimeLocation = process.env.RUNTIME_LOCATION;
const RUNTIME_LOCATION = envRuntimeLocation
  ? path.resolve(process.cwd(), envRuntimeLocation)
  : path.resolve(
      __dirname,
      __filename.endsWith('.ts') ? './index.ts' : './index.js',
    );

const DEFAULT_OVERRIDES = {
  maxObjectDepth: undefined,
  maxArrayLength: undefined,
  stackFrameDepth: undefined,
  maxObjectProperties: undefined,
  maxStringLength: undefined,
};

const HARDCODED_PROBES = [
  {
    id: 'probe-snapshot-123',
    type: ProbeType.PROBE_TYPE_SNAPSHOT,
    runtimeLocation: RUNTIME_LOCATION,
    runtimeLine: 28,
    hitLimit: 1000000,
    expiryTime: BigInt(Date.now() + 1000 * 60 * 60),
    watchExpressions: ['itemPrice', 'discount * 100'],
    secondaryRuntimeLocation: '',
    secondaryRuntimeLine: 0,
    condition: '',
    template: '',
    metricName: '',
    metricExpression: '',
    runtimeColumn: 0,
    secondaryRuntimeColumn: 0,
    correlationExpression: '',
    ...DEFAULT_OVERRIDES,
  },
  {
    id: 'probe-log-456',
    type: ProbeType.PROBE_TYPE_LOG,
    runtimeLocation: RUNTIME_LOCATION,
    runtimeLine: 25,
    hitLimit: 1000000,
    expiryTime: BigInt(Date.now() + 1000 * 60 * 60),
    // biome-ignore lint/suspicious/noTemplateCurlyInString: its a hardcoded template
    template: 'Processing item price: ${item.price}',
    secondaryRuntimeLocation: '',
    secondaryRuntimeLine: 0,
    condition: '',
    metricName: '',
    metricExpression: '',
    watchExpressions: [],
    runtimeColumn: 0,
    secondaryRuntimeColumn: 0,
    correlationExpression: '',
    ...DEFAULT_OVERRIDES,
  },
  {
    id: 'probe-metric-789',
    type: ProbeType.PROBE_TYPE_METRIC,
    runtimeLocation: RUNTIME_LOCATION,
    runtimeLine: 30,
    hitLimit: 1000000,
    expiryTime: BigInt(Date.now() + 1000 * 60 * 60),
    metricName: 'cart_total',
    metricExpression: 'cartTotal',
    secondaryRuntimeLocation: '',
    secondaryRuntimeLine: 0,
    condition: '',
    template: '',
    watchExpressions: [],
    runtimeColumn: 0,
    secondaryRuntimeColumn: 0,
    correlationExpression: '',
    ...DEFAULT_OVERRIDES,
  },
  {
    id: 'probe-duration-999',
    type: ProbeType.PROBE_TYPE_DURATION,
    runtimeLocation: RUNTIME_LOCATION,
    runtimeLine: 28,
    secondaryRuntimeLocation: RUNTIME_LOCATION,
    secondaryRuntimeLine: 35,
    hitLimit: 1000000,
    expiryTime: BigInt(Date.now() + 1000 * 60 * 60),
    condition: '',
    template: '',
    metricName: '',
    metricExpression: '',
    watchExpressions: [],
    runtimeColumn: 0,
    secondaryRuntimeColumn: 0,
    correlationExpression: '',
    ...DEFAULT_OVERRIDES,
  },
];

const mockBrokerHandler: AgentBrokerServer = {
  getProbes: (_call, callback) => {
    const isIdle = process.env.HYPERPROBE_SCENARIO === 'IDLE';
    const probesToReturn = isIdle ? [] : HARDCODED_PROBES;

    callback(null, {
      probes: probesToReturn as any,
      nextSyncIntervalMs: 5000,
      globalConfig: {
        redactKeys: [],
        redactValues: [],
        maxObjectDepth: 3,
        maxArrayLength: 3,
        stackFrameDepth: 3,
        maxObjectProperties: 50,
        maxStringLength: 1024,
      },
    });
  },

  getSourceMapStatus: (_call, callback) => {
    callback(null, { isUploader: false, isComplete: true });
  },

  uploadSourceMap: (call, callback) => {
    call.on('data', () => {});
    call.on('end', () => {
      callback(null, { success: true });
    });
  },

  markSourceMapComplete: (_call, callback) => {
    callback(null, { success: true });
  },

  reportTelemetry: (call, callback) => {
    const _batch = call.request;
    // For benchmarks we don't log to avoid noise
    /*
    for (const event of batch.events || []) {
        if (event.probeId === 'probe-duration-999') {
            console.log(`[MockBroker] DURATION HIT: ${event.metricValue?.toFixed(4)}ms`);
        }
    }
    */

    callback(null, {
      finishedProbeIds: [],
    });
  },
};

function main() {
  const server = new grpc.Server();
  server.addService(AgentBrokerClient.service, mockBrokerHandler);

  server.bindAsync(
    '0.0.0.0:50051',
    grpc.ServerCredentials.createInsecure(),
    (err, port) => {
      if (err) {
        console.error(err);
        return;
      }
      server.start();
      console.log(`[MockBroker] Listening on port ${port}...`);
    },
  );
}

main();
