import { HyperProbe } from '@hyperprobe/node-sdk';

// Initialize the Agent only if HYPERPROBE_ENABLED is true
if (process.env.HYPERPROBE_ENABLED === 'true') {
  HyperProbe.start({
    serviceId: process.env.HYPERPROBE_SERVICE_ID || 'demo-app',
    environment: process.env.HYPERPROBE_ENVIRONMENT || 'development',
    brokerUrl: process.env.HYPERPROBE_BROKER_URL || 'http://localhost:50051',
    flushIntervalMs: 100,
    appRoot: process.env.HYPERPROBE_APP_ROOT || 'apps/demo-app',
    distLocation: process.env.HYPERPROBE_DIST_LOCATION || 'dist',
    syncIntervalMs: Number(process.env.HYPERPROBE_SYNC_INTERVAL_MS || '1000'),
    commitSha: process.env.GIT_COMMIT || new Date().toLocaleString(),
  });
}
