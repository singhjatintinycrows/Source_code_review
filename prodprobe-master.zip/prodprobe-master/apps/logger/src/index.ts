import * as path from 'node:path';
import * as zlib from 'node:zlib';
import type {
  ServerReadableStream,
  ServerUnaryCall,
  sendUnaryData,
} from '@grpc/grpc-js';
import * as grpc from '@grpc/grpc-js';
import {
  type AgentInfo,
  getConfig,
  getConsul,
  getLogger,
  HP_GLOBAL_ACTIVE_AGENTS_KEY,
  HP_LICENCE_MEMORY_REFRESH_KEY,
  HP_LICENSE_SYNC_STATUS,
  HP_LICENSE_UPGRADE_KEY,
  HP_SERVICE_LIMIT_REFRESH_KEY,
  LicenseManager,
  resolvePathWithOverlap,
  stableStringify,
  syncLicenseAndSoftLimit,
  watchLogLevel,
} from '@hyperprobe/common';
import {
  NATS_TELEMETRY_STREAM,
  NATS_TELEMETRY_SUBJECT,
} from '@hyperprobe/constants';
import {
  ProbeType as DbProbeType,
  initDatabase,
  ProbeStatus,
} from '@hyperprobe/database';
import {
  AgentBrokerClient,
  type AgentBrokerServer,
  type GetProbesRequest,
  type GetProbesResponse,
  type MarkSourceMapCompleteRequest,
  type MarkSourceMapCompleteResponse,
  type Probe as ProtoProbe,
  ProbeType as ProtoProbeType,
  type SourceMapChunk,
  type SourceMapStatusRequest,
  type SourceMapStatusResponse,
  TelemetryBatch,
  type TelemetryResponse,
  type UploadResponse,
} from '@hyperprobe/protos';
import { connect } from 'nats';
import { createClient } from 'redis';

const server = new grpc.Server();

const REDIS_KEY_PREFIX = 'probe';
const getHitKey = (id: string) => `${REDIS_KEY_PREFIX}:hits:${id}`;
const getLimitKey = (id: string) => `${REDIS_KEY_PREFIX}:limit:${id}`;
const getLatestHitKey = (id: string) => `${REDIS_KEY_PREFIX}:latest-hit:${id}`;
const getRetiredKey = (id: string) => `${REDIS_KEY_PREFIX}:retired:${id}`;

const getSourceMapExistsKey = (s: string, e: string, c: string) =>
  `sourcemap:exists:${s}:${e}:${c}`;
const getSourceMapLockKey = (s: string, e: string, c: string) =>
  `sourcemap:lock:${s}:${e}:${c}`;

const parseEnvInt = (
  key: string,
  defaultValue?: number,
): number | undefined => {
  const val = process.env[key];
  if (val === undefined || val === '') return defaultValue;
  const parsed = parseInt(val, 10);
  return Number.isNaN(parsed) ? defaultValue : parsed;
};

async function start() {
  const config = await getConfig();
  const prisma = initDatabase(config.databaseUrl);
  const logger = getLogger();
  watchLogLevel(getConsul());

  // Initial License Load
  const licenseManager = LicenseManager.getInstance();
  const licenseBootstrap = licenseManager.capturePublication();
  let sysConfig = await prisma.systemConfig.findUnique({
    where: { id: 'singleton' },
  });
  if (
    sysConfig?.licensePublicKey &&
    !licenseManager.setBootstrapPublicKey(
      sysConfig.licensePublicKey,
      licenseBootstrap,
    )
  ) {
    sysConfig = null;
  }

  const pollLicense = async () => {
    try {
      if (!sysConfig?.licensePublicKey) {
        const publication = licenseManager.capturePublication();
        const config = await prisma.systemConfig.findUnique({
          where: { id: 'singleton' },
        });
        if (
          config?.licensePublicKey &&
          licenseManager.setBootstrapPublicKey(
            config.licensePublicKey,
            publication,
          )
        ) {
          sysConfig = config;
        }
      }

      await syncLicenseAndSoftLimit(getConsul(), licenseManager);
    } catch (_e) {
      logger.warn('Failed to poll license from Consul');
    }
  };
  await pollLicense();
  setInterval(pollLicense, 1000 * 60 * 120); // Poll every 2 hours

  const nc = await connect({ servers: config.natsUrl });
  const redisClient = createClient({ url: config.redisUrl });

  redisClient.on('error', (err) => logger.error({ err }, 'Redis Client Error'));
  await redisClient.connect();
  logger.info('Connected to Redis');

  let serviceLimitMap = new Map<string, number>();

  const syncLimitsMapFromDb = async () => {
    try {
      const services = await prisma.service.findMany({
        where: { agentLimit: { not: null } },
        select: { id: true, agentLimit: true },
      });
      const tempMap = new Map<string, number>();
      for (const s of services) {
        if (s.agentLimit !== null) {
          tempMap.set(s.id, s.agentLimit);
        }
      }
      serviceLimitMap = tempMap;
      logger.info(
        { limitCount: serviceLimitMap.size },
        'Service limits map successfully synchronized from database',
      );
    } catch (err) {
      logger.error(
        { err },
        'Failed to synchronize service limits map from database',
      );
    }
  };

  const redisSubscriber = redisClient.duplicate();
  redisSubscriber.on('error', (err) =>
    logger.error({ err }, 'Redis Subscriber Error'),
  );

  let isInitialConnect = true;

  // On reconnect, auto-resync from DB to heal any missed pub/sub messages
  redisSubscriber.on('ready', async () => {
    if (isInitialConnect) {
      isInitialConnect = false;
      return;
    }
    logger.info('Redis Subscriber ready. Re-synchronizing service limits...');
    await syncLimitsMapFromDb();
  });

  await redisSubscriber.connect();
  logger.info('Connected to Redis Subscriber for service limit updates');

  await redisSubscriber.subscribe(HP_SERVICE_LIMIT_REFRESH_KEY, (message) => {
    try {
      const data = JSON.parse(message);
      const { serviceId, agentLimit, action } = data;
      if (action === 'delete' || agentLimit === null) {
        serviceLimitMap.delete(serviceId);
        logger.info({ serviceId }, 'Removed service limit from local Map');
      } else if (typeof agentLimit === 'number') {
        serviceLimitMap.set(serviceId, agentLimit);
        logger.info(
          { serviceId, agentLimit },
          'Updated service limit in local Map',
        );
      }
    } catch (err) {
      logger.error(
        { err, message },
        'Failed to parse service limit refresh event',
      );
    }
  });

  await redisSubscriber.subscribe(HP_LICENCE_MEMORY_REFRESH_KEY, async () => {
    logger.info('Received Pub/Sub message to refresh license memory.');
    await pollLicense();
  });

  // Perform initial synchronization
  await syncLimitsMapFromDb();

  const js = nc.jetstream();
  const jm = await nc.jetstreamManager();

  // Ensure stream exists
  try {
    await jm.streams.info(NATS_TELEMETRY_STREAM);
  } catch (_err) {
    await jm.streams.add({
      name: NATS_TELEMETRY_STREAM,
      subjects: [NATS_TELEMETRY_SUBJECT],
    });
    logger.info({ stream: NATS_TELEMETRY_STREAM }, 'Created JetStream stream');
  }

  const handler: AgentBrokerServer = {
    getProbes: async (
      call: ServerUnaryCall<GetProbesRequest, GetProbesResponse>,
      callback: sendUnaryData<GetProbesResponse>,
    ) => {
      try {
        const { serviceId, environment, agentId, commitSha, agentVersion } =
          call.request;

        logger.info(
          { agentId, serviceId, environment, commitSha, agentVersion },
          'Agent fetching probes',
        );

        // Tier 1 Check: Global Shutdown
        const licenseStatus = LicenseManager.getInstance().getStatus();
        if (
          licenseStatus === HP_LICENSE_SYNC_STATUS.LOCKED ||
          licenseStatus === HP_LICENSE_SYNC_STATUS.REVOKED
        ) {
          logger.warn(
            { agentId },
            `Agent rejected: License is ${licenseStatus}`,
          );
          return callback(
            {
              code: grpc.status.PERMISSION_DENIED,
              message: `License is ${licenseStatus}`,
            },
            null as any,
          );
        }

        const agentInfoObj: AgentInfo = {
          agentId,
          serviceId,
          environment,
          commitSha,
          sdkVersion: agentVersion || undefined,
        };
        const agentInfoStr = stableStringify(agentInfoObj)!;
        const now = Date.now();
        const cleanupThreshold = now - 100000; // 100 seconds

        // Tier 2 Check: Lenient Agent Limits
        const maxAgents = LicenseManager.getInstance().getMaxAgents();
        const softLimit = LicenseManager.getInstance().getSoftAgentLimit();
        const customServiceLimit = serviceLimitMap.get(serviceId);

        // If custom setting exists, use it; otherwise, inherit the Consul softLimit
        const limitToEnforce =
          customServiceLimit !== undefined ? customServiceLimit : softLimit;

        const multi = redisClient.multi();
        // 1. Evict globally dead agents & check global presence/count
        multi.zRemRangeByScore(
          HP_GLOBAL_ACTIVE_AGENTS_KEY,
          '-inf',
          cleanupThreshold,
        );
        multi.zCard(HP_GLOBAL_ACTIVE_AGENTS_KEY);
        multi.zScore(HP_GLOBAL_ACTIVE_AGENTS_KEY, agentId);

        // 2. Evict service dead agents & check service presence/count
        multi.zRemRangeByScore(
          `active_agents:${serviceId}`,
          '-inf',
          cleanupThreshold,
        );
        multi.zCard(`active_agents:${serviceId}`);
        multi.zScore(`active_agents:${serviceId}`, agentInfoStr);

        const results = await multi.exec();
        const globalAgentCount = Number(results[1]);
        const globalScore = results[2];
        const isGlobalExisting =
          globalScore !== null && Number(globalScore) >= cleanupThreshold;

        const serviceAgentCount = Number(results[4]);
        const serviceScore = results[5];
        const isServiceExisting =
          serviceScore !== null && Number(serviceScore) >= cleanupThreshold;

        // Check Global License Limits
        let rejectGlobal = false;
        if (!isGlobalExisting && globalAgentCount >= maxAgents) {
          rejectGlobal = true;
        }

        // Check Per-Service Soft Limits
        let rejectService = false;
        if (!isServiceExisting && serviceAgentCount >= limitToEnforce) {
          rejectService = true;
        }

        if (rejectGlobal) {
          logger.warn(
            { agentId },
            `Agent rejected: Max global agents (${maxAgents}) exceeded. Current active agents: ${globalAgentCount}`,
          );
          await redisClient.set(HP_LICENSE_UPGRADE_KEY, '1', { EX: 86400 }); // Persistent 24 hour banner

          // Gracefully reject by returning 0 probes
          return callback(null, {
            probes: [],
            nextSyncIntervalMs:
              parseEnvInt('HYPERPROBE_SYNC_INTERVAL_MS') || 10000,
            globalConfig: {
              redactKeys: process.env.HYPERPROBE_REDACT_KEYS
                ? process.env.HYPERPROBE_REDACT_KEYS.split(',')
                    .map((k) => k.trim())
                    .filter(Boolean)
                : [],
              redactValues: process.env.HYPERPROBE_REDACT_VALUES
                ? process.env.HYPERPROBE_REDACT_VALUES.split(',')
                    .map((v) => v.trim())
                    .filter(Boolean)
                : [],
              maxObjectDepth: undefined,
              maxArrayLength: undefined,
              stackFrameDepth: undefined,
              maxObjectProperties: undefined,
              maxStringLength: undefined,
              captureClosures: undefined,
            },
          });
        }

        if (rejectService) {
          logger.warn(
            { agentId, serviceId, limit: limitToEnforce },
            `Agent rejected: Service agent limit (${limitToEnforce}) exceeded. Current service active agents: ${serviceAgentCount}`,
          );

          // Gracefully reject by returning 0 probes
          return callback(null, {
            probes: [],
            nextSyncIntervalMs:
              parseEnvInt('HYPERPROBE_SYNC_INTERVAL_MS') || 10000,
            globalConfig: {
              redactKeys: process.env.HYPERPROBE_REDACT_KEYS
                ? process.env.HYPERPROBE_REDACT_KEYS.split(',')
                    .map((k) => k.trim())
                    .filter(Boolean)
                : [],
              redactValues: process.env.HYPERPROBE_REDACT_VALUES
                ? process.env.HYPERPROBE_REDACT_VALUES.split(',')
                    .map((v) => v.trim())
                    .filter(Boolean)
                : [],
              maxObjectDepth: undefined,
              maxArrayLength: undefined,
              stackFrameDepth: undefined,
              maxObjectProperties: undefined,
              maxStringLength: undefined,
              captureClosures: undefined,
            },
          });
        }

        // Handle global health warning banner state
        if (globalAgentCount >= maxAgents) {
          await redisClient.set(HP_LICENSE_UPGRADE_KEY, '1', { EX: 86400 });
        } else {
          await redisClient.del(HP_LICENSE_UPGRADE_KEY);
        }

        const probes = await prisma.probe.findMany({
          where: {
            serviceId,
            environment,
            commitSha,
            status: ProbeStatus.ACTIVE,
          },
        });

        const nowBigInt = BigInt(Date.now());
        const activeProbes = probes.filter((p) => {
          if (BigInt(p.expiryTime) <= nowBigInt) {
            return false;
          }
          if (p.type === DbProbeType.DURATION) {
            return (
              !!p.secondaryRuntimeLocation && (p.secondaryRuntimeLine || 0) > 0
            );
          }
          return true;
        });

        logger.info(
          { agentId, count: activeProbes.length },
          'Returning active probes to agent',
        );

        const regMulti = redisClient.multi();

        // Mark probes as live
        for (const p of activeProbes) {
          regMulti.set(`probe:live:${p.id}`, '1', { EX: 120 });
        }

        // Register active agent in sorted set
        regMulti.zRemRangeByScore(
          `active_agents:${serviceId}`,
          '-inf',
          cleanupThreshold,
        );
        regMulti.zAdd(`active_agents:${serviceId}`, [
          { score: now, value: agentInfoStr },
        ]);
        regMulti.expire(`active_agents:${serviceId}`, 120);

        // Register in Global Active Agents set for fast O(1) limits checking
        regMulti.zAdd(HP_GLOBAL_ACTIVE_AGENTS_KEY, [
          { score: now, value: agentId },
        ]);
        regMulti.expire(HP_GLOBAL_ACTIVE_AGENTS_KEY, 120);

        await regMulti.exec();

        const protoProbes: ProtoProbe[] = activeProbes.map((p) => ({
          id: p.id,
          type: mapDbProbeTypeToProto(p.type),
          runtimeLocation: p.runtimeLocation,
          runtimeLine: p.runtimeLine,
          runtimeColumn: p.runtimeColumn || 0,
          secondaryRuntimeLocation: p.secondaryRuntimeLocation || '',
          secondaryRuntimeLine: p.secondaryRuntimeLine || 0,
          secondaryRuntimeColumn: p.secondaryRuntimeColumn || 0,
          condition: p.condition || '',
          template: p.template || '',
          metricName: p.metricName || '',
          metricExpression: p.metricExpression || '',
          watchExpressions: (p.watchExpressions as string[]) || [],
          hitLimit: p.hitLimit,
          expiryTime: p.expiryTime,
          correlationExpression: p.correlationExpression || '',
          maxObjectDepth: p.maxObjectDepth ?? undefined,
          maxArrayLength: p.maxArrayLength ?? undefined,
          stackFrameDepth: p.stackFrameDepth ?? undefined,
          maxObjectProperties: p.maxObjectProperties ?? undefined,
          maxStringLength: p.maxStringLength ?? undefined,
          shouldCaptureTraceId: p.shouldCaptureTraceId ?? false,
          logLevel: p.logLevel ?? undefined,
          shouldLogToStdout: p.shouldLogToStdout ?? false,
          captureClosures: p.captureClosures ?? false,
        }));

        callback(null, {
          probes: protoProbes,
          nextSyncIntervalMs: parseEnvInt('HYPERPROBE_SYNC_INTERVAL_MS'),
          globalConfig: {
            redactKeys: process.env.HYPERPROBE_REDACT_KEYS
              ? process.env.HYPERPROBE_REDACT_KEYS.split(',')
                  .map((k) => k.trim())
                  .filter(Boolean)
              : [],
            redactValues: process.env.HYPERPROBE_REDACT_VALUES
              ? process.env.HYPERPROBE_REDACT_VALUES.split(',')
                  .map((v) => v.trim())
                  .filter(Boolean)
              : [],
            maxObjectDepth: parseEnvInt('HYPERPROBE_MAX_OBJECT_DEPTH'),
            maxArrayLength: parseEnvInt('HYPERPROBE_MAX_ARRAY_LENGTH'),
            stackFrameDepth: parseEnvInt('HYPERPROBE_STACK_FRAME_DEPTH'),
            maxObjectProperties: parseEnvInt(
              'HYPERPROBE_MAX_OBJECT_PROPERTIES',
            ),
            maxStringLength: parseEnvInt('HYPERPROBE_MAX_STRING_LENGTH'),
            captureClosures: process.env.HYPERPROBE_CAPTURE_CLOSURES === 'true',
          },
        });
      } catch (error: any) {
        logger.error({ error }, 'GetProbes Error');
        callback(error, null as any);
      }
    },

    getSourceMapStatus: async (
      call: ServerUnaryCall<SourceMapStatusRequest, SourceMapStatusResponse>,
      callback: sendUnaryData<SourceMapStatusResponse>,
    ) => {
      try {
        const { serviceId, environment, commitSha } = call.request;

        const existsKey = getSourceMapExistsKey(
          serviceId,
          environment,
          commitSha,
        );
        const lockKey = getSourceMapLockKey(serviceId, environment, commitSha);

        let sourceMapRequired = false;
        const serviceMapRequiredKey = `service:sourcemap-required:${serviceId}`;
        const sourceMapRequiredRedis = await redisClient.get(
          serviceMapRequiredKey,
        );
        if (sourceMapRequiredRedis === '1') {
          sourceMapRequired = true;
        } else if (sourceMapRequiredRedis === '0') {
          sourceMapRequired = false;
        } else {
          const service = await prisma.service.findUnique({
            where: { id: serviceId },
          });
          if (service) {
            sourceMapRequired = service.sourceMapRequired;
            await redisClient.set(
              serviceMapRequiredKey,
              sourceMapRequired ? '1' : '0',
              { EX: 3600 },
            ); // cache for 1 hour
          } else {
            await redisClient.set(serviceMapRequiredKey, '0', { EX: 3600 });
          }
        }

        if (!sourceMapRequired) {
          return callback(null, { isUploader: false, isComplete: true });
        }

        // 1. Fast Path: Check Redis cache
        const exists = await redisClient.get(existsKey);
        if (exists === '1') {
          return callback(null, { isUploader: false, isComplete: true });
        }

        // 2. Distributed Coordination: Attempt to acquire the uploader/indexing lock
        // We acquire the lock BEFORE checking the database to ensure that if an agent is
        // currently indexing, others wait for it to finish rather than seeing a
        // "partially indexed" state in the DB.
        const acquired = await redisClient.set(lockKey, '1', {
          NX: true,
          EX: 180,
        }); // 3 min lock

        if (!acquired) {
          // Someone else is uploading or indexing. Tell the agent to wait.
          return callback(null, { isUploader: false, isComplete: false });
        }

        // 3. Double Check Database (While holding the lock)
        const commitRecord = await prisma.sourceMapCommit.findUnique({
          where: {
            serviceId_environment_commitSha: {
              serviceId,
              environment,
              commitSha,
            },
            isComplete: true,
          },
        });

        if (commitRecord) {
          // It's actually complete. Update cache and release lock.
          await redisClient.set(existsKey, '1', { EX: 86400 }); // 24h
          await redisClient.del(lockKey);
          return callback(null, { isUploader: false, isComplete: true });
        }

        // 4. This agent is now the designated uploader.
        return callback(null, { isUploader: true, isComplete: false });
      } catch (error: any) {
        logger.error({ error }, 'GetSourceMapStatus Error');
        callback(error, null as any);
      }
    },

    uploadSourceMap: async (
      call: ServerReadableStream<SourceMapChunk, UploadResponse>,
      callback: sendUnaryData<UploadResponse>,
    ) => {
      let isFinished = false;
      let serviceId = '';
      let environment = '';
      let commitSha = '';
      let fileName = '';
      const decompressedChunks: Buffer[] = [];
      let totalSize = 0;
      let decompressedSize = 0;
      const MAX_SOURCE_MAP_SIZE = 20 * 1024 * 1024; // 20MB limit
      const MAX_DECOMPRESSED_SIZE = 100 * 1024 * 1024; // 100MB limit for unzipped data

      const gunzip = zlib.createGunzip();

      gunzip.on('data', (chunk: Buffer) => {
        decompressedSize += chunk.length;
        if (decompressedSize > MAX_DECOMPRESSED_SIZE) {
          isFinished = true;
          const err = new Error('Decompressed source map exceeds size limit');
          gunzip.destroy(err);
          call.destroy(err);
          return callback(err, null as any);
        }
        decompressedChunks.push(chunk);
      });
      gunzip.on('error', (err) => {
        if (isFinished) return;
        isFinished = true;
        call.destroy(err);
        return callback(err, null as any);
      });

      call.on('data', (chunk: SourceMapChunk) => {
        if (isFinished) return;

        if (!serviceId) {
          serviceId = chunk.serviceId;
          environment = chunk.environment;
          commitSha = chunk.commitSha;
          fileName = chunk.fileName;
        }

        // Basic validation
        if (
          chunk.serviceId !== serviceId ||
          chunk.commitSha !== commitSha ||
          chunk.fileName !== fileName ||
          chunk.environment !== environment
        ) {
          isFinished = true;
          const err = new Error('Inconsistent metadata in stream');
          call.destroy(err);
          return callback(err, null as any);
        }

        totalSize += chunk.data.length;
        if (totalSize > MAX_SOURCE_MAP_SIZE) {
          isFinished = true;
          const err = new Error('Source map exceeds maximum size limit');
          call.destroy(err);
          return callback(err, null as any);
        }

        gunzip.write(Buffer.from(chunk.data));
      });

      call.on('end', async () => {
        if (isFinished) return;
        gunzip.end();
      });

      gunzip.on('end', async () => {
        if (isFinished) return;
        isFinished = true;

        try {
          if (!serviceId || !commitSha || !fileName || !environment) {
            return callback(
              new Error('Missing metadata in source map upload'),
              null as any,
            );
          }

          const content = Buffer.concat(decompressedChunks);
          logger.info(
            {
              serviceId,
              environment,
              commitSha,
              fileName,
              size: content.length,
            },
            'Source map received',
          );

          let sources: string[] = [];
          let contentJson: any = {};
          try {
            // Memory Optimization: Directly parse buffer to avoid extra string copy
            contentJson = JSON.parse(content.toString('utf8'));
            sources = contentJson.sources || [];
          } catch (err) {
            logger.warn(
              { err, fileName },
              'Failed to parse sources from uploaded map',
            );
          }

          await prisma.sourceMap.upsert({
            where: {
              serviceId_environment_commitSha_fileName: {
                serviceId,
                environment,
                commitSha,
                fileName,
              },
            },
            update: { content: contentJson, sources },
            create: {
              serviceId,
              environment,
              commitSha,
              fileName,
              content: contentJson,
              sources,
            },
          });

          // Ensure a commit record exists (Incomplete until markSourceMapComplete is called)
          await prisma.sourceMapCommit.upsert({
            where: {
              serviceId_environment_commitSha: {
                serviceId,
                environment,
                commitSha,
              },
            },
            update: {},
            create: { serviceId, environment, commitSha, isComplete: false },
          });

          callback(null, { success: true });
        } catch (error: any) {
          logger.error({ error }, 'UploadSourceMap Error');
          callback(error, null as any);
        }
      });

      call.on('error', (err) => {
        if (isFinished) return;
        isFinished = true;
        gunzip.destroy(err);
        logger.error({ err }, 'UploadSourceMap Stream Error');
        callback(err, null as any);
      });
    },

    markSourceMapComplete: async (
      call: ServerUnaryCall<
        MarkSourceMapCompleteRequest,
        MarkSourceMapCompleteResponse
      >,
      callback: sendUnaryData<MarkSourceMapCompleteResponse>,
    ) => {
      try {
        const { serviceId, environment, commitSha } = call.request;

        const existsKey = getSourceMapExistsKey(
          serviceId,
          environment,
          commitSha,
        );
        const lockKey = getSourceMapLockKey(serviceId, environment, commitSha);

        logger.info(
          { serviceId, environment, commitSha },
          'Processing and marking source map as complete',
        );

        // 1. Fetch all source maps for this commit
        const sourceMaps = await prisma.sourceMap.findMany({
          where: { serviceId, environment, commitSha },
        });

        const fileMappings: any[] = [];
        for (const sm of sourceMaps) {
          try {
            const rawMap = sm.content as any;
            const sources = sm.sources || rawMap.sources || [];
            const sourceRoot = rawMap.sourceRoot || '';

            for (const source of sources) {
              const isMeteorApp = source.startsWith('meteor://💻app/');

              // 1. Strip bundler protocols (webpack:///, file:///, etc.)
              let cleanPath = source.replace(
                /^(webpack:\/\/(?:[^/]+\/)?|file:\/\/\/|meteor:\/\/(?:[^/]+\/)?)/,
                '',
              );

              // 2. Strip query parameters
              cleanPath = cleanPath.split('?')[0];

              // 3. Normalize separators (Windows \ to Unix /)
              cleanPath = cleanPath.replace(/\\/g, '/');

              // 4. Resolve path against uploaded directory and sourceRoot
              // path.join handles .. and . segments
              const baseDir = path.posix.dirname(sm.fileName);

              let resolvedPath = resolvePathWithOverlap(
                baseDir,
                cleanPath,
                sourceRoot,
              );

              // 5. Final cleanup: strip leading ./ and ensure it doesn't escape git root via ../
              resolvedPath = path.posix.normalize(resolvedPath);
              if (resolvedPath.startsWith('./'))
                resolvedPath = resolvedPath.substring(2);
              resolvedPath = resolvedPath.replace(/^(\.\.\/)+/, '');

              if (isMeteorApp) {
                if (resolvedPath.startsWith('app/')) {
                  resolvedPath = resolvedPath.substring(4);
                } else if (resolvedPath.includes('/app/')) {
                  resolvedPath = resolvedPath.replace('/app/', '/');
                }
              }

              fileMappings.push({
                sourceMapId: sm.id,
                serviceId,
                environment,
                commitSha,
                resolvedPath,
                rawPath: source,
              });
            }
          } catch (err) {
            logger.warn(
              { err, fileName: sm.fileName },
              'Failed to process source map file mappings',
            );
          }
        }

        // 2. Atomic Database Update
        // We use a transaction to ensure that we never mark the commit as complete
        // until ALL individual file mappings are successfully persisted.
        await prisma.$transaction(
          async (tx) => {
            if (fileMappings.length > 0) {
              await tx.sourceMapFile.createMany({
                data: fileMappings,
                skipDuplicates: true,
              });
            }

            await tx.sourceMapCommit.upsert({
              where: {
                serviceId_environment_commitSha: {
                  serviceId,
                  environment,
                  commitSha,
                },
              },
              update: { isComplete: true },
              create: { serviceId, environment, commitSha, isComplete: true },
            });
          },
          { timeout: 30000 },
        );

        // 3. Update Redis and Release Lock
        await redisClient
          .multi()
          .set(existsKey, '1', { EX: 86400 })
          .del(lockKey)
          .exec();

        logger.info(
          { commitSha, mappingsCount: fileMappings.length },
          'Source map indexing finalized',
        );

        // 4. Background Cleanup (Non-blocking)
        // Retention policy: Keep only 15 latest completed commits per service/env
        const obsoleteCommits = await prisma.sourceMapCommit.findMany({
          where: { serviceId, environment, isComplete: true },
          select: { commitSha: true },
          orderBy: { createdAt: 'desc' },
          skip: 15,
        });

        const commitsToDelete = obsoleteCommits.map((c) => c.commitSha);
        if (commitsToDelete.length > 0) {
          (async () => {
            try {
              const delMulti = redisClient.multi();
              for (const sha of commitsToDelete) {
                delMulti.del(
                  getSourceMapExistsKey(serviceId, environment, sha),
                );
                delMulti.del(getSourceMapLockKey(serviceId, environment, sha));
              }
              await delMulti.exec();

              await prisma.sourceMap.deleteMany({
                where: {
                  serviceId,
                  environment,
                  commitSha: { in: commitsToDelete },
                },
              });
              await prisma.sourceMapFile.deleteMany({
                where: {
                  serviceId,
                  environment,
                  commitSha: { in: commitsToDelete },
                },
              });
              await prisma.sourceMapCommit.deleteMany({
                where: {
                  serviceId,
                  environment,
                  commitSha: { in: commitsToDelete },
                },
              });
              logger.info(
                { deletedCommits: commitsToDelete.length },
                'Cleaned up obsolete source maps',
              );
            } catch (err) {
              logger.error(
                { err },
                'Error during source map retention cleanup',
              );
            }
          })();
        }

        callback(null, { success: true });
      } catch (error: any) {
        logger.error({ error }, 'MarkSourceMapComplete Error');
        callback(error, null as any);
      }
    },

    reportTelemetry: async (
      call: ServerUnaryCall<TelemetryBatch, TelemetryResponse>,
      callback: sendUnaryData<TelemetryResponse>,
    ) => {
      try {
        const { agentId, events } = call.request;
        logger.info(
          { agentId, eventCount: events.length },
          'Received telemetry batch',
        );

        const hitIncrements = new Map<string, number>();
        for (const event of events) {
          hitIncrements.set(
            event.probeId,
            (hitIncrements.get(event.probeId) || 0) + 1,
          );
        }

        const finishedProbeIds: string[] = [];
        const probeIds = Array.from(hitIncrements.keys());

        if (probeIds.length > 0) {
          // Pass 1: Check retirement to avoid recreating keys for finished probes
          const checkMulti = redisClient.multi();
          for (const probeId of probeIds) {
            checkMulti.exists(getRetiredKey(probeId));
          }
          const retirementResults = await checkMulti.exec();

          const activeProbeIds: string[] = [];
          for (let i = 0; i < probeIds.length; i++) {
            const isRetired = Number(retirementResults[i]) === 1;
            if (isRetired) {
              finishedProbeIds.push(probeIds[i]);
            } else {
              activeProbeIds.push(probeIds[i]);
            }
          }

          // Pass 2: Update hits and keep TTL for active probes only
          if (activeProbeIds.length > 0) {
            const actMulti = redisClient.multi();
            const hitTimestamp = new Date().toISOString();

            for (const probeId of activeProbeIds) {
              const increment = hitIncrements.get(probeId)!;

              actMulti.incrBy(getHitKey(probeId), increment);
              actMulti.set(getLatestHitKey(probeId), hitTimestamp, {
                KEEPTTL: true,
              });
              actMulti.get(getLimitKey(probeId));
            }

            const actResults = await actMulti.exec();

            for (let i = 0; i < activeProbeIds.length; i++) {
              // Results stride is 3: INCRBY, SET, GET
              const currentHits = Number(actResults[i * 3]);
              const limit = Number(actResults[i * 3 + 2] || 0);

              if (limit > 0 && currentHits >= limit) {
                finishedProbeIds.push(activeProbeIds[i]);
              }
            }
          }
        }

        // Binary pass-through: We serialize the incoming gRPC object back to binary
        // using the generated Protobuf classes and push it to NATS.
        const binaryData = TelemetryBatch.encode(call.request).finish();

        await js.publish(NATS_TELEMETRY_SUBJECT, binaryData);
        logger.debug(
          { subject: NATS_TELEMETRY_SUBJECT },
          'Published batch to NATS',
        );

        callback(null, { finishedProbeIds });
      } catch (error: any) {
        logger.error({ error }, 'ReportTelemetry Error');
        callback(error, null as any);
      }
    },
  };

  server.addService(AgentBrokerClient.service, handler as any);

  const PORT = process.env.GRPC_PORT || '50051';
  server.bindAsync(
    `0.0.0.0:${PORT}`,
    grpc.ServerCredentials.createInsecure(),
    (err, port) => {
      if (err) {
        logger.error({ err }, 'Failed to bind gRPC server');
        process.exit(1);
      }
      server.start();
      logger.info({ port }, 'gRPC Agent Broker listening');
    },
  );
}

function mapDbProbeTypeToProto(type: DbProbeType): ProtoProbeType {
  switch (type) {
    case DbProbeType.SNAPSHOT:
      return ProtoProbeType.PROBE_TYPE_SNAPSHOT;
    case DbProbeType.LOG:
      return ProtoProbeType.PROBE_TYPE_LOG;
    case DbProbeType.COUNTER:
      return ProtoProbeType.PROBE_TYPE_COUNTER;
    case DbProbeType.METRIC:
      return ProtoProbeType.PROBE_TYPE_METRIC;
    case DbProbeType.DURATION:
      return ProtoProbeType.PROBE_TYPE_DURATION;
    default:
      return ProtoProbeType.PROBE_TYPE_UNSPECIFIED;
  }
}

start().catch((err) => {
  const logger = getLogger();
  logger.error(err);
  process.exit(1);
});
