import {
  type AgentInfo,
  HP_GLOBAL_ACTIVE_AGENTS_KEY,
} from '@hyperprobe/common';
import { TRPCError } from '@trpc/server';
import { z } from 'zod';
import { authProcedure, protectedProcedure, t } from '../trpc.js';

export const agentsRouter = t.router({
  listActiveAgents: protectedProcedure
    .input(z.object({ serviceIds: z.array(z.string()).min(1).optional() }))
    .query(async ({ ctx, input }) => {
      let allowedServiceIds: string[] = [];
      if (!ctx.user.permissions.isAdmin) {
        allowedServiceIds = input.serviceIds
          ? input.serviceIds.filter(
              (id) => ctx.user.permissions.permissions[id] !== undefined,
            )
          : Object.keys(ctx.user.permissions.permissions);
      } else {
        const services = await ctx.prisma.service.findMany({
          where: {
            id: input.serviceIds ? { in: input.serviceIds } : undefined,
          },
          select: { id: true },
        });

        allowedServiceIds = services.map((service) => service.id);
      }

      if (allowedServiceIds.length === 0) return [];

      const now = Date.now();
      const threshold = now - 100000;

      const multi = ctx.redisClient.multi();
      for (const serviceId of allowedServiceIds) {
        multi.zRemRangeByScore(`active_agents:${serviceId}`, '-inf', threshold);
        multi.zRange(`active_agents:${serviceId}`, 0, -1);
      }

      const results = await multi.exec();
      const agentMap = new Map<string, AgentInfo>();
      const activeAgentIds: Array<{ agentId: string; serviceId: string }> = [];

      // Results have a cleanup result and active members for each service.
      for (let i = 0; i < allowedServiceIds.length; i++) {
        const rawAgents = results[i * 2 + 1] as unknown as string[];
        for (const rawAgent of rawAgents ?? []) {
          // JSON is the canonical member format. Raw IDs are read only to bridge
          // data already written by the incompatible branch logger.
          if (rawAgent.startsWith('{')) {
            try {
              const parsed = JSON.parse(rawAgent) as AgentInfo;
              if (parsed?.agentId) {
                agentMap.set(parsed.agentId, parsed);
              }
            } catch {
              // Ignore malformed legacy JSON
            }
          } else {
            activeAgentIds.push({
              agentId: rawAgent,
              serviceId: allowedServiceIds[i]!,
            });
          }
        }
      }

      const metadata =
        activeAgentIds.length > 0
          ? await ctx.redisClient.mGet(
              activeAgentIds.map(
                ({ agentId, serviceId }) =>
                  `active_agent_info:${serviceId}:${agentId}`,
              ),
            )
          : [];

      for (let i = 0; i < activeAgentIds.length; i++) {
        const { agentId, serviceId } = activeAgentIds[i]!;
        if (agentMap.has(agentId)) continue;
        const value = metadata[i];
        if (value) {
          try {
            const parsed = JSON.parse(value) as AgentInfo;
            if (parsed?.agentId === agentId && parsed.serviceId === serviceId) {
              agentMap.set(agentId, parsed);
              continue;
            }
          } catch {
            // Ignore malformed sidecar JSON and fall back to the member identity.
          }
        }
        agentMap.set(agentId, {
          agentId,
          serviceId,
          environment: 'unknown',
          commitSha: '',
        });
      }

      return Array.from(agentMap.values());
    }),
  getActiveAgentsCount: authProcedure.query(async ({ ctx }) => {
    try {
      const now = Date.now();
      const cleanupThreshold = now - 100000;

      const multi = ctx.redisClient.multi();
      multi.zRemRangeByScore(
        HP_GLOBAL_ACTIVE_AGENTS_KEY,
        '-inf',
        cleanupThreshold,
      );
      multi.zCard(HP_GLOBAL_ACTIVE_AGENTS_KEY);

      const results = await multi.exec();
      return { count: Number(results[1]) };
    } catch (err) {
      ctx.logger.error(
        { err },
        'Failed to fetch active agents count from Redis',
      );
      throw new TRPCError({
        code: 'INTERNAL_SERVER_ERROR',
        message: 'Could not retrieve active agent stats at this time.',
      });
    }
  }),
});
