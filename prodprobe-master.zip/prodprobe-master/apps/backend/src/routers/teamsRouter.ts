import { TRPCError } from '@trpc/server';
import { z } from 'zod';
import { adminProcedure, protectedProcedure, t } from '../trpc.js';

export const teamsRouter = t.router({
  create: adminProcedure
    .input(
      z.object({ name: z.string(), isAdminTeam: z.boolean().default(false) }),
    )
    .mutation(async ({ ctx, input }) => {
      if (input.isAdminTeam) {
        const adminTeam = await ctx.prisma.team.findFirst({
          where: { isAdminTeam: true },
        });
        if (adminTeam) {
          throw new TRPCError({
            code: 'BAD_REQUEST',
            message: 'Admin team already exists',
          });
        }
      }
      return ctx.prisma.team.create({
        data: input,
      });
    }),
  list: protectedProcedure.query(async ({ ctx }) => {
    // Admins see all teams. Others see only teams they belong to.

    if (ctx.user.permissions.isAdmin) {
      return await ctx.prisma.team.findMany({
        orderBy: [{ createdAt: 'desc' }, { id: 'desc' }],
      });
    }

    return await ctx.prisma.team.findMany({
      where: {
        users: {
          some: {
            userId: ctx.user.userId,
          },
        },
      },
      orderBy: [{ createdAt: 'desc' }, { id: 'desc' }],
    });
  }),
  update: adminProcedure
    .input(z.object({ id: z.string(), name: z.string() }))
    .mutation(async ({ ctx, input }) => {
      const currentTeam = await ctx.prisma.team.findFirst({
        where: {
          id: {
            not: input.id,
          },
          name: input.name,
        },
      });
      if (currentTeam) {
        throw new TRPCError({
          code: 'BAD_REQUEST',
          message: 'Team name already exists',
        });
      }
      return ctx.prisma.team.update({
        where: { id: input.id },
        data: { name: input.name },
      });
    }),
  delete: adminProcedure
    .input(z.object({ id: z.string() }))
    .mutation(async ({ ctx, input }) => {
      await ctx.prisma.team.delete({
        where: { id: input.id },
      });
      return { success: true };
    }),
});
