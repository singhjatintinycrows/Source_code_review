import { TRPCError } from '@trpc/server';
import { z } from 'zod';
import {
  asAuditStore,
  completeEvidenceAudit,
  EvidenceAuditError,
  type EvidenceAuditEvent,
  failEvidenceAudit,
  startEvidenceAudit,
} from '../observability/audit.js';
import {
  type EvidenceScope,
  OBSERVABILITY_SIGNALS,
  type ObservabilitySignalName,
  type ProviderAdapter,
  type ProviderDiscoveryAvailability,
  type ProviderDiscoveryFailure,
  type ProviderDiscoveryResult,
  type StoredCapabilityBinding,
  type StoredObservabilityConnection,
} from '../observability/contracts.js';
import { CredentialCipherError } from '../observability/credentialCipher.js';
import {
  ProviderError,
  providerErrorFrom,
  providerErrorToTrpcError,
} from '../observability/errors.js';
import {
  redactEvidence,
  safeFailureMessage,
} from '../observability/redaction.js';
import { observabilityProviderRegistry } from '../observability/registry.js';
import { coordinatorFor } from '../observability/requestCoordinator.js';
import { SENTRY_METRIC_INTERVALS_SECONDS } from '../rca/sentryExploreClient.js';
import {
  type Context,
  hasServiceMembership,
  serviceMemberProcedure,
  t,
} from '../trpc.js';

const MAX_OBSERVABILITY_ROWS = 25;
const MAX_METRIC_POINTS = 360;
const MAX_ROW_VALUE_CHARACTERS = 512;
const MAX_TABLE_STRING_CHARACTERS = 16 * 1024;
const MAX_ERROR_TYPES = 10;
const MAX_QUERY_WINDOW_MS = 24 * 60 * 60 * 1_000;
const MAX_PROVIDER_CURSOR_CHARACTERS = 2_048;

const IdentifierSchema = z
  .string()
  .min(1)
  .max(128)
  .refine((value) => value.trim().length > 0, 'Must not be blank');
const TimestampSchema = z.string().datetime({ offset: true });
const MetricSchema = z.enum(['THROUGHPUT', 'FAILURE_RATE']);
const PurposeSchema = z
  .string()
  .trim()
  .min(1, 'Purpose must not be blank.')
  .max(128);
const TraceIdSchema = z
  .string()
  .trim()
  .min(1, 'Trace ID must not be blank.')
  .max(512);
const TraceFormatSchema = z
  .string()
  .trim()
  .min(1, 'Trace format must not be blank.')
  .max(128);

const ScopeSchema = z
  .object({
    serviceId: IdentifierSchema,
    environment: IdentifierSchema,
    providerEnvironment: IdentifierSchema.optional(),
    release: z.string().min(1).max(256).optional(),
  })
  .strict();
type RcaScope = z.infer<typeof ScopeSchema>;

const TimeRangeSchema = z
  .object({ start: TimestampSchema, end: TimestampSchema })
  .strict()
  .superRefine((range, context) => {
    const start = Date.parse(range.start);
    const end = Date.parse(range.end);
    if (end <= start) {
      context.addIssue({
        code: z.ZodIssueCode.custom,
        path: ['end'],
        message: 'Query end must be after query start.',
      });
    }
    if (end - start > MAX_QUERY_WINDOW_MS) {
      context.addIssue({
        code: z.ZodIssueCode.custom,
        path: ['end'],
        message: 'An observability query may not exceed 24 hours.',
      });
    }
  });

export const QueryTableInputSchema = ScopeSchema.extend({
  timeRange: TimeRangeSchema,
  purpose: PurposeSchema,
  filter: z.string().min(1).max(512).optional(),
  traceId: TraceIdSchema.optional(),
  traceFormat: TraceFormatSchema.optional(),
  limit: z.number().int().positive().max(MAX_OBSERVABILITY_ROWS).default(20),
  cursor: z.string().min(1).max(MAX_PROVIDER_CURSOR_CHARACTERS).optional(),
}).strict();
export const QueryMetricInputSchema = ScopeSchema.extend({
  timeRange: TimeRangeSchema,
  purpose: PurposeSchema,
  filter: z.string().min(1).max(512).optional(),
  metric: MetricSchema.default('THROUGHPUT'),
  intervalSeconds: z.number().int().min(60).max(3_600).default(60),
}).strict();

type TableSignal = 'ERRORS' | 'LOGS' | 'TRACES';
type TableQueryInput = z.infer<typeof QueryTableInputSchema>;
type CompactRow = Record<string, string | number>;
type CompactState = {
  remainingCharacters: number;
  truncatedValueCount: number;
  omittedFieldCount: number;
  redactionCount: number;
};
type MetricPoint = { timestamp: string; value: number };

type ObservabilityStore = {
  observabilityConnection: {
    findMany(args: unknown): Promise<StoredObservabilityConnection[]>;
    findFirst(args: unknown): Promise<StoredObservabilityConnection | null>;
  };
  observabilityCapabilityBinding: {
    findMany(args: unknown): Promise<StoredCapabilityBinding[]>;
  };
};

type ResolvedSource = {
  binding: StoredCapabilityBinding;
  connection: StoredObservabilityConnection;
  adapter: ProviderAdapter;
  credential: string;
  scope: EvidenceScope;
};

type SourceFailure = ProviderDiscoveryFailure & {
  connectionId: string;
  connectionName: string;
  provider: string;
  section?: keyof ProviderDiscoveryResult;
};

function observabilityStore(ctx: Context): ObservabilityStore {
  return ctx.prisma as unknown as ObservabilityStore;
}

function asRecord(value: unknown): Record<string, unknown> | null {
  return typeof value === 'object' && value !== null && !Array.isArray(value)
    ? (value as Record<string, unknown>)
    : null;
}

function boundedText(value: unknown, state: CompactState): string | undefined {
  if (
    typeof value !== 'string' &&
    typeof value !== 'number' &&
    typeof value !== 'boolean'
  ) {
    if (value !== undefined && value !== null) state.omittedFieldCount += 1;
    return undefined;
  }
  const original = String(value).trim();
  if (!original) return undefined;
  if (state.remainingCharacters <= 0) {
    state.omittedFieldCount += 1;
    return undefined;
  }
  // Inspect the full selected value before truncation can split a credential.
  const redacted = redactEvidence(original);
  state.redactionCount += redacted.redactionCount;
  const text = redacted.value;
  const maximum = Math.min(MAX_ROW_VALUE_CHARACTERS, state.remainingCharacters);
  const output =
    text.length > maximum
      ? `${text.slice(0, Math.max(0, maximum - 3))}${'...'.slice(0, maximum)}`
      : text;
  state.remainingCharacters -= output.length;
  if (output.length < text.length) state.truncatedValueCount += 1;
  return output;
}

function firstValue(
  row: Record<string, unknown>,
  keys: readonly string[],
): unknown {
  for (const key of keys) {
    if (row[key] !== undefined && row[key] !== null) return row[key];
  }
  return undefined;
}

function addText(
  target: CompactRow,
  outputKey: string,
  row: Record<string, unknown>,
  sourceKeys: readonly string[],
  state: CompactState,
): void {
  const value = boundedText(firstValue(row, sourceKeys), state);
  if (value !== undefined) target[outputKey] = value;
}

function addErrorType(
  target: CompactRow,
  row: Record<string, unknown>,
  state: CompactState,
): void {
  for (const key of ['error.type', 'error_type']) {
    let value = row[key];
    let clipped = false;
    if (Array.isArray(value)) {
      clipped = value.length > MAX_ERROR_TYPES;
      const types = value
        .slice(0, MAX_ERROR_TYPES)
        .flatMap((entry) =>
          typeof entry === 'string' && entry.trim() ? [entry.trim()] : [],
        );
      if (types.length === 0) continue;
      // Sentry exception chains are lists; the public compact field stays scalar.
      value = types.join(', ') + (clipped ? ', ...' : '');
    }
    const previousTruncations = state.truncatedValueCount;
    const text = boundedText(value, state);
    if (text === undefined) continue;
    target.errorType = text;
    if (clipped && state.truncatedValueCount === previousTruncations) {
      state.truncatedValueCount += 1;
    }
    return;
  }
}

function addDuration(
  target: CompactRow,
  row: Record<string, unknown>,
  state: CompactState,
): void {
  const value = firstValue(row, ['span.duration', 'duration', 'duration_ms']);
  const numeric =
    typeof value === 'number'
      ? value
      : typeof value === 'string' && value.trim() !== ''
        ? Number(value)
        : NaN;
  if (Number.isFinite(numeric) && numeric >= 0) {
    target.durationMs = Math.round(numeric * 1_000) / 1_000;
  } else if (value !== undefined && value !== null) {
    state.omittedFieldCount += 1;
  }
}

export function normalizeTableRows(signal: TableSignal, rows: unknown[]) {
  const state: CompactState = {
    remainingCharacters: MAX_TABLE_STRING_CHARACTERS,
    truncatedValueCount: 0,
    omittedFieldCount: 0,
    redactionCount: 0,
  };
  let malformedRowCount = 0;
  const normalized: CompactRow[] = [];
  for (const value of rows.slice(0, MAX_OBSERVABILITY_ROWS)) {
    const row = asRecord(value);
    if (!row) {
      malformedRowCount += 1;
      continue;
    }
    const compact: CompactRow = {};
    if (signal === 'ERRORS') {
      addText(compact, 'id', row, ['id'], state);
      addText(compact, 'timestamp', row, ['timestamp'], state);
      addText(compact, 'message', row, ['message', 'title'], state);
      addText(compact, 'severity', row, ['level', 'severity'], state);
      addErrorType(compact, row, state);
      addText(compact, 'traceId', row, ['trace', 'trace_id'], state);
      addText(compact, 'requestId', row, ['request_id', 'request.id'], state);
    } else if (signal === 'LOGS') {
      addText(compact, 'id', row, ['sentry.item_id', 'id'], state);
      addText(compact, 'timestamp', row, ['timestamp'], state);
      addText(compact, 'message', row, ['message'], state);
      addText(compact, 'severity', row, ['severity', 'level'], state);
      addErrorType(compact, row, state);
      addText(compact, 'traceId', row, ['trace', 'trace_id'], state);
      addText(compact, 'spanId', row, ['span', 'span_id'], state);
      addText(compact, 'requestId', row, ['request_id', 'request.id'], state);
    } else {
      addText(compact, 'id', row, ['id', 'span_id'], state);
      addText(compact, 'timestamp', row, ['timestamp'], state);
      addText(compact, 'traceId', row, ['trace', 'trace_id'], state);
      addText(compact, 'operation', row, ['span.op', 'operation'], state);
      addText(
        compact,
        'message',
        row,
        ['span.description', 'description'],
        state,
      );
      addText(compact, 'status', row, ['span.status', 'status'], state);
      addDuration(compact, row, state);
      addText(compact, 'transaction', row, ['transaction'], state);
    }
    if (Object.keys(compact).length === 0) {
      malformedRowCount += 1;
      continue;
    }
    normalized.push(compact);
  }
  return {
    rows: normalized,
    redactionCount: state.redactionCount,
    delivery: {
      providerRowCount: rows.length,
      returnedRowCount: normalized.length,
      truncatedValueCount: state.truncatedValueCount,
      omittedFieldCount: state.omittedFieldCount,
      malformedRowCount,
    },
  };
}

function normalizeAlertRows(rows: unknown[]) {
  const state: CompactState = {
    remainingCharacters: MAX_TABLE_STRING_CHARACTERS,
    truncatedValueCount: 0,
    omittedFieldCount: 0,
    redactionCount: 0,
  };
  let malformedRowCount = 0;
  const normalized: CompactRow[] = [];
  for (const value of rows.slice(0, MAX_OBSERVABILITY_ROWS)) {
    const row = asRecord(value);
    if (!row) {
      malformedRowCount += 1;
      continue;
    }
    const compact: CompactRow = {};
    addText(compact, 'id', row, ['id', 'shortId'], state);
    addText(compact, 'title', row, ['title'], state);
    addText(compact, 'culprit', row, ['culprit'], state);
    addText(compact, 'severity', row, ['level'], state);
    addText(compact, 'status', row, ['status'], state);
    addText(compact, 'firstSeen', row, ['firstSeen'], state);
    addText(compact, 'lastSeen', row, ['lastSeen'], state);
    addText(compact, 'count', row, ['count'], state);
    if (Object.keys(compact).length === 0) {
      malformedRowCount += 1;
      continue;
    }
    normalized.push(compact);
  }
  return {
    rows: normalized,
    redactionCount: state.redactionCount,
    delivery: {
      providerRowCount: rows.length,
      returnedRowCount: normalized.length,
      truncatedValueCount: state.truncatedValueCount,
      omittedFieldCount: state.omittedFieldCount,
      malformedRowCount,
    },
  };
}

function metricTimestamp(value: unknown): string | undefined {
  if (typeof value === 'string' && Number.isFinite(Date.parse(value))) {
    return new Date(value).toISOString();
  }
  if (typeof value === 'number' && Number.isFinite(value)) {
    const milliseconds =
      Math.abs(value) < 100_000_000_000 ? value * 1_000 : value;
    const date = new Date(milliseconds);
    return Number.isFinite(date.getTime()) ? date.toISOString() : undefined;
  }
  return undefined;
}

export function normalizeMetricPoints(value: unknown): {
  points: MetricPoint[];
  providerPointCount: number;
  omittedIncompletePointCount: number;
} {
  const points: MetricPoint[] = [];
  // Keep the existing unique numeric-candidate count, including omitted points.
  const candidates = new Map<string, boolean>();
  let omittedIncompletePointCount = 0;
  const valueKeys = [
    'value',
    'count()',
    'count',
    'failure_rate()',
    'failure_rate',
    'failureRate',
  ];
  const addPoint = (
    timestamp: string,
    raw: unknown,
    incomplete: boolean,
  ): boolean => {
    const numeric =
      typeof raw === 'number'
        ? raw
        : typeof raw === 'string' && raw.trim() !== ''
          ? Number(raw)
          : NaN;
    const key = Number.isFinite(numeric)
      ? `${timestamp}:${numeric}`
      : undefined;
    if (key && !candidates.has(key)) candidates.set(key, false);
    if (incomplete) {
      omittedIncompletePointCount += 1;
      return true;
    }
    if (!key) return false;
    if (!candidates.get(key)) {
      candidates.set(key, true);
      points.push({ timestamp, value: numeric });
    }
    return true;
  };
  const visit = (current: unknown, depth: number): void => {
    if (depth > 5) return;
    if (Array.isArray(current)) {
      if (
        current.length >= 2 &&
        (typeof current[0] === 'number' || typeof current[0] === 'string')
      ) {
        const timestamp = metricTimestamp(current[0]);
        if (timestamp) {
          let value: unknown = current[1];
          if (Array.isArray(value) && value.length > 0) value = value[0];
          const row = asRecord(value);
          if (
            addPoint(
              timestamp,
              row ? firstValue(row, valueKeys) : value,
              row?.incomplete === true,
            )
          )
            return;
        }
      }
      for (const entry of current) visit(entry, depth + 1);
      return;
    }
    const row = asRecord(current);
    if (!row) return;
    const timestamp = metricTimestamp(
      firstValue(row, ['timestamp', 'time', 'start', 'date']),
    );
    if (
      timestamp &&
      addPoint(timestamp, firstValue(row, valueKeys), row.incomplete === true)
    )
      return;
    for (const nested of Object.values(row)) visit(nested, depth + 1);
  };
  visit(value, 0);
  return {
    points,
    providerPointCount: candidates.size,
    omittedIncompletePointCount,
  };
}

export function effectiveMetricInterval(
  start: string,
  end: string,
  requestedIntervalSeconds: number,
): { intervalSeconds: number; automaticallyCoarsened: boolean } {
  const durationMilliseconds = Date.parse(end) - Date.parse(start);
  const minimumIntervalSeconds = Math.ceil(
    durationMilliseconds / ((MAX_METRIC_POINTS - 1) * 1_000),
  );
  const intervalSeconds = SENTRY_METRIC_INTERVALS_SECONDS.find(
    (interval) =>
      interval >= Math.max(requestedIntervalSeconds, minimumIntervalSeconds),
  );
  if (
    intervalSeconds === undefined ||
    intervalSeconds * 1_000 > durationMilliseconds
  ) {
    throw new ProviderError(
      'INVALID_REQUEST',
      'The metric time range must accommodate a supported Sentry interval.',
    );
  }
  return {
    intervalSeconds,
    automaticallyCoarsened: intervalSeconds > requestedIntervalSeconds,
  };
}

export function downsampleMetricPoints(
  points: readonly MetricPoint[],
  maximum = MAX_METRIC_POINTS,
): { points: MetricPoint[]; downsampled: boolean } {
  const sorted = [...points].sort((left, right) =>
    left.timestamp.localeCompare(right.timestamp),
  );
  if (sorted.length <= maximum) return { points: sorted, downsampled: false };
  const stride = (sorted.length - 1) / (maximum - 1);
  const sampled = Array.from({ length: maximum }, (_, index) => {
    return sorted[Math.round(index * stride)] as MetricPoint;
  });
  return { points: sampled, downsampled: true };
}

function asTrpcError(error: unknown): TRPCError {
  if (error instanceof TRPCError) return error;
  if (error instanceof ProviderError) return providerErrorToTrpcError(error);
  if (error instanceof CredentialCipherError) {
    return new TRPCError({
      code: 'PRECONDITION_FAILED',
      message: 'The configured provider credential is unavailable.',
      cause: error,
    });
  }
  return new TRPCError({
    code: 'INTERNAL_SERVER_ERROR',
    message: 'The observability request could not be completed.',
    cause: error,
  });
}

function selectedScope(scope: RcaScope) {
  return {
    environment: scope.environment,
    providerEnvironment: scope.providerEnvironment ?? scope.environment,
    ...(scope.release ? { release: scope.release } : {}),
  };
}

async function requireRcaServiceAccess(
  ctx: Context,
  serviceId: string,
): Promise<void> {
  if (!hasServiceMembership(ctx.user, serviceId)) {
    throw new TRPCError({
      code: 'FORBIDDEN',
      message: 'You do not have access to this service.',
    });
  }
  const service = await ctx.prisma.service.findUnique({
    where: { id: serviceId },
    select: { id: true },
  });
  if (!service) {
    throw new TRPCError({ code: 'NOT_FOUND', message: 'Service not found.' });
  }
}

function sourceProvenance(source: ResolvedSource) {
  return {
    bindingId: source.binding.id,
    connectionId: source.connection.id,
    connectionName: source.connection.name,
    provider: source.connection.provider,
    scope: source.scope,
  };
}

async function requireCredentialEncryptionNotInMaintenance(ctx: Context) {
  if (await ctx.credentialEncryptionMaintenanceActive()) {
    throw new TRPCError({
      code: 'PRECONDITION_FAILED',
      message:
        'Credential encryption maintenance is in progress. Try again after it completes.',
    });
  }
}

async function resolveSource(
  ctx: Context,
  input: RcaScope,
  signal: ObservabilitySignalName,
): Promise<ResolvedSource> {
  await requireRcaServiceAccess(ctx, input.serviceId);
  const bindings = await observabilityStore(
    ctx,
  ).observabilityCapabilityBinding.findMany({
    where: { serviceId: input.serviceId, signal },
    include: { connection: true },
  });
  const binding = bindings[0];
  if (!binding || binding.connection.enabled === false) {
    throw new TRPCError({
      code: 'PRECONDITION_FAILED',
      message: `${signal} is disabled in this service's observability settings.`,
    });
  }
  if (!ctx.credentialCipher) {
    throw new TRPCError({
      code: 'PRECONDITION_FAILED',
      message: 'Credential encryption is not configured on this backend.',
    });
  }
  await requireCredentialEncryptionNotInMaintenance(ctx);
  const adapter = observabilityProviderRegistry.require(
    binding.connection.provider,
  );
  if (!adapter.supportedSignals.includes(signal)) {
    throw new ProviderError(
      'UNSUPPORTED',
      `${binding.connection.name} does not support ${signal}.`,
    );
  }
  const credential = ctx.credentialCipher.decrypt(
    {
      serviceId: binding.connection.serviceId,
      connectionId: binding.connection.id,
      provider: binding.connection.provider,
      credentialFormat: binding.connection.credentialFormat,
    },
    binding.connection,
  );
  return {
    binding,
    connection: binding.connection,
    adapter,
    credential,
    scope: selectedScope(input),
  };
}

async function auditedSourceCall<T, R>(
  ctx: Context,
  source: ResolvedSource,
  signal: ObservabilitySignalName,
  purpose: string,
  input: { start: string; end: string; query: unknown },
  request: () => Promise<T>,
  materialize: (result: T) => {
    value: R;
    resultCount: number;
    redactionCount: number;
    partial: boolean;
    sourceFailureCount?: number;
  },
): Promise<R> {
  const actorId = ctx.user?.userId;
  if (!actorId) throw new TRPCError({ code: 'UNAUTHORIZED' });
  const auditStore = asAuditStore(ctx.prisma);
  let auditEvent: EvidenceAuditEvent;
  try {
    auditEvent = await startEvidenceAudit(auditStore, {
      serviceId: source.connection.serviceId,
      actorId,
      connection: source.connection,
      signal,
      purpose,
      query: input.query,
      start: input.start,
      end: input.end,
    });
  } catch (error) {
    throw new EvidenceAuditError('Evidence audit could not be started.', {
      cause: error,
    });
  }
  try {
    const raw = await coordinatorFor(ctx.redisClient, ctx.logger).run(
      source.connection.provider,
      source.connection.id,
      request,
    );
    const materialized = materialize(raw);
    try {
      await completeEvidenceAudit(auditStore, auditEvent, {
        outcome: materialized.partial ? 'PARTIAL' : 'COMPLETE',
        resultCount: materialized.resultCount,
        redactionCount: materialized.redactionCount,
        sourceFailureCount: materialized.sourceFailureCount,
      });
    } catch (error) {
      throw new EvidenceAuditError('Evidence audit could not be completed.', {
        cause: error,
      });
    }
    return materialized.value;
  } catch (error) {
    if (error instanceof EvidenceAuditError) throw error;
    // If this fails, the audit error propagates and evidence remains withheld.
    try {
      await failEvidenceAudit(auditStore, auditEvent, error);
    } catch (auditError) {
      throw new EvidenceAuditError('Evidence audit could not be completed.', {
        cause: auditError,
      });
    }
    throw error;
  }
}

export async function settledSources<T>(
  sources: readonly ResolvedSource[],
  request: (source: ResolvedSource, index: number) => Promise<T>,
): Promise<{ values: T[]; warnings: string[]; failures: SourceFailure[] }> {
  const settled = await Promise.allSettled(sources.map(request));
  const values: T[] = [];
  const warnings: string[] = [];
  const failures: SourceFailure[] = [];
  for (let index = 0; index < settled.length; index += 1) {
    const result = settled[index]!;
    if (result.status === 'fulfilled') {
      values.push(result.value);
      continue;
    }
    if (result.reason instanceof EvidenceAuditError) throw result.reason;
    const source = sources[index]!;
    const error = providerErrorFrom(result.reason);
    failures.push({
      connectionId: source.connection.id,
      connectionName: source.connection.name,
      provider: source.connection.provider,
      code: error.code,
      reason: safeFailureMessage(error),
      ...(error.rateLimit?.retryAt ? { retryAt: error.rateLimit.retryAt } : {}),
    });
    warnings.push(
      `${source.connection.name} (${source.connection.provider}) failed: ${safeFailureMessage(result.reason)}`,
    );
  }
  if (values.length === 0) {
    const firstFailure = settled.find(
      (result): result is PromiseRejectedResult => result.status === 'rejected',
    );
    throw (
      firstFailure?.reason ??
      new ProviderError('UNAVAILABLE', 'No source responded.')
    );
  }
  return { values, warnings, failures };
}

async function queryTable(
  ctx: Context,
  input: TableQueryInput,
  signal: TableSignal,
) {
  const source = await resolveSource(ctx, input, signal);
  const result = await auditedSourceCall(
    ctx,
    source,
    signal,
    input.purpose,
    {
      start: input.timeRange.start,
      end: input.timeRange.end,
      query: {
        signal,
        scope: source.scope,
        filter: input.filter,
        traceId: input.traceId,
        traceFormat: input.traceFormat,
        limit: input.limit,
        cursor: input.cursor,
      },
    },
    () =>
      source.adapter.queryTable(source.connection, source.credential, {
        signal,
        scope: source.scope,
        start: input.timeRange.start,
        end: input.timeRange.end,
        filter: input.filter,
        traceId: input.traceId,
        traceFormat: input.traceFormat,
        limit: input.limit,
        cursor: input.cursor,
      }),
    (providerResult) => {
      const normalized = normalizeTableRows(signal, providerResult.rows);
      return {
        value: {
          source: sourceProvenance(source),
          ...normalized,
          page: providerResult.page,
        },
        resultCount: normalized.rows.length,
        redactionCount: normalized.redactionCount,
        partial:
          normalized.redactionCount > 0 ||
          normalized.delivery.returnedRowCount <
            normalized.delivery.providerRowCount,
      };
    },
  );
  return {
    signal,
    scope: selectedScope(input),
    rows: result.rows,
    delivery: {
      ...result.delivery,
      returnedRowCount: result.rows.length,
    },
    page: result.page,
    sources: [
      {
        ...result.source,
        resultCount: result.rows.length,
        redactionCount: result.redactionCount,
      },
    ],
    warnings: [],
  };
}

async function queryAlerts(ctx: Context, input: TableQueryInput) {
  const source = await resolveSource(ctx, input, 'ALERTS');
  const result = await auditedSourceCall(
    ctx,
    source,
    'ALERTS',
    input.purpose,
    {
      start: input.timeRange.start,
      end: input.timeRange.end,
      query: {
        signal: 'ALERTS',
        scope: source.scope,
        filter: input.filter,
        limit: input.limit,
        cursor: input.cursor,
      },
    },
    () =>
      source.adapter.queryAlerts(source.connection, source.credential, {
        scope: source.scope,
        start: input.timeRange.start,
        end: input.timeRange.end,
        filter: input.filter,
        limit: input.limit,
        cursor: input.cursor,
      }),
    (providerResult) => {
      const normalized = normalizeAlertRows(providerResult.rows);
      return {
        value: {
          source: sourceProvenance(source),
          ...normalized,
          page: providerResult.page,
        },
        resultCount: normalized.rows.length,
        redactionCount: normalized.redactionCount,
        partial:
          normalized.redactionCount > 0 ||
          normalized.delivery.returnedRowCount <
            normalized.delivery.providerRowCount,
      };
    },
  );
  return {
    signal: 'ALERTS' as const,
    scope: selectedScope(input),
    rows: result.rows,
    delivery: {
      ...result.delivery,
      returnedRowCount: result.rows.length,
    },
    page: result.page,
    sources: [
      {
        ...result.source,
        resultCount: result.rows.length,
        redactionCount: result.redactionCount,
      },
    ],
    warnings: [],
  };
}

async function queryMetrics(
  ctx: Context,
  input: z.infer<typeof QueryMetricInputSchema>,
) {
  const source = await resolveSource(ctx, input, 'METRICS');
  const interval = effectiveMetricInterval(
    input.timeRange.start,
    input.timeRange.end,
    input.intervalSeconds,
  );
  const result = await auditedSourceCall(
    ctx,
    source,
    'METRICS',
    input.purpose,
    {
      start: input.timeRange.start,
      end: input.timeRange.end,
      query: {
        signal: 'METRICS',
        scope: source.scope,
        filter: input.filter,
        metric: input.metric,
        intervalSeconds: interval.intervalSeconds,
      },
    },
    () =>
      source.adapter.queryMetrics(source.connection, source.credential, {
        scope: source.scope,
        start: input.timeRange.start,
        end: input.timeRange.end,
        filter: input.filter,
        metric: input.metric,
        intervalSeconds: interval.intervalSeconds,
      }),
    (providerResult) => {
      const normalized = normalizeMetricPoints(providerResult.timeSeries);
      const sampled = downsampleMetricPoints(
        normalized.points,
        MAX_METRIC_POINTS,
      );
      const redacted = redactEvidence(sampled.points);
      return {
        value: {
          source: sourceProvenance(source),
          points: redacted.value,
          providerSeriesCount: providerResult.timeSeries.length,
          providerPointCount: normalized.providerPointCount,
          omittedIncompletePointCount: normalized.omittedIncompletePointCount,
          downsampled: sampled.downsampled,
          redactionCount: redacted.redactionCount,
        },
        resultCount: redacted.value.length,
        redactionCount: redacted.redactionCount,
        partial:
          normalized.omittedIncompletePointCount > 0 ||
          sampled.downsampled ||
          redacted.redactionCount > 0,
      };
    },
  );
  return {
    scope: selectedScope(input),
    metric: input.metric,
    requestedIntervalSeconds: input.intervalSeconds,
    intervalSeconds: interval.intervalSeconds,
    points: result.points,
    delivery: {
      providerSeriesCount: result.providerSeriesCount,
      providerPointCount: result.providerPointCount,
      returnedPointCount: result.points.length,
      omittedIncompletePointCount: result.omittedIncompletePointCount,
      downsampled: result.downsampled,
    },
    sources: [
      {
        ...result.source,
        points: result.points,
        resultCount: result.points.length,
        redactionCount: result.redactionCount,
        providerSeriesCount: result.providerSeriesCount,
        providerPointCount: result.providerPointCount,
        omittedIncompletePointCount: result.omittedIncompletePointCount,
        downsampled: result.downsampled,
      },
    ],
    warnings: [
      ...(interval.automaticallyCoarsened
        ? [
            `Metric interval automatically increased from ${input.intervalSeconds} seconds to ${interval.intervalSeconds} seconds to use a supported bucket and cover the full requested window within ${MAX_METRIC_POINTS} points.`,
          ]
        : []),
      ...(result.omittedIncompletePointCount > 0
        ? [
            `Omitted ${result.omittedIncompletePointCount} metric ${result.omittedIncompletePointCount === 1 ? 'point' : 'points'} marked incomplete by the provider; missing buckets are not zero.`,
          ]
        : []),
    ],
  };
}

async function configuredCapability(
  ctx: Context,
  input: RcaScope,
  signal: ObservabilitySignalName,
) {
  try {
    await requireRcaServiceAccess(ctx, input.serviceId);
    await requireCredentialEncryptionNotInMaintenance(ctx);
    const bindings = await observabilityStore(
      ctx,
    ).observabilityCapabilityBinding.findMany({
      where: { serviceId: input.serviceId, signal },
      include: { connection: true },
    });
    const binding = bindings[0];
    if (!binding || binding.connection.enabled === false) {
      return {
        availability: 'UNAVAILABLE' as const,
        reason: `${signal} is not enabled for this service.`,
      };
    }
    const adapter = observabilityProviderRegistry.require(
      binding.connection.provider,
    );
    if (!adapter.supportedSignals.includes(signal)) {
      throw new ProviderError(
        'UNSUPPORTED',
        `${binding.connection.name} does not support ${signal}.`,
      );
    }
    return {
      availability: 'AVAILABLE' as const,
      sources: [
        {
          bindingId: binding.id,
          connectionId: binding.connection.id,
          connectionName: binding.connection.name,
          provider: binding.connection.provider,
        },
      ],
    };
  } catch (error) {
    return {
      availability: 'UNAVAILABLE' as const,
      reason: safeFailureMessage(error),
    };
  }
}

export async function getObservabilityCapabilities(
  ctx: Context,
  input: RcaScope,
) {
  await requireRcaServiceAccess(ctx, input.serviceId);
  const [errors, logs, traces, metrics, alerts] = await Promise.all(
    OBSERVABILITY_SIGNALS.map((signal) =>
      configuredCapability(ctx, input, signal),
    ),
  );
  return {
    checkedAt: new Date().toISOString(),
    scope: selectedScope(input),
    errors,
    logs,
    traces,
    metrics,
    alerts,
    limits: {
      maxRows: MAX_OBSERVABILITY_ROWS,
      maxTimeRangeSeconds: MAX_QUERY_WINDOW_MS / 1_000,
      maxMetricPoints: MAX_METRIC_POINTS,
    },
  };
}

function aggregateDiscovery<T>(
  values: readonly ProviderDiscoveryAvailability<T>[],
): ProviderDiscoveryAvailability<T> {
  const available = values.filter(
    (value): value is { availability: 'AVAILABLE'; values: T[] } =>
      value.availability === 'AVAILABLE',
  );
  if (available.length === 0) {
    const unavailable = values.find(
      (
        value,
      ): value is { availability: 'UNAVAILABLE' } & ProviderDiscoveryFailure =>
        value.availability === 'UNAVAILABLE',
    );
    return (
      unavailable ?? {
        availability: 'UNAVAILABLE',
        code: 'UNAVAILABLE',
        reason: 'Provider discovery could not be completed.',
      }
    );
  }
  const unique = new Map<string, T>();
  for (const entry of available.flatMap((value) => value.values)) {
    unique.set(JSON.stringify(entry), entry);
  }
  return {
    availability: 'AVAILABLE',
    values: [...unique.values()].slice(0, 25),
  };
}

async function discoverySources(
  ctx: Context,
  serviceId: string,
  connectionId?: string,
): Promise<ResolvedSource[]> {
  await requireRcaServiceAccess(ctx, serviceId);
  const store = observabilityStore(ctx);
  let bindings: StoredCapabilityBinding[];
  if (connectionId) {
    const connection = await store.observabilityConnection.findFirst({
      where: { id: connectionId, serviceId },
    });
    if (!connection) {
      throw new TRPCError({
        code: 'NOT_FOUND',
        message: 'Observability connection not found.',
      });
    }
    if (connection.enabled === false) {
      throw new TRPCError({
        code: 'PRECONDITION_FAILED',
        message: 'Observability connection is disabled.',
      });
    }
    bindings = [
      {
        id: `discovery:${connection.id}`,
        serviceId: connection.serviceId,
        signal: 'ERRORS',
        connectionId: connection.id,
        connection,
      },
    ];
  } else {
    bindings = await store.observabilityCapabilityBinding.findMany({
      where: { serviceId },
      include: { connection: true },
    });
  }
  const uniqueBindings = [
    ...new Map(
      bindings
        .filter((binding) => binding.connection.enabled !== false)
        .map((binding) => [binding.connection.id, binding]),
    ).values(),
  ];
  if (uniqueBindings.length === 0) {
    throw new TRPCError({
      code: 'PRECONDITION_FAILED',
      message:
        'No enabled observability connection is configured for this service.',
    });
  }
  if (!ctx.credentialCipher) {
    throw new TRPCError({
      code: 'PRECONDITION_FAILED',
      message: 'Credential encryption is not configured on this backend.',
    });
  }
  await requireCredentialEncryptionNotInMaintenance(ctx);
  return uniqueBindings.map((binding) => {
    const connection = binding.connection;
    const adapter = observabilityProviderRegistry.require(connection.provider);
    const credential = ctx.credentialCipher!.decrypt(
      {
        serviceId: connection.serviceId,
        connectionId: connection.id,
        provider: connection.provider,
        credentialFormat: connection.credentialFormat,
      },
      connection,
    );
    return {
      binding,
      connection,
      adapter,
      credential,
      scope: { environment: 'default', providerEnvironment: 'default' },
    };
  });
}

export async function discoverObservabilityContext(
  ctx: Context,
  input: { serviceId: string; connectionId?: string },
) {
  const sources = await discoverySources(
    ctx,
    input.serviceId,
    input.connectionId,
  );
  const now = new Date();
  const start = new Date(now.getTime() - 60_000).toISOString();
  const end = now.toISOString();
  const sections = ['alerts', 'environments', 'releases', 'tags'] as const;
  const settled = await settledSources(sources, (source) =>
    auditedSourceCall(
      ctx,
      source,
      'ERRORS',
      'RCA_DISCOVERY',
      { start, end, query: { purpose: 'RCA_DISCOVERY' } },
      async () => {
        const discovery = await source.adapter.discoverContext(
          source.connection,
          source.credential,
        );
        const failures: SourceFailure[] = [];
        for (const section of sections) {
          const result = discovery[section];
          if (result.availability === 'UNAVAILABLE') {
            failures.push({
              connectionId: source.connection.id,
              connectionName: source.connection.name,
              provider: source.connection.provider,
              section,
              code: result.code,
              reason: result.reason,
              ...(result.retryAt ? { retryAt: result.retryAt } : {}),
            });
          }
        }
        // Record section-level limits while still holding the request's slot.
        const retryAt = await coordinatorFor(
          ctx.redisClient,
          ctx.logger,
        ).recordRateLimits(
          source.connection.provider,
          source.connection.id,
          failures.filter((failure) => failure.code === 'RATE_LIMITED'),
        );
        for (const failure of failures) {
          if (failure.code === 'RATE_LIMITED') failure.retryAt = retryAt;
        }
        return { discovery, failures, retryAt };
      },
      ({ discovery, failures, retryAt }) => {
        if (failures.length === sections.length) {
          const failure =
            failures.find((entry) => entry.code === 'RATE_LIMITED') ??
            failures[0]!;
          throw new ProviderError(
            failure.code,
            retryAt
              ? `The observability provider rate-limited this connection. Retry after ${retryAt}.`
              : safeFailureMessage(new Error(failure.reason)),
            { rateLimit: retryAt ? { retryAt } : undefined },
          );
        }
        const redacted = redactEvidence({ discovery, failures });
        const valueCount = Object.values(redacted.value.discovery).reduce(
          (count, section) =>
            count +
            (section.availability === 'AVAILABLE' ? section.values.length : 0),
          0,
        );
        return {
          value: {
            source: sourceProvenance(source),
            ...redacted.value,
            redactionCount: redacted.redactionCount,
          },
          resultCount: valueCount,
          redactionCount: redacted.redactionCount,
          partial: failures.length > 0 || redacted.redactionCount > 0,
          // Each audit event covers one connection, not one discovery section.
          sourceFailureCount: failures.length > 0 ? 1 : 0,
        };
      },
    ),
  );
  const discoveries = settled.values;
  const bindings = await observabilityStore(
    ctx,
  ).observabilityCapabilityBinding.findMany({
    where: { serviceId: input.serviceId },
    include: { connection: true },
  });
  const enabledBindings = bindings.filter(
    (binding) => binding.connection.enabled !== false,
  );
  return {
    provider:
      discoveries.length === 1 ? discoveries[0]!.source.provider : 'MULTIPLE',
    supportedSignals: OBSERVABILITY_SIGNALS,
    configuredCapabilities: OBSERVABILITY_SIGNALS.map((signal) => ({
      signal,
      enabled: enabledBindings.some((binding) => binding.signal === signal),
      sources: enabledBindings
        .filter((binding) => binding.signal === signal)
        .map((binding) => ({
          bindingId: binding.id,
          connectionId: binding.connection.id,
          provider: binding.connection.provider,
        })),
    })),
    limits: {
      maxEnvironmentCandidates: 25,
      maxReleaseCandidates: 25,
      maxTagCandidates: 25,
    },
    alerts: aggregateDiscovery(
      discoveries.map((discovery) => discovery.discovery.alerts),
    ),
    environments: aggregateDiscovery(
      discoveries.map((discovery) => discovery.discovery.environments),
    ),
    releases: aggregateDiscovery(
      discoveries.map((discovery) => discovery.discovery.releases),
    ),
    tags: aggregateDiscovery(
      discoveries.map((discovery) => discovery.discovery.tags),
    ),
    sources: discoveries.map((discovery) => ({
      ...discovery.source,
      redactionCount: discovery.redactionCount,
    })),
    failures: [
      ...settled.failures,
      ...discoveries.flatMap((discovery) => discovery.failures),
    ],
    warnings: [
      ...settled.warnings,
      ...discoveries.flatMap((discovery) =>
        discovery.failures.map(
          (failure) =>
            `${failure.connectionName} (${failure.provider}) ${failure.section} discovery failed: ${failure.reason}`,
        ),
      ),
    ],
  };
}

export async function testObservabilityConnection(
  ctx: Context,
  input: { serviceId: string; connectionId: string },
) {
  const discovery = await discoverObservabilityContext(ctx, input);
  const sections = [
    discovery.alerts,
    discovery.environments,
    discovery.releases,
    discovery.tags,
  ];
  const firstUnavailable = sections.find(
    (section) => section.availability === 'UNAVAILABLE',
  );
  const connected = sections.some(
    (section) => section.availability === 'AVAILABLE',
  );
  const summary = (section: (typeof sections)[number]) =>
    section.availability === 'AVAILABLE'
      ? { availability: 'AVAILABLE' as const, itemCount: section.values.length }
      : section;
  return {
    checkedAt: new Date().toISOString(),
    connection: connected
      ? { availability: 'AVAILABLE' as const }
      : {
          availability: 'UNAVAILABLE' as const,
          reason:
            firstUnavailable && firstUnavailable.availability === 'UNAVAILABLE'
              ? firstUnavailable.reason
              : 'Observability connection could not be verified.',
        },
    alerts: summary(discovery.alerts),
    environments: summary(discovery.environments),
    releases: summary(discovery.releases),
    tags: summary(discovery.tags),
    sources: discovery.sources,
    failures: discovery.failures,
    warnings: discovery.warnings,
  };
}

export const rcaRouter = t.router({
  discoverObservabilityContext: serviceMemberProcedure
    .input(z.object({ serviceId: IdentifierSchema }).strict())
    .query(async ({ ctx, input }) => {
      try {
        return await discoverObservabilityContext(ctx, input);
      } catch (error) {
        throw asTrpcError(error);
      }
    }),

  getCapabilities: serviceMemberProcedure
    .input(ScopeSchema)
    .query(async ({ ctx, input }) => {
      try {
        return await getObservabilityCapabilities(ctx, input);
      } catch (error) {
        throw asTrpcError(error);
      }
    }),

  queryErrors: serviceMemberProcedure
    .input(QueryTableInputSchema)
    .mutation(async ({ ctx, input }) => {
      try {
        return await queryTable(ctx, input, 'ERRORS');
      } catch (error) {
        throw asTrpcError(error);
      }
    }),

  queryLogs: serviceMemberProcedure
    .input(QueryTableInputSchema)
    .mutation(async ({ ctx, input }) => {
      try {
        return await queryTable(ctx, input, 'LOGS');
      } catch (error) {
        throw asTrpcError(error);
      }
    }),

  queryTraces: serviceMemberProcedure
    .input(QueryTableInputSchema)
    .mutation(async ({ ctx, input }) => {
      try {
        return await queryTable(ctx, input, 'TRACES');
      } catch (error) {
        throw asTrpcError(error);
      }
    }),

  queryMetrics: serviceMemberProcedure
    .input(QueryMetricInputSchema)
    .mutation(async ({ ctx, input }) => {
      try {
        return await queryMetrics(ctx, input);
      } catch (error) {
        throw asTrpcError(error);
      }
    }),

  queryAlerts: serviceMemberProcedure
    .input(QueryTableInputSchema)
    .mutation(async ({ ctx, input }) => {
      try {
        return await queryAlerts(ctx, input);
      } catch (error) {
        throw asTrpcError(error);
      }
    }),
});
