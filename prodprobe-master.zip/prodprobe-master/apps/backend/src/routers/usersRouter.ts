import type { Prisma } from '@hyperprobe/database';
import { TRPCError } from '@trpc/server';
import { z } from 'zod';
import { adminProcedure, t } from '../trpc.js';

export const usersRouter = t.router({
  create: adminProcedure
    .input(
      z.object({
        email: z.string().email(),
        teamIds: z.array(z.string()).min(1),
      }),
    )
    .mutation(async ({ ctx, input }) => {
      return ctx.prisma.$transaction(async (tx) => {
        const user = await tx.user.create({
          data: {
            email: input.email,
          },
        });
        const uniqueTeamIds = Array.from(new Set(input.teamIds));
        await tx.userTeam.createMany({
          data: uniqueTeamIds.map((teamId) => ({
            userId: user.id,
            teamId,
          })),
        });
        return user;
      });
    }),
  list: adminProcedure
    .input(
      z
        .object({
          email: z.string().optional(),
          teamIds: z.array(z.string()).optional(),
          limit: z.number().int().positive().optional().default(10),
          offset: z.number().int().min(0).optional().default(0),
        })
        .optional()
        .default({}),
    )
    .query(async ({ ctx, input }) => {
      const where: Prisma.UserWhereInput = {};
      if (input.email) {
        where.email = { contains: input.email, mode: 'insensitive' };
      }
      if (input.teamIds && input.teamIds.length > 0) {
        where.teams = {
          some: {
            teamId: { in: input.teamIds },
          },
        };
      }

      const total = await ctx.prisma.user.count({ where });

      const data = await ctx.prisma.user.findMany({
        where,
        include: { teams: { include: { team: true } } },
        orderBy: [{ createdAt: 'desc' }, { id: 'desc' }],
        take: input.limit,
        skip: input.offset,
      });

      return { data, total, limit: input.limit, offset: input.offset };
    }),
  update: adminProcedure
    .input(
      z.object({
        userId: z.string(),
        email: z.string().email().optional(),
        teamIds: z.array(z.string()).min(1),
      }),
    )
    .mutation(async ({ ctx, input }) => {
      try {
        return await ctx.prisma.$transaction(async (tx) => {
          const dataToUpdate: {
            email?: string;
          } = {};
          if (input.email !== undefined) dataToUpdate.email = input.email;

          // Update basic user info
          await tx.user.update({
            where: { id: input.userId },
            data: dataToUpdate,
          });

          // Compute diff for UserTeam mappings to avoid hitting trigger locks on unchanged rows
          const existingTeams = await tx.userTeam.findMany({
            where: { userId: input.userId },
          });
          const existingTeamIds = new Set(existingTeams.map((t) => t.teamId));
          const uniqueTeamIds = Array.from(new Set(input.teamIds));
          const newTeamIds = new Set(uniqueTeamIds);

          const toAdd = uniqueTeamIds.filter((id) => !existingTeamIds.has(id));
          const toRemove = Array.from(existingTeamIds).filter(
            (id) => !newTeamIds.has(id),
          );

          // IMPORTANT: Insert new teams before removing old ones so the "must belong to 1 team" trigger passes!
          if (toAdd.length > 0) {
            await tx.userTeam.createMany({
              data: toAdd.map((teamId) => ({
                userId: input.userId,
                teamId,
              })),
            });
          }

          if (toRemove.length > 0) {
            await tx.userTeam.deleteMany({
              where: {
                userId: input.userId,
                teamId: { in: toRemove },
              },
            });
          }

          return { success: true, message: 'User updated successfully' };
        });
      } catch (error: any) {
        const message = error.message || 'Failed to update user';
        if (
          message.includes('Cannot remove the last user from the Admin team')
        ) {
          throw new TRPCError({
            code: 'BAD_REQUEST',
            message:
              'Action blocked: This user is the last remaining global Admin.',
          });
        }
        throw new TRPCError({ code: 'INTERNAL_SERVER_ERROR', message });
      }
    }),
  delete: adminProcedure
    .input(z.object({ userId: z.string() }))
    .mutation(async ({ ctx, input }) => {
      if (ctx.user.userId === input.userId) {
        throw new TRPCError({
          code: 'BAD_REQUEST',
          message: 'Action blocked: You cannot delete your own account.',
        });
      }

      try {
        await ctx.prisma.user.delete({
          where: { id: input.userId },
        });
        return { success: true, message: 'User deleted successfully' };
      } catch (error: any) {
        // Intercept specific Postgres exceptions thrown by trigger functions
        const message = error.message || 'Failed to delete user';

        if (
          message.includes('Cannot remove the last user from the Admin team')
        ) {
          throw new TRPCError({
            code: 'BAD_REQUEST',
            message:
              'Action blocked: This user is the last remaining global Admin.',
          });
        }

        throw new TRPCError({
          code: 'INTERNAL_SERVER_ERROR',
          message,
        });
      }
    }),
});

export const usersFlatRouter = t.router({
  getUserCount: t.procedure.query(async ({ ctx }) => {
    return ctx.prisma.user.count();
  }),
});
