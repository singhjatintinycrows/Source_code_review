import { describe, expect, it } from 'vitest';
import { ROLE_TYPES } from '../helpers/appConstants.js';
import { ServiceAccessRoleSchema } from './servicesRouter.js';

describe('ServiceAccessRoleSchema', () => {
  it('accepts Viewer, Editor, and Manager roles only', () => {
    expect(ServiceAccessRoleSchema.safeParse(ROLE_TYPES.Viewer).success).toBe(
      true,
    );
    expect(ServiceAccessRoleSchema.safeParse(ROLE_TYPES.Editor).success).toBe(
      true,
    );
    expect(ServiceAccessRoleSchema.safeParse(ROLE_TYPES.Manager).success).toBe(
      true,
    );
    expect(ServiceAccessRoleSchema.safeParse(40).success).toBe(false);
  });
});
