import { HP_SERVICE_LIMIT_REFRESH_KEY } from '@hyperprobe/common';
import { TRPCError } from '@trpc/server';
import { z } from 'zod';
import { ROLE_TYPES } from '../helpers/appConstants.js';
import {
  adminProcedure,
  protectedProcedure,
  serviceLeadProcedure,
  t,
} from '../trpc.js';

export const ServiceAccessRoleSchema = z.union([
  z.literal(ROLE_TYPES.Viewer),
  z.literal(ROLE_TYPES.Editor),
  z.literal(ROLE_TYPES.Manager),
]);

export const servicesRouter = t.router({
  create: protectedProcedure
    .input(
      z.object({
        name: z.string(),
        teamIds: z.array(z.string()).min(1),
        language: z.enum(['JAVA', 'NODE', 'PYTHON', 'RUBY']).default('NODE'),
        sourceMapRequired: z.boolean().default(false),
        agentLimit: z.number().int().nonnegative().nullable().optional(),
      }),
    )
    .mutation(async ({ ctx, input }) => {
      const validTeamIds = Array.from(new Set(input.teamIds));
      if (!ctx.user.permissions.isAdmin) {
        const userTeams = await ctx.prisma.userTeam.findMany({
          where: { userId: ctx.user.userId },
        });
        const userTeamIdsSet = new Set(userTeams.map((ut) => ut.teamId));
        const hasUnauthorizedTeam = validTeamIds.some(
          (id) => !userTeamIdsSet.has(id),
        );
        if (hasUnauthorizedTeam) {
          throw new TRPCError({
            code: 'FORBIDDEN',
            message: 'You can only assign a service to teams you belong to.',
          });
        }
      }

      if (input.agentLimit !== undefined) {
        if (!ctx.user.permissions.isAdmin) {
          throw new TRPCError({
            code: 'FORBIDDEN',
            message: 'Only admins can configure agent limit on a service.',
          });
        }
      }

      const agentLimit =
        ctx.user.permissions.isAdmin && input.agentLimit !== undefined
          ? input.agentLimit
          : null;

      const service = await ctx.prisma.$transaction(async (tx) => {
        const service = await tx.service.create({
          data: {
            name: input.name,
            language: input.language,
            sourceMapRequired:
              input.language === 'NODE' ? input.sourceMapRequired : false,
            agentLimit: agentLimit,
          },
        });

        const teamServicesData = validTeamIds.map((teamId) => ({
          serviceId: service.id,
          teamId,
          role: ROLE_TYPES.Manager,
        }));

        await tx.teamService.createMany({
          data: teamServicesData,
        });

        return service;
      });

      if (service.agentLimit !== null) {
        try {
          await ctx.redisClient.publish(
            HP_SERVICE_LIMIT_REFRESH_KEY,
            JSON.stringify({
              serviceId: service.id,
              agentLimit: service.agentLimit,
              action: 'update',
            }),
          );
        } catch (err) {
          ctx.logger.error(
            { err, serviceId: service.id },
            'Failed to publish service agent limit creation update',
          );
        }
      }

      if (ctx.user.permissions.isAdmin) {
        return service;
      }

      return {
        ...service,
        agentLimit: null,
      };
    }),
  list: protectedProcedure.query(async ({ ctx }) => {
    if (ctx.user.permissions.isAdmin) {
      return await ctx.prisma.service.findMany({
        include: { teamServices: { include: { team: true } } },
        orderBy: [{ createdAt: 'desc' }, { id: 'desc' }],
      });
    }

    const userServices = await ctx.prisma.service.findMany({
      where: {
        // 1. Look at the TeamService mapping table
        teamServices: {
          some: {
            // 2. Look at the Team
            team: {
              // 3. Look at the UserTeam mapping table
              users: {
                some: {
                  // 4. Filter by the specific user
                  userId: ctx.user.userId,
                },
              },
            },
          },
        },
      },
      // Only fetch the ID to keep the query lightning fast
      select: {
        id: true,
      },
    });

    if (userServices.length === 0) return [];

    const serviceIds = userServices.map((service) => service.id);

    const services = await ctx.prisma.service.findMany({
      where: {
        id: { in: serviceIds },
      },
      include: { teamServices: { include: { team: true } } },
      orderBy: [{ createdAt: 'desc' }, { id: 'desc' }],
    });

    return services.map((service) => ({
      ...service,
      agentLimit: null,
    }));
  }),
  update: serviceLeadProcedure
    .input(
      z.object({
        serviceId: z.string(),
        name: z.string(),
        sourceMapRequired: z.boolean().optional(),
        agentLimit: z.number().int().nonnegative().nullable().optional(),
      }),
    )
    .mutation(async ({ ctx, input }) => {
      const existingService = await ctx.prisma.service.findUnique({
        where: { id: input.serviceId },
        select: { language: true },
      });

      if (!existingService) {
        throw new TRPCError({
          code: 'NOT_FOUND',
          message: 'Service not found.',
        });
      }

      const dataToUpdate: {
        name: string;
        sourceMapRequired?: boolean;
        agentLimit?: number | null;
      } = { name: input.name };
      if (input.sourceMapRequired !== undefined) {
        dataToUpdate.sourceMapRequired =
          existingService.language === 'NODE' ? input.sourceMapRequired : false;
      }
      if (input.agentLimit !== undefined) {
        if (!ctx.user.permissions.isAdmin) {
          throw new TRPCError({
            code: 'FORBIDDEN',
            message: 'Only admins can configure agent limit on a service.',
          });
        }
        dataToUpdate.agentLimit = input.agentLimit;
      }
      const service = await ctx.prisma.service.update({
        where: { id: input.serviceId },
        data: dataToUpdate,
      });

      if (ctx.user.permissions.isAdmin && input.agentLimit !== undefined) {
        try {
          await ctx.redisClient.publish(
            HP_SERVICE_LIMIT_REFRESH_KEY,
            JSON.stringify({
              serviceId: service.id,
              agentLimit: service.agentLimit,
              action: 'update',
            }),
          );
        } catch (err) {
          ctx.logger.error(
            { err, serviceId: service.id },
            'Failed to publish service agent limit update',
          );
        }
      }

      if (ctx.user.permissions.isAdmin) {
        return service;
      }

      return {
        ...service,
        agentLimit: null,
      };
    }),
  delete: serviceLeadProcedure
    .input(z.object({ serviceId: z.string() }))
    .mutation(async ({ ctx, input }) => {
      await ctx.prisma.service.delete({
        where: { id: input.serviceId },
      });

      try {
        await ctx.redisClient.publish(
          HP_SERVICE_LIMIT_REFRESH_KEY,
          JSON.stringify({
            serviceId: input.serviceId,
            agentLimit: null,
            action: 'delete',
          }),
        );
      } catch (err) {
        ctx.logger.error(
          { err, serviceId: input.serviceId },
          'Failed to publish service agent limit deletion',
        );
      }

      return { success: true };
    }),
  updateAccess: adminProcedure
    .input(
      z.object({
        serviceId: z.string(),
        teamId: z.string(),
        role: ServiceAccessRoleSchema,
      }),
    )
    .mutation(async ({ ctx, input }) => {
      const updated = await ctx.prisma.teamService.upsert({
        where: {
          teamId_serviceId: {
            teamId: input.teamId,
            serviceId: input.serviceId,
          },
        },
        update: { role: input.role },
        create: {
          teamId: input.teamId,
          serviceId: input.serviceId,
          role: input.role,
        },
      });

      return updated;
    }),

  removeAccess: adminProcedure
    .input(z.object({ serviceId: z.string(), teamId: z.string() }))
    .mutation(async ({ ctx, input }) => {
      return ctx.prisma.$transaction(async (tx) => {
        // Orphan Prevention: Check if this would leave the service with 0 teams
        const teamServiceCount = await tx.teamService.count({
          where: { serviceId: input.serviceId },
        });

        if (teamServiceCount === 1) {
          throw new TRPCError({
            code: 'BAD_REQUEST',
            message:
              'Cannot remove this team. A service must have at least one team assigned to it.',
          });
        }

        // Delete the mapping from the TeamService table
        await tx.teamService.delete({
          where: {
            teamId_serviceId: {
              teamId: input.teamId,
              serviceId: input.serviceId,
            },
          },
        });

        return { success: true };
      });
    }),
});

export const servicesFlatRouter = t.router({
  getServiceNames: protectedProcedure
    .input(z.object({ serviceIds: z.array(z.string()).min(1) }))
    .query(async ({ ctx, input }) => {
      let allowedServiceIds = input.serviceIds;
      if (!ctx.user.permissions.isAdmin) {
        allowedServiceIds = input.serviceIds.filter(
          (id) => ctx.user.permissions.permissions[id] !== undefined,
        );
      }

      if (allowedServiceIds.length === 0) return {};

      const services = await ctx.prisma.service.findMany({
        where: { id: { in: allowedServiceIds } },
        select: { id: true, name: true },
      });

      const mapping: Record<string, string> = {};

      // First, default all requested IDs to just be their ID
      for (const id of allowedServiceIds) {
        mapping[id] = id;
      }

      // Then overwrite with the actual name if it exists in the database
      for (const service of services) {
        mapping[service.id] = service.name;
      }

      return mapping;
    }),
});
