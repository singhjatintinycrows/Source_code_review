import * as path from 'node:path';
import { ProbeStatus, ProbeType } from '@hyperprobe/database';
import {
  type SectionedSourceMapInput,
  SourceMapConsumer,
} from '@jridgewell/source-map';
import { TRPCError } from '@trpc/server';
import { z } from 'zod';
import { type Context, protectedProcedure, t } from '../trpc.js';

const baseProbeSchema = z.object({
  serviceId: z.string(),
  environment: z.string(),
  commitSha: z.string(),
  uiFilePath: z.string(),
  uiLineNumber: z.number().int().positive(),
  uiColumnNumber: z.number().int().positive().optional(),
  hitLimit: z.number().int().positive().optional().default(1),
  expiryTime: z.number().int().positive(), // epoch ms
  condition: z.string().optional(),
  maxObjectDepth: z.number().int().nonnegative().optional(),
  maxArrayLength: z.number().int().nonnegative().optional(),
  stackFrameDepth: z.number().int().nonnegative().optional(),
  maxObjectProperties: z.number().int().nonnegative().optional(),
  maxStringLength: z.number().int().nonnegative().optional(),
  shouldCaptureTraceId: z.boolean().default(false),
});

const createProbeInputSchema = z.discriminatedUnion('type', [
  baseProbeSchema.extend({
    type: z.literal(ProbeType.SNAPSHOT),
    watchExpressions: z.array(z.string()).optional().default([]),
    captureClosures: z.boolean().default(false),
  }),
  baseProbeSchema.extend({
    type: z.literal(ProbeType.LOG),
    template: z.string().min(1),
    logLevel: z.enum(['INFO', 'ERROR']).optional().default('INFO'),
    shouldLogToStdout: z.boolean().optional().default(false),
  }),
  baseProbeSchema.extend({
    type: z.literal(ProbeType.COUNTER),
    metricName: z.string().min(1),
  }),
  baseProbeSchema.extend({
    type: z.literal(ProbeType.METRIC),
    metricName: z.string().min(1),
    metricExpression: z.string().min(1),
  }),
  baseProbeSchema.extend({
    type: z.literal(ProbeType.DURATION),
    metricName: z.string().min(1),
    secondaryUiFilePath: z.string(),
    secondaryUiLineNumber: z.number().int().positive(),
    secondaryUiColumnNumber: z.number().int().positive().optional(),
    correlationExpression: z.string().optional(),
  }),
]);

async function resolveCoordinate(
  ctx: Context,
  serviceId: string,
  environment: string,
  commitSha: string,
  uiFilePath: string,
  uiLineNumber: number,
  uiColumnNumber: number,
) {
  let normalizedUiPath = uiFilePath.replace(/\\/g, '/');
  normalizedUiPath = path.posix.normalize(normalizedUiPath);
  if (normalizedUiPath.startsWith('./'))
    normalizedUiPath = normalizedUiPath.substring(2);
  normalizedUiPath = normalizedUiPath.replace(/^(\.\.\/)+/, '');

  const fileMappings = await ctx.prisma.sourceMapFile.findMany({
    where: {
      serviceId,
      environment,
      commitSha,
      resolvedPath: normalizedUiPath,
    },
    include: { sourceMap: { select: { id: true, fileName: true } } },
  });

  if (fileMappings.length === 0) {
    throw new TRPCError({
      code: 'NOT_FOUND',
      message: `Coordinate ${normalizedUiPath} not indexed in commit ${commitSha}`,
    });
  }

  for (const mapping of fileMappings) {
    const smMeta = mapping.sourceMap;
    let consumer = ctx.consumerCache.get(smMeta.id);

    if (!consumer) {
      try {
        const fullSm = await ctx.prisma.sourceMap.findUnique({
          where: { id: smMeta.id },
          select: { content: true },
        });
        if (!fullSm || !fullSm.content) {
          ctx.logger.error(
            { sourceMapId: smMeta.id },
            'Source map content not found',
          );
          continue;
        }
        const rawMap = fullSm.content as SectionedSourceMapInput;
        consumer = new SourceMapConsumer(rawMap);
        ctx.consumerCache.set(smMeta.id, consumer);
      } catch (err) {
        ctx.logger.error(
          { err, sourceMapId: smMeta.id },
          'Failed to parse source map',
        );
        continue;
      }
    }

    type Position = {
      line: number | null;
      column: number | null;
    };

    const actualSource = mapping.rawPath;
    let positions: Position[] = [];
    let resolvedUiLine = uiLineNumber;
    const MAX_FORWARD_OFFSET = 50;

    for (let offset = 0; offset <= MAX_FORWARD_OFFSET; offset++) {
      const lineToTry = uiLineNumber + offset;
      positions = consumer.allGeneratedPositionsFor({
        source: actualSource,
        line: lineToTry,
        column: uiColumnNumber - 1,
      });
      if (positions && positions.length > 0) {
        resolvedUiLine = lineToTry;
        break;
      }
    }

    let pos = null;
    if (positions && positions.length > 0) {
      pos = positions.reduce((prev: Position, curr: Position) => {
        const target = uiColumnNumber - 1;
        return Math.abs((curr.column ?? 0) - target) <
          Math.abs((prev.column ?? 0) - target)
          ? curr
          : prev;
      });
    }

    if (pos && pos.line !== null) {
      let runtimeLoc = smMeta.fileName
        .replace('.js.map', '.js')
        .replace('.map', '');

      const isMeteor = mapping.rawPath.startsWith('meteor://');

      if (isMeteor) {
        const parts = runtimeLoc.split('/');
        const packageIdx = parts.lastIndexOf('packages');
        if (packageIdx !== -1) {
          runtimeLoc = `meteor://💻app/${parts.slice(packageIdx).join('/')}`;
        } else {
          const appIdx = parts.lastIndexOf('app');
          if (appIdx !== -1 && appIdx < parts.length - 1) {
            runtimeLoc = `meteor://💻app/app/${parts.slice(appIdx + 1).join('/')}`;
          } else {
            runtimeLoc = `meteor://💻app/app/${parts[parts.length - 1]}`;
          }
        }
      } else {
        if (runtimeLoc.startsWith('./')) {
          runtimeLoc = runtimeLoc.substring(2);
        }
      }

      return {
        runtimeLocation: runtimeLoc,
        runtimeLine: pos.line,
        runtimeColumn: (pos.column || 0) + 1,
        resolvedUiLine,
      };
    }
  }

  throw new TRPCError({
    code: 'NOT_FOUND',
    message: `Could not resolve coordinate for ${uiFilePath}:${uiLineNumber} in commit ${commitSha}`,
  });
}

async function getListProbesWhereClause(
  ctx: Context,
  serviceIds: string[],
  sourceSearchTags?: string[],
  status?: ProbeStatus,
) {
  let allowedServiceIds = serviceIds;
  if (!ctx?.user?.permissions.isAdmin) {
    allowedServiceIds = serviceIds.filter(
      (id) => ctx?.user?.permissions.permissions[id] !== undefined,
    );
  }

  if (allowedServiceIds.length === 0) {
    return { hasAllowedServices: false, whereClause: {} };
  }

  const dynamicWhereClause: Record<string, string> = {};
  const serviceNames: string[] = [];
  const sourceTags = sourceSearchTags ?? [];

  for (const sourceSearch of sourceTags) {
    if (sourceSearch.includes(':')) {
      const [key, value] = sourceSearch.split(':');
      const sourceKey = key.trim();
      const sourceValue = value.trim();

      if (sourceKey === 'environment' || sourceKey === 'env') {
        dynamicWhereClause.environment = sourceValue;
      }
      if (sourceKey === 'commitSha' || sourceKey === 'commit') {
        dynamicWhereClause.commitSha = sourceValue;
      }
      if (sourceKey === 'serviceName') {
        serviceNames.push(sourceValue);
      }
    }
  }

  let serviceIdsToFilter = allowedServiceIds;
  if (serviceNames.length > 0) {
    const services = await ctx.prisma.service.findMany({
      where: {
        name: { in: serviceNames },
        id: { in: allowedServiceIds },
      },
      select: {
        id: true,
      },
    });
    serviceIdsToFilter = services.map((s) => s.id);
  }

  const whereClause = {
    serviceId: { in: serviceIdsToFilter },
    status: status ? status : undefined,
    ...dynamicWhereClause,
  };

  return { hasAllowedServices: true, whereClause };
}

export const probesRouter = t.router({
  createProbe: protectedProcedure
    .input(createProbeInputSchema)
    .mutation(async ({ ctx, input }) => {
      const { environment, commitSha, expiryTime, ...rest } = input;

      if (
        !ctx.user.permissions.isAdmin &&
        ctx.user.permissions.permissions[input.serviceId] === undefined
      ) {
        throw new TRPCError({
          code: 'FORBIDDEN',
          message: 'You do not have access to this service',
        });
      }

      const service = await ctx.prisma.service.findUnique({
        where: { id: input.serviceId },
      });
      if (!service)
        throw new TRPCError({
          code: 'NOT_FOUND',
          message: 'Service not found',
        });

      let runtimeLocation = input.uiFilePath;
      let runtimeLine = input.uiLineNumber;
      let runtimeColumn = input.uiColumnNumber || 1;

      if (service.sourceMapRequired) {
        const loc = await resolveCoordinate(
          ctx,
          input.serviceId,
          environment,
          commitSha,
          input.uiFilePath,
          input.uiLineNumber,
          input.uiColumnNumber || 1,
        );
        runtimeLocation = loc.runtimeLocation;
        runtimeLine = loc.runtimeLine;
        runtimeColumn = loc.runtimeColumn;
      }

      let secondaryRuntimeLocation =
        'secondaryUiFilePath' in input ? input.secondaryUiFilePath : undefined;
      let secondaryRuntimeLine =
        'secondaryUiLineNumber' in input
          ? input.secondaryUiLineNumber
          : undefined;
      let secondaryRuntimeColumn =
        'secondaryUiColumnNumber' in input
          ? input.secondaryUiColumnNumber
          : undefined;

      if (
        service.sourceMapRequired &&
        'secondaryUiFilePath' in input &&
        input.secondaryUiFilePath &&
        input.secondaryUiLineNumber
      ) {
        const secLoc = await resolveCoordinate(
          ctx,
          input.serviceId,
          environment,
          commitSha,
          input.secondaryUiFilePath,
          input.secondaryUiLineNumber,
          input.secondaryUiColumnNumber || 1,
        );
        secondaryRuntimeLocation = secLoc.runtimeLocation;
        secondaryRuntimeLine = secLoc.runtimeLine;
        secondaryRuntimeColumn = secLoc.runtimeColumn;
      }

      const data = {
        ...rest,
        environment,
        commitSha,
        expiryTime: BigInt(expiryTime),
        status: ProbeStatus.ACTIVE,
        createdBy: ctx.user.email,
        runtimeLocation,
        runtimeLine,
        runtimeColumn,
        // Always provide a default empty array for non-SNAPSHOT probes to satisfy Prisma's String[] requirement
        watchExpressions:
          'watchExpressions' in input ? input.watchExpressions : [],
        logLevel:
          'logLevel' in input && input.logLevel
            ? input.logLevel?.trim()
            : undefined,
        shouldLogToStdout:
          'shouldLogToStdout' in input ? input.shouldLogToStdout : false,
        secondaryRuntimeLocation,
        secondaryRuntimeLine,
        secondaryRuntimeColumn,
      };

      const probe = await ctx.prisma.probe.create({ data: data });

      // Initialize Redis state
      const now = Date.now();
      const ttlSeconds =
        Math.max(Math.ceil((expiryTime - now) / 1000), 0) + 130 * 60; // 130 min buffer

      const multi = ctx.redisClient.multi();
      multi.set(`probe:limit:${probe.id}`, data.hitLimit.toString(), {
        EX: ttlSeconds,
      });
      multi.set(`probe:hits:${probe.id}`, '0', { EX: ttlSeconds });
      multi.set(`probe:latest-hit:${probe.id}`, '-1', { EX: ttlSeconds });
      await multi.exec();

      return { success: true, id: probe.id };
    }),
  deleteProbes: protectedProcedure
    .input(z.object({ ids: z.array(z.string()).min(1) }))
    .mutation(async ({ ctx, input }) => {
      // First verify access to the probes' services
      if (!ctx.user.permissions.isAdmin) {
        const probes = await ctx.prisma.probe.findMany({
          where: { id: { in: input.ids } },
          select: { serviceId: true },
        });

        for (const probe of probes) {
          if (ctx.user.permissions.permissions[probe.serviceId] === undefined) {
            throw new TRPCError({
              code: 'FORBIDDEN',
              message: 'You do not have access to some of the requested probes',
            });
          }
        }
      }

      // 1. Delete from Postgres (Cascade will handle SnapshotEvent, LogEvent, MetricEvent)
      await ctx.prisma.probe.deleteMany({
        where: { id: { in: input.ids } },
      });

      // 2. Clean up Redis state
      const multi = ctx.redisClient.multi();
      for (const id of input.ids) {
        multi.del(`probe:limit:${id}`);
        multi.del(`probe:hits:${id}`);
        multi.del(`probe:latest-hit:${id}`);
      }
      await multi.exec();

      return { success: true, count: input.ids.length };
    }),
  toggleProbeStatus: protectedProcedure
    .input(
      z.object({
        id: z.string(),
        status: z
          .nativeEnum(ProbeStatus)
          .refine(
            (status) =>
              status === ProbeStatus.ACTIVE || status === ProbeStatus.INACTIVE,
            { message: 'Can only toggle between ACTIVE and INACTIVE' },
          ),
      }),
    )
    .mutation(async ({ ctx, input }) => {
      const probe = await ctx.prisma.probe.findUnique({
        where: { id: input.id },
      });
      if (!probe)
        throw new TRPCError({ code: 'NOT_FOUND', message: 'Probe not found' });

      if (
        !ctx.user.permissions.isAdmin &&
        ctx.user.permissions.permissions[probe.serviceId] === undefined
      ) {
        throw new TRPCError({
          code: 'FORBIDDEN',
          message: 'You do not have access to this probe',
        });
      }

      if (
        probe.status !== ProbeStatus.ACTIVE &&
        probe.status !== ProbeStatus.INACTIVE
      ) {
        throw new TRPCError({
          code: 'PRECONDITION_FAILED',
          message: `Cannot change status of a ${probe.status} probe`,
        });
      }

      if (probe.expiryTime <= BigInt(Date.now())) {
        throw new TRPCError({
          code: 'PRECONDITION_FAILED',
          message: 'Cannot toggle the status of an expired probe.',
        });
      }

      await ctx.prisma.probe.update({
        where: { id: input.id },
        data: { status: input.status },
      });
      return { success: true, id: input.id, status: input.status };
    }),
  listSnapshots: protectedProcedure
    .input(z.object({ probeId: z.string() }))
    .query(async ({ ctx, input }) => {
      return ctx.prisma.snapshotEvent.findMany({
        where: {
          probeId: input.probeId,
          serviceId: ctx.user.permissions.isAdmin
            ? undefined
            : {
                in: Object.keys(ctx.user.permissions.permissions),
              },
        },
        select: { id: true, capturedAt: true, payload: true, traceId: true },
        // include: { probe: true },
        orderBy: { capturedAt: 'desc' },
      });
    }),
  listLogs: protectedProcedure
    .input(z.object({ probeId: z.string() }))
    .query(async ({ ctx, input }) => {
      return ctx.prisma.logEvent.findMany({
        where: {
          probeId: input.probeId,
          serviceId: ctx.user.permissions.isAdmin
            ? undefined
            : {
                in: Object.keys(ctx.user.permissions.permissions),
              },
        },
        select: { id: true, message: true, capturedAt: true, traceId: true },
        // include: { probe: true },
        orderBy: { capturedAt: 'desc' },
      });
    }),
  listProbes: protectedProcedure
    .input(
      z.object({
        serviceIds: z.array(z.string()).min(1),
        sourceSearchTags: z.array(z.string()).optional(),
        status: z.nativeEnum(ProbeStatus).optional(),
        sortBy: z
          .enum(['createdAt', 'uiFilePath'])
          .optional()
          .default('createdAt'),
        offset: z.number().int().min(0).optional().default(0),
        limit: z.number().int().positive().max(200).optional().default(10),
      }),
    )
    .query(async ({ ctx, input }) => {
      const { hasAllowedServices, whereClause } =
        await getListProbesWhereClause(
          ctx,
          input.serviceIds,
          input.sourceSearchTags,
          input.status,
        );
      if (!hasAllowedServices) return [];

      const sortBy = input.sortBy || 'createdAt';
      const sortOrder = input.sortBy === 'uiFilePath' ? 'asc' : 'desc';

      const probes = await ctx.prisma.probe.findMany({
        where: whereClause,
        orderBy: {
          [sortBy]: sortOrder,
        },
        skip: input.offset,
        take: input.limit,
      });

      const nowBigInt = BigInt(Date.now());

      const activeProbes = probes.filter(
        (p) =>
          (p.status === ProbeStatus.ACTIVE ||
            p.status === ProbeStatus.INACTIVE) &&
          p.expiryTime > nowBigInt,
      );
      const multi = ctx.redisClient.multi();

      for (const probe of activeProbes) {
        multi.get(`probe:hits:${probe.id}`);
        multi.get(`probe:latest-hit:${probe.id}`);
        multi.get(`probe:live:${probe.id}`);
      }
      const redisResults = await multi.exec();

      let activeIndex = 0;
      const enhancedProbes = probes.map((probe) => {
        const isExpired = probe.expiryTime <= nowBigInt;

        if (
          (probe.status !== ProbeStatus.ACTIVE &&
            probe.status !== ProbeStatus.INACTIVE) ||
          isExpired
        ) {
          // Completed or expired probes don't need live Redis stats
          if (
            isExpired &&
            (probe.status === ProbeStatus.ACTIVE ||
              probe.status === ProbeStatus.INACTIVE)
          ) {
            probe.status = ProbeStatus.EXPIRED;
          }
          return {
            ...probe,
            latestHitAt: probe.createdAt.toISOString(),
            isLive: false,
          };
        }

        // Only active/inactive unexpired probes reach here, so indexing is perfectly aligned
        const hitCountStr = redisResults[activeIndex * 3] as unknown as
          | string
          | null;
        const latestHitAtStr = redisResults[activeIndex * 3 + 1] as unknown as
          | string
          | null;
        const liveStr = redisResults[activeIndex * 3 + 2] as unknown as
          | string
          | null;
        activeIndex++;

        const hitCount = hitCountStr
          ? parseInt(hitCountStr, 10)
          : probe.hitCount;
        const latestHitAt =
          latestHitAtStr && latestHitAtStr !== '-1'
            ? latestHitAtStr
            : probe.createdAt.toISOString();

        const isLive = liveStr === '1';

        return {
          ...probe,
          hitCount,
          latestHitAt,
          isLive,
        };
      });

      return enhancedProbes;
    }),
  getProbesCount: protectedProcedure
    .input(
      z.object({
        serviceIds: z.array(z.string()).min(1),
        sourceSearchTags: z.array(z.string()).optional(),
        status: z.nativeEnum(ProbeStatus).optional(),
      }),
    )
    .query(async ({ ctx, input }) => {
      const { hasAllowedServices, whereClause } =
        await getListProbesWhereClause(
          ctx,
          input.serviceIds,
          input.sourceSearchTags,
          input.status,
        );
      if (!hasAllowedServices) return 0;

      const totalProbes = await ctx.prisma.probe.count({
        where: whereClause,
      });

      return totalProbes;
    }),
  // TODO: potentially deprecated
  resolveRuntimeLocation: t.procedure
    .input(
      z.object({
        serviceId: z.string(),
        environment: z.string(),
        commitSha: z.string(),
        uiFilePath: z.string(),
        uiLineNumber: z.number().int().positive(),
        uiColumnNumber: z.number().int().positive().optional().default(1),
      }),
    )
    .query(async ({ ctx, input }) => {
      const {
        serviceId,
        environment,
        commitSha,
        uiFilePath,
        uiLineNumber,
        uiColumnNumber,
      } = input;
      return resolveCoordinate(
        ctx,
        serviceId,
        environment,
        commitSha,
        uiFilePath,
        uiLineNumber,
        uiColumnNumber,
      );
    }),
});
