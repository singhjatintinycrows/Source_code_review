import { getConsul, getLogger } from '@hyperprobe/common';
import type { User } from '@hyperprobe/database';
import { TRPCError } from '@trpc/server';
import crypto from 'crypto';
import COMMON_EMAIL_DOMAINS from 'free-email-domains';
import jwt from 'jsonwebtoken';
import { z } from 'zod';
import { decryptEmailToken } from '../helpers/decryptSsoToken.js';
import { getPermissionsObj } from '../helpers/getPermissionsObj.js';
import { getTokenSecret } from '../helpers/tokenSecret.js';
import { adminProcedure, authProcedure, t } from '../trpc.js';

let cachedSelfServe: { value: boolean; expiresAt: number } | null = null;

async function getIsSelfServeEnabled(
  consul: ReturnType<typeof getConsul>,
): Promise<boolean> {
  const now = Date.now();
  if (
    process.env.HYPERPROBE_ENV !== 'e2e' &&
    cachedSelfServe &&
    cachedSelfServe.expiresAt > now
  ) {
    return cachedSelfServe.value;
  }
  try {
    const selfServeItem: any = await consul.kv.get('HP_SELF_SERVE_ENABLED');
    const value = !!(
      selfServeItem && selfServeItem.Value?.toLowerCase().trim() === 'yes'
    );
    cachedSelfServe = { value, expiresAt: now + 60 * 1000 }; // Cache for 1 minute
    return value;
  } catch (err) {
    getLogger().warn(
      { err },
      'Failed to fetch HP_SELF_SERVE_ENABLED from Consul',
    );
    // Graceful degradation: Fall back to last known cached state during a Consul network outage
    return cachedSelfServe ? cachedSelfServe.value : false;
  }
}

export const authRouter = t.router({
  verifySso: t.procedure
    .input(
      z.object({
        token: z.string(),
        identifier: z.string().optional(),
      }),
    )
    .mutation(async ({ ctx, input }) => {
      let payload: string;
      let email: string;
      if (!input.token) {
        throw new TRPCError({
          code: 'UNAUTHORIZED',
          message: 'Invalid or expired SSO token',
        });
      }
      try {
        if (
          process.env.NODE_ENV !== 'production' &&
          process.env.HYPERPROBE_ENV === 'e2e' &&
          input.token.trim().startsWith('{')
        ) {
          payload = input.token;
        } else {
          payload = decryptEmailToken(input.token);
        }
        const { email: emailValue, ts: timestamp } = JSON.parse(payload);
        email =
          typeof emailValue === 'string' ? emailValue.toLowerCase().trim() : ''; // verifying the expiry window with token creation time(tolerance of 60s)
        const tolerance = 1 * 60 * 1000;
        const numTimestamp = Number(timestamp);
        if (
          Number.isNaN(numTimestamp) ||
          Math.abs(Date.now() - numTimestamp) > tolerance
        ) {
          throw new TRPCError({
            code: 'BAD_REQUEST',
            message: 'Access token has expired or is invalid.',
          });
        }
      } catch (err) {
        if (err instanceof TRPCError) {
          throw err;
        }
        throw new TRPCError({
          code: 'UNAUTHORIZED',
          message: 'Invalid or expired SSO token',
        });
      }

      if (!email) {
        throw new TRPCError({
          code: 'BAD_REQUEST',
          message: 'Email missing in token payload',
        });
      }

      const userCount = await ctx.prisma.user.count();
      const teamCount = await ctx.prisma.team.count({
        where: { isAdminTeam: true },
      });

      let user: User | null = null;

      if (userCount === 0 && teamCount === 0) {
        // First user flow
        user = await ctx.prisma.$transaction(async (tx) => {
          const adminTeam = await tx.team.create({
            data: {
              name: 'Admin',
              isAdminTeam: true,
            },
          });

          const newUser = await tx.user.create({
            data: {
              email,
            },
          });

          await tx.userTeam.create({
            data: {
              userId: newUser.id,
              teamId: adminTeam.id,
            },
          });

          return newUser;
        });
      } else if (userCount === 0) {
        user = await ctx.prisma.$transaction(async (tx) => {
          const adminTeam = await tx.team.findFirst({
            where: {
              isAdminTeam: true,
            },
          });

          if (!adminTeam) {
            throw new TRPCError({
              code: 'NOT_FOUND',
              message: 'Admin team not found',
            });
          }

          const newUser = await tx.user.create({
            data: {
              email,
            },
          });

          await tx.userTeam.create({
            data: {
              userId: newUser.id,
              teamId: adminTeam.id,
            },
          });

          return newUser;
        });
      } else {
        // Standard flow
        user = await ctx.prisma.user.findUnique({
          where: { email },
        });

        if (!user) {
          // Check Consul toggle for self-serve auto team & user creation
          const consul = getConsul();
          const isSelfServeEnabled = await getIsSelfServeEnabled(consul);

          if (isSelfServeEnabled) {
            const domainMatch = email.match(/@([^@]+)$/); // @gmail.com -> ['@gmail.com', 'gmail.com'] | "john.doe@work"@acme.com -> ["@acme.com", "acme.com"]
            const domain = domainMatch
              ? domainMatch[1].toLowerCase().trim()
              : null;
            if (!domain) {
              throw new TRPCError({
                code: 'BAD_REQUEST',
                message: 'Invalid email address in token payload',
              });
            }

            const isBlocked = COMMON_EMAIL_DOMAINS.some(
              (blocked) => domain === blocked || domain.endsWith(`.${blocked}`),
            );
            if (isBlocked) {
              throw new TRPCError({
                code: 'FORBIDDEN',
                message:
                  'Self-serve is not available for common email providers. Please sign up using your organization email address.',
              });
            }

            // Find or create the team outside the transaction
            const existingTeam = await ctx.prisma.team.findFirst({
              where: {
                name: {
                  equals: domain,
                  mode: 'insensitive',
                },
              },
            });

            if (existingTeam?.isAdminTeam) {
              throw new TRPCError({
                code: 'FORBIDDEN',
                message:
                  'Registration is not permitted under administrative domains.',
              });
            }

            const team =
              existingTeam ||
              (await ctx.prisma.team.create({
                data: {
                  name: domain,
                  isAdminTeam: false,
                },
              }));

            // In the transaction, just add the user and assign them to the found team
            user = await ctx.prisma.$transaction(async (tx) => {
              const newUser = await tx.user.create({
                data: { email },
              });

              await tx.userTeam.create({
                data: {
                  userId: newUser.id,
                  teamId: team.id,
                },
              });

              return newUser;
            });
          } else {
            throw new TRPCError({
              code: 'FORBIDDEN',
              message:
                'Please ask your Admin for permission to login to the Hyper Probe dashboard.',
            });
          }
        }
      }
      if (!user) {
        throw new TRPCError({
          code: 'INTERNAL_SERVER_ERROR',
          message: 'User could not be successfully loaded or created.',
        });
      }
      // Generate a new application JWT for the logged-in user
      const fullUser = await ctx.prisma.user.findUnique({
        where: { id: user.id },
        include: {
          teams: {
            include: {
              team: {
                include: { services: true },
              },
            },
          },
        },
      });

      if (!fullUser) {
        throw new TRPCError({
          code: 'INTERNAL_SERVER_ERROR',
          message: 'Failed to retrieve user details',
        });
      }

      const userPermissions = getPermissionsObj(fullUser);

      const secret = getTokenSecret();

      const accessToken = jwt.sign(
        {
          userId: user.id,
          email: user.email,
          permissions: userPermissions,
        },
        secret,
        { expiresIn: '15m' },
      );

      // Generate Stateless Refresh Token
      const refreshToken = jwt.sign(
        { userId: user.id, userSecret: user.sessionSecret },
        secret,
        { expiresIn: '60d' },
      );

      // Web flow
      if (input.identifier) {
        await ctx.redisClient.set(
          `login:${input.identifier}`,
          JSON.stringify({ accessToken, refreshToken }),
          { EX: 120 }, // 2 min expiry
        );
        return {
          success: true,
          message: 'Return to VSCode',
          accessToken,
          refreshToken,
        };
      }
      return { success: true, accessToken, refreshToken };
    }),
  pollLogin: t.procedure
    .input(z.object({ identifier: z.string() }))
    .query(async ({ ctx, input }) => {
      const dataStr = await ctx.redisClient.get(`login:${input.identifier}`);
      if (!dataStr) {
        return { status: 'pending' };
      }
      const tokens = JSON.parse(dataStr) as {
        accessToken: string;
        refreshToken: string;
      };
      await ctx.redisClient.del(`login:${input.identifier}`);
      return {
        status: 'success',
        accessToken: tokens.accessToken,
        refreshToken: tokens.refreshToken,
      };
    }),
  authorizeVsc: authProcedure
    .input(z.object({ identifier: z.string() }))
    .mutation(async ({ ctx, input }) => {
      const user = await ctx.prisma.user.findUnique({
        where: { id: ctx.user.userId },
        include: {
          teams: {
            include: {
              team: {
                include: { services: true },
              },
            },
          },
        },
      });

      if (!user) {
        throw new TRPCError({
          code: 'UNAUTHORIZED',
          message: 'User not found',
        });
      }

      const userPermissions = getPermissionsObj(user);

      const secret = getTokenSecret();

      const accessToken = jwt.sign(
        {
          userId: user.id,
          email: user.email,
          permissions: userPermissions,
        },
        secret,
        { expiresIn: '15m' },
      );

      const refreshToken = jwt.sign(
        { userId: user.id, userSecret: user.sessionSecret },
        secret,
        { expiresIn: '60d' },
      );

      await ctx.redisClient.set(
        `login:${input.identifier}`,
        JSON.stringify({ accessToken, refreshToken }),
        { EX: 120 }, // 2 min expiry
      );
      return { success: true };
    }),
  refresh: t.procedure
    .input(z.object({ refreshToken: z.string() }))
    .mutation(async ({ ctx, input }) => {
      const token = input.refreshToken;
      if (!token) {
        throw new TRPCError({
          code: 'UNAUTHORIZED',
          message: 'No refresh token provided',
        });
      }

      const secret = getTokenSecret();
      let decoded: jwt.JwtPayload;
      try {
        decoded = jwt.verify(token, secret) as jwt.JwtPayload;
      } catch (_err) {
        throw new TRPCError({
          code: 'UNAUTHORIZED',
          message: 'Invalid or expired refresh token',
        });
      }

      const user = await ctx.prisma.user.findUnique({
        where: { id: decoded.userId },
        include: {
          teams: {
            include: {
              team: {
                include: { services: true },
              },
            },
          },
        },
      });

      if (!user) {
        throw new TRPCError({
          code: 'UNAUTHORIZED',
          message: 'User not found',
        });
      }

      // Token version validation logic
      if (user.sessionSecret !== decoded.userSecret) {
        throw new TRPCError({
          code: 'UNAUTHORIZED',
          message: 'Session expired or revoked',
        });
      }

      const userPermissions = getPermissionsObj(user);

      const newAccessToken = jwt.sign(
        {
          userId: user.id,
          email: user.email,
          permissions: userPermissions,
        },
        secret,
        { expiresIn: '15m' },
      );

      const newRefreshToken = jwt.sign(
        { userId: user.id, userSecret: user.sessionSecret },
        secret,
        { expiresIn: '60d' },
      );

      return { accessToken: newAccessToken, refreshToken: newRefreshToken };
    }),
  refreshAuthToken: t.procedure
    .input(z.object({ refreshToken: z.string() }))
    .mutation(async ({ ctx, input }) => {
      const token = input.refreshToken;
      if (!token) {
        throw new TRPCError({
          code: 'UNAUTHORIZED',
          message: 'No refresh token provided',
        });
      }

      const secret = getTokenSecret();
      let decoded: jwt.JwtPayload;
      try {
        decoded = jwt.verify(token, secret) as jwt.JwtPayload;
      } catch (_err) {
        throw new TRPCError({
          code: 'UNAUTHORIZED',
          message: 'Invalid or expired refresh token',
        });
      }

      const user = await ctx.prisma.user.findUnique({
        where: { id: decoded.userId },
        include: {
          teams: {
            include: {
              team: {
                include: { services: true },
              },
            },
          },
        },
      });

      if (!user) {
        throw new TRPCError({
          code: 'UNAUTHORIZED',
          message: 'User not found',
        });
      }

      // Token version validation logic
      if (user.sessionSecret !== decoded.userSecret) {
        throw new TRPCError({
          code: 'UNAUTHORIZED',
          message: 'Session expired or revoked',
        });
      }

      const userPermissions = getPermissionsObj(user);

      const refreshTokenValidity = decoded.exp
        ? decoded.exp - Math.floor(Date.now() / 1000)
        : 0;

      if (refreshTokenValidity <= 0) {
        throw new TRPCError({
          code: 'UNAUTHORIZED',
          message: 'Session or refresh token has expired',
        });
      }

      const newAccessToken = jwt.sign(
        {
          userId: user.id,
          email: user.email,
          permissions: userPermissions,
        },
        secret,
        {
          expiresIn:
            refreshTokenValidity < 15 * 60 ? refreshTokenValidity : '15m',
        },
      );

      return { accessToken: newAccessToken };
    }),
  revokeUserSessionSecret: adminProcedure
    .input(z.object({ userId: z.string() }))
    .mutation(async ({ ctx, input }) => {
      await ctx.prisma.user.update({
        where: { id: input.userId },
        data: { sessionSecret: crypto.randomUUID() },
      });
      return { success: true };
    }),
  me: authProcedure.query(async ({ ctx }) => {
    const user = await ctx.prisma.user.findUnique({
      where: { id: ctx.user.userId },
      include: {
        teams: {
          include: {
            team: true,
          },
        },
      },
    });
    return {
      ...ctx.user,
      teams: user?.teams.map((t) => t.team.name) || [],
    };
  }),
});
