import {
  type AgentInfo,
  HP_GLOBAL_ACTIVE_AGENTS_KEY,
  HP_LICENSE_SYNC_STATUS,
  LicenseManager,
  stableStringify,
} from '@hyperprobe/common';
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import type { Context } from '../trpc.js';
import { agentsRouter } from './agentsRouter.js';

const agent: AgentInfo = {
  agentId: 'agent-a',
  serviceId: 'service-a',
  environment: 'production',
  commitSha: 'commit-a',
  sdkVersion: '1.2.28',
};

function fixture(members: string[], metadata: Array<string | null> = []) {
  const multi = {
    zRemRangeByScore: vi.fn(),
    zRange: vi.fn(),
    zCard: vi.fn(),
    exec: vi.fn().mockResolvedValue([0, members]),
  };
  const redisClient = {
    multi: vi.fn(() => multi),
    mGet: vi.fn().mockResolvedValue(metadata),
  };
  const caller = agentsRouter.createCaller({
    redisClient,
    user: {
      userId: 'user-a',
      email: 'user@example.test',
      permissions: { isAdmin: false, permissions: { [agent.serviceId]: 10 } },
    },
  } as unknown as Context);
  return { caller, multi, redisClient };
}

beforeEach(() => {
  vi.spyOn(LicenseManager.getInstance(), 'getStatus').mockReturnValue(
    HP_LICENSE_SYNC_STATUS.SYNCED,
  );
});

afterEach(() => {
  vi.restoreAllMocks();
});

describe('listActiveAgents compatibility', () => {
  it.each([
    '1.2.28',
    undefined,
  ])('reads master JSON with sdkVersion %s without sidecars', async (sdkVersion) => {
    const info = { ...agent, sdkVersion };
    const { caller, multi, redisClient } = fixture([stableStringify(info)!]);
    const now = Date.now();
    vi.spyOn(Date, 'now').mockReturnValue(now);

    expect(await caller.listActiveAgents({})).toEqual([info]);
    expect(multi.zRemRangeByScore).toHaveBeenCalledWith(
      `active_agents:${agent.serviceId}`,
      '-inf',
      now - 100000,
    );
    expect(multi.zRange).toHaveBeenCalledWith(
      `active_agents:${agent.serviceId}`,
      0,
      -1,
    );
    expect(redisClient.mGet).not.toHaveBeenCalled();
  });

  it('reads transient raw-ID metadata including the SDK version', async () => {
    const { caller, redisClient } = fixture(
      [agent.agentId],
      [JSON.stringify(agent)],
    );

    expect(await caller.listActiveAgents({})).toEqual([agent]);
    expect(redisClient.mGet).toHaveBeenCalledWith([
      `active_agent_info:${agent.serviceId}:${agent.agentId}`,
    ]);
  });

  it.each([
    false,
    true,
  ])('prefers JSON over stale sidecars (raw first: %s)', async (rawFirst) => {
    const members = [stableStringify(agent)!, agent.agentId];
    const { caller } = fixture(rawFirst ? members.reverse() : members, [
      JSON.stringify({
        ...agent,
        environment: 'stale-environment',
        commitSha: 'stale-commit',
        sdkVersion: '1.0.0',
      }),
    ]);

    expect(await caller.listActiveAgents({})).toEqual([agent]);
  });

  it.each([
    ['missing', null],
    ['malformed', '{bad-json'],
    ['null', 'null'],
    ['missing identity', '{}'],
    ['wrong agent', JSON.stringify({ ...agent, agentId: 'another-agent' })],
    [
      'wrong service',
      JSON.stringify({ ...agent, serviceId: 'another-service' }),
    ],
  ])('uses the raw member identity for %s metadata', async (_name, value) => {
    const { caller } = fixture([agent.agentId], [value]);

    expect(await caller.listActiveAgents({})).toEqual([
      {
        agentId: agent.agentId,
        serviceId: agent.serviceId,
        environment: 'unknown',
        commitSha: '',
      },
    ]);
  });

  it('ignores malformed JSON without hiding valid legacy members', async () => {
    const { caller, redisClient } = fixture([
      '{bad-json',
      '{}',
      stableStringify(agent)!,
    ]);

    expect(await caller.listActiveAgents({})).toEqual([agent]);
    expect(redisClient.mGet).not.toHaveBeenCalled();
  });

  it('does not read services outside the caller permissions', async () => {
    const { caller, redisClient } = fixture([stableStringify(agent)!]);

    expect(
      await caller.listActiveAgents({ serviceIds: ['another-service'] }),
    ).toEqual([]);
    expect(redisClient.multi).not.toHaveBeenCalled();
    expect(redisClient.mGet).not.toHaveBeenCalled();
  });
});

it('keeps the global active-agent count on the unchanged ID set', async () => {
  const { caller, multi } = fixture([]);
  multi.exec.mockResolvedValue([0, 2]);

  expect(await caller.getActiveAgentsCount()).toEqual({ count: 2 });
  expect(multi.zRemRangeByScore).toHaveBeenCalledWith(
    HP_GLOBAL_ACTIVE_AGENTS_KEY,
    '-inf',
    expect.any(Number),
  );
  expect(multi.zCard).toHaveBeenCalledWith(HP_GLOBAL_ACTIVE_AGENTS_KEY);
});
