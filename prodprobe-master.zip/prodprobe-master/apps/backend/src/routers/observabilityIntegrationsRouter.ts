import { randomUUID } from 'node:crypto';
import { stableStringify } from '@hyperprobe/common';
import { Prisma } from '@hyperprobe/database';
import { TRPCError } from '@trpc/server';
import { z } from 'zod';
import {
  OBSERVABILITY_SIGNALS,
  type StoredCapabilityBinding,
  type StoredObservabilityConnection,
} from '../observability/contracts.js';
import { CredentialCipherError } from '../observability/credentialCipher.js';
import {
  ProviderError,
  providerErrorToTrpcError,
} from '../observability/errors.js';
import { observabilityProviderRegistry } from '../observability/registry.js';
import {
  type Context,
  protectedProcedure,
  serviceLeadProcedure,
  t,
} from '../trpc.js';
import { testObservabilityConnection } from './rcaRouter.js';

const DEFAULT_SENTRY_API_BASE_URL = 'https://sentry.io/api/0/';

const IdentifierSchema = z
  .string()
  .min(1)
  .max(128)
  .refine((value) => value.trim().length > 0, 'Must not be blank');
const ProviderSchema = z
  .string()
  .min(1)
  .max(64)
  .regex(/^[A-Za-z][A-Za-z0-9_-]*$/)
  .transform((value) => value.toUpperCase());
const ApiBaseUrlSchema = z.string().url().max(2_048);
const AuthTokenSchema = z
  .string()
  .min(1)
  .max(8_192)
  .refine(
    (value) => !/\p{Cc}/u.test(value),
    'Token contains control characters',
  );

const SentryConfigSchema = z
  .object({
    orgSlug: z.string().regex(/^[A-Za-z0-9][A-Za-z0-9_-]{0,127}$/),
    projectId: z
      .string()
      .regex(/^\d{1,32}$/)
      .optional(),
    projectSlug: z
      .string()
      .regex(/^[A-Za-z0-9][A-Za-z0-9_-]{0,127}$/)
      .optional(),
  })
  .strict()
  .refine(
    (value) => Boolean(value.projectId || value.projectSlug),
    'Project ID is required.',
  );

const UpsertConnectionInputSchema = z
  .object({
    serviceId: IdentifierSchema,
    connectionId: IdentifierSchema.optional(),
    name: IdentifierSchema,
    provider: ProviderSchema,
    publicConfig: z.record(z.unknown()).optional(),
    configVersion: z.number().int().positive().max(1_000).default(1),
    // Retained as a request compatibility shim. Only publicConfig is persisted.
    apiBaseUrl: ApiBaseUrlSchema.optional(),
    config: SentryConfigSchema.optional(),
    authToken: AuthTokenSchema.optional(),
  })
  .strict();

const CapabilityConnectionInputSchema = z
  .object({
    signal: z.enum(OBSERVABILITY_SIGNALS),
    connectionId: IdentifierSchema.nullable(),
  })
  .strict();
const SetCapabilityConnectionsInputSchema = z
  .object({
    serviceId: IdentifierSchema,
    capabilities: z
      .array(CapabilityConnectionInputSchema)
      .length(OBSERVABILITY_SIGNALS.length),
  })
  .strict()
  .refine(
    (value) =>
      new Set(value.capabilities.map((capability) => capability.signal))
        .size === OBSERVABILITY_SIGNALS.length,
    'Every observability capability must be selected exactly once.',
  );
const LegacyCapabilityBindingInputSchema = z
  .object({
    signal: z.enum(OBSERVABILITY_SIGNALS),
    connectionId: IdentifierSchema.nullable(),
    selectorKey: z.enum(['environment', 'default']).default('default'),
    scopeSelector: z.record(z.unknown()).default({}),
    priority: z.number().int().min(-1_000).max(1_000).default(0),
    enabled: z.boolean().default(true),
  })
  .strict();
const LegacySetCapabilityBindingsInputSchema = z
  .object({
    serviceId: IdentifierSchema,
    bindings: z.array(LegacyCapabilityBindingInputSchema).max(50),
  })
  .strict();
const LegacyActivateConnectionForRcaInputSchema = z
  .object({
    serviceId: IdentifierSchema,
    connectionId: IdentifierSchema,
  })
  .strict();

type ObservabilityStore = {
  observabilityConnection: {
    findMany(args: unknown): Promise<StoredObservabilityConnection[]>;
    findFirst(args: unknown): Promise<StoredObservabilityConnection | null>;
    create(args: unknown): Promise<StoredObservabilityConnection>;
    update(args: unknown): Promise<StoredObservabilityConnection>;
    delete(args: unknown): Promise<StoredObservabilityConnection>;
  };
  observabilityCapabilityBinding: {
    findMany(args: unknown): Promise<StoredCapabilityBinding[]>;
    deleteMany(args: unknown): Promise<unknown>;
    create(args: unknown): Promise<StoredCapabilityBinding>;
  };
  $executeRawUnsafe(query: string, ...values: unknown[]): Promise<number>;
  $transaction<T>(
    callback: (transaction: ObservabilityStore) => Promise<T>,
  ): Promise<T>;
};

function observabilityStore(ctx: Context): ObservabilityStore {
  return ctx.prisma as unknown as ObservabilityStore;
}

function legacySentryPublicConfig(input: {
  apiBaseUrl?: string;
  config?: z.infer<typeof SentryConfigSchema>;
}): Record<string, unknown> | undefined {
  if (!input.config) return undefined;
  return {
    apiBaseUrl: input.apiBaseUrl ?? DEFAULT_SENTRY_API_BASE_URL,
    orgSlug: input.config.orgSlug,
    ...(input.config.projectId ? { projectId: input.config.projectId } : {}),
    ...(input.config.projectSlug
      ? { projectSlug: input.config.projectSlug }
      : {}),
  };
}

function connectionConfigForInput(
  input: z.infer<typeof UpsertConnectionInputSchema>,
) {
  const publicConfig = input.publicConfig ?? legacySentryPublicConfig(input);
  if (!publicConfig) {
    throw new TRPCError({
      code: 'BAD_REQUEST',
      message: 'publicConfig is required for this observability provider.',
    });
  }
  return observabilityProviderRegistry
    .require(input.provider)
    .validateConnectionConfig(publicConfig);
}

function publicConnection(connection: StoredObservabilityConnection) {
  const adapter = observabilityProviderRegistry.get(connection.provider);
  const config = connection.publicConfig;
  const sentryConfig =
    connection.provider === 'SENTRY' &&
    typeof config === 'object' &&
    config !== null &&
    !Array.isArray(config)
      ? (config as Record<string, unknown>)
      : undefined;
  return {
    id: connection.id,
    serviceId: connection.serviceId,
    name: connection.name,
    provider: connection.provider,
    publicConfig: connection.publicConfig,
    configVersion: connection.configVersion,
    credentialFormat: connection.credentialFormat,
    enabled: connection.enabled ?? true,
    supportedSignals: adapter?.supportedSignals ?? [],
    credentialsEncryptedInDatabase: true,
    createdAt: connection.createdAt,
    updatedAt: connection.updatedAt,
    ...(sentryConfig
      ? {
          apiBaseUrl: sentryConfig.apiBaseUrl,
          config: {
            orgSlug: sentryConfig.orgSlug,
            projectSlug: sentryConfig.projectSlug,
            ...(typeof sentryConfig.projectId === 'string'
              ? { projectId: sentryConfig.projectId }
              : {}),
          },
        }
      : {}),
  };
}

function capabilityConnectionsResponse(
  bindings: readonly StoredCapabilityBinding[],
) {
  return OBSERVABILITY_SIGNALS.map((signal) => {
    const binding = bindings.find((candidate) => candidate.signal === signal);
    return {
      signal,
      connectionId: binding?.connectionId ?? null,
      ...(binding
        ? {
            connection: {
              id: binding.connection.id,
              name: binding.connection.name,
              provider: binding.connection.provider,
              enabled: binding.connection.enabled !== false,
            },
          }
        : {}),
    };
  });
}

function legacyCapabilityBindingsResponse(
  bindings: readonly StoredCapabilityBinding[],
) {
  return OBSERVABILITY_SIGNALS.map((signal) => {
    const binding = bindings.find((candidate) => candidate.signal === signal);
    return {
      signal,
      enabled: Boolean(binding),
      ...(binding
        ? {
            connectionId: binding.connectionId,
            connection: {
              id: binding.connection.id,
              name: binding.connection.name,
              provider: binding.connection.provider,
            },
          }
        : {}),
      bindings: binding
        ? [
            {
              id: binding.id,
              connectionId: binding.connectionId,
              selectorKey: 'default',
              scopeSelector: {},
              priority: 0,
              enabled: true,
              connection: {
                id: binding.connection.id,
                name: binding.connection.name,
                provider: binding.connection.provider,
              },
            },
          ]
        : [],
    };
  });
}

export function asTrpcError(error: unknown): TRPCError {
  if (error instanceof TRPCError) return error;
  if (error instanceof ProviderError) return providerErrorToTrpcError(error);
  if (error instanceof CredentialCipherError) {
    return new TRPCError({
      code: 'PRECONDITION_FAILED',
      message: error.message,
      cause: error,
    });
  }
  if (
    (error instanceof Prisma.PrismaClientKnownRequestError &&
      error.code === 'P2002') ||
    (typeof error === 'object' &&
      error !== null &&
      'code' in error &&
      (error as { code: unknown }).code === 'P2002')
  ) {
    return new TRPCError({
      code: 'CONFLICT',
      message:
        'An observability connection with this name already exists for this service.',
      cause: error,
    });
  }
  return new TRPCError({
    code: 'INTERNAL_SERVER_ERROR',
    message: 'The observability integration request could not be completed.',
    cause: error,
  });
}

async function requireServiceAccess(
  ctx: Context,
  serviceId: string,
): Promise<void> {
  if (
    !ctx.user?.permissions.isAdmin &&
    ctx.user?.permissions.permissions[serviceId] === undefined
  ) {
    throw new TRPCError({
      code: 'FORBIDDEN',
      message: 'You do not have access to this service.',
    });
  }
  const service = await ctx.prisma.service.findUnique({
    where: { id: serviceId },
    select: { id: true },
  });
  if (!service) {
    throw new TRPCError({ code: 'NOT_FOUND', message: 'Service not found.' });
  }
}

async function requireCredentialCipher(ctx: Context) {
  if (!ctx.credentialCipher) {
    throw new TRPCError({
      code: 'PRECONDITION_FAILED',
      message:
        'Credential encryption must be configured before adding an observability connection.',
    });
  }
  if (await ctx.credentialEncryptionMaintenanceActive()) {
    throw new TRPCError({
      code: 'PRECONDITION_FAILED',
      message:
        'Credential encryption maintenance is in progress. Try again after it completes.',
    });
  }
  return ctx.credentialCipher;
}

async function lockServiceObservability(
  store: ObservabilityStore,
  serviceId: string,
) {
  await store.$executeRawUnsafe(
    'SELECT pg_advisory_xact_lock(hashtextextended($1::text, 0::bigint))',
    serviceId,
  );
}

function assertConnectionSupportsCapability(
  connection: StoredObservabilityConnection | undefined,
  signal: (typeof OBSERVABILITY_SIGNALS)[number],
  allowDisabled: boolean,
) {
  if (!connection) {
    throw new TRPCError({
      code: 'BAD_REQUEST',
      message: 'A selected connection does not belong to this service.',
    });
  }
  if (connection.enabled === false && !allowDisabled) {
    throw new TRPCError({
      code: 'PRECONDITION_FAILED',
      message: `${connection.name} is disabled. Enable it before assigning capabilities.`,
    });
  }
  if (
    !observabilityProviderRegistry
      .require(connection.provider)
      .supportedSignals.includes(signal)
  ) {
    throw new TRPCError({
      code: 'BAD_REQUEST',
      message: `${connection.name} does not provide ${signal}.`,
    });
  }
}

export async function setCapabilityConnections(
  ctx: Context,
  input: z.infer<typeof SetCapabilityConnectionsInputSchema>,
) {
  await requireServiceAccess(ctx, input.serviceId);
  const store = observabilityStore(ctx);
  const connectionIds = input.capabilities.flatMap((capability) =>
    capability.connectionId ? [capability.connectionId] : [],
  );

  await store.$transaction(async (transaction) => {
    await lockServiceObservability(transaction, input.serviceId);
    const existingBindings =
      await transaction.observabilityCapabilityBinding.findMany({
        where: { serviceId: input.serviceId },
        include: { connection: true },
      });
    const existingConnectionBySignal = new Map(
      existingBindings.map((binding) => [binding.signal, binding.connectionId]),
    );
    const connections = await transaction.observabilityConnection.findMany({
      where: { serviceId: input.serviceId, id: { in: connectionIds } },
    });
    const connectionById = new Map(
      connections.map((connection) => [connection.id, connection]),
    );
    for (const capability of input.capabilities) {
      if (!capability.connectionId) continue;
      assertConnectionSupportsCapability(
        connectionById.get(capability.connectionId),
        capability.signal,
        existingConnectionBySignal.get(capability.signal) ===
          capability.connectionId,
      );
    }

    await transaction.observabilityCapabilityBinding.deleteMany({
      where: { serviceId: input.serviceId },
    });
    for (const capability of input.capabilities) {
      if (!capability.connectionId) continue;
      await transaction.observabilityCapabilityBinding.create({
        data: {
          id: randomUUID(),
          serviceId: input.serviceId,
          signal: capability.signal,
          connectionId: capability.connectionId,
        },
      });
    }
  });

  const bindings = await store.observabilityCapabilityBinding.findMany({
    where: { serviceId: input.serviceId },
    include: { connection: true },
  });
  return capabilityConnectionsResponse(bindings);
}

export function capabilityConnectionsFromLegacyBindings(
  bindings: readonly z.infer<typeof LegacyCapabilityBindingInputSchema>[],
) {
  const connectionBySignal = new Map<
    (typeof OBSERVABILITY_SIGNALS)[number],
    string | null
  >();
  const coveredSignals = new Set<(typeof OBSERVABILITY_SIGNALS)[number]>();
  const activeSignals = new Set<(typeof OBSERVABILITY_SIGNALS)[number]>();
  for (const binding of bindings) {
    coveredSignals.add(binding.signal);
    if (!binding.connectionId || !binding.enabled) continue;
    if (
      binding.selectorKey !== 'default' ||
      Object.keys(binding.scopeSelector).length > 0 ||
      binding.priority !== 0
    ) {
      throw new TRPCError({
        code: 'BAD_REQUEST',
        message:
          'Advanced routing is no longer supported. Refresh the dashboard and choose one connection per capability.',
      });
    }
    if (activeSignals.has(binding.signal)) {
      throw new TRPCError({
        code: 'BAD_REQUEST',
        message: 'Refresh the dashboard before saving capability choices.',
      });
    }
    activeSignals.add(binding.signal);
    connectionBySignal.set(binding.signal, binding.connectionId);
  }
  if (coveredSignals.size !== OBSERVABILITY_SIGNALS.length) {
    throw new TRPCError({
      code: 'BAD_REQUEST',
      message: 'Refresh the dashboard before saving capability choices.',
    });
  }
  return OBSERVABILITY_SIGNALS.map((signal) => ({
    signal,
    connectionId: connectionBySignal.get(signal) ?? null,
  }));
}

async function activateLegacyConnectionForRca(
  ctx: Context,
  input: z.infer<typeof LegacyActivateConnectionForRcaInputSchema>,
) {
  await requireServiceAccess(ctx, input.serviceId);
  const store = observabilityStore(ctx);
  await store.$transaction(async (transaction) => {
    await lockServiceObservability(transaction, input.serviceId);
    const existingBindings =
      await transaction.observabilityCapabilityBinding.findMany({
        where: { serviceId: input.serviceId },
        take: 1,
      });
    if (existingBindings.length > 0) {
      throw new TRPCError({
        code: 'CONFLICT',
        message:
          'Capability routing is already configured for this service. Refresh the dashboard to change it.',
      });
    }
    const connection = await transaction.observabilityConnection.findFirst({
      where: { id: input.connectionId, serviceId: input.serviceId },
    });
    if (!connection) {
      throw new TRPCError({
        code: 'NOT_FOUND',
        message: 'Observability connection not found.',
      });
    }
    if (connection.enabled === false) {
      throw new TRPCError({
        code: 'PRECONDITION_FAILED',
        message: 'Enable this connection before using it for RCA.',
      });
    }
    for (const signal of observabilityProviderRegistry.require(
      connection.provider,
    ).supportedSignals) {
      await transaction.observabilityCapabilityBinding.create({
        data: {
          id: randomUUID(),
          serviceId: input.serviceId,
          signal,
          connectionId: connection.id,
        },
      });
    }
  });
  const bindings = await store.observabilityCapabilityBinding.findMany({
    where: { serviceId: input.serviceId },
    include: { connection: true },
  });
  return legacyCapabilityBindingsResponse(bindings);
}

function samePublicConfig(left: unknown, right: unknown) {
  return stableStringify(left) === stableStringify(right);
}

async function refreshConnectionForTest(
  ctx: Context,
  input: { serviceId: string; connectionId: string },
) {
  await requireServiceAccess(ctx, input.serviceId);
  const credentialCipher = await requireCredentialCipher(ctx);
  const store = observabilityStore(ctx);
  const snapshot = await store.observabilityConnection.findFirst({
    where: { id: input.connectionId, serviceId: input.serviceId },
  });
  if (!snapshot) {
    throw new TRPCError({
      code: 'NOT_FOUND',
      message: 'Observability connection not found.',
    });
  }
  if (snapshot.enabled === false) {
    throw new TRPCError({
      code: 'PRECONDITION_FAILED',
      message: 'Observability connection is disabled.',
    });
  }
  const adapter = observabilityProviderRegistry.require(snapshot.provider);
  const publicConfig = await adapter.resolveConnectionConfig(
    adapter.validateConnectionConfig(snapshot.publicConfig),
    credentialCipher.decrypt(
      {
        serviceId: snapshot.serviceId,
        connectionId: snapshot.id,
        provider: snapshot.provider,
        credentialFormat: snapshot.credentialFormat,
      },
      snapshot,
    ),
  );
  return store.$transaction(async (transaction) => {
    await lockServiceObservability(transaction, input.serviceId);
    const connection = await transaction.observabilityConnection.findFirst({
      where: { id: input.connectionId, serviceId: input.serviceId },
    });
    if (!connection) {
      throw new TRPCError({
        code: 'NOT_FOUND',
        message: 'Observability connection not found.',
      });
    }
    if (connection.enabled === false) {
      throw new TRPCError({
        code: 'PRECONDITION_FAILED',
        message: 'Observability connection is disabled.',
      });
    }
    if (connection.updatedAt.getTime() !== snapshot.updatedAt.getTime()) {
      throw new TRPCError({
        code: 'CONFLICT',
        message:
          'Observability connection changed while it was being tested. Try again.',
      });
    }
    if (samePublicConfig(publicConfig, connection.publicConfig)) {
      return connection;
    }
    return transaction.observabilityConnection.update({
      where: { id: connection.id },
      data: { publicConfig },
    });
  });
}

export const observabilityIntegrationsRouter = t.router({
  listProviders: protectedProcedure.query(() => {
    return observabilityProviderRegistry.metadata();
  }),

  listConnections: protectedProcedure
    .input(z.object({ serviceId: IdentifierSchema }).strict())
    .query(async ({ ctx, input }) => {
      await requireServiceAccess(ctx, input.serviceId);
      const connections = await observabilityStore(
        ctx,
      ).observabilityConnection.findMany({
        where: { serviceId: input.serviceId },
        orderBy: { name: 'asc' },
      });
      return connections.map(publicConnection);
    }),

  listCapabilityConnections: protectedProcedure
    .input(z.object({ serviceId: IdentifierSchema }).strict())
    .query(async ({ ctx, input }) => {
      await requireServiceAccess(ctx, input.serviceId);
      const bindings = await observabilityStore(
        ctx,
      ).observabilityCapabilityBinding.findMany({
        where: { serviceId: input.serviceId },
        include: { connection: true },
      });
      return capabilityConnectionsResponse(bindings);
    }),

  setCapabilityConnections: serviceLeadProcedure
    .input(SetCapabilityConnectionsInputSchema)
    .mutation(async ({ ctx, input }) => {
      try {
        return await setCapabilityConnections(ctx, input);
      } catch (error) {
        throw asTrpcError(error);
      }
    }),

  // Cached dashboards retain these procedures until their static assets refresh.
  listCapabilityBindings: protectedProcedure
    .input(z.object({ serviceId: IdentifierSchema }).strict())
    .query(async ({ ctx, input }) => {
      await requireServiceAccess(ctx, input.serviceId);
      const bindings = await observabilityStore(
        ctx,
      ).observabilityCapabilityBinding.findMany({
        where: { serviceId: input.serviceId },
        include: { connection: true },
      });
      return legacyCapabilityBindingsResponse(bindings);
    }),

  setCapabilityBindings: serviceLeadProcedure
    .input(LegacySetCapabilityBindingsInputSchema)
    .mutation(async ({ ctx, input }) => {
      try {
        await setCapabilityConnections(ctx, {
          serviceId: input.serviceId,
          capabilities: capabilityConnectionsFromLegacyBindings(input.bindings),
        });
        const bindings = await observabilityStore(
          ctx,
        ).observabilityCapabilityBinding.findMany({
          where: { serviceId: input.serviceId },
          include: { connection: true },
        });
        return legacyCapabilityBindingsResponse(bindings);
      } catch (error) {
        throw asTrpcError(error);
      }
    }),

  activateConnectionForRca: serviceLeadProcedure
    .input(LegacyActivateConnectionForRcaInputSchema)
    .mutation(async ({ ctx, input }) => {
      try {
        return await activateLegacyConnectionForRca(ctx, input);
      } catch (error) {
        throw asTrpcError(error);
      }
    }),

  upsertConnection: serviceLeadProcedure
    .input(UpsertConnectionInputSchema)
    .mutation(async ({ ctx, input }) => {
      try {
        await requireServiceAccess(ctx, input.serviceId);
        const credentialCipher = await requireCredentialCipher(ctx);
        const adapter = observabilityProviderRegistry.require(input.provider);
        const connectionConfig = connectionConfigForInput(input);
        const store = observabilityStore(ctx);
        const snapshot = input.connectionId
          ? await store.observabilityConnection.findFirst({
              where: { id: input.connectionId, serviceId: input.serviceId },
            })
          : null;
        if (input.connectionId && !snapshot) {
          throw new TRPCError({
            code: 'NOT_FOUND',
            message: 'Observability connection not found.',
          });
        }
        if (snapshot && snapshot.provider !== input.provider) {
          throw new TRPCError({
            code: 'BAD_REQUEST',
            message: 'A connection provider cannot be changed after creation.',
          });
        }
        if (!snapshot && !input.authToken) {
          throw new TRPCError({
            code: 'BAD_REQUEST',
            message:
              'An authentication token is required for a new connection.',
          });
        }
        const connectionId = snapshot?.id ?? randomUUID();
        const owner = {
          serviceId: input.serviceId,
          connectionId,
          provider: input.provider,
          credentialFormat: adapter.credentialFormat,
        };
        const credentialForConfig =
          input.authToken ??
          (snapshot
            ? credentialCipher.decrypt(
                {
                  serviceId: snapshot.serviceId,
                  connectionId: snapshot.id,
                  provider: snapshot.provider,
                  credentialFormat: snapshot.credentialFormat,
                },
                snapshot,
              )
            : undefined);
        if (!credentialForConfig) {
          throw new TRPCError({
            code: 'PRECONDITION_FAILED',
            message: 'A credential is required to resolve this connection.',
          });
        }
        const publicConfig = await adapter.resolveConnectionConfig(
          connectionConfig,
          credentialForConfig,
        );
        const encryptedCredential = input.authToken
          ? credentialCipher.encrypt(owner, input.authToken)
          : snapshot && credentialCipher.needsRotation(snapshot)
            ? credentialCipher.reencrypt(owner, snapshot)
            : undefined;
        const connection = await store.$transaction(async (transaction) => {
          await lockServiceObservability(transaction, input.serviceId);
          const existing = input.connectionId
            ? await transaction.observabilityConnection.findFirst({
                where: { id: input.connectionId, serviceId: input.serviceId },
              })
            : null;
          if (input.connectionId && !existing) {
            throw new TRPCError({
              code: 'NOT_FOUND',
              message: 'Observability connection not found.',
            });
          }
          if (
            existing &&
            (!snapshot ||
              existing.updatedAt.getTime() !== snapshot.updatedAt.getTime())
          ) {
            throw new TRPCError({
              code: 'CONFLICT',
              message:
                'Observability connection changed while it was being saved. Try again.',
            });
          }
          return existing
            ? transaction.observabilityConnection.update({
                where: { id: connectionId },
                data: {
                  name: input.name.trim(),
                  publicConfig,
                  configVersion: input.configVersion,
                  ...(encryptedCredential ?? {}),
                },
              })
            : transaction.observabilityConnection.create({
                data: {
                  id: connectionId,
                  serviceId: input.serviceId,
                  name: input.name.trim(),
                  provider: input.provider,
                  publicConfig,
                  configVersion: input.configVersion,
                  ...encryptedCredential!,
                  enabled: true,
                  createdBy: ctx.user.userId,
                },
              });
        });
        return publicConnection(connection);
      } catch (error) {
        throw asTrpcError(error);
      }
    }),

  testConnection: serviceLeadProcedure
    .input(
      z
        .object({ serviceId: IdentifierSchema, connectionId: IdentifierSchema })
        .strict(),
    )
    .mutation(async ({ ctx, input }) => {
      try {
        const connection = await refreshConnectionForTest(ctx, input);
        return {
          ...(await testObservabilityConnection(ctx, input)),
          testedConnection: publicConnection(connection),
        };
      } catch (error) {
        throw asTrpcError(error);
      }
    }),

  setConnectionEnabled: serviceLeadProcedure
    .input(
      z
        .object({
          serviceId: IdentifierSchema,
          connectionId: IdentifierSchema,
          enabled: z.boolean(),
        })
        .strict(),
    )
    .mutation(async ({ ctx, input }) => {
      try {
        await requireServiceAccess(ctx, input.serviceId);
        const store = observabilityStore(ctx);
        const updated = await store.$transaction(async (transaction) => {
          await lockServiceObservability(transaction, input.serviceId);
          const connection =
            await transaction.observabilityConnection.findFirst({
              where: { id: input.connectionId, serviceId: input.serviceId },
            });
          if (!connection) {
            throw new TRPCError({
              code: 'NOT_FOUND',
              message: 'Observability connection not found.',
            });
          }
          return transaction.observabilityConnection.update({
            where: { id: connection.id },
            data: { enabled: input.enabled },
          });
        });
        return publicConnection(updated);
      } catch (error) {
        throw asTrpcError(error);
      }
    }),

  deleteConnection: serviceLeadProcedure
    .input(
      z
        .object({ serviceId: IdentifierSchema, connectionId: IdentifierSchema })
        .strict(),
    )
    .mutation(async ({ ctx, input }) => {
      try {
        await requireServiceAccess(ctx, input.serviceId);
        const store = observabilityStore(ctx);
        const connection = await store.$transaction(async (transaction) => {
          await lockServiceObservability(transaction, input.serviceId);
          const existing = await transaction.observabilityConnection.findFirst({
            where: { id: input.connectionId, serviceId: input.serviceId },
          });
          if (!existing) {
            throw new TRPCError({
              code: 'NOT_FOUND',
              message: 'Observability connection not found.',
            });
          }
          return transaction.observabilityConnection.delete({
            where: { id: existing.id },
          });
        });
        return { id: connection.id };
      } catch (error) {
        throw asTrpcError(error);
      }
    }),
});
