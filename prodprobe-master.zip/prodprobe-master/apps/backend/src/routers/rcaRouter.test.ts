import { HP_LICENSE_SYNC_STATUS, LicenseManager } from '@hyperprobe/common';
import { fetchRequestHandler } from '@trpc/server/adapters/fetch';
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import { EvidenceAuditError } from '../observability/audit.js';
import type { StoredObservabilityConnection } from '../observability/contracts.js';
import { ProviderError } from '../observability/errors.js';
import { RECORD_COOLDOWN_SCRIPT } from '../observability/requestCoordinator.js';
import { sentryAdapter } from '../observability/sentryAdapter.js';
import type { Context } from '../trpc.js';
import {
  discoverObservabilityContext,
  downsampleMetricPoints,
  effectiveMetricInterval,
  getObservabilityCapabilities,
  normalizeMetricPoints,
  normalizeTableRows,
  QueryMetricInputSchema,
  QueryTableInputSchema,
  rcaRouter,
  settledSources,
  testObservabilityConnection,
} from './rcaRouter.js';

const connection: StoredObservabilityConnection = {
  id: 'connection-a',
  serviceId: 'service-a',
  name: 'Sentry',
  provider: 'SENTRY',
  publicConfig: {},
  configVersion: 1,
  credentialCiphertext: new Uint8Array([1]),
  credentialNonce: new Uint8Array(12),
  credentialAuthTag: new Uint8Array(16),
  credentialKeyVersion: 'v1',
  credentialFormat: 'SENTRY_AUTH_TOKEN',
  createdAt: new Date(),
  updatedAt: new Date(),
};

function connectionTestContext(
  selectedConnection: StoredObservabilityConnection | null,
  onFindFirst?: (args: unknown) => void,
): Context {
  return {
    user: {
      userId: 'user-a',
      email: 'user@example.test',
      permissions: { isAdmin: true, permissions: {} },
    },
    prisma: {
      service: { findUnique: async () => ({ id: 'service-a' }) },
      observabilityConnection: {
        findFirst: async (args: unknown) => {
          onFindFirst?.(args);
          return selectedConnection;
        },
      },
    },
    credentialEncryptionMaintenanceActive: async () => false,
  } as unknown as Context;
}

function discoveryFixture(connections = [connection]) {
  const configured = connections.map((entry, index) => ({
    ...entry,
    publicConfig: {
      orgSlug: 'acme',
      projectSlug: `payments-${index}`,
      projectId: String(42 + index),
    },
  }));
  const cooldowns = new Map<string, string>();
  const commands = {
    get: vi.fn(async (key: string) => cooldowns.get(key) ?? null),
    eval: vi.fn(
      async (
        script: string,
        options: { keys: string[]; arguments: string[] },
      ) => {
        if (script === RECORD_COOLDOWN_SCRIPT) {
          const key = options.keys[0]!;
          const retryAt = options.arguments[0]!;
          if (!cooldowns.has(key) || cooldowns.get(key)! < retryAt)
            cooldowns.set(key, retryAt);
        }
        return 1;
      },
    ),
  };
  const redis = {
    isReady: true,
    ...commands,
    withAbortSignal: (_signal: AbortSignal) => commands,
  };
  let nextAudit = 0;
  const audit = {
    create: vi.fn(async (_args: { data: Record<string, unknown> }) => ({
      id: `audit-${++nextAudit}`,
    })),
    update: vi.fn(
      async (_args: { where: { id: string }; data: Record<string, unknown> }) =>
        undefined,
    ),
  };
  const fetch = vi.fn(async (_url: URL) => Response.json([]));
  vi.stubGlobal('fetch', fetch);
  const ctx = {
    user: {
      userId: 'user-a',
      email: 'user@example.test',
      permissions: { isAdmin: true, permissions: {} },
    },
    prisma: {
      service: { findUnique: async () => ({ id: 'service-a' }) },
      observabilityConnection: {
        findFirst: async ({
          where,
        }: {
          where: { id: string; serviceId: string };
        }) =>
          configured.find(
            (entry) =>
              entry.id === where.id && entry.serviceId === where.serviceId,
          ) ?? null,
      },
      observabilityCapabilityBinding: {
        findMany: async ({ where }: { where: { signal?: string } }) =>
          configured.map((entry) => ({
            id: `binding-${entry.id}`,
            connectionId: entry.id,
            connection: entry,
            serviceId: entry.serviceId,
            signal: where.signal ?? 'ERRORS',
          })),
      },
      observabilityEvidenceAuditEvent: audit,
    },
    credentialCipher: { decrypt: () => 'test-credential' },
    credentialEncryptionMaintenanceActive: async () => false,
    redisClient: redis,
  } as unknown as Context;
  return { ctx, audit, fetch, redis, cooldowns };
}

afterEach(() => {
  vi.restoreAllMocks();
  vi.unstubAllGlobals();
});

describe('normalizeMetricPoints', () => {
  it('normalizes Sentry numeric metric timestamps without returning provider fields', () => {
    expect(
      normalizeMetricPoints([
        {
          values: [
            {
              timestamp: 1_786_157_400,
              value: 0.25,
              incomplete: false,
              sampleCount: 12,
            },
          ],
          yAxis: 'failure_rate()',
        },
      ]),
    ).toEqual({
      points: [{ timestamp: '2026-08-08T02:50:00.000Z', value: 0.25 }],
      providerPointCount: 1,
      omittedIncompletePointCount: 0,
    });
  });

  it('normalizes Sentry timeseries tuple responses', () => {
    expect(
      normalizeMetricPoints([
        [1786157400, [{ 'count()': 150 }]],
        [1786157460, [{ 'failure_rate()': 0.12 }]],
      ]),
    ).toEqual({
      points: [
        { timestamp: '2026-08-08T02:50:00.000Z', value: 150 },
        { timestamp: '2026-08-08T02:51:00.000Z', value: 0.12 },
      ],
      providerPointCount: 2,
      omittedIncompletePointCount: 0,
    });
  });

  it('omits marked points including null values but preserves complete zeroes and sampling metadata semantics', () => {
    const start = Date.parse('2026-08-08T02:50:00.000Z');
    const result = normalizeMetricPoints([
      {
        values: [
          { timestamp: start, value: 100, incomplete: false },
          { timestamp: start + 60_000, value: 0, incomplete: true },
          {
            timestamp: start + 120_000,
            value: 12,
            incomplete: true,
            incompleteReason: 'INCOMPLETE_BUCKET',
          },
          { timestamp: start + 180_000, value: null, incomplete: true },
          {
            timestamp: start + 240_000,
            value: 0,
            incomplete: false,
            sampleRate: null,
            confidence: null,
          },
          { timestamp: 'invalid', value: 3, incomplete: true },
          { timestamp: start + 300_000, value: null },
        ],
      },
    ]);
    expect(result).toEqual({
      points: [
        { timestamp: new Date(start).toISOString(), value: 100 },
        { timestamp: new Date(start + 240_000).toISOString(), value: 0 },
      ],
      providerPointCount: 4,
      omittedIncompletePointCount: 3,
    });
  });

  it.each([
    false,
    true,
  ])('does not let an incomplete duplicate suppress a complete point (incomplete first=%s)', (incompleteFirst) => {
    const timestamp = '2026-08-08T02:50:00.000Z';
    const complete = { timestamp, value: 7 };
    const incomplete = { ...complete, incomplete: true };
    const pair = incompleteFirst
      ? [incomplete, complete]
      : [complete, incomplete];
    expect(
      normalizeMetricPoints([...pair, complete, { timestamp, value: 8 }]),
    ).toEqual({
      points: [complete, { timestamp, value: 8 }],
      providerPointCount: 2,
      omittedIncompletePointCount: 1,
    });
  });

  it("does not recover measurements from an omitted point's metadata and retains tuple compatibility", () => {
    expect(
      normalizeMetricPoints([
        [1786157400, [{ 'count()': 150 }]],
        [1786157460, [{ 'count()': 0, incomplete: true }]],
        {
          timestamp: 1786157520000,
          value: null,
          incomplete: true,
          incompleteReason: { timestamp: 1786157520000, value: 999 },
        },
      ]),
    ).toEqual({
      points: [{ timestamp: '2026-08-08T02:50:00.000Z', value: 150 }],
      providerPointCount: 2,
      omittedIncompletePointCount: 2,
    });
  });

  it('counts repeated incomplete tuple/object records without suppressing a complete copy', () => {
    const point = { timestamp: '2026-08-08T02:50:00.000Z', value: 7 };
    expect(
      normalizeMetricPoints([
        [1786157400, [{ 'count()': 7, incomplete: true }]],
        { timestamp: 1786157400000, value: 7, incomplete: true },
        point,
      ]),
    ).toEqual({
      points: [point],
      providerPointCount: 1,
      omittedIncompletePointCount: 2,
    });
  });
});

describe('normalizeTableRows', () => {
  it.each([
    [['TypeError'], 'FallbackError', 'TypeError'],
    [['TypeError', ' HttpError '], 'FallbackError', 'TypeError, HttpError'],
    [[null, {}, '', ' TypeError ', 12], 'FallbackError', 'TypeError'],
    [[], 'FallbackError', 'FallbackError'],
    [[null, {}, ' '], 'FallbackError', 'FallbackError'],
    ['TypeError', 'FallbackError', 'TypeError'],
    ['', 'FallbackError', 'FallbackError'],
    [undefined, 'FallbackError', 'FallbackError'],
    [[], undefined, undefined],
  ])('normalizes exception types %j with scalar fallback %s', (primary, fallback, expected) => {
    for (const signal of ['ERRORS', 'LOGS'] as const) {
      const result = normalizeTableRows(signal, [
        {
          id: 'event-1',
          'error.type': primary,
          error_type: fallback,
        },
      ]);
      if (expected === undefined)
        expect(result.rows[0]).not.toHaveProperty('errorType');
      else expect(result.rows[0]).toHaveProperty('errorType', expected);
    }
  });

  it('limits exception chains and applies normal text compaction to their scalar representation', () => {
    const types = Array.from({ length: 50 }, (_, index) => `ErrorType${index}`);
    const bounded = normalizeTableRows('ERRORS', [
      { id: 'event-1', 'error.type': types },
    ]);
    expect(bounded.rows[0]!.errorType).toBe(
      `${types.slice(0, 10).join(', ')}, ...`,
    );
    expect(bounded.delivery.truncatedValueCount).toBe(1);
    const compacted = normalizeTableRows('ERRORS', [
      { 'error.type': ['x'.repeat(1000), ...types] },
    ]);
    expect(String(compacted.rows[0]!.errorType)).toHaveLength(512);
    expect(String(compacted.rows[0]!.errorType)).toMatch(/\.\.\.$/);
    expect(compacted.delivery.truncatedValueCount).toBe(1);
  });

  it('uses canonical fields and bounds long trace descriptions', () => {
    const result = normalizeTableRows('TRACES', [
      {
        id: 'span-1',
        trace: 'a'.repeat(32),
        'span.description': 'x'.repeat(2_000),
        'span.status': 'internal_error',
        unrequestedPayload: { customerEmail: 'secret@example.com' },
      },
    ]);

    expect(result.rows).toHaveLength(1);
    expect(result.rows[0]).toMatchObject({
      id: 'span-1',
      traceId: 'a'.repeat(32),
      status: 'internal_error',
    });
    expect(result.rows[0]).not.toHaveProperty('unrequestedPayload');
    expect(String(result.rows[0]?.message).length).toBeLessThanOrEqual(512);
    expect(result.delivery.truncatedValueCount).toBe(1);
  });

  it.each([
    0, 1, 2,
  ])('redacts only delivered fields with %s characters left in the aggregate budget', (remaining) => {
    const full = 'x'.repeat(512);
    const row = {
      'sentry.item_id': full,
      timestamp: full,
      message: full,
      severity: full,
      'error.type': full,
      trace: full,
      span_id: full,
      request_id: full,
    };
    const result = normalizeTableRows('LOGS', [
      ...Array(3).fill(row),
      { ...row, request_id: full.slice(0, 512 - remaining) },
      { message: 'password=NOT_DELIVERED' },
    ]);
    expect(result.redactionCount).toBe(remaining > 0 ? 1 : 0);
    expect(JSON.stringify(result.rows)).not.toContain('NOT_DELIVERED');
    expect(result.rows).toHaveLength(remaining > 0 ? 5 : 4);
    if (remaining > 0)
      expect(result.rows.at(-1)!.message).toBe('.'.repeat(remaining));
    expect(
      result.rows
        .flatMap(Object.values)
        .reduce((length, value) => length + String(value).length, 0),
    ).toBe(16 * 1024);
  });
});

describe('metric window controls', () => {
  it('coarsens a 24-hour one-minute request to cover the whole window', () => {
    expect(
      effectiveMetricInterval(
        '2026-08-07T00:00:00.000Z',
        '2026-08-08T00:00:00.000Z',
        60,
      ),
    ).toEqual({ intervalSeconds: 300, automaticallyCoarsened: true });
  });

  it.each([
    [359 * 60_000, 60],
    [359 * 60_000 + 1, 120],
    [359 * 120_000, 120],
    [359 * 120_000 + 1, 300],
    [60_000, 60],
  ])('selects a supported bucket at the %s ms window boundary', (duration, intervalSeconds) => {
    const start = Date.parse('2026-08-07T00:00:00.000Z');
    expect(
      effectiveMetricInterval(
        new Date(start).toISOString(),
        new Date(start + duration).toISOString(),
        60,
      ),
    ).toEqual({
      intervalSeconds,
      automaticallyCoarsened: intervalSeconds > 60,
    });
  });

  it.each([
    [60, 60],
    [61, 120],
    [90, 120],
    [120, 120],
    [121, 300],
    [241, 300],
    [300, 300],
    [301, 600],
    [600, 600],
    [601, 900],
    [900, 900],
    [901, 1_800],
    [1_800, 1_800],
    [1_801, 3_600],
    [3_600, 3_600],
  ])('rounds requested interval %s upward to %s', (requested, intervalSeconds) => {
    expect(
      effectiveMetricInterval(
        '2026-08-07T00:00:00.000Z',
        '2026-08-07T02:00:00.000Z',
        requested,
      ),
    ).toEqual({
      intervalSeconds,
      automaticallyCoarsened: intervalSeconds > requested,
    });
  });

  it.each([
    ['2026-08-07T00:00:59.999Z', 60],
    ['2026-08-07T00:04:00.000Z', 241],
    ['2026-08-07T00:04:00.000Z', 300],
  ])('rejects a window ending %s that cannot fit requested bucket %s', (end, interval) => {
    expect(() =>
      effectiveMetricInterval('2026-08-07T00:00:00.000Z', end, interval),
    ).toThrow(expect.objectContaining({ code: 'INVALID_REQUEST' }));
  });

  it('downsamples oversized provider output while preserving both ends of the window', () => {
    const points = Array.from({ length: 500 }, (_, index) => ({
      timestamp: new Date(Date.UTC(2026, 7, 7, 0, index)).toISOString(),
      value: index,
    }));
    const result = downsampleMetricPoints(points);

    expect(result.downsampled).toBe(true);
    expect(result.points).toHaveLength(360);
    expect(result.points[0]).toEqual(points[0]);
    expect(result.points.at(-1)).toEqual(points.at(-1));
  });
});

describe('evidence query input', () => {
  const scope = {
    serviceId: 'service-a',
    environment: 'production',
    timeRange: {
      start: '2026-08-07T00:00:00.000Z',
      end: '2026-08-07T00:05:00.000Z',
    },
  };

  it('requires a nonblank purpose and accepts generic bounded trace IDs', () => {
    expect(
      QueryTableInputSchema.safeParse({
        ...scope,
        purpose: 'Investigate checkout failures',
        traceId: 'w3c:4bf92f3577b34da6a3ce929d0e0e4736-00f067aa0ba902b7-01',
        traceFormat: 'traceparent',
      }).success,
    ).toBe(true);
    expect(QueryTableInputSchema.safeParse(scope).success).toBe(false);
    expect(
      QueryMetricInputSchema.safeParse({ ...scope, purpose: '   ' }).success,
    ).toBe(false);
  });
});

describe('multi-source settlement', () => {
  const sources = [
    { connection: { id: 'a', name: 'source-a', provider: 'SENTRY' } },
    { connection: { id: 'b', name: 'source-b', provider: 'SENTRY' } },
  ] as never;

  it('returns partial results for provider failures but withholds all evidence on audit failure', async () => {
    await expect(
      settledSources(sources, async (_source, index) => {
        if (index === 0) throw new ProviderError('UNAVAILABLE', 'offline');
        return 'evidence';
      }),
    ).resolves.toMatchObject({
      values: ['evidence'],
      warnings: [expect.any(String)],
      failures: [{ connectionId: 'a', code: 'UNAVAILABLE', reason: 'offline' }],
    });

    await expect(
      settledSources(sources, async (_source, index) => {
        if (index === 0) throw new EvidenceAuditError('audit unavailable');
        return 'evidence';
      }),
    ).rejects.toBeInstanceOf(EvidenceAuditError);
  });
});

describe('coordinated and audited discovery', () => {
  const now = Date.parse('2026-09-17T12:00:00.000Z');
  const retryAt = new Date(now + 60_000).toISOString();

  beforeEach(() => {
    vi.spyOn(Date, 'now').mockReturnValue(now);
    vi.spyOn(LicenseManager.getInstance(), 'getStatus').mockReturnValue(
      HP_LICENSE_SYNC_STATUS.SYNCED,
    );
  });

  it('treats empty successful discovery as success, not source failure', async () => {
    const { ctx, fetch, audit } = discoveryFixture();
    const result = await discoverObservabilityContext(ctx, {
      serviceId: 'service-a',
    });
    expect(result.alerts).toEqual({ availability: 'AVAILABLE', values: [] });
    expect(result.failures).toEqual([]);
    expect(result.warnings).toEqual([]);
    expect(fetch).toHaveBeenCalledTimes(4);
    expect(audit.update.mock.calls[0]![0].data).toMatchObject({
      outcome: 'SUCCESS',
      resultCount: 0,
      sourceFailures: 0,
    });
  });

  it('fails and audits all-429 discovery, blocks a repeat, and resumes after the cooldown', async () => {
    const { ctx, fetch, audit, redis } = discoveryFixture();
    fetch.mockImplementation(
      async () =>
        new Response(null, { status: 429, headers: { 'retry-after': '60' } }),
    );

    for (let attempt = 0; attempt < 2; attempt++) {
      await expect(
        discoverObservabilityContext(ctx, { serviceId: 'service-a' }),
      ).rejects.toMatchObject({
        code: 'RATE_LIMITED',
        rateLimit: { retryAt },
      });
    }
    expect(fetch).toHaveBeenCalledTimes(4);
    expect(audit.update.mock.calls.map(([args]) => args.data)).toEqual([
      expect.objectContaining({
        outcome: 'FAILURE',
        sourceFailures: 1,
        resultCount: 0,
      }),
      expect.objectContaining({
        outcome: 'FAILURE',
        sourceFailures: 1,
        resultCount: 0,
      }),
    ]);
    expect(
      redis.eval.mock.calls.filter(
        ([script]) => script === RECORD_COOLDOWN_SCRIPT,
      ),
    ).toHaveLength(1);

    vi.mocked(Date.now).mockReturnValue(now + 60_001);
    fetch.mockImplementation(async () => Response.json([]));
    await expect(
      discoverObservabilityContext(ctx, { serviceId: 'service-a' }),
    ).resolves.toMatchObject({ failures: [] });
    expect(fetch).toHaveBeenCalledTimes(8);
    expect(audit.update.mock.calls.at(-1)![0].data).toMatchObject({
      outcome: 'SUCCESS',
      sourceFailures: 0,
    });
  });

  it('keeps typed rate-limit metadata through the tRPC error formatter', async () => {
    const { ctx, fetch } = discoveryFixture();
    fetch.mockImplementation(
      async () =>
        new Response(null, { status: 429, headers: { 'retry-after': '60' } }),
    );
    const input = encodeURIComponent(
      JSON.stringify({ json: { serviceId: 'service-a' } }),
    );
    const response = await fetchRequestHandler({
      endpoint: '/trpc',
      req: new Request(
        `https://backend.example/trpc/discoverObservabilityContext?input=${input}`,
      ),
      router: rcaRouter,
      createContext: async () => ctx,
    });
    expect(response.status).toBe(429);
    expect(await response.json()).toMatchObject({
      error: { json: { data: { code: 'TOO_MANY_REQUESTS', retryAt } } },
    });
    expect(fetch).toHaveBeenCalledTimes(4);
  });

  it('retains partial 429 metadata and records the longest effective section cooldown once', async () => {
    const { ctx, fetch, audit, redis, cooldowns } = discoveryFixture();
    fetch.mockImplementation(async (url) => {
      if (url.pathname.endsWith('/tags/environment/values/'))
        return Response.json([{ name: 'production' }]);
      const seconds = url.pathname.endsWith('/releases/')
        ? '60'
        : url.pathname.endsWith('/issues/')
          ? '10'
          : undefined;
      return new Response(null, {
        status: 429,
        headers: seconds ? { 'retry-after': seconds } : {},
      });
    });
    const result = await discoverObservabilityContext(ctx, {
      serviceId: 'service-a',
    });
    expect(result.environments).toEqual({
      availability: 'AVAILABLE',
      values: ['production'],
    });
    expect(result.failures).toHaveLength(3);
    expect(JSON.parse(JSON.stringify(result)).failures).toEqual(
      ['alerts', 'releases', 'tags'].map((section) =>
        expect.objectContaining({
          connectionId: 'connection-a',
          section,
          code: 'RATE_LIMITED',
          retryAt,
          reason: expect.any(String),
        }),
      ),
    );
    expect(result.warnings).toHaveLength(3);
    expect(cooldowns.get('observability:cooldown:SENTRY:connection-a')).toBe(
      retryAt,
    );
    expect(
      redis.eval.mock.calls.filter(
        ([script]) => script === RECORD_COOLDOWN_SCRIPT,
      ),
    ).toHaveLength(1);
    expect(audit.update.mock.calls[0]![0].data).toMatchObject({
      outcome: 'PARTIAL',
      sourceFailures: 1,
      resultCount: 1,
    });
    await expect(
      discoverObservabilityContext(ctx, { serviceId: 'service-a' }),
    ).rejects.toMatchObject({ code: 'RATE_LIMITED' });
    expect(fetch).toHaveBeenCalledTimes(4);
  });

  it('preserves failure codes and reasons in partial connection-test summaries', async () => {
    const { ctx, fetch, audit, redis } = discoveryFixture();
    fetch.mockImplementation(async (url) =>
      url.pathname.endsWith('/releases/')
        ? new Response(null, { status: 403 })
        : Response.json([]),
    );
    const result = await testObservabilityConnection(ctx, {
      serviceId: 'service-a',
      connectionId: 'connection-a',
    });
    expect(result.connection).toEqual({ availability: 'AVAILABLE' });
    expect(result.releases).toEqual({
      availability: 'UNAVAILABLE',
      code: 'AUTHENTICATION_FAILED',
      reason: 'Sentry rejected the configured credential.',
    });
    expect(result.failures).toEqual([
      expect.objectContaining({
        section: 'releases',
        code: 'AUTHENTICATION_FAILED',
      }),
    ]);
    expect(audit.update.mock.calls[0]![0].data).toMatchObject({
      outcome: 'PARTIAL',
      sourceFailures: 1,
    });
    expect(
      redis.eval.mock.calls.some(
        ([script]) => script === RECORD_COOLDOWN_SCRIPT,
      ),
    ).toBe(false);
  });

  it.each([
    [401, 'AUTHENTICATION_FAILED'],
    [503, 'UNAVAILABLE'],
  ] as const)('throws typed failure for all-%s discovery and never audits it as success', async (status, code) => {
    const { ctx, fetch, audit } = discoveryFixture();
    fetch.mockImplementation(async () => new Response(null, { status }));
    await expect(
      discoverObservabilityContext(ctx, { serviceId: 'service-a' }),
    ).rejects.toMatchObject({ code });
    expect(audit.update.mock.calls[0]![0].data).toMatchObject({
      outcome: 'FAILURE',
      sourceFailures: 1,
    });
  });

  it('does not hide complementary section failures behind merged availability', async () => {
    const { ctx, fetch, audit } = discoveryFixture([
      connection,
      { ...connection, id: 'connection-b', name: 'Sentry B' },
    ]);
    fetch.mockImplementation(async (url) => {
      if (url.pathname.endsWith('/releases/'))
        return url.searchParams.get('project') === '42'
          ? new Response(null, { status: 403 })
          : Response.json([{ version: 'release-b' }]);
      if (url.pathname.endsWith('/tags/environment/values/'))
        return url.pathname.includes('/projects/acme/43/')
          ? new Response(null, { status: 503 })
          : Response.json([{ name: 'production' }]);
      return Response.json([]);
    });
    const result = await discoverObservabilityContext(ctx, {
      serviceId: 'service-a',
    });
    expect(result.releases).toEqual({
      availability: 'AVAILABLE',
      values: [{ version: 'release-b' }],
    });
    expect(result.environments).toEqual({
      availability: 'AVAILABLE',
      values: ['production'],
    });
    expect(result.failures).toEqual([
      expect.objectContaining({
        connectionId: 'connection-a',
        section: 'releases',
        code: 'AUTHENTICATION_FAILED',
      }),
      expect.objectContaining({
        connectionId: 'connection-b',
        section: 'environments',
        code: 'UNAVAILABLE',
      }),
    ]);
    expect(result.warnings).toHaveLength(2);
    expect(audit.update.mock.calls.map(([args]) => args.data)).toEqual([
      expect.objectContaining({
        outcome: 'PARTIAL',
        resultCount: 1,
        sourceFailures: 1,
      }),
      expect.objectContaining({
        outcome: 'PARTIAL',
        resultCount: 1,
        sourceFailures: 1,
      }),
    ]);
  });

  it('retains a fully failed source alongside another source that succeeded', async () => {
    const { ctx, fetch, audit } = discoveryFixture([
      connection,
      { ...connection, id: 'connection-b', name: 'Sentry B' },
    ]);
    fetch.mockImplementation(async (url) =>
      url.searchParams.get('project') === '42' ||
      url.pathname.includes('/projects/acme/42/')
        ? new Response(null, { status: 429, headers: { 'retry-after': '60' } })
        : Response.json([]),
    );
    const result = await discoverObservabilityContext(ctx, {
      serviceId: 'service-a',
    });
    expect(result.sources.map((source) => source.connectionId)).toEqual([
      'connection-b',
    ]);
    expect(result.failures).toEqual([
      expect.objectContaining({
        connectionId: 'connection-a',
        code: 'RATE_LIMITED',
        retryAt,
      }),
    ]);
    expect(result.warnings).toHaveLength(1);
    expect(audit.update.mock.calls.map(([args]) => args.data)).toEqual(
      expect.arrayContaining([
        expect.objectContaining({ outcome: 'FAILURE', sourceFailures: 1 }),
        expect.objectContaining({ outcome: 'SUCCESS', sourceFailures: 0 }),
      ]),
    );
  });

  it('redacts section failure messages without persisting provider errors or credentials', async () => {
    const { ctx, audit } = discoveryFixture();
    vi.spyOn(sentryAdapter, 'discoverContext').mockResolvedValue({
      alerts: { availability: 'AVAILABLE', values: [] },
      environments: { availability: 'AVAILABLE', values: [] },
      releases: {
        availability: 'UNAVAILABLE',
        code: 'UNAVAILABLE',
        reason: 'Bearer abcdefghijklmnop customer@example.test',
      },
      tags: { availability: 'AVAILABLE', values: [] },
    });
    const result = await discoverObservabilityContext(ctx, {
      serviceId: 'service-a',
    });
    expect(result.failures[0]!.reason).toBe('[REDACTED] [REDACTED]');
    const serialized = JSON.stringify([
      result,
      audit.create.mock.calls,
      audit.update.mock.calls,
    ]);
    expect(serialized).not.toContain('abcdefghijklmnop');
    expect(serialized).not.toContain('customer@example.test');
    expect(serialized).not.toContain('test-credential');
    expect(audit.update.mock.calls[0]![0].data).toMatchObject({
      outcome: 'PARTIAL',
      sourceFailures: 1,
      redactionCount: 4,
    });
  });

  it('does not count evidence redaction as a source failure', async () => {
    const { ctx, fetch, audit } = discoveryFixture();
    fetch.mockImplementation(async (url) =>
      Response.json(
        url.pathname.endsWith('/releases/')
          ? [{ version: 'customer@example.test' }]
          : [],
      ),
    );
    const result = await discoverObservabilityContext(ctx, {
      serviceId: 'service-a',
    });
    expect(result.failures).toEqual([]);
    expect(audit.update.mock.calls[0]![0].data).toMatchObject({
      outcome: 'PARTIAL',
      sourceFailures: 0,
      redactionCount: 1,
    });
  });

  it('does not dispatch provider requests when the audit cannot be started', async () => {
    const { ctx, fetch, audit } = discoveryFixture();
    audit.create.mockRejectedValue(new Error('audit unavailable'));
    await expect(
      discoverObservabilityContext(ctx, { serviceId: 'service-a' }),
    ).rejects.toBeInstanceOf(EvidenceAuditError);
    expect(fetch).not.toHaveBeenCalled();
    expect(audit.update).not.toHaveBeenCalled();
  });

  it.each([
    'complete',
    'partial',
    'failed',
  ])('withholds %s discovery when its audit cannot be completed', async (outcome) => {
    const { ctx, fetch, audit } = discoveryFixture();
    audit.update.mockRejectedValue(new Error('audit unavailable'));
    fetch.mockImplementation(async (url) =>
      outcome === 'failed' ||
      (outcome === 'partial' && url.pathname.endsWith('/releases/'))
        ? new Response(null, { status: 403 })
        : Response.json([]),
    );
    await expect(
      discoverObservabilityContext(ctx, { serviceId: 'service-a' }),
    ).rejects.toBeInstanceOf(EvidenceAuditError);
    expect(fetch).toHaveBeenCalledTimes(4);
    expect(audit.update).toHaveBeenCalledTimes(1);
  });

  it('preserves local-only fallback and failure auditing when Redis is offline', async () => {
    const { ctx, redis, fetch, audit } = discoveryFixture();
    redis.isReady = false;
    fetch.mockImplementation(async () => new Response(null, { status: 429 }));
    for (let attempt = 0; attempt < 2; attempt++) {
      await expect(
        discoverObservabilityContext(ctx, { serviceId: 'service-a' }),
      ).rejects.toMatchObject({ code: 'RATE_LIMITED' });
    }
    expect(fetch).toHaveBeenCalledTimes(8);
    expect(redis.get).not.toHaveBeenCalled();
    expect(redis.eval).not.toHaveBeenCalled();
    expect(
      audit.update.mock.calls.every(
        ([args]) => args.data.outcome === 'FAILURE',
      ),
    ).toBe(true);
  });

  it.each([
    'queryErrors',
    'queryLogs',
  ] as const)('keeps array-shaped provider exception types through %s', async (method) => {
    const { ctx, fetch } = discoveryFixture();
    fetch.mockImplementation(async () =>
      Response.json({
        data: [
          {
            id: 'event-1',
            'sentry.item_id': 'event-1',
            'error.type': ['TypeError', 'HttpError'],
            error_type: 'FallbackError',
          },
        ],
      }),
    );
    const result = await rcaRouter.createCaller(ctx)[method]({
      serviceId: 'service-a',
      environment: 'production',
      purpose: 'Identify exception types',
      timeRange: {
        start: '2026-08-07T00:00:00.000Z',
        end: '2026-08-07T00:05:00.000Z',
      },
    });
    expect(result.rows[0]).toEqual({
      id: 'event-1',
      errorType: 'TypeError, HttpError',
    });
    expect(result.sources[0]!.redactionCount).toBe(0);
  });

  it.each([
    'ERRORS',
    'LOGS',
    'TRACES',
    'ALERTS',
  ] as const)('redacts embedded credentials in %s and audits the replacement once', async (signal) => {
    const { ctx, fetch, audit } = discoveryFixture();
    const text =
      'payload={"password":"PASSWORD_SENTINEL","api_key":"KEY_SENTINEL"}';
    const timestamp = '2026-08-07T00:01:00.000Z';
    const row = {
      id: 'row-1',
      'sentry.item_id': 'row-1',
      timestamp,
      message: text,
      'span.description': text,
      title: text,
      firstSeen: timestamp,
      lastSeen: timestamp,
      unrequestedSecret: 'IGNORED_FIELD',
    };
    fetch.mockImplementation(async () =>
      Response.json(signal === 'ALERTS' ? [row] : { data: [row] }),
    );
    const method = {
      ERRORS: 'queryErrors',
      LOGS: 'queryLogs',
      TRACES: 'queryTraces',
      ALERTS: 'queryAlerts',
    } as const;
    const result = await rcaRouter.createCaller(ctx)[method[signal]]({
      serviceId: 'service-a',
      environment: 'production',
      purpose: 'Verify evidence privacy',
      timeRange: {
        start: '2026-08-07T00:00:00.000Z',
        end: '2026-08-07T00:05:00.000Z',
      },
    });
    expect(result.rows[0]).toHaveProperty(
      signal === 'ALERTS' ? 'title' : 'message',
      '[REDACTED]',
    );
    expect(result.rows[0]).toHaveProperty('id', 'row-1');
    expect(result.sources[0]!.redactionCount).toBe(1);
    expect(audit.update.mock.calls[0]![0].data).toMatchObject({
      outcome: 'PARTIAL',
      redactionCount: 1,
      resultCount: 1,
      sourceFailures: 0,
    });
    const output = JSON.stringify([
      result,
      audit.create.mock.calls,
      audit.update.mock.calls,
    ]);
    for (const secret of ['PASSWORD_SENTINEL', 'KEY_SENTINEL', 'IGNORED_FIELD'])
      expect(output).not.toContain(secret);
  });

  it.each([
    [
      'bearer across the cutoff',
      `${'x'.repeat(497)} Bearer ZXQ987654321SENSITIVE`,
      `${'x'.repeat(497)} [REDACTED]`,
      'ZXQ9',
    ],
    [
      'email across the cutoff',
      `${'x'.repeat(480)} private-user@private-domain.test`,
      `${'x'.repeat(480)} [REDACTED]`,
      'private-user',
    ],
    [
      'key beyond the cutoff',
      `PREFIX_SENTINEL ${'x'.repeat(600)} password=HIDDEN_SENTINEL`,
      '[REDACTED]',
      'PREFIX_SENTINEL',
    ],
    [
      'escaped keyed payload',
      JSON.stringify(JSON.stringify('{"\\u0070assword":"ENCODED_SENTINEL"}')),
      '[REDACTED]',
      'ENCODED_SENTINEL',
    ],
    [
      'quoted Unicode-escaped key',
      String.raw`{"user \"pass\u0077ord\" hint":"QUOTED_SENTINEL"}`,
      '[REDACTED]',
      'QUOTED_SENTINEL',
    ],
    [
      'over inspection limit',
      'x'.repeat(16 * 1024 + 1),
      '[REDACTED]',
      'x'.repeat(512),
    ],
  ])('redacts original log text before compaction: %s', async (_name, text, expected, secret) => {
    const { ctx, fetch, audit } = discoveryFixture();
    fetch.mockImplementation(async () =>
      Response.json({
        data: [{ 'sentry.item_id': 'log-1', message: text }],
      }),
    );
    const result = await rcaRouter.createCaller(ctx).queryLogs({
      serviceId: 'service-a',
      environment: 'production',
      purpose: 'Verify evidence privacy',
      timeRange: {
        start: '2026-08-07T00:00:00.000Z',
        end: '2026-08-07T00:05:00.000Z',
      },
    });
    expect(result.rows[0]).toMatchObject({ id: 'log-1', message: expected });
    expect(result.sources[0]!.redactionCount).toBe(1);
    expect(audit.update.mock.calls[0]![0].data).toMatchObject({
      outcome: 'PARTIAL',
      redactionCount: 1,
      sourceFailures: 0,
    });
    expect(
      JSON.stringify([
        result,
        audit.create.mock.calls,
        audit.update.mock.calls,
      ]),
    ).not.toContain(secret);
  });

  it('does not count unrequested provider fields as evidence redactions', async () => {
    const { ctx, fetch, audit } = discoveryFixture();
    fetch.mockImplementation(async () =>
      Response.json({
        data: [
          {
            'sentry.item_id': 'log-1',
            message: 'Password reset failed',
            password: 'UNREQUESTED_SENTINEL',
          },
        ],
      }),
    );
    const result = await rcaRouter.createCaller(ctx).queryLogs({
      serviceId: 'service-a',
      environment: 'production',
      purpose: 'Verify projection boundaries',
      timeRange: {
        start: '2026-08-07T00:00:00.000Z',
        end: '2026-08-07T00:05:00.000Z',
      },
    });
    expect(result.rows[0]).toEqual({
      id: 'log-1',
      message: 'Password reset failed',
    });
    expect(result.sources[0]!.redactionCount).toBe(0);
    expect(audit.update.mock.calls[0]![0].data).toMatchObject({
      outcome: 'SUCCESS',
      redactionCount: 0,
      sourceFailures: 0,
    });
  });

  it.each([
    '0123456789abcdef',
    undefined,
  ])('preserves the canonical Sentry log span_id %s through projection and normalization', async (spanId) => {
    const { ctx, fetch } = discoveryFixture();
    const timestamp = '2026-08-07T00:01:00.000Z';
    const traceId = 'a'.repeat(32);
    fetch.mockImplementation(async () =>
      Response.json({
        data: [
          {
            'sentry.item_id': 'log-1',
            timestamp,
            message: 'Checkout failed',
            severity: 'error',
            trace: traceId,
            span_id: spanId,
          },
        ],
      }),
    );
    const result = await rcaRouter.createCaller(ctx).queryLogs({
      serviceId: 'service-a',
      environment: 'production',
      purpose: 'Correlate checkout failures',
      timeRange: {
        start: '2026-08-07T00:00:00.000Z',
        end: '2026-08-07T00:05:00.000Z',
      },
    });
    expect(result.rows).toHaveLength(1);
    expect(result.rows[0]).toMatchObject({ id: 'log-1', timestamp, traceId });
    if (spanId) expect(result.rows[0]).toHaveProperty('spanId', spanId);
    else expect(result.rows[0]).not.toHaveProperty('spanId');
    expect(result.rows[0]).not.toHaveProperty('span_id');
    const fields = fetch.mock.calls[0]![0].searchParams.getAll('field');
    expect(fields).toContain('span_id');
    expect(fields).not.toContain('span');
  });

  it('returns filtered alert frequency and timestamps for the selected release', async () => {
    const { ctx, fetch } = discoveryFixture();
    const firstSeen = '2026-08-07T00:02:00.000Z';
    const lastSeen = '2026-08-07T00:03:00.000Z';
    fetch.mockImplementation(async () =>
      Response.json([
        {
          id: 'issue-1',
          title: 'Payment failures',
          count: '101',
          firstSeen: '2026-08-07T00:00:30.000Z',
          lastSeen: '2026-08-07T00:04:30.000Z',
          filtered: { firstSeen, lastSeen, count: '1', userCount: 1 },
        },
      ]),
    );
    const result = await rcaRouter.createCaller(ctx).queryAlerts({
      serviceId: 'service-a',
      environment: 'production',
      release: 'v2',
      purpose: 'Check incident frequency',
      timeRange: {
        start: '2026-08-07T00:00:00.000Z',
        end: '2026-08-07T00:05:00.000Z',
      },
    });
    expect(result.scope.release).toBe('v2');
    expect(result.rows).toEqual([
      {
        id: 'issue-1',
        title: 'Payment failures',
        count: '1',
        firstSeen,
        lastSeen,
      },
    ]);
    expect(fetch.mock.calls[0]![0].searchParams.get('query')).toBe(
      'has:environment release:"v2" is:unresolved',
    );
  });

  it.each([
    ['queryErrors', 'level:error) OR (level:warning'],
    ['queryLogs', 'foo" ) OR (level:warning bar"'],
    ['queryTraces', 'tag:[a) OR (tag:b]'],
    ['queryMetrics', 'level:error) OR (level:warning'],
  ] as const)('rejects scope-escaping filters through %s before provider dispatch', async (method, filter) => {
    const { ctx, fetch, audit } = discoveryFixture();
    await expect(
      rcaRouter.createCaller(ctx)[method]({
        serviceId: 'service-a',
        environment: 'production',
        release: 'v1',
        purpose: 'Check scoped evidence',
        filter,
        ...(method === 'queryMetrics' ? {} : { traceId: 'a'.repeat(32) }),
        timeRange: {
          start: '2026-08-07T00:00:00.000Z',
          end: '2026-08-07T00:05:00.000Z',
        },
      }),
    ).rejects.toMatchObject({
      code: 'BAD_REQUEST',
      cause: { code: 'INVALID_REQUEST' },
    });
    expect(fetch).not.toHaveBeenCalled();
    expect(audit.update.mock.calls[0]![0].data).toMatchObject({
      outcome: 'FAILURE',
      resultCount: 0,
    });
  });

  it('keeps a valid grouped filter under both release and trace constraints', async () => {
    const { ctx, fetch } = discoveryFixture();
    const traceId = 'a'.repeat(32);
    const filter =
      '(level:error OR level:warning) message:"literal ) OR ( text"';
    fetch.mockImplementation(async () => Response.json({ data: [] }));
    await rcaRouter.createCaller(ctx).queryLogs({
      serviceId: 'service-a',
      environment: 'production',
      release: 'v1',
      traceId,
      purpose: 'Check scoped evidence',
      filter,
      timeRange: {
        start: '2026-08-07T00:00:00.000Z',
        end: '2026-08-07T00:05:00.000Z',
      },
    });
    expect(fetch.mock.calls[0]![0].searchParams.get('query')).toBe(
      `release:"v1" trace:"${traceId}" (${filter})`,
    );
  });

  it.each([
    'THROUGHPUT',
    'FAILURE_RATE',
  ] as const)('does not present an incomplete zero as a finalized %s drop', async (metric) => {
    const { ctx, fetch, audit } = discoveryFixture();
    const value = metric === 'THROUGHPUT' ? 100 : 0.25;
    const complete = {
      timestamp: new Date(now - 120_000).toISOString(),
      value,
    };
    fetch.mockImplementation(async () =>
      Response.json({
        timeSeries: [
          {
            values: [
              { timestamp: now - 120_000, value, incomplete: false },
              {
                timestamp: now - 60_000,
                value: 0,
                incomplete: true,
                incompleteReason: 'password=OMITTED_REASON',
              },
            ],
          },
        ],
      }),
    );
    const result = await rcaRouter.createCaller(ctx).queryMetrics({
      serviceId: 'service-a',
      environment: 'production',
      metric,
      purpose: 'Check recent metrics',
      timeRange: {
        start: new Date(now - 300_000).toISOString(),
        end: new Date(now).toISOString(),
      },
    });
    expect(result.points).toEqual([complete]);
    expect(result.sources[0]!.points).toEqual([complete]);
    expect(result.delivery).toMatchObject({
      providerPointCount: 2,
      returnedPointCount: 1,
      omittedIncompletePointCount: 1,
      downsampled: false,
    });
    expect(result.sources[0]).toMatchObject({
      resultCount: 1,
      omittedIncompletePointCount: 1,
    });
    expect(result.warnings).toEqual([
      expect.stringMatching(/incomplete.*not zero/i),
    ]);
    expect(audit.update.mock.calls[0]![0].data).toMatchObject({
      outcome: 'PARTIAL',
      resultCount: 1,
      sourceFailures: 0,
      redactionCount: 0,
    });
    expect(JSON.stringify(result)).not.toContain('OMITTED_REASON');
    expect(JSON.stringify(result)).not.toContain('incompleteReason');
  });

  it.each([
    0,
    null,
  ])('keeps all-incomplete metrics partial when the provisional value is %s', async (value) => {
    const { ctx, fetch, audit } = discoveryFixture();
    fetch.mockImplementation(async () =>
      Response.json({
        timeSeries: [
          { values: [{ timestamp: now - 60_000, value, incomplete: true }] },
        ],
      }),
    );
    const result = await rcaRouter.createCaller(ctx).queryMetrics({
      serviceId: 'service-a',
      environment: 'production',
      purpose: 'Check recent metrics',
      timeRange: {
        start: new Date(now - 300_000).toISOString(),
        end: new Date(now).toISOString(),
      },
    });
    expect(result.points).toEqual([]);
    expect(result.delivery.omittedIncompletePointCount).toBe(1);
    expect(result.warnings).toHaveLength(1);
    expect(audit.update.mock.calls[0]![0].data).toMatchObject({
      outcome: 'PARTIAL',
      resultCount: 0,
      sourceFailures: 0,
    });
  });

  it('keeps genuine empty metric responses complete', async () => {
    const { ctx, fetch, audit } = discoveryFixture();
    fetch.mockImplementation(async () => Response.json({ timeSeries: [] }));
    const result = await rcaRouter.createCaller(ctx).queryMetrics({
      serviceId: 'service-a',
      environment: 'production',
      purpose: 'Check recent metrics',
      timeRange: {
        start: new Date(now - 300_000).toISOString(),
        end: new Date(now).toISOString(),
      },
    });
    expect(result.points).toEqual([]);
    expect(result.delivery.omittedIncompletePointCount).toBe(0);
    expect(result.warnings).toEqual([]);
    expect(audit.update.mock.calls[0]![0].data).toMatchObject({
      outcome: 'SUCCESS',
      resultCount: 0,
      sourceFailures: 0,
    });
  });

  it.each([
    361, 501,
  ])('reports incompleteness before downsampling %s candidates and retains the coarsening warning', async (providerPointCount) => {
    const { ctx, fetch, audit } = discoveryFixture();
    const start = Date.parse('2026-08-07T00:00:00.000Z');
    const values = Array.from({ length: providerPointCount }, (_, index) => ({
      timestamp: start + index * 60_000,
      value: index,
      incomplete: index === 5,
    }));
    fetch.mockImplementation(async () =>
      Response.json({ timeSeries: [{ values }] }),
    );
    const result = await rcaRouter.createCaller(ctx).queryMetrics({
      serviceId: 'service-a',
      environment: 'production',
      purpose: 'Check the incident window',
      timeRange: {
        start: new Date(start).toISOString(),
        end: '2026-08-08T00:00:00.000Z',
      },
    });
    expect(result.points).toHaveLength(360);
    expect(result.points.some((point) => point.value === 5)).toBe(false);
    expect(result.delivery).toMatchObject({
      providerPointCount,
      omittedIncompletePointCount: 1,
      downsampled: providerPointCount > 361,
    });
    expect(result.warnings).toEqual([
      expect.stringContaining('automatically increased'),
      expect.stringContaining('incomplete'),
    ]);
    expect(audit.update.mock.calls[0]![0].data).toMatchObject({
      outcome: 'PARTIAL',
      resultCount: 360,
      sourceFailures: 0,
    });
  });

  it.each([
    [undefined, '2026-08-08T00:00:00.000Z', 300],
    [90, '2026-08-07T02:00:00.000Z', 120],
  ] as const)('forwards the effective metric bucket for requested interval %s', async (requested, end, effective) => {
    const { ctx, fetch } = discoveryFixture();
    fetch.mockImplementation(async () =>
      Response.json({ timeSeries: [], meta: {} }),
    );
    const result = await rcaRouter.createCaller(ctx).queryMetrics({
      serviceId: 'service-a',
      environment: 'production',
      purpose: 'Investigate failures',
      timeRange: { start: '2026-08-07T00:00:00.000Z', end },
      intervalSeconds: requested,
    });
    expect(result).toMatchObject({
      requestedIntervalSeconds: requested ?? 60,
      intervalSeconds: effective,
    });
    expect(result.warnings[0]).toContain('supported bucket');
    expect(fetch.mock.calls[0]![0].searchParams.get('interval')).toBe(
      String(effective),
    );
  });
});

describe('testObservabilityConnection', () => {
  it('looks up only the requested connection within its service', async () => {
    let query: unknown;
    const ctx = connectionTestContext(null, (args) => {
      query = args;
    });

    await expect(
      testObservabilityConnection(ctx, {
        serviceId: 'service-a',
        connectionId: 'connection-a',
      }),
    ).rejects.toMatchObject({ code: 'NOT_FOUND' });
    expect(query).toEqual({
      where: { id: 'connection-a', serviceId: 'service-a' },
    });
  });

  it('rejects a disabled requested connection before discovery', async () => {
    const ctx = connectionTestContext({ ...connection, enabled: false });

    await expect(
      testObservabilityConnection(ctx, {
        serviceId: 'service-a',
        connectionId: 'connection-a',
      }),
    ).rejects.toMatchObject({ code: 'PRECONDITION_FAILED' });
  });
});

describe('getObservabilityCapabilities', () => {
  it('reports one configured connection per capability without routing metadata', async () => {
    const binding = {
      id: 'binding-errors',
      serviceId: 'service-a',
      signal: 'ERRORS' as const,
      connectionId: connection.id,
      connection,
    };
    const ctx = {
      user: {
        userId: 'user-a',
        email: 'user@example.test',
        permissions: { isAdmin: true, permissions: {} },
      },
      prisma: {
        service: { findUnique: async () => ({ id: 'service-a' }) },
        observabilityCapabilityBinding: {
          findMany: async ({ where }: { where: { signal?: string } }) =>
            where.signal === 'ERRORS' ? [binding] : [],
        },
      },
      credentialEncryptionMaintenanceActive: async () => false,
    } as unknown as Context;

    const result = await getObservabilityCapabilities(ctx, {
      serviceId: 'service-a',
      environment: 'production',
    });

    expect(result.errors.availability).toBe('AVAILABLE');
    if (result.errors.availability !== 'AVAILABLE') {
      throw new Error('Expected the Errors capability to be available.');
    }
    expect(result.errors).toMatchObject({
      availability: 'AVAILABLE',
      sources: [
        {
          bindingId: 'binding-errors',
          connectionId: 'connection-a',
          provider: 'SENTRY',
        },
      ],
    });
    expect(result.errors.sources[0]).not.toHaveProperty('priority');
    expect(result.logs).toMatchObject({ availability: 'UNAVAILABLE' });
  });

  it('reports capabilities as unavailable during credential encryption maintenance', async () => {
    const ctx = {
      user: {
        userId: 'user-a',
        email: 'user@example.test',
        permissions: { isAdmin: true, permissions: {} },
      },
      prisma: {
        service: { findUnique: async () => ({ id: 'service-a' }) },
        observabilityCapabilityBinding: { findMany: async () => [] },
      },
      credentialEncryptionMaintenanceActive: async () => true,
    } as unknown as Context;

    const result = await getObservabilityCapabilities(ctx, {
      serviceId: 'service-a',
      environment: 'production',
    });

    expect(result.errors).toMatchObject({ availability: 'UNAVAILABLE' });
    expect(result.errors).toMatchObject({
      reason: expect.stringContaining('maintenance'),
    });
  });
});
