import { HP_LICENSE_SYNC_STATUS, LicenseManager } from '@hyperprobe/common';
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import {
  OBSERVABILITY_SIGNALS,
  type ObservabilitySignalName,
  type StoredCapabilityBinding,
  type StoredObservabilityConnection,
} from '../observability/contracts.js';
import { ProviderError } from '../observability/errors.js';
import { sentryAdapter } from '../observability/sentryAdapter.js';
import type { Context } from '../trpc.js';
import {
  asTrpcError,
  capabilityConnectionsFromLegacyBindings,
  observabilityIntegrationsRouter,
  setCapabilityConnections,
} from './observabilityIntegrationsRouter.js';

const connection: StoredObservabilityConnection = {
  id: 'connection-a',
  serviceId: 'service-a',
  name: 'acme / web-api',
  provider: 'SENTRY',
  publicConfig: {
    apiBaseUrl: 'https://sentry.io/api/0/',
    orgSlug: 'acme',
    projectSlug: 'web-api',
  },
  configVersion: 1,
  credentialCiphertext: new Uint8Array([1]),
  credentialNonce: new Uint8Array(12),
  credentialAuthTag: new Uint8Array(16),
  credentialKeyVersion: 'v1',
  credentialFormat: 'SENTRY_AUTH_TOKEN',
  enabled: true,
  createdAt: new Date(),
  updatedAt: new Date(),
};

type CapabilityInput = {
  signal: ObservabilitySignalName;
  connectionId: string | null;
};

type CapabilityStore = {
  service: {
    findUnique(): Promise<{ id: string }>;
  };
  observabilityConnection: {
    findMany(): Promise<StoredObservabilityConnection[]>;
  };
  observabilityCapabilityBinding: {
    findMany(): Promise<StoredCapabilityBinding[]>;
    deleteMany(): Promise<{ count: number }>;
    create(args: {
      data: {
        id: string;
        serviceId: string;
        signal: ObservabilitySignalName;
        connectionId: string;
      };
    }): Promise<StoredCapabilityBinding>;
  };
  $executeRawUnsafe(query: string, ...values: unknown[]): Promise<number>;
  $transaction<T>(
    callback: (transaction: CapabilityStore) => Promise<T>,
  ): Promise<T>;
};

function capabilities(connectionId: string | null): CapabilityInput[] {
  return OBSERVABILITY_SIGNALS.map((signal) => ({ signal, connectionId }));
}

function capabilityContext(options?: {
  connection?: StoredObservabilityConnection;
  initialBindings?: StoredCapabilityBinding[];
}) {
  const selectedConnection = options?.connection ?? connection;
  let bindings = [...(options?.initialBindings ?? [])];
  let lockCount = 0;
  const store: CapabilityStore = {
    service: { findUnique: async () => ({ id: 'service-a' }) },
    observabilityConnection: {
      findMany: async () => [selectedConnection],
    },
    observabilityCapabilityBinding: {
      findMany: async () => bindings,
      deleteMany: async () => {
        const count = bindings.length;
        bindings = [];
        return { count };
      },
      create: async ({ data }) => {
        const binding = { ...data, connection: selectedConnection };
        bindings.push(binding);
        return binding;
      },
    },
    $executeRawUnsafe: async () => {
      lockCount += 1;
      return 0;
    },
    $transaction: async <T>(
      callback: (transaction: CapabilityStore) => Promise<T>,
    ) => callback(store),
  };
  return {
    bindings: () => bindings,
    ctx: {
      user: {
        userId: 'user-a',
        email: 'user@example.test',
        permissions: { isAdmin: true, permissions: {} },
      },
      prisma: store,
      credentialEncryptionMaintenanceActive: async () => false,
    } as unknown as Context,
    lockCount: () => lockCount,
  };
}

describe('setCapabilityConnections', () => {
  it('only accepts complete simple legacy capability saves', () => {
    const legacyBindings = OBSERVABILITY_SIGNALS.map((signal) => ({
      signal,
      connectionId: signal === 'ERRORS' ? 'connection-a' : null,
      selectorKey: 'default' as const,
      scopeSelector: {},
      priority: 0,
      enabled: signal === 'ERRORS',
    }));

    expect(capabilityConnectionsFromLegacyBindings(legacyBindings)).toEqual(
      OBSERVABILITY_SIGNALS.map((signal) => ({
        signal,
        connectionId: signal === 'ERRORS' ? 'connection-a' : null,
      })),
    );
    expect(
      capabilityConnectionsFromLegacyBindings([
        ...legacyBindings,
        {
          signal: 'ERRORS',
          connectionId: 'connection-b',
          selectorKey: 'environment',
          scopeSelector: { environment: 'staging' },
          priority: 100,
          enabled: false,
        },
      ]),
    ).toEqual(
      OBSERVABILITY_SIGNALS.map((signal) => ({
        signal,
        connectionId: signal === 'ERRORS' ? 'connection-a' : null,
      })),
    );
    expect(() =>
      capabilityConnectionsFromLegacyBindings(legacyBindings.slice(0, 1)),
    ).toThrow('Refresh the dashboard before saving capability choices.');
  });

  it('assigns one connection to every capability in one locked transaction', async () => {
    const test = capabilityContext();

    const result = await setCapabilityConnections(test.ctx, {
      serviceId: 'service-a',
      capabilities: capabilities('connection-a'),
    });

    expect(test.lockCount()).toBe(1);
    expect(test.bindings()).toHaveLength(5);
    expect(result).toEqual(
      OBSERVABILITY_SIGNALS.map((signal) =>
        expect.objectContaining({ signal, connectionId: 'connection-a' }),
      ),
    );
  });

  it('uses no row to represent a disabled capability', async () => {
    const test = capabilityContext();
    const selections = capabilities('connection-a');
    selections[0] = { signal: 'ERRORS', connectionId: null };

    const result = await setCapabilityConnections(test.ctx, {
      serviceId: 'service-a',
      capabilities: selections,
    });

    expect(test.bindings()).toHaveLength(4);
    expect(result.find((capability) => capability.signal === 'ERRORS')).toEqual(
      expect.objectContaining({ connectionId: null }),
    );
  });

  it('does not replace current assignments with a disabled connection', async () => {
    const currentBinding: StoredCapabilityBinding = {
      id: 'binding-errors',
      serviceId: 'service-a',
      signal: 'ERRORS',
      connectionId: 'connection-a',
      connection,
    };
    const test = capabilityContext({
      connection: { ...connection, enabled: false },
      initialBindings: [currentBinding],
    });

    await expect(
      setCapabilityConnections(test.ctx, {
        serviceId: 'service-a',
        capabilities: capabilities('connection-a'),
      }),
    ).rejects.toMatchObject({ code: 'PRECONDITION_FAILED' });
    expect(test.bindings()).toEqual([currentBinding]);
  });

  it('maps Prisma P2002 unique constraint violations to CONFLICT', () => {
    const error = {
      code: 'P2002',
      meta: { target: ['serviceId', 'name'] },
    };
    const trpcError = asTrpcError(error);
    expect(trpcError.code).toBe('CONFLICT');
    expect(trpcError.message).toContain('already exists');
  });
});

describe('connection enablement', () => {
  const input = {
    serviceId: connection.serviceId,
    connectionId: connection.id,
    provider: connection.provider,
    name: 'Updated label',
    publicConfig: connection.publicConfig as Record<string, unknown>,
  };

  function fixture(existing: StoredObservabilityConnection | null) {
    let saved = existing;
    const model = {
      findFirst: vi.fn(async () => saved),
      update: vi.fn(
        async ({ data }: { data: Partial<StoredObservabilityConnection> }) => {
          if (!saved) throw new Error('Expected an existing connection');
          saved = {
            ...saved,
            ...data,
            updatedAt: new Date(saved.updatedAt.getTime() + 1),
          };
          return saved;
        },
      ),
      create: vi.fn(
        async ({ data }: { data: StoredObservabilityConnection }) => {
          saved = { ...connection, ...data };
          return saved;
        },
      ),
    };
    const store = {
      service: { findUnique: async () => ({ id: connection.serviceId }) },
      observabilityConnection: model,
      $executeRawUnsafe: vi.fn(async () => 0),
    };
    const credentialCipher = {
      decrypt: vi.fn(() => 'stored-test-token'),
      needsRotation: () => false,
      encrypt: vi.fn(() => ({
        credentialCiphertext: new Uint8Array([2]),
        credentialNonce: connection.credentialNonce,
        credentialAuthTag: connection.credentialAuthTag,
        credentialKeyVersion: connection.credentialKeyVersion,
        credentialFormat: connection.credentialFormat,
      })),
    };
    const caller = observabilityIntegrationsRouter.createCaller({
      user: {
        userId: 'user-a',
        email: 'user@example.test',
        permissions: { isAdmin: true, permissions: {} },
      },
      prisma: {
        ...store,
        $transaction: async <T>(
          callback: (transaction: typeof store) => Promise<T>,
        ) => callback(store),
      },
      credentialCipher,
      credentialEncryptionMaintenanceActive: async () => false,
    } as unknown as Context);
    return { caller, model, credentialCipher, saved: () => saved };
  }

  beforeEach(() => {
    vi.spyOn(LicenseManager.getInstance(), 'getStatus').mockReturnValue(
      HP_LICENSE_SYNC_STATUS.SYNCED,
    );
    vi.spyOn(sentryAdapter, 'resolveConnectionConfig').mockImplementation(
      async (config) => ({
        ...config,
        projectId: '42',
        projectSlug: 'web-api',
      }),
    );
  });

  afterEach(() => vi.restoreAllMocks());

  it.each([
    [false, undefined],
    [false, 'replacement-test-token'],
    [true, undefined],
    [true, 'replacement-test-token'],
  ] as const)('preserves enabled=%s when editing with authToken=%s', async (enabled, authToken) => {
    const test = fixture({ ...connection, enabled });
    const result = await test.caller.upsertConnection({ ...input, authToken });
    expect(result).toMatchObject({ enabled, name: input.name });
    expect(test.saved()?.enabled).toBe(enabled);
    expect(test.model.update.mock.calls[0]![0].data).not.toHaveProperty(
      'enabled',
    );
    expect(test.credentialCipher.encrypt).toHaveBeenCalledTimes(
      authToken ? 1 : 0,
    );
    if (!enabled) {
      await expect(
        test.caller.testConnection({
          serviceId: input.serviceId,
          connectionId: input.connectionId,
        }),
      ).rejects.toMatchObject({ code: 'PRECONDITION_FAILED' });
      expect(sentryAdapter.resolveConnectionConfig).toHaveBeenCalledTimes(1);
    }
  });

  it('still creates enabled connections', async () => {
    const test = fixture(null);
    const result = await test.caller.upsertConnection({
      ...input,
      connectionId: undefined,
      authToken: 'new-test-token',
    });
    expect(result.enabled).toBe(true);
    expect(test.model.create.mock.calls[0]![0].data.enabled).toBe(true);
    expect(test.model.update).not.toHaveBeenCalled();
  });

  it('only re-enables a disabled connection through the explicit enable action', async () => {
    const test = fixture({ ...connection, enabled: false });
    await expect(test.caller.upsertConnection(input)).resolves.toMatchObject({
      enabled: false,
    });
    await expect(
      test.caller.setConnectionEnabled({
        serviceId: input.serviceId,
        connectionId: input.connectionId,
        enabled: true,
      }),
    ).resolves.toMatchObject({ enabled: true });
    expect(test.model.update.mock.calls[1]![0].data).toEqual({ enabled: true });
  });

  it('does not mutate a disabled connection if provider validation fails', async () => {
    const test = fixture({ ...connection, enabled: false });
    vi.mocked(sentryAdapter.resolveConnectionConfig).mockRejectedValue(
      new ProviderError('AUTHENTICATION_FAILED', 'Rejected token'),
    );
    await expect(test.caller.upsertConnection(input)).rejects.toMatchObject({
      code: 'PRECONDITION_FAILED',
    });
    expect(test.saved()?.enabled).toBe(false);
    expect(test.model.update).not.toHaveBeenCalled();
  });

  it('rejects an edit when the connection was disabled after its snapshot was read', async () => {
    const test = fixture(connection);
    test.model.findFirst
      .mockResolvedValueOnce(connection)
      .mockResolvedValueOnce({
        ...connection,
        enabled: false,
        updatedAt: new Date(connection.updatedAt.getTime() + 1),
      });
    await expect(test.caller.upsertConnection(input)).rejects.toMatchObject({
      code: 'CONFLICT',
    });
    expect(test.model.update).not.toHaveBeenCalled();
  });
});
