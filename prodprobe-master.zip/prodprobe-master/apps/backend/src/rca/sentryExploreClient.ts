const MAX_RESPONSE_BYTES = 2 * 1024 * 1024;
const MAX_TIMEOUT_MS = 10_000;
const DEFAULT_SENTRY_BASE_URL = 'https://sentry.io/api/0/';

// Provider responses can be large even for a modest number of rows. These
// limits apply to the live payload returned to the host agent, not the
// provider request itself. They keep an RCA from filling the model context or
// exposing a whole serialized job/request body through a span description.
export const MAX_SENTRY_TABLE_ROWS = 25;
export const SENTRY_METRIC_INTERVALS_SECONDS = [
  60, 120, 300, 600, 900, 1_800, 3_600,
] as const;

export type SentrySignal = 'ERRORS' | 'LOGS' | 'TRACES';
export type SentryMetric = 'THROUGHPUT' | 'FAILURE_RATE';

export type SentryDiscoveryAvailability<T> =
  | { availability: 'AVAILABLE'; values: T[] }
  | {
      availability: 'UNAVAILABLE';
      code: SentryExploreErrorCode;
      reason: string;
      retryAt?: string;
    };

export type SentryDiscoveryTag = {
  key: string;
  name: string;
  totalValues?: number;
};

export type SentryDiscoveryRelease = {
  version: string;
  shortVersion?: string;
  dateCreated?: string;
  dateReleased?: string;
};

export type SentryDiscoveryResult = {
  alerts: SentryDiscoveryAvailability<Record<string, never>>;
  environments: SentryDiscoveryAvailability<string>;
  releases: SentryDiscoveryAvailability<SentryDiscoveryRelease>;
  tags: SentryDiscoveryAvailability<SentryDiscoveryTag>;
};

export type SentryProject = {
  id: string;
  slug: string;
};

export type SentryExploreErrorCode =
  | 'AUTHENTICATION_FAILED'
  | 'INVALID_CONFIGURATION'
  | 'INVALID_REQUEST'
  | 'OVERLOADED'
  | 'RATE_LIMITED'
  | 'RESPONSE_TOO_LARGE'
  | 'TIMEOUT'
  | 'UNAVAILABLE';

export type SentryRateLimit = {
  limit?: number;
  remaining?: number;
  resetAt?: string;
  concurrentLimit?: number;
  concurrentRemaining?: number;
  retryAt?: string;
};

type SentryExploreErrorOptions = ErrorOptions & {
  rateLimit?: SentryRateLimit;
};

export class SentryExploreError extends Error {
  readonly code: SentryExploreErrorCode;
  readonly rateLimit?: SentryRateLimit;

  constructor(
    code: SentryExploreErrorCode,
    message: string,
    options?: SentryExploreErrorOptions,
  ) {
    super(message, options);
    this.code = code;
    this.rateLimit = options?.rateLimit;
    this.name = 'SentryExploreError';
  }
}

type FetchImplementation = (
  input: URL,
  init?: RequestInit,
) => Promise<Response>;

export type SentryExploreScope = {
  organizationSlug: string;
  projectSlug: string;
  projectId?: string | null;
  providerEnvironment: string;
  release?: string | null;
};

export type SentryTableQuery = {
  signal: SentrySignal;
  // The backend observability contract chooses this provider projection. It is
  // not an agent-controlled field list.
  fields: readonly string[];
  scope: SentryExploreScope;
  start: string;
  end: string;
  filter?: string;
  traceId?: string;
  traceFormat?: string;
  limit: number;
  cursor?: string;
  timeoutMs?: number;
};

export type SentryMetricQuery = {
  scope: SentryExploreScope;
  start: string;
  end: string;
  filter?: string;
  metric: SentryMetric;
  intervalSeconds: number;
  timeoutMs?: number;
};

export type SentryAlertQuery = {
  scope: SentryExploreScope;
  start: string;
  end: string;
  filter?: string;
  limit: number;
  cursor?: string;
  timeoutMs?: number;
};

export type SentryTableResult = {
  data: unknown[];
  page: { hasMore: boolean; nextCursor?: string };
};

export type SentryMetricResult = {
  timeSeries: unknown[];
  meta: Record<string, unknown>;
};

export type SentryAlertResult = {
  data: unknown[];
  page: { hasMore: boolean; nextCursor?: string };
};

export type SentryExploreClientConfig = {
  authToken: string;
  apiBaseUrl?: string;
  nodeEnvironment?: string;
  allowedBaseUrls?: readonly string[];
};

function asRecord(value: unknown): Record<string, unknown> | null {
  return typeof value === 'object' && value !== null && !Array.isArray(value)
    ? (value as Record<string, unknown>)
    : null;
}

function nonBlank(value: string, name: string, maximum: number): string {
  const normalized = value.trim();
  if (!normalized || normalized.length > maximum) {
    throw new SentryExploreError(
      'INVALID_REQUEST',
      `The Sentry ${name} is invalid.`,
    );
  }
  return normalized;
}

function slug(value: string, name: string): string {
  const normalized = nonBlank(value, name, 128);
  if (!/^[A-Za-z0-9][A-Za-z0-9_-]*$/.test(normalized)) {
    throw new SentryExploreError(
      'INVALID_REQUEST',
      `The Sentry ${name} is invalid.`,
    );
  }
  return normalized;
}

function projectIdString(value: unknown): string | undefined {
  const normalized =
    typeof value === 'string'
      ? value.trim()
      : typeof value === 'number' && Number.isSafeInteger(value)
        ? String(value)
        : '';
  return /^\d{1,32}$/.test(normalized) ? normalized : undefined;
}

function projectId(value: unknown): string {
  const normalized = projectIdString(value);
  if (!normalized) {
    throw new SentryExploreError(
      'INVALID_REQUEST',
      'The Sentry project ID is invalid.',
    );
  }
  return normalized;
}

function isoTime(value: string, name: string): string {
  if (!Number.isFinite(Date.parse(value))) {
    throw new SentryExploreError(
      'INVALID_REQUEST',
      `The ${name} timestamp must be ISO-8601.`,
    );
  }
  return value;
}

function quotedQueryValue(value: string): string {
  return `"${value.replaceAll('\\', '\\\\').replaceAll('"', '\\"')}"`;
}

function releaseQuery(scope: SentryExploreScope): string[] {
  const release = scope.release?.trim();
  if (!release) return [];
  // Quoting alone does not disable Sentry's aliases, wildcards, or escapes.
  if (release === 'latest' || release.includes('\\')) {
    throw new SentryExploreError(
      'INVALID_REQUEST',
      'The Sentry release cannot be matched literally.',
    );
  }
  return [`release:${quotedQueryValue(release).replaceAll('*', '\\*')}`];
}

function isContainedFilter(filter: string): boolean {
  // Sentry event_search.py (5c1eecde): a quote after ANY backslash run is
  // escaped. Only verified atoms may hide parentheses, not arbitrary quotes.
  const quotedValue = String.raw`"(?:[^"]|(?<=\\)")*(?<!\\)"`;
  const key = String.raw`(?:tags\[[A-Za-z0-9_.:-]+\]|[A-Za-z0-9_.-]+)`;
  const hasKey = new RegExp(`^${key}`);
  const listItem = String.raw`(?:${quotedValue}|[^()[\], "\x60]+)`;
  const quotedAtom = new RegExp(`(!?${key}:)?${quotedValue}(?=[ )]|$)`, 'y');
  const listAtom = new RegExp(
    String.raw`(!?${key}):\[${listItem}(?: *, *${listItem})*\](?=[ )]|$)`,
    'y',
  );
  const bareAtom = new RegExp(
    String.raw`(!?${key}):([^()" \x60]*)(?=[ ()]|$)`,
    'y',
  );
  const booleanOperator = /(?:AND|OR)(?=[ )]|$)/iy;
  // False marks free-text/function parentheses, where quoted arguments are
  // outside this bounded subset. Spaces alone do not end unquoted free text.
  const groups = [true];
  let rawText = false;
  for (let index = 0; index < filter.length; ) {
    const character = filter[index];
    if (character === ' ') {
      index += 1;
      continue;
    }
    if (character === '(') {
      groups.push(groups[groups.length - 1]! && !rawText);
      rawText = !groups[groups.length - 1];
      index += 1;
      continue;
    }
    if (character === ')') {
      if (groups.length === 1) return false;
      // Empty parentheses are free text and can absorb following quotes.
      let previous = index - 1;
      while (filter[previous] === ' ') previous -= 1;
      rawText = !groups.pop() || filter[previous] === '(';
      index += 1;
      continue;
    }
    if (groups[groups.length - 1]) {
      listAtom.lastIndex = index;
      const list = listAtom.exec(filter);
      // has:/is: take earlier grammar branches, not ordinary text IN lists.
      if (list && !/^!?(?:has|is)$/.test(list[1]!)) {
        index = listAtom.lastIndex;
        rawText = false;
        continue;
      }
      quotedAtom.lastIndex = index;
      const atom = quotedAtom.exec(filter);
      if (atom && (atom[1] !== undefined || !rawText)) {
        index = quotedAtom.lastIndex;
        rawText = false;
        continue;
      }
    }
    bareAtom.lastIndex = index;
    const bare = bareAtom.exec(filter);
    if (bare) {
      index = bareAtom.lastIndex;
      // Numeric/has filters can consume only a scalar prefix; unverified IN
      // lists can fall back to text. A following standalone quote is ambiguous.
      rawText =
        bare[2]!.startsWith('[') ||
        (/^!?has$/.test(bare[1]!)
          ? hasKey.exec(bare[2]!)?.[0] !== bare[2]
          : /[,\]]/.test(bare[2]!));
      continue;
    }
    booleanOperator.lastIndex = index;
    if (booleanOperator.test(filter)) {
      index = booleanOperator.lastIndex;
      rawText = false;
      continue;
    }
    rawText = true;
    while (index < filter.length && !' ()'.includes(filter[index]!)) {
      if (filter[index] === '"' || filter[index] === '`') return false;
      index += 1;
    }
  }
  return groups.length === 1;
}

function buildQuery(
  scope: SentryExploreScope,
  filter?: string,
  traceId?: string,
): string | undefined {
  const terms = releaseQuery(scope);
  if (traceId) {
    const normalized = nonBlank(traceId, 'traceId', 512);
    // Doubling a trailing backslash still escapes Sentry's closing quote.
    if (normalized.endsWith('\\')) {
      throw new SentryExploreError(
        'INVALID_REQUEST',
        'The Sentry traceId cannot end with a backslash.',
      );
    }
    terms.push(`trace:${quotedQueryValue(normalized)}`);
  }
  if (filter !== undefined) {
    const normalized = nonBlank(filter, 'filter', 512);
    if (/\p{Cc}/u.test(filter) || !isContainedFilter(normalized)) {
      throw new SentryExploreError(
        'INVALID_REQUEST',
        'The Sentry filter cannot be safely grouped. Use balanced parentheses and supported quoted values, without control characters or unquoted backticks.',
      );
    }
    terms.push(`(${normalized})`);
  }
  return terms.length === 0 ? undefined : terms.join(' ');
}

function discoveryAvailability<T>(
  result: PromiseSettledResult<T[]>,
): SentryDiscoveryAvailability<T> {
  if (result.status === 'fulfilled') {
    return { availability: 'AVAILABLE', values: result.value };
  }
  const reason =
    result.reason instanceof Error
      ? result.reason.message
      : 'Sentry discovery could not be completed.';
  return {
    availability: 'UNAVAILABLE',
    code:
      result.reason instanceof SentryExploreError
        ? result.reason.code
        : 'UNAVAILABLE',
    reason: reason.replace(/\p{Cc}/gu, ' ').slice(0, 512),
    ...(result.reason instanceof SentryExploreError &&
    result.reason.rateLimit?.retryAt
      ? { retryAt: result.reason.rateLimit.retryAt }
      : {}),
  };
}

function normalizedApprovedBaseUrl(value: string): string | undefined {
  try {
    const url = new URL(value.trim());
    if (
      url.protocol !== 'https:' ||
      url.username ||
      url.password ||
      url.search ||
      url.hash
    ) {
      return undefined;
    }
    if (!url.pathname.endsWith('/')) url.pathname += '/';
    return url.toString();
  } catch {
    return undefined;
  }
}

function baseUrl(config: SentryExploreClientConfig): URL {
  const raw = config.apiBaseUrl?.trim() || DEFAULT_SENTRY_BASE_URL;
  const normalized = normalizedApprovedBaseUrl(raw);
  if (!normalized) {
    throw new SentryExploreError(
      'INVALID_CONFIGURATION',
      'The Sentry API base URL must be an HTTPS URL without credentials, query, or fragment.',
    );
  }
  const allowed = new Set(
    [DEFAULT_SENTRY_BASE_URL, ...(config.allowedBaseUrls ?? [])]
      .map(normalizedApprovedBaseUrl)
      .filter((value): value is string => Boolean(value)),
  );
  if (!allowed.has(normalized)) {
    throw new SentryExploreError(
      'INVALID_CONFIGURATION',
      'The Sentry API base URL is not approved for this deployment.',
    );
  }
  return new URL(normalized);
}

function pageFromLink(
  linkHeader: string | null,
  baseUrl?: string,
): SentryTableResult['page'] {
  if (!linkHeader) return { hasMore: false };
  for (const link of linkHeader.split(',')) {
    if (!/rel="?next"?/i.test(link) || !/results="?true"?/i.test(link)) {
      continue;
    }
    const urlMatch = link.match(/<([^>]+)>/);
    if (!urlMatch) continue;
    try {
      const cursor = new URL(
        urlMatch[1]!,
        baseUrl ?? 'https://sentry.io',
      ).searchParams.get('cursor');
      if (cursor) return { hasMore: true, nextCursor: cursor };
    } catch {
      return { hasMore: true };
    }
  }
  return { hasMore: false };
}

function responseHeaderNumber(
  headers: Headers,
  name: string,
): number | undefined {
  const raw = headers.get(name)?.trim();
  if (!raw) return undefined;
  const value = Number(raw);
  return Number.isFinite(value) && value >= 0 ? value : undefined;
}

function retryAtFromHeaders(headers: Headers): string | undefined {
  const retryAfter = headers.get('retry-after')?.trim();
  if (retryAfter) {
    const seconds = Number(retryAfter);
    if (Number.isFinite(seconds) && seconds >= 0) {
      return new Date(Date.now() + seconds * 1_000).toISOString();
    }
    const date = Date.parse(retryAfter);
    if (Number.isFinite(date)) return new Date(date).toISOString();
  }
  const reset = responseHeaderNumber(headers, 'x-sentry-rate-limit-reset');
  return reset === undefined
    ? undefined
    : new Date(reset * 1_000).toISOString();
}

function rateLimitFromHeaders(headers: Headers): SentryRateLimit {
  const limit = responseHeaderNumber(headers, 'x-sentry-rate-limit-limit');
  const remaining = responseHeaderNumber(
    headers,
    'x-sentry-rate-limit-remaining',
  );
  const reset = responseHeaderNumber(headers, 'x-sentry-rate-limit-reset');
  const concurrentLimit = responseHeaderNumber(
    headers,
    'x-sentry-rate-limit-concurrentlimit',
  );
  const concurrentRemaining = responseHeaderNumber(
    headers,
    'x-sentry-rate-limit-concurrentremaining',
  );
  const retryAt = retryAtFromHeaders(headers);
  return {
    ...(limit === undefined ? {} : { limit }),
    ...(remaining === undefined ? {} : { remaining }),
    ...(reset === undefined
      ? {}
      : { resetAt: new Date(reset * 1_000).toISOString() }),
    ...(concurrentLimit === undefined ? {} : { concurrentLimit }),
    ...(concurrentRemaining === undefined ? {} : { concurrentRemaining }),
    ...(retryAt ? { retryAt } : {}),
  };
}

function errorForStatus(status: number, headers: Headers): SentryExploreError {
  if (status === 401 || status === 403) {
    return new SentryExploreError(
      'AUTHENTICATION_FAILED',
      'Sentry rejected the configured credential.',
    );
  }
  if (status === 429) {
    const rateLimit = rateLimitFromHeaders(headers);
    const retryAt = rateLimit.retryAt;
    return new SentryExploreError(
      'RATE_LIMITED',
      retryAt
        ? 'Sentry rate-limited this evidence request. Retry after ' +
            retryAt +
            '.'
        : 'Sentry rate-limited this evidence request.',
      { rateLimit },
    );
  }
  if (status >= 500) {
    return new SentryExploreError(
      'UNAVAILABLE',
      'Sentry is temporarily unavailable.',
    );
  }
  return new SentryExploreError(
    'INVALID_REQUEST',
    'Sentry rejected the evidence query.',
  );
}

async function boundedResponseText(response: Response): Promise<string> {
  const declaredLength = Number(response.headers.get('content-length'));
  if (Number.isFinite(declaredLength) && declaredLength > MAX_RESPONSE_BYTES) {
    throw new SentryExploreError(
      'RESPONSE_TOO_LARGE',
      'Sentry returned more data than this evidence request allows.',
    );
  }
  if (!response.body) {
    throw new SentryExploreError(
      'UNAVAILABLE',
      'Sentry returned an empty response.',
    );
  }
  const reader = response.body.getReader();
  const chunks: Uint8Array[] = [];
  let length = 0;
  while (true) {
    const chunk = await reader.read();
    if (chunk.done) break;
    length += chunk.value.byteLength;
    if (length > MAX_RESPONSE_BYTES) {
      await reader.cancel();
      throw new SentryExploreError(
        'RESPONSE_TOO_LARGE',
        'Sentry returned more data than this evidence request allows.',
      );
    }
    chunks.push(chunk.value);
  }
  const bytes = new Uint8Array(length);
  let offset = 0;
  for (const chunk of chunks) {
    bytes.set(chunk, offset);
    offset += chunk.byteLength;
  }
  try {
    return new TextDecoder('utf-8', { fatal: true }).decode(bytes);
  } catch (error) {
    throw new SentryExploreError(
      'UNAVAILABLE',
      'Sentry returned malformed UTF-8.',
      {
        cause: error,
      },
    );
  }
}
export class SentryExploreClient {
  private readonly authToken: string;
  private readonly apiBaseUrl: URL;
  private readonly fetchImplementation: FetchImplementation;

  private constructor(
    authToken: string,
    apiBaseUrl: URL,
    fetchImplementation: FetchImplementation,
  ) {
    this.authToken = authToken;
    this.apiBaseUrl = apiBaseUrl;
    this.fetchImplementation = fetchImplementation;
  }

  static fromConfig(
    config: SentryExploreClientConfig,
    fetchImplementation: FetchImplementation = globalThis.fetch,
  ): SentryExploreClient {
    const authToken = config.authToken.trim();
    if (!authToken || /\p{Cc}/u.test(authToken)) {
      throw new SentryExploreError(
        'INVALID_CONFIGURATION',
        'The Sentry credential is invalid.',
      );
    }
    if (typeof fetchImplementation !== 'function') {
      throw new SentryExploreError(
        'INVALID_CONFIGURATION',
        'The Fetch API is unavailable.',
      );
    }
    return new SentryExploreClient(
      authToken,
      baseUrl(config),
      fetchImplementation,
    );
  }

  async queryTable(input: SentryTableQuery): Promise<SentryTableResult> {
    const scope = this.validateScope(input.scope);
    const limit = Math.min(
      MAX_SENTRY_TABLE_ROWS,
      Math.max(1, Math.floor(input.limit)),
    );
    const params = this.scopeParameters(scope, input.start, input.end);
    params.set(
      'dataset',
      input.signal === 'TRACES' ? 'spans' : input.signal.toLowerCase(),
    );
    const fields = input.fields
      .map((field) => field.trim())
      .filter((field) => field.length > 0);
    if (
      fields.length === 0 ||
      fields.length > 16 ||
      fields.some(
        (field) => field.length > 128 || !/^[A-Za-z0-9_.-]+$/.test(field),
      )
    ) {
      throw new SentryExploreError(
        'INVALID_REQUEST',
        'The observability field projection is invalid.',
      );
    }
    for (const field of fields) params.append('field', field);
    params.set('per_page', String(limit));
    params.set('sort', '-timestamp');
    params.set('allowAggregateConditions', 'false');
    const query = buildQuery(scope, input.filter, input.traceId);
    if (query) params.set('query', query);
    if (input.cursor)
      params.set('cursor', nonBlank(input.cursor, 'cursor', 2_048));
    const response = await this.request(
      ['organizations', scope.organizationSlug, 'events'],
      params,
      input.timeoutMs,
    );
    const body = asRecord(response.body);
    if (!body || !Array.isArray(body.data)) {
      throw new SentryExploreError(
        'UNAVAILABLE',
        'Sentry returned an invalid table response.',
      );
    }
    const data = body.data.slice(0, limit).map((value) => {
      const row = asRecord(value);
      if (!row) return {};
      return Object.fromEntries(
        fields.flatMap((field) =>
          row[field] === undefined ? [] : [[field, row[field]]],
        ),
      );
    });
    return {
      data,
      page: pageFromLink(response.linkHeader, this.apiBaseUrl?.toString()),
    };
  }

  async queryMetricSeries(
    input: SentryMetricQuery,
  ): Promise<SentryMetricResult> {
    const scope = this.validateScope(input.scope);
    const params = this.scopeParameters(scope, input.start, input.end);
    const interval = input.intervalSeconds;
    if (
      !SENTRY_METRIC_INTERVALS_SECONDS.some((value) => value === interval) ||
      interval * 1_000 > Date.parse(input.end) - Date.parse(input.start)
    ) {
      throw new SentryExploreError(
        'INVALID_REQUEST',
        'The metric interval must be a supported Sentry bucket that fits the requested time range.',
      );
    }
    // Sentry's spans dataset supports both V1 aggregates across current
    // organizations: count() for throughput and failure_rate() for failures.
    // The tracemetrics dataset rejects those aggregates for some projects.
    params.set('dataset', 'spans');
    params.set('interval', String(interval));
    params.set(
      'yAxis',
      input.metric === 'THROUGHPUT' ? 'count()' : 'failure_rate()',
    );
    const query = buildQuery(scope, input.filter);
    if (query) params.set('query', query);
    const response = await this.request(
      ['organizations', scope.organizationSlug, 'events-timeseries'],
      params,
      input.timeoutMs,
    );
    const body = asRecord(response.body);
    if (!body || !Array.isArray(body.timeSeries)) {
      throw new SentryExploreError(
        'UNAVAILABLE',
        'Sentry returned an invalid metric response.',
      );
    }
    return { timeSeries: body.timeSeries, meta: asRecord(body.meta) ?? {} };
  }

  async queryAlerts(input: SentryAlertQuery): Promise<SentryAlertResult> {
    const scope = this.validateScope(input.scope);
    const limit = Math.min(
      MAX_SENTRY_TABLE_ROWS,
      Math.max(1, Math.floor(input.limit)),
    );
    // Organization issues enforce project, environment, and event time bounds.
    // https://docs.sentry.io/api/events/list-an-organizations-issues/
    // Keep the metadata-only projection below rather than returning raw events.
    const params = this.scopeParameters(scope, input.start, input.end);
    const start = Date.parse(input.start);
    const end = Date.parse(input.end);
    params.set('limit', String(limit));
    // A bare event-ID query bypasses scope filters; force normal issue search.
    const query = ['has:environment', ...releaseQuery(scope)];
    // Issue search ANDs bare tokens; parentheses would turn filters into text.
    query.push(
      input.filter ? nonBlank(input.filter, 'filter', 512) : 'is:unresolved',
    );
    params.set('query', query.join(' '));
    if (input.cursor)
      params.set('cursor', nonBlank(input.cursor, 'cursor', 2_048));
    const response = await this.request(
      ['organizations', scope.organizationSlug, 'issues'],
      params,
      input.timeoutMs,
    );
    if (!Array.isArray(response.body)) {
      throw new SentryExploreError(
        'UNAVAILABLE',
        'Sentry returned an invalid alert response.',
      );
    }
    const fields = [
      'id',
      'shortId',
      'title',
      'culprit',
      'level',
      'status',
      'firstSeen',
      'lastSeen',
      'count',
      'permalink',
    ];
    const data = response.body.flatMap((value) => {
      const issue = asRecord(value);
      if (!issue) return [];
      // Filtered counts and dates describe the matching events, not other releases.
      const statistics = asRecord(issue.filtered) ?? issue;
      const firstSeen =
        typeof statistics.firstSeen === 'string'
          ? Date.parse(statistics.firstSeen)
          : Number.NaN;
      const lastSeen =
        typeof statistics.lastSeen === 'string'
          ? Date.parse(statistics.lastSeen)
          : Number.NaN;
      if (!Number.isFinite(firstSeen) || !Number.isFinite(lastSeen)) {
        return [];
      }
      if (firstSeen > end || lastSeen < start) return [];
      return [
        Object.fromEntries(
          fields.flatMap((field) => {
            const source =
              field === 'count' || field === 'firstSeen' || field === 'lastSeen'
                ? statistics
                : issue;
            return source[field] === undefined ? [] : [[field, source[field]]];
          }),
        ),
      ];
    });
    return {
      data: data.slice(0, limit),
      page: pageFromLink(response.linkHeader, this.apiBaseUrl.toString()),
    };
  }

  private async resolveProject(
    organization: string,
    projectIdentifier: string,
  ): Promise<SentryProject> {
    const response = await this.request(
      ['projects', organization, projectIdentifier],
      new URLSearchParams(),
    );
    const project = asRecord(response.body);
    if (
      !project ||
      !projectIdString(project.id) ||
      typeof project.slug !== 'string'
    ) {
      throw new SentryExploreError(
        'UNAVAILABLE',
        'Sentry returned an invalid project response.',
      );
    }
    return {
      id: projectId(project.id),
      slug: slug(project.slug, 'project slug'),
    };
  }

  async resolveProjectById(
    organizationSlug: string,
    inputProjectId: string,
  ): Promise<SentryProject> {
    const id = projectId(inputProjectId);
    const project = await this.resolveProject(
      slug(organizationSlug, 'organization slug'),
      id,
    );
    if (project.id !== id) {
      throw new SentryExploreError(
        'UNAVAILABLE',
        'Sentry returned an invalid project response.',
      );
    }
    return project;
  }

  async resolveProjectBySlug(
    organizationSlug: string,
    projectSlug: string,
  ): Promise<SentryProject> {
    return this.resolveProject(
      slug(organizationSlug, 'organization slug'),
      slug(projectSlug, 'project slug'),
    );
  }

  async discoverContext(input: {
    organizationSlug: string;
    projectSlug: string;
    projectId?: string | null;
  }): Promise<SentryDiscoveryResult> {
    const organizationSlug = slug(input.organizationSlug, 'organization slug');
    const projectSlug = slug(input.projectSlug, 'project slug');
    const project = input.projectId ? projectId(input.projectId) : projectSlug;
    const [alerts, environments, releases, tags] = await Promise.allSettled([
      this.listAlerts(organizationSlug, project),
      this.listTagValues(organizationSlug, project, 'environment'),
      this.listReleases(organizationSlug, project),
      this.listTags(organizationSlug, project),
    ]);
    return {
      alerts: discoveryAvailability(alerts),
      environments: discoveryAvailability(environments),
      releases: discoveryAvailability(releases),
      tags: discoveryAvailability(tags),
    };
  }

  private async listAlerts(
    organizationSlug: string,
    project: string,
  ): Promise<Record<string, never>[]> {
    const params = new URLSearchParams();
    params.set('limit', '1');
    const response = await this.request(
      ['projects', organizationSlug, project, 'issues'],
      params,
    );
    if (!Array.isArray(response.body)) {
      throw new SentryExploreError(
        'UNAVAILABLE',
        'Sentry returned an invalid alert response.',
      );
    }
    return [];
  }

  private async listTagValues(
    organizationSlug: string,
    project: string,
    key: string,
  ): Promise<string[]> {
    const response = await this.request(
      ['projects', organizationSlug, project, 'tags', key, 'values'],
      new URLSearchParams(),
    );
    if (!Array.isArray(response.body)) {
      throw new SentryExploreError(
        'UNAVAILABLE',
        'Sentry returned an invalid tag-value response.',
      );
    }
    return [
      ...new Set(
        response.body.flatMap((entry) => {
          const raw = asRecord(entry);
          const rawValue =
            typeof raw?.name === 'string' && raw.name.trim()
              ? raw.name
              : raw?.value;
          const value =
            typeof rawValue === 'string' && rawValue.trim()
              ? rawValue.trim().slice(0, 128)
              : undefined;
          return value ? [value] : [];
        }),
      ),
    ]
      .sort((left, right) => left.localeCompare(right))
      .slice(0, 25);
  }

  private async listReleases(
    organizationSlug: string,
    project: string,
  ): Promise<SentryDiscoveryRelease[]> {
    const params = new URLSearchParams();
    params.set('project', project);
    params.set('per_page', '25');
    const response = await this.request(
      ['organizations', organizationSlug, 'releases'],
      params,
    );
    if (!Array.isArray(response.body)) {
      throw new SentryExploreError(
        'UNAVAILABLE',
        'Sentry returned an invalid release response.',
      );
    }
    return response.body.flatMap((entry) => {
      const release = asRecord(entry);
      if (!release) return [];
      const version = release.version;
      if (typeof version !== 'string' || !version.trim()) return [];
      return [
        {
          version: version.trim().slice(0, 256),
          ...(typeof release.shortVersion === 'string' &&
          release.shortVersion.trim()
            ? { shortVersion: release.shortVersion.trim().slice(0, 256) }
            : {}),
          ...(typeof release.dateCreated === 'string'
            ? { dateCreated: release.dateCreated.slice(0, 64) }
            : {}),
          ...(typeof release.dateReleased === 'string'
            ? { dateReleased: release.dateReleased.slice(0, 64) }
            : {}),
        },
      ];
    });
  }

  private async listTags(
    organizationSlug: string,
    project: string,
  ): Promise<SentryDiscoveryTag[]> {
    const params = new URLSearchParams();
    params.set('project', project);
    params.set('dataset', 'events');
    params.set('statsPeriod', '30d');
    params.set('use_cache', '1');
    const response = await this.request(
      ['organizations', organizationSlug, 'tags'],
      params,
    );
    if (!Array.isArray(response.body)) {
      throw new SentryExploreError(
        'UNAVAILABLE',
        'Sentry returned an invalid tag response.',
      );
    }
    return response.body
      .flatMap((entry) => {
        const tag = asRecord(entry);
        if (!tag) return [];
        const key = tag.key;
        if (typeof key !== 'string' || !key.trim()) return [];
        return [
          {
            key: key.trim().slice(0, 128),
            name:
              typeof tag.name === 'string' && tag.name.trim()
                ? tag.name.trim().slice(0, 128)
                : key.trim().slice(0, 128),
            ...(typeof tag.totalValues === 'number' &&
            Number.isFinite(tag.totalValues)
              ? { totalValues: Math.max(0, Math.floor(tag.totalValues)) }
              : {}),
          },
        ];
      })
      .sort((left, right) => left.key.localeCompare(right.key))
      .slice(0, 25);
  }

  private validateScope(scope: SentryExploreScope): SentryExploreScope {
    return {
      organizationSlug: slug(scope.organizationSlug, 'organization slug'),
      projectSlug: slug(scope.projectSlug, 'project slug'),
      ...(scope.projectId
        ? { projectId: nonBlank(scope.projectId, 'project ID', 128) }
        : {}),
      providerEnvironment: nonBlank(
        scope.providerEnvironment,
        'environment',
        128,
      ),
      ...(scope.release
        ? { release: nonBlank(scope.release, 'release', 256) }
        : {}),
    };
  }

  private scopeParameters(
    scope: SentryExploreScope,
    start: string,
    end: string,
  ): URLSearchParams {
    const normalizedStart = isoTime(start, 'start');
    const normalizedEnd = isoTime(end, 'end');
    if (Date.parse(normalizedEnd) <= Date.parse(normalizedStart)) {
      throw new SentryExploreError(
        'INVALID_REQUEST',
        'The evidence query end must be after its start.',
      );
    }
    const params = new URLSearchParams();
    params.set('project', scope.projectId ?? scope.projectSlug);
    params.set('environment', scope.providerEnvironment);
    params.set('start', normalizedStart);
    params.set('end', normalizedEnd);
    return params;
  }

  private async request(
    path: readonly string[],
    parameters: URLSearchParams,
    requestedTimeoutMs?: number,
  ): Promise<{ body: unknown; linkHeader: string | null }> {
    const url = new URL(
      `${path.map((part) => encodeURIComponent(part)).join('/')}/`,
      this.apiBaseUrl,
    );
    url.search = parameters.toString();
    const validTimeout =
      typeof requestedTimeoutMs === 'number' &&
      Number.isFinite(requestedTimeoutMs)
        ? requestedTimeoutMs
        : MAX_TIMEOUT_MS;
    const timeoutMs = Math.min(
      MAX_TIMEOUT_MS,
      Math.max(1, Math.floor(validTimeout)),
    );
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), timeoutMs);
    try {
      const response = await this.fetchImplementation(url, {
        method: 'GET',
        headers: {
          accept: 'application/json',
          authorization: `Bearer ${this.authToken}`,
        },
        redirect: 'error',
        signal: controller.signal,
      });
      if (!response.ok) throw errorForStatus(response.status, response.headers);
      const text = await boundedResponseText(response);
      try {
        return {
          body: JSON.parse(text),
          linkHeader: response.headers.get('link'),
        };
      } catch {
        throw new SentryExploreError(
          'UNAVAILABLE',
          'Sentry returned malformed JSON.',
        );
      }
    } catch (error) {
      // Status and size checks can reject before the response body is consumed.
      controller.abort();
      if (error instanceof SentryExploreError) throw error;
      if (
        typeof error === 'object' &&
        error !== null &&
        (error as Error).name === 'AbortError'
      ) {
        throw new SentryExploreError(
          'TIMEOUT',
          'The Sentry request timed out.',
          { cause: error },
        );
      }
      throw new SentryExploreError(
        'UNAVAILABLE',
        'The Sentry request failed.',
        { cause: error },
      );
    } finally {
      clearTimeout(timeout);
    }
  }
}
