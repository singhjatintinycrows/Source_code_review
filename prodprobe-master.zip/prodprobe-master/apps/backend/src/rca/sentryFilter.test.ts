import { describe, expect, it, vi } from 'vitest';
import {
  SentryExploreClient,
  type SentryExploreScope,
} from './sentryExploreClient.js';

const scope: SentryExploreScope = {
  organizationSlug: 'acme',
  projectSlug: 'payments',
  projectId: '42',
  providerEnvironment: 'production',
  release: 'payments@v1',
};
const traceId = 'w3c:4bf92f35-00f067aa';
const window = {
  start: '2026-08-07T00:00:00.000Z',
  end: '2026-08-07T00:05:00.000Z',
};

describe.each([
  'ERRORS',
  'LOGS',
  'TRACES',
  'THROUGHPUT',
  'FAILURE_RATE',
] as const)('%s filter containment', (signal) => {
  const isMetric = signal === 'THROUGHPUT' || signal === 'FAILURE_RATE';
  const query = (
    client: SentryExploreClient,
    filter?: string,
    queryScope = scope,
    queryTraceId: string | undefined = traceId,
  ) => {
    const input = { ...window, scope: queryScope, filter };
    return signal === 'THROUGHPUT' || signal === 'FAILURE_RATE'
      ? client.queryMetricSeries({
          ...input,
          metric: signal,
          intervalSeconds: 60,
        })
      : client.queryTable({
          ...input,
          signal,
          traceId: queryTraceId,
          fields: ['id'],
          limit: 1,
        });
  };

  it.each([
    'level:error OR level:warning',
    '(level:error OR level:warning) !has:user.email',
    '((level:error or level:warning) aNd !has:user.email)',
    'message:"literal ) OR ( text"',
    String.raw`message:"say \"hello\" (again)"`,
    'message:""',
    'tag:[error,warning]',
    'tag:[error, warning]',
    'tag:[123,456] "quoted ) free text"',
    'tag:123,raw',
    'tag:>=-123.5k,raw AND "quoted ) free text"',
    'tag:123] message:"quoted ) tag value"',
    'tag:["a)b","c(d"]',
    '!tag:["a)b", warning, "c(d"]',
    'tag:["comma, ] bracket",plain]',
    'tags[custom:key]:"Cafe"',
    '!tags[custom:key]:["a)b","c(d"]',
    'p95(span.duration):>500',
    'count():>0 AND failure_rate():>0.1',
    'TypeError Anonymous function(app/foo)',
    'request failed at function(app/foo(bar))',
    '"whole quoted ) OR ( free text"',
    '("quoted (group)") OR level:error',
    'level:error "quoted ) free text"',
    'raw words OR "quoted ) free text"',
    'raw words level:error "quoted ) free text"',
    'raw words message:"quoted ) tag value"',
    '(raw words) "quoted ) free text"',
    '() OR "quoted ) free text"',
    '() level:error "quoted ) free text"',
    '(()) "quoted ) free text"',
    '(\u2028) "quoted ) free text"',
    'has:"custom:key" is:"unresolved"',
    'has:user.email ("quoted ) free text")',
    '!has:user.email "quoted ) free text"',
    'has:tags[custom:key] (message:"quoted ) tag value")',
    "tag:'ordinary' tag:'(balanced)'",
    'message:\u201cliteral (balanced)\u201d',
    'message:/error(foo|bar)/',
    'message:"literal `backticks` (here)"',
    'tag:["`a)b`","c(d"]',
    'message:Caf\u00e9\u00a0\u4e16\u754c',
    'message:"Caf\u00e9 \u4e16\u754c )"',
    'message:foo%22%20%29%20OR%20%28level:warning',
    'message:foo%2529',
    'level:error\\',
    'tag:a\\(b)',
    '  level:error  OR  level:warning  ',
    'x'.repeat(512),
    `  ${'x'.repeat(512)}  `,
    ...[1, 2, 3].flatMap((count) => [
      `message:"a${'\\'.repeat(count)}" ) OR ( still literal"`,
      `tag:["a${'\\'.repeat(count)}" ) OR ( literal","ok"]`,
      `"a${'\\'.repeat(count)}" ) OR ( still literal"`,
    ]),
  ])('keeps accepted filter %j conjunctive and unchanged', async (filter) => {
    const fetch = vi.fn(async (_url: URL) =>
      Response.json({ data: [{ id: 'event' }], timeSeries: [], meta: {} }),
    );
    const client = SentryExploreClient.fromConfig(
      { authToken: 'token' },
      fetch,
    );

    const result = await query(client, filter);

    expect(fetch).toHaveBeenCalledTimes(1);
    const request = fetch.mock.calls[0]![0];
    const prefix = `release:"payments@v1"${isMetric ? '' : ` trace:"${traceId}"`}`;
    expect(request.searchParams.get('query')).toBe(
      `${prefix} (${filter.trim()})`,
    );
    expect(request.pathname).toBe(
      `/api/0/organizations/acme/${isMetric ? 'events-timeseries' : 'events'}/`,
    );
    expect(request.searchParams.get('dataset')).toBe(
      isMetric || signal === 'TRACES' ? 'spans' : signal.toLowerCase(),
    );
    expect(request.searchParams.get('project')).toBe('42');
    expect(request.searchParams.get('environment')).toBe('production');
    expect(request.searchParams.get('start')).toBe(window.start);
    expect(request.searchParams.get('end')).toBe(window.end);
    expect(result).toEqual(
      isMetric
        ? { timeSeries: [], meta: {} }
        : { data: [{ id: 'event' }], page: { hasMore: false } },
    );
  });

  it.each([
    'level:error) OR (level:warning',
    'foo" ) OR (level:warning bar"',
    'foo " ) OR (level:warning bar"',
    "tag:'a) OR (tag:b'",
    String.raw`tag:a\) OR \(tag:b`,
    'tag:[a) OR (tag:b]',
    'tag:\u201ca) OR (tag:b\u201d',
    'message:/a) OR (level:warning/',
    '(level:error',
    'level:error)',
    '((level:error)',
    'message:"unterminated',
    '"unterminated',
    'message:`a) OR (level:warning`',
    'count_if(`level:error`):>0',
    'count("a)b"):>0',
    'count(foo OR "a)b"):>0',
    'p95("span.duration"):>500',
    'raw (message:"a)b")',
    '() " ) OR (level:warning"',
    '(   ) " ) OR (level:warning"',
    '()" ) OR (level:warning"',
    'tag:["a)b","c(d"]junk',
    'tag:["a)b"junk,"c(d"]',
    'tag:["a)b" "c(d"]',
    'tag:["a)b",,"c(d"]',
    'tag:["a)b",]',
    'tag:["a)b","c(d"',
    'tag:[ "a)b","c(d"]',
    'tag:[a, "b)c"',
    'tag:[a" ) OR (tag:b"]',
    'prefix:tag:["a)b","c(d"]',
    'is:["a)b","c(d"]',
    'has:["a)b",tag:c]',
    'message:"a) OR (level:warning"junk',
    'message:"a) OR (level:warning"(other)',
    '@message:"a) OR (level:warning"',
    'prefix:message:"a) OR (level:warning"',
    'tag:123,raw " ) OR (level:warning"',
    'tag:123] " ) OR (level:warning"',
    'tag:>=-123.5k,raw " ) OR (level:warning"',
    'is:1] " ) OR (level:warning"',
    'has:1,raw " ) OR (level:warning"',
    'tags[bad/key]:"a) OR (level:warning"',
    'tags[custom:key, string]:"literal (value)"',
    'flags[custom:key]:"literal (value)"',
    '"custom:key":"literal (value)"',
    'message:="literal (value)"',
    'message:>"a) OR (level:warning"',
    'is:!="a) OR (level:warning"',
    'has:user.email:raw "a) OR (level:warning"',
    'has:user.email] "a) OR (level:warning"',
    'has:tags[custom:key]:raw "a) OR (level:warning"',
    'has:user.email\u2028 "a) OR (level:warning"',
    'has:user.email\u2029 "a) OR (level:warning"',
    'level:error raw "a) OR (level:warning"',
    'raw OR("a) OR (level:warning")',
    'raw\u00a0" ) OR (level:warning"',
    'message:"a) OR (level:warning"\u00a0junk',
    'message:\u00a0" ) OR (level:warning"',
    'level:error\nOR level:warning',
    'level:error\tOR level:warning',
    'message:"nul\u0000inside"',
    'message:"delete\u007finside"',
    'message:"control\u0085inside"',
    '\tlevel:error',
    'level:error\n',
    ...[1, 2, 3].flatMap((count) => [
      `message:"trailing${'\\'.repeat(count)}"`,
      `message:"a${'\\'.repeat(count)}") OR (level:warning`,
      `tag:["trailing${'\\'.repeat(count)}"]`,
    ]),
  ])('rejects unsafe or ambiguous filter %j before HTTP', async (filter) => {
    const fetch = vi.fn(async (_url: URL) =>
      Response.json({ data: [], timeSeries: [], meta: {} }),
    );
    const client = SentryExploreClient.fromConfig(
      { authToken: 'token' },
      fetch,
    );

    await expect(query(client, filter)).rejects.toMatchObject({
      name: 'SentryExploreError',
      code: 'INVALID_REQUEST',
      message: expect.stringContaining('filter cannot be safely grouped'),
    });
    expect(fetch).not.toHaveBeenCalled();
  });

  it.each([
    '',
    '   ',
    'x'.repeat(513),
  ])('retains the nonBlank 512-character bound for %j', async (filter) => {
    const fetch = vi.fn();
    const client = SentryExploreClient.fromConfig(
      { authToken: 'token' },
      fetch,
    );
    await expect(query(client, filter)).rejects.toMatchObject({
      code: 'INVALID_REQUEST',
      message: 'The Sentry filter is invalid.',
    });
    expect(fetch).not.toHaveBeenCalled();
  });

  it.each([
    undefined,
    'level:error OR level:warning',
  ])('preserves optional release/filter composition for %j', async (filter) => {
    const fetch = vi.fn(async (_url: URL) =>
      Response.json({ data: [], timeSeries: [], meta: {} }),
    );
    const client = SentryExploreClient.fromConfig(
      { authToken: 'token' },
      fetch,
    );
    await query(client, filter, { ...scope, release: undefined });
    const terms = isMetric ? [] : [`trace:"${traceId}"`];
    if (filter !== undefined) terms.push(`(${filter})`);
    expect(fetch.mock.calls[0]![0].searchParams.get('query')).toBe(
      terms.length ? terms.join(' ') : null,
    );
  });

  it.each([
    [400, 'INVALID_REQUEST', 'Sentry rejected the evidence query.'],
    [
      401,
      'AUTHENTICATION_FAILED',
      'Sentry rejected the configured credential.',
    ],
    [
      403,
      'AUTHENTICATION_FAILED',
      'Sentry rejected the configured credential.',
    ],
    [429, 'RATE_LIMITED', 'Sentry rate-limited this evidence request.'],
    [503, 'UNAVAILABLE', 'Sentry is temporarily unavailable.'],
  ] as const)('preserves provider error mapping for HTTP %s', async (status, code, message) => {
    const fetch = vi.fn(async (_url: URL) => new Response(null, { status }));
    const client = SentryExploreClient.fromConfig(
      { authToken: 'token' },
      fetch,
    );
    await expect(
      query(client, 'unknown.field:>nonsense'),
    ).rejects.toMatchObject({
      code,
      message,
    });
    expect(fetch).toHaveBeenCalledTimes(1);
  });

  if (!isMetric) {
    it.each([
      1, 2, 3,
    ])('rejects %s trailing trace backslashes that could swallow the filter wrapper', async (count) => {
      const fetch = vi.fn();
      const client = SentryExploreClient.fromConfig(
        { authToken: 'token' },
        fetch,
      );
      await expect(
        query(
          client,
          'message:" OR (level:warning"',
          scope,
          `trace${'\\'.repeat(count)}`,
        ),
      ).rejects.toMatchObject({
        code: 'INVALID_REQUEST',
        message: 'The Sentry traceId cannot end with a backslash.',
      });
      expect(fetch).not.toHaveBeenCalled();
    });

    it.each([
      String.raw`trace\middle`,
      'trace" (literal)',
      ' trace ',
    ])('does not otherwise narrow the trace contract for %j', async (value) => {
      const fetch = vi.fn(async (_url: URL) => Response.json({ data: [] }));
      const client = SentryExploreClient.fromConfig(
        { authToken: 'token' },
        fetch,
      );
      await query(client, 'level:error', scope, value);
      expect(fetch.mock.calls[0]![0].searchParams.get('query')).toBe(
        `release:"payments@v1" trace:"${value.trim().replaceAll('\\', '\\\\').replaceAll('"', '\\"')}" (level:error)`,
      );
    });
  }
});
