import { once } from 'node:events';
import { createServer } from 'node:http';
import { afterEach, describe, expect, it, vi } from 'vitest';
import { SentryExploreClient } from './sentryExploreClient.js';

const scope = {
  organizationSlug: 'acme',
  projectSlug: 'payments',
  projectId: '42',
  providerEnvironment: 'production',
  release: 'a'.repeat(40),
};

describe('SentryExploreClient', () => {
  afterEach(() => {
    vi.restoreAllMocks();
  });

  it('resolves a project slug by stable project ID', async () => {
    let request: URL | undefined;
    const client = SentryExploreClient.fromConfig(
      { authToken: 'token-with-at-least-sixteen-characters' },
      async (url) => {
        request = url;
        return new Response(
          JSON.stringify({ id: '42', slug: 'renamed-payments' }),
        );
      },
    );

    await expect(client.resolveProjectById('acme', '42')).resolves.toEqual({
      id: '42',
      slug: 'renamed-payments',
    });
    expect(request?.pathname).toBe('/api/0/projects/acme/42/');
  });

  it('rejects an invalid project response', async () => {
    const client = SentryExploreClient.fromConfig(
      { authToken: 'token-with-at-least-sixteen-characters' },
      async () => new Response(JSON.stringify([])),
    );

    await expect(client.resolveProjectById('acme', '42')).rejects.toThrow(
      'invalid project response',
    );
  });

  it('clears successful request timeouts without aborting the completed request', async () => {
    vi.useFakeTimers();
    try {
      let signal: AbortSignal | undefined;
      const client = SentryExploreClient.fromConfig(
        { authToken: 'test-token' },
        async (_url, init) => {
          signal = init?.signal ?? undefined;
          return Response.json({ id: '42', slug: 'payments' });
        },
      );
      await expect(client.resolveProjectById('acme', '42')).resolves.toEqual({
        id: '42',
        slug: 'payments',
      });
      expect(signal?.aborted).toBe(false);
      expect(vi.getTimerCount()).toBe(0);
      await vi.advanceTimersByTimeAsync(10_001);
      expect(signal?.aborted).toBe(false);
    } finally {
      vi.useRealTimers();
    }
  });

  it('queries the bounded logs dataset and returns the provider cursor', async () => {
    let request: URL | undefined;
    const client = SentryExploreClient.fromConfig(
      {
        authToken: 'token-with-at-least-sixteen-characters',
        nodeEnvironment: 'test',
      },
      async (url) => {
        request = url;
        return new Response(
          JSON.stringify({ data: [{ message: 'payment failed' }], meta: {} }),
          {
            headers: {
              link: '<https://sentry.io/api/0/organizations/acme/events/?cursor=next-page>; rel="next"; results="true"',
            },
          },
        );
      },
    );

    const result = await client.queryTable({
      signal: 'LOGS',
      fields: [
        'sentry.item_id',
        'timestamp',
        'message',
        'severity',
        'trace',
        'span_id',
        'request_id',
        'error.type',
      ],
      scope,
      start: '2026-08-07T00:00:00.000Z',
      end: '2026-08-07T00:05:00.000Z',
      limit: 100,
    });

    expect(request?.pathname).toBe('/api/0/organizations/acme/events/');
    expect(request?.searchParams.get('dataset')).toBe('logs');
    expect(request?.searchParams.get('project')).toBe('42');
    expect(request?.searchParams.get('query')).toContain('release:');
    expect(request?.searchParams.get('per_page')).toBe('25');
    expect(result.page).toEqual({ hasMore: true, nextCursor: 'next-page' });
    expect(result.data).toHaveLength(1);
  });

  it('parses nextCursor from relative URL link headers', async () => {
    const client = SentryExploreClient.fromConfig(
      {
        authToken: 'token-with-at-least-sixteen-characters',
        nodeEnvironment: 'test',
      },
      async () =>
        new Response(JSON.stringify({ data: [{ id: '1' }], meta: {} }), {
          headers: {
            link: '</api/0/organizations/acme/events/?cursor=relative-cursor-123>; rel="next"; results="true"',
          },
        }),
    );

    const result = await client.queryTable({
      signal: 'ERRORS',
      fields: ['id'],
      scope,
      start: '2026-08-07T00:00:00.000Z',
      end: '2026-08-07T00:05:00.000Z',
      limit: 10,
    });

    expect(result.page).toEqual({
      hasMore: true,
      nextCursor: 'relative-cursor-123',
    });
  });

  it('queries Sentry spans as a bounded throughput time series', async () => {
    let request: URL | undefined;
    const client = SentryExploreClient.fromConfig(
      {
        authToken: 'token-with-at-least-sixteen-characters',
        nodeEnvironment: 'test',
      },
      async (url) => {
        request = url;
        return new Response(JSON.stringify({ timeSeries: [], meta: {} }));
      },
    );

    await client.queryMetricSeries({
      scope,
      start: '2026-08-07T00:00:00.000Z',
      end: '2026-08-07T00:05:00.000Z',
      metric: 'THROUGHPUT',
      intervalSeconds: 60,
    });

    expect(request?.pathname).toBe(
      '/api/0/organizations/acme/events-timeseries/',
    );
    expect(request?.searchParams.get('dataset')).toBe('spans');
    expect(request?.searchParams.get('yAxis')).toBe('count()');
    expect(request?.searchParams.get('interval')).toBe('60');
  });

  it.each([
    60, 120, 300, 600, 900, 1_800, 3_600,
  ])('sends supported metric bucket %s unchanged, including a bucket equal to the window', async (intervalSeconds) => {
    const fetch = vi.fn(async (_url: URL) =>
      Response.json({ timeSeries: [], meta: {} }),
    );
    const client = SentryExploreClient.fromConfig(
      { authToken: 'token' },
      fetch,
    );
    await client.queryMetricSeries({
      scope,
      start: '2026-08-07T00:00:00.000Z',
      end: '2026-08-07T01:00:00.000Z',
      metric: 'FAILURE_RATE',
      intervalSeconds,
    });
    const params = fetch.mock.calls[0]![0].searchParams;
    expect(params.get('interval')).toBe(String(intervalSeconds));
    expect(params.get('yAxis')).toBe('failure_rate()');
  });

  it.each([
    59,
    61,
    90,
    241,
    3_601,
    Number.NaN,
    Infinity,
    60.5,
  ])('rejects unsupported metric bucket %s before HTTP dispatch', async (intervalSeconds) => {
    const fetch = vi.fn();
    const client = SentryExploreClient.fromConfig(
      { authToken: 'token' },
      fetch,
    );
    await expect(
      client.queryMetricSeries({
        scope,
        start: '2026-08-07T00:00:00.000Z',
        end: '2026-08-07T01:00:00.000Z',
        metric: 'THROUGHPUT',
        intervalSeconds,
      }),
    ).rejects.toMatchObject({ code: 'INVALID_REQUEST' });
    expect(fetch).not.toHaveBeenCalled();
  });

  it('rejects a supported metric bucket larger than the window without fetching', async () => {
    const fetch = vi.fn();
    const client = SentryExploreClient.fromConfig(
      { authToken: 'token' },
      fetch,
    );
    await expect(
      client.queryMetricSeries({
        scope,
        start: '2026-08-07T00:00:00.000Z',
        end: '2026-08-07T00:04:00.000Z',
        metric: 'THROUGHPUT',
        intervalSeconds: 300,
      }),
    ).rejects.toMatchObject({ code: 'INVALID_REQUEST' });
    expect(fetch).not.toHaveBeenCalled();
  });

  describe.each([
    'ERRORS',
    'LOGS',
    'TRACES',
    'THROUGHPUT',
    'FAILURE_RATE',
  ] as const)('%s literal releases', (signal) => {
    const query = (client: SentryExploreClient, release?: string) => {
      const input = {
        scope: { ...scope, release },
        start: '2026-08-07T00:00:00.000Z',
        end: '2026-08-07T00:05:00.000Z',
        filter: 'level:error',
      };
      return signal === 'THROUGHPUT' || signal === 'FAILURE_RATE'
        ? client.queryMetricSeries({
            ...input,
            metric: signal,
            intervalSeconds: 60,
          })
        : client.queryTable({
            ...input,
            signal,
            fields: ['timestamp'],
            limit: 1,
            traceId: 'w3c:4bf92f35-00f067aa',
          });
    };

    it.each([
      ['payments@v1', 'release:"payments@v1"'],
      ['payments@"v1" (blue)', 'release:"payments@\\"v1\\" (blue)"'],
      ['payments@v1**', 'release:"payments@v1\\*\\*"'],
      ['*', 'release:"\\*"'],
      ['[v1,v2]', 'release:"[v1,v2]"'],
      [undefined, undefined],
    ])('preserves literal release %s and query grouping', async (release, term) => {
      const fetch = vi.fn(async (_url: URL) =>
        Response.json({ data: [], timeSeries: [], meta: {} }),
      );
      const client = SentryExploreClient.fromConfig(
        { authToken: 'token' },
        fetch,
      );
      await query(client, release);
      const terms = term ? [term] : [];
      if (signal !== 'THROUGHPUT' && signal !== 'FAILURE_RATE') {
        terms.push('trace:"w3c:4bf92f35-00f067aa"');
      }
      terms.push('(level:error)');
      expect(fetch.mock.calls[0]![0].searchParams.get('query')).toBe(
        terms.join(' '),
      );
    });

    it.each([
      'latest',
      ' latest ',
      'payments\\v1',
      'payments\\*',
    ])('rejects unrepresentable release %s before HTTP dispatch', async (release) => {
      const fetch = vi.fn();
      const client = SentryExploreClient.fromConfig(
        { authToken: 'token' },
        fetch,
      );
      await expect(query(client, release)).rejects.toMatchObject({
        code: 'INVALID_REQUEST',
        message: 'The Sentry release cannot be matched literally.',
      });
      expect(fetch).not.toHaveBeenCalled();
    });
  });

  it('queries bounded issue metadata with enforced scope, time bounds, and cursors', async () => {
    let request: URL | undefined;
    const client = SentryExploreClient.fromConfig(
      {
        authToken: 'token-with-at-least-sixteen-characters',
        nodeEnvironment: 'test',
      },
      async (url) => {
        request = url;
        return new Response(
          JSON.stringify(
            Array.from({ length: 26 }, () => ({
              id: '123',
              shortId: 'PAYMENTS-1',
              title: 'Payment failures',
              level: 'error',
              firstSeen: '2026-08-07T00:01:00.000Z',
              lastSeen: '2026-08-07T00:04:00.000Z',
              user: { email: 'not-projected@example.com' },
            })),
          ),
          {
            headers: {
              link: '</api/0/organizations/acme/issues/?cursor=next-page>; rel="next"; results="true"',
            },
          },
        );
      },
    );

    const result = await client.queryAlerts({
      scope,
      start: '2026-08-07T00:00:00.000Z',
      end: '2026-08-07T00:05:00.000Z',
      filter: 'is:unresolved',
      limit: 100,
      cursor: 'current-page',
    });

    expect(request?.pathname).toBe('/api/0/organizations/acme/issues/');
    expect(request?.searchParams.get('project')).toBe('42');
    expect(request?.searchParams.get('environment')).toBe('production');
    expect(request?.searchParams.get('limit')).toBe('25');
    expect(request?.searchParams.get('query')).toBe(
      `has:environment release:"${scope.release}" is:unresolved`,
    );
    expect(request?.searchParams.has('release')).toBe(false);
    expect(request?.searchParams.get('start')).toBe('2026-08-07T00:00:00.000Z');
    expect(request?.searchParams.get('end')).toBe('2026-08-07T00:05:00.000Z');
    expect(request?.searchParams.has('statsPeriod')).toBe(false);
    expect(request?.searchParams.get('cursor')).toBe('current-page');
    expect(result.page).toEqual({ hasMore: true, nextCursor: 'next-page' });
    expect(result.data).toEqual(
      Array(25).fill({
        id: '123',
        shortId: 'PAYMENTS-1',
        title: 'Payment failures',
        level: 'error',
        firstSeen: '2026-08-07T00:01:00.000Z',
        lastSeen: '2026-08-07T00:04:00.000Z',
      }),
    );
  });

  it.each([
    ['payments@"v1" (blue)', 'release:"payments@\\"v1\\" (blue)"'],
    ['payments@v1*', 'release:"payments@v1\\*"'],
    ['[v1,v2]', 'release:"[v1,v2]"'],
  ])('matches the alert release %s literally', async (release, releaseQuery) => {
    let request: URL | undefined;
    const client = SentryExploreClient.fromConfig(
      { authToken: 'token-with-at-least-sixteen-characters' },
      async (url) => {
        request = url;
        return new Response(JSON.stringify([]));
      },
    );

    await client.queryAlerts({
      scope: { ...scope, release },
      start: '2026-08-07T00:00:00.000Z',
      end: '2026-08-07T00:05:00.000Z',
      filter: 'is:resolved level:error',
      limit: 25,
    });

    expect(request?.searchParams.get('query')).toBe(
      `has:environment ${releaseQuery} is:resolved level:error`,
    );
  });

  it.each([
    'latest',
    ' latest ',
    'payments\\v1',
  ])('rejects an unsupported literal alert release %s before requesting evidence', async (release) => {
    const fetch = vi.fn(async () => new Response(JSON.stringify([])));
    const client = SentryExploreClient.fromConfig(
      { authToken: 'token-with-at-least-sixteen-characters' },
      fetch,
    );

    await expect(
      client.queryAlerts({
        scope: { ...scope, release },
        start: '2026-08-07T00:00:00.000Z',
        end: '2026-08-07T00:05:00.000Z',
        limit: 25,
      }),
    ).rejects.toMatchObject({
      code: 'INVALID_REQUEST',
      message: 'The Sentry release cannot be matched literally.',
    });
    expect(fetch).not.toHaveBeenCalled();
  });

  it.each([
    undefined,
    'a'.repeat(32),
  ])('keeps environment-only alert queries scoped with filter %s', async (filter) => {
    let request: URL | undefined;
    const client = SentryExploreClient.fromConfig(
      { authToken: 'token-with-at-least-sixteen-characters' },
      async (url) => {
        request = url;
        return new Response(JSON.stringify([]));
      },
    );

    await client.queryAlerts({
      scope: { ...scope, projectId: undefined, release: undefined },
      start: '2026-08-07T00:00:00.000Z',
      end: '2026-08-07T00:05:00.000Z',
      filter,
      limit: 25,
    });

    expect(request?.pathname).toBe('/api/0/organizations/acme/issues/');
    expect(request?.searchParams.get('project')).toBe('payments');
    expect(request?.searchParams.get('environment')).toBe('production');
    expect(request?.searchParams.get('query')).toBe(
      `has:environment ${filter ?? 'is:unresolved'}`,
    );
    expect(request?.searchParams.has('shortIdLookup')).toBe(false);
  });

  it('excludes issue metadata outside the requested alert interval', async () => {
    const client = SentryExploreClient.fromConfig(
      { authToken: 'token-with-at-least-sixteen-characters' },
      async () =>
        new Response(
          JSON.stringify([
            {
              id: 'before',
              firstSeen: '2026-08-06T00:00:00.000Z',
              lastSeen: '2026-08-06T01:00:00.000Z',
            },
            {
              id: 'after',
              firstSeen: '2026-08-08T00:00:00.000Z',
              lastSeen: '2026-08-08T01:00:00.000Z',
            },
            {
              id: 'overlap',
              firstSeen: '2026-08-07T00:04:00.000Z',
              lastSeen: '2026-08-07T00:06:00.000Z',
            },
            { id: 'invalid', firstSeen: 'not-a-date', lastSeen: 'not-a-date' },
          ]),
        ),
    );

    const result = await client.queryAlerts({
      scope,
      start: '2026-08-07T00:00:00.000Z',
      end: '2026-08-07T00:05:00.000Z',
      limit: 25,
    });

    expect(result.data).toEqual([
      {
        id: 'overlap',
        firstSeen: '2026-08-07T00:04:00.000Z',
        lastSeen: '2026-08-07T00:06:00.000Z',
      },
    ]);
  });

  describe('scoped alert statistics', () => {
    const issue = {
      id: 'issue-1',
      title: 'Payment failures',
      status: 'unresolved',
      count: '101',
      firstSeen: '2026-08-07T00:00:30.000Z',
      lastSeen: '2026-08-07T00:04:30.000Z',
    };
    const scoped = {
      firstSeen: '2026-08-07T00:02:00.000Z',
      lastSeen: '2026-08-07T00:03:00.000Z',
    };
    const query = {
      scope: { ...scope, release: 'v2' },
      start: '2026-08-07T00:00:00.000Z',
      end: '2026-08-07T00:05:00.000Z',
      limit: 25,
    };

    it.each([
      '1',
      1,
      '0',
      0,
    ])('uses filtered count %s and timestamps without leaking other filtered fields', async (count) => {
      const client = SentryExploreClient.fromConfig(
        { authToken: 'test-token' },
        async () =>
          Response.json([
            {
              ...issue,
              filtered: {
                ...scoped,
                count,
                title: 'Not the issue title',
                userCount: 99,
              },
            },
          ]),
      );
      const result = await client.queryAlerts(query);
      expect(result.data).toEqual([{ ...issue, ...scoped, count }]);
      expect(result.data[0]).not.toHaveProperty('filtered');
      expect(result.data[0]).not.toHaveProperty('userCount');
    });

    it.each([
      undefined,
      null,
    ])('retains top-level statistics when filtered statistics are %s', async (filtered) => {
      const client = SentryExploreClient.fromConfig(
        { authToken: 'test-token' },
        async () => Response.json([{ ...issue, filtered }]),
      );
      expect((await client.queryAlerts(query)).data).toEqual([issue]);
    });

    it.each([
      {
        count: '1',
        firstSeen: '2026-08-06T00:00:00.000Z',
        lastSeen: '2026-08-06T01:00:00.000Z',
      },
      {
        count: '1',
        firstSeen: '2026-08-08T00:00:00.000Z',
        lastSeen: '2026-08-08T01:00:00.000Z',
      },
      { count: '0', firstSeen: null, lastSeen: null },
      { count: '1', firstSeen: 'invalid', lastSeen: scoped.lastSeen },
      {},
    ])('does not borrow broader timestamps to pass the overlap check: %j', async (filtered) => {
      const client = SentryExploreClient.fromConfig(
        { authToken: 'test-token' },
        async () => Response.json([{ ...issue, filtered }]),
      );
      expect((await client.queryAlerts(query)).data).toEqual([]);
    });

    it('can use valid filtered dates without top-level dates', async () => {
      const client = SentryExploreClient.fromConfig(
        { authToken: 'test-token' },
        async () =>
          Response.json([
            { id: issue.id, count: '101', filtered: { ...scoped, count: '1' } },
          ]),
      );
      expect((await client.queryAlerts(query)).data).toEqual([
        { id: issue.id, ...scoped, count: '1' },
      ]);
    });
  });

  it('uses the spans dataset for trace evidence', async () => {
    let request: URL | undefined;
    const client = SentryExploreClient.fromConfig(
      {
        authToken: 'token-with-at-least-sixteen-characters',
        nodeEnvironment: 'test',
      },
      async (url) => {
        request = url;
        return new Response(JSON.stringify({ data: [], meta: {} }));
      },
    );

    await client.queryTable({
      signal: 'TRACES',
      fields: [
        'id',
        'trace',
        'span.op',
        'span.description',
        'span.status',
        'span.duration',
        'timestamp',
        'transaction',
      ],
      scope,
      start: '2026-08-07T00:00:00.000Z',
      end: '2026-08-07T00:05:00.000Z',
      limit: 25,
    });

    expect(request?.searchParams.get('dataset')).toBe('spans');
  });

  it('rejects declared Sentry responses over the evidence size limit', async () => {
    let signal: AbortSignal | undefined;
    const client = SentryExploreClient.fromConfig(
      {
        authToken: 'token-with-at-least-sixteen-characters',
        nodeEnvironment: 'test',
      },
      async (_url, init) => {
        signal = init?.signal ?? undefined;
        return new Response(JSON.stringify({ data: [], meta: {} }), {
          headers: { 'content-length': String(2 * 1024 * 1024 + 1) },
        });
      },
    );

    await expect(
      client.queryTable({
        signal: 'LOGS',
        fields: [
          'sentry.item_id',
          'timestamp',
          'message',
          'severity',
          'trace',
          'span_id',
          'request_id',
          'error.type',
        ],
        scope,
        start: '2026-08-07T00:00:00.000Z',
        end: '2026-08-07T00:05:00.000Z',
        limit: 25,
      }),
    ).rejects.toMatchObject({ code: 'RESPONSE_TOO_LARGE' });
    expect(signal?.aborted).toBe(true);
  });

  it.each([
    ['declared oversize', 200, 2 * 1024 * 1024 + 1, 1, 'RESPONSE_TOO_LARGE'],
    [
      'streamed oversize',
      200,
      undefined,
      2 * 1024 * 1024 + 1,
      'RESPONSE_TOO_LARGE',
    ],
    ['rate limit', 429, 1000, 1, 'RATE_LIMITED'],
    ['server error', 503, 1000, 1, 'UNAVAILABLE'],
  ] as const)('closes an unfinished HTTP response on %s', async (_name, status, declaredLength, bodyLength, code) => {
    let responseClosed!: () => void;
    const closed = new Promise<void>((resolve) => {
      responseClosed = resolve;
    });
    const server = createServer((_request, response) => {
      response.once('close', responseClosed);
      response.writeHead(status, {
        'content-type': 'application/json',
        ...(declaredLength === undefined
          ? {}
          : { 'content-length': String(declaredLength) }),
      });
      // Leave the response unfinished so only cancellation can close it.
      response.write(Buffer.alloc(bodyLength));
    });
    let deadline: ReturnType<typeof setTimeout> | undefined;
    server.listen(0, '127.0.0.1');
    try {
      await once(server, 'listening');
      const address = server.address();
      if (!address || typeof address === 'string')
        throw new Error('Expected a loopback port');
      const client = SentryExploreClient.fromConfig(
        { authToken: 'test-token' },
        (_url, init) =>
          globalThis.fetch(`http://127.0.0.1:${address.port}/`, init),
      );
      await expect(
        client.queryTable({
          signal: 'ERRORS',
          fields: ['id'],
          scope,
          start: '2026-08-07T00:00:00.000Z',
          end: '2026-08-07T00:05:00.000Z',
          limit: 1,
        }),
      ).rejects.toMatchObject({ code });
      await Promise.race([
        closed,
        new Promise<never>((_resolve, reject) => {
          deadline = setTimeout(
            () => reject(new Error('Provider response was not closed')),
            2000,
          );
        }),
      ]);
    } finally {
      clearTimeout(deadline);
      if (server.listening) {
        await new Promise<void>((resolve, reject) => {
          server.close((error) => (error ? reject(error) : resolve()));
          server.closeAllConnections();
        });
      }
    }
  });

  it('returns only the backend-selected table projection', async () => {
    const client = SentryExploreClient.fromConfig(
      {
        authToken: 'token-with-at-least-sixteen-characters',
        nodeEnvironment: 'test',
      },
      async () =>
        new Response(
          JSON.stringify({
            data: [
              {
                id: 'span-1',
                trace: 'a'.repeat(32),
                'span.description': 'payload='.concat('x'.repeat(4_000)),
                'span.status': 'internal_error',
                unrequestedPayload: { customerEmail: 'secret@example.com' },
              },
            ],
            meta: {
              dataset: 'spans',
              fields: { 'span.description': 'string' },
              accuracy: [{ unbounded: 'x'.repeat(4_000) }],
            },
          }),
        ),
    );

    const result = await client.queryTable({
      signal: 'TRACES',
      fields: [
        'id',
        'trace',
        'span.op',
        'span.description',
        'span.status',
        'span.duration',
        'timestamp',
        'transaction',
      ],
      scope,
      start: '2026-08-07T00:00:00.000Z',
      end: '2026-08-07T00:05:00.000Z',
      limit: 100,
    });

    expect(result.data).toEqual([
      expect.objectContaining({
        id: 'span-1',
        trace: 'a'.repeat(32),
        'span.status': 'internal_error',
      }),
    ]);
    expect(
      (result.data[0] as Record<string, unknown>).unrequestedPayload,
    ).toBeUndefined();
    expect(
      ((result.data[0] as Record<string, string>)['span.description'] ?? '')
        .length,
    ).toBeGreaterThan(512);
  });

  it.each([
    'redirected',
    'reused',
  ] as const)('uses the stable project ID when the stored slug is %s', async (oldSlugState) => {
    const fetch = vi.fn(async (url: URL, _init?: RequestInit) => {
      if (url.pathname.includes('/old-project/')) {
        return oldSlugState === 'redirected'
          ? new Response(null, {
              status: 302,
              headers: { location: '/api/0/projects/acme/renamed-project/' },
            })
          : Response.json(
              url.pathname.endsWith('/values/')
                ? [{ name: 'other-project' }]
                : [],
            );
      }
      return Response.json(
        url.pathname.endsWith('/tags/environment/values/')
          ? [{ name: 'production' }]
          : [],
      );
    });
    const client = SentryExploreClient.fromConfig(
      { authToken: 'test-token' },
      fetch,
    );
    const result = await client.discoverContext({
      organizationSlug: 'acme',
      projectSlug: 'old-project',
      projectId: '42',
    });
    expect(result.alerts).toEqual({ availability: 'AVAILABLE', values: [] });
    expect(result.environments).toEqual({
      availability: 'AVAILABLE',
      values: ['production'],
    });
    expect(
      Object.values(result).every(
        (section) => section.availability === 'AVAILABLE',
      ),
    ).toBe(true);
    expect(fetch).toHaveBeenCalledTimes(4);
    const requests = fetch.mock.calls.map(([url]) => url);
    expect(requests.map((url) => url.pathname)).toContain(
      '/api/0/projects/acme/42/issues/',
    );
    expect(requests.map((url) => url.pathname)).toContain(
      '/api/0/projects/acme/42/tags/environment/values/',
    );
    expect(requests.some((url) => url.pathname.includes('/old-project/'))).toBe(
      false,
    );
    expect(
      requests
        .filter((url) => url.pathname.includes('/organizations/'))
        .every((url) => url.searchParams.get('project') === '42'),
    ).toBe(true);
    expect(
      fetch.mock.calls.every(([, init]) => init?.redirect === 'error'),
    ).toBe(true);
  });

  it.each([
    undefined,
    null,
  ])('retains slug-only discovery when project ID is %s', async (projectId) => {
    const fetch = vi.fn(async (_url: URL) => Response.json([]));
    const client = SentryExploreClient.fromConfig(
      { authToken: 'test-token' },
      fetch,
    );
    await client.discoverContext({
      organizationSlug: 'acme',
      projectSlug: 'payments',
      projectId,
    });
    const requests = fetch.mock.calls.map(([url]) => url);
    expect(requests.map((url) => url.pathname)).toContain(
      '/api/0/projects/acme/payments/issues/',
    );
    expect(requests.map((url) => url.pathname)).toContain(
      '/api/0/projects/acme/payments/tags/environment/values/',
    );
    expect(
      requests
        .filter((url) => url.pathname.includes('/organizations/'))
        .every((url) => url.searchParams.get('project') === 'payments'),
    ).toBe(true);
  });

  it.each([
    'not-an-id',
    '../payments',
    '42,43',
  ])('rejects invalid discovery project ID %s before dispatch', async (projectId) => {
    const fetch = vi.fn(async () => Response.json([]));
    const client = SentryExploreClient.fromConfig(
      { authToken: 'test-token' },
      fetch,
    );
    await expect(
      client.discoverContext({
        organizationSlug: 'acme',
        projectSlug: 'payments',
        projectId,
      }),
    ).rejects.toMatchObject({ code: 'INVALID_REQUEST' });
    expect(fetch).not.toHaveBeenCalled();
  });

  it('discovers bounded environment, release, and tag metadata without telemetry rows', async () => {
    const requests: URL[] = [];
    const client = SentryExploreClient.fromConfig(
      { authToken: 'token-with-at-least-sixteen-characters' },
      async (url) => {
        requests.push(url);
        if (url.pathname.endsWith('/tags/environment/values/')) {
          return new Response(
            JSON.stringify([{ name: 'staging' }, { name: 'production' }]),
          );
        }
        if (url.pathname.endsWith('/issues/')) {
          return new Response(JSON.stringify([]));
        }
        if (url.pathname.endsWith('/releases/')) {
          return new Response(
            JSON.stringify([
              {
                version: 'hp-demo@abc123',
                shortVersion: 'abc123',
                dateCreated: '2026-08-08T00:00:00Z',
              },
            ]),
          );
        }
        if (url.pathname.endsWith('/tags/')) {
          return new Response(
            JSON.stringify([
              { key: 'environment', name: 'Environment', totalValues: 2 },
              { key: 'transaction', name: 'Transaction', totalValues: 12 },
            ]),
          );
        }
        throw new Error(`Unexpected Sentry request: ${url}`);
      },
    );

    const result = await client.discoverContext({
      organizationSlug: 'acme',
      projectSlug: 'payments',
      projectId: '42',
    });

    expect(result.environments).toEqual({
      availability: 'AVAILABLE',
      values: ['production', 'staging'],
    });
    expect(result.releases).toEqual({
      availability: 'AVAILABLE',
      values: [
        {
          version: 'hp-demo@abc123',
          shortVersion: 'abc123',
          dateCreated: '2026-08-08T00:00:00Z',
        },
      ],
    });
    expect(result.tags).toEqual({
      availability: 'AVAILABLE',
      values: [
        { key: 'environment', name: 'Environment', totalValues: 2 },
        { key: 'transaction', name: 'Transaction', totalValues: 12 },
      ],
    });
    expect(result.alerts).toEqual({ availability: 'AVAILABLE', values: [] });
    expect(requests).toHaveLength(4);
    expect(
      requests
        .find((request) => request.pathname.endsWith('/releases/'))
        ?.searchParams.get('project'),
    ).toBe('42');
  });

  it('discovers tag values using value property fallback when name is omitted', async () => {
    const client = SentryExploreClient.fromConfig(
      { authToken: 'token-with-at-least-sixteen-characters' },
      async (url) => {
        if (url.pathname.endsWith('/tags/environment/values/')) {
          return new Response(
            JSON.stringify([{ value: 'staging' }, { value: 'production' }]),
          );
        }
        if (url.pathname.endsWith('/issues/')) {
          return new Response(JSON.stringify([]));
        }
        if (url.pathname.endsWith('/releases/')) {
          return new Response(JSON.stringify([]));
        }
        if (url.pathname.endsWith('/tags/')) {
          return new Response(JSON.stringify([]));
        }
        throw new Error(`Unexpected Sentry request: ${url}`);
      },
    );

    const result = await client.discoverContext({
      organizationSlug: 'acme',
      projectSlug: 'payments',
      projectId: '42',
    });

    expect(result.environments).toEqual({
      availability: 'AVAILABLE',
      values: ['production', 'staging'],
    });
    expect(result.alerts).toEqual({ availability: 'AVAILABLE', values: [] });
  });

  it('reports a discovery section as unavailable without suppressing other metadata', async () => {
    const client = SentryExploreClient.fromConfig(
      { authToken: 'token-with-at-least-sixteen-characters' },
      async (url) => {
        if (url.pathname.endsWith('/tags/environment/values/')) {
          return new Response(JSON.stringify([{ name: 'production' }]));
        }
        if (url.pathname.endsWith('/releases/')) {
          return new Response(JSON.stringify({ detail: 'forbidden' }), {
            status: 403,
          });
        }
        return new Response(JSON.stringify([]));
      },
    );

    const result = await client.discoverContext({
      organizationSlug: 'acme',
      projectSlug: 'payments',
    });

    expect(result.environments).toEqual({
      availability: 'AVAILABLE',
      values: ['production'],
    });
    expect(result.releases).toMatchObject({
      availability: 'UNAVAILABLE',
      code: 'AUTHENTICATION_FAILED',
      reason: 'Sentry rejected the configured credential.',
    });
    expect(result.tags).toEqual({ availability: 'AVAILABLE', values: [] });
  });

  it('preserves typed rate-limit details for every failed discovery section', async () => {
    const retryAt = '2026-09-17T12:01:00.000Z';
    const fetch = vi.fn(
      async () =>
        new Response(null, {
          status: 429,
          headers: { 'retry-after': 'Thu, 17 Sep 2026 12:01:00 GMT' },
        }),
    );
    const client = SentryExploreClient.fromConfig(
      { authToken: 'token' },
      fetch,
    );
    const result = await client.discoverContext({
      organizationSlug: 'acme',
      projectSlug: 'payments',
    });
    expect(fetch).toHaveBeenCalledTimes(4);
    for (const section of Object.values(result)) {
      expect(section).toEqual({
        availability: 'UNAVAILABLE',
        code: 'RATE_LIMITED',
        retryAt,
        reason: `Sentry rate-limited this evidence request. Retry after ${retryAt}.`,
      });
    }
    expect(JSON.parse(JSON.stringify(result))).toEqual(result);
  });

  it('reports Alerts unavailable when the credential cannot list project issues', async () => {
    const client = SentryExploreClient.fromConfig(
      { authToken: 'token-with-at-least-sixteen-characters' },
      async (url) => {
        if (url.pathname.endsWith('/issues/')) {
          return new Response(JSON.stringify({ detail: 'forbidden' }), {
            status: 403,
          });
        }
        return new Response(JSON.stringify([]));
      },
    );

    const result = await client.discoverContext({
      organizationSlug: 'acme',
      projectSlug: 'payments',
    });

    expect(result.alerts).toMatchObject({
      availability: 'UNAVAILABLE',
      reason: 'Sentry rejected the configured credential.',
    });
  });

  it('rejects unapproved HTTPS API origins before sending a stored credential', () => {
    expect(() =>
      SentryExploreClient.fromConfig({
        authToken: 'token-with-at-least-sixteen-characters',
        apiBaseUrl: 'https://capture.invalid/api/0/',
        nodeEnvironment: 'test',
      }),
    ).toThrow('not approved');
  });

  it('rejects insecure API origins in every environment', () => {
    expect(() =>
      SentryExploreClient.fromConfig({
        authToken: 'token-with-at-least-sixteen-characters',
        apiBaseUrl: 'http://sentry.io/api/0/',
        nodeEnvironment: 'development',
      }),
    ).toThrow('must be an HTTPS URL');
  });

  it('allows an explicitly approved self-hosted API origin', async () => {
    let request: URL | undefined;
    const client = SentryExploreClient.fromConfig(
      {
        authToken: 'token-with-at-least-sixteen-characters',
        apiBaseUrl: 'https://sentry.internal.example/api/0/',
        allowedBaseUrls: ['https://sentry.internal.example/api/0/'],
      },
      async (url) => {
        request = url;
        return new Response(JSON.stringify({ data: [], meta: {} }));
      },
    );

    await client.queryTable({
      signal: 'ERRORS',
      fields: ['id'],
      scope,
      start: '2026-08-07T00:00:00.000Z',
      end: '2026-08-07T00:05:00.000Z',
      limit: 1,
    });

    expect(request?.origin).toBe('https://sentry.internal.example');
  });

  it('surfaces a rejected provider credential as an authentication failure', async () => {
    const client = SentryExploreClient.fromConfig(
      { authToken: 'token-with-at-least-sixteen-characters' },
      async () =>
        new Response(JSON.stringify({ detail: 'forbidden' }), { status: 403 }),
    );

    await expect(
      client.queryTable({
        signal: 'ERRORS',
        fields: ['id'],
        scope,
        start: '2026-08-07T00:00:00.000Z',
        end: '2026-08-07T00:05:00.000Z',
        limit: 1,
      }),
    ).rejects.toMatchObject({ code: 'AUTHENTICATION_FAILED' });
  });

  it('maps standard AbortError instances to TIMEOUT code', async () => {
    const abortError = new Error('The operation was aborted');
    abortError.name = 'AbortError';

    const client = SentryExploreClient.fromConfig(
      { authToken: 'token-with-at-least-sixteen-characters' },
      async () => {
        throw abortError;
      },
    );

    await expect(
      client.queryTable({
        signal: 'ERRORS',
        fields: ['id'],
        scope,
        start: '2026-08-07T00:00:00.000Z',
        end: '2026-08-07T00:05:00.000Z',
        limit: 1,
      }),
    ).rejects.toMatchObject({ code: 'TIMEOUT' });
  });

  it('joins multiple query conditions with spaces instead of AND', async () => {
    let request: URL | undefined;
    const client = SentryExploreClient.fromConfig(
      {
        authToken: 'token-with-at-least-sixteen-characters',
        nodeEnvironment: 'test',
      },
      async (url) => {
        request = url;
        return new Response(JSON.stringify({ data: [], meta: {} }));
      },
    );

    await client.queryTable({
      signal: 'ERRORS',
      fields: ['id'],
      scope,
      filter: 'level:error',
      traceId: 'w3c:4bf92f35-00f067aa',
      start: '2026-08-07T00:00:00.000Z',
      end: '2026-08-07T00:05:00.000Z',
      limit: 1,
    });

    const query = request?.searchParams.get('query');
    expect(query).toContain('release:');
    expect(query).toContain('trace:"w3c:4bf92f35-00f067aa"');
    expect(query).toContain('(level:error)');
    expect(query).not.toContain(' AND ');
  });

  it('exposes API rate-limit retry metadata from a 429 response', async () => {
    const reset = Math.floor(Date.now() / 1_000) + 120;
    const client = SentryExploreClient.fromConfig(
      { authToken: 'token-with-at-least-sixteen-characters' },
      async () =>
        new Response(null, {
          status: 429,
          headers: {
            'x-sentry-rate-limit-limit': '50',
            'x-sentry-rate-limit-remaining': '0',
            'x-sentry-rate-limit-reset': String(reset),
            'x-sentry-rate-limit-concurrentlimit': '2',
            'x-sentry-rate-limit-concurrentremaining': '0',
          },
        }),
    );

    await expect(
      client.queryTable({
        signal: 'ERRORS',
        fields: ['id'],
        scope,
        start: '2026-08-07T00:00:00.000Z',
        end: '2026-08-07T00:05:00.000Z',
        limit: 1,
      }),
    ).rejects.toMatchObject({
      code: 'RATE_LIMITED',
      rateLimit: {
        limit: 50,
        remaining: 0,
        resetAt: new Date(reset * 1_000).toISOString(),
        retryAt: new Date(reset * 1_000).toISOString(),
        concurrentLimit: 2,
        concurrentRemaining: 0,
      },
    });
  });

  it.each([
    undefined,
    '',
    ' \t ',
  ])('omits missing or blank rate-limit headers (%s) on a 429 response', async (value) => {
    const headers = new Headers();
    if (value !== undefined) {
      for (const name of [
        'x-sentry-rate-limit-limit',
        'x-sentry-rate-limit-remaining',
        'x-sentry-rate-limit-reset',
        'x-sentry-rate-limit-concurrentlimit',
        'x-sentry-rate-limit-concurrentremaining',
        'retry-after',
      ]) {
        headers.set(name, value);
      }
    }
    const client = SentryExploreClient.fromConfig(
      { authToken: 'token-with-at-least-sixteen-characters' },
      async () => new Response(null, { status: 429, headers }),
    );

    const result = client.resolveProjectById('acme', '42');

    await expect(result).rejects.toMatchObject({
      code: 'RATE_LIMITED',
      message: 'Sentry rate-limited this evidence request.',
    });
    await expect(result).rejects.toHaveProperty('rateLimit', {});
  });

  it.each([
    ['30', undefined, '2026-08-07T00:00:30.000Z'],
    ['0', undefined, '2026-08-07T00:00:00.000Z'],
    ['Fri, 07 Aug 2026 00:01:00 GMT', undefined, '2026-08-07T00:01:00.000Z'],
    ['30', '2026-08-07T00:02:00.000Z', '2026-08-07T00:00:30.000Z'],
    [undefined, '2026-08-07T00:02:00.000Z', '2026-08-07T00:02:00.000Z'],
    ['', '2026-08-07T00:02:00.000Z', '2026-08-07T00:02:00.000Z'],
    [' \t ', '2026-08-07T00:02:00.000Z', '2026-08-07T00:02:00.000Z'],
    ['not-a-date', '2026-08-07T00:02:00.000Z', '2026-08-07T00:02:00.000Z'],
    [undefined, '1970-01-01T00:00:00.000Z', '1970-01-01T00:00:00.000Z'],
  ])('parses Retry-After %s with reset %s as %s', async (retryAfter, resetAt, retryAt) => {
    vi.spyOn(Date, 'now').mockReturnValue(
      Date.parse('2026-08-07T00:00:00.000Z'),
    );
    const headers = new Headers();
    if (retryAfter !== undefined) headers.set('retry-after', retryAfter);
    if (resetAt !== undefined) {
      headers.set(
        'x-sentry-rate-limit-reset',
        String(Date.parse(resetAt) / 1_000),
      );
    }
    const client = SentryExploreClient.fromConfig(
      { authToken: 'token-with-at-least-sixteen-characters' },
      async () => new Response(null, { status: 429, headers }),
    );

    await expect(
      client.resolveProjectById('acme', '42'),
    ).rejects.toHaveProperty('rateLimit', {
      ...(resetAt === undefined ? {} : { resetAt }),
      retryAt,
    });
  });
});
