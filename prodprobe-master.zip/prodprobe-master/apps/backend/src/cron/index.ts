import { getLogger } from '@hyperprobe/common';
import { Queue, Worker } from 'bullmq';
import type { RedisClientType } from 'redis';
import { performHeartbeat } from '../license/heartbeat.js';
import { expireProbesJobHandler } from './jobs/expireProbes.js';
// Constants for job names
export const JOB_EXPIRE_PROBES = 'expire-probes-job';
export const JOB_LICENSE_HEARTBEAT = 'license-heartbeat-job';

const SIX_MINUTES_IN_MS = 6 * 60 * 1000;
const ONE_DAY_IN_MS = 24 * 60 * 60 * 1000;

export async function initCronSchedulers(
  redisUrl: string,
  redisClient: RedisClientType,
) {
  const logger = getLogger();
  const connection = { url: redisUrl }; // BullMQ takes its own connection config

  // 1. Create the Queue (The Dispatcher)
  const cronQueue = new Queue('hyperprobe-cron', { connection });

  // Important: set global concurrency to 1.
  // This ensures that across all instances of the backend,
  // only ONE job of any type from this queue will be running at a time.
  await cronQueue.setGlobalConcurrency(1);

  // 2. Define the Scheduler (Runs every 6 minutes)
  await cronQueue.upsertJobScheduler(
    'expire-probes-scheduler',
    { every: SIX_MINUTES_IN_MS }, // repeat every 6 minutes
    {
      name: JOB_EXPIRE_PROBES, // The job name the worker looks for
      opts: {
        removeOnComplete: true,
        removeOnFail: 500, // keep the last 1000 failed jobs for debugging
      },
    },
  );

  // Define License Heartbeat Scheduler (Runs every 24 hours)
  await cronQueue.upsertJobScheduler(
    'license-heartbeat-scheduler',
    { every: ONE_DAY_IN_MS },
    {
      name: JOB_LICENSE_HEARTBEAT,
      opts: {
        removeOnComplete: true,
        removeOnFail: 50,
      },
    },
  );

  logger.info('Cron Schedulers initialized');

  // 3. Create the Worker (The Executor)
  // By setting concurrency: 1, we ensure this Node instance only runs ONE
  // background task at a time, protecting the Fastify event loop.
  const worker = new Worker(
    'hyperprobe-cron',
    async (job) => {
      switch (job.name) {
        case JOB_EXPIRE_PROBES:
          return await expireProbesJobHandler(redisClient);

        case JOB_LICENSE_HEARTBEAT:
          return await performHeartbeat(redisClient);

        default:
          logger.warn(`Unknown job name: ${job.name}`);
      }
    },
    {
      connection,
      concurrency: 1,
    },
  );

  worker.on('failed', (job, err) => {
    logger.error({ err, jobId: job?.id }, 'A cron job failed');
  });

  return { cronQueue, worker };
}
