import { getLogger } from '@hyperprobe/common';
import { getDatabase, ProbeStatus } from '@hyperprobe/database';
import type { RedisClientType } from 'redis';

export async function expireProbesJobHandler(redisClient: RedisClientType) {
  const logger = getLogger();
  const prisma = getDatabase();

  logger.info('Running expire probes job...');

  const nowEpoch = Date.now();

  // 1. Find probes that should expire
  const toExpire = await prisma.probe.findMany({
    where: {
      expiryTime: { lt: BigInt(nowEpoch) },
      status: { in: [ProbeStatus.ACTIVE, ProbeStatus.INACTIVE] },
    },
    select: { id: true, type: true },
  });

  if (toExpire.length === 0) {
    logger.info('No probes to expire');
    return 0;
  }

  const ids = toExpire.map((p) => p.id);

  // 2 Fetch final hit counts from Redis before deleting
  const hitMulti = redisClient.multi();
  for (const id of ids) {
    hitMulti.get(`probe:hits:${id}`);
  }
  const hitResults = await hitMulti.exec();

  // 3. Update status and hitCount in DB using a transaction
  const updates = [];
  for (let i = 0; i < toExpire.length; i++) {
    const probe = toExpire[i];
    const id = probe.id;
    const hitsStr = hitResults[i] as unknown as string | null;

    let hitCount = hitsStr ? parseInt(hitsStr, 10) : 0;

    // Fallback: Count actual entries in the relevant DB table if Redis key is missing
    if (hitsStr === null) {
      if (probe.type === 'SNAPSHOT') {
        hitCount = await prisma.snapshotEvent.count({ where: { probeId: id } });
      } else if (probe.type === 'LOG') {
        hitCount = await prisma.logEvent.count({ where: { probeId: id } });
      } else if (
        probe.type === 'METRIC' ||
        probe.type === 'COUNTER' ||
        probe.type === 'DURATION'
      ) {
        hitCount = await prisma.metricEvent.count({ where: { probeId: id } });
      } else {
        logger.warn({ probe }, 'Unknown probe type');
      }
    }

    updates.push(
      prisma.probe.update({
        where: { id },
        data: { status: ProbeStatus.EXPIRED, hitCount },
      }),
    );
  }

  if (updates.length > 0) {
    await prisma.$transaction(updates);
  }

  // 4. Clean up Redis state
  const multi = redisClient.multi();
  for (const id of ids) {
    multi.del(`probe:limit:${id}`);
    multi.del(`probe:hits:${id}`);
    multi.del(`probe:latest-hit:${id}`);
    multi.del(`probe:live:${id}`);
  }
  await multi.exec();

  logger.info(
    { count: ids.length },
    'Expire probes completed and Redis state cleaned',
  );
  return ids.length;
}
