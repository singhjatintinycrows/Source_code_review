import { randomUUID } from 'node:crypto';
import type { RedisClientType } from 'redis';
import { ProviderError, type ProviderRateLimit } from './errors.js';

const COOLDOWN_PREFIX = 'observability:cooldown:';
const CONCURRENCY_PREFIX = 'observability:concurrency:';
const DEFAULT_COOLDOWN_MS = 30_000;
const DEFAULT_LEASE_MS = 30_000;
const DEFAULT_REDIS_COMMAND_TIMEOUT_MS = 250;

type RedisCoordinationClient = Pick<RedisClientType, 'isReady'> & {
  withAbortSignal(signal: AbortSignal): Pick<RedisClientType, 'eval' | 'get'>;
};

type CoordinationLogger = {
  warn(fields: Record<string, unknown>, message: string): void;
};

// Individual deadlines prevent ongoing traffic from keeping abandoned slots alive.
const ACQUIRE_LEASE_SCRIPT = `
local time = redis.call('TIME')
local now = tonumber(time[1]) * 1000 + math.floor(tonumber(time[2]) / 1000)
redis.call('ZREMRANGEBYSCORE', KEYS[1], '-inf', now)
if redis.call('ZCARD', KEYS[1]) >= tonumber(ARGV[1]) then return 0 end
redis.call('ZADD', KEYS[1], now + tonumber(ARGV[2]), ARGV[3])
redis.call('PEXPIRE', KEYS[1], ARGV[2])
return 1
`;

const RELEASE_LEASE_SCRIPT = `
return redis.call('ZREM', KEYS[1], ARGV[1])
`;

export const RECORD_COOLDOWN_SCRIPT = `
local current = redis.call('GET', KEYS[1])
if not current or current < ARGV[1] then
  redis.call('SET', KEYS[1], ARGV[1], 'PX', tonumber(ARGV[2]))
  return 1
end
return 0
`;

type QueueEntry = {
  resolve: () => void;
};

export class ObservabilityRequestCoordinator {
  private readonly client: RedisCoordinationClient;
  private readonly maximumConcurrent: number;
  private readonly maximumQueued: number;
  private readonly redisCommandTimeoutMs: number;
  private readonly logger?: CoordinationLogger;
  private lastRedisWarningAt = -Infinity;
  private readonly active = new Map<string, number>();
  private readonly queues = new Map<string, QueueEntry[]>();

  constructor(
    client: RedisCoordinationClient,
    maximumConcurrent = 2,
    maximumQueued = 8,
    redisCommandTimeoutMs = DEFAULT_REDIS_COMMAND_TIMEOUT_MS,
    logger?: CoordinationLogger,
  ) {
    this.client = client;
    this.maximumConcurrent = maximumConcurrent;
    this.maximumQueued = maximumQueued;
    this.redisCommandTimeoutMs = redisCommandTimeoutMs;
    this.logger = logger;
  }

  async run<T>(
    provider: string,
    connectionId: string,
    request: () => Promise<T>,
  ): Promise<T> {
    const key = `${provider}:${connectionId}`;
    await this.assertNoCooldown(key);
    await this.acquire(key);
    let leaseId: string | undefined;
    try {
      leaseId = await this.acquireGlobalLease(key);
      await this.assertNoCooldown(key);
      try {
        return await request();
      } catch (error) {
        if (error instanceof ProviderError && error.code === 'RATE_LIMITED') {
          const retryAt = await this.recordRateLimits(provider, connectionId, [
            error.rateLimit ?? {},
          ]);
          throw new ProviderError(
            'RATE_LIMITED',
            `The observability provider rate-limited this connection. Retry after ${retryAt}.`,
            { cause: error, rateLimit: { retryAt } },
          );
        }
        throw error;
      }
    } finally {
      try {
        if (leaseId) await this.releaseGlobalLease(key, leaseId);
      } finally {
        this.release(key);
      }
    }
  }

  async recordRateLimits(
    provider: string,
    connectionId: string,
    rateLimits: readonly ProviderRateLimit[],
  ): Promise<string | undefined> {
    if (rateLimits.length === 0) return undefined;
    const now = Date.now();
    let latest = -Infinity;
    for (const rateLimit of rateLimits) {
      const parsed = Date.parse(rateLimit.retryAt ?? '');
      latest = Math.max(
        latest,
        Number.isFinite(parsed) ? parsed : now + DEFAULT_COOLDOWN_MS,
      );
    }
    const retryAt = new Date(latest).toISOString();
    try {
      await this.redisCommand((client) =>
        client.eval(RECORD_COOLDOWN_SCRIPT, {
          keys: [`${COOLDOWN_PREFIX}${provider}:${connectionId}`],
          arguments: [retryAt, String(Math.max(1_000, latest - now))],
        }),
      );
    } catch {
      // A provider rate limit still propagates when the shared cooldown is unavailable.
    }
    return retryAt;
  }

  private async redisCommand<T>(
    operation: (
      client: Pick<RedisClientType, 'eval' | 'get'>,
      signal: AbortSignal,
    ) => Promise<T>,
  ): Promise<T> {
    const controller = new AbortController();
    let timer: ReturnType<typeof setTimeout> | undefined;
    try {
      if (!this.client.isReady) throw new Error('Redis is not ready');
      return await Promise.race([
        new Promise<never>((_resolve, reject) => {
          timer = setTimeout(() => {
            // Abort removes unsent commands; in-flight commands also need this JS deadline.
            reject(new Error('Redis coordination command timed out'));
            controller.abort();
          }, this.redisCommandTimeoutMs);
        }),
        operation(
          this.client.withAbortSignal(controller.signal),
          controller.signal,
        ),
      ]);
    } catch (error) {
      const now = Date.now();
      if (this.logger && now - this.lastRedisWarningAt >= 60_000) {
        this.lastRedisWarningAt = now;
        this.logger.warn(
          {
            redisReady: this.client.isReady,
            redisCommandTimeoutMs: this.redisCommandTimeoutMs,
          },
          'Redis observability coordination is unavailable; requests may use local limits.',
        );
      }
      throw error;
    } finally {
      clearTimeout(timer);
    }
  }

  private async assertNoCooldown(key: string): Promise<void> {
    try {
      const retryAt = await this.redisCommand((client) =>
        client.get(COOLDOWN_PREFIX + key),
      );
      if (retryAt && Date.parse(retryAt) > Date.now()) {
        throw new ProviderError(
          'RATE_LIMITED',
          `The observability provider rate-limited this connection. Retry after ${retryAt}.`,
          { rateLimit: { retryAt } },
        );
      }
    } catch (error) {
      if (error instanceof ProviderError) throw error;
      // Coordination degrades to the in-process queue if Redis is unavailable.
    }
  }

  private acquire(key: string): Promise<void> {
    const active = this.active.get(key) ?? 0;
    if (active < this.maximumConcurrent) {
      this.active.set(key, active + 1);
      return Promise.resolve();
    }
    const queue = this.queues.get(key) ?? [];
    if (queue.length >= this.maximumQueued) {
      throw new ProviderError(
        'OVERLOADED',
        'Too many observability requests are already in progress for this connection.',
      );
    }
    this.queues.set(key, queue);
    return new Promise<void>((resolve) => queue.push({ resolve }));
  }

  private release(key: string): void {
    const queue = this.queues.get(key);
    const next = queue?.shift();
    if (next) {
      if (queue?.length === 0) this.queues.delete(key);
      next.resolve();
      return;
    }
    const active = this.active.get(key) ?? 0;
    if (active <= 1) this.active.delete(key);
    else this.active.set(key, active - 1);
  }

  private async acquireGlobalLease(key: string): Promise<string | undefined> {
    const leaseId = randomUUID();
    const leaseKey = `${CONCURRENCY_PREFIX}${key}:leases`;
    let result: unknown;
    try {
      result = await this.redisCommand((client, signal) => {
        const acquiring = client.eval(ACQUIRE_LEASE_SCRIPT, {
          keys: [leaseKey],
          arguments: [
            String(this.maximumConcurrent),
            String(DEFAULT_LEASE_MS),
            leaseId,
          ],
        });
        void acquiring.then(
          (result) => {
            // A late acquisition may happen after the first best-effort cleanup.
            if (signal.aborted && result === 1) {
              return this.releaseGlobalLease(key, leaseId);
            }
          },
          () => {},
        );
        return acquiring;
      });
    } catch {
      // Redis is advisory only when unavailable; local queuing still protects this node.
    }
    if (result === 1) return leaseId;
    if (result === 0) {
      throw new ProviderError(
        'OVERLOADED',
        'Too many observability requests are already in progress for this connection.',
      );
    }
    // A failed acquisition can still have created this UUID's lease on the server.
    void this.releaseGlobalLease(key, leaseId);
    return undefined;
  }

  private async releaseGlobalLease(
    key: string,
    leaseId: string,
  ): Promise<void> {
    const leaseKey = `${CONCURRENCY_PREFIX}${key}:leases`;
    try {
      await this.redisCommand((client) =>
        client.eval(RELEASE_LEASE_SCRIPT, {
          keys: [leaseKey],
          arguments: [leaseId],
        }),
      );
    } catch {
      // The lease expires if Redis cannot be reached during release.
    }
  }
}

const coordinators = new WeakMap<object, ObservabilityRequestCoordinator>();

export function coordinatorFor(
  client: RedisCoordinationClient,
  logger?: CoordinationLogger,
): ObservabilityRequestCoordinator {
  const existing = coordinators.get(client);
  if (existing) return existing;
  const coordinator = new ObservabilityRequestCoordinator(
    client,
    undefined,
    undefined,
    undefined,
    logger,
  );
  coordinators.set(client, coordinator);
  return coordinator;
}
