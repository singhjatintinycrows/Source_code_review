import { afterEach, describe, expect, it, vi } from 'vitest';
import { sentryAdapter } from './sentryAdapter.js';

describe('sentry connection configuration', () => {
  afterEach(() => {
    vi.unstubAllGlobals();
  });

  it('requires a project identifier before resolving the current slug', () => {
    expect(
      sentryAdapter.validateConnectionConfig({
        orgSlug: 'acme',
        projectId: '42',
      }),
    ).toMatchObject({
      orgSlug: 'acme',
      projectId: '42',
    });
    expect(() =>
      sentryAdapter.validateConnectionConfig({ orgSlug: 'acme' }),
    ).toThrow('project ID');
    expect(
      sentryAdapter.validateConnectionConfig({
        orgSlug: 'acme',
        projectSlug: 'payments',
      }),
    ).toMatchObject({ projectSlug: 'payments' });
  });

  it('requires a resolved project slug before provider requests', () => {
    expect(() =>
      sentryAdapter.validatePublicConfig({
        orgSlug: 'acme',
        projectId: '42',
      }),
    ).toThrow('could not be resolved');
    expect(
      sentryAdapter.validatePublicConfig({
        orgSlug: 'acme',
        projectId: '42',
        projectSlug: 'payments',
      }),
    ).toMatchObject({ projectSlug: 'payments' });
  });

  it('documents the minimum read scopes for connection setup and discovery', () => {
    expect(
      sentryAdapter.credentialGuidance.match(/\b[a-z]+:[a-z]+\b/g),
    ).toEqual(['org:read', 'project:read', 'event:read']);
  });

  it('upgrades a legacy project slug to its stable project ID', async () => {
    let request: URL | undefined;
    vi.stubGlobal('fetch', async (url: URL) => {
      request = url;
      return new Response(
        JSON.stringify({ id: '42', slug: 'renamed-payments' }),
      );
    });

    await expect(
      sentryAdapter.resolveConnectionConfig(
        { orgSlug: 'acme', projectSlug: 'payments' },
        'token-with-at-least-sixteen-characters',
      ),
    ).resolves.toMatchObject({
      projectId: '42',
      projectSlug: 'renamed-payments',
    });
    expect(request?.pathname).toBe('/api/0/projects/acme/payments/');
  });
});
