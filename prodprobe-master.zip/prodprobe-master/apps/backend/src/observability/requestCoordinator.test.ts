import { getEventListeners } from 'node:events';
import type { RedisClientType } from 'redis';
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import {
  ProviderError,
  type ProviderErrorCode,
  type ProviderRateLimit,
  providerErrorToTrpcError,
} from './errors.js';
import {
  ObservabilityRequestCoordinator,
  RECORD_COOLDOWN_SCRIPT,
} from './requestCoordinator.js';

function deferred<T>() {
  let resolve!: (value: T) => void;
  let reject!: (reason: unknown) => void;
  const promise = new Promise<T>((resolvePromise, rejectPromise) => {
    resolve = resolvePromise;
    reject = rejectPromise;
  });
  return { promise, resolve, reject };
}

function redisClient(options?: {
  isReady?: boolean;
  get?: (key: string, signal?: AbortSignal) => Promise<string | null>;
  eval?: (
    script: string,
    config: { keys: string[]; arguments: string[] },
    signal?: AbortSignal,
  ) => Promise<unknown>;
}) {
  const values = new Map<string, string>();
  const client = {
    isOpen: true,
    get isReady() {
      return options?.isReady ?? true;
    },
    withAbortSignal: vi.fn((signal: AbortSignal) =>
      Object.assign(Object.create(client), { signal }),
    ),
    get: vi.fn(async function (this: { signal?: AbortSignal }, key: string) {
      return options?.get
        ? options.get(key, this.signal)
        : (values.get(key) ?? null);
    }),
    set: vi.fn(async (key: string, value: string) => {
      values.set(key, value);
      return 'OK';
    }),
    eval: vi.fn(async function (
      this: { signal?: AbortSignal },
      script: string,
      config: { keys: string[]; arguments: string[] },
    ) {
      if (options?.eval) return options.eval(script, config, this.signal);
      if (script === RECORD_COOLDOWN_SCRIPT) {
        const key = config.keys[0];
        const retryAt = config.arguments[0];
        if (key && retryAt) {
          const current = values.get(key);
          if (!current || current < retryAt) {
            values.set(key, retryAt);
            return 1;
          }
          return 0;
        }
      }
      return 1;
    }),
  };
  return client as unknown as RedisClientType;
}

const COMMAND_TIMEOUT_MS = 20;

beforeEach(() => {
  vi.useFakeTimers({ toFake: ['Date', 'setTimeout', 'clearTimeout'] });
  vi.setSystemTime(new Date('2026-09-16T12:00:00.000Z'));
});

afterEach(() => {
  const timers = vi.getTimerCount();
  vi.useRealTimers();
  expect(timers).toBe(0);
});

describe('ObservabilityRequestCoordinator', () => {
  it.each([
    false,
    true,
  ])('throttles safe fallback diagnostics when Redis readiness is %s', async (isReady) => {
    const fail = async () => {
      throw new Error('redis://user:secret@localhost');
    };
    const client = redisClient({ isReady, get: fail, eval: fail });
    const warn = vi.fn();
    const coordinator = new ObservabilityRequestCoordinator(
      client,
      2,
      8,
      COMMAND_TIMEOUT_MS,
      { warn },
    );
    for (let attempt = 0; attempt < 2; attempt++) {
      await expect(
        coordinator.run('SENTRY', 'connection-a', async () => 'evidence'),
      ).resolves.toBe('evidence');
    }
    expect(warn).toHaveBeenCalledExactlyOnceWith(
      { redisReady: isReady, redisCommandTimeoutMs: COMMAND_TIMEOUT_MS },
      expect.stringContaining('local limits'),
    );
    expect(JSON.stringify(warn.mock.calls)).not.toContain('secret');
    await vi.advanceTimersByTimeAsync(60_000);
    await coordinator.run('SENTRY', 'connection-a', async () => 'evidence');
    expect(warn).toHaveBeenCalledTimes(2);
  });

  it('reports global and local capacity as OVERLOADED without recording a cooldown', async () => {
    const globallyBusy = redisClient({ eval: async () => 0 });
    const globalCoordinator = new ObservabilityRequestCoordinator(
      globallyBusy,
      1,
      0,
    );

    await expect(
      globalCoordinator.run('SENTRY', 'connection-a', async () => undefined),
    ).rejects.toMatchObject({ code: 'OVERLOADED' });
    expect(globallyBusy.set).not.toHaveBeenCalled();

    const locallyBusy = redisClient();
    const localCoordinator = new ObservabilityRequestCoordinator(
      locallyBusy,
      1,
      0,
    );
    const started = deferred<void>();
    const blocker = deferred<void>();
    const first = localCoordinator.run('SENTRY', 'connection-a', async () => {
      started.resolve();
      return blocker.promise;
    });
    await started.promise;

    await expect(
      localCoordinator.run('SENTRY', 'connection-a', async () => undefined),
    ).rejects.toMatchObject({ code: 'OVERLOADED' });
    expect(locallyBusy.set).not.toHaveBeenCalled();

    blocker.resolve();
    await first;
  });

  it('releases a global lease and only records a genuine provider rate limit', async () => {
    const client = redisClient();
    const coordinator = new ObservabilityRequestCoordinator(client);
    const startedAt = Date.now();

    await expect(
      coordinator.run('SENTRY', 'connection-a', async () => {
        throw new ProviderError('RATE_LIMITED', 'provider limit');
      }),
    ).rejects.toMatchObject({ code: 'RATE_LIMITED' });

    expect(client.eval).toHaveBeenCalledTimes(3);
    const cooldownCall = vi
      .mocked(client.eval)
      .mock.calls.find(([script]) => script === RECORD_COOLDOWN_SCRIPT);
    expect(cooldownCall).toBeDefined();
    const retryAt = String((cooldownCall![1] as any).arguments[0]);
    expect(Date.parse(retryAt)).toBeGreaterThanOrEqual(startedAt + 30_000);
    expect(Date.parse(retryAt)).toBeLessThanOrEqual(Date.now() + 30_000);
  });

  it('does not dispatch queued requests during a newly recorded cooldown', async () => {
    const client = redisClient();
    const coordinator = new ObservabilityRequestCoordinator(client, 1);
    const started = deferred<void>();
    const blocker = deferred<void>();
    const retryAt = new Date(Date.now() + 60_000).toISOString();
    const first = coordinator.run('SENTRY', 'connection-a', async () => {
      started.resolve();
      await blocker.promise;
      throw new ProviderError('RATE_LIMITED', 'provider limit', {
        rateLimit: { retryAt },
      });
    });
    await started.promise;

    const request = vi.fn(async () => 'evidence');
    const queued = coordinator.run('SENTRY', 'connection-a', request);
    const results = Promise.allSettled([first, queued]);
    await new Promise<void>((resolve) => setImmediate(resolve));
    expect(request).not.toHaveBeenCalled();

    blocker.resolve();
    expect(await results).toMatchObject([
      {
        status: 'rejected',
        reason: { code: 'RATE_LIMITED', rateLimit: { retryAt } },
      },
      {
        status: 'rejected',
        reason: { code: 'RATE_LIMITED', rateLimit: { retryAt } },
      },
    ]);
    expect(request).not.toHaveBeenCalled();
    expect(client.eval).toHaveBeenCalledTimes(5);

    vi.mocked(client.get).mockResolvedValue(null);
    await expect(
      coordinator.run('SENTRY', 'connection-a', request),
    ).resolves.toBe('evidence');
    expect(client.eval).toHaveBeenCalledTimes(7);
  });

  it('rechecks cooldown after waiting for a global lease', async () => {
    const acquiring = deferred<void>();
    const lease = deferred<number>();
    const client = redisClient({
      eval: async () => {
        acquiring.resolve();
        return lease.promise;
      },
    });
    const coordinator = new ObservabilityRequestCoordinator(client);
    const request = vi.fn(async () => 'evidence');
    const pending = coordinator.run('SENTRY', 'connection-a', request);
    await acquiring.promise;

    const retryAt = new Date(Date.now() + 60_000).toISOString();
    await client.set('observability:cooldown:SENTRY:connection-a', retryAt);
    lease.resolve(1);

    await expect(pending).rejects.toMatchObject({
      code: 'RATE_LIMITED',
      rateLimit: { retryAt },
    });
    expect(request).not.toHaveBeenCalled();
    expect(client.eval).toHaveBeenCalledTimes(2);
  });

  it('does not overwrite a newer deadline when a stale cooldown check rejects', async () => {
    const client = redisClient();
    const coordinator = new ObservabilityRequestCoordinator(client);
    const checking = deferred<void>();
    const cooldownRead = deferred<string>();
    vi.mocked(client.get)
      .mockResolvedValueOnce(null)
      .mockImplementationOnce(async () => {
        checking.resolve();
        return cooldownRead.promise;
      });
    const request = vi.fn(async () => 'evidence');
    const pending = coordinator.run('SENTRY', 'connection-a', request);
    await checking.promise;

    const retryAt = new Date(Date.now() + 60_000).toISOString();
    const newerRetryAt = new Date(Date.now() + 120_000).toISOString();
    const cooldownKey = 'observability:cooldown:SENTRY:connection-a';
    await client.set(cooldownKey, newerRetryAt);
    cooldownRead.resolve(retryAt);

    await expect(pending).rejects.toMatchObject({
      code: 'RATE_LIMITED',
      rateLimit: { retryAt },
    });
    expect(request).not.toHaveBeenCalled();
    expect(client.set).toHaveBeenCalledTimes(1);
    expect(await client.get(cooldownKey)).toBe(newerRetryAt);
    expect(client.eval).toHaveBeenCalledTimes(2);
  });

  it('falls back to local coordination when Redis is unavailable', async () => {
    const client = redisClient({
      get: async () => {
        throw new Error('redis unavailable');
      },
      eval: async () => {
        throw new Error('redis unavailable');
      },
    });
    const coordinator = new ObservabilityRequestCoordinator(client);

    await expect(
      coordinator.run('SENTRY', 'connection-a', async () => 'evidence'),
    ).resolves.toBe('evidence');
  });

  it('does not overwrite an existing longer cooldown with an earlier retryAt', async () => {
    const client = redisClient();
    const coordinator = new ObservabilityRequestCoordinator(client);
    const cooldownKey = 'observability:cooldown:SENTRY:connection-a';

    const longerRetryAt = new Date(Date.now() + 60_000).toISOString();
    const shorterRetryAt = new Date(Date.now() + 5_000).toISOString();

    await expect(
      coordinator.run('SENTRY', 'connection-a', async () => {
        throw new ProviderError('RATE_LIMITED', 'limit 1', {
          rateLimit: { retryAt: longerRetryAt },
        });
      }),
    ).rejects.toMatchObject({ code: 'RATE_LIMITED' });

    expect(await client.get(cooldownKey)).toBe(longerRetryAt);

    // Bypass both cooldown checks to exercise the monotonic write itself.
    vi.mocked(client.get)
      .mockResolvedValueOnce(null)
      .mockResolvedValueOnce(null);

    await expect(
      coordinator.run('SENTRY', 'connection-a', async () => {
        throw new ProviderError('RATE_LIMITED', 'limit 2', {
          rateLimit: { retryAt: shorterRetryAt },
        });
      }),
    ).rejects.toMatchObject({
      code: 'RATE_LIMITED',
      rateLimit: { retryAt: shorterRetryAt },
    });

    // Cooldown must not have been shortened
    expect(await client.get(cooldownKey)).toBe(longerRetryAt);
  });

  it('handles invalid retryAt by falling back to default cooldown without NaN', async () => {
    const client = redisClient();
    const coordinator = new ObservabilityRequestCoordinator(client);

    await expect(
      coordinator.run('SENTRY', 'connection-a', async () => {
        throw new ProviderError('RATE_LIMITED', 'limit invalid date', {
          rateLimit: { retryAt: 'invalid-date' },
        });
      }),
    ).rejects.toMatchObject({ code: 'RATE_LIMITED' });

    const cooldownCall = vi
      .mocked(client.eval)
      .mock.calls.find(([script]) => script === RECORD_COOLDOWN_SCRIPT);
    expect(cooldownCall).toBeDefined();
    const recordedDuration = Number((cooldownCall![1] as any).arguments[1]);
    expect(Number.isFinite(recordedDuration)).toBe(true);
    expect(recordedDuration).toBeGreaterThanOrEqual(29_000);
    expect(recordedDuration).toBeLessThanOrEqual(30_000);
  });

  it('normalizes non-UTC retryAt to an ISO-8601 UTC string', async () => {
    const client = redisClient();
    const coordinator = new ObservabilityRequestCoordinator(client);
    const nonUtcRetryAt = '2026-09-09T10:00:00+05:30';
    const expectedUtc = new Date(nonUtcRetryAt).toISOString();

    await expect(
      coordinator.run('SENTRY', 'connection-a', async () => {
        throw new ProviderError('RATE_LIMITED', 'limit non-utc', {
          rateLimit: { retryAt: nonUtcRetryAt },
        });
      }),
    ).rejects.toMatchObject({
      code: 'RATE_LIMITED',
      rateLimit: { retryAt: expectedUtc },
    });

    const cooldownCall = vi
      .mocked(client.eval)
      .mock.calls.find(([script]) => script === RECORD_COOLDOWN_SCRIPT);
    expect(cooldownCall).toBeDefined();
    expect((cooldownCall![1] as any).arguments[0]).toBe(expectedUtc);
  });

  it('maps overloads to TOO_MANY_REQUESTS', () => {
    expect(
      providerErrorToTrpcError(new ProviderError('OVERLOADED', 'busy')).code,
    ).toBe('TOO_MANY_REQUESTS');
  });
});

describe('bounded Redis coordination', () => {
  it.each([
    'initial cooldown GET',
    'acquire EVAL',
    'second cooldown GET',
    'record cooldown EVAL',
    'release EVAL',
  ])('bounds a stalled %s even when native abort is ignored', async (phase) => {
    const stalled = deferred<never>();
    const client = redisClient();
    if (phase.includes('GET')) {
      if (phase === 'second cooldown GET') {
        vi.mocked(client.get).mockResolvedValueOnce(null);
      }
      vi.mocked(client.get).mockImplementationOnce(() => stalled.promise);
    } else {
      if (phase !== 'acquire EVAL') {
        vi.mocked(client.eval).mockResolvedValueOnce(1);
      }
      vi.mocked(client.eval).mockImplementationOnce(() => stalled.promise);
    }
    const coordinator = new ObservabilityRequestCoordinator(
      client,
      1,
      0,
      COMMAND_TIMEOUT_MS,
    );
    const value = { evidence: 'original result' };
    const retryAt = '2026-09-16T12:01:00.000Z';
    const providerError = new ProviderError('RATE_LIMITED', 'provider limit', {
      rateLimit: { retryAt },
    });
    const request = vi.fn(async () => {
      if (phase === 'record cooldown EVAL') throw providerError;
      return value;
    });
    let finished = false;
    const completion = Promise.allSettled([
      coordinator.run('SENTRY', 'connection-a', request),
    ]);
    void completion.then(() => {
      finished = true;
    });

    await vi.advanceTimersByTimeAsync(0);
    const signal = vi.mocked(client.withAbortSignal).mock.calls.at(-1)![0];
    expect(vi.getTimerCount()).toBe(1);
    await vi.advanceTimersByTimeAsync(COMMAND_TIMEOUT_MS - 1);
    expect(finished).toBe(false);
    expect(signal.aborted).toBe(false);
    await vi.advanceTimersByTimeAsync(1);

    expect(finished).toBe(true);
    expect(signal.aborted).toBe(true);
    expect(request).toHaveBeenCalledTimes(1);
    if (phase === 'record cooldown EVAL') {
      expect(await completion).toMatchObject([
        {
          status: 'rejected',
          reason: {
            code: 'RATE_LIMITED',
            rateLimit: { retryAt },
            cause: providerError,
          },
        },
      ]);
    } else {
      expect(await completion).toEqual([{ status: 'fulfilled', value }]);
    }
    const signals = vi
      .mocked(client.withAbortSignal)
      .mock.calls.map(([s]) => s);
    expect(new Set(signals).size).toBe(signals.length);
    expect(signals.filter((s) => s.aborted)).toEqual([signal]);
    expect(client).not.toHaveProperty('signal');
    await expect(
      coordinator.run('SENTRY', 'connection-a', async () => 'reused slot'),
    ).resolves.toBe('reused slot');

    // Losing commands may reject long after the provider has already completed.
    const calls = vi.mocked(client.eval).mock.calls.length;
    stalled.reject(new Error('late Redis rejection'));
    await vi.advanceTimersByTimeAsync(0);
    expect(client.eval).toHaveBeenCalledTimes(calls);
    expect(request).toHaveBeenCalledTimes(1);
  });

  it('defaults to a 250ms command deadline', async () => {
    const client = redisClient();
    vi.mocked(client.get).mockImplementationOnce(() => new Promise(() => {}));
    const coordinator = new ObservabilityRequestCoordinator(client);
    const request = vi.fn(async () => 'evidence');
    const pending = coordinator.run('SENTRY', 'connection-a', request);
    await vi.advanceTimersByTimeAsync(249);
    expect(request).not.toHaveBeenCalled();
    await vi.advanceTimersByTimeAsync(1);
    await expect(pending).resolves.toBe('evidence');
  });

  it('skips an open but unready client without caching local cooldowns', async () => {
    const state = { isReady: false };
    const client = redisClient(state);
    const coordinator = new ObservabilityRequestCoordinator(client);
    const request = vi.fn(async () => 'evidence');
    expect(client.isOpen).toBe(true);
    await expect(
      coordinator.run('SENTRY', 'connection-a', async () => {
        throw new ProviderError('RATE_LIMITED', 'provider limit');
      }),
    ).rejects.toMatchObject({
      code: 'RATE_LIMITED',
      rateLimit: { retryAt: '2026-09-16T12:00:30.000Z' },
    });
    await expect(
      coordinator.run('SENTRY', 'connection-a', request),
    ).resolves.toBe('evidence');
    expect(client.get).not.toHaveBeenCalled();
    expect(client.eval).not.toHaveBeenCalled();
    expect(client.withAbortSignal).not.toHaveBeenCalled();

    state.isReady = true;
    await expect(
      coordinator.run('SENTRY', 'connection-a', request),
    ).resolves.toBe('evidence');
    expect(client.get).toHaveBeenCalledTimes(2);
    expect(client.eval).toHaveBeenCalledTimes(2);
    expect(request).toHaveBeenCalledTimes(2);
  });

  it.each([
    'offline',
    'rejecting',
    'stalled',
  ])('keeps bounded per-process capacity, FIFO and slot reuse with %s Redis', async (mode) => {
    const unavailable = () =>
      mode === 'rejecting'
        ? Promise.reject(new Error('Redis unavailable'))
        : new Promise<never>(() => {});
    const client = redisClient({
      isReady: mode !== 'offline',
      get: unavailable,
      eval: unavailable,
    });
    const coordinator = new ObservabilityRequestCoordinator(
      client,
      2,
      2,
      COMMAND_TIMEOUT_MS,
    );
    const blockers = Array.from({ length: 4 }, () => deferred<void>());
    const started: number[] = [];
    let active = 0;
    let peak = 0;
    const requests = blockers.map((blocker, index) =>
      coordinator.run('SENTRY', 'connection-a', async () => {
        started.push(index);
        peak = Math.max(peak, ++active);
        await blocker.promise;
        active--;
        return index;
      }),
    );
    const extra = vi.fn(async () => undefined);
    const overflow = expect(
      coordinator.run('SENTRY', 'connection-a', extra),
    ).rejects.toMatchObject({ code: 'OVERLOADED' });

    await vi.advanceTimersByTimeAsync(3 * COMMAND_TIMEOUT_MS);
    await overflow;
    expect(started).toEqual([0, 1]);
    expect(active).toBe(2);
    expect(extra).not.toHaveBeenCalled();
    blockers[0].resolve();
    await vi.advanceTimersByTimeAsync(2 * COMMAND_TIMEOUT_MS);
    expect(started).toEqual([0, 1, 2]);
    expect(active).toBe(2);
    blockers[1].resolve();
    await vi.advanceTimersByTimeAsync(2 * COMMAND_TIMEOUT_MS);
    expect(started).toEqual([0, 1, 2, 3]);
    expect(active).toBe(2);
    blockers[2].resolve();
    blockers[3].resolve();
    expect(await Promise.all(requests)).toEqual([0, 1, 2, 3]);
    expect(peak).toBe(2);
    expect(active).toBe(0);

    const reused = coordinator.run('SENTRY', 'connection-a', extra);
    await vi.advanceTimersByTimeAsync(3 * COMMAND_TIMEOUT_MS);
    await reused;
    expect(extra).toHaveBeenCalledTimes(1);
    expect(client.eval).not.toHaveBeenCalledWith(
      RECORD_COOLDOWN_SCRIPT,
      expect.anything(),
    );
  });

  it('cancels unsent commands with a fresh proxy for every operation', async () => {
    const queued = new Set<AbortSignal>();
    const enqueue = (signal: AbortSignal) =>
      new Promise<never>((_resolve, reject) => {
        queued.add(signal);
        signal.addEventListener(
          'abort',
          () => {
            queued.delete(signal);
            reject(new Error('unsent command aborted'));
          },
          { once: true },
        );
      });
    const client = redisClient({
      get: (_key, signal) => enqueue(signal!),
      eval: (_script, _config, signal) => enqueue(signal!),
    });
    const coordinator = new ObservabilityRequestCoordinator(
      client,
      1,
      0,
      COMMAND_TIMEOUT_MS,
    );
    const request = vi.fn(async () => 'evidence');
    const pending = coordinator.run('SENTRY', 'connection-a', request);
    await vi.advanceTimersByTimeAsync(0);
    expect(queued.size).toBe(1);
    await vi.advanceTimersByTimeAsync(COMMAND_TIMEOUT_MS);
    expect(queued.size).toBe(1);
    await vi.advanceTimersByTimeAsync(COMMAND_TIMEOUT_MS);
    // The ambiguous lease cleanup is detached from the second cooldown check.
    expect(queued.size).toBe(2);
    await vi.advanceTimersByTimeAsync(COMMAND_TIMEOUT_MS);
    await expect(pending).resolves.toBe('evidence');
    expect(request).toHaveBeenCalledTimes(1);
    expect(queued.size).toBe(0);
    const signals = vi
      .mocked(client.withAbortSignal)
      .mock.calls.map(([s]) => s);
    expect(signals).toHaveLength(4);
    expect(new Set(signals).size).toBe(4);
    for (const signal of signals) {
      expect(signal.aborted).toBe(true);
      expect(getEventListeners(signal, 'abort')).toHaveLength(0);
    }
  });

  it('clears healthy deadlines and releases globally before handing off a local slot', async () => {
    const releasing = deferred<void>();
    const released = deferred<number>();
    const client = redisClient();
    vi.mocked(client.eval)
      .mockResolvedValueOnce(1)
      .mockImplementationOnce(() => {
        releasing.resolve();
        return released.promise;
      });
    const coordinator = new ObservabilityRequestCoordinator(
      client,
      1,
      1,
      COMMAND_TIMEOUT_MS,
    );
    const first = coordinator.run(
      'SENTRY',
      'connection-a',
      async () => 'first',
    );
    await releasing.promise;
    const request = vi.fn(async () => 'second');
    const second = coordinator.run('SENTRY', 'connection-a', request);
    await vi.advanceTimersByTimeAsync(0);
    expect(request).not.toHaveBeenCalled();
    expect(client.eval).toHaveBeenCalledTimes(2);
    released.resolve(1);
    expect(await Promise.all([first, second])).toEqual(['first', 'second']);
    expect(request).toHaveBeenCalledTimes(1);
    expect(vi.getTimerCount()).toBe(0);
    await vi.advanceTimersByTimeAsync(10 * COMMAND_TIMEOUT_MS);
    for (const [signal] of vi.mocked(client.withAbortSignal).mock.calls) {
      expect(signal.aborted).toBe(false);
    }
  });

  it.each([
    'acquire',
    'release',
    'proxy',
  ])('handles a synchronous %s failure without leaking timers or local capacity', async (phase) => {
    const client = redisClient();
    const fail = () => {
      throw new Error('synchronous Redis failure');
    };
    if (phase === 'proxy') {
      vi.mocked(client.withAbortSignal).mockImplementationOnce(fail);
    } else {
      if (phase === 'release') vi.mocked(client.eval).mockResolvedValueOnce(1);
      vi.mocked(client.eval).mockImplementationOnce(fail);
    }
    const coordinator = new ObservabilityRequestCoordinator(
      client,
      1,
      0,
      COMMAND_TIMEOUT_MS,
    );
    const request = vi.fn(async () => 'evidence');
    await expect(
      coordinator.run('SENTRY', 'connection-a', request),
    ).resolves.toBe('evidence');
    await expect(
      coordinator.run('SENTRY', 'connection-a', request),
    ).resolves.toBe('evidence');
    expect(request).toHaveBeenCalledTimes(2);
    if (phase === 'acquire') {
      const [acquire, cleanup] = vi.mocked(client.eval).mock.calls;
      expect(cleanup[1]).toEqual({
        keys: ['observability:concurrency:SENTRY:connection-a:leases'],
        arguments: [(acquire[1] as any).arguments[2]],
      });
    }
  });

  it.each([
    'AUTHENTICATION_FAILED',
    'INVALID_CONFIGURATION',
    'INVALID_REQUEST',
    'OVERLOADED',
    'RESPONSE_TOO_LARGE',
    'TIMEOUT',
    'UNAVAILABLE',
    'UNSUPPORTED',
  ] satisfies ProviderErrorCode[])('preserves the original provider %s error when release stalls', async (code) => {
    const client = redisClient({
      eval: async (script) =>
        script.includes('ZADD') ? 1 : new Promise<never>(() => {}),
    });
    const coordinator = new ObservabilityRequestCoordinator(
      client,
      1,
      0,
      COMMAND_TIMEOUT_MS,
    );
    const error = new ProviderError(code, 'original provider failure');
    const request = vi.fn(async () => {
      throw error;
    });
    const outcome = expect(
      coordinator.run('SENTRY', 'connection-a', request),
    ).rejects.toBe(error);
    await vi.advanceTimersByTimeAsync(COMMAND_TIMEOUT_MS);
    await outcome;
    expect(request).toHaveBeenCalledTimes(1);
    expect(client.eval).not.toHaveBeenCalledWith(
      RECORD_COOLDOWN_SCRIPT,
      expect.anything(),
    );
  });

  it('preserves a provider rate limit when both recording and releasing stall', async () => {
    const client = redisClient({
      eval: async (script) =>
        script.includes('ZADD') ? 1 : new Promise<never>(() => {}),
    });
    const coordinator = new ObservabilityRequestCoordinator(
      client,
      1,
      0,
      COMMAND_TIMEOUT_MS,
    );
    const error = new ProviderError('RATE_LIMITED', 'original provider limit', {
      rateLimit: { retryAt: '2026-09-16T14:01:00+02:00' },
    });
    const outcome = expect(
      coordinator.run('SENTRY', 'connection-a', async () => {
        throw error;
      }),
    ).rejects.toMatchObject({
      code: 'RATE_LIMITED',
      cause: error,
      rateLimit: { retryAt: '2026-09-16T12:01:00.000Z' },
    });
    await vi.advanceTimersByTimeAsync(2 * COMMAND_TIMEOUT_MS);
    await outcome;
    const next = coordinator.run(
      'SENTRY',
      'connection-a',
      async () => 'reused',
    );
    await vi.advanceTimersByTimeAsync(COMMAND_TIMEOUT_MS);
    await expect(next).resolves.toBe('reused');
  });
});

describe('ambiguous Redis acquisitions', () => {
  it.each([
    { timing: 'before', cleanup: 'healthy' },
    { timing: 'after', cleanup: 'healthy' },
    { timing: 'before', cleanup: 'rejecting' },
    { timing: 'after', cleanup: 'rejecting' },
    { timing: 'before', cleanup: 'stalled' },
    { timing: 'after', cleanup: 'stalled' },
  ])('cleans late success $timing fallback completes with $cleanup cleanup', async ({
    timing,
    cleanup,
  }) => {
    const acquiring = deferred<number>();
    const firstBlocker = deferred<void>();
    const secondBlocker = deferred<void>();
    const leases = new Set<string>();
    const releases: { id: string; signal: AbortSignal }[] = [];
    let candidate: string | undefined;
    const client = redisClient({
      eval: async (script, config, signal) => {
        if (script.includes('ZADD')) {
          const id = config.arguments[2];
          expect(config.arguments.slice(0, 2)).toEqual(['1', '30000']);
          if (!candidate) {
            candidate = id;
            const result = await acquiring.promise;
            if (result === 1) leases.add(id);
            return result;
          }
          leases.add(id);
          return 1;
        }
        expect(config.keys).toEqual([
          'observability:concurrency:SENTRY:connection-a:leases',
        ]);
        expect(script).toContain("redis.call('ZREM', KEYS[1], ARGV[1])");
        const id = config.arguments[0];
        releases.push({ id, signal: signal! });
        if (id === candidate) {
          if (cleanup === 'rejecting') throw new Error('cleanup failed');
          if (cleanup === 'stalled') return new Promise<never>(() => {});
        }
        return Number(leases.delete(id));
      },
    });
    const coordinator = new ObservabilityRequestCoordinator(
      client,
      1,
      1,
      COMMAND_TIMEOUT_MS,
    );
    const firstRequest = vi.fn(async () => {
      await firstBlocker.promise;
      return 'first';
    });
    const first = coordinator.run('SENTRY', 'connection-a', firstRequest);
    await vi.advanceTimersByTimeAsync(COMMAND_TIMEOUT_MS);
    expect(firstRequest).toHaveBeenCalledTimes(1);
    expect(releases).toHaveLength(1);
    expect(releases[0].id).toBe(candidate);
    expect(releases[0].signal.aborted).toBe(false);
    expect(leases.size).toBe(0);

    const secondRequest = vi.fn(async () => {
      await secondBlocker.promise;
      return 'second';
    });
    const second = coordinator.run('SENTRY', 'connection-a', secondRequest);
    await vi.advanceTimersByTimeAsync(0);
    expect(secondRequest).not.toHaveBeenCalled();
    if (timing === 'after') {
      firstBlocker.resolve();
      await expect(first).resolves.toBe('first');
      await vi.advanceTimersByTimeAsync(0);
      expect(secondRequest).toHaveBeenCalledTimes(1);
    }

    acquiring.resolve(1);
    await vi.advanceTimersByTimeAsync(0);
    expect(releases).toHaveLength(2);
    expect(releases.map(({ id }) => id)).toEqual([candidate, candidate]);
    expect(releases[1].signal).not.toBe(releases[0].signal);
    expect(releases[1].signal.aborted).toBe(false);
    await vi.advanceTimersByTimeAsync(COMMAND_TIMEOUT_MS);
    expect(leases.has(candidate!)).toBe(cleanup !== 'healthy');
    if (timing === 'before') {
      // Neither cleanup may hand off the local slot while the fallback is active.
      expect(secondRequest).not.toHaveBeenCalled();
      firstBlocker.resolve();
      await expect(first).resolves.toBe('first');
      await vi.advanceTimersByTimeAsync(0);
    }
    expect(secondRequest).toHaveBeenCalledTimes(1);
    const secondLease = [...leases].find((id) => id !== candidate);
    expect(secondLease).toBeDefined();
    const thirdRequest = vi.fn(async () => 'third');
    const third = coordinator.run('SENTRY', 'connection-a', thirdRequest);
    await vi.advanceTimersByTimeAsync(0);
    expect(thirdRequest).not.toHaveBeenCalled();
    await expect(
      coordinator.run('SENTRY', 'connection-a', async () => 'overflow'),
    ).rejects.toMatchObject({ code: 'OVERLOADED' });
    expect(leases.has(secondLease!)).toBe(true);
    secondBlocker.resolve();
    expect(await Promise.all([second, third])).toEqual(['second', 'third']);
    expect(firstRequest).toHaveBeenCalledTimes(1);
    expect(thirdRequest).toHaveBeenCalledTimes(1);
    expect(leases.has(secondLease!)).toBe(false);
    expect(releases.filter(({ id }) => id === candidate)).toHaveLength(2);
    const signals = vi
      .mocked(client.withAbortSignal)
      .mock.calls.map(([s]) => s);
    expect(new Set(signals).size).toBe(signals.length);
  });

  it.each([
    'zero',
    'rejection',
  ])('ignores a late acquire %s after falling back', async (reply) => {
    const acquiring = deferred<number>();
    const client = redisClient();
    vi.mocked(client.eval).mockImplementationOnce(() => acquiring.promise);
    const coordinator = new ObservabilityRequestCoordinator(
      client,
      1,
      0,
      COMMAND_TIMEOUT_MS,
    );
    const error = new Error('original provider failure');
    const request = vi.fn(async () => {
      throw error;
    });
    const outcome = expect(
      coordinator.run('SENTRY', 'connection-a', request),
    ).rejects.toBe(error);
    await vi.advanceTimersByTimeAsync(COMMAND_TIMEOUT_MS);
    await outcome;
    expect(client.eval).toHaveBeenCalledTimes(2);
    if (reply === 'zero') acquiring.resolve(0);
    else acquiring.reject(new Error('late acquire failed'));
    await vi.advanceTimersByTimeAsync(0);
    expect(client.eval).toHaveBeenCalledTimes(2);
    expect(request).toHaveBeenCalledTimes(1);
    await expect(
      coordinator.run('SENTRY', 'connection-a', async () => 'reused'),
    ).resolves.toBe('reused');
  });

  it('does not clean or dispatch on a real capacity result of zero', async () => {
    const client = redisClient();
    vi.mocked(client.eval).mockResolvedValueOnce(0);
    const coordinator = new ObservabilityRequestCoordinator(
      client,
      1,
      0,
      COMMAND_TIMEOUT_MS,
    );
    const request = vi.fn(async () => 'evidence');
    await expect(
      coordinator.run('SENTRY', 'connection-a', request),
    ).rejects.toMatchObject({ code: 'OVERLOADED' });
    expect(request).not.toHaveBeenCalled();
    expect(client.eval).toHaveBeenCalledTimes(1);
    await expect(
      coordinator.run('SENTRY', 'connection-a', request),
    ).resolves.toBe('evidence');
    expect(request).toHaveBeenCalledTimes(1);
  });
});

describe('recordRateLimits', () => {
  it('does nothing for an empty list, including no readiness check', async () => {
    const client = redisClient();
    const ready = vi.spyOn(client, 'isReady', 'get');
    const coordinator = new ObservabilityRequestCoordinator(client);
    await expect(
      coordinator.recordRateLimits('SENTRY', 'connection-a', []),
    ).resolves.toBeUndefined();
    expect(ready).not.toHaveBeenCalled();
    expect(client.withAbortSignal).not.toHaveBeenCalled();
    expect(client.get).not.toHaveBeenCalled();
    expect(client.eval).not.toHaveBeenCalled();
  });

  it.each<{
    name: string;
    rateLimits: readonly ProviderRateLimit[];
    retryAt: string;
  }>([
    {
      name: 'the latest normalized offset, not the largest raw string',
      rateLimits: [
        { retryAt: '2026-09-16T15:00:10+03:00' },
        { retryAt: '2026-09-16T08:01:00-04:00' },
      ],
      retryAt: '2026-09-16T12:01:00.000Z',
    },
    {
      name: 'a missing deadline',
      rateLimits: [{}],
      retryAt: '2026-09-16T12:00:30.000Z',
    },
    {
      name: 'an invalid deadline',
      rateLimits: [{ retryAt: 'invalid' }],
      retryAt: '2026-09-16T12:00:30.000Z',
    },
    {
      name: 'an empty deadline',
      rateLimits: [{ retryAt: '' }],
      retryAt: '2026-09-16T12:00:30.000Z',
    },
    {
      name: 'fallbacks later than valid short deadlines',
      rateLimits: [
        {},
        { retryAt: 'invalid' },
        { retryAt: '2026-09-16T12:00:05Z' },
      ],
      retryAt: '2026-09-16T12:00:30.000Z',
    },
    {
      name: 'a valid deadline later than all fallbacks',
      rateLimits: [
        { retryAt: '2026-09-16T12:02:00Z' },
        {},
        { retryAt: 'invalid' },
      ],
      retryAt: '2026-09-16T12:02:00.000Z',
    },
    {
      name: 'a valid zero timestamp',
      rateLimits: [{ retryAt: '1970-01-01T00:00:00Z' }],
      retryAt: '1970-01-01T00:00:00.000Z',
    },
    {
      name: 'the latest of exclusively past deadlines',
      rateLimits: [
        { retryAt: '1969-12-31T23:59:59Z' },
        { retryAt: '2026-09-16T11:59:59Z' },
      ],
      retryAt: '2026-09-16T11:59:59.000Z',
    },
    {
      name: 'a valid negative timestamp',
      rateLimits: [{ retryAt: '1969-12-31T23:59:59Z' }],
      retryAt: '1969-12-31T23:59:59.000Z',
    },
    {
      name: 'a deadline exactly at the present',
      rateLimits: [{ retryAt: '2026-09-16T12:00:00Z' }],
      retryAt: '2026-09-16T12:00:00.000Z',
    },
  ])('records $name once without modifying inputs', async ({
    rateLimits,
    retryAt,
  }) => {
    const client = redisClient();
    const coordinator = new ObservabilityRequestCoordinator(client);
    const input = Object.freeze(
      rateLimits.map((limit) => Object.freeze({ ...limit })),
    );
    await expect(
      coordinator.recordRateLimits('SENTRY', 'connection-a', input),
    ).resolves.toBe(retryAt);
    expect(client.eval).toHaveBeenCalledExactlyOnceWith(
      RECORD_COOLDOWN_SCRIPT,
      {
        keys: ['observability:cooldown:SENTRY:connection-a'],
        arguments: [
          retryAt,
          String(Math.max(1_000, Date.parse(retryAt) - Date.now())),
        ],
      },
    );
    expect(client.get).not.toHaveBeenCalled();
    expect(client.set).not.toHaveBeenCalled();
    expect(input).toEqual(rateLimits);
  });

  it.each([
    'offline',
    'rejecting',
    'stalled',
  ])('returns the effective latest deadline with %s Redis', async (mode) => {
    const client = redisClient({
      isReady: mode !== 'offline',
      eval: () =>
        mode === 'rejecting'
          ? Promise.reject(new Error('Redis unavailable'))
          : new Promise<never>(() => {}),
    });
    const coordinator = new ObservabilityRequestCoordinator(
      client,
      1,
      0,
      COMMAND_TIMEOUT_MS,
    );
    const pending = coordinator.recordRateLimits('SENTRY', 'connection-a', [
      { retryAt: '2026-09-16T15:01:00+03:00' },
      {},
    ]);
    await vi.advanceTimersByTimeAsync(COMMAND_TIMEOUT_MS);
    await expect(pending).resolves.toBe('2026-09-16T12:01:00.000Z');
    expect(client.eval).toHaveBeenCalledTimes(mode === 'offline' ? 0 : 1);
  });

  it('uses the same public API for a thrown provider rate limit', async () => {
    const client = redisClient();
    const coordinator = new ObservabilityRequestCoordinator(client);
    const record = vi.spyOn(coordinator, 'recordRateLimits');
    const error = new ProviderError('RATE_LIMITED', 'provider limit', {
      rateLimit: { retryAt: '1970-01-01T01:00:00+01:00' },
    });
    await expect(
      coordinator.run('SENTRY', 'connection-a', async () => {
        throw error;
      }),
    ).rejects.toMatchObject({
      code: 'RATE_LIMITED',
      cause: error,
      rateLimit: { retryAt: '1970-01-01T00:00:00.000Z' },
    });
    expect(record).toHaveBeenCalledExactlyOnceWith('SENTRY', 'connection-a', [
      error.rateLimit,
    ]);
    expect(
      vi
        .mocked(client.eval)
        .mock.calls.filter(([script]) => script === RECORD_COOLDOWN_SCRIPT),
    ).toHaveLength(1);
  });

  it('keeps a longer shared cooldown while returning the latest supplied deadline', async () => {
    const client = redisClient();
    const coordinator = new ObservabilityRequestCoordinator(client);
    const longer = '2026-09-16T12:02:00.000Z';
    const shorter = '2026-09-16T12:01:00.000Z';
    await coordinator.recordRateLimits('SENTRY', 'connection-a', [
      { retryAt: longer },
    ]);
    await expect(
      coordinator.recordRateLimits('SENTRY', 'connection-a', [
        { retryAt: shorter },
        {},
      ]),
    ).resolves.toBe(shorter);
    expect(await client.get('observability:cooldown:SENTRY:connection-a')).toBe(
      longer,
    );
    expect(client.eval).toHaveBeenCalledTimes(2);
  });

  it('records partial limits inside admitted work before queued requests recheck cooldown', async () => {
    const client = redisClient();
    const coordinator = new ObservabilityRequestCoordinator(client, 1);
    const started = deferred<void>();
    const blocker = deferred<void>();
    const retryAt = '2026-09-16T12:01:00.000Z';
    const partialResult = Object.freeze({
      evidence: ['available project'],
      partial: true,
    });
    const first = coordinator.run('SENTRY', 'connection-a', async () => {
      started.resolve();
      await blocker.promise;
      await coordinator.recordRateLimits('SENTRY', 'connection-a', [
        {},
        { retryAt },
      ]);
      return partialResult;
    });
    await started.promise;
    const request = vi.fn(async () => 'must not dispatch');
    const queued = coordinator.run('SENTRY', 'connection-a', request);
    const results = Promise.allSettled([first, queued]);
    await vi.advanceTimersByTimeAsync(0);
    expect(request).not.toHaveBeenCalled();
    blocker.resolve();
    expect(await results).toMatchObject([
      { status: 'fulfilled', value: partialResult },
      {
        status: 'rejected',
        reason: { code: 'RATE_LIMITED', rateLimit: { retryAt } },
      },
    ]);
    await expect(first).resolves.toBe(partialResult);
    expect(request).not.toHaveBeenCalled();
    expect(
      vi
        .mocked(client.eval)
        .mock.calls.filter(([script]) => script === RECORD_COOLDOWN_SCRIPT),
    ).toHaveLength(1);
  });
});
