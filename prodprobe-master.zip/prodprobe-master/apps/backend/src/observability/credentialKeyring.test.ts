import { EventEmitter } from 'node:events';
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import { CredentialCipherError } from './credentialCipher.js';
import {
  acquireCredentialEncryptionLock,
  appendCredentialEncryptionKeyVersion,
  CREDENTIAL_ENCRYPTION_ACTIVE_VERSION_KEY,
  CREDENTIAL_ENCRYPTION_KEYRING_KEY,
  CREDENTIAL_ENCRYPTION_LOCK_KEY,
  CREDENTIAL_ENCRYPTION_ROTATION_KEY,
  CredentialEncryptionInitializationRequiredError,
  type CredentialKeyringConsul,
  CredentialKeyringError,
  completeCredentialEncryptionRotation,
  deriveCredentialEncryptionKey,
  isCredentialEncryptionMaintenanceActive,
  loadCredentialEncryptionKeyring,
  loadCredentialEncryptionRotation,
  loadOrInitializeCredentialCipher,
  nextCredentialKeyVersion,
  parseCredentialEncryptionKeyring,
} from './credentialKeyring.js';

const secretV1 = '550e8400-e29b-41d4-a716-446655440000';
const secretV2 = '01890f53-5a9b-4c5d-8b74-3b5ac470a001';

type TransactionOperation = {
  KV: {
    Verb: 'cas';
    Key: string;
    Value: string;
    Index: number;
  };
};

type RequestContext = Parameters<
  CredentialKeyringConsul['kv']['get']
>[0]['ctx'];

function deferred<T>() {
  let resolve!: (value: T) => void;
  let reject!: (error: unknown) => void;
  const promise = new Promise<T>((resolvePromise, rejectPromise) => {
    resolve = resolvePromise;
    reject = rejectPromise;
  });
  return { promise, resolve, reject };
}

class FakeConsul implements CredentialKeyringConsul {
  private readonly values = new Map<
    string,
    { ModifyIndex: number; Session?: string | null; Value: string }
  >();
  private index = 1;
  private lockSession: string | undefined;
  private sessionNumber = 0;
  private conflictNextTransaction = false;
  transactionCount = 0;

  readonly kv: CredentialKeyringConsul['kv'] = {
    get: async ({ key }) => {
      const item = this.values.get(key);
      return item ? { ...item } : undefined;
    },
    set: async (options) => {
      if (options.acquire) {
        if (this.lockSession && this.lockSession !== options.acquire) {
          return false;
        }
        this.lockSession = options.acquire;
        this.write(options.key, options.value, options.acquire);
        return true;
      }
      if (options.release) {
        if (this.lockSession !== options.release) return false;
        this.lockSession = undefined;
        this.write(options.key, options.value, null);
        return true;
      }
      this.write(options.key, options.value);
      return true;
    },
    del: async (options) => {
      const existing = this.values.get(options.key);
      if (!existing || existing.ModifyIndex !== options.cas) return false;
      this.values.delete(options.key);
      return true;
    },
  };

  readonly session: CredentialKeyringConsul['session'] = {
    create: async (_options) => {
      this.sessionNumber += 1;
      return { ID: `session-${this.sessionNumber}` };
    },
    renew: async (_options) => undefined,
    destroy: async ({ id }) => {
      if (this.lockSession === id) this.lockSession = undefined;
    },
  };

  readonly transaction = {
    create: async (
      operations: TransactionOperation[],
      _options: { ctx: RequestContext },
    ) => {
      this.transactionCount += 1;
      if (this.conflictNextTransaction) {
        this.conflictNextTransaction = false;
        throw Object.assign(new Error('CAS conflict'), { statusCode: 409 });
      }
      for (const operation of operations) {
        const existing = this.values.get(operation.KV.Key);
        if ((existing?.ModifyIndex ?? 0) !== operation.KV.Index) {
          throw Object.assign(new Error('CAS conflict'), { statusCode: 409 });
        }
      }
      this.writeMany(
        operations.map((operation) => ({
          key: operation.KV.Key,
          value: Buffer.from(operation.KV.Value, 'base64').toString('utf8'),
        })),
      );
      return {};
    },
  };

  seed(key: string, value: string) {
    this.write(key, value);
  }

  seedKeyring(keyring: string, activeVersion: string) {
    this.writeMany([
      { key: CREDENTIAL_ENCRYPTION_KEYRING_KEY, value: keyring },
      {
        key: CREDENTIAL_ENCRYPTION_ACTIVE_VERSION_KEY,
        value: activeVersion,
      },
    ]);
  }

  value(key: string) {
    return this.values.get(key)?.Value;
  }

  conflictOnce() {
    this.conflictNextTransaction = true;
  }

  private write(key: string, value: string, session?: string | null) {
    this.values.set(key, {
      ModifyIndex: this.index,
      ...(session === undefined ? {} : { Session: session }),
      Value: value,
    });
    this.index += 1;
  }

  private writeMany(entries: Array<{ key: string; value: string }>) {
    const modifyIndex = this.index;
    this.index += 1;
    for (const entry of entries) {
      this.values.set(entry.key, {
        ModifyIndex: modifyIndex,
        Value: entry.value,
      });
    }
  }
}

const owner = {
  serviceId: 'service-a',
  connectionId: 'connection-a',
  provider: 'SENTRY',
  credentialFormat: 'SENTRY_AUTH_TOKEN',
};

describe('credential encryption keyring', () => {
  it('parses UUID v4 secrets and derives stable version-bound AES keys', () => {
    const secrets = parseCredentialEncryptionKeyring(
      JSON.stringify({ v1: secretV1, v2: secretV2 }),
    );

    const key = deriveCredentialEncryptionKey(secretV1, 'v1');
    expect(key).toHaveLength(32);
    expect(deriveCredentialEncryptionKey(secretV1, 'v1')).toEqual(key);
    expect(deriveCredentialEncryptionKey(secretV1, 'v2')).not.toEqual(key);
    expect(nextCredentialKeyVersion(secrets)).toBe('v3');
  });

  it('rejects malformed versions, UUIDs, and reused UUIDs', () => {
    expect(() => parseCredentialEncryptionKeyring('{')).toThrow(
      CredentialCipherError,
    );
    expect(() =>
      parseCredentialEncryptionKeyring(JSON.stringify({ current: secretV1 })),
    ).toThrow();
    expect(() =>
      parseCredentialEncryptionKeyring(JSON.stringify({ v1: 'not-a-uuid' })),
    ).toThrow();
    expect(() =>
      parseCredentialEncryptionKeyring(
        JSON.stringify({ v1: secretV1, v2: secretV1 }),
      ),
    ).toThrow();
  });

  it('uses the greatest version when computing the next version', () => {
    expect(
      nextCredentialKeyVersion(
        new Map([
          ['v1', secretV1],
          ['v7', secretV2],
        ]),
      ),
    ).toBe('v8');
  });

  it('initializes an empty Consul keyring once and then reuses it', async () => {
    const consul = new FakeConsul();

    const cipher = await loadOrInitializeCredentialCipher(
      consul,
      async () => 0,
    );
    expect(cipher.encrypt(owner, 'token').credentialKeyVersion).toBe('v1');
    expect(consul.value(CREDENTIAL_ENCRYPTION_ACTIVE_VERSION_KEY)).toBe('v1');
    expect(consul.value(CREDENTIAL_ENCRYPTION_KEYRING_KEY)).toContain('v1');
    expect(consul.transactionCount).toBe(1);

    await loadOrInitializeCredentialCipher(consul, async () => {
      throw new Error('A configured keyring must not query connection rows.');
    });
    expect(consul.transactionCount).toBe(1);
  });

  it('requires explicit initialization when connection rows exist', async () => {
    const consul = new FakeConsul();

    await expect(
      loadOrInitializeCredentialCipher(consul, async () => 1),
    ).rejects.toBeInstanceOf(CredentialEncryptionInitializationRequiredError);
    expect(consul.value(CREDENTIAL_ENCRYPTION_KEYRING_KEY)).toBeUndefined();
    expect(
      consul.value(CREDENTIAL_ENCRYPTION_ACTIVE_VERSION_KEY),
    ).toBeUndefined();
  });

  it('does not initialize while a rotation marker exists', async () => {
    const consul = new FakeConsul();
    consul.seed(CREDENTIAL_ENCRYPTION_ROTATION_KEY, 'v1');

    await expect(
      loadOrInitializeCredentialCipher(consul, async () => 0),
    ).rejects.toThrow('rotation is in progress');
    expect(consul.value(CREDENTIAL_ENCRYPTION_KEYRING_KEY)).toBeUndefined();
  });

  it('retries initial bootstrap after a Consul CAS conflict', async () => {
    const consul = new FakeConsul();
    consul.conflictOnce();

    const cipher = await loadOrInitializeCredentialCipher(
      consul,
      async () => 0,
    );
    expect(cipher.encrypt(owner, 'token').credentialKeyVersion).toBe('v1');
    expect(consul.transactionCount).toBe(2);
  });

  it('waits for another backend to release the initialization lock', async () => {
    const consul = new FakeConsul();
    const heldLock = await acquireCredentialEncryptionLock(consul);
    setTimeout(() => {
      void heldLock.release();
    }, 10);

    const cipher = await loadOrInitializeCredentialCipher(
      consul,
      async () => 0,
    );
    expect(cipher.encrypt(owner, 'token').credentialKeyVersion).toBe('v1');
  });

  it('rejects a partial Consul keyring', async () => {
    const consul = new FakeConsul();
    consul.seed(
      CREDENTIAL_ENCRYPTION_KEYRING_KEY,
      JSON.stringify({ v1: secretV1 }),
    );

    await expect(
      loadCredentialEncryptionKeyring(consul),
    ).rejects.toBeInstanceOf(CredentialKeyringError);
  });

  it('rejects an active version missing from the keyring', async () => {
    const consul = new FakeConsul();
    consul.seedKeyring(JSON.stringify({ v1: secretV1 }), 'v2');

    await expect(loadCredentialEncryptionKeyring(consul)).rejects.toThrow(
      'absent from the keyring',
    );
  });

  it('rejects keyring values read from different Consul transactions', async () => {
    const consul = new FakeConsul();
    consul.seed(
      CREDENTIAL_ENCRYPTION_KEYRING_KEY,
      JSON.stringify({ v1: secretV1 }),
    );
    consul.seed(CREDENTIAL_ENCRYPTION_ACTIVE_VERSION_KEY, 'v1');

    await expect(loadCredentialEncryptionKeyring(consul)).rejects.toThrow(
      'changed while it was being read',
    );
  });

  it('appends the next version and preserves decryptability of prior rows', async () => {
    const consul = new FakeConsul();
    consul.seedKeyring(JSON.stringify({ v1: secretV1 }), 'v1');
    const original = await loadCredentialEncryptionKeyring(consul);
    if (!original) throw new Error('Expected a configured keyring.');
    const encrypted = original.cipher.encrypt(owner, 'token');

    const rotated = await appendCredentialEncryptionKeyVersion(
      consul,
      original,
    );
    const reencrypted = rotated.cipher.reencrypt(owner, encrypted);
    expect(rotated.activeVersion).toBe('v2');
    expect(rotated.cipher.decrypt(owner, encrypted)).toBe('token');
    expect(reencrypted.credentialKeyVersion).toBe('v2');
    expect(rotated.cipher.decrypt(owner, reencrypted)).toBe('token');
    expect(
      rotated.cipher.encrypt(owner, 'new-token').credentialKeyVersion,
    ).toBe('v2');
    expect(consul.value(CREDENTIAL_ENCRYPTION_ACTIVE_VERSION_KEY)).toBe('v2');

    expect((await loadCredentialEncryptionRotation(consul))?.version).toBe(
      'v2',
    );
    await expect(isCredentialEncryptionMaintenanceActive(consul)).resolves.toBe(
      true,
    );
    await completeCredentialEncryptionRotation(consul, 'v2');
    await expect(loadCredentialEncryptionRotation(consul)).resolves.toBeNull();
    await expect(isCredentialEncryptionMaintenanceActive(consul)).resolves.toBe(
      false,
    );

    const nextRotation = await appendCredentialEncryptionKeyVersion(
      consul,
      rotated,
    );
    expect(nextRotation.activeVersion).toBe('v3');
  });

  it('refuses concurrent rotation writes and serializes maintenance locks', async () => {
    const consul = new FakeConsul();
    consul.seedKeyring(JSON.stringify({ v1: secretV1 }), 'v1');
    const stale = await loadCredentialEncryptionKeyring(consul);
    if (!stale) throw new Error('Expected a configured keyring.');
    consul.seed(
      CREDENTIAL_ENCRYPTION_KEYRING_KEY,
      JSON.stringify({ v1: secretV1, v2: secretV2 }),
    );

    await expect(
      appendCredentialEncryptionKeyVersion(consul, stale),
    ).rejects.toBeInstanceOf(CredentialKeyringError);

    const lock = await acquireCredentialEncryptionLock(consul);
    await expect(isCredentialEncryptionMaintenanceActive(consul)).resolves.toBe(
      true,
    );
    await expect(
      acquireCredentialEncryptionLock(consul),
    ).rejects.toBeInstanceOf(CredentialKeyringError);
    await lock.release();
    await expect(isCredentialEncryptionMaintenanceActive(consul)).resolves.toBe(
      false,
    );
  });
});

describe('credential encryption Consul cancellation', () => {
  beforeEach(() => {
    vi.useFakeTimers({
      toFake: ['setTimeout', 'clearTimeout', 'setInterval', 'clearInterval'],
    });
  });

  afterEach(() => {
    const timers = vi.getTimerCount();
    vi.useRealTimers();
    vi.restoreAllMocks();
    expect(timers).toBe(0);
  });

  it.each([
    'fulfillment',
    'rejection',
  ])('keeps the single maintenance deadline authoritative over late %s', async (lateResult) => {
    const consul = new FakeConsul();
    const requests = [deferred<undefined>(), deferred<undefined>()];
    const contexts: RequestContext[] = [];
    const canceled = vi.fn();
    const get = vi.spyOn(consul.kv, 'get').mockImplementation(({ ctx }) => {
      expect(vi.getTimerCount()).toBe(1);
      const request = requests[contexts.length];
      contexts.push(ctx);
      ctx.once('cancel', () => {
        expect(ctx.canceled).toBe(true);
        expect(vi.getTimerCount()).toBe(0);
        canceled();
      });
      return request.promise;
    });
    const result = Promise.allSettled([
      isCredentialEncryptionMaintenanceActive(consul),
    ]);

    expect(contexts[0]).toBeInstanceOf(EventEmitter);
    expect(contexts[0]).toBe(contexts[1]);
    await vi.advanceTimersByTimeAsync(9_999);
    expect(contexts[0].canceled).toBe(false);
    await vi.advanceTimersByTimeAsync(1);
    expect(await result).toMatchObject([
      {
        status: 'rejected',
        reason: {
          name: 'CredentialKeyringError',
          message:
            'Timed out reading credential encryption maintenance state from Consul.',
        },
      },
    ]);
    expect(canceled).toHaveBeenCalledTimes(2);

    for (const request of requests) {
      if (lateResult === 'fulfillment') request.resolve(undefined);
      else request.reject(new Error('late transport failure'));
    }
    await vi.advanceTimersByTimeAsync(60_000);
    expect(get).toHaveBeenCalledTimes(2);
    expect(canceled).toHaveBeenCalledTimes(2);
    expect(contexts[0].listenerCount('cancel')).toBe(0);
    expect((await result)[0].status).toBe('rejected');
  });

  it.each([
    'single request',
    'aggregate',
  ])('handles a synchronous %s factory failure and cancels started siblings', async (mode) => {
    const consul = new FakeConsul();
    const error = new Error('synchronous Consul failure');
    const canceled = vi.fn();
    vi.spyOn(consul.kv, 'get').mockImplementation(({ key, ctx }) => {
      expect(vi.getTimerCount()).toBe(1);
      ctx.once('cancel', () => {
        expect(ctx.canceled).toBe(true);
        canceled();
      });
      if (key === CREDENTIAL_ENCRYPTION_LOCK_KEY) {
        return new Promise((_resolve, reject) => {
          ctx.once('cancel', () => reject(new Error('sibling aborted')));
        });
      }
      throw error;
    });

    await expect(
      mode === 'aggregate'
        ? isCredentialEncryptionMaintenanceActive(consul)
        : loadCredentialEncryptionRotation(consul),
    ).rejects.toBe(error);
    expect(canceled).toHaveBeenCalledTimes(mode === 'aggregate' ? 2 : 1);
  });

  it('passes fresh contexts without changing KV, session or CAS transaction options', async () => {
    const consul = new FakeConsul();
    consul.seedKeyring(JSON.stringify({ v1: secretV1 }), 'v1');
    const get = vi.spyOn(consul.kv, 'get');
    const set = vi.spyOn(consul.kv, 'set');
    const del = vi.spyOn(consul.kv, 'del');
    const create = vi.spyOn(consul.session, 'create');
    const renew = vi.spyOn(consul.session, 'renew');
    const destroy = vi.spyOn(consul.session, 'destroy');
    const transaction = vi.spyOn(consul.transaction, 'create');
    const original = (await loadCredentialEncryptionKeyring(consul))!;
    const lock = await acquireCredentialEncryptionLock(consul);
    await lock.renew();
    const rotated = await appendCredentialEncryptionKeyVersion(
      consul,
      original,
    );
    const rotation = (await loadCredentialEncryptionRotation(consul))!;
    await completeCredentialEncryptionRotation(consul, 'v2');
    await lock.release();

    const ctx = expect.any(EventEmitter);
    expect(create).toHaveBeenCalledExactlyOnceWith({
      name: 'hyperprobe-credential-encryption',
      ttl: '60s',
      behavior: 'release',
      ctx,
    });
    expect(renew).toHaveBeenCalledExactlyOnceWith({ id: 'session-1', ctx });
    expect(destroy).toHaveBeenCalledExactlyOnceWith({ id: 'session-1', ctx });
    expect(set.mock.calls).toEqual([
      [
        {
          key: CREDENTIAL_ENCRYPTION_LOCK_KEY,
          value: expect.any(String),
          acquire: 'session-1',
          ctx,
        },
      ],
      [
        {
          key: CREDENTIAL_ENCRYPTION_LOCK_KEY,
          value: set.mock.calls[0][0].value,
          release: 'session-1',
          ctx,
        },
      ],
    ]);
    expect(del).toHaveBeenCalledExactlyOnceWith({
      key: CREDENTIAL_ENCRYPTION_ROTATION_KEY,
      cas: rotation.modifyIndex,
      ctx,
    });
    expect(transaction).toHaveBeenCalledExactlyOnceWith(
      [
        {
          KV: {
            Verb: 'cas',
            Key: CREDENTIAL_ENCRYPTION_KEYRING_KEY,
            Value: Buffer.from(
              JSON.stringify(Object.fromEntries(rotated.secrets)),
            ).toString('base64'),
            Index: original.keyringModifyIndex,
          },
        },
        {
          KV: {
            Verb: 'cas',
            Key: CREDENTIAL_ENCRYPTION_ACTIVE_VERSION_KEY,
            Value: Buffer.from('v2').toString('base64'),
            Index: original.activeVersionModifyIndex,
          },
        },
        {
          KV: {
            Verb: 'cas',
            Key: CREDENTIAL_ENCRYPTION_ROTATION_KEY,
            Value: Buffer.from('v2').toString('base64'),
            Index: 0,
          },
        },
      ],
      { ctx },
    );
    const contexts = [
      ...get.mock.calls.map(([options]) => options.ctx),
      ...set.mock.calls.map(([options]) => options.ctx),
      ...del.mock.calls.map(([options]) => options.ctx),
      ...create.mock.calls.map(([options]) => options.ctx),
      ...renew.mock.calls.map(([options]) => options.ctx),
      ...destroy.mock.calls.map(([options]) => options.ctx),
      ...transaction.mock.calls.map(([, options]) => options.ctx),
    ];
    expect(new Set(contexts).size).toBe(contexts.length);
    expect(get.mock.calls.map(([options]) => options.key)).toEqual(
      expect.arrayContaining([
        CREDENTIAL_ENCRYPTION_KEYRING_KEY,
        CREDENTIAL_ENCRYPTION_ACTIVE_VERSION_KEY,
        CREDENTIAL_ENCRYPTION_ROTATION_KEY,
      ]),
    );
    await vi.advanceTimersByTimeAsync(60_000);
    for (const context of contexts) {
      expect(context).toBeInstanceOf(EventEmitter);
      expect(context.canceled).toBe(false);
      expect(context.listenerCount('cancel')).toBe(0);
    }
  });

  it('reconciles committed transaction and deletion timeouts with fresh contexts', async () => {
    const consul = new FakeConsul();
    consul.seedKeyring(JSON.stringify({ v1: secretV1 }), 'v1');
    const original = (await loadCredentialEncryptionKeyring(consul))!;
    const create = consul.transaction.create;
    const transactionReply = deferred<object>();
    const transaction = vi
      .spyOn(consul.transaction, 'create')
      .mockImplementationOnce(async (operations, options) => {
        await create(operations, options);
        return transactionReply.promise;
      });
    const get = vi.spyOn(consul.kv, 'get');
    const pending = appendCredentialEncryptionKeyVersion(consul, original);
    await vi.advanceTimersByTimeAsync(10_000);
    const rotated = await pending;
    expect(rotated.activeVersion).toBe('v2');
    expect(transaction).toHaveBeenCalledTimes(1);
    const transactionCtx = transaction.mock.calls[0][1].ctx;
    expect(transactionCtx.canceled).toBe(true);

    const remove = consul.kv.del;
    const deletionReply = deferred<boolean>();
    const del = vi
      .spyOn(consul.kv, 'del')
      .mockImplementationOnce(async (options) => {
        await remove(options);
        return deletionReply.promise;
      });
    const completion = completeCredentialEncryptionRotation(consul, 'v2');
    await vi.advanceTimersByTimeAsync(10_000);
    await completion;
    expect(consul.value(CREDENTIAL_ENCRYPTION_ROTATION_KEY)).toBeUndefined();
    const deletionCtx = del.mock.calls[0][0].ctx;
    expect(deletionCtx.canceled).toBe(true);
    expect(deletionCtx).not.toBe(transactionCtx);
    for (const [options] of get.mock.calls) {
      expect(options.ctx).not.toBe(transactionCtx);
      expect(options.ctx).not.toBe(deletionCtx);
      expect(options.ctx.canceled).toBe(false);
    }

    transactionReply.reject(new Error('late transaction rejection'));
    deletionReply.resolve(true);
    await vi.advanceTimersByTimeAsync(0);
    expect(transaction).toHaveBeenCalledTimes(1);
    expect(del).toHaveBeenCalledTimes(1);
  });

  it('preserves conflict identity and skips ambiguous-write reconciliation on 409', async () => {
    const consul = new FakeConsul();
    consul.seedKeyring(JSON.stringify({ v1: secretV1 }), 'v1');
    const keyring = (await loadCredentialEncryptionKeyring(consul))!;
    const conflict = Object.assign(new Error('CAS conflict'), {
      statusCode: 409,
    });
    const transaction = vi
      .spyOn(consul.transaction, 'create')
      .mockRejectedValueOnce(conflict);
    const get = vi.spyOn(consul.kv, 'get');

    const error = await appendCredentialEncryptionKeyVersion(
      consul,
      keyring,
    ).catch((error: unknown) => error);
    expect(error).toBeInstanceOf(CredentialKeyringError);
    expect((error as Error).cause).toBe(conflict);
    expect(transaction.mock.calls[0][1].ctx.canceled).toBe(true);
    expect(get).toHaveBeenCalledTimes(1);
  });

  it('still rejects invalid read modification indexes', async () => {
    const consul = new FakeConsul();
    const get = vi.spyOn(consul.kv, 'get');
    for (const ModifyIndex of [
      undefined,
      0,
      -1,
      1.5,
      Number.MAX_SAFE_INTEGER + 1,
    ]) {
      get.mockResolvedValueOnce({ Value: 'v1', ModifyIndex });
      await expect(loadCredentialEncryptionRotation(consul)).rejects.toThrow(
        'invalid modification index',
      );
    }
  });

  it.each([
    'manual',
    'automatic',
  ])('latches a %s renewal timeout and still releases with fresh cleanup contexts', async (mode) => {
    const consul = new FakeConsul();
    const lock = await acquireCredentialEncryptionLock(consul);
    const stalled = deferred<unknown>();
    const renew = vi
      .spyOn(consul.session, 'renew')
      .mockReturnValueOnce(stalled.promise);
    const set = vi.spyOn(consul.kv, 'set');
    const destroy = vi.spyOn(consul.session, 'destroy');
    const result =
      mode === 'manual' ? Promise.allSettled([lock.renew()]) : undefined;
    if (mode === 'automatic') await vi.advanceTimersByTimeAsync(20_000);
    await vi.advanceTimersByTimeAsync(10_000);
    if (result) {
      expect(await result).toMatchObject([
        {
          status: 'rejected',
          reason: {
            message: 'Credential encryption lock could not be renewed.',
            cause: { message: 'Credential encryption lock renewal timed out.' },
          },
        },
      ]);
    }
    const renewalCtx = renew.mock.calls[0][0].ctx;
    expect(renewalCtx.canceled).toBe(true);
    expect(() => lock.assertHeld()).toThrow('lock was lost');
    await expect(lock.renew()).rejects.toMatchObject({
      cause: { message: 'Credential encryption lock renewal timed out.' },
    });
    stalled.resolve(undefined);
    await vi.advanceTimersByTimeAsync(60_000);
    expect(() => lock.assertHeld()).toThrow('lock was lost');
    expect(renew).toHaveBeenCalledTimes(1);

    await lock.release();
    expect(set.mock.calls[0][0]).toMatchObject({ release: 'session-1' });
    expect(destroy.mock.calls[0][0]).toMatchObject({ id: 'session-1' });
    for (const ctx of [
      set.mock.calls[0][0].ctx,
      destroy.mock.calls[0][0].ctx,
    ]) {
      expect(ctx).not.toBe(renewalCtx);
      expect(ctx.canceled).toBe(false);
    }
  });

  it.each([
    'rejection',
    'timeout',
  ])('destroys the session after acquisition %s and preserves that failure if cleanup fails', async (mode) => {
    const consul = new FakeConsul();
    const failure = new Error('acquisition failed');
    const set = vi.spyOn(consul.kv, 'set');
    const destroy = vi.spyOn(consul.session, 'destroy');
    if (mode === 'rejection') {
      set.mockRejectedValueOnce(failure);
      destroy.mockRejectedValueOnce(new Error('cleanup failed'));
    } else {
      set.mockImplementationOnce(() => new Promise(() => {}));
      destroy.mockImplementationOnce(() => new Promise(() => {}));
    }
    const result = Promise.allSettled([
      acquireCredentialEncryptionLock(consul),
    ]);
    await vi.advanceTimersByTimeAsync(20_000);
    if (mode === 'rejection') {
      expect(await result).toEqual([{ status: 'rejected', reason: failure }]);
    } else {
      expect(await result).toMatchObject([
        {
          status: 'rejected',
          reason: {
            message: 'Credential encryption lock acquisition timed out.',
          },
        },
      ]);
    }
    expect(destroy).toHaveBeenCalledExactlyOnceWith({
      id: 'session-1',
      ctx: expect.any(EventEmitter),
    });
    expect(set.mock.calls[0][0].ctx.canceled).toBe(true);
    expect(destroy.mock.calls[0][0].ctx.canceled).toBe(true);
    expect(destroy.mock.calls[0][0].ctx).not.toBe(set.mock.calls[0][0].ctx);
  });

  it.each([
    'rejection',
    'timeout',
  ])('always destroys the session and clears renewal after release %s', async (mode) => {
    const consul = new FakeConsul();
    const lock = await acquireCredentialEncryptionLock(consul);
    const failure = new Error('release failed');
    const set = vi.spyOn(consul.kv, 'set');
    if (mode === 'rejection') set.mockRejectedValueOnce(failure);
    else set.mockImplementationOnce(() => new Promise(() => {}));
    const destroy = vi.spyOn(consul.session, 'destroy');
    const renew = vi.spyOn(consul.session, 'renew');
    const result = Promise.allSettled([lock.release()]);
    await vi.advanceTimersByTimeAsync(60_000);

    expect(await result).toMatchObject([
      {
        status: 'rejected',
        reason: {
          message:
            mode === 'rejection'
              ? failure.message
              : 'Credential encryption lock release timed out.',
        },
      },
    ]);
    expect(set.mock.calls[0][0].ctx.canceled).toBe(true);
    expect(destroy).toHaveBeenCalledExactlyOnceWith({
      id: 'session-1',
      ctx: expect.any(EventEmitter),
    });
    expect(destroy.mock.calls[0][0].ctx).not.toBe(set.mock.calls[0][0].ctx);
    expect(destroy.mock.calls[0][0].ctx.canceled).toBe(false);
    expect(renew).not.toHaveBeenCalled();
  });
});
