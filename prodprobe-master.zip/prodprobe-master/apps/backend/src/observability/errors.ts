import { TRPCError } from '@trpc/server';
import { SentryExploreError } from '../rca/sentryExploreClient.js';

export type ProviderErrorCode =
  | 'AUTHENTICATION_FAILED'
  | 'INVALID_CONFIGURATION'
  | 'INVALID_REQUEST'
  | 'OVERLOADED'
  | 'RATE_LIMITED'
  | 'RESPONSE_TOO_LARGE'
  | 'TIMEOUT'
  | 'UNAVAILABLE'
  | 'UNSUPPORTED';

export type ProviderRateLimit = {
  retryAt?: string;
};

export class ProviderError extends Error {
  readonly code: ProviderErrorCode;
  readonly rateLimit?: ProviderRateLimit;

  constructor(
    code: ProviderErrorCode,
    message: string,
    options?: ErrorOptions & { rateLimit?: ProviderRateLimit },
  ) {
    super(message, options);
    this.code = code;
    this.rateLimit = options?.rateLimit;
    this.name = 'ProviderError';
  }
}

export function providerErrorFrom(error: unknown): ProviderError {
  if (error instanceof ProviderError) return error;
  if (error instanceof SentryExploreError) {
    return new ProviderError(error.code, error.message, {
      cause: error,
      rateLimit: error.rateLimit?.retryAt
        ? { retryAt: error.rateLimit.retryAt }
        : undefined,
    });
  }
  return new ProviderError(
    'UNAVAILABLE',
    'The observability provider request could not be completed.',
    { cause: error instanceof Error ? error : undefined },
  );
}

export function providerErrorToTrpcError(error: ProviderError): TRPCError {
  const code = (() => {
    switch (error.code) {
      case 'AUTHENTICATION_FAILED':
      case 'UNSUPPORTED':
        return 'PRECONDITION_FAILED' as const;
      case 'INVALID_CONFIGURATION':
      case 'INVALID_REQUEST':
        return 'BAD_REQUEST' as const;
      case 'RATE_LIMITED':
      case 'OVERLOADED':
        return 'TOO_MANY_REQUESTS' as const;
      case 'TIMEOUT':
        return 'TIMEOUT' as const;
      case 'RESPONSE_TOO_LARGE':
        return 'PAYLOAD_TOO_LARGE' as const;
      case 'UNAVAILABLE':
        return 'INTERNAL_SERVER_ERROR' as const;
    }
  })();
  return new TRPCError({ code, message: error.message, cause: error });
}

export function retryAtFor(error: unknown): string | undefined {
  return error instanceof ProviderError ? error.rateLimit?.retryAt : undefined;
}
