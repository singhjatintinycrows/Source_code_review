import { describe, expect, it } from 'vitest';
import {
  type AuditStore,
  completeEvidenceAudit,
  startEvidenceAudit,
} from './audit.js';
import type { StoredObservabilityConnection } from './contracts.js';

const connection: StoredObservabilityConnection = {
  id: 'connection-a',
  serviceId: 'service-a',
  name: 'Sentry production',
  provider: 'SENTRY',
  publicConfig: {},
  configVersion: 1,
  credentialCiphertext: new Uint8Array([1]),
  credentialNonce: new Uint8Array(12),
  credentialAuthTag: new Uint8Array(16),
  credentialKeyVersion: 'v1',
  credentialFormat: 'SENTRY_AUTH_TOKEN',
  createdAt: new Date(),
  updatedAt: new Date(),
};

describe('evidence audit', () => {
  it('persists connection snapshots and a query fingerprint without raw evidence', async () => {
    const creates: Record<string, unknown>[] = [];
    const updates: Record<string, unknown>[] = [];
    const store: AuditStore = {
      observabilityEvidenceAuditEvent: {
        create: async ({ data }) => {
          creates.push(data);
          return { id: 'audit-a' };
        },
        update: async ({ data }) => {
          updates.push(data);
        },
      },
    };

    const event = await startEvidenceAudit(store, {
      serviceId: 'service-a',
      actorId: 'actor-a',
      connection,
      signal: 'ERRORS',
      purpose: 'Investigate checkout failures',
      query: { filter: 'email:alice@example.com', token: 'never-store-me' },
      start: '2026-08-07T00:00:00.000Z',
      end: '2026-08-07T00:05:00.000Z',
    });
    await completeEvidenceAudit(store, event, {
      outcome: 'COMPLETE',
      resultCount: 2,
      redactionCount: 1,
    });

    expect(creates[0]).toMatchObject({
      connectionId: 'connection-a',
      connectionName: 'Sentry production',
      provider: 'SENTRY',
      purpose: 'Investigate checkout failures',
      queryFingerprint: expect.any(String),
      completedAt: null,
    });
    expect(JSON.stringify(creates[0])).not.toContain('never-store-me');
    expect(updates[0]).toMatchObject({
      outcome: 'SUCCESS',
      resultCount: 2,
      redactionCount: 1,
    });
  });
});
