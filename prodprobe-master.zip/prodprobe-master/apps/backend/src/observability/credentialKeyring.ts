import { hkdfSync, randomUUID } from 'node:crypto';
import { EventEmitter } from 'node:events';
import {
  CREDENTIAL_KEY_BYTES,
  CredentialCipher,
  CredentialCipherError,
  credentialKeyVersionNumber,
} from './credentialCipher.js';

export const CREDENTIAL_ENCRYPTION_KEYRING_KEY =
  'HYPERPROBE/CREDENTIAL_ENCRYPTION/KEYRING';
export const CREDENTIAL_ENCRYPTION_ACTIVE_VERSION_KEY =
  'HYPERPROBE/CREDENTIAL_ENCRYPTION/ACTIVE_VERSION';
export const CREDENTIAL_ENCRYPTION_LOCK_KEY =
  'HYPERPROBE/CREDENTIAL_ENCRYPTION/LOCK';
export const CREDENTIAL_ENCRYPTION_ROTATION_KEY =
  'HYPERPROBE/CREDENTIAL_ENCRYPTION/ROTATION';

const LOCK_TTL = '60s';
const LOCK_RENEWAL_INTERVAL_MS = 20_000;
const CONSUL_REQUEST_TIMEOUT_MS = 10_000;
const KEYRING_READ_ATTEMPTS = 3;
const KEYRING_READ_RETRY_MS = 25;
const BOOTSTRAP_LOCK_ATTEMPTS = 20;
const BOOTSTRAP_LOCK_RETRY_MS = 250;
const UUID_V4_PATTERN =
  /^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/;
const HKDF_SALT = Buffer.from(
  'hyperprobe:credential-encryption:uuid-keyring:v1',
  'utf8',
);
const HKDF_INFO_PREFIX = 'hyperprobe:observability:aes-256-gcm:v1';

type ConsulKvItem = {
  Session?: string | null;
  Value?: string | Buffer | null;
  ModifyIndex?: number;
};

// consul/papi accept a Node EventEmitter context, not an AbortSignal.
type ConsulRequestContext = EventEmitter & { canceled: boolean };

export type CredentialKeyringConsul = {
  kv: {
    get(options: {
      key: string;
      ctx: ConsulRequestContext;
    }): Promise<ConsulKvItem | null | undefined>;
    set(options: {
      key: string;
      value: string;
      acquire?: string;
      release?: string;
      ctx: ConsulRequestContext;
    }): Promise<boolean>;
    del(options: {
      key: string;
      cas: number;
      ctx: ConsulRequestContext;
    }): Promise<boolean>;
  };
  session: {
    create(options: {
      name: string;
      ttl: string;
      behavior: 'release';
      ctx: ConsulRequestContext;
    }): Promise<{ ID?: string }>;
    renew(options: { id: string; ctx: ConsulRequestContext }): Promise<unknown>;
    destroy(options: {
      id: string;
      ctx: ConsulRequestContext;
    }): Promise<unknown>;
  };
  transaction: {
    create: ConsulTransactionCreate;
  };
};

type ConsulTransactionOperation = {
  KV: {
    Verb: 'cas';
    Key: string;
    Value: string;
    Index: number;
  };
};

type ConsulTransactionCreate = (
  operations: ConsulTransactionOperation[],
  options: { ctx: ConsulRequestContext },
) => Promise<unknown>;

export type CredentialEncryptionKeyring = {
  readonly activeVersion: string;
  readonly cipher: CredentialCipher;
  readonly keyringModifyIndex: number;
  readonly activeVersionModifyIndex: number;
  readonly secrets: ReadonlyMap<string, string>;
};

export type CredentialEncryptionLock = {
  assertHeld(): void;
  renew(): Promise<void>;
  release(): Promise<void>;
};

export type CredentialEncryptionRotation = {
  readonly modifyIndex: number;
  readonly version: string;
};

export class CredentialKeyringError extends Error {
  constructor(message: string, options?: ErrorOptions) {
    super(message, options);
    this.name = 'CredentialKeyringError';
  }
}

export class CredentialEncryptionLockUnavailableError extends CredentialKeyringError {
  constructor() {
    super('Credential encryption maintenance is already in progress.');
    this.name = 'CredentialEncryptionLockUnavailableError';
  }
}

export class CredentialEncryptionInitializationRequiredError extends CredentialKeyringError {
  constructor() {
    super(
      'Credential encryption keys are missing while observability connections exist. Run the explicit destructive initialization script before starting the backend.',
    );
    this.name = 'CredentialEncryptionInitializationRequiredError';
  }
}

function consulValue(item: ConsulKvItem | null | undefined): string | null {
  if (!item || item.Value === undefined || item.Value === null) return null;
  return Buffer.isBuffer(item.Value) ? item.Value.toString('utf8') : item.Value;
}

function modificationIndex(item: ConsulKvItem, key: string): number {
  if (
    typeof item.ModifyIndex !== 'number' ||
    !Number.isSafeInteger(item.ModifyIndex) ||
    item.ModifyIndex <= 0
  ) {
    throw new CredentialKeyringError(
      `Consul key '${key}' has an invalid modification index.`,
    );
  }
  return item.ModifyIndex;
}

function encodedTransactionValue(value: string): string {
  return Buffer.from(value, 'utf8').toString('base64');
}

function wait(milliseconds: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, milliseconds));
}

function withTimeout<T>(
  start: (ctx: ConsulRequestContext) => Promise<T>,
  message: string,
): Promise<T> {
  return new Promise((resolve, reject) => {
    const ctx = Object.assign(new EventEmitter(), { canceled: false });
    let settled = false;
    const fail = (error: unknown) => {
      if (settled) return;
      settled = true;
      clearTimeout(timeout);
      ctx.canceled = true;
      // Consul can resolve an aborted, unfinished 404 as missing. Reject first.
      reject(error);
      ctx.emit('cancel');
    };
    const timeout = setTimeout(() => {
      fail(new CredentialKeyringError(message));
    }, CONSUL_REQUEST_TIMEOUT_MS);
    try {
      void start(ctx).then((value) => {
        if (settled) return;
        settled = true;
        clearTimeout(timeout);
        resolve(value);
      }, fail);
    } catch (error) {
      fail(error);
    }
  });
}

function isTransactionConflict(error: unknown): boolean {
  return (
    typeof error === 'object' &&
    error !== null &&
    'statusCode' in error &&
    (error as { statusCode?: unknown }).statusCode === 409
  );
}

async function createTransaction(
  consul: CredentialKeyringConsul,
  operations: ConsulTransactionOperation[],
): Promise<void> {
  const result = (await withTimeout(
    (ctx) => consul.transaction.create(operations, { ctx }),
    'Credential encryption Consul transaction timed out.',
  )) as { Errors?: unknown };
  if (Array.isArray(result?.Errors) && result.Errors.length > 0) {
    throw new CredentialKeyringError('Consul transaction was rejected.');
  }
}

function credentialSecret(value: unknown, version: string): string {
  if (typeof value !== 'string' || !UUID_V4_PATTERN.test(value)) {
    throw new CredentialCipherError(
      'INVALID_CONFIGURATION',
      `Credential encryption secret ${version} must be a canonical UUID v4.`,
    );
  }
  return value;
}

export function parseCredentialEncryptionKeyring(
  contents: string,
): ReadonlyMap<string, string> {
  let parsed: unknown;
  try {
    parsed = JSON.parse(contents);
  } catch (error) {
    throw new CredentialCipherError(
      'INVALID_CONFIGURATION',
      'Credential encryption keyring must contain a JSON object.',
      { cause: error },
    );
  }
  if (
    typeof parsed !== 'object' ||
    parsed === null ||
    Array.isArray(parsed) ||
    Object.keys(parsed).length === 0
  ) {
    throw new CredentialCipherError(
      'INVALID_CONFIGURATION',
      'Credential encryption keyring must contain one or more versioned UUIDs.',
    );
  }

  const secrets = new Map<string, string>();
  const seenSecrets = new Set<string>();
  for (const [version, value] of Object.entries(parsed)) {
    credentialKeyVersionNumber(version);
    const secret = credentialSecret(value, version);
    if (seenSecrets.has(secret)) {
      throw new CredentialCipherError(
        'INVALID_CONFIGURATION',
        'Credential encryption keyring must not reuse a UUID across versions.',
      );
    }
    seenSecrets.add(secret);
    secrets.set(version, secret);
  }
  return secrets;
}

export function deriveCredentialEncryptionKey(
  secret: string,
  version: string,
): Buffer {
  credentialKeyVersionNumber(version);
  const normalizedSecret = credentialSecret(secret, version);
  return Buffer.from(
    hkdfSync(
      'sha256',
      Buffer.from(normalizedSecret, 'utf8'),
      HKDF_SALT,
      Buffer.from(`${HKDF_INFO_PREFIX}:${version}`, 'utf8'),
      CREDENTIAL_KEY_BYTES,
    ),
  );
}

export function nextCredentialKeyVersion(
  secrets: ReadonlyMap<string, string>,
): string {
  let maximum = 0;
  for (const version of secrets.keys()) {
    maximum = Math.max(maximum, credentialKeyVersionNumber(version));
  }
  if (maximum >= Number.MAX_SAFE_INTEGER) {
    throw new CredentialKeyringError(
      'Credential encryption key version is too large to rotate.',
    );
  }
  return `v${maximum + 1}`;
}

function cipherForKeyring(
  secrets: ReadonlyMap<string, string>,
  activeVersion: string,
): CredentialCipher {
  credentialKeyVersionNumber(activeVersion);
  if (!secrets.has(activeVersion)) {
    throw new CredentialCipherError(
      'INVALID_CONFIGURATION',
      'The active credential encryption key version is absent from the keyring.',
    );
  }
  return new CredentialCipher({
    currentKeyVersion: activeVersion,
    keys: new Map(
      [...secrets.entries()].map(([version, secret]) => [
        version,
        deriveCredentialEncryptionKey(secret, version),
      ]),
    ),
  });
}

function serializedKeyring(secrets: ReadonlyMap<string, string>): string {
  return JSON.stringify(
    Object.fromEntries(
      [...secrets.entries()].sort(
        ([left], [right]) =>
          credentialKeyVersionNumber(left) - credentialKeyVersionNumber(right),
      ),
    ),
  );
}

type ConsulKeyringItems = {
  keyringItem: ConsulKvItem | null | undefined;
  activeVersionItem: ConsulKvItem | null | undefined;
};

async function readKeyringItems(
  consul: CredentialKeyringConsul,
): Promise<ConsulKeyringItems> {
  const [keyringItem, activeVersionItem] = await Promise.all([
    withTimeout(
      (ctx) => consul.kv.get({ key: CREDENTIAL_ENCRYPTION_KEYRING_KEY, ctx }),
      'Timed out reading the credential encryption keyring from Consul.',
    ),
    withTimeout(
      (ctx) =>
        consul.kv.get({ key: CREDENTIAL_ENCRYPTION_ACTIVE_VERSION_KEY, ctx }),
      'Timed out reading the credential encryption active version from Consul.',
    ),
  ]);
  return { keyringItem, activeVersionItem };
}

function keyringFromItems(
  items: ConsulKeyringItems,
): CredentialEncryptionKeyring | null {
  const keyring = consulValue(items.keyringItem);
  const activeVersion = consulValue(items.activeVersionItem);
  if (keyring === null && activeVersion === null) return null;
  if (keyring === null || activeVersion === null) {
    throw new CredentialKeyringError(
      'Credential encryption keyring is incomplete in Consul.',
    );
  }
  if (
    !items.keyringItem ||
    !items.activeVersionItem ||
    activeVersion.trim() !== activeVersion
  ) {
    throw new CredentialKeyringError(
      'Credential encryption keyring is invalid in Consul.',
    );
  }

  const secrets = parseCredentialEncryptionKeyring(keyring);
  credentialKeyVersionNumber(activeVersion);
  const keyringModifyIndex = modificationIndex(
    items.keyringItem,
    CREDENTIAL_ENCRYPTION_KEYRING_KEY,
  );
  const activeVersionModifyIndex = modificationIndex(
    items.activeVersionItem,
    CREDENTIAL_ENCRYPTION_ACTIVE_VERSION_KEY,
  );
  if (keyringModifyIndex !== activeVersionModifyIndex) {
    throw new CredentialKeyringError(
      'Credential encryption keyring changed while it was being read from Consul.',
    );
  }
  return {
    activeVersion,
    cipher: cipherForKeyring(secrets, activeVersion),
    keyringModifyIndex,
    activeVersionModifyIndex,
    secrets,
  };
}

export async function loadCredentialEncryptionKeyring(
  consul: CredentialKeyringConsul,
): Promise<CredentialEncryptionKeyring | null> {
  let lastError: unknown;
  for (let attempt = 0; attempt < KEYRING_READ_ATTEMPTS; attempt += 1) {
    try {
      return keyringFromItems(await readKeyringItems(consul));
    } catch (error) {
      lastError = error;
      if (attempt + 1 < KEYRING_READ_ATTEMPTS) {
        await wait(KEYRING_READ_RETRY_MS);
      }
    }
  }
  throw (
    lastError ??
    new CredentialKeyringError(
      'Credential encryption keyring could not be read from Consul.',
    )
  );
}

export async function isCredentialEncryptionMaintenanceActive(
  consul: CredentialKeyringConsul,
): Promise<boolean> {
  const [lock, rotation] = await withTimeout(
    (ctx) =>
      Promise.all(
        [
          CREDENTIAL_ENCRYPTION_LOCK_KEY,
          CREDENTIAL_ENCRYPTION_ROTATION_KEY,
        ].map(async (key) => consul.kv.get({ key, ctx })),
      ),
    'Timed out reading credential encryption maintenance state from Consul.',
  );
  return (
    (typeof lock?.Session === 'string' && lock.Session.length > 0) ||
    (rotation !== null && rotation !== undefined)
  );
}

export async function loadCredentialEncryptionRotation(
  consul: CredentialKeyringConsul,
): Promise<CredentialEncryptionRotation | null> {
  const item = await withTimeout(
    (ctx) => consul.kv.get({ key: CREDENTIAL_ENCRYPTION_ROTATION_KEY, ctx }),
    'Timed out reading credential encryption rotation state from Consul.',
  );
  if (!item) return null;
  const version = consulValue(item);
  if (version === null || version.trim() !== version) {
    throw new CredentialKeyringError(
      'Credential encryption rotation state is invalid in Consul.',
    );
  }
  credentialKeyVersionNumber(version);
  return {
    modifyIndex: modificationIndex(item, CREDENTIAL_ENCRYPTION_ROTATION_KEY),
    version,
  };
}

export async function completeCredentialEncryptionRotation(
  consul: CredentialKeyringConsul,
  version: string,
): Promise<void> {
  const rotation = await loadCredentialEncryptionRotation(consul);
  if (!rotation) return;
  if (rotation.version !== version) {
    throw new CredentialKeyringError(
      'Credential encryption rotation state does not match the active version.',
    );
  }

  try {
    if (
      await withTimeout(
        (ctx) =>
          consul.kv.del({
            key: CREDENTIAL_ENCRYPTION_ROTATION_KEY,
            cas: rotation.modifyIndex,
            ctx,
          }),
        'Credential encryption rotation completion timed out.',
      )
    ) {
      return;
    }
  } catch (error) {
    try {
      if (!(await loadCredentialEncryptionRotation(consul))) return;
    } catch (_reconciliationError) {
      // Preserve the original Consul failure when rotation state cannot be read.
    }
    throw error;
  }

  if (!(await loadCredentialEncryptionRotation(consul))) return;
  throw new CredentialKeyringError(
    'Credential encryption rotation state changed before completion.',
  );
}

async function tryCreateInitialCredentialKeyring(
  consul: CredentialKeyringConsul,
): Promise<boolean> {
  const version = 'v1';
  const secrets = new Map([[version, randomUUID()]]);
  try {
    await createTransaction(consul, [
      {
        KV: {
          Verb: 'cas',
          Key: CREDENTIAL_ENCRYPTION_KEYRING_KEY,
          Value: encodedTransactionValue(serializedKeyring(secrets)),
          Index: 0,
        },
      },
      {
        KV: {
          Verb: 'cas',
          Key: CREDENTIAL_ENCRYPTION_ACTIVE_VERSION_KEY,
          Value: encodedTransactionValue(version),
          Index: 0,
        },
      },
    ]);
    return true;
  } catch (error) {
    if (isTransactionConflict(error)) return false;
    try {
      if (await loadCredentialEncryptionKeyring(consul)) return true;
    } catch (_reconciliationError) {
      // Preserve the original transaction failure when Consul cannot be read.
    }
    throw error;
  }
}

export async function createInitialCredentialEncryptionKeyring(
  consul: CredentialKeyringConsul,
): Promise<CredentialEncryptionKeyring> {
  for (let attempt = 0; attempt < 3; attempt += 1) {
    const existing = await loadCredentialEncryptionKeyring(consul);
    if (existing) return existing;
    if (await tryCreateInitialCredentialKeyring(consul)) {
      const created = await loadCredentialEncryptionKeyring(consul);
      if (created) return created;
      throw new CredentialKeyringError(
        'Credential encryption keyring was not available after initialization.',
      );
    }
  }
  throw new CredentialKeyringError(
    'Credential encryption keyring changed repeatedly during initialization.',
  );
}

export async function appendCredentialEncryptionKeyVersion(
  consul: CredentialKeyringConsul,
  keyring: CredentialEncryptionKeyring,
): Promise<CredentialEncryptionKeyring> {
  const nextVersion = nextCredentialKeyVersion(keyring.secrets);
  if (keyring.secrets.has(nextVersion)) {
    throw new CredentialKeyringError(
      `Credential encryption key version ${nextVersion} already exists.`,
    );
  }
  const secrets = new Map(keyring.secrets);
  secrets.set(nextVersion, randomUUID());

  if (await loadCredentialEncryptionRotation(consul)) {
    throw new CredentialKeyringError(
      'Credential encryption rotation is already in progress.',
    );
  }

  try {
    await createTransaction(consul, [
      {
        KV: {
          Verb: 'cas',
          Key: CREDENTIAL_ENCRYPTION_KEYRING_KEY,
          Value: encodedTransactionValue(serializedKeyring(secrets)),
          Index: keyring.keyringModifyIndex,
        },
      },
      {
        KV: {
          Verb: 'cas',
          Key: CREDENTIAL_ENCRYPTION_ACTIVE_VERSION_KEY,
          Value: encodedTransactionValue(nextVersion),
          Index: keyring.activeVersionModifyIndex,
        },
      },
      {
        KV: {
          Verb: 'cas',
          Key: CREDENTIAL_ENCRYPTION_ROTATION_KEY,
          Value: encodedTransactionValue(nextVersion),
          Index: 0,
        },
      },
    ]);
  } catch (error) {
    if (isTransactionConflict(error)) {
      throw new CredentialKeyringError(
        'Credential encryption keyring changed while rotation was starting.',
        { cause: error },
      );
    }
    try {
      const reconciled = await loadCredentialEncryptionKeyring(consul);
      const rotation = await loadCredentialEncryptionRotation(consul);
      if (
        reconciled &&
        reconciled.activeVersion === nextVersion &&
        reconciled.secrets.get(nextVersion) === secrets.get(nextVersion) &&
        rotation?.version === nextVersion
      ) {
        return reconciled;
      }
    } catch (_reconciliationError) {
      // Preserve the original transaction failure when Consul cannot be read.
    }
    throw error;
  }

  const updated = await loadCredentialEncryptionKeyring(consul);
  const rotation = await loadCredentialEncryptionRotation(consul);
  if (
    !updated ||
    updated.activeVersion !== nextVersion ||
    updated.secrets.get(nextVersion) !== secrets.get(nextVersion) ||
    rotation?.version !== nextVersion
  ) {
    throw new CredentialKeyringError(
      'Credential encryption keyring did not contain the rotated version after the Consul transaction.',
    );
  }
  return updated;
}

export async function loadOrInitializeCredentialCipher(
  consul: CredentialKeyringConsul,
  connectionCount: () => Promise<number>,
): Promise<CredentialCipher> {
  for (let attempt = 0; attempt < BOOTSTRAP_LOCK_ATTEMPTS; attempt += 1) {
    const existing = await loadCredentialEncryptionKeyring(consul);
    if (existing) return existing.cipher;
    if (await loadCredentialEncryptionRotation(consul)) {
      throw new CredentialKeyringError(
        'Credential encryption rotation is in progress and must be completed before initialization.',
      );
    }

    let lock: CredentialEncryptionLock;
    try {
      lock = await acquireCredentialEncryptionLock(consul);
    } catch (error) {
      if (
        error instanceof CredentialEncryptionLockUnavailableError &&
        attempt + 1 < BOOTSTRAP_LOCK_ATTEMPTS
      ) {
        await wait(BOOTSTRAP_LOCK_RETRY_MS);
        continue;
      }
      throw error;
    }
    try {
      const keyring = await loadCredentialEncryptionKeyring(consul);
      if (keyring) return keyring.cipher;
      if (await loadCredentialEncryptionRotation(consul)) {
        throw new CredentialKeyringError(
          'Credential encryption rotation is in progress and must be completed before initialization.',
        );
      }

      if ((await connectionCount()) > 0) {
        throw new CredentialEncryptionInitializationRequiredError();
      }
      return (await createInitialCredentialEncryptionKeyring(consul)).cipher;
    } finally {
      await lock.release();
    }
  }
  throw new CredentialKeyringError(
    'Credential encryption initialization did not acquire the Consul lock.',
  );
}

export async function acquireCredentialEncryptionLock(
  consul: CredentialKeyringConsul,
): Promise<CredentialEncryptionLock> {
  const session = await withTimeout(
    (ctx) =>
      consul.session.create({
        name: 'hyperprobe-credential-encryption',
        ttl: LOCK_TTL,
        behavior: 'release',
        ctx,
      }),
    'Credential encryption lock session creation timed out.',
  );
  if (!session.ID) {
    throw new CredentialKeyringError(
      'Consul did not return a credential encryption lock session.',
    );
  }

  const sessionId = session.ID;
  const owner = randomUUID();
  let renewalError: unknown;
  let renewalInProgress = false;
  const assertHeld = () => {
    if (renewalError) {
      throw new CredentialKeyringError('Credential encryption lock was lost.', {
        cause: renewalError,
      });
    }
  };
  const renew = async () => {
    assertHeld();
    try {
      await withTimeout(
        (ctx) => consul.session.renew({ id: sessionId, ctx }),
        'Credential encryption lock renewal timed out.',
      );
    } catch (error) {
      renewalError = error;
      throw new CredentialKeyringError(
        'Credential encryption lock could not be renewed.',
        { cause: error },
      );
    }
  };

  try {
    const acquired = await withTimeout(
      (ctx) =>
        consul.kv.set({
          key: CREDENTIAL_ENCRYPTION_LOCK_KEY,
          value: owner,
          acquire: sessionId,
          ctx,
        }),
      'Credential encryption lock acquisition timed out.',
    );
    if (!acquired) {
      throw new CredentialEncryptionLockUnavailableError();
    }
  } catch (error) {
    try {
      await withTimeout(
        (ctx) => consul.session.destroy({ id: sessionId, ctx }),
        'Credential encryption lock session cleanup timed out.',
      );
    } catch (_cleanupError) {
      // Preserve the lock acquisition failure.
    }
    throw error;
  }

  const renewalTimer = setInterval(() => {
    if (renewalInProgress || renewalError) return;
    renewalInProgress = true;
    void renew()
      .catch(() => undefined)
      .finally(() => {
        renewalInProgress = false;
      });
  }, LOCK_RENEWAL_INTERVAL_MS);
  renewalTimer.unref();

  return {
    assertHeld,
    renew,
    async release() {
      clearInterval(renewalTimer);
      try {
        await withTimeout(
          (ctx) =>
            consul.kv.set({
              key: CREDENTIAL_ENCRYPTION_LOCK_KEY,
              value: owner,
              release: sessionId,
              ctx,
            }),
          'Credential encryption lock release timed out.',
        );
      } finally {
        await withTimeout(
          (ctx) => consul.session.destroy({ id: sessionId, ctx }),
          'Credential encryption lock session cleanup timed out.',
        );
      }
    },
  };
}
