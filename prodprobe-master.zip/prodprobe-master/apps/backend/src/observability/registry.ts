import type { ObservabilitySignalName, ProviderAdapter } from './contracts.js';
import { ProviderError } from './errors.js';
import { sentryAdapter } from './sentryAdapter.js';

export class ObservabilityProviderRegistry {
  private readonly adapters = new Map<string, ProviderAdapter>();

  constructor(adapters: readonly ProviderAdapter[]) {
    for (const adapter of adapters) {
      this.adapters.set(adapter.provider, adapter);
    }
  }

  get(provider: string): ProviderAdapter | undefined {
    return this.adapters.get(provider.trim().toUpperCase());
  }

  require(provider: string): ProviderAdapter {
    const adapter = this.get(provider);
    if (!adapter) {
      throw new ProviderError(
        'UNSUPPORTED',
        `Observability provider ${provider} is not implemented by this backend.`,
      );
    }
    return adapter;
  }

  supports(provider: string, signal: ObservabilitySignalName): boolean {
    return this.require(provider).supportedSignals.includes(signal);
  }

  metadata() {
    return [...this.adapters.values()].map((adapter) => ({
      id: adapter.provider,
      provider: adapter.provider,
      displayName: adapter.displayName,
      supportedSignals: adapter.supportedSignals,
      credentialFormat: adapter.credentialFormat,
      credentialGuidance: adapter.credentialGuidance,
    }));
  }
}

export const observabilityProviderRegistry = new ObservabilityProviderRegistry([
  sentryAdapter,
]);
