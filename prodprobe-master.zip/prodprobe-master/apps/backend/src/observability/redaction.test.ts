import { describe, expect, it } from 'vitest';
import {
  MAX_TEXT_INSPECTION_CHARACTERS,
  redactEvidence,
  safeFailureMessage,
} from './redaction.js';

const redacted = { value: '[REDACTED]', redactionCount: 1 };
const wrap = (text: string, layers: number): string => {
  for (let layer = 0; layer < layers; layer += 1) text = JSON.stringify(text);
  return text;
};
const unicodeName = (name: string): string =>
  Array.from(
    name,
    (character) =>
      `\\u${character.charCodeAt(0).toString(16).padStart(4, '0')}`,
  ).join('');

describe('redactEvidence', () => {
  it('redacts sensitive fields and common credential-shaped text', () => {
    const result = redactEvidence({
      authorization: 'Bearer abcdefghijklmnop',
      message: 'Contact alice@example.com',
      nested: { apiKey: 'secret-value' },
    });

    expect(result.value).toEqual({
      authorization: '[REDACTED]',
      message: 'Contact [REDACTED]',
      nested: { apiKey: '[REDACTED]' },
    });
    expect(result.redactionCount).toBe(3);
  });

  it.each([
    'payload={"password":"sentinel","api_key":"sentinel"}',
    `prefix ${JSON.stringify({ nested: { password: 'sentinel' } })} suffix`,
    'first={"ok":true} second={"password":"sentinel"} third={"token":"sentinel"}',
    '{"password":"sentinel-first","password":"sentinel-second"}',
    '{"detail":"password=sentinel","detail":"public"}',
    JSON.stringify({ message: 'nested payload={"api_key":"sentinel"}' }),
    JSON.stringify({ 'user password hint': 'sentinel' }),
    JSON.stringify({ 'password "quoted" hint': 'sentinel' }),
    "{'user password hint': 'sentinel'}",
    'settings.PaSsWoRd = sentinel',
    'config[api_key]=sentinel',
    'config["api_key"]=sentinel',
    "config['API-KEY']: sentinel",
    'config [ "password" ] = sentinel',
    'password [ "child" ] = sentinel',
    'config["api_key" ]["child"] = sentinel',
    'config["password hint"]["child"] = sentinel',
    'config["password:hint"].child = sentinel',
    '"password hint" . child = sentinel',
    'credentials . value = sentinel',
    'Authorization: Basic c2VudGluZWw=',
    'a header\r\naUtHoRiZaTiOn : Basic sentinel==\r\nend',
    'Cookie: session = sentinel; mode = public',
    'Set-Cookie: session = sentinel; Path=/',
    'headers[Authorization] = Basic sentinel==',
    '/v1/items?api%5Fkey=sentinel&limit=1',
    '/v1/items?%61%70%69%5f%6b%65%79=sentinel',
    'public=true&API%2dKEY=sentinel',
    '--api-key=sentinel --public=true',
    '--password = "sentinel with spaces"',
    'client_secret=sentinel',
    'refreshToken: sentinel',
    'credential=null',
    'password=false',
    'token=42',
  ])('omits a string containing a sensitive assignment: %s', (text) => {
    expect(redactEvidence(text)).toEqual(redacted);
  });

  it.each([
    0, 1, 2,
  ])('inspects raw and decoded JSON at wrapping depth %i', (layers) => {
    const payloads = [
      JSON.stringify({ password: 'sentinel', api_key: 'sentinel' }),
      JSON.stringify({
        message: 'A "quoted" failure',
        nested: { token: 'sentinel\\suffix"' },
      }),
      JSON.stringify({ 'password "quoted" hint': 'sentinel' }),
      `{"pass\\u0077ord":"sentinel"}`,
      `{"${unicodeName('api_key')}":"sentinel"}`,
      `{"${unicodeName('API-KEY')}":"sentinel"}`,
      `{"${unicodeName('headers.Authorization')}":"sentinel"}`,
      `{"${unicodeName('safe')}":true,"${unicodeName('api_key')}":"sentinel"}`,
    ] as const;
    for (const payload of payloads) {
      const text = wrap(payload, layers);
      expect(redactEvidence(text)).toEqual(redacted);
      expect(redactEvidence(`prefix payload=${text} suffix`)).toEqual(redacted);
    }
    // Decoding is inspection only, even when the raw view already matches.
    expect(
      redactEvidence(`password=sentinel; encoded=${wrap(payloads[4], layers)}`),
    ).toEqual(redacted);
  });

  it.each([
    'prefix {"password":"sentinel',
    'prefix {"api_key": "sentinel\\',
    'payload={"safe":true,"password":',
    'password=',
    'password = "sentinel" trailing malformed }}}',
    'password={"unclosed":"sentinel',
    '{"\\u00":"sentinel"}',
    '{"\\uZZZZ":"sentinel"}',
    '{"\\q":"sentinel"}',
    '{"unknown \\u12 key":"sentinel"}',
    '{"\\u00',
    '{"\\u00 missing quote: sentinel}',
    '{"safe":1,"\\u00',
    '{"safe":1,"\\u00 missing quote: sentinel}',
    '{"safe":[],"\\q"}',
    '/items?api%ZZkey=sentinel',
    '/items?%61%70%69%=sentinel',
    '/items?%E0%A4=sentinel',
    '/items?%2561pi%255Fkey=sentinel',
  ])('fails closed on malformed or unchecked keyed payloads: %s', (payload) => {
    for (const layers of [0, 1, 2]) {
      expect(redactEvidence(wrap(payload, layers))).toEqual(redacted);
    }
  });

  it.each([
    3, 4, 8,
  ])('omits unsupported wrapping depth %i without exposing a prefix', (layers) => {
    for (const payload of [
      JSON.stringify({ password: 'sentinel' }),
      `{"${unicodeName('api_key')}":"sentinel"}`,
      // No raw policy word or even raw punctuation is available for a precheck.
      unicodeName(JSON.stringify({ api_key: 'sentinel' })),
    ]) {
      expect(redactEvidence(wrap(payload, layers))).toEqual(redacted);
      expect(
        redactEvidence(`prefix payload=${wrap(payload, layers)} suffix`),
      ).toEqual(redacted);
    }
    expect(
      redactEvidence(wrap(JSON.stringify({ status: 'ok' }), layers)),
    ).toEqual(redacted);
  });

  it('omits deeply escaped Unicode payloads even without outer string quotes', () => {
    let payload = unicodeName(JSON.stringify({ password: 'sentinel' }));
    for (let layer = 0; layer < 7; layer++) {
      expect(redactEvidence(payload)).toEqual(redacted);
      expect(redactEvidence(`payload=${payload}`)).toEqual(redacted);
      payload = JSON.stringify(payload).slice(1, -1);
    }
  });

  it('decodes policy names inside quoted keys without losing the original key boundaries', () => {
    for (const name of [
      'password',
      'api_key',
      'authorization',
      'client_secret',
    ]) {
      const payload = JSON.stringify({
        [`user "${name}" hint`]: 'sentinel',
      }).replace(name, unicodeName(name));
      for (const layers of [0, 1, 2]) {
        const text = wrap(payload, layers);
        expect(redactEvidence(text)).toEqual(redacted);
        expect(redactEvidence(`payload=${text}`)).toEqual(redacted);
        expect(safeFailureMessage(new Error(text))).toBe('[REDACTED]');
      }
    }
  });

  it.each([
    '',
    '[REDACTED]',
    '[OMITTED]',
    'Password reset failed',
    'No token was returned for this request',
    'Authorization was denied',
    '/var/log/password-reset.log',
    'C:\\work\\public\\notes.txt',
    '\\\\server\\share\\public.txt',
    '/v1/items?limit=10&status=ok',
    'status=ok; retries: 2',
    '[token] status=ok',
    'config["api key"].child=public',
    JSON.stringify({
      status: 'ok',
      attempts: 2,
      path: 'C:\\work\\public\\notes.txt',
    }),
    JSON.stringify({ 'rate%': 50, message: 'Password reset failed' }),
    JSON.stringify(['Password reset failed', 'public']),
    `{"${unicodeName('status')}":"ok"}`,
  ])('preserves benign text and returns no decoded content: %s', (text) => {
    expect(redactEvidence(text)).toEqual({ value: text, redactionCount: 0 });
  });

  it.each([
    0, 1, 2,
  ])('preserves clean JSON at supported wrapping depth %i', (layers) => {
    for (const payload of [
      JSON.stringify({ status: 'ok', count: 2 }),
      JSON.stringify({
        message: 'A "quoted" failure',
        path: 'C:\\work\\notes.txt',
      }),
      JSON.stringify({ paths: ['public', 'C:\\work\\public.txt'] }),
      `{"${unicodeName('status')}":"ok"}`,
    ]) {
      const text = wrap(payload, layers);
      expect(redactEvidence(text)).toEqual({ value: text, redactionCount: 0 });
      const embedded = `prefix payload=${text} suffix`;
      expect(redactEvidence(embedded)).toEqual({
        value: embedded,
        redactionCount: 0,
      });
    }
  });

  it('checks every policy name with deterministic Unicode key escaping', () => {
    for (const name of [
      'authorization',
      'cookie',
      'credential',
      'password',
      'secret',
      'token',
      'api_key',
    ]) {
      for (let index = 0; index < name.length; index += 1) {
        const escaped =
          name.slice(0, index) +
          unicodeName(name.charAt(index)) +
          name.slice(index + 1);
        for (const layers of [0, 1, 2]) {
          const payload = wrap(`{"${escaped}":"sentinel"}`, layers);
          expect(redactEvidence(`before ${payload} after`)).toEqual(redacted);
        }
      }
    }
  });

  it('preserves scalar/array shape and does not mutate objects', () => {
    const input = [
      null,
      false,
      42,
      'public',
      'password=sentinel',
      { token: 'sentinel' },
    ];
    expect(redactEvidence(input)).toEqual({
      value: [null, false, 42, 'public', '[REDACTED]', { token: '[REDACTED]' }],
      redactionCount: 2,
    });
    expect(input[4]).toBe('password=sentinel');
    expect(input[5]).toEqual({ token: 'sentinel' });
    for (const scalar of [null, undefined, true, 42]) {
      expect(redactEvidence(scalar)).toEqual({
        value: scalar,
        redactionCount: 0,
      });
    }
  });

  it('keeps object-field and standalone bearer/email per-match counts', () => {
    expect(
      redactEvidence({
        password: 'sentinel',
        nested: { cookie: 'sentinel' },
        text: 'Bearer abcdefghijkl+/== and bearer abcdefgh_~.-/+=; alice@example.com, bob+tag@example.co.uk.',
      }),
    ).toEqual({
      value: {
        password: '[REDACTED]',
        nested: { cookie: '[REDACTED]' },
        text: '[REDACTED] and [REDACTED]; [REDACTED], [REDACTED].',
      },
      redactionCount: 6,
    });
    expect(redactEvidence('Bearer short')).toEqual({
      value: 'Bearer short',
      redactionCount: 0,
    });
  });

  it('counts a keyed string only once even when it also contains bearer tokens and emails', () => {
    expect(
      redactEvidence(
        'password=sentinel token=sentinel Bearer abcdefghijkl== alice@example.com',
      ),
    ).toEqual(redacted);
  });

  it('is idempotent and counts only new replacements', () => {
    const first = redactEvidence({
      password: 'sentinel',
      text: 'payload={"api_key":"sentinel","token":"sentinel"}',
      nested: ['Contact alice@example.com', 'Bearer abcdefghijkl+/=='],
    });
    expect(first.redactionCount).toBe(4);
    expect(redactEvidence(first.value)).toEqual({
      value: first.value,
      redactionCount: 0,
    });
    expect(redactEvidence('[REDACTED]')).toEqual({
      value: '[REDACTED]',
      redactionCount: 0,
    });
  });

  it('omits entire over-budget strings, including a 2 MiB provider value', () => {
    const boundary = 'x'.repeat(MAX_TEXT_INSPECTION_CHARACTERS);
    expect(redactEvidence(boundary)).toEqual({
      value: boundary,
      redactionCount: 0,
    });
    for (const text of [
      `${boundary}x`,
      `${boundary} password=sentinel`,
      'x'.repeat(2 * 1024 * 1024),
    ]) {
      expect(redactEvidence(text)).toEqual(redacted);
      expect(redactEvidence(redactEvidence(text).value).redactionCount).toBe(0);
    }
  });

  it('handles deterministic long negative email, backslash and quote runs without retries', () => {
    const size = MAX_TEXT_INSPECTION_CHARACTERS;
    const negatives = [
      'a'.repeat(size),
      'a.'.repeat(size / 2),
      `${'a'.repeat(size - 2)}@x`,
      `a@${'a'.repeat(size - 2)}`,
      `a@${'a.'.repeat((size - 2) / 2)}`,
      `${'a@'.repeat(size / 2)}`,
      '\\'.repeat(size),
      '"'.repeat(size),
      `"${'\\"'.repeat((size - 2) / 2)}`,
      `${' '.repeat(size - 1)}x`,
    ];
    for (let repeat = 0; repeat < 10; repeat += 1) {
      for (const text of negatives) {
        expect(redactEvidence(text)).toEqual({
          value: text,
          redactionCount: 0,
        });
      }
    }
  }, 5_000);
});

describe('safeFailureMessage', () => {
  it('redacts before truncation, including sensitive assignments beyond character 512', () => {
    expect(
      safeFailureMessage(new Error(`${'x'.repeat(600)} password=sentinel`)),
    ).toBe('[REDACTED]');
    expect(
      safeFailureMessage(
        new Error(`${'x'.repeat(500)} Bearer abcdefghijkl+/==`),
      ),
    ).toBe(`${'x'.repeat(500)} [REDACTED]`);
    expect(safeFailureMessage(new Error('x'.repeat(2 * 1024 * 1024)))).toBe(
      '[REDACTED]',
    );
  });

  it('still sanitizes controls, truncates benign messages and hides non-Error inputs', () => {
    expect(safeFailureMessage(new Error('Provider\nrequest\u0000failed'))).toBe(
      'Provider request failed',
    );
    expect(safeFailureMessage(new Error('x'.repeat(600)))).toBe(
      'x'.repeat(512),
    );
    expect(safeFailureMessage('password=sentinel')).toBe(
      'Provider request failed.',
    );
  });
});
