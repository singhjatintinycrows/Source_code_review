import type { ProviderErrorCode } from './errors.js';

export const OBSERVABILITY_SIGNALS = [
  'ERRORS',
  'LOGS',
  'TRACES',
  'METRICS',
  'ALERTS',
] as const;

export type ObservabilitySignalName = (typeof OBSERVABILITY_SIGNALS)[number];

export type EvidenceScope = {
  environment: string;
  providerEnvironment: string;
  release?: string;
};

export type StoredObservabilityConnection = {
  id: string;
  serviceId: string;
  name: string;
  provider: string;
  publicConfig: unknown;
  configVersion: number;
  credentialCiphertext: Uint8Array;
  credentialNonce: Uint8Array;
  credentialAuthTag: Uint8Array;
  credentialKeyVersion: string;
  credentialFormat: string;
  enabled?: boolean;
  createdAt: Date;
  updatedAt: Date;
};

export type StoredCapabilityBinding = {
  id: string;
  serviceId: string;
  signal: ObservabilitySignalName;
  connectionId: string;
  connection: StoredObservabilityConnection;
};

export type ProviderPage = {
  hasMore: boolean;
  nextCursor?: string;
};

export type ProviderTableQuery = {
  signal: Extract<ObservabilitySignalName, 'ERRORS' | 'LOGS' | 'TRACES'>;
  scope: EvidenceScope;
  start: string;
  end: string;
  filter?: string;
  traceId?: string;
  traceFormat?: string;
  limit: number;
  cursor?: string;
};

export type ProviderMetricQuery = {
  scope: EvidenceScope;
  start: string;
  end: string;
  filter?: string;
  metric: 'THROUGHPUT' | 'FAILURE_RATE';
  intervalSeconds: number;
};

export type ProviderAlertQuery = {
  scope: EvidenceScope;
  start: string;
  end: string;
  filter?: string;
  limit: number;
  cursor?: string;
};

export type ProviderDiscoveryFailure = {
  code: ProviderErrorCode;
  reason: string;
  retryAt?: string;
};

export type ProviderDiscoveryAvailability<T> =
  | { availability: 'AVAILABLE'; values: T[] }
  | ({ availability: 'UNAVAILABLE' } & ProviderDiscoveryFailure);

export type ProviderDiscoveryResult = {
  alerts: ProviderDiscoveryAvailability<Record<string, never>>;
  environments: ProviderDiscoveryAvailability<string>;
  releases: ProviderDiscoveryAvailability<Record<string, unknown>>;
  tags: ProviderDiscoveryAvailability<Record<string, unknown>>;
};

export type ProviderAdapter = {
  readonly provider: string;
  readonly displayName: string;
  readonly credentialFormat: string;
  readonly credentialGuidance: string;
  readonly supportedSignals: readonly ObservabilitySignalName[];
  validateConnectionConfig(config: unknown): Record<string, unknown>;
  validatePublicConfig(config: unknown): Record<string, unknown>;
  resolveConnectionConfig(
    config: Record<string, unknown>,
    credential: string,
  ): Promise<Record<string, unknown>>;
  queryTable(
    connection: StoredObservabilityConnection,
    credential: string,
    query: ProviderTableQuery,
  ): Promise<{ rows: unknown[]; page: ProviderPage }>;
  queryMetrics(
    connection: StoredObservabilityConnection,
    credential: string,
    query: ProviderMetricQuery,
  ): Promise<{ timeSeries: unknown[]; meta: Record<string, unknown> }>;
  queryAlerts(
    connection: StoredObservabilityConnection,
    credential: string,
    query: ProviderAlertQuery,
  ): Promise<{ rows: unknown[]; page: ProviderPage }>;
  discoverContext(
    connection: StoredObservabilityConnection,
    credential: string,
  ): Promise<ProviderDiscoveryResult>;
};
