import { EventEmitter, once } from 'node:events';
import {
  createServer,
  type IncomingMessage,
  type ServerResponse,
} from 'node:http';
import { createRequire } from 'node:module';
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import {
  acquireCredentialEncryptionLock,
  CREDENTIAL_ENCRYPTION_LOCK_KEY,
  CREDENTIAL_ENCRYPTION_ROTATION_KEY,
  type CredentialEncryptionLock,
  type CredentialKeyringConsul,
  completeCredentialEncryptionRotation,
  createInitialCredentialEncryptionKeyring,
  isCredentialEncryptionMaintenanceActive,
  loadCredentialEncryptionRotation,
} from './credentialKeyring.js';

type RequestContext = Parameters<
  CredentialKeyringConsul['kv']['get']
>[0]['ctx'];
type TransportConsul = CredentialKeyringConsul &
  EventEmitter & {
    destroy(): void;
    watch(options: {
      method: CredentialKeyringConsul['kv']['get'];
      options: { key: string; wait: string };
    }): EventEmitter & { end(): void; isRunning(): boolean };
    _ext(
      event: 'onRequest',
      callback: (request: { ctx: RequestContext }, next: () => void) => void,
    ): void;
  };

// Resolve only the installed client, without importing common's startup/config.
const require = createRequire(import.meta.url);
const Consul = createRequire(
  require.resolve('@hyperprobe/common/package.json'),
)('consul') as new (options: {
  host: string;
  port: number;
  secure: boolean;
}) => TransportConsul;
const nativeTimers = { setTimeout, clearTimeout };

function deferred<T = void>() {
  let resolve!: (value: T) => void;
  const promise = new Promise<T>((done) => {
    resolve = done;
  });
  return { promise, resolve };
}

async function bounded<T>(promise: Promise<T>): Promise<T> {
  let timer!: ReturnType<typeof setTimeout>;
  const watchdog = new Promise<never>((_resolve, reject) => {
    timer = nativeTimers.setTimeout(
      () => reject(new Error('Local Consul transport test watchdog expired.')),
      2_000,
    );
  });
  try {
    return await Promise.race([promise, watchdog]);
  } finally {
    nativeTimers.clearTimeout(timer);
  }
}

async function withConsul(
  handler: (request: IncomingMessage, response: ServerResponse) => void,
  run: (consul: TransportConsul) => Promise<void>,
) {
  const server = createServer(handler);
  server.listen(0, '127.0.0.1');
  await bounded(once(server, 'listening'));
  const address = server.address();
  if (!address || typeof address === 'string')
    throw new Error('Expected a local TCP stub.');
  const consul = new Consul({
    host: '127.0.0.1',
    port: address.port,
    secure: false,
  });
  try {
    await bounded(run(consul));
  } finally {
    // Only this test's private client and ephemeral server are destroyed.
    consul.destroy();
    const closed = once(server, 'close');
    server.close();
    server.closeAllConnections();
    await bounded(closed);
  }
}

function track(request: IncomingMessage, response: ServerResponse) {
  return {
    request,
    response,
    // Cancellation may reset the peer; wait for close even if an error precedes it.
    closed: Promise.all([
      new Promise<void>((resolve) => response.once('close', () => resolve())),
      new Promise<void>((resolve) =>
        request.socket.once('close', () => resolve()),
      ),
    ]),
  };
}

beforeEach(() => {
  vi.useFakeTimers({ toFake: ['setTimeout', 'clearTimeout'] });
});

afterEach(() => {
  const timers = vi.getTimerCount();
  vi.useRealTimers();
  vi.restoreAllMocks();
  expect(timers).toBe(0);
});

describe('credential keyring with the installed Consul HTTP transport', () => {
  it.each([
    'silent',
    'unfinished 200',
    'trickling 200',
    'unfinished 404',
    'trickling 404',
  ])('closes both %s responses and sockets on the single maintenance deadline', async (mode) => {
    const seen = deferred();
    const headers = deferred();
    const requests: ReturnType<typeof track>[] = [];
    await withConsul(
      (request, response) => {
        requests.push(track(request, response));
        if (mode !== 'silent') {
          response.writeHead(mode.includes('404') ? 404 : 200, {
            'Content-Type': 'application/json',
          });
          response.write('[');
        }
        if (requests.length === 2) seen.resolve();
      },
      async (consul) => {
        let responses = 0;
        consul.on('log', (tags: string[]) => {
          if (tags[1] === 'response' && ++responses === 2) headers.resolve();
        });
        const get = vi.spyOn(consul.kv, 'get');
        const outcome = expect(
          isCredentialEncryptionMaintenanceActive(consul),
        ).rejects.toMatchObject({
          name: 'CredentialKeyringError',
          message:
            'Timed out reading credential encryption maintenance state from Consul.',
        });
        await seen.promise;
        if (mode !== 'silent') await headers.promise;
        const ctx = get.mock.calls[0][0].ctx;
        expect(ctx).toBe(get.mock.calls[1][0].ctx);
        expect(ctx.listenerCount('cancel')).toBe(2);
        expect(vi.getTimerCount()).toBe(1);

        // Advance only after real requests/headers arrive; body progress cannot
        // extend the absolute wrapper deadline. Native watchdogs stay real.
        if (mode.startsWith('trickling')) {
          for (let chunk = 0; chunk < 3; chunk++) {
            await vi.advanceTimersByTimeAsync(2_500);
            for (const { response } of requests) response.write(' ');
          }
          await vi.advanceTimersByTimeAsync(2_499);
        } else {
          await vi.advanceTimersByTimeAsync(9_999);
        }
        expect(ctx.canceled).toBe(false);
        for (const { response } of requests)
          expect(response.destroyed).toBe(false);
        await vi.advanceTimersByTimeAsync(1);
        await outcome;
        await Promise.all(requests.map(({ closed }) => closed));
        for (const { request, response } of requests) {
          expect(response.writableEnded).toBe(false);
          expect(response.destroyed).toBe(true);
          expect(request.socket.destroyed).toBe(true);
        }
        expect(ctx.canceled).toBe(true);
        expect(ctx.listenerCount('cancel')).toBe(0);
        expect(vi.getTimerCount()).toBe(0);
      },
    );
  });

  it.each([
    CREDENTIAL_ENCRYPTION_LOCK_KEY,
    CREDENTIAL_ENCRYPTION_ROTATION_KEY,
  ])('does not treat a completed missing %s plus a pending 404 as inactive', async (missingKey) => {
    const headers = deferred();
    let pending!: ReturnType<typeof track>;
    await withConsul(
      (request, response) => {
        response.writeHead(404, { 'Content-Type': 'text/plain' });
        if (decodeURIComponent(request.url!) === `/v1/kv/${missingKey}`) {
          response.end('missing');
        } else {
          pending = track(request, response);
          response.write('missing');
        }
      },
      async (consul) => {
        let responses = 0;
        consul.on('log', (tags: string[]) => {
          if (tags[1] === 'response' && ++responses === 2) headers.resolve();
        });
        const get = vi.spyOn(consul.kv, 'get');
        const outcome = expect(
          isCredentialEncryptionMaintenanceActive(consul),
        ).rejects.toThrow(
          'Timed out reading credential encryption maintenance state from Consul.',
        );
        await headers.promise;
        const missing = get.mock.calls.findIndex(
          ([options]) => options.key === missingKey,
        );
        await expect(get.mock.results[missing].value).resolves.toBeUndefined();
        const ctx = get.mock.calls[0][0].ctx;
        expect(ctx.listenerCount('cancel')).toBe(1);
        await vi.advanceTimersByTimeAsync(10_000);
        await outcome;
        await pending.closed;
        expect(pending.response.writableEnded).toBe(false);
        expect(pending.request.socket.destroyed).toBe(true);
        expect(ctx.listenerCount('cancel')).toBe(0);
      },
    );
  });

  it.each([
    CREDENTIAL_ENCRYPTION_LOCK_KEY,
    CREDENTIAL_ENCRYPTION_ROTATION_KEY,
  ])('preserves an early 500 from %s and aborts its pending sibling', async (failedKey) => {
    const seen = deferred();
    const requests: ReturnType<typeof track>[] = [];
    await withConsul(
      (request, response) => {
        requests.push(track(request, response));
        if (requests.length === 2) seen.resolve();
      },
      async (consul) => {
        const get = vi.spyOn(consul.kv, 'get');
        const result = isCredentialEncryptionMaintenanceActive(consul).catch(
          (error: unknown) => error,
        );
        await seen.promise;
        const failed = requests.find(
          ({ request }) =>
            decodeURIComponent(request.url!) === `/v1/kv/${failedKey}`,
        )!;
        const pending = requests.find((request) => request !== failed)!;
        failed.response.writeHead(500, { 'Content-Type': 'text/plain' });
        failed.response.end('Consul unavailable');
        const failedCall = get.mock.calls.findIndex(
          ([options]) => options.key === failedKey,
        );
        const error = await result;
        expect(error).toBe(
          await get.mock.results[failedCall].value.catch(
            (error: unknown) => error,
          ),
        );
        expect(error).toMatchObject({ statusCode: 500 });
        await pending.closed;
        expect(pending.response.writableEnded).toBe(false);
        expect(pending.request.socket.destroyed).toBe(true);
        expect(get.mock.calls[0][0].ctx.canceled).toBe(true);
        expect(get.mock.calls[0][0].ctx.listenerCount('cancel')).toBe(0);
        expect(vi.getTimerCount()).toBe(0);
      },
    );
  });

  it.each([
    false,
    true,
  ])('clears healthy cancel listeners and timers (active=%s)', async (active) => {
    await withConsul(
      (request, response) => {
        if (
          active &&
          decodeURIComponent(request.url!) ===
            `/v1/kv/${CREDENTIAL_ENCRYPTION_LOCK_KEY}`
        ) {
          response.writeHead(200, { 'Content-Type': 'application/json' });
          response.end(JSON.stringify([{ Session: 'session-1' }]));
        } else {
          response.writeHead(404);
          response.end();
        }
      },
      async (consul) => {
        const get = vi.spyOn(consul.kv, 'get');
        await expect(
          isCredentialEncryptionMaintenanceActive(consul),
        ).resolves.toBe(active);
        const ctx = get.mock.calls[0][0].ctx;
        const emit = vi.spyOn(ctx, 'emit');
        expect(ctx.listenerCount('cancel')).toBe(0);
        expect(vi.getTimerCount()).toBe(0);
        await vi.advanceTimersByTimeAsync(60_000);
        expect(ctx.canceled).toBe(false);
        expect(emit).not.toHaveBeenCalled();
      },
    );
  });

  it('leaves an unrelated GET and watch on the same client running', async () => {
    const seen = deferred();
    const requests = new Map<string, ReturnType<typeof track>>();
    await withConsul(
      (request, response) => {
        const path = decodeURIComponent(
          new URL(request.url!, 'http://127.0.0.1').pathname,
        );
        requests.set(path, track(request, response));
        if (requests.size === 4) seen.resolve();
      },
      async (consul) => {
        const unrelatedCtx = Object.assign(new EventEmitter(), {
          canceled: false,
        });
        const unrelated = consul.kv.get({
          key: 'unrelated-get',
          ctx: unrelatedCtx,
        });
        const watch = consul.watch({
          method: consul.kv.get,
          options: { key: 'unrelated-watch', wait: '30s' },
        });
        const watchError = vi.fn();
        watch.on('error', watchError);
        try {
          const changed = once(watch, 'change');
          watch.once('change', () => watch.end());
          const outcome = expect(
            isCredentialEncryptionMaintenanceActive(consul),
          ).rejects.toThrow('Timed out');
          await seen.promise;
          await vi.advanceTimersByTimeAsync(10_000);
          await outcome;
          await Promise.all([
            requests.get(`/v1/kv/${CREDENTIAL_ENCRYPTION_LOCK_KEY}`)!.closed,
            requests.get(`/v1/kv/${CREDENTIAL_ENCRYPTION_ROTATION_KEY}`)!
              .closed,
          ]);
          expect(watch.isRunning()).toBe(true);
          expect(unrelatedCtx.canceled).toBe(false);
          for (const key of ['unrelated-get', 'unrelated-watch']) {
            const { request, response } = requests.get(`/v1/kv/${key}`)!;
            expect(response.destroyed).toBe(false);
            expect(request.socket.destroyed).toBe(false);
            response.writeHead(200, {
              'Content-Type': 'application/json',
              'X-Consul-Index': '1',
            });
            response.end(
              JSON.stringify([
                { Value: Buffer.from(key).toString('base64'), ModifyIndex: 1 },
              ]),
            );
          }
          await expect(unrelated).resolves.toMatchObject({
            Value: 'unrelated-get',
          });
          expect((await changed)[0]).toMatchObject({
            Value: 'unrelated-watch',
          });
          expect(watchError).not.toHaveBeenCalled();
          expect(unrelatedCtx.listenerCount('cancel')).toBe(0);
          expect(watch.listenerCount('cancel')).toBe(0);
          expect(vi.getTimerCount()).toBe(0);
        } finally {
          watch.end();
        }
      },
    );
  });

  it.each([
    ['session creation', 'PUT', '/v1/session/create'],
    [
      'acquisition',
      'PUT',
      `/v1/kv/${CREDENTIAL_ENCRYPTION_LOCK_KEY}?acquire=session-1`,
    ],
    ['renewal', 'PUT', '/v1/session/renew/session-1'],
    [
      'release',
      'PUT',
      `/v1/kv/${CREDENTIAL_ENCRYPTION_LOCK_KEY}?release=session-1`,
    ],
    ['session cleanup', 'PUT', '/v1/session/destroy/session-1'],
    [
      'rotation completion',
      'DELETE',
      `/v1/kv/${CREDENTIAL_ENCRYPTION_ROTATION_KEY}?cas=7`,
    ],
  ])("aborts the actual %s request using that API's context option", async (phase, method, path) => {
    const seen = deferred<ReturnType<typeof track>>();
    await withConsul(
      (request, response) => {
        const url = decodeURIComponent(request.url!);
        if (request.method === method && url === path) {
          seen.resolve(track(request, response));
          return;
        }
        response.writeHead(200, { 'Content-Type': 'application/json' });
        if (url === '/v1/session/create') {
          response.end(JSON.stringify({ ID: 'session-1' }));
        } else if (request.method === 'GET') {
          response.end(
            JSON.stringify([
              { Value: Buffer.from('v2').toString('base64'), ModifyIndex: 7 },
            ]),
          );
        } else {
          response.end('true');
        }
      },
      async (consul) => {
        let lock: CredentialEncryptionLock | undefined;
        let pending: Promise<unknown>;
        if (phase === 'session creation' || phase === 'acquisition') {
          pending = acquireCredentialEncryptionLock(consul);
        } else if (phase === 'rotation completion') {
          pending = completeCredentialEncryptionRotation(consul, 'v2');
        } else {
          lock = await acquireCredentialEncryptionLock(consul);
          pending = phase === 'renewal' ? lock.renew() : lock.release();
        }
        try {
          const result = pending.catch((error: unknown) => error);
          const request = await seen.promise;
          await vi.advanceTimersByTimeAsync(10_000);
          const message = `Credential encryption ${phase === 'rotation completion' ? '' : 'lock '}${phase} timed out.`;
          expect(await result).toMatchObject(
            phase === 'renewal' ? { cause: { message } } : { message },
          );
          await request.closed;
          expect(request.response.writableEnded).toBe(false);
          expect(request.request.socket.destroyed).toBe(true);
          expect(vi.getTimerCount()).toBe(0);
        } finally {
          if (phase === 'renewal') await lock?.release();
        }
      },
    );
  });

  it('reconciles a committed transaction whose HTTP response was aborted', async () => {
    const committed = deferred<ReturnType<typeof track>>();
    const values = new Map<string, { Value: string; ModifyIndex: number }>();
    let operations: Parameters<
      CredentialKeyringConsul['transaction']['create']
    >[0] = [];
    await withConsul(
      (request, response) => {
        if (request.url === '/v1/txn') {
          const transaction = track(request, response);
          const chunks: Buffer[] = [];
          request.on('data', (chunk: Buffer) => chunks.push(chunk));
          request.on('end', () => {
            operations = JSON.parse(Buffer.concat(chunks).toString('utf8'));
            for (const { KV } of operations)
              values.set(KV.Key, { Value: KV.Value, ModifyIndex: 1 });
            response.writeHead(200, { 'Content-Type': 'application/json' });
            response.write('{');
            committed.resolve(transaction);
          });
        } else {
          const key = decodeURIComponent(request.url!).slice('/v1/kv/'.length);
          const value = values.get(key);
          response.writeHead(value ? 200 : 404, {
            'Content-Type': 'application/json',
          });
          response.end(value ? JSON.stringify([value]) : '');
        }
      },
      async (consul) => {
        const get = vi.spyOn(consul.kv, 'get');
        const create = vi.spyOn(consul.transaction, 'create');
        const pending = createInitialCredentialEncryptionKeyring(consul);
        const request = await committed.promise;
        await vi.advanceTimersByTimeAsync(10_000);
        const keyring = await pending;
        expect(keyring.activeVersion).toBe('v1');
        expect(values.size).toBe(2);
        expect(create).toHaveBeenCalledTimes(1);
        for (const operation of operations)
          expect(operation).toMatchObject({ KV: { Verb: 'cas', Index: 0 } });
        const ctx = create.mock.calls[0][1].ctx;
        expect(ctx.canceled).toBe(true);
        for (const [options] of get.mock.calls) {
          expect(options.ctx).not.toBe(ctx);
          expect(options.ctx.canceled).toBe(false);
          expect(options.ctx.listenerCount('cancel')).toBe(0);
        }
        await request.closed;
        expect(request.response.writableEnded).toBe(false);
        expect(request.request.socket.destroyed).toBe(true);
        expect(ctx.listenerCount('cancel')).toBe(0);
      },
    );
  });

  it('prevents a queued request from dispatching after cancellation', async () => {
    const handler = vi.fn(
      (_request: IncomingMessage, response: ServerResponse) => response.end(),
    );
    await withConsul(handler, async (consul) => {
      const queued = deferred<() => void>();
      consul._ext('onRequest', (_request, next) => queued.resolve(next));
      const get = vi.spyOn(consul.kv, 'get');
      const outcome = expect(
        loadCredentialEncryptionRotation(consul),
      ).rejects.toThrow('Timed out');
      const dispatch = await queued.promise;
      await vi.advanceTimersByTimeAsync(10_000);
      await outcome;
      expect(get.mock.calls[0][0].ctx.canceled).toBe(true);
      dispatch();
      await expect(get.mock.results[0].value).rejects.toThrow(
        'ctx already canceled',
      );
      expect(handler).not.toHaveBeenCalled();
      expect(get.mock.calls[0][0].ctx.listenerCount('cancel')).toBe(0);
    });
  });
});
