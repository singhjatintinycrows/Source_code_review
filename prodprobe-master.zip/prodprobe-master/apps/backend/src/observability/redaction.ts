const SENSITIVE_KEY =
  /(?:authorization|cookie|credential|password|secret|token|api[_-]?key)/i;
const BEARER_TOKEN = /\bBearer\s+[A-Za-z0-9._~+/=-]{8,}/gi;
const EMAIL_ADDRESS = /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}\b/i;
const JSON_ESCAPE = /\\(?:u([\da-fA-F]{4})|(["\\/bfnrt]))/g;
const JSON_ESCAPES: Record<string, string> = {
  '"': '"',
  '\\': '\\',
  '/': '/',
  b: '\b',
  f: '\f',
  n: '\n',
  r: '\r',
  t: '\t',
};
const REDACTED = '[REDACTED]';

// Match the table aggregate budget: omit, rather than inspect or expose a prefix
// of, larger provider strings. This trades evidence detail for bounded work/privacy.
export const MAX_TEXT_INSPECTION_CHARACTERS = 16 * 1024;

export type RedactionResult<T> = {
  value: T;
  redactionCount: number;
};

function decodeJsonEscapes(text: string): string {
  return text.replace(JSON_ESCAPE, (match, unicode: string, simple: string) =>
    unicode
      ? String.fromCharCode(Number.parseInt(unicode, 16))
      : (JSON_ESCAPES[simple] ?? match),
  );
}

function hasSensitiveAssignment(text: string, finalView: boolean): boolean {
  if (!/[:=\\{]/.test(text)) return false;
  const unsafeKey = (key: string, delimiter = ':'): boolean => {
    // Decode the captured name before unescaping quotes can split its boundaries.
    const name = decodeJsonEscapes(key);
    if (SENSITIVE_KEY.test(name)) return true;
    try {
      // Percent encoding belongs to query/form assignment names, not JSON keys.
      const percentEncoded = delimiter === '=' && name.includes('%');
      const decoded = percentEncoded ? decodeURIComponent(name) : name;
      return (
        SENSITIVE_KEY.test(decoded) ||
        (finalView && /\\/.test(decoded)) ||
        (percentEncoded && decoded.includes('%'))
      );
    } catch {
      // A recognizable assignment with an undecodable name is not inspectable.
      return true;
    }
  };
  const suffixAt = (index: number, view = text): string => {
    while (index < view.length && /[\s\]]/.test(view.charAt(index))) index += 1;
    return view[index] ?? '';
  };

  // Inspect quoted names containing spaces/punctuation. Consider adjacent
  // unescaped quotes, not JSON value boundaries: fragments may be malformed.
  const quotes = { '"': -1, "'": -1 };
  const keyStarts = new Map(
    Array.from(text.matchAll(/([{,[])\s*["']/g), (match) => [
      match.index + match[0].length - 1,
      match[1],
    ]),
  );
  const pathCharacters = text.split('');
  for (const match of text.matchAll(/\\[\s\S]|["']/g)) {
    const quote = match[0];
    if (quote !== '"' && quote !== "'") continue;
    const start = quotes[quote];
    const delimiter = suffixAt(match.index + 1);
    if (
      start >= 0 &&
      (delimiter === ':' ||
        delimiter === '=' ||
        keyStarts.get(start) === '{') &&
      unsafeKey(text.slice(start + 1, match.index), delimiter || ':')
    )
      return true;
    let next = match.index + 1;
    while (next < text.length && /\s/.test(text.charAt(next))) next += 1;
    if (
      keyStarts.get(start) === ',' &&
      finalView &&
      !/[,\]]/.test(text[next] ?? '') &&
      text.slice(start + 1, match.index).includes('\\')
    )
      return true;
    if (
      start >= 0 &&
      (keyStarts.get(start) === '[' || delimiter === '.' || delimiter === '[')
    ) {
      // Keep a quoted path component atomic without joining policy words across
      // its punctuation ("api key" must not become "apikey"). Inspection only.
      for (let index = start + 1; index < match.index; index += 1) {
        if (/[\s:=,{}?&();<>]/.test(text.charAt(index)))
          pathCharacters[index] = '.';
      }
    }
    // Decode only complete string literals to detect unsupported wrapping,
    // including embedded fragments. Never parse an object (duplicate keys matter).
    let wrapped = start >= 0 ? text.slice(start, match.index + 1) : '';
    for (let layer = 0; layer < 3 && wrapped.startsWith('"'); layer += 1) {
      try {
        const decoded: unknown = JSON.parse(wrapped);
        if (typeof decoded !== 'string') break;
        if (layer === 2) return true;
        wrapped = decoded.trim();
      } catch {
        break;
      }
    }
    quotes[quote] = match.index;
  }
  for (const start of Object.values(quotes)) {
    if (keyStarts.get(start) === '{' && unsafeKey(text.slice(start + 1)))
      return true;
    if (
      keyStarts.get(start) === ',' &&
      finalView &&
      text.slice(start + 1).includes('\\')
    )
      return true;
  }

  // Consume entire candidate runs before checking their suffix, never retrying
  // an arbitrary value regex at each character. Normalize only path spacing.
  const names = pathCharacters.join('');
  const paths = names.replace(/\s+/g, (space, index: number) =>
    /[.[]/.test(names[index - 1] ?? '') ||
    /[.[\]]/.test(names[index + space.length] ?? '')
      ? ''
      : space,
  );
  for (const match of paths.matchAll(/[^\s:=,{}?&();<>]+/g)) {
    const delimiter = suffixAt(match.index + match[0].length, paths);
    if (
      (delimiter === ':' || delimiter === '=') &&
      unsafeKey(match[0], delimiter)
    )
      return true;
  }
  return false;
}

function redactText(value: string): RedactionResult<string> {
  const omit = (): RedactionResult<string> => ({
    value: REDACTED,
    redactionCount: 1,
  });
  if (value.length > MAX_TEXT_INSPECTION_CHARACTERS) return omit();

  let view = value;
  // Two JSON string layers plus Unicode escapes in the underlying keys.
  // Inspect every view, including raw text; never return a decoded view.
  for (let layer = 0; layer <= 3; layer += 1) {
    const decoded = decodeJsonEscapes(view);
    if (hasSensitiveAssignment(view, layer === 3 || decoded === view))
      return omit();
    // Remaining escaped structure can conceal an unsupported/truncated wrapper.
    if (
      layer === 3 &&
      (/\\u(?:0022|007[bB]|003[aAdD])/.test(view) ||
        (/\\["\\]/.test(view) && /["'{:=]/.test(view)))
    )
      return omit();
    if (decoded === view) break;
    view = decoded;
  }

  let redactionCount = 0;
  const replace = (_match: string): string => {
    redactionCount += 1;
    return REDACTED;
  };
  const text = value.replace(BEARER_TOKEN, replace);
  const parts: string[] = [];
  let localStart = -1;
  let copied = 0;
  // Each local/domain run is examined at most twice. Anchoring prevents the
  // quadratic retries of an unanchored email regex on long negative inputs.
  for (let index = 0; index < text.length; index += 1) {
    const character = text.charAt(index);
    if (character === '@' && localStart >= copied) {
      let end = index + 1;
      while (end < text.length && /[A-Z0-9.-]/i.test(text.charAt(end)))
        end += 1;
      const match = EMAIL_ADDRESS.exec(text.slice(localStart, end));
      if (match) {
        parts.push(text.slice(copied, localStart), replace(match[0]));
        copied = localStart + match[0].length;
      }
    }
    if (!/[A-Z0-9._%+-]/i.test(character)) localStart = -1;
    else if (localStart < copied && /\w/.test(character)) localStart = index;
  }
  parts.push(text.slice(copied));
  return {
    value: parts.join(''),
    redactionCount,
  };
}

export function redactEvidence<T>(input: T): RedactionResult<T> {
  let redactionCount = 0;
  const visit = (value: unknown, depth: number): unknown => {
    if (depth > 12) return '[OMITTED]';
    if (typeof value === 'string') {
      const redacted = redactText(value);
      redactionCount += redacted.redactionCount;
      return redacted.value;
    }
    if (Array.isArray(value))
      return value.map((entry) => visit(entry, depth + 1));
    if (typeof value !== 'object' || value === null) return value;
    return Object.fromEntries(
      Object.entries(value as Record<string, unknown>).map(([key, entry]) => {
        if (SENSITIVE_KEY.test(key)) {
          if (entry !== REDACTED) redactionCount += 1;
          return [key, REDACTED];
        }
        return [key, visit(entry, depth + 1)];
      }),
    );
  };
  return { value: visit(input, 0) as T, redactionCount };
}

export function safeFailureMessage(error: unknown): string {
  const message =
    error instanceof Error ? error.message : 'Provider request failed.';
  return redactEvidence(message)
    .value.replace(/\p{Cc}/gu, ' ')
    .slice(0, 512);
}
