import { describe, expect, it } from 'vitest';
import { CredentialCipher, CredentialCipherError } from './credentialCipher.js';

const owner = {
  serviceId: 'service-a',
  connectionId: 'connection-a',
  provider: 'SENTRY',
  credentialFormat: 'SENTRY_AUTH_TOKEN',
};

function cipher() {
  return new CredentialCipher({
    currentKeyVersion: 'v1',
    keys: new Map([['v1', Buffer.alloc(32, 7)]]),
  });
}

describe('CredentialCipher', () => {
  it('binds encrypted credentials to a provider and credential format', () => {
    const credential = cipher().encrypt(owner, 'sntrys_example_token');

    expect(cipher().decrypt(owner, credential)).toBe('sntrys_example_token');
    expect(() =>
      cipher().decrypt(
        { ...owner, credentialFormat: 'SENTRY_DSN' },
        credential,
      ),
    ).toThrow(CredentialCipherError);
    expect(() =>
      cipher().decrypt({ ...owner, provider: 'OTHER' }, credential),
    ).toThrow(CredentialCipherError);
  });

  it('rejects ciphertext changes and owner swaps', () => {
    const encrypted = cipher().encrypt(owner, 'sntrys_example_token');
    const tamperedCiphertext = Buffer.from(encrypted.credentialCiphertext);
    tamperedCiphertext[0] = tamperedCiphertext[0]! ^ 1;

    expect(() =>
      cipher().decrypt(
        { ...owner, serviceId: 'service-b', connectionId: 'connection-b' },
        encrypted,
      ),
    ).toThrow(CredentialCipherError);
    expect(() =>
      cipher().decrypt(owner, {
        ...encrypted,
        credentialCiphertext: new Uint8Array(tamperedCiphertext),
      }),
    ).toThrow(CredentialCipherError);
  });

  it('requires numeric key versions and 32-byte keys', () => {
    expect(
      () =>
        new CredentialCipher({
          currentKeyVersion: 'primary',
          keys: new Map([['primary', Buffer.alloc(32, 7)]]),
        }),
    ).toThrow(CredentialCipherError);
    expect(
      () =>
        new CredentialCipher({
          currentKeyVersion: 'v1',
          keys: new Map([['v1', Buffer.alloc(31, 7)]]),
        }),
    ).toThrow(CredentialCipherError);
  });
});
