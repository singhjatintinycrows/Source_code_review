import {
  type CipherGCM,
  createCipheriv,
  createDecipheriv,
  type DecipherGCM,
  randomBytes,
} from 'node:crypto';

const ALGORITHM = 'aes-256-gcm';
export const CREDENTIAL_KEY_BYTES = 32;
const NONCE_BYTES = 12;
export const CREDENTIAL_KEY_VERSION_PATTERN = /^v([1-9]\d*)$/;

export type CredentialOwner = {
  serviceId: string;
  connectionId: string;
  provider: string;
  credentialFormat: string;
};

export type EncryptedCredential = {
  credentialCiphertext: Uint8Array<ArrayBuffer>;
  credentialNonce: Uint8Array<ArrayBuffer>;
  credentialAuthTag: Uint8Array<ArrayBuffer>;
  credentialKeyVersion: string;
  credentialFormat: string;
};

export class CredentialCipherError extends Error {
  readonly code: 'INVALID_CONFIGURATION' | 'INVALID_CREDENTIAL';

  constructor(
    code: 'INVALID_CONFIGURATION' | 'INVALID_CREDENTIAL',
    message: string,
    options?: ErrorOptions,
  ) {
    super(message, options);
    this.code = code;
    this.name = 'CredentialCipherError';
  }
}

export function credentialKeyVersionNumber(version: string): number {
  const match = CREDENTIAL_KEY_VERSION_PATTERN.exec(version);
  if (!match) {
    throw new CredentialCipherError(
      'INVALID_CONFIGURATION',
      'Credential encryption key version must use the v<number> format.',
    );
  }
  const value = Number(match[1]);
  if (!Number.isSafeInteger(value)) {
    throw new CredentialCipherError(
      'INVALID_CONFIGURATION',
      'Credential encryption key version is too large.',
    );
  }
  return value;
}

export type CredentialCipherOptions = {
  currentKeyVersion: string;
  keys: ReadonlyMap<string, Buffer>;
};

function storedBytes(bytes: Uint8Array): Uint8Array<ArrayBuffer> {
  return new Uint8Array(bytes);
}

function credentialText(value: string): string {
  const normalized = value.trim();
  if (!normalized || /\p{Cc}/u.test(normalized)) {
    throw new CredentialCipherError(
      'INVALID_CREDENTIAL',
      'The provider credential is invalid.',
    );
  }
  return normalized;
}

function ownerPart(value: string, name: string): string {
  const normalized = value.trim();
  if (!normalized || /[\p{Cc}:]/u.test(normalized)) {
    throw new CredentialCipherError(
      'INVALID_CONFIGURATION',
      `Credential ${name} is invalid.`,
    );
  }
  return normalized;
}

function additionalAuthenticatedData(owner: CredentialOwner): Buffer {
  return Buffer.from(
    [
      'hyperprobe:observability:v1',
      ownerPart(owner.serviceId, 'service owner'),
      ownerPart(owner.connectionId, 'connection owner'),
      ownerPart(owner.provider, 'provider'),
      ownerPart(owner.credentialFormat, 'format'),
    ].join(':'),
    'utf8',
  );
}

function keyFor(keys: ReadonlyMap<string, Buffer>, version: string): Buffer {
  const key = keys.get(version);
  if (!key) {
    throw new CredentialCipherError(
      'INVALID_CONFIGURATION',
      `No credential encryption key is configured for version ${version}.`,
    );
  }
  return key;
}

export class CredentialCipher {
  private readonly currentKeyVersion: string;
  private readonly keys: ReadonlyMap<string, Buffer>;

  constructor(options: CredentialCipherOptions) {
    credentialKeyVersionNumber(options.currentKeyVersion);
    for (const [version, key] of options.keys) {
      credentialKeyVersionNumber(version);
      if (key.length !== CREDENTIAL_KEY_BYTES) {
        throw new CredentialCipherError(
          'INVALID_CONFIGURATION',
          `Credential encryption key ${version} must contain ${CREDENTIAL_KEY_BYTES} bytes.`,
        );
      }
    }
    keyFor(options.keys, options.currentKeyVersion);
    this.currentKeyVersion = options.currentKeyVersion;
    this.keys = options.keys;
  }

  needsRotation(credential: { credentialKeyVersion: string }): boolean {
    return credential.credentialKeyVersion !== this.currentKeyVersion;
  }

  encrypt(owner: CredentialOwner, value: string): EncryptedCredential {
    const nonce = randomBytes(NONCE_BYTES);
    const cipher = createCipheriv(
      ALGORITHM,
      keyFor(this.keys, this.currentKeyVersion),
      nonce,
    ) as CipherGCM;
    cipher.setAAD(additionalAuthenticatedData(owner));
    const ciphertext = Buffer.concat([
      cipher.update(credentialText(value), 'utf8'),
      cipher.final(),
    ]);
    return {
      credentialCiphertext: storedBytes(ciphertext),
      credentialNonce: storedBytes(nonce),
      credentialAuthTag: storedBytes(cipher.getAuthTag()),
      credentialKeyVersion: this.currentKeyVersion,
      credentialFormat: owner.credentialFormat,
    };
  }

  decrypt(
    owner: CredentialOwner,
    credential: {
      credentialCiphertext: Uint8Array;
      credentialNonce: Uint8Array;
      credentialAuthTag: Uint8Array;
      credentialKeyVersion: string;
      credentialFormat: string;
    },
  ): string {
    try {
      if (credential.credentialFormat !== owner.credentialFormat) {
        throw new Error('Stored credential format does not match the owner.');
      }
      if (
        credential.credentialNonce.length !== NONCE_BYTES ||
        credential.credentialAuthTag.length !== 16 ||
        credential.credentialCiphertext.length === 0
      ) {
        throw new Error('Stored credential fields are invalid.');
      }
      const decipher = createDecipheriv(
        ALGORITHM,
        keyFor(this.keys, credential.credentialKeyVersion),
        credential.credentialNonce,
      ) as DecipherGCM;
      decipher.setAAD(additionalAuthenticatedData(owner));
      decipher.setAuthTag(credential.credentialAuthTag);
      return credentialText(
        Buffer.concat([
          decipher.update(credential.credentialCiphertext),
          decipher.final(),
        ]).toString('utf8'),
      );
    } catch (error) {
      if (error instanceof CredentialCipherError) throw error;
      throw new CredentialCipherError(
        'INVALID_CREDENTIAL',
        'The stored provider credential could not be decrypted.',
        { cause: error },
      );
    }
  }

  reencrypt(
    owner: CredentialOwner,
    credential: {
      credentialCiphertext: Uint8Array;
      credentialNonce: Uint8Array;
      credentialAuthTag: Uint8Array;
      credentialKeyVersion: string;
      credentialFormat: string;
    },
  ): EncryptedCredential {
    return this.encrypt(owner, this.decrypt(owner, credential));
  }
}
