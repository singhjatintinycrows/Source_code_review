import { describe, expect, it } from 'vitest';
import type { ProviderAdapter } from './contracts.js';
import { ObservabilityProviderRegistry } from './registry.js';

const adapter: ProviderAdapter = {
  provider: 'TEST',
  displayName: 'Test provider',
  credentialFormat: 'TEST_TOKEN',
  credentialGuidance: 'Use a test token with read access.',
  supportedSignals: ['ERRORS'],
  validateConnectionConfig: () => ({}),
  validatePublicConfig: () => ({}),
  async resolveConnectionConfig(config) {
    return config;
  },
  async queryTable() {
    return { rows: [], page: { hasMore: false } };
  },
  async queryMetrics() {
    return { timeSeries: [], meta: {} };
  },
  async queryAlerts() {
    return { rows: [], page: { hasMore: false } };
  },
  async discoverContext() {
    return {
      alerts: { availability: 'AVAILABLE', values: [] },
      environments: { availability: 'AVAILABLE', values: [] },
      releases: { availability: 'AVAILABLE', values: [] },
      tags: { availability: 'AVAILABLE', values: [] },
    };
  },
};

describe('ObservabilityProviderRegistry metadata', () => {
  it('returns only metadata from registered providers', () => {
    const registry = new ObservabilityProviderRegistry([adapter]);

    expect(registry.metadata()).toEqual([
      {
        id: 'TEST',
        provider: 'TEST',
        displayName: 'Test provider',
        supportedSignals: ['ERRORS'],
        credentialFormat: 'TEST_TOKEN',
        credentialGuidance: 'Use a test token with read access.',
      },
    ]);
  });
});
