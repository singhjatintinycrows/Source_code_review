import {
  SentryExploreClient,
  type SentryMetric,
  type SentrySignal,
} from '../rca/sentryExploreClient.js';
import type {
  EvidenceScope,
  ObservabilitySignalName,
  ProviderAdapter,
  ProviderAlertQuery,
  ProviderDiscoveryResult,
  ProviderMetricQuery,
  ProviderTableQuery,
  StoredObservabilityConnection,
} from './contracts.js';
import { ProviderError, providerErrorFrom } from './errors.js';

const DEFAULT_SENTRY_API_BASE_URL = 'https://sentry.io/api/0/';

const SENTRY_TABLE_FIELDS: Record<
  Extract<ObservabilitySignalName, 'ERRORS' | 'LOGS' | 'TRACES'>,
  readonly string[]
> = {
  ERRORS: [
    'id',
    'timestamp',
    'message',
    'title',
    'level',
    'error.type',
    'error_type',
    'trace',
    'request_id',
    'request.id',
  ],
  LOGS: [
    'sentry.item_id',
    'timestamp',
    'message',
    'severity',
    'trace',
    'span_id',
    'request_id',
    'request.id',
    'error.type',
    'error_type',
  ],
  TRACES: [
    'id',
    'trace',
    'span.op',
    'span.description',
    'span.status',
    'span.duration',
    'timestamp',
    'transaction',
  ],
};

type SentryConnectionConfig = {
  apiBaseUrl: string;
  orgSlug: string;
  projectId?: string;
  projectSlug?: string;
};

type SentryPublicConfig = SentryConnectionConfig & {
  projectId: string;
  projectSlug: string;
};

function asRecord(value: unknown): Record<string, unknown> | null {
  return typeof value === 'object' && value !== null && !Array.isArray(value)
    ? (value as Record<string, unknown>)
    : null;
}

function identifier(
  value: unknown,
  name: string,
  pattern = /^[A-Za-z0-9][A-Za-z0-9_-]{0,127}$/,
): string {
  if (typeof value !== 'string' || !pattern.test(value)) {
    throw new ProviderError(
      'INVALID_CONFIGURATION',
      `The Sentry ${name} is invalid.`,
    );
  }
  return value;
}

function allowedBaseUrls(): string[] {
  return [
    DEFAULT_SENTRY_API_BASE_URL,
    ...(process.env.SENTRY_ALLOWED_BASE_URLS ?? '')
      .split(',')
      .map((value) => value.trim())
      .filter(Boolean),
  ];
}

function sentryConnectionConfig(value: unknown): SentryConnectionConfig {
  const config = asRecord(value);
  if (!config) {
    throw new ProviderError(
      'INVALID_CONFIGURATION',
      'The Sentry public connection configuration is invalid.',
    );
  }
  const apiBaseUrl =
    typeof config.apiBaseUrl === 'string' && config.apiBaseUrl.trim()
      ? config.apiBaseUrl.trim()
      : DEFAULT_SENTRY_API_BASE_URL;
  try {
    // Reuse the client validation so configured bases stay on the deployment allowlist.
    SentryExploreClient.fromConfig({
      authToken: 'configuration-validation',
      apiBaseUrl,
      allowedBaseUrls: allowedBaseUrls(),
    });
  } catch (error) {
    throw providerErrorFrom(error);
  }
  const projectId = config.projectId;
  const projectSlug = config.projectSlug;
  if (projectId === undefined && projectSlug === undefined) {
    throw new ProviderError(
      'INVALID_CONFIGURATION',
      'The Sentry project ID is required.',
    );
  }
  return {
    apiBaseUrl,
    orgSlug: identifier(config.orgSlug, 'organization slug'),
    ...(projectId === undefined
      ? {}
      : { projectId: identifier(projectId, 'project ID', /^\d{1,32}$/) }),
    ...(projectSlug === undefined
      ? {}
      : { projectSlug: identifier(projectSlug, 'project slug') }),
  };
}

function sentryConfig(value: unknown): SentryPublicConfig {
  const config = sentryConnectionConfig(value);
  const { projectId, projectSlug } = config;
  if (!projectId || !projectSlug) {
    throw new ProviderError(
      'INVALID_CONFIGURATION',
      'The Sentry project slug could not be resolved from the project ID.',
    );
  }
  return { ...config, projectId, projectSlug };
}

function scope(config: SentryPublicConfig, input: EvidenceScope) {
  return {
    organizationSlug: config.orgSlug,
    projectSlug: config.projectSlug,
    projectId: config.projectId,
    providerEnvironment: input.providerEnvironment,
    ...(input.release ? { release: input.release } : {}),
  };
}

function client(
  connection: StoredObservabilityConnection,
  credential: string,
): { client: SentryExploreClient; config: SentryPublicConfig } {
  const config = sentryConfig(connection.publicConfig);
  try {
    return {
      client: SentryExploreClient.fromConfig({
        authToken: credential,
        apiBaseUrl: config.apiBaseUrl,
        nodeEnvironment: process.env.NODE_ENV,
        allowedBaseUrls: allowedBaseUrls(),
      }),
      config,
    };
  } catch (error) {
    throw providerErrorFrom(error);
  }
}

async function sentryRequest<T>(request: () => Promise<T>): Promise<T> {
  try {
    return await request();
  } catch (error) {
    throw providerErrorFrom(error);
  }
}

export const sentryAdapter: ProviderAdapter = {
  provider: 'SENTRY',
  displayName: 'Sentry',
  credentialFormat: 'SENTRY_AUTH_TOKEN',
  credentialGuidance:
    'Use a Sentry auth token with org:read, project:read, and event:read scopes and access to the selected organization and project.',
  supportedSignals: ['ERRORS', 'LOGS', 'TRACES', 'METRICS', 'ALERTS'],

  validateConnectionConfig(config: unknown): Record<string, unknown> {
    return sentryConnectionConfig(config);
  },

  validatePublicConfig(config: unknown): Record<string, unknown> {
    return sentryConfig(config);
  },

  async resolveConnectionConfig(
    config: Record<string, unknown>,
    credential: string,
  ): Promise<Record<string, unknown>> {
    const configured = sentryConnectionConfig(config);
    try {
      const sentry = SentryExploreClient.fromConfig({
        authToken: credential,
        apiBaseUrl: configured.apiBaseUrl,
        nodeEnvironment: process.env.NODE_ENV,
        allowedBaseUrls: allowedBaseUrls(),
      });
      const project = configured.projectId
        ? await sentry.resolveProjectById(
            configured.orgSlug,
            configured.projectId,
          )
        : await sentry.resolveProjectBySlug(
            configured.orgSlug,
            configured.projectSlug!,
          );
      return {
        ...configured,
        projectId: project.id,
        projectSlug: project.slug,
      };
    } catch (error) {
      throw providerErrorFrom(error);
    }
  },

  async queryTable(
    connection: StoredObservabilityConnection,
    credential: string,
    query: ProviderTableQuery,
  ) {
    const configured = client(connection, credential);
    return sentryRequest(async () => {
      const result = await configured.client.queryTable({
        signal: query.signal as SentrySignal,
        fields: SENTRY_TABLE_FIELDS[query.signal],
        scope: scope(configured.config, query.scope),
        start: query.start,
        end: query.end,
        filter: query.filter,
        traceId: query.traceId,
        traceFormat: query.traceFormat,
        limit: query.limit,
        cursor: query.cursor,
      });
      return { rows: result.data, page: result.page };
    });
  },

  async queryMetrics(
    connection: StoredObservabilityConnection,
    credential: string,
    query: ProviderMetricQuery,
  ) {
    const configured = client(connection, credential);
    return sentryRequest(async () => {
      const result = await configured.client.queryMetricSeries({
        scope: scope(configured.config, query.scope),
        start: query.start,
        end: query.end,
        filter: query.filter,
        metric: query.metric as SentryMetric,
        intervalSeconds: query.intervalSeconds,
      });
      return result;
    });
  },

  async queryAlerts(
    connection: StoredObservabilityConnection,
    credential: string,
    query: ProviderAlertQuery,
  ) {
    const configured = client(connection, credential);
    return sentryRequest(async () => {
      const result = await configured.client.queryAlerts({
        scope: scope(configured.config, query.scope),
        start: query.start,
        end: query.end,
        filter: query.filter,
        limit: query.limit,
        cursor: query.cursor,
      });
      return { rows: result.data, page: result.page };
    });
  },

  async discoverContext(
    connection: StoredObservabilityConnection,
    credential: string,
  ): Promise<ProviderDiscoveryResult> {
    const configured = client(connection, credential);
    return sentryRequest(() =>
      configured.client.discoverContext({
        organizationSlug: configured.config.orgSlug,
        projectSlug: configured.config.projectSlug,
        projectId: configured.config.projectId,
      }),
    );
  },
};
