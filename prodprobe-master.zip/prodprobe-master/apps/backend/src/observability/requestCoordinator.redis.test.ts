import { randomUUID } from 'node:crypto';
import { createClient } from 'redis';
import { afterAll, beforeAll, describe, expect, it, vi } from 'vitest';
import { ObservabilityRequestCoordinator } from './requestCoordinator.js';

// Opt in with an isolated Redis instance to exercise the actual Lua scripts.
const redisUrl = process.env.OBSERVABILITY_TEST_REDIS_URL;

function deferred() {
  let resolve!: () => void;
  const promise = new Promise<void>((resolvePromise) => {
    resolve = resolvePromise;
  });
  return { promise, resolve };
}

describe.skipIf(!redisUrl)('Redis observability leases', () => {
  const client = createClient({
    url: redisUrl,
    socket: { connectTimeout: 1_000, reconnectStrategy: false },
  });
  client.on('error', console.error);

  beforeAll(async () => {
    await client.connect();
  });

  afterAll(async () => {
    if (client.isOpen) await client.close();
  });

  it('reclaims expired leases even while healthy traffic keeps the key alive', async () => {
    const connectionId = randomUUID();
    const leaseKey = `observability:concurrency:SENTRY:${connectionId}:leases`;
    const coordinator = new ObservabilityRequestCoordinator(client);
    const otherNode = new ObservabilityRequestCoordinator(client);
    const started = deferred();
    const blocker = deferred();
    let pending: Promise<void> | undefined;
    try {
      await client.zAdd(leaseKey, [
        { score: 0, value: 'abandoned' },
        { score: Date.now() + 60_000, value: 'healthy' },
      ]);
      await client.pExpire(leaseKey, 60_000);

      pending = coordinator.run('SENTRY', connectionId, async () => {
        started.resolve();
        await blocker.promise;
      });
      await Promise.race([started.promise, pending]);

      expect(await client.zScore(leaseKey, 'abandoned')).toBeNull();
      expect(await client.zScore(leaseKey, 'healthy')).not.toBeNull();
      expect(await client.zCard(leaseKey)).toBe(2);
      await expect(
        otherNode.run('SENTRY', connectionId, async () => undefined),
      ).rejects.toMatchObject({ code: 'OVERLOADED' });

      blocker.resolve();
      await pending;
      expect(await client.zRange(leaseKey, 0, -1)).toEqual(['healthy']);
      await expect(
        otherNode.run('SENTRY', connectionId, async () => 'evidence'),
      ).resolves.toBe('evidence');
      expect(await client.zRange(leaseKey, 0, -1)).toEqual(['healthy']);
    } finally {
      blocker.resolve();
      await Promise.allSettled([pending]);
      await client.del(leaseKey);
    }
  });

  it('does not release a replacement lease when an expired request finishes', async () => {
    const connectionId = randomUUID();
    const leaseKey = `observability:concurrency:SENTRY:${connectionId}:leases`;
    const firstNode = new ObservabilityRequestCoordinator(client, 1);
    const secondNode = new ObservabilityRequestCoordinator(client, 1);
    const firstStarted = deferred();
    const firstBlocker = deferred();
    const secondStarted = deferred();
    const secondBlocker = deferred();
    const first = firstNode.run('SENTRY', connectionId, async () => {
      firstStarted.resolve();
      await firstBlocker.promise;
    });
    let second: Promise<void> | undefined;
    try {
      await Promise.race([firstStarted.promise, first]);
      const [expiredLease] = await client.zRange(leaseKey, 0, -1);
      expect(expiredLease).toBeDefined();
      await client.zAdd(leaseKey, { score: 0, value: expiredLease });

      second = secondNode.run('SENTRY', connectionId, async () => {
        secondStarted.resolve();
        await secondBlocker.promise;
      });
      await Promise.race([secondStarted.promise, second]);

      firstBlocker.resolve();
      await first;
      expect(await client.zCard(leaseKey)).toBe(1);
      expect(await client.zScore(leaseKey, expiredLease)).toBeNull();
      await expect(
        firstNode.run('SENTRY', connectionId, async () => undefined),
      ).rejects.toMatchObject({ code: 'OVERLOADED' });

      secondBlocker.resolve();
      await second;
      expect(await client.exists(leaseKey)).toBe(0);
    } finally {
      firstBlocker.resolve();
      secondBlocker.resolve();
      await Promise.allSettled([first, second]);
      await client.del(leaseKey);
    }
  });

  it.each([
    'acquire',
    'release',
  ])('bounds an in-flight delayed %s without changing the Redis connection', async (phase) => {
    const connectionId = randomUUID();
    const leaseKey = `observability:concurrency:SENTRY:${connectionId}:leases`;
    const blockKey = `observability:test-block:${connectionId}`;
    const delayed = client.duplicate();
    delayed.on('error', () => {});
    const options = delayed.options;
    const commands: { kind: string; signal: AbortSignal; reply?: unknown }[] =
      [];
    const withAbortSignal = delayed.withAbortSignal.bind(delayed);
    vi.spyOn(delayed, 'withAbortSignal').mockImplementation((signal) => {
      const proxy = withAbortSignal(signal);
      const evaluate = proxy.eval.bind(proxy);
      vi.spyOn(proxy, 'eval').mockImplementation((script, config) => {
        const command = {
          kind: String(script).includes('ZADD') ? 'acquire' : 'release',
          signal,
          reply: undefined as unknown,
        };
        commands.push(command);
        const pending = evaluate(script, config);
        void pending.then(
          (reply) => {
            command.reply = reply;
          },
          () => {},
        );
        return pending;
      });
      return proxy;
    });
    const coordinator = new ObservabilityRequestCoordinator(delayed, 1, 1, 50);
    let blocking: Promise<unknown> | undefined;
    const block = () => {
      // BLPOP stalls only this test's connection, never the Redis server or other clients.
      blocking = delayed.blPop(blockKey, 0);
      void blocking.catch(() => {});
    };
    const evidence = { evidence: 'original provider result' };
    const request = vi.fn(async () => {
      if (phase === 'release') block();
      return evidence;
    });
    const nextRequest = vi.fn(async () => 'reused slot');
    let first: Promise<typeof evidence> | undefined;
    let second: Promise<string> | undefined;
    try {
      await delayed.connect();
      if (phase === 'acquire') block();
      first = coordinator.run('SENTRY', connectionId, request);
      await expect(first).resolves.toBe(evidence);
      expect(delayed.isReady).toBe(true);
      expect(request).toHaveBeenCalledTimes(1);
      expect(await client.zCard(leaseKey)).toBe(phase === 'release' ? 1 : 0);

      // Slot reuse must not wait for either the blocked release or detached cleanup.
      second = coordinator.run('SENTRY', connectionId, nextRequest);
      await expect(second).resolves.toBe('reused slot');
      expect(nextRequest).toHaveBeenCalledTimes(1);
      expect(commands.filter(({ kind }) => kind === 'release')).toHaveLength(2);
      for (const command of commands.filter(({ kind }) => kind === phase)) {
        expect(command.signal.aborted).toBe(true);
        expect(command.reply).toBeUndefined();
      }

      await client.lPush(blockKey, 'resume');
      await blocking;
      await expect
        .poll(() =>
          commands
            .filter(({ kind }) => kind === 'acquire')
            .map(({ reply }) => reply),
        )
        .toEqual([1, 1]);
      await expect
        .poll(
          () =>
            commands.filter(
              ({ kind, reply }) => kind === 'release' && reply !== undefined,
            ).length,
        )
        .toBe(phase === 'acquire' ? 4 : 3);
      expect(await client.exists(leaseKey)).toBe(0);
      const signals = vi
        .mocked(delayed.withAbortSignal)
        .mock.calls.map(([signal]) => signal);
      expect(new Set(signals).size).toBe(signals.length);
      expect(delayed.options).toBe(options);
      expect(delayed.options.commandOptions).toBeUndefined();
      expect(delayed.isReady).toBe(true);

      await expect(
        coordinator.run('SENTRY', connectionId, async () => 'healthy again'),
      ).resolves.toBe('healthy again');
      expect(await client.exists(leaseKey)).toBe(0);
      expect(request).toHaveBeenCalledTimes(1);
      expect(nextRequest).toHaveBeenCalledTimes(1);
    } finally {
      if (delayed.isOpen) delayed.destroy();
      await Promise.allSettled([blocking, first, second]);
      await client.del([leaseKey, blockKey]);
    }
  });
});
