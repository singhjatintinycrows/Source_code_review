import { createHash } from 'node:crypto';
import type {
  ObservabilitySignalName,
  StoredObservabilityConnection,
} from './contracts.js';
import { safeFailureMessage } from './redaction.js';

type AuditModel = {
  create(args: { data: Record<string, unknown> }): Promise<{ id: string }>;
  update(args: {
    where: { id: string };
    data: Record<string, unknown>;
  }): Promise<unknown>;
};

export type AuditStore = {
  observabilityEvidenceAuditEvent: AuditModel;
};

export type EvidenceAuditStart = {
  serviceId: string;
  actorId: string;
  connection: StoredObservabilityConnection;
  signal: ObservabilitySignalName;
  purpose: string;
  query: unknown;
  start: string;
  end: string;
};

export type EvidenceAuditEvent = {
  id: string;
};

export class EvidenceAuditError extends Error {
  constructor(message: string, options?: ErrorOptions) {
    super(message, options);
    this.name = 'EvidenceAuditError';
  }
}

export function asAuditStore(prisma: unknown): AuditStore {
  return prisma as AuditStore;
}

export function queryFingerprint(query: unknown): string {
  return createHash('sha256').update(JSON.stringify(query)).digest('hex');
}

export async function startEvidenceAudit(
  store: AuditStore,
  input: EvidenceAuditStart,
): Promise<EvidenceAuditEvent> {
  return store.observabilityEvidenceAuditEvent.create({
    data: {
      serviceId: input.serviceId,
      actorId: input.actorId,
      connectionId: input.connection.id,
      connectionName: input.connection.name,
      provider: input.connection.provider,
      signal: input.signal,
      purpose: input.purpose,
      queryFingerprint: queryFingerprint(input.query),
      timeRangeStart: new Date(input.start),
      timeRangeEnd: new Date(input.end),
      resultCount: 0,
      redactionCount: 0,
      // The audit schema represents an in-flight STARTED event by a null
      // completedAt. Its persisted enum calls a completed success SUCCESS.
      outcome: 'SUCCESS',
      sourceFailures: 0,
      startedAt: new Date(),
      completedAt: null,
    },
  });
}

export async function completeEvidenceAudit(
  store: AuditStore,
  event: EvidenceAuditEvent,
  input: {
    outcome: 'COMPLETE' | 'PARTIAL' | 'FAILED';
    resultCount: number;
    redactionCount: number;
    sourceFailureCount?: number;
  },
): Promise<void> {
  await store.observabilityEvidenceAuditEvent.update({
    where: { id: event.id },
    data: {
      outcome:
        input.outcome === 'COMPLETE'
          ? 'SUCCESS'
          : input.outcome === 'FAILED'
            ? 'FAILURE'
            : 'PARTIAL',
      resultCount: Math.max(0, Math.floor(input.resultCount)),
      redactionCount: Math.max(0, Math.floor(input.redactionCount)),
      sourceFailures: Math.max(0, Math.floor(input.sourceFailureCount ?? 0)),
      completedAt: new Date(),
    },
  });
}

export async function failEvidenceAudit(
  store: AuditStore,
  event: EvidenceAuditEvent,
  error: unknown,
): Promise<void> {
  await completeEvidenceAudit(store, event, {
    outcome: 'FAILED',
    resultCount: 0,
    redactionCount: 0,
    sourceFailureCount: safeFailureMessage(error) ? 1 : 0,
  });
}
