import { describe, expect, it } from 'vitest';
import { ROLE_TYPES } from './helpers/appConstants.js';
import { type Context, hasServiceMembership } from './trpc.js';

function userWithRole(role: number): NonNullable<Context['user']> {
  return {
    userId: 'user-a',
    email: 'user@example.test',
    permissions: {
      isAdmin: false,
      permissions: { 'service-a': role },
    },
  };
}

describe('hasServiceMembership', () => {
  it('allows every defined service role for its service', () => {
    expect(
      hasServiceMembership(userWithRole(ROLE_TYPES.Viewer), 'service-a'),
    ).toBe(true);
    expect(
      hasServiceMembership(userWithRole(ROLE_TYPES.Editor), 'service-a'),
    ).toBe(true);
    expect(
      hasServiceMembership(userWithRole(ROLE_TYPES.Manager), 'service-a'),
    ).toBe(true);
  });

  it('allows admins but rejects users without service membership', () => {
    expect(
      hasServiceMembership(userWithRole(ROLE_TYPES.Viewer), 'service-b'),
    ).toBe(false);
    expect(
      hasServiceMembership(
        {
          ...userWithRole(ROLE_TYPES.Viewer),
          permissions: { isAdmin: true, permissions: {} },
        },
        'service-b',
      ),
    ).toBe(true);
    expect(hasServiceMembership(undefined, 'service-a')).toBe(false);
  });
});
