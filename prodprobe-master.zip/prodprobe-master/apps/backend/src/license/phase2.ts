import {
  type getConsul,
  HP_DEPLOYMENT_KEYS as K,
  type LicenseManager,
  type LicenseRecoveryContext,
  readLicenseSnapshot as readLicenseState,
  HP_LICENSE_SYNC_STATUS as Status,
} from '@hyperprobe/common';
import { TRPCError } from '@trpc/server';
import jwt from 'jsonwebtoken';

type Consul = ReturnType<typeof getConsul>;
type Operation = {
  KV: {
    Verb: 'get-or-empty' | 'check-index' | 'check-not-exists' | 'cas';
    Key: string;
    Index?: number;
    Value?: string;
    Flags?: number;
  };
};
type TransactionResult = {
  Results?: {
    KV: {
      Key: string;
      ModifyIndex: number;
      Value: string | null;
      Flags?: number;
    };
  }[];
  Errors?: { OpIndex: number; What: string }[] | null;
};

const keys = {
  jwt: K.HP_LICENSE_JWT,
  nextToken: K.NEXT_TOKEN,
  publicKey: 'LICENSE_PUBLIC_KEY',
  hintStatus: K.HP_LICENSE_SYNC_STATUS,
  licenseId: K.HP_LICENSE_ID,
};

function transactions(consul: Consul) {
  // consul@2 declares a different API from the uppercase wire format its runtime forwards.
  return consul.transaction as unknown as {
    create(
      operations: Operation[],
      options?: { consistent: boolean },
    ): Promise<TransactionResult>;
  };
}

function conflict() {
  return new TRPCError({
    code: 'CONFLICT',
    message:
      'License state changed; reload the deployment configuration before retrying',
  });
}

function checkIndex(Key: string, Index: number): Operation {
  return {
    KV:
      Index === 0
        ? { Verb: 'check-not-exists', Key }
        : { Verb: 'check-index', Key, Index },
  };
}

export { readLicenseState };

// Best-effort source inspection only; accepting a license still requires verification.
export function decodeLicenseSource(
  token: string | null,
): jwt.JwtPayload | null {
  try {
    const payload = token ? jwt.decode(token) : null;
    return payload && typeof payload === 'object' ? payload : null;
  } catch (_) {
    return null;
  }
}

type LicenseState = Awaited<ReturnType<typeof readLicenseState>>;

export async function writeAndConfirm(
  consul: Consul,
  manager: LicenseManager,
  operations: Operation[],
  matches: (state: LicenseState) => boolean,
  options: {
    acknowledgeConflict?: boolean;
    recoveryContext?: LicenseRecoveryContext;
  } = {},
) {
  const { acknowledgeConflict = true, recoveryContext } = options;
  if (recoveryContext && !manager.isRecoveryCurrent(recoveryContext)) {
    throw conflict();
  }
  let failure: unknown;
  if (operations.length) {
    manager.invalidatePublications();
    try {
      const result = await transactions(consul).create(operations);
      if (result.Errors?.length) throw conflict();
    } catch (error) {
      failure = error;
    } finally {
      manager.invalidatePublications();
    }
  }
  const knownConflict =
    (failure instanceof TRPCError && failure.code === 'CONFLICT') ||
    (typeof failure === 'object' &&
      failure !== null &&
      'statusCode' in failure &&
      failure.statusCode === 409);
  // A lost acknowledgement is not a rollback. Confirm the durable pair before continuing.
  for (;;) {
    let state: LicenseState;
    try {
      state = await readLicenseState(consul, manager, { hydrate: false });
    } catch (error) {
      // A failed confirmation cannot make a known rejection an ambiguous write.
      if (knownConflict) throw conflict();
      throw error;
    }
    const matched = (!knownConflict || acknowledgeConflict) && matches(state);
    const authorized =
      !recoveryContext || manager.isRecoveryCurrent(recoveryContext);
    if (
      !manager.publishSnapshot(
        state,
        state.publication!,
        matched && authorized ? recoveryContext : undefined,
      )
    ) {
      continue;
    }
    if (matched && authorized) {
      return { ...state, recoveryContext: manager.captureRecoveryContext() };
    }
    if (!authorized) throw conflict();
    // A confirmation can prove a conflict even if the rejection response was lost.
    if (
      failure &&
      !knownConflict &&
      operations.every(({ KV }) => state.indices[KV.Key] === (KV.Index ?? 0))
    ) {
      throw failure;
    }
    throw conflict();
  }
}

export async function prepareRelayToken(
  consul: Consul,
  manager: LicenseManager,
  input: {
    jwt: string;
    previousNextToken: string;
    nextToken: string;
    syncStatusIndex?: number;
  },
) {
  if (
    typeof input.nextToken !== 'string' ||
    !input.nextToken.trim() ||
    !input.previousNextToken
  ) {
    throw new TRPCError({
      code: 'BAD_REQUEST',
      message: 'An established token and a nonempty candidate are required',
    });
  }
  const state = await readLicenseState(consul, manager);
  if (
    input.syncStatusIndex === undefined
      ? state.recoveryContext!.revoked
      : state.indices[K.HP_LICENSE_SYNC_STATUS] !== input.syncStatusIndex
  ) {
    throw conflict();
  }
  const prepared = (current: LicenseState) =>
    current.jwt === input.jwt &&
    current.nextToken === input.nextToken &&
    current.indices[K.HP_LICENSE_JWT] === state.indices[K.HP_LICENSE_JWT] &&
    current.indices[K.HP_LICENSE_SYNC_STATUS] ===
      state.indices[K.HP_LICENSE_SYNC_STATUS];
  if (prepared(state)) return state;
  if (state.jwt !== input.jwt || state.nextToken !== input.previousNextToken) {
    throw conflict();
  }
  return writeAndConfirm(
    consul,
    manager,
    [
      checkIndex(K.HP_LICENSE_JWT, state.indices[K.HP_LICENSE_JWT]),
      checkIndex(
        K.HP_LICENSE_SYNC_STATUS,
        state.indices[K.HP_LICENSE_SYNC_STATUS],
      ),
      {
        KV: {
          Verb: 'cas',
          Key: K.NEXT_TOKEN,
          Index: state.indices[K.NEXT_TOKEN],
          Value: Buffer.from(input.nextToken).toString('base64'),
        },
      },
    ],
    prepared,
  );
}

export async function updateLicenseHint(
  consul: Consul,
  manager: LicenseManager,
  previous: LicenseState,
  hintStatus: Status.COURIER_REQUIRED | Status.REVOKED,
) {
  const state = await readLicenseState(consul, manager);
  if (
    Object.values(keys).some(
      (key) => state.indices[key] !== previous.indices[key],
    )
  ) {
    throw conflict();
  }
  // A transport failure permits a courier, but is not evidence against revocation.
  if (
    hintStatus === Status.COURIER_REQUIRED &&
    state.hintStatus === Status.REVOKED
  ) {
    return state;
  }
  // Consul no-ops equal value/flags. Reserve bit 0 for revocation events without 32-bit truncation.
  const flags =
    hintStatus === Status.REVOKED
      ? state.hintFlags + (state.hintFlags % 2 === 0 ? 1 : -1)
      : state.hintFlags;
  return writeAndConfirm(
    consul,
    manager,
    Object.values(keys).map(
      (Key): Operation =>
        Key === K.HP_LICENSE_SYNC_STATUS
          ? {
              KV: {
                Verb: 'cas',
                Key,
                Index: state.indices[Key],
                Value: Buffer.from(hintStatus).toString('base64'),
                Flags: flags,
              },
            }
          : checkIndex(Key, state.indices[Key]),
    ),
    (current) =>
      current.hintStatus === hintStatus &&
      current.hintFlags === flags &&
      Object.values(keys).every(
        (key) =>
          key === K.HP_LICENSE_SYNC_STATUS ||
          current.indices[key] === state.indices[key],
      ),
    // A rejected revocation CAS must not acknowledge somebody else's event as its own.
    { acknowledgeConflict: hintStatus !== Status.REVOKED },
  );
}

export async function recordRevocation(
  consul: Consul,
  manager: LicenseManager,
  previous?: LicenseState,
) {
  const revocation = manager.beginRevocation(
    previous?.recoveryContext ?? manager.captureRecoveryContext(),
  );
  if (!revocation) {
    try {
      await readLicenseState(consul, manager);
    } catch (_) {}
    throw conflict();
  }
  if (previous) manager.bindRevocation(revocation, previous.jwt);
  try {
    previous ??= await readLicenseState(consul, manager);
    if (!manager.bindRevocation(revocation, previous.jwt)) throw conflict();
    return await updateLicenseHint(consul, manager, previous, Status.REVOKED);
  } catch (error) {
    // A known conflict must not poison a winner's RAM if confirmation is unavailable.
    if (!(error instanceof TRPCError && error.code === 'CONFLICT')) {
      try {
        const current = await readLicenseState(consul, manager);
        if (!previous) manager.bindRevocation(revocation, current.jwt);
        if (
          !previous ||
          Object.entries(previous.indices).every(
            ([key, index]) => current.indices[key] === index,
          )
        ) {
          manager.recordLocalRevocation(revocation);
        }
      } catch (_) {
        manager.recordLocalRevocation(revocation);
      }
    }
    throw error;
  } finally {
    manager.endRevocation(revocation);
  }
}

export async function replaceLicenseState(
  consul: Consul,
  manager: LicenseManager,
  previous: LicenseState,
  input: {
    jwt: string;
    licenseId: string;
    publicKey: string;
    nextToken?: string;
  },
  recoveryContext: LicenseRecoveryContext,
) {
  const nextToken = input.nextToken?.trim() ? input.nextToken : null;
  const hintStatus = input.nextToken ? Status.SYNCED : Status.COURIER_REQUIRED;
  const values = {
    [K.HP_LICENSE_JWT]: input.jwt,
    [K.NEXT_TOKEN]: input.nextToken ?? '',
    [K.HP_LICENSE_SYNC_STATUS]: hintStatus,
    [K.HP_LICENSE_ID]: input.licenseId,
    LICENSE_PUBLIC_KEY: input.publicKey,
  };
  return writeAndConfirm(
    consul,
    manager,
    Object.entries(values).map(
      ([Key, value]): Operation => ({
        KV: {
          Verb: 'cas',
          Key,
          Index: previous.indices[Key],
          Value: Buffer.from(value).toString('base64'),
          ...(Key === K.HP_LICENSE_SYNC_STATUS
            ? { Flags: previous.hintFlags }
            : {}),
        },
      }),
    ),
    (current) =>
      current.jwt === input.jwt &&
      current.nextToken === nextToken &&
      current.licenseId === input.licenseId &&
      current.hintStatus === hintStatus &&
      current.hintFlags === previous.hintFlags &&
      current.publicKey === input.publicKey,
    { recoveryContext },
  );
}

export function validateLicenseRecovery(
  sourceJwt: string | null,
  targetJwt: string,
  target: jwt.JwtPayload,
  context: LicenseRecoveryContext,
  allowReplacement = false,
) {
  if (!context.revoked) return;
  if (
    target.exp !== undefined &&
    (!Number.isFinite(target.exp) || Date.now() >= target.exp * 1000)
  ) {
    throw new TRPCError({
      code: 'BAD_REQUEST',
      message: 'Expired license token',
    });
  }
  const source = decodeLicenseSource(sourceJwt);
  if (
    allowReplacement &&
    typeof target.licenseId === 'string' &&
    target.licenseId.trim() &&
    (!source || source.licenseId !== target.licenseId)
  ) {
    return;
  }
  if (
    typeof target.last_heartbeat_timestamp !== 'number' ||
    !Number.isFinite(target.last_heartbeat_timestamp) ||
    target.last_heartbeat_timestamp < 0 ||
    Date.now() - target.last_heartbeat_timestamp > 7 * 24 * 60 * 60 * 1000
  ) {
    throw new TRPCError({
      code: 'BAD_REQUEST',
      message: 'Invalid heartbeat timestamp, expiry, or grace period exceeded',
    });
  }
  if (
    !source ||
    typeof target.licenseId !== 'string' ||
    !target.licenseId.trim() ||
    source.licenseId !== target.licenseId ||
    targetJwt === sourceJwt ||
    typeof source.last_heartbeat_timestamp !== 'number' ||
    !Number.isFinite(source.last_heartbeat_timestamp) ||
    source.last_heartbeat_timestamp < 0 ||
    target.last_heartbeat_timestamp <= source.last_heartbeat_timestamp
  ) {
    throw conflict();
  }
}

export async function completeRelayToken(
  consul: Consul,
  manager: LicenseManager,
  input: {
    jwt: string;
    preparedFrom: string;
    nextToken: string;
    publicKey?: string;
    syncStatusIndex?: number;
  },
  recoveryContext?: LicenseRecoveryContext,
) {
  const state = await readLicenseState(consul, manager);
  recoveryContext ??= state.recoveryContext!;
  if (!manager.isRecoveryCurrent(recoveryContext)) throw conflict();
  let verified: jwt.JwtPayload | string;
  try {
    verified = jwt.verify(
      input.jwt,
      input.publicKey || state.verificationKey || '',
      { algorithms: ['ES256'] },
    );
  } catch (cause) {
    throw new TRPCError({
      code: 'BAD_REQUEST',
      message: 'Invalid, forged, or expired license token in relay',
      cause,
    });
  }
  const target = verified;
  const source = decodeLicenseSource(input.preparedFrom);
  if (
    !source ||
    typeof target === 'string' ||
    typeof target.licenseId !== 'string' ||
    !target.licenseId.trim() ||
    source.licenseId !== target.licenseId
  ) {
    throw conflict();
  }
  // RAM-only revocation needs the same signed, advancing refresh as durable R.
  // Compare against the captured installed JWT, never an older replay's marker.
  validateLicenseRecovery(state.jwt, input.jwt, target, recoveryContext);
  const completed = (current: LicenseState) =>
    current.jwt === input.jwt &&
    current.nextToken === input.nextToken &&
    current.indices[K.NEXT_TOKEN] === state.indices[K.NEXT_TOKEN] &&
    current.hintStatus === Status.SYNCED &&
    current.hintFlags === state.hintFlags &&
    current.licenseId === target.licenseId &&
    current.publicKey === (input.publicKey || state.publicKey) &&
    current.verificationKey === (input.publicKey || state.verificationKey);
  // Finalization can advance the hint index; only this exact SYNCED pair may acknowledge it.
  if (completed(state)) return state;
  if (
    state.jwt !== input.preparedFrom ||
    state.nextToken !== input.nextToken ||
    (input.syncStatusIndex === undefined
      ? recoveryContext.revoked
      : state.indices[K.HP_LICENSE_SYNC_STATUS] !== input.syncStatusIndex)
  ) {
    throw conflict();
  }
  // Apply the existing heartbeat grace check before committing, not after clearing the hint.
  if (
    typeof target.last_heartbeat_timestamp !== 'number' ||
    !Number.isFinite(target.last_heartbeat_timestamp) ||
    target.last_heartbeat_timestamp < 0 ||
    Date.now() - target.last_heartbeat_timestamp > 7 * 24 * 60 * 60 * 1000
  ) {
    throw new TRPCError({
      code: 'BAD_REQUEST',
      message: 'Invalid heartbeat timestamp or grace period exceeded',
    });
  }
  const values = {
    [K.HP_LICENSE_JWT]: input.jwt,
    [K.HP_LICENSE_SYNC_STATUS]: Status.SYNCED,
    [K.HP_LICENSE_ID]: target.licenseId,
    ...(input.publicKey ? { LICENSE_PUBLIC_KEY: input.publicKey } : {}),
  };
  return writeAndConfirm(
    consul,
    manager,
    [
      checkIndex(K.NEXT_TOKEN, state.indices[K.NEXT_TOKEN]),
      checkIndex('LICENSE_PUBLIC_KEY', state.indices.LICENSE_PUBLIC_KEY),
      ...Object.entries(values).map(
        ([Key, value]): Operation => ({
          KV: {
            Verb: 'cas',
            Key,
            Index: state.indices[Key],
            Value: Buffer.from(value).toString('base64'),
            ...(Key === K.HP_LICENSE_SYNC_STATUS
              ? { Flags: state.hintFlags }
              : {}),
          },
        }),
      ),
    ],
    completed,
    { recoveryContext },
  );
}
