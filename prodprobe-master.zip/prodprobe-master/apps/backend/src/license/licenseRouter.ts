import {
  getConsul,
  HP_DEPLOYMENT_KEYS,
  HP_LICENCE_MEMORY_REFRESH_KEY,
  HP_LICENSE_SYNC_STATUS,
  HP_LICENSE_UPGRADE_KEY,
  type HpLicenseJwtPayload,
  LicenseManager,
} from '@hyperprobe/common';
import { TRPCError } from '@trpc/server';
import jwt from 'jsonwebtoken';
import { z } from 'zod';
import { HP_LICENCE_HEARTBEAT_LOCK_KEY } from '../helpers/appConstants.js';
import { authProcedure, t, unlicensedAdminProcedure } from '../trpc.js';
import { performHeartbeat } from './heartbeat.js';
import {
  completeRelayToken,
  decodeLicenseSource,
  prepareRelayToken,
  readLicenseState,
  recordRevocation,
  replaceLicenseState,
  validateLicenseRecovery,
  writeAndConfirm,
} from './phase2.js';

function verifyLicenseJwtOffline(
  token: string,
  publicKey: string,
  ignoreExpiration = true,
): HpLicenseJwtPayload | null {
  try {
    const payload = jwt.verify(token, publicKey, {
      algorithms: ['ES256'],
      ignoreExpiration,
    }) as HpLicenseJwtPayload;
    return payload;
  } catch (_e) {
    return null;
  }
}

export const licenseRouter = t.router({
  status: authProcedure.query(async ({ ctx }) => {
    const manager = LicenseManager.getInstance();

    // Check upgrade banner flag in Redis
    const upgradeRequired = await ctx.redisClient.get(HP_LICENSE_UPGRADE_KEY);

    // In-memory strictly evaluated status
    const strictStatus = manager.getStatus();

    return {
      status: strictStatus,
      hintStatus: manager.getHintStatus(), // Instant from RAM
      maxAgents: manager.getMaxAgents(),
      softAgentLimit: manager.getSoftAgentLimit(),
      licenseId: manager.getLicenseId(),
      customerName: manager.getCustomerName(),
      expiryDate: manager.getExpiryDate(),
      isProvisioned: manager.getRawJwt() !== null,
      upgradeRequired: upgradeRequired === '1',
    };
  }),

  provision: unlicensedAdminProcedure
    .input(
      z.object({
        jwt: z.string(),
        nextToken: z.string().optional(),
        publicKey: z.string().optional(),
      }),
    )
    .mutation(async ({ ctx, input }) => {
      const manager = LicenseManager.getInstance();
      const consul = getConsul();
      const previous = await readLicenseState(consul, manager, {
        hydrate: false,
      });
      const inputJwt = input.jwt.trim();

      const formattedKey = input.publicKey
        ? input.publicKey.replace(/\\n/g, '\n').replace(/^['"]|['"]$/g, '')
        : undefined;
      const verificationKey = formattedKey || previous.verificationKey;
      if (!verificationKey) {
        throw new TRPCError({
          code: 'BAD_REQUEST',
          message: 'No public key available for verification',
        });
      }

      const decodedPayload = verifyLicenseJwtOffline(inputJwt, verificationKey);
      const isExpired =
        decodedPayload !== null &&
        decodedPayload.exp !== undefined &&
        (!Number.isFinite(decodedPayload.exp) ||
          decodedPayload.exp * 1000 <= Date.now());

      if (
        !decodedPayload ||
        isExpired ||
        typeof decodedPayload.licenseId !== 'string' ||
        !decodedPayload.licenseId.trim()
      ) {
        throw new TRPCError({
          code: 'BAD_REQUEST',
          message: 'Invalid or expired license token',
        });
      }

      const installed = decodeLicenseSource(previous.jwt);
      if (installed?.licenseId === decodedPayload.licenseId) {
        throw new TRPCError({
          code: 'CONFLICT',
          message:
            'This license is already installed. Use Sync License to refresh its entitlements.',
        });
      }

      await replaceLicenseState(
        consul,
        manager,
        previous,
        {
          jwt: inputJwt,
          licenseId: decodedPayload.licenseId,
          publicKey: verificationKey,
          nextToken: input.nextToken,
        },
        previous.recoveryContext!,
      );
      try {
        await ctx.redisClient.publish(HP_LICENCE_MEMORY_REFRESH_KEY, '1');
      } catch (error) {
        ctx.logger.warn(
          { error },
          'License persisted; refresh notification failed',
        );
      }

      return { success: true };
    }),

  getDeploymentConfig: authProcedure.query(async () => {
    const state = await readLicenseState(
      getConsul(),
      LicenseManager.getInstance(),
    );
    // Pair identity with this JWT, not a cached manager or separately indexed license ID.
    const payload = decodeLicenseSource(state.jwt);
    const licenseId =
      payload &&
      typeof payload.licenseId === 'string' &&
      payload.licenseId.trim()
        ? payload.licenseId
        : null;
    return {
      licenseId,
      jwt: state.jwt,
      nextToken: state.nextToken,
      syncStatusIndex: state.indices[HP_DEPLOYMENT_KEYS.HP_LICENSE_SYNC_STATUS],
    };
  }),

  prepareRelay: authProcedure
    .input(
      z.object({
        jwt: z.string().min(1),
        previousNextToken: z.string().min(1),
        nextToken: z.string().min(1),
        syncStatusIndex: z
          .number()
          .int()
          .min(0)
          .max(Number.MAX_SAFE_INTEGER)
          .optional(),
      }),
    )
    .mutation(async ({ input }) => {
      await prepareRelayToken(getConsul(), LicenseManager.getInstance(), input);
      return { success: true };
    }),

  // submitRelay is used by the "courier relay" flow to persist a JWT/nextToken fetched from the central licensing server.
  submitRelay: authProcedure
    .input(
      z
        .object({
          jwt: z.string(),
          nextToken: z.string(),
          publicKey: z.string().optional(),
          preparedFrom: z.string().optional(),
          initialFrom: z.string().optional(),
          syncStatusIndex: z
            .number()
            .int()
            .min(0)
            .max(Number.MAX_SAFE_INTEGER)
            .optional(),
        })
        .refine(
          (input) =>
            input.initialFrom === undefined ||
            (input.preparedFrom === undefined &&
              !!input.initialFrom.trim() &&
              !!input.jwt.trim() &&
              !!input.nextToken.trim()),
          {
            message:
              'Initial relay requires nonempty fields and cannot include preparedFrom',
          },
        ),
    )
    .mutation(async ({ ctx, input }) => {
      const manager = LicenseManager.getInstance();
      const consul = getConsul();
      const previous = await readLicenseState(consul, manager);
      const recoveryContext = previous.recoveryContext!;
      const previousPublicKey = previous.verificationKey;
      const previousJwt = previous.jwt;
      const previousNextToken = previous.nextToken;
      const previousHintStatus = previous.hintStatus;
      const previousPayload = decodeLicenseSource(previousJwt);
      const previousLicenseId = previousPayload?.licenseId ?? null;
      const inputJwt = input.jwt.trim();

      const formattedKey = input.publicKey
        ? input.publicKey.replace(/\\n/g, '\n').replace(/^['"]|['"]$/g, '')
        : undefined;

      // Step 1: Verification OUT-OF-BAND (no mutation of global singleton memory yet)
      const verificationKey =
        input.initialFrom !== undefined && input.publicKey !== undefined
          ? formattedKey
          : formattedKey || previousPublicKey;
      if (!verificationKey) {
        throw new TRPCError({
          code: 'BAD_REQUEST',
          message: 'No public key available for verification',
        });
      }

      const decodedPayload = verifyLicenseJwtOffline(
        inputJwt,
        verificationKey,
        input.initialFrom === undefined,
      );
      const isExpired =
        decodedPayload !== null &&
        decodedPayload.exp &&
        decodedPayload.exp * 1000 < Date.now();

      if (!decodedPayload || isExpired) {
        throw new TRPCError({
          code: 'BAD_REQUEST',
          message: 'Invalid, forged, or expired license token in relay',
        });
      }

      if (!manager.isRecoveryCurrent(recoveryContext)) {
        throw new TRPCError({
          code: 'CONFLICT',
          message: 'License state changed; reload before retrying',
        });
      }
      if (input.preparedFrom === undefined) {
        validateLicenseRecovery(
          previousJwt,
          inputJwt,
          decodedPayload,
          recoveryContext,
          input.initialFrom === undefined,
        );
      }

      if (input.initialFrom !== undefined) {
        const source = decodeLicenseSource(input.initialFrom);
        const completed =
          previous.jwt === inputJwt &&
          previous.nextToken === input.nextToken &&
          previous.hintStatus === HP_LICENSE_SYNC_STATUS.SYNCED &&
          previous.licenseId === decodedPayload.licenseId &&
          previous.publicKey === verificationKey;
        if (
          !source ||
          typeof decodedPayload.licenseId !== 'string' ||
          !decodedPayload.licenseId.trim() ||
          source.licenseId !== decodedPayload.licenseId ||
          previous.hintStatus === HP_LICENSE_SYNC_STATUS.REVOKED ||
          (!completed &&
            (previous.jwt !== input.initialFrom || previous.nextToken !== null))
        ) {
          throw new TRPCError({
            code: 'CONFLICT',
            message:
              'License state changed; reload the deployment configuration before retrying',
          });
        }
        // A duplicate may acknowledge this pair, but only an untouched source may write it.
        if (!completed) {
          await replaceLicenseState(
            consul,
            manager,
            previous,
            {
              jwt: inputJwt,
              licenseId: decodedPayload.licenseId,
              publicKey: verificationKey,
              nextToken: input.nextToken,
            },
            recoveryContext,
          );
        }
      } else if (input.preparedFrom !== undefined) {
        await completeRelayToken(
          consul,
          manager,
          {
            jwt: inputJwt,
            preparedFrom: input.preparedFrom,
            nextToken: input.nextToken,
            publicKey: formattedKey,
            syncStatusIndex: input.syncStatusIndex,
          },
          recoveryContext,
        );
      }
      if (input.initialFrom !== undefined || input.preparedFrom !== undefined) {
        try {
          await ctx.redisClient.publish(HP_LICENCE_MEMORY_REFRESH_KEY, '1');
        } catch (error) {
          ctx.logger.warn(
            { error },
            'License relay persisted; refresh notification failed',
          );
        }
        return { success: true };
      }

      // Preserve the unmarked relay's legacy writes/rollback, but never publish
      // their input as a verified RAM state before a coherent confirmation.
      manager.invalidatePublications();
      try {
        if (formattedKey) {
          await consul.kv.set('LICENSE_PUBLIC_KEY', formattedKey);
        }

        await consul.kv.set(HP_DEPLOYMENT_KEYS.HP_LICENSE_JWT, inputJwt);
        await consul.kv.set(HP_DEPLOYMENT_KEYS.NEXT_TOKEN, input.nextToken);
        if (!manager.isRecoveryCurrent(recoveryContext)) {
          throw new TRPCError({
            code: 'CONFLICT',
            message: 'License state changed; reload before retrying',
          });
        }
        await consul.kv.set(
          HP_DEPLOYMENT_KEYS.HP_LICENSE_SYNC_STATUS,
          HP_LICENSE_SYNC_STATUS.SYNCED,
        );

        if (decodedPayload.licenseId) {
          await consul.kv.set(
            HP_DEPLOYMENT_KEYS.HP_LICENSE_ID,
            decodedPayload.licenseId,
          );
        }
      } catch (consulError) {
        if (!manager.isRecoveryCurrent(recoveryContext)) throw consulError;
        // Consul Write Failed: Best-effort rollback of Consul keys to preserve state consistency
        try {
          if (input.publicKey) {
            await consul.kv.set('LICENSE_PUBLIC_KEY', previousPublicKey || '');
          }
          await consul.kv.set(
            HP_DEPLOYMENT_KEYS.HP_LICENSE_JWT,
            previousJwt || '',
          );
          await consul.kv.set(
            HP_DEPLOYMENT_KEYS.NEXT_TOKEN,
            previousNextToken || '',
          );
          await consul.kv.set(
            HP_DEPLOYMENT_KEYS.HP_LICENSE_SYNC_STATUS,
            previousHintStatus,
          );
          await consul.kv.set(
            HP_DEPLOYMENT_KEYS.HP_LICENSE_ID,
            previousLicenseId || '',
          );
        } catch (_rollbackErr) {
          // Fail silently on rollback failures to avoid masking original error
        }

        throw new TRPCError({
          code: 'INTERNAL_SERVER_ERROR',
          message: `Failed to persist license config in Consul: ${(consulError as Error).message}`,
        });
      } finally {
        manager.invalidatePublications();
      }

      const normalizedNextToken =
        input.nextToken.trim() !== '' ? input.nextToken : null;
      await writeAndConfirm(
        consul,
        manager,
        [],
        (current) =>
          current.jwt === inputJwt &&
          current.nextToken === normalizedNextToken &&
          current.hintStatus === HP_LICENSE_SYNC_STATUS.SYNCED &&
          current.publicKey === (formattedKey || previous.publicKey) &&
          current.verificationKey === verificationKey &&
          current.licenseId ===
            (decodedPayload.licenseId || previous.licenseId),
        { recoveryContext },
      );

      await ctx.redisClient.publish(HP_LICENCE_MEMORY_REFRESH_KEY, '1');

      return { success: true };
    }),

  sync: unlicensedAdminProcedure.mutation(async ({ ctx }) => {
    const result = await performHeartbeat(ctx.redisClient);
    const manager = LicenseManager.getInstance();

    if (!result || !result.success) {
      if (
        result?.requiresCourier ??
        manager.getHintStatus() === HP_LICENSE_SYNC_STATUS.COURIER_REQUIRED
      ) {
        return { success: false, requiresCourier: true };
      }
      throw new TRPCError({
        code: 'BAD_REQUEST',
        message:
          (result as { success: boolean; message: string })?.message ||
          'Failed to sync license',
      });
    }

    if ((result as { success: boolean; limitUpdated: boolean })?.limitUpdated) {
      await ctx.redisClient.del(HP_LICENSE_UPGRADE_KEY);
    }

    return { success: true, requiresCourier: false };
  }),

  acquireCourierLock: authProcedure.mutation(async ({ ctx }) => {
    const lock = await ctx.redisClient.set(HP_LICENCE_HEARTBEAT_LOCK_KEY, '1', {
      condition: 'NX',
      expiration: { type: 'EX', value: 300 },
    });
    return { success: !!lock };
  }),

  releaseCourierLock: authProcedure.mutation(async ({ ctx }) => {
    await ctx.redisClient.del(HP_LICENCE_HEARTBEAT_LOCK_KEY);
    return { success: true };
  }),

  reportRevocation: authProcedure.mutation(async ({ ctx }) => {
    const manager = LicenseManager.getInstance();
    const consul = getConsul();
    await recordRevocation(consul, manager);

    await ctx.redisClient.publish(HP_LICENCE_MEMORY_REFRESH_KEY, '1');
    return { success: true };
  }),
});
