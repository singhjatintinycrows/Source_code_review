# Phase 2 Recovery

An updated heartbeat or courier persists the Phase 1 candidate `T1` in
`DEPLOYMENT/NEXT_TOKEN` before sending Phase 2. Preparation keeps the installed
JWT, public key, and sync hint unchanged, and refreshes the serving process's
memory from Consul.

- Couriers use `licenseId`, `jwt`, `nextToken`, and `syncStatusIndex` from one
  `getDeploymentConfig` response. Its ID comes from the captured JWT, not an
  earlier status response or the separately indexed ID. An incomplete snapshot
  must not be sent to the licensing server. `syncStatusIndex` is the Consul
  revision of the hint captured before Phase 1; it is platform RPC metadata and
  must not be included in Lambda requests.
- `license.prepareRelay({ jwt: J0, previousNextToken: T0, nextToken: T1, syncStatusIndex: E0 })`
  checks the captured JWT, predecessor, and hint revision, then conditionally
  writes the token. An identical persisted candidate acknowledges a retried
  preparation only while its source and hint revision still match.
- Phase 2 must not be sent if preparation cannot be confirmed.
- Updated couriers finalize with
  `license.submitRelay({ jwt: J1, nextToken: T1, preparedFrom: J0, syncStatusIndex: E0, publicKey? })`.
  The prepared pair and pre-handshake hint revision must still match. Final
  JWT/key/hint writes are atomic, and no failure path restores `T0`.
- Heartbeats and `getDeploymentConfig` read a consistent persisted snapshot;
  recovery does not depend on a replica receiving Redis notifications.

After a dropped Phase 2 request, `T1` is still pending on the licensing server.
After a dropped committed response, `T1` is expected. The next attempt starts
at Phase 1 using the durable expected or pending `T1` in either case, rather
than replaying Phase 2.

The legacy licensing Lambda handler is retained. This release adds no Lambda
payload fields and requires no Lambda redeploy. Its known behaviors remain:

- A duplicate Phase 2 with the expected token and no pending token returns HTTP
  200 with a signed JWT, leaving the central record unchanged and the transaction
  aborted. `limitUpdated` still reflects the old JWT versus central entitlements.
- The same duplicate with a distinct newer pending token returns HTTP 403 with
  `Handshake failed. License revoked.` and no JWT. It commits `isRevoked: true`
  while retaining both the expected and pending tokens.
- A discarded Phase 1 callback with a stale expected token can leave a false HTTP
  403 with `Clone detected. License revoked.` despite the final transaction
  committing a nonrevoked record with a new pending token.
- A discarded Phase 2 callback with a stale pending token can leave a false HTTP
  403 with `Handshake failed. License revoked.` despite the final transaction
  committing the submitted token as expected, clearing pending, and remaining
  nonrevoked.

These false 403 responses can mark the platform revoked despite a nonrevoked
central record. A later, successful version-fenced handshake can reconcile that
older local hint; it does not prevent the Lambda errors or override an actual
central revocation.

## Stale Local Revocation

The `REVOKED` hint remains in place during Phase 1 and token preparation. Only
a verified Phase 2 completion may clear it to `SYNCED`. The returned JWT must
pass ES256, license identity, expiry, and heartbeat-grace validation. Recovery
also requires a different JWT with a signed heartbeat timestamp advancing the
captured source timestamp; a revision by itself is not license validation.

| Previous false response | Durable state for the new attempt | Recovery entry |
| --- | --- | --- |
| Phase 1, predecessor still installed | `J0/T0/REVOKED` | Phase 1 with expected `T0`, receiving pending `T1` |
| Phase 1, candidate already prepared | `J0/T1/REVOKED` | Phase 1 with pending `T1`, then idempotent preparation |
| Phase 2 committed but returned false 403 | `J0/T1/REVOKED` | Phase 1 with expected `T1`, receiving new candidate `T2` |

The hint's original Consul revision must remain unchanged throughout the new
handshake. Consul preserves `ModifyIndex` on equal value/flags writes, so updated
revocation writers toggle reserved bit 0 of the hint key's existing `Flags`
metadata. The value remains plain `REVOKED`, other flag bits are preserved, and
each committed revocation advances the fence even for `REVOKED` over `REVOKED`.
Direct same-value KV puts without that metadata change do not record a new event.
No additional key or migration is required. Source/token replacements and late
completion replay are likewise rejected.
An exact already-completed `SYNCED` pair may acknowledge a lost response, but
cannot clear a subsequent revocation.

Absent-key preconditions use Consul `check-not-exists`, not `check-index: 0`;
zero-index CAS writes still create absent keys. A known rejected transaction
remains a conflict if the confirmation read fails, rather than being treated as
an ambiguous write and revoking a replacement in RAM.

Failure-status writes are conditional on the captured state. A network or
verification failure must not clear an existing/newer revocation or overwrite
a replacement or completed result. A known conflict preserves the durable
winner rather than applying a fallback revocation to its memory state.

Administrators can retry through Sync License; scheduled backend heartbeats also
revalidate. A failed backend connection may return `requiresCourier: true` while
retaining `REVOKED`, allowing the manual browser courier to validate it. Central
401/403 responses and state conflicts do not enable that fallback. Dashboard and
VS Code automatic couriers still start only for `COURIER_REQUIRED`, not merely
because a revoked status is polled.

`syncStatusIndex` is optional for existing RPC callers. Unversioned prepared
handshakes retain their revoked-hint rejection; they do not gain a reset bypass.
Phase 0 submission fencing and legacy unmarked submission shapes are unchanged.

## RAM Publication

Backend queries, heartbeat helpers, and common backend/logger refreshes share one
coherent Consul snapshot reader. Public key, JWT, rolling token, and durable hint
are published to `LicenseManager` together. A local publication ticket is captured
before each actual read. Any intervening publication, mutation, or revocation
invalidates that ticket; a crossed read is repeated rather than applied late.
Even identical admitted observations advance the local generation. Per-key
`ModifyIndex` values remain CAS fences, not a global snapshot clock: deleted keys
return zero, and the transaction response does not supply a usable global index.

Snapshot values and the captured verification-key fallback are kept separate
from mutable RAM. Rejected provisioning still performs a non-hydrating read.
Confirmation first checks the intended durable result; it cannot apply a stale
or mismatched snapshot as a privileged recovery. Superseded confirmations can
return `CONFLICT` even when an earlier write committed, without replaying it.

Source decoding is best effort, not license verification. Malformed persisted JWT
payloads have an unknown identity: configuration returns `licenseId: null` while
preserving the raw JWT and rolling token, without substituting RAM or the indexed
ID. Heartbeat takes its incomplete-source exit and releases its lock without
contacting Lambda or enabling courier fallback. A verified replacement can repair
an unreadable source; incoming signature/expiry checks and known same-ID rejection
still apply. Unreadable required relay markers remain conflicts, and source decoding
alone cannot clear revocation.

A pending revocation immediately blocks licensed use in that process. Each
attempt binds once to the JWT identity from its captured coherent source, not
later RAM or the separately indexed ID. A generic report stays unbound until its
own read establishes that source. If no read establishes an identity, its barrier
remains unknown and fail-closed. Overlapping attempts retain independent ownership.

If the Consul write fails, source-bound RAM barriers survive passive configuration,
polling, and pub/sub refreshes for the same license, including changed JWTs, keys,
tokens, or `SYNCED`/`COURIER_REQUIRED` hints. Observing the same durable revocation
repeatedly is not a new local event. A fresh active recovery or replacement may
clear the barriers with its captured local recovery context still current.

A passive read may also recognize a different-license replacement committed by
another replica, or a local replacement whose confirmation read failed. All five
license rows must be present in one fresh snapshot, with a persisted key, matching
signed/indexed identity, ES256 verification, valid optional expiry, heartbeat grace,
and a `SYNCED` or `COURIER_REQUIRED` hint. An empty token row is valid tokenless
provisioning, and key rotation is supported. No heartbeat advancement relative to
the unrelated old license or equal per-key indices is required.
Every pending or latched RAM source must be known and different from that verified
license ID; otherwise passive clearance is refused. An admitted replacement retires
the old attempts so their delayed failures cannot relatch the barrier. A newer
revocation targeting the replacement still wins. This exception does not grant
same-ID passive recovery or authority to incomplete/unverified snapshots.

Async bootstrap/database key loads also carry publication tickets. Their keys
are fallbacks and cannot overwrite a coherently hydrated Consul key. A rejected
logger key lookup does not become a permanently accepted cache entry. Soft-limit
normalization remains separate and does not republish license fields after its
own awaits. Direct Phase 0 and unmarked relay RAM application/rollback use the
same guarded contract; their legacy sequential durable-write limitations remain.
An authorized Phase 0 rollback holds an unbound barrier throughout its sequential
rollback writes, preventing passive replacement clearance during that I/O. Once
the writes settle, it restores the original captured revocation scopes before
releasing the guard, including failures before publication. Those scopes may
differ from the JWT being rolled back and are not reconstructed from later RAM.

Publication generations and RAM-only barriers are per-process. They do not make
a failed revocation write durable across restart or communicate it to another
replica. All backend/logger processes must use the guarded common implementation;
an old passive hydration path can still regress its own singleton.

## Existing Guarantees

Browser couriers finish initial Phase 0 with
`license.submitRelay({ jwt: J1, nextToken: T0, initialFrom: J0, publicKey? })`.
`initialFrom` is the exact JWT captured before the initial heartbeat and cannot
be combined with `preparedFrom`. The returned JWT must verify and identify the
same license. Persistence atomically checks that the original JWT is still
installed, its rolling token is absent, and its hint is not revoked. An exact
completed pair can be acknowledged again, but a replacement or advanced token
must not be overwritten.

Once a successful Phase 0 response is available, its verification and persistence
survive SPA page/layout unmount while the captured session and license operation
remain current. This includes public-key retries. The courier retains its lease
until persistence finishes, refreshes shared status, and does not notify the
departed view. Pre-request cancellation, session/license ownership changes,
unsuccessful responses, and Phase 1/2 continuations retain their existing guards.

Dashboard provisioning and manual/automatic sync reserve mutually exclusive
ownership before provision preflight or courier requests. Conflicting actions
are disabled and refused by their handlers, not queued. A duplicate JWT precheck
does not invalidate pending status reads. Ownership survives view unmount until
the action's cleanup finishes; clearing the auth session resets it, and stale
cleanup cannot release a successor's ownership. This is per-dashboard exclusion;
the Redis courier lease and backend write fences still protect cross-client work.

For fenced initial submissions only, `submitInitialRelay` retries a transport
cancellation when the failed attempt's credentials changed within the same auth
session and the caller still owns the license operation. Each retry uses current
credentials and the exact captured JWT/token/`initialFrom`; it never repeats the
central Phase 0 request. Unchanged-credential cancellations, other failures, and
session/operation changes are not retried. General tRPC cancellation checks and
Phase 1/2 submission behavior are unchanged.

Confirmed courier cleanup remains bound to the acquisition session, not its
original access-token version. While that session is current, cleanup selects
current credentials and renews them when needed. A same-session rotation during
renewal can restart credential resolution before dispatch. Failed proactive
renewal can still use an unexpired bearer. After an auth boundary, cleanup only
attempts the captured original bearer; it never renews or borrows a successor
session. If that bearer has expired, release is best effort and the lock's
300-second TTL remains the fallback. The release RPC is sent at most once and is not
replayed after an ambiguous failure, which could otherwise delete a newer lock.

JWT provisioning is for a different license ID. Re-uploading a token for the
durably installed license is rejected without changing its JWT, rolling token,
public key, or hint; use Sync License for entitlement changes. Valid replacements
are conditional atomic writes and do not inherit the previous license's token
when no token is supplied. This rule does not change central clone detection or
recover a rolling token that has already been lost. Renew and sync before the
installed JWT expires; after expiry, a new license with a different ID is required.

Deploy the backend RPC support, including `initialFrom`, `syncStatusIndex`, and
the revocation-event writer, on all replicas before the updated dashboard/VS Code
couriers. Mixed old backends can still issue same-value revocation writes that do
not advance the fence. Existing submission shapes remain
supported, but old clients that do not prepare their candidate do not gain this
protection. There is no unsafe fallback when the preparation RPC is unavailable,
and legacy relay submissions do not provide the Phase 0 write fence.

This covers a serialized Phase 2 handshake while the installed JWT remains
valid, version-fenced reconciliation of a stale local revocation hint, and Phase 0
completion across SPA navigation in a still-running dashboard.
Phase 0 network response loss, browser reload/closure, storage loss, expired-JWT
recovery, and arbitrary historical or overlapping handshakes are not covered.
Do not clear or restore an older rolling token as an operational workaround.

Run the isolated real-handler/backend regression suite from the workspace root:

```sh
pnpm exec vitest run --config vitest.license-phase2.config.mts --configLoader runner
```

The suite uses in-memory Consul/RTDB adapters and never contacts live services.

Run dashboard lifecycle and real-transport regressions with
`pnpm --filter dashboard test`. These use test browser storage and in-memory RPC
endpoints rather than live services. Cleanup expiry regressions verify signed
auth JWTs before simulated lock admission/deletion and prove reacquisition before
the lock TTL, rather than only comparing bearer strings.
