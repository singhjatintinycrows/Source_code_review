import {
  getConsul,
  getLogger,
  HP_DEPLOYMENT_KEYS,
  HP_LICENCE_MEMORY_REFRESH_KEY,
  HP_LICENSE_SYNC_STATUS,
  LicenseManager,
} from '@hyperprobe/common';
import {
  getLicensingServerUrl,
  HYPERPROBE_LICENSING_PUBLIC_KEY_URL,
} from '@hyperprobe/constants';
import { TRPCError } from '@trpc/server';
import jwt from 'jsonwebtoken';
import type { RedisClientType } from 'redis';
import { HP_LICENCE_HEARTBEAT_LOCK_KEY } from '../helpers/appConstants.js';
import {
  completeRelayToken,
  decodeLicenseSource,
  prepareRelayToken,
  readLicenseState,
  recordRevocation,
  updateLicenseHint,
  validateLicenseRecovery,
  writeAndConfirm,
} from './phase2.js';

function verifyJwtOffline(token: string, publicKey: string): boolean {
  try {
    jwt.verify(token, publicKey, {
      algorithms: ['ES256'],
      ignoreExpiration: true,
    });
    return true;
  } catch (_e) {
    return false;
  }
}

async function fetchWithTimeout(
  url: string,
  options: RequestInit,
  timeoutMs = 10000,
) {
  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), timeoutMs);

  try {
    const response = await fetch(url, {
      ...options,
      signal: controller.signal,
    });
    clearTimeout(timeoutId);
    return response;
  } catch (error) {
    clearTimeout(timeoutId);
    if ((error as Error).name === 'AbortError') {
      throw new Error(`Connection timed out after ${timeoutMs}ms`);
    }
    throw error;
  }
}

async function handleRevocation(
  logger: ReturnType<typeof getLogger>,
  manager: LicenseManager,
  consul: ReturnType<typeof getConsul>,
  redisClient: RedisClientType,
  previous: Awaited<ReturnType<typeof readLicenseState>>,
  message: string,
) {
  try {
    await recordRevocation(consul, manager, previous);
  } catch (consulErr) {
    logger.error(
      `[Heartbeat] Failed to set revocation status in Consul: ${(consulErr as Error).message}`,
    );
  }
  logger.error(`[Heartbeat] ${message}`);

  if (redisClient) {
    try {
      await redisClient.publish(HP_LICENCE_MEMORY_REFRESH_KEY, '1');
    } catch (_) {}
    try {
      await redisClient.del(HP_LICENCE_HEARTBEAT_LOCK_KEY);
    } catch (_) {}
  }
  return { success: false, requiresCourier: false, message };
}

export async function performHeartbeat(redisClient: RedisClientType): Promise<{
  success: boolean;
  message?: string;
  limitUpdated?: boolean;
  requiresCourier?: boolean;
}> {
  const logger = getLogger();
  logger.info('[Heartbeat] Running heartbeat check.');
  const manager = LicenseManager.getInstance();
  const consul = getConsul();

  const lock = await redisClient.set(HP_LICENCE_HEARTBEAT_LOCK_KEY, '1', {
    condition: 'NX',
    expiration: { type: 'EX', value: 300 },
  });
  if (!lock) {
    logger.info(
      '[Heartbeat] Another instance or courier is already syncing. Skipping.',
    );
    return { success: false, message: 'Already syncing' };
  }

  let sourceState: Awaited<ReturnType<typeof readLicenseState>>;
  try {
    sourceState = await readLicenseState(consul, manager);
  } catch (error) {
    logger.error(
      { error },
      '[Heartbeat] Failed to read persisted license state',
    );
    try {
      await redisClient.del(HP_LICENCE_HEARTBEAT_LOCK_KEY);
    } catch (releaseError) {
      logger.warn(
        { releaseError },
        '[Heartbeat] Failed to release heartbeat lock',
      );
    }
    return {
      success: false,
      message: 'Unable to read persisted license state',
    };
  }
  const syncStatusIndex =
    sourceState.indices[HP_DEPLOYMENT_KEYS.HP_LICENSE_SYNC_STATUS];
  const recoveryContext = sourceState.recoveryContext!;
  const rawJwt = sourceState.jwt;
  const nextToken = sourceState.nextToken;
  // Keep identity tied to the captured JWT, not concurrently hydrated RAM.
  const payload = decodeLicenseSource(rawJwt);
  const licenseId =
    payload && typeof payload.licenseId === 'string' && payload.licenseId.trim()
      ? payload.licenseId
      : null;

  if (!licenseId || !rawJwt) {
    if (redisClient) await redisClient.del(HP_LICENCE_HEARTBEAT_LOCK_KEY);
    return {
      success: false,
      requiresCourier: false,
      message: 'Not provisioned yet',
    };
  }

  // Helper to dynamically fetch updated public key from Firebase if validation fails
  async function fetchNewPublicKey(): Promise<string | null> {
    try {
      const pubKeyRes = await fetchWithTimeout(
        HYPERPROBE_LICENSING_PUBLIC_KEY_URL,
        {},
        5000,
      );
      if (pubKeyRes.ok) {
        const pubKey = await pubKeyRes.json();
        if (pubKey && typeof pubKey === 'string') {
          return pubKey;
        }
      }
    } catch (err) {
      logger.warn(
        `[Heartbeat] Failed to fetch LICENSE_PUBLIC_KEY from Firebase URL: ${(err as Error).message}`,
      );
    }
    return null;
  }

  const phase = nextToken ? 1 : 0;

  try {
    const licensingServerUrl = await getLicensingServerUrl();
    // --- Phase 0/1: Request new token ---
    const res1 = await fetchWithTimeout(`${licensingServerUrl}/api/heartbeat`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ phase, licenseId, jwt: rawJwt, nextToken }),
    });

    if (res1.status === 403 || res1.status === 401) {
      return await handleRevocation(
        logger,
        manager,
        consul,
        redisClient,
        sourceState,
        'License revoked or clone detected.',
      );
    }

    if (!res1.ok) {
      throw new Error('Phase 1 Failed');
    }

    const data1 = (await res1.json()) as {
      nextToken: string;
      jwt?: string;
      limitUpdated?: boolean;
    };

    // Lazy Init (Phase 0) returns the JWT immediately if handled seamlessly by the server
    if (phase === 0 && data1.jwt) {
      const previousPublicKey = sourceState.verificationKey;
      const previousJwt = sourceState.jwt;
      const previousNextToken = sourceState.nextToken;

      let isVerified = false;
      let usedPublicKey = previousPublicKey;

      // Try verifying out-of-band with existing key first
      if (previousPublicKey && verifyJwtOffline(data1.jwt, previousPublicKey)) {
        isVerified = true;
      } else {
        logger.info(
          '[Heartbeat] Verification failed with existing key. Fetching updated public key...',
        );
        const pendingPublicKey = await fetchNewPublicKey();
        if (pendingPublicKey) {
          const formattedKey = pendingPublicKey
            .replace(/\\n/g, '\n')
            .replace(/^['"]|['"]$/g, '');
          if (verifyJwtOffline(data1.jwt, formattedKey)) {
            isVerified = true;
            usedPublicKey = formattedKey;
          }
        }
      }

      if (!isVerified) {
        logger.error(
          '[Heartbeat] Cryptographic signature verification failed with both existing and fetched public keys.',
        );
        throw new Error('New JWT signature verification failed');
      }

      const target = jwt.decode(data1.jwt) as jwt.JwtPayload;
      validateLicenseRecovery(previousJwt, data1.jwt, target, recoveryContext);
      let rollbackContext = recoveryContext;
      manager.invalidatePublications();
      try {
        if (!manager.isRecoveryCurrent(recoveryContext)) {
          throw new TRPCError({
            code: 'CONFLICT',
            message: 'License state changed; reload before retrying',
          });
        }
        if (
          typeof target.last_heartbeat_timestamp !== 'number' ||
          Number.isNaN(target.last_heartbeat_timestamp) ||
          Date.now() - target.last_heartbeat_timestamp >
            7 * 24 * 60 * 60 * 1000 ||
          (target.exp && Date.now() > target.exp * 1000)
        ) {
          logger.error(
            '[Heartbeat] License has expired or exceeded grace period.',
          );
          throw new Error('License expired or grace period exceeded');
        }

        // Commit public key to Consul if it was rotated
        if (usedPublicKey && usedPublicKey !== previousPublicKey) {
          await consul.kv.set('LICENSE_PUBLIC_KEY', usedPublicKey);
          logger.info(
            '[Heartbeat] Successfully committed rotated public key to Consul.',
          );
        }

        await consul.kv.set(HP_DEPLOYMENT_KEYS.HP_LICENSE_JWT, data1.jwt);
        await consul.kv.set(HP_DEPLOYMENT_KEYS.NEXT_TOKEN, data1.nextToken);
        if (!manager.isRecoveryCurrent(recoveryContext)) {
          throw new TRPCError({
            code: 'CONFLICT',
            message: 'License state changed; reload before retrying',
          });
        }
        await consul.kv.set(
          HP_DEPLOYMENT_KEYS.HP_LICENSE_SYNC_STATUS,
          HP_LICENSE_SYNC_STATUS.SYNCED,
        );
        manager.invalidatePublications();
        const confirmed = await writeAndConfirm(
          consul,
          manager,
          [],
          (current) =>
            current.jwt === data1.jwt &&
            current.nextToken ===
              (data1.nextToken?.trim() ? data1.nextToken : null) &&
            current.hintStatus === HP_LICENSE_SYNC_STATUS.SYNCED &&
            current.publicKey ===
              (usedPublicKey !== previousPublicKey
                ? usedPublicKey
                : sourceState.publicKey) &&
            current.verificationKey === usedPublicKey,
          { recoveryContext },
        );
        rollbackContext = confirmed.recoveryContext;

        await redisClient.publish(HP_LICENCE_MEMORY_REFRESH_KEY, '1');
        await redisClient.del(HP_LICENCE_HEARTBEAT_LOCK_KEY);
        return { success: true, limitUpdated: data1.limitUpdated };
      } catch (err) {
        if (
          !manager.isRecoveryCurrent(rollbackContext) ||
          (err instanceof TRPCError && err.code === 'CONFLICT')
        ) {
          throw err;
        }
        // Do not let passive replacement admission cross unfinished legacy writes.
        const revoked = recoveryContext.revoked
          ? manager.beginRevocation(rollbackContext)
          : null;
        // Best-effort rollback of Consul keys to preserve state consistency
        try {
          if (usedPublicKey && usedPublicKey !== previousPublicKey) {
            await consul.kv.set('LICENSE_PUBLIC_KEY', previousPublicKey || '');
          }
          await consul.kv.set(
            HP_DEPLOYMENT_KEYS.HP_LICENSE_JWT,
            previousJwt || '',
          );
          await consul.kv.set(
            HP_DEPLOYMENT_KEYS.NEXT_TOKEN,
            previousNextToken || '',
          );
          await consul.kv.set(
            HP_DEPLOYMENT_KEYS.HP_LICENSE_SYNC_STATUS,
            HP_LICENSE_SYNC_STATUS.COURIER_REQUIRED,
          );
        } catch (_rollbackErr) {
          // Fail silently on rollback failures to avoid masking original error
        } finally {
          if (revoked) {
            manager.recordLocalRevocation(
              revoked,
              recoveryContext.revocationSources,
            );
            manager.endRevocation(revoked);
          }
        }
        throw err;
      } finally {
        manager.invalidatePublications();
      }
    }

    const newNextToken = data1.nextToken;

    if (!nextToken) throw new Error('Phase 2 requires an established token');
    // Both a lost request and a lost committed response can resume from this candidate.
    sourceState = await prepareRelayToken(consul, manager, {
      jwt: rawJwt,
      previousNextToken: nextToken,
      nextToken: newNextToken,
      syncStatusIndex,
    });

    // --- Phase 2: Commit new token and get JWT ---
    const res2 = await fetchWithTimeout(`${licensingServerUrl}/api/heartbeat`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        phase: 2,
        licenseId,
        jwt: rawJwt,
        nextToken: newNextToken,
      }),
    });

    if (res2.status === 403 || res2.status === 401) {
      return await handleRevocation(
        logger,
        manager,
        consul,
        redisClient,
        sourceState,
        'License revoked or clone detected during Phase 2.',
      );
    }

    if (!res2.ok) {
      throw new Error('Phase 2 Failed');
    }

    const data2 = (await res2.json()) as { jwt: string; limitUpdated: boolean };
    const newJwt = data2.jwt;

    // Finalize State
    const previousPublicKey = sourceState.verificationKey;

    let isVerified = false;
    let usedPublicKey = previousPublicKey;

    // Try verifying out-of-band with existing key first
    if (previousPublicKey && verifyJwtOffline(newJwt, previousPublicKey)) {
      isVerified = true;
    } else {
      logger.info(
        '[Heartbeat] Verification failed with existing key. Fetching updated public key...',
      );
      const pendingPublicKey = await fetchNewPublicKey();
      if (pendingPublicKey) {
        const formattedKey = pendingPublicKey
          .replace(/\\n/g, '\n')
          .replace(/^['"]|['"]$/g, '');
        if (verifyJwtOffline(newJwt, formattedKey)) {
          isVerified = true;
          usedPublicKey = formattedKey;
        }
      }
    }

    if (!isVerified) {
      logger.error(
        '[Heartbeat] Cryptographic signature verification failed with both existing and fetched public keys.',
      );
      throw new Error('New JWT signature verification failed');
    }

    // Keep error writes fenced to the prepared source if the final acknowledgement is lost.
    await completeRelayToken(
      consul,
      manager,
      {
        jwt: newJwt,
        preparedFrom: rawJwt,
        nextToken: newNextToken,
        publicKey: usedPublicKey || undefined,
        syncStatusIndex,
      },
      recoveryContext,
    );
    logger.info(
      '[Heartbeat] Successfully synced with Central Licensing Server.',
    );
    try {
      await redisClient.publish(HP_LICENCE_MEMORY_REFRESH_KEY, '1');
    } catch (error) {
      logger.warn(
        { error },
        '[Heartbeat] License persisted; refresh notification failed',
      );
    }
    try {
      await redisClient.del(HP_LICENCE_HEARTBEAT_LOCK_KEY);
    } catch (error) {
      logger.warn(
        { error },
        '[Heartbeat] License persisted; lock release failed',
      );
    }
    return { success: true, limitUpdated: data2.limitUpdated };
  } catch (e) {
    console.log(
      '[Heartbeat] Heartbeat synchronization error.',
      (e as Error).message,
    );
    let requiresCourier = !(e instanceof TRPCError && e.code === 'CONFLICT');
    try {
      if (requiresCourier) {
        await updateLicenseHint(
          consul,
          manager,
          sourceState,
          HP_LICENSE_SYNC_STATUS.COURIER_REQUIRED,
        );
      } else {
        await readLicenseState(consul, manager);
      }
    } catch (consulErr) {
      if (consulErr instanceof TRPCError && consulErr.code === 'CONFLICT') {
        requiresCourier = false;
      }
      logger.error(
        `[Heartbeat] Failed to set sync status in Consul: ${(consulErr as Error).message}`,
      );
    }
    logger.warn(
      `[Heartbeat] Heartbeat synchronization error. Courier required: ${requiresCourier}.`,
    );

    if (redisClient) {
      try {
        await redisClient.publish(HP_LICENCE_MEMORY_REFRESH_KEY, '1');
      } catch (_) {}
      try {
        await redisClient.del(HP_LICENCE_HEARTBEAT_LOCK_KEY);
      } catch (_) {}
    }
    return { success: false, requiresCourier, message: (e as Error).message };
  }
}
