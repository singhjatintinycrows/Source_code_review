import { getConfig, getConsul } from '@hyperprobe/common';
import { initDatabase } from '@hyperprobe/database';
import {
  acquireCredentialEncryptionLock,
  appendCredentialEncryptionKeyVersion,
  type CredentialKeyringConsul,
  completeCredentialEncryptionRotation,
  loadCredentialEncryptionKeyring,
  loadCredentialEncryptionRotation,
  nextCredentialKeyVersion,
} from '../observability/credentialKeyring.js';

const DEFAULT_BATCH_SIZE = 100;
const MAX_BATCH_SIZE = 1_000;

type RotationOptions = {
  batchSize: number;
  dryRun: boolean;
};

type StoredConnection = {
  id: string;
  serviceId: string;
  provider: string;
  credentialFormat: string;
  credentialCiphertext: Uint8Array;
  credentialNonce: Uint8Array;
  credentialAuthTag: Uint8Array;
  credentialKeyVersion: string;
  updatedAt: Date;
};

type RotationStore = {
  observabilityConnection: {
    count(args: unknown): Promise<number>;
    findMany(args: unknown): Promise<StoredConnection[]>;
    updateMany(args: unknown): Promise<{ count: number }>;
  };
};

async function assertStoredVersionsAreConfigured(
  store: RotationStore,
  configuredVersions: ReadonlyMap<string, string>,
) {
  const storedVersions = await store.observabilityConnection.findMany({
    distinct: ['credentialKeyVersion'],
    select: { credentialKeyVersion: true },
  });
  const missingVersion = storedVersions.find(
    ({ credentialKeyVersion }) => !configuredVersions.has(credentialKeyVersion),
  )?.credentialKeyVersion;
  if (missingVersion) {
    throw new Error(
      `Credential encryption key ${missingVersion} is missing from the Consul keyring.`,
    );
  }
}

function parseOptions(arguments_: string[]): RotationOptions {
  const normalizedArguments =
    arguments_[0] === '--' ? arguments_.slice(1) : arguments_;
  let dryRun = false;
  let batchSize = DEFAULT_BATCH_SIZE;
  for (const argument of normalizedArguments) {
    if (argument === '--dry-run') {
      dryRun = true;
      continue;
    }
    if (argument.startsWith('--batch-size=')) {
      const value = Number(argument.slice('--batch-size='.length));
      if (!Number.isSafeInteger(value) || value < 1 || value > MAX_BATCH_SIZE) {
        throw new Error(
          `--batch-size must be an integer between 1 and ${MAX_BATCH_SIZE}.`,
        );
      }
      batchSize = value;
      continue;
    }
    throw new Error(
      'Usage: pnpm credentials:rotate -- [--dry-run] [--batch-size=<1-1000>]',
    );
  }
  return { batchSize, dryRun };
}

async function main() {
  const options = parseOptions(process.argv.slice(2));
  const config = await getConfig();
  const prisma = initDatabase(config.databaseUrl);
  const consul = getConsul() as unknown as CredentialKeyringConsul;
  const store = prisma as unknown as RotationStore;

  try {
    const keyring = await loadCredentialEncryptionKeyring(consul);
    if (!keyring) {
      throw new Error(
        'Credential encryption is not initialized in Consul. Run the initialization script first.',
      );
    }

    const rotation = await loadCredentialEncryptionRotation(consul);
    if (rotation && rotation.version !== keyring.activeVersion) {
      throw new Error(
        'Credential encryption rotation state does not match the active Consul version.',
      );
    }
    await assertStoredVersionsAreConfigured(store, keyring.secrets);

    const pendingConnections = await store.observabilityConnection.count({
      where: { credentialKeyVersion: { not: keyring.activeVersion } },
    });
    const targetVersion =
      rotation || pendingConnections > 0
        ? keyring.activeVersion
        : nextCredentialKeyVersion(keyring.secrets);
    if (options.dryRun) {
      const affectedConnections =
        rotation || pendingConnections > 0
          ? pendingConnections
          : await store.observabilityConnection.count({
              where: { credentialKeyVersion: { not: targetVersion } },
            });
      console.log(
        rotation || pendingConnections > 0
          ? `Dry run: would resume ${targetVersion} and re-encrypt ${pendingConnections} observability connection(s).`
          : `Dry run: would create ${targetVersion} and re-encrypt ${affectedConnections} observability connection(s).`,
      );
      return;
    }

    const lock = await acquireCredentialEncryptionLock(consul);
    try {
      await lock.renew();
      lock.assertHeld();
      const currentKeyring = await loadCredentialEncryptionKeyring(consul);
      if (!currentKeyring) {
        throw new Error(
          'Credential encryption is not initialized in Consul. Run the initialization script first.',
        );
      }

      const currentRotation = await loadCredentialEncryptionRotation(consul);
      if (
        currentRotation &&
        currentRotation.version !== currentKeyring.activeVersion
      ) {
        throw new Error(
          'Credential encryption rotation state does not match the active Consul version.',
        );
      }

      await assertStoredVersionsAreConfigured(store, currentKeyring.secrets);

      const currentPendingConnections =
        await store.observabilityConnection.count({
          where: {
            credentialKeyVersion: { not: currentKeyring.activeVersion },
          },
        });
      const startsNewRotation =
        !currentRotation && currentPendingConnections === 0;
      const rotatedKeyring =
        currentRotation || currentPendingConnections > 0
          ? currentKeyring
          : await appendCredentialEncryptionKeyVersion(consul, currentKeyring);
      const targetVersion = rotatedKeyring.activeVersion;
      const resumedRotation = !startsNewRotation;
      const activeRotation = await loadCredentialEncryptionRotation(consul);
      if (startsNewRotation && activeRotation?.version !== targetVersion) {
        throw new Error(
          'Credential encryption rotation state was not created in Consul.',
        );
      }
      if (activeRotation && activeRotation.version !== targetVersion) {
        throw new Error(
          'Credential encryption rotation state changed while rotation was running.',
        );
      }
      let cursor: string | undefined;
      let migratedConnections = 0;

      while (true) {
        await lock.renew();
        const connections = await store.observabilityConnection.findMany({
          where: {
            credentialKeyVersion: { not: targetVersion },
            ...(cursor ? { id: { gt: cursor } } : {}),
          },
          orderBy: { id: 'asc' },
          take: options.batchSize,
        });
        if (connections.length === 0) break;

        for (const connection of connections) {
          lock.assertHeld();
          const encryptedCredential = rotatedKeyring.cipher.reencrypt(
            {
              serviceId: connection.serviceId,
              connectionId: connection.id,
              provider: connection.provider,
              credentialFormat: connection.credentialFormat,
            },
            connection,
          );
          const updated = await store.observabilityConnection.updateMany({
            where: {
              id: connection.id,
              credentialKeyVersion: connection.credentialKeyVersion,
              updatedAt: connection.updatedAt,
            },
            data: encryptedCredential,
          });
          migratedConnections += updated.count;
        }
        cursor = connections[connections.length - 1]?.id;
      }

      await lock.renew();
      lock.assertHeld();
      const remainingConnections = await store.observabilityConnection.count({
        where: { credentialKeyVersion: { not: targetVersion } },
      });
      if (remainingConnections > 0) {
        throw new Error(
          `${remainingConnections} observability connection(s) remain on an older credential encryption version. Re-run the rotation script.`,
        );
      }

      if (activeRotation) {
        lock.assertHeld();
        await completeCredentialEncryptionRotation(consul, targetVersion);
      }

      console.log(
        `${resumedRotation ? 'Resumed' : 'Created'} ${targetVersion} and re-encrypted ${migratedConnections} observability connection(s).`,
      );
    } finally {
      try {
        await lock.release();
      } catch (_error) {
        console.warn(
          'Credential encryption lock cleanup failed; the Consul session will expire.',
        );
      }
    }
  } finally {
    try {
      await prisma.$disconnect();
    } catch (_error) {
      console.warn('Database connection cleanup failed.');
    }
  }
}

void main().catch((error: unknown) => {
  console.error(
    error instanceof Error
      ? `Credential encryption rotation failed: ${error.message}`
      : 'Credential encryption rotation failed.',
  );
  process.exitCode = 1;
});
