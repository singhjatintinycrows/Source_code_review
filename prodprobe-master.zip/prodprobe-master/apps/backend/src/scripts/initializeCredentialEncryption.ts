import { getConfig, getConsul } from '@hyperprobe/common';
import { initDatabase } from '@hyperprobe/database';
import {
  acquireCredentialEncryptionLock,
  type CredentialKeyringConsul,
  createInitialCredentialEncryptionKeyring,
  loadCredentialEncryptionKeyring,
  loadCredentialEncryptionRotation,
} from '../observability/credentialKeyring.js';

const DISCARD_FLAG = '--discard-existing-connections';
const CONFIRMATION_FLAG = '--confirm=DISCARD_OBSERVABILITY_CONNECTIONS';

type InitializationStore = {
  observabilityConnection: {
    count(): Promise<number>;
    deleteMany(args: Record<string, never>): Promise<{ count: number }>;
  };
  $transaction<T>(
    callback: (transaction: InitializationStore) => Promise<T>,
  ): Promise<T>;
};

function validateArguments(arguments_: string[]) {
  const normalizedArguments =
    arguments_[0] === '--' ? arguments_.slice(1) : arguments_;
  const expected = new Set([DISCARD_FLAG, CONFIRMATION_FLAG]);
  if (
    normalizedArguments.length !== expected.size ||
    new Set(normalizedArguments).size !== expected.size ||
    [...expected].some((argument) => !normalizedArguments.includes(argument))
  ) {
    throw new Error(
      `Usage: pnpm credentials:initialize -- ${DISCARD_FLAG} ${CONFIRMATION_FLAG}`,
    );
  }
}

async function main() {
  validateArguments(process.argv.slice(2));

  const config = await getConfig();
  const prisma = initDatabase(config.databaseUrl);
  const consul = getConsul() as unknown as CredentialKeyringConsul;
  const store = prisma as unknown as InitializationStore;
  let lock:
    | Awaited<ReturnType<typeof acquireCredentialEncryptionLock>>
    | undefined;

  try {
    lock = await acquireCredentialEncryptionLock(consul);
    if (await loadCredentialEncryptionKeyring(consul)) {
      throw new Error(
        'Credential encryption is already configured in Consul. Refusing to discard connections.',
      );
    }
    if (await loadCredentialEncryptionRotation(consul)) {
      throw new Error(
        'Credential encryption rotation is in progress. Resume it instead of initializing a new keyring.',
      );
    }

    await lock.renew();
    lock.assertHeld();
    const discardedConnections = await store.$transaction(async (transaction) =>
      transaction.observabilityConnection.deleteMany({}),
    );

    await lock.renew();
    lock.assertHeld();
    const keyring = await createInitialCredentialEncryptionKeyring(consul);
    console.log(
      `Discarded ${discardedConnections.count} observability connection(s). Initialized credential encryption at ${keyring.activeVersion}.`,
    );
  } finally {
    try {
      await lock?.release();
    } catch (_error) {
      console.warn(
        'Credential encryption lock cleanup failed; the Consul session will expire.',
      );
    } finally {
      try {
        await prisma.$disconnect();
      } catch (_error) {
        console.warn('Database connection cleanup failed.');
      }
    }
  }
}

void main().catch((error: unknown) => {
  console.error(
    error instanceof Error
      ? `Credential encryption initialization failed: ${error.message}`
      : 'Credential encryption initialization failed.',
  );
  process.exitCode = 1;
});
