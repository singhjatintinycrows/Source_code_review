import * as path from 'node:path';
import cors from '@fastify/cors';
import proxy from '@fastify/http-proxy';
import fastifyStaticPlugin, { type SetHeadersResponse } from '@fastify/static';
import {
  getConfig,
  getConsul,
  getLogger,
  HP_LICENCE_MEMORY_REFRESH_KEY,
  LicenseManager,
  syncLicenseAndSoftLimit,
  watchLogLevel,
} from '@hyperprobe/common';
import { initDatabase, type Prisma } from '@hyperprobe/database';
import type { SourceMapConsumer } from '@jridgewell/source-map';
import type { CreateFastifyContextOptions } from '@trpc/server/adapters/fastify';
import { fastifyTRPCPlugin } from '@trpc/server/adapters/fastify';
import crypto from 'crypto';
import Fastify from 'fastify';
import jwt from 'jsonwebtoken';
import { LRUCache } from 'lru-cache';
import { createClient, type RedisClientType } from 'redis';
import { initCronSchedulers } from './cron/index.js';
import { getTokenSecret, setTokenSecret } from './helpers/tokenSecret.js';
import { licenseRouter } from './license/licenseRouter.js';
import {
  type CredentialKeyringConsul,
  isCredentialEncryptionMaintenanceActive,
  loadOrInitializeCredentialCipher,
} from './observability/credentialKeyring.js';
import { agentsRouter } from './routers/agentsRouter.js';
import { authRouter } from './routers/authRouter.js';
import { observabilityIntegrationsRouter } from './routers/observabilityIntegrationsRouter.js';
import { probesRouter } from './routers/probesRouter.js';
import { rcaRouter } from './routers/rcaRouter.js';
import {
  servicesFlatRouter,
  servicesRouter,
} from './routers/servicesRouter.js';
import { teamsRouter } from './routers/teamsRouter.js';
import { usersFlatRouter, usersRouter } from './routers/usersRouter.js';
import { type Context, t } from './trpc.js';

const appRouter = t.mergeRouters(
  t.router({
    teams: teamsRouter,
    users: usersRouter,
    services: servicesRouter,
    license: licenseRouter,
    rca: rcaRouter,
    observabilityIntegrations: observabilityIntegrationsRouter,
  }),
  usersFlatRouter,
  servicesFlatRouter,
  probesRouter,
  agentsRouter,
  authRouter,
);

export type AppRouter = typeof appRouter;

async function start() {
  const config = await getConfig();
  const prisma = initDatabase(config.databaseUrl);
  const logger = getLogger();
  const consul = getConsul();
  const credentialKeyringConsul = consul as unknown as CredentialKeyringConsul;
  const credentialCipher = await loadOrInitializeCredentialCipher(
    credentialKeyringConsul,
    async () =>
      (
        prisma as unknown as {
          observabilityConnection: { count(): Promise<number> };
        }
      ).observabilityConnection.count(),
  );
  if (await isCredentialEncryptionMaintenanceActive(credentialKeyringConsul)) {
    throw new Error(
      'Credential encryption maintenance is in progress. Backend startup is blocked until it completes.',
    );
  }
  logger.info(
    'Consul-backed database encryption for observability credentials is enabled.',
  );
  // prisma middleware to log postgres queries to console
  prisma.$on('query' as never, (event: Prisma.QueryEvent) => {
    logger.debug(
      { query: event.query, params: event.params, duration: event.duration },
      'prisma:sql',
    );
  });

  const licenseManager = LicenseManager.getInstance();
  const licenseBootstrap = licenseManager.capturePublication();

  // Initialize in-memory token secret and handle injected public key
  let rawPublicKey = process.env.LICENSE_PUBLIC_KEY;

  if (!rawPublicKey) {
    try {
      const pubKeyItem: any = await consul.kv.get('LICENSE_PUBLIC_KEY');
      if (pubKeyItem && pubKeyItem.Value) {
        rawPublicKey = pubKeyItem.Value;
      }
    } catch (_e) {
      logger.warn('Failed to fetch LICENSE_PUBLIC_KEY from Consul');
    }
  }

  const updateData: Prisma.SystemConfigUpdateInput = {};

  if (rawPublicKey) {
    // If the public key is provided (with literal \n for newlines), fix it
    let formattedKey = rawPublicKey.replace(/\\n/g, '\n');
    // Strip accidental surrounding single or double quotes
    formattedKey = formattedKey.replace(/^['"]|['"]$/g, '');
    updateData.licensePublicKey = formattedKey;
  }

  const sysConfig = await prisma.systemConfig.upsert({
    where: { id: 'singleton' },
    update: updateData,
    create: {
      id: 'singleton',
      tokenSecret: crypto.randomUUID(),
      ...updateData,
    } as Prisma.SystemConfigCreateInput,
  });

  setTokenSecret(sysConfig.tokenSecret);

  if (sysConfig.licensePublicKey) {
    licenseManager.setBootstrapPublicKey(
      sysConfig.licensePublicKey,
      licenseBootstrap,
    );
  }

  const syncLicenseFromConsul = async () => {
    try {
      await syncLicenseAndSoftLimit(consul, licenseManager);
    } catch (_e) {
      logger.warn('Failed to fetch license state from Consul');
    }
  };

  await syncLicenseFromConsul();

  // The 2-hour fallback interval
  setInterval(syncLicenseFromConsul, 2 * 60 * 60 * 1000);

  watchLogLevel(consul);

  const redisClient: RedisClientType = createClient({ url: config.redisUrl });
  redisClient.on('error', (err) => logger.error({ err }, 'Redis Client Error'));
  await redisClient.connect();
  logger.info('Connected to Redis');

  // Set up Redis Pub/Sub for instant memory propagation
  const redisSubscriber = redisClient.duplicate();
  await redisSubscriber.connect();
  await redisSubscriber.subscribe(HP_LICENCE_MEMORY_REFRESH_KEY, async () => {
    logger.info('Received Pub/Sub message to refresh license memory.');
    await syncLicenseFromConsul();
  });

  // Simple in-memory cache for source map consumers
  const consumerCache = new LRUCache<string, SourceMapConsumer>({
    max: 500,
  });

  // Initialize BullMQ Schedulers and Workers
  await initCronSchedulers(config.redisUrl, redisClient);

  // --- Fastify / tRPC Server ---
  const fastify = Fastify({
    logger, // Simplified logger configuration to bypass strict Fastify/Pino typing mismatch
  });

  await fastify.register(cors, {
    origin: true, // Allow all origins for the extension webview
    credentials: true,
  });

  fastify.get('/health', (_req, res) => {
    res.send('OK');
  });

  // Redirect root to dashboard
  fastify.get('/', (_req, res) => {
    res.redirect('/dashboard/');
  });

  fastify.register(fastifyTRPCPlugin, {
    prefix: '/trpc',
    trpcOptions: {
      router: appRouter,
      createContext: ({ req, res }: CreateFastifyContextOptions): Context => {
        let user: Context['user'];
        try {
          const authHeader = req.headers.authorization;
          let token = '';
          if (authHeader && authHeader.startsWith('Bearer ')) {
            token = authHeader.substring(7);
          }

          if (token) {
            const decoded = jwt.verify(
              token,
              getTokenSecret(),
            ) as jwt.JwtPayload;
            user = {
              userId: decoded.userId,
              email: decoded.email,
              permissions: decoded.permissions,
            };
          }
        } catch (_e) {
          // Token invalid or expired, ignore and leave user undefined
        }

        return {
          prisma,
          redisClient,
          consumerCache,
          logger,
          credentialCipher,
          credentialEncryptionMaintenanceActive: () =>
            isCredentialEncryptionMaintenanceActive(credentialKeyringConsul),
          req,
          res,
          user,
        };
      },
    },
  });

  if (process.env.NODE_ENV === 'production') {
    await fastify.register(fastifyStaticPlugin, {
      root: path.join(__dirname, 'dashboard-dist'),
      prefix: '/dashboard/',
      setHeaders(reply: SetHeadersResponse, filePath: string) {
        reply.setHeader(
          'Cache-Control',
          filePath.endsWith('.html') ? 'no-cache' : 'public, max-age=31536000',
        );
      },
    });
  } else {
    // dashboard proxy
    await fastify.register(proxy, {
      upstream: `http://localhost:${process.env.DASHBOARD_PORT!}/`,
      prefix: '/dashboard',
      rewritePrefix: '/dashboard',
      http2: false, // optional
      websocket: true,
    });
  }

  const HTTP_PORT = parseInt(process.env.HTTP_PORT || '3001', 10);

  fastify.listen({ port: HTTP_PORT, host: '0.0.0.0' }, (err) => {
    if (err) {
      fastify.log.error(err);
      process.exit(1);
    }
  });
}

start().catch((err) => {
  console.error(err);
  process.exit(1);
});
