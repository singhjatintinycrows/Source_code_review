import {
  type getLogger,
  HP_LICENSE_SYNC_STATUS,
  LicenseManager,
} from '@hyperprobe/common';
import type { initDatabase } from '@hyperprobe/database';
import type { SourceMapConsumer } from '@jridgewell/source-map';
import { initTRPC, TRPCError } from '@trpc/server';
import type { CreateFastifyContextOptions } from '@trpc/server/adapters/fastify';
import type { LRUCache } from 'lru-cache';
import type { RedisClientType } from 'redis';
import superjson from 'superjson';
import { ROLE_TYPES } from './helpers/appConstants.js';
import type { CredentialCipher } from './observability/credentialCipher.js';
import { retryAtFor } from './observability/errors.js';

export type Context = {
  prisma: ReturnType<typeof initDatabase>;
  redisClient: RedisClientType;
  consumerCache: LRUCache<string, SourceMapConsumer>;
  logger: ReturnType<typeof getLogger>;
  credentialCipher: CredentialCipher | null;
  credentialEncryptionMaintenanceActive: () => Promise<boolean>;
  req: CreateFastifyContextOptions['req'];
  res: CreateFastifyContextOptions['res'];
  user?: {
    userId: string;
    email: string;
    permissions: {
      isAdmin: boolean;
      permissions: Record<string, number>;
    };
  };
};

export const t = initTRPC.context<Context>().create({
  transformer: superjson,
  errorFormatter({ shape, error }) {
    const retryAt = retryAtFor(error.cause);
    return {
      ...shape,
      data: { ...shape.data, ...(retryAt ? { retryAt } : {}) },
    };
  },
});

// Middleware to protect routes that require authentication
const isAuth = t.middleware(async ({ ctx, next }) => {
  if (!ctx.user) {
    throw new TRPCError({ code: 'UNAUTHORIZED' });
  }

  return next({
    ctx: {
      user: ctx.user,
    },
  });
});

// Middleware to check if user is Global Admin
const isAdmin = t.middleware(async ({ ctx, next }) => {
  if (!ctx.user) {
    throw new TRPCError({ code: 'UNAUTHORIZED' });
  }

  if (!ctx.user.permissions.isAdmin) {
    throw new TRPCError({
      code: 'FORBIDDEN',
      message: 'Admin access required',
    });
  }
  return next({
    ctx: {
      user: ctx.user,
    },
  });
});

// Middleware to check if user is Global Admin OR has Service Manager access
const hasServiceLeadAccess = t.middleware(async ({ ctx, next, rawInput }) => {
  if (!ctx.user) {
    throw new TRPCError({ code: 'UNAUTHORIZED' });
  }

  const input = rawInput as { serviceId?: string } | undefined;
  const serviceId = input?.serviceId;

  if (!serviceId) {
    throw new TRPCError({
      code: 'BAD_REQUEST',
      message: 'serviceId is required for access check',
    });
  }

  const adminCheck = ctx.user.permissions.isAdmin;

  if (adminCheck) {
    return next({ ctx: { user: ctx.user } });
  }

  const leadCheck =
    ctx.user.permissions.permissions[serviceId] === ROLE_TYPES.Manager;

  if (leadCheck) {
    return next({ ctx: { user: ctx.user } });
  }

  throw new TRPCError({
    code: 'FORBIDDEN',
    message:
      'You must be a Service Manager or an Admin to modify or delete this service.',
  });
});

export function hasServiceMembership(
  user: Context['user'],
  serviceId: string,
): boolean {
  return (
    user?.permissions.isAdmin === true ||
    user?.permissions.permissions[serviceId] !== undefined
  );
}

const hasServiceMemberAccess = t.middleware(async ({ ctx, next, rawInput }) => {
  if (!ctx.user) {
    throw new TRPCError({ code: 'UNAUTHORIZED' });
  }
  const input = rawInput as { serviceId?: string } | undefined;
  const serviceId = input?.serviceId;
  if (!serviceId) {
    throw new TRPCError({
      code: 'BAD_REQUEST',
      message: 'serviceId is required for access check',
    });
  }
  if (hasServiceMembership(ctx.user, serviceId)) {
    return next({ ctx: { user: ctx.user } });
  }
  throw new TRPCError({
    code: 'FORBIDDEN',
    message: 'You must have access to this service to access RCA evidence.',
  });
});

// Helper procedure to build off for admin routes
const isLicensed = t.middleware(async ({ next }) => {
  const licenseManager = LicenseManager.getInstance();
  const status = licenseManager.getStatus();

  if (
    status === HP_LICENSE_SYNC_STATUS.LOCKED ||
    status === HP_LICENSE_SYNC_STATUS.REVOKED
  ) {
    throw new TRPCError({
      code: 'FORBIDDEN',
      message: `License is ${status}. Please update your license or contact support.`,
    });
  }

  return next();
});

export const authProcedure = t.procedure.use(isAuth);
export const unlicensedAdminProcedure = authProcedure.use(isAdmin);
export const licensedProcedure = t.procedure.use(isLicensed);
export const adminProcedure = licensedProcedure.use(isAdmin);
export const protectedProcedure = licensedProcedure.use(isAuth);
export const serviceLeadProcedure = licensedProcedure.use(hasServiceLeadAccess);
export const serviceMemberProcedure = licensedProcedure.use(
  hasServiceMemberAccess,
);
