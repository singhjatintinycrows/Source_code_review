export const ROLE_TYPES = {
  Viewer: 10,
  Editor: 30,
  Manager: 50,
};

export const HP_LICENCE_HEARTBEAT_LOCK_KEY = 'hp_license:heartbeat_lock';
