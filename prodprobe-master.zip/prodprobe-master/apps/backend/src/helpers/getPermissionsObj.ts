import type { Prisma } from '@hyperprobe/database';

export interface PermissionsResult {
  isAdmin: boolean;
  permissions: Record<string, number>;
}

export type FullUserWithTeamsAndServices = Prisma.UserGetPayload<{
  include: {
    teams: {
      include: {
        team: {
          include: {
            services: true;
          };
        };
      };
    };
  };
}>;

/**
 * Calculates the permissions object for a user based on their team affiliations and team service roles.
 *
 * @param user The full user object with nested teams and services
 * @returns A PermissionsResult containing a boolean flag for global admin and a mapping of serviceId to roleValue.
 */
export function getPermissionsObj(
  user: FullUserWithTeamsAndServices,
): PermissionsResult {
  // Check if any of the user's teams is the global Admin team
  const isAdmin = user.teams.some((ut) => ut.team.isAdminTeam);

  if (isAdmin) {
    return {
      isAdmin: true,
      permissions: {},
    };
  }

  // Compute the max role for each service the user has access to
  const permissions: Record<string, number> = {};

  for (const ut of user.teams) {
    for (const ts of ut.team.services) {
      const currentRole = permissions[ts.serviceId];
      if (currentRole === undefined || ts.role > currentRole) {
        permissions[ts.serviceId] = ts.role;
      }
    }
  }

  return {
    isAdmin: false,
    permissions,
  };
}
