let tokenSecret: string | null = null;

export function getTokenSecret(): string {
  if (!tokenSecret) {
    throw new Error('Token secret has not been initialized');
  }
  return tokenSecret;
}

export function setTokenSecret(secret: string): void {
  if (!secret) {
    throw new Error('Token secret must be a non-empty string');
  }
  tokenSecret = secret;
}
