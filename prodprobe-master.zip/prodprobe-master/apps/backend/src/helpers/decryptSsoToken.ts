import crypto from 'crypto';
import { publicKey } from '../public_key_pem.js';

// Decrypt email with public key
export function decryptEmailToken(encryptedEmail: string): string {
  try {
    const encryptedBuffer = Buffer.from(encryptedEmail, 'base64');
    // Decrypt using the public key
    const decrypted = crypto.publicDecrypt(
      {
        key: publicKey,
        padding: crypto.constants.RSA_PKCS1_PADDING, // Ensure padding matches encryption
      },
      encryptedBuffer,
    );

    return decrypted.toString('utf8'); // Convert decrypted Buffer back to string
  } catch (error) {
    console.error('Decryption error:', error);
    throw new Error('Failed to decrypt the email.');
  }
}
