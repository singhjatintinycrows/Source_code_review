export type WireOperation = {
  KV: {
    Verb: 'get-or-empty' | 'check-index' | 'check-not-exists' | 'cas' | 'set';
    Key: string;
    Index?: number;
    Value?: string;
    Flags?: number;
  };
};

type WriteFault = { key: string; mode: 'before-write' | 'ack-loss' };

export function deferred<T = void>() {
  let resolve!: (value: T) => void;
  const promise = new Promise<T>((done) => {
    resolve = done;
  });
  return { promise, resolve };
}

export class DurableConsul {
  private rows = new Map<
    string,
    { value: string; index: number; flags: number }
  >();
  private revision = 0;
  fault?: WriteFault;
  beforeNextWrite?: () => unknown;
  private deferredReads: {
    started: ReturnType<typeof deferred<void>>;
    captured: ReturnType<typeof deferred<void>>;
    linearize: ReturnType<typeof deferred<void>>;
    release: ReturnType<typeof deferred<void>>;
  }[] = [];
  // Accepted write transactions can be no-ops; writes records only changed KV rows.
  readonly writes: { key: string; value: string }[] = [];
  readonly transactions: {
    operations: WireOperation[];
    consistent: boolean;
    committed: boolean;
    changedKeys: string[];
  }[] = [];

  constructor(
    seed: Record<string, string>,
    flags: Record<string, number> = {},
  ) {
    for (const [key, value] of Object.entries(seed)) {
      this.rows.set(key, {
        value,
        index: ++this.revision,
        flags: flags[key] ?? 0,
      });
    }
  }

  value(key: string) {
    return this.rows.get(key)?.value ?? null;
  }

  index(key: string) {
    return this.rows.get(key)?.index ?? 0;
  }

  flags(key: string) {
    return this.rows.get(key)?.flags ?? 0;
  }

  snapshot() {
    return Object.fromEntries(
      [...this.rows].map(([key, row]) => [key, row.value]),
    );
  }

  deferNextRead(beforeLinearization = false) {
    const read = {
      started: deferred(),
      captured: deferred(),
      linearize: deferred(),
      release: deferred(),
    };
    if (!beforeLinearization) read.linearize.resolve();
    this.deferredReads.push(read);
    return {
      started: read.started.promise,
      captured: read.captured.promise,
      linearize: () => read.linearize.resolve(),
      release: () => read.release.resolve(),
    };
  }

  private takeFault(keys: string[]) {
    if (this.fault && keys.includes(this.fault.key)) {
      const fault = this.fault;
      this.fault = undefined;
      return fault;
    }
  }

  private fail(fault: WriteFault) {
    throw new Error(`Consul ${fault.mode}: ${fault.key}`);
  }

  readonly kv = {
    del: async (key: string) => {
      this.revision++;
      return this.rows.delete(key);
    },
    get: async (input: string | { key: string; consistent?: boolean }) => {
      const key = typeof input === 'string' ? input : input.key;
      const row = this.rows.get(key);
      return row
        ? {
            Key: key,
            ModifyIndex: row.index,
            Value: row.value,
            Flags: row.flags,
          }
        : undefined;
    },
    set: async (key: string, value: string, options?: { flags?: number }) => {
      const fault = this.takeFault([key]);
      if (fault?.mode === 'before-write') this.fail(fault);
      const flags = options?.flags ?? 0;
      const index = ++this.revision;
      const existing = this.rows.get(key);
      if (!existing || existing.value !== value || existing.flags !== flags) {
        this.rows.set(key, { value, index, flags });
        this.writes.push({ key, value });
      }
      if (fault) this.fail(fault);
      return true;
    },
  };

  readonly transaction = {
    create: async (
      operations: WireOperation[],
      options?: { consistent?: boolean },
    ) => {
      const record = {
        operations: structuredClone(operations),
        consistent: options?.consistent === true,
        committed: false,
        changedKeys: [] as string[],
      };
      this.transactions.push(record);
      if (!Array.isArray(operations) || operations.length === 0) {
        throw new Error('Consul requires a nonempty wire operation array');
      }

      for (const operation of operations) {
        const op = operation.KV;
        if (
          !op ||
          typeof op.Key !== 'string' ||
          ![
            'get-or-empty',
            'check-index',
            'check-not-exists',
            'cas',
            'set',
          ].includes(op.Verb)
        ) {
          throw new Error(
            'Expected uppercase Consul wire operations: { KV: { Verb, Key } }',
          );
        }
        if (op.Verb === 'get-or-empty' && !record.consistent) {
          throw new Error('License reads must use { consistent: true }');
        }
        if (op.Verb === 'cas' || op.Verb === 'set') {
          if (
            typeof op.Value !== 'string' ||
            Buffer.from(op.Value, 'base64').toString('base64') !== op.Value
          ) {
            throw new Error('Consul transaction Value must be base64');
          }
        }
      }

      const writes = operations.filter(
        ({ KV }) => KV.Verb === 'cas' || KV.Verb === 'set',
      );
      const readonly = operations.every(({ KV }) => KV.Verb === 'get-or-empty');
      const deferredRead = readonly ? this.deferredReads.shift() : undefined;
      if (deferredRead) {
        deferredRead.started.resolve();
        await deferredRead.linearize.promise;
      }
      if (writes.length && this.beforeNextWrite) {
        const interleave = this.beforeNextWrite;
        this.beforeNextWrite = undefined;
        await interleave();
      }

      // Like txnKVS/kvsSetTxn in Consul 1.22, operations see prior staged changes,
      // but no rows are committed if any check fails. Equal value/flags are no-ops.
      const updated = new Map(this.rows);
      const index = writes.length ? ++this.revision : this.revision;
      const changes: { key: string; value: string }[] = [];
      const Results: {
        KV: {
          Key: string;
          ModifyIndex: number;
          Value: string | null;
          Flags: number;
        };
      }[] = [];
      for (const [opIndex, { KV: op }] of operations.entries()) {
        const existing = updated.get(op.Key);
        const expectedIndex = op.Index ?? 0;
        if (
          (op.Verb === 'check-index' &&
            (!existing || existing.index !== expectedIndex)) ||
          (op.Verb === 'check-not-exists' && existing) ||
          (op.Verb === 'cas' &&
            (expectedIndex === 0
              ? existing
              : !existing || existing.index !== expectedIndex))
        ) {
          const Errors = [
            { OpIndex: opIndex, What: `Index conflict: ${op.Key}` },
          ];
          throw Object.assign(new Error(Errors[0].What), {
            statusCode: 409,
            response: { statusCode: 409, body: { Errors } },
          });
        }
        if (op.Verb === 'cas' || op.Verb === 'set') {
          const value = Buffer.from(op.Value!, 'base64').toString('utf8');
          const flags = op.Flags ?? 0;
          if (
            !existing ||
            existing.value !== value ||
            existing.flags !== flags
          ) {
            updated.set(op.Key, { value, index, flags });
            changes.push({ key: op.Key, value });
          }
        }
        if (op.Verb !== 'check-not-exists') {
          const row = updated.get(op.Key);
          Results.push({
            KV: {
              Key: op.Key,
              ModifyIndex: row?.index ?? 0,
              Value:
                op.Verb === 'get-or-empty' && row
                  ? Buffer.from(row.value).toString('base64')
                  : null,
              Flags: row?.flags ?? 0,
            },
          });
        }
      }

      const fault = this.takeFault(writes.map(({ KV }) => KV.Key));
      if (fault?.mode === 'before-write') this.fail(fault);
      if (writes.length) {
        this.rows = updated;
        this.writes.push(...changes);
        record.committed = true;
        record.changedKeys = changes.map(({ key }) => key);
      }
      if (fault) this.fail(fault);

      if (deferredRead) {
        deferredRead.captured.resolve();
        await deferredRead.release.promise;
      }
      // Consul's read-only txn body Index is not a global KV revision.
      return { Results, ...(readonly ? { Index: 1 } : {}) };
    },
  };
}

export type LicenseRecord = {
  isInitialized: boolean;
  isRevoked: boolean;
  expectedNextToken: string;
  pendingNextToken: string | null;
  maxAgents: number;
  customerName: string;
  expiryDate: number;
};

function snapshot(value: unknown) {
  const copy = structuredClone(value ?? null);
  return {
    val: () => structuredClone(copy),
    exists: () => copy !== null,
  };
}

export class DurableRtdb {
  private rows: Map<string, unknown>;
  rerunWith?: LicenseRecord | null;
  readonly transactions: {
    proposals: (LicenseRecord | null | undefined)[];
    committed: boolean;
  }[] = [];

  constructor(
    private readonly licenseId: string,
    privateKey: string,
    license: LicenseRecord,
  ) {
    this.rows = new Map<string, unknown>([
      ['/system/privateKeyPem', privateKey],
      [`/licenses/${licenseId}`, structuredClone(license)],
    ]);
  }

  get license() {
    return structuredClone(
      this.rows.get(`/licenses/${this.licenseId}`),
    ) as LicenseRecord;
  }

  ref(path: string) {
    if (
      path !== '/system/privateKeyPem' &&
      path !== `/licenses/${this.licenseId}`
    ) {
      throw new Error(`Unexpected RTDB path: ${path}`);
    }
    return {
      once: async (event: string) => {
        if (event !== 'value')
          throw new Error(`Unexpected RTDB event: ${event}`);
        return snapshot(this.rows.get(path));
      },
      transaction: async (
        update: (
          data: LicenseRecord | null,
        ) => LicenseRecord | null | undefined,
      ) => {
        const record = {
          proposals: [] as (LicenseRecord | null | undefined)[],
          committed: false,
        };
        this.transactions.push(record);
        if (this.rerunWith !== undefined) {
          const stale = this.rerunWith;
          this.rerunWith = undefined;
          record.proposals.push(
            structuredClone(update(structuredClone(stale))),
          );
        }
        // Firebase may discard a proposal, and mutating an aborted copy is not a write.
        const proposal = update(
          structuredClone(this.rows.get(path)) as LicenseRecord | null,
        );
        record.proposals.push(structuredClone(proposal));
        if (proposal !== undefined) {
          this.rows.set(path, structuredClone(proposal));
          record.committed = true;
        }
        return {
          committed: record.committed,
          snapshot: snapshot(this.rows.get(path)),
        };
      },
      update: async (patch: Partial<LicenseRecord>) => {
        this.rows.set(path, {
          ...(this.rows.get(path) as LicenseRecord),
          ...structuredClone(patch),
        });
      },
    };
  }
}

export class MemoryRedis {
  private rows = new Map<string, string>();
  failPublish = false;
  readonly publications: { channel: string; message: string }[] = [];

  async set(key: string, value: string, options?: { condition?: string }) {
    if (options?.condition === 'NX' && this.rows.has(key)) return null;
    this.rows.set(key, value);
    return 'OK';
  }

  async get(key: string) {
    return this.rows.get(key) ?? null;
  }

  async del(key: string) {
    return this.rows.delete(key) ? 1 : 0;
  }

  async publish(channel: string, message: string) {
    if (this.failPublish) throw new Error('Redis notification unavailable');
    this.publications.push({ channel, message });
    return 0;
  }
}
