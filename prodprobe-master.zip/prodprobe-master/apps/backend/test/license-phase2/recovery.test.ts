import { generateKeyPairSync } from 'node:crypto';
import {
  HP_LICENCE_MEMORY_REFRESH_KEY,
  HP_DEPLOYMENT_KEYS as K,
  LicenseManager,
  HP_LICENSE_SYNC_STATUS as Status,
  syncLicenseAndSoftLimit,
} from '@hyperprobe/common';
import { TRPCError } from '@trpc/server';
import jwt from 'jsonwebtoken';
import { beforeEach, describe, expect, it, vi } from 'vitest';
import { heartbeat as centralHeartbeat } from '../../../../external/licensing-server/src/handler.js';
import { HP_LICENCE_HEARTBEAT_LOCK_KEY } from '../../src/helpers/appConstants.js';
import { performHeartbeat } from '../../src/license/heartbeat.js';
import { licenseRouter } from '../../src/license/licenseRouter.js';
import {
  readLicenseState,
  recordRevocation,
} from '../../src/license/phase2.js';
import type { Context } from '../../src/trpc.js';
import {
  DurableConsul,
  DurableRtdb,
  deferred,
  MemoryRedis,
} from './durable-fakes.js';

const services = vi.hoisted(() => ({
  consul: undefined as unknown as DurableConsul,
  db: undefined as unknown as DurableRtdb,
  url: 'https://license.phase2.invalid',
  publicKeyUrl: 'https://license.phase2.invalid/public-key.json',
  logger: { info: vi.fn(), warn: vi.fn(), error: vi.fn() },
}));

vi.mock('@hyperprobe/common', async (importOriginal) => ({
  ...(await importOriginal<
    typeof import('../../../../packages/common/src/index.js')
  >()),
  getConsul: () => services.consul,
  getLogger: () => services.logger,
}));

vi.mock('@hyperprobe/constants', async (importOriginal) => ({
  ...(await importOriginal<
    typeof import('../../../../packages/constants/index.js')
  >()),
  getLicensingServerUrl: async () => services.url,
  HYPERPROBE_LICENSING_PUBLIC_KEY_URL: services.publicKeyUrl,
}));

vi.mock('firebase-admin', () => ({
  initializeApp: vi.fn(),
  credential: { cert: vi.fn(() => ({})) },
  database: () => services.db,
}));

vi.mock('dotenv', () => ({ config: vi.fn(() => ({ parsed: {} })) }));

const { privateKey, publicKey } = generateKeyPairSync('ec', {
  namedCurve: 'prime256v1',
  privateKeyEncoding: { type: 'pkcs8', format: 'pem' },
  publicKeyEncoding: { type: 'spki', format: 'pem' },
});
const untrustedKey = generateKeyPairSync('ec', {
  namedCurve: 'prime256v1',
}).privateKey;
const rotatedKeys = generateKeyPairSync('ec', {
  namedCurve: 'prime256v1',
  privateKeyEncoding: { type: 'pkcs8', format: 'pem' },
  publicKeyEncoding: { type: 'spki', format: 'pem' },
});
const licenseId = 'phase2-regression-license';
const T0 = 'initialized-predecessor-T0';
const startedAt = Date.now();
const expiry = Math.floor(startedAt / 1000) + 30 * 24 * 60 * 60;
const originalPayload = {
  licenseId,
  max_agents: 12,
  customerName: 'Phase2 regression',
  last_heartbeat_timestamp: startedAt - 2 * 24 * 60 * 60 * 1000,
  exp: expiry,
};
const J0 = jwt.sign(originalPayload, privateKey, { algorithm: 'ES256' });
const otherJwt = jwt.sign(
  { ...originalPayload, jti: 'another-captured-source' },
  privateKey,
  {
    algorithm: 'ES256',
  },
);
const malformedJsonJwt = [
  Buffer.from(JSON.stringify({ alg: 'ES256', typ: 'JWT' })).toString(
    'base64url',
  ),
  Buffer.from('not-json').toString('base64url'),
  'c2ln',
].join('.');

type RequestBody = {
  phase: number;
  licenseId: string;
  jwt: string;
  nextToken: string;
};
type ResponseBody = {
  nextToken?: string;
  jwt?: string;
  limitUpdated?: boolean;
  error?: string;
};
type Exchange = {
  request: RequestBody;
  durable: Record<string, string>;
  memory: { jwt: string | null; nextToken: string | null; hint: Status };
  response?: { status: number; body: ResponseBody };
};

let consul: DurableConsul;
let db: DurableRtdb;
let redis: MemoryRedis;
let manager: LicenseManager;
let context: Context;
let caller: ReturnType<typeof licenseRouter.createCaller>;
let exchanges: Exchange[];
let onExchange: ((exchange: Exchange) => void | Promise<void>) | undefined;
let transportFault:
  | 'drop-request'
  | 'drop-response'
  | 'bad-signature'
  | undefined;
let publicKeyFetches: number;

beforeEach(() => {
  consul = new DurableConsul({
    [K.HP_LICENSE_JWT]: J0,
    [K.NEXT_TOKEN]: T0,
    [K.HP_LICENSE_SYNC_STATUS]: Status.COURIER_REQUIRED,
    [K.HP_LICENSE_ID]: licenseId,
    LICENSE_PUBLIC_KEY: publicKey,
  });
  db = new DurableRtdb(licenseId, privateKey, {
    isInitialized: true,
    isRevoked: false,
    expectedNextToken: T0,
    pendingNextToken: null,
    maxAgents: 20,
    customerName: originalPayload.customerName,
    expiryDate: expiry * 1000,
  });
  redis = new MemoryRedis();
  services.consul = consul;
  services.db = db;
  Reflect.deleteProperty(LicenseManager, 'instance');
  manager = LicenseManager.getInstance();
  manager.setPublicKey(publicKey);
  manager.updateState(J0, T0);
  manager.setHintStatus(Status.COURIER_REQUIRED);
  expect(manager.getStatus()).toBe(Status.SYNCED);
  context = {
    redisClient: redis,
    logger: services.logger,
    user: {
      userId: 'phase2-admin',
      email: 'phase2@example.invalid',
      permissions: { isAdmin: true, permissions: {} },
    },
  } as unknown as Context;
  caller = licenseRouter.createCaller(context);
  exchanges = [];
  onExchange = undefined;
  transportFault = undefined;
  publicKeyFetches = 0;

  vi.stubEnv('FIREBASE_PROJECT_ID', 'phase2-in-memory');
  vi.stubEnv('FIREBASE_CLIENT_EMAIL', 'phase2@example.invalid');
  vi.stubEnv('FIREBASE_PRIVATE_KEY', 'unused-by-stubbed-credential');
  vi.stubEnv('FIREBASE_DATABASE_URL', 'https://rtdb.phase2.invalid');
  vi.stubGlobal(
    'fetch',
    vi.fn(async (input: string | URL | Request, init?: RequestInit) => {
      const url =
        typeof input === 'string'
          ? input
          : input instanceof URL
            ? input.href
            : input.url;
      if (url === services.publicKeyUrl) {
        publicKeyFetches++;
        return Response.json(publicKey);
      }
      if (url !== `${services.url}/api/heartbeat`) {
        throw new Error(`Unexpected network request: ${url}`);
      }
      const request = JSON.parse(String(init?.body)) as RequestBody;
      const activeManager = LicenseManager.getInstance();
      const exchange: Exchange = {
        request,
        durable: consul.snapshot(),
        memory: {
          jwt: activeManager.getRawJwt(),
          nextToken: activeManager.getNextToken(),
          hint: activeManager.getHintStatus(),
        },
      };
      exchanges.push(exchange);
      await onExchange?.(exchange);
      if (request.phase === 2 && transportFault === 'drop-request') {
        transportFault = undefined;
        throw new TypeError('Phase 2 request lost before central handler');
      }

      const result = await centralHeartbeat({ body: JSON.stringify(request) });
      const body = JSON.parse(result.body) as ResponseBody;
      exchange.response = { status: result.statusCode, body };
      await onExchange?.(exchange);
      if (request.phase === 2 && transportFault === 'drop-response') {
        transportFault = undefined;
        throw new TypeError('Phase 2 response lost after central commit');
      }
      if (request.phase === 2 && transportFault === 'bad-signature') {
        transportFault = undefined;
        const forged = jwt.sign(jwt.decode(body.jwt!) as object, untrustedKey, {
          algorithm: 'ES256',
        });
        return Response.json(
          { ...body, jwt: forged },
          { status: result.statusCode },
        );
      }
      return new Response(JSON.stringify(body), {
        status: exchange.response.status,
        headers: result.headers,
      });
    }),
  );
});

async function central(phase: 1 | 2, nextToken: string, token = J0) {
  const result = await centralHeartbeat({
    body: JSON.stringify({ phase, licenseId, jwt: token, nextToken }),
  });
  return {
    status: result.statusCode,
    body: JSON.parse(result.body) as ResponseBody,
  };
}

async function phaseOne() {
  const result = await central(1, T0);
  expect(result).toEqual({
    status: 200,
    body: { nextToken: expect.any(String) },
  });
  expect(result.body.nextToken).not.toBe(T0);
  return result.body.nextToken!;
}

async function phaseTwo(candidate: string) {
  const result = await central(2, candidate);
  expect(result).toEqual({
    status: 200,
    body: { jwt: expect.any(String), limitUpdated: true },
  });
  expectValidJwt(result.body.jwt!);
  return result.body.jwt!;
}

function expectValidJwt(token: string) {
  expect(jwt.decode(token, { complete: true })?.header.alg).toBe('ES256');
  expect(jwt.verify(token, publicKey, { algorithms: ['ES256'] })).toMatchObject(
    {
      licenseId,
      max_agents: 20,
      customerName: originalPayload.customerName,
      exp: expiry,
      last_heartbeat_timestamp: expect.any(Number),
    },
  );
  const decoded = jwt.decode(token) as { last_heartbeat_timestamp: number };
  expect(decoded.last_heartbeat_timestamp).toBeGreaterThanOrEqual(startedAt);
  expect(decoded.last_heartbeat_timestamp).toBeLessThanOrEqual(Date.now());
}

function expectPrepared(candidate: string, hint = Status.COURIER_REQUIRED) {
  expect(consul.value(K.HP_LICENSE_JWT)).toBe(J0);
  expect(consul.value(K.NEXT_TOKEN)).toBe(candidate);
  expect(consul.value(K.HP_LICENSE_SYNC_STATUS)).toBe(hint);
  expect(manager.getRawJwt()).toBe(J0);
  expect(manager.getNextToken()).toBe(candidate);
  expect(manager.getHintStatus()).toBe(hint);
  expect(db.license.isRevoked).toBe(false);
}

function expectPreparedBeforePhaseTwo() {
  const requests = exchanges.filter(({ request }) => request.phase === 2);
  expect(requests.length).toBeGreaterThan(0);
  for (const exchange of requests) {
    expect(exchange.request).toEqual({
      phase: 2,
      licenseId,
      jwt: J0,
      nextToken: expect.any(String),
    });
    expect(exchange.durable).toMatchObject({
      [K.HP_LICENSE_JWT]: J0,
      [K.NEXT_TOKEN]: exchange.request.nextToken,
      [K.HP_LICENSE_SYNC_STATUS]: Status.COURIER_REQUIRED,
    });
    expect(exchange.memory).toEqual({
      jwt: J0,
      nextToken: exchange.request.nextToken,
      hint: Status.COURIER_REQUIRED,
    });
  }
}

async function expectSynced() {
  const token = consul.value(K.HP_LICENSE_JWT)!;
  expectValidJwt(token);
  expect(manager.getRawJwt()).toBe(token);
  expect(manager.getNextToken()).toBe(consul.value(K.NEXT_TOKEN));
  expect(manager.getPublicKey()).toBe(consul.value('LICENSE_PUBLIC_KEY'));
  expect(manager.getHintStatus()).toBe(Status.SYNCED);
  expect(manager.getStatus()).toBe(Status.SYNCED);
  expect(consul.value(K.HP_LICENSE_SYNC_STATUS)).toBe(Status.SYNCED);
  expect(db.license).toMatchObject({
    expectedNextToken: consul.value(K.NEXT_TOKEN),
    pendingNextToken: null,
    isRevoked: false,
  });
  expect(await redis.get(HP_LICENCE_HEARTBEAT_LOCK_KEY)).toBeNull();
  expect(redis.publications).toContainEqual({
    channel: HP_LICENCE_MEMORY_REFRESH_KEY,
    message: '1',
  });
}

describe('Consul 1.22 KV contract in the durable model', () => {
  it.each([
    'kv.set',
    'set',
    'cas',
  ] as const)('preserves the index for equal value/flags and changes it for flags-only writes (%s)', async (verb) => {
    const Key = K.HP_LICENSE_SYNC_STATUS;
    await consul.kv.set(Key, Status.REVOKED);
    const writeFrom = consul.writes.length;
    const initialIndex = consul.index(Key);
    const write = (Flags?: number) =>
      verb === 'kv.set'
        ? consul.kv.set(Key, Status.REVOKED, { flags: Flags })
        : consul.transaction.create([
            {
              KV: {
                Verb: verb,
                Key,
                Index: consul.index(Key),
                Value: Buffer.from(Status.REVOKED).toString('base64'),
                Flags,
              },
            },
          ]);

    await write();
    expect(consul.index(Key)).toBe(initialIndex);
    expect(consul.writes).toHaveLength(writeFrom);
    const flags = 2 ** 40 + 6;
    await write(flags);
    const changedIndex = consul.index(Key);
    expect(changedIndex).toBeGreaterThan(initialIndex);
    await write(flags);
    expect(consul.index(Key)).toBe(changedIndex);
    expect(await consul.kv.get(Key)).toMatchObject({
      Value: Status.REVOKED,
      Flags: flags,
      ModifyIndex: changedIndex,
    });
    expect(consul.writes.slice(writeFrom)).toEqual([
      { key: Key, value: Status.REVOKED },
    ]);
    if (verb !== 'kv.set') {
      expect(consul.transactions.at(-1)).toMatchObject({
        committed: true,
        changedKeys: [],
      });
    }
    await write();
    expect(consul.flags(Key)).toBe(0);
    expect(consul.index(Key)).toBeGreaterThan(changedIndex);
  });

  it('commits only changed rows and retains indices for no-op CASes in the same transaction', async () => {
    const jwtIndex = consul.index(K.HP_LICENSE_JWT);
    await consul.transaction.create([
      {
        KV: {
          Verb: 'cas',
          Key: K.HP_LICENSE_JWT,
          Index: jwtIndex,
          Value: Buffer.from(J0).toString('base64'),
        },
      },
      {
        KV: {
          Verb: 'cas',
          Key: K.NEXT_TOKEN,
          Index: consul.index(K.NEXT_TOKEN),
          Value: Buffer.from('changed-token').toString('base64'),
        },
      },
    ]);
    expect(consul.index(K.HP_LICENSE_JWT)).toBe(jwtIndex);
    expect(consul.index(K.NEXT_TOKEN)).toBeGreaterThan(jwtIndex);
    expect(consul.transactions.at(-1)).toMatchObject({
      committed: true,
      changedKeys: [K.NEXT_TOKEN],
    });
    expect(consul.writes).toEqual([
      { key: K.NEXT_TOKEN, value: 'changed-token' },
    ]);
  });

  it('requires check-not-exists for absence, while CAS index zero creates a key', async () => {
    const store = new DurableConsul({});
    const Key = K.HP_LICENSE_SYNC_STATUS;
    const creation = {
      KV: {
        Verb: 'cas' as const,
        Key,
        Index: 0,
        Value: Buffer.from(Status.REVOKED).toString('base64'),
      },
    };
    await expect(
      store.transaction.create([
        { KV: { Verb: 'check-index', Key, Index: 0 } },
      ]),
    ).rejects.toMatchObject({ statusCode: 409 });
    await expect(
      store.transaction.create([{ KV: { Verb: 'check-not-exists', Key } }]),
    ).resolves.toEqual({ Results: [] });
    await store.transaction.create([
      { KV: { Verb: 'check-not-exists', Key } },
      creation,
    ]);
    expect(store.value(Key)).toBe(Status.REVOKED);
    expect(store.index(Key)).toBeGreaterThan(0);
    await expect(store.transaction.create([creation])).rejects.toMatchObject({
      statusCode: 409,
    });
    await expect(
      store.transaction.create([{ KV: { Verb: 'check-not-exists', Key } }]),
    ).rejects.toMatchObject({ statusCode: 409 });
  });

  it.each([
    'concurrent creation',
    'earlier staged creation',
  ])('rejects absence checks after %s without partial writes', async (kind) => {
    const store = new DurableConsul({});
    const Key = K.HP_LICENSE_SYNC_STATUS;
    const creation = {
      KV: {
        Verb: 'cas' as const,
        Key,
        Index: 0,
        Value: Buffer.from(Status.SYNCED).toString('base64'),
      },
    };
    const check = { KV: { Verb: 'check-not-exists' as const, Key } };
    if (kind === 'concurrent creation')
      store.beforeNextWrite = () => store.kv.set(Key, Status.REVOKED);
    await expect(
      store.transaction.create(
        kind === 'concurrent creation' ? [check, creation] : [creation, check],
      ),
    ).rejects.toMatchObject({ statusCode: 409 });
    expect(store.snapshot()).toEqual(
      kind === 'concurrent creation' ? { [Key]: Status.REVOKED } : {},
    );
    expect(store.transactions.at(-1)).toMatchObject({
      committed: false,
      changedKeys: [],
    });
  });
});

describe('narrow Phase 2 recovery through the real backend and central handler', () => {
  it('keeps the captured JWT identity when a microtask hydrates different RAM before heartbeat resumes', async () => {
    const ramJwt = jwt.sign(
      { ...originalPayload, licenseId: 'ram-only-license' },
      privateKey,
      { algorithm: 'ES256' },
    );
    const before = consul.snapshot();
    const publishSnapshot = manager.publishSnapshot.bind(manager);
    vi.spyOn(manager, 'publishSnapshot').mockImplementationOnce((...args) => {
      const admitted = publishSnapshot(...args);
      queueMicrotask(() => manager.updateState(ramJwt, 'ram-only-token'));
      return admitted;
    });

    const result = await performHeartbeat(context.redisClient);

    expect(exchanges[0].durable).toEqual(before);
    expect(exchanges[0].memory).toEqual({
      jwt: ramJwt,
      nextToken: 'ram-only-token',
      hint: Status.COURIER_REQUIRED,
    });
    expect(exchanges.map(({ request }) => request)).toEqual([
      { phase: 1, licenseId, jwt: J0, nextToken: T0 },
      {
        phase: 2,
        licenseId,
        jwt: J0,
        nextToken: exchanges[0].response?.body.nextToken,
      },
    ]);
    expect(result.success).toBe(true);
    expectPreparedBeforePhaseTwo();
    await expectSynced();
  });

  it('never sends Phase 2 when candidate persistence fails before writing', async () => {
    consul.fault = { key: K.NEXT_TOKEN, mode: 'before-write' };
    const result = await performHeartbeat(context.redisClient);

    expect(result.success).toBe(false);
    expect(exchanges.map(({ request }) => request.phase)).toEqual([1]);
    expect(exchanges[0].request).toEqual({
      phase: 1,
      licenseId,
      jwt: J0,
      nextToken: T0,
    });
    expect(exchanges[0].response).toEqual({
      status: 200,
      body: { nextToken: expect.any(String) },
    });
    expect(consul.fault).toBeUndefined();
    expectPrepared(T0);
    expect(db.license.expectedNextToken).toBe(T0);
    expect(db.license.pendingNextToken).toBe(
      exchanges[0].response!.body.nextToken,
    );
    expect(await redis.get(HP_LICENCE_HEARTBEAT_LOCK_KEY)).toBeNull();
  });

  it('prepares through the router idempotently and reconciles a lost Consul write acknowledgement', async () => {
    const candidate = await phaseOne();
    const jwtIndex = consul.index(K.HP_LICENSE_JWT);
    const tokenIndex = consul.index(K.NEXT_TOKEN);
    consul.fault = { key: K.NEXT_TOKEN, mode: 'ack-loss' };
    const input = { jwt: J0, previousNextToken: T0, nextToken: candidate };

    await expect(caller.prepareRelay(input)).resolves.toEqual({
      success: true,
    });
    expectPrepared(candidate);
    expect(consul.fault).toBeUndefined();
    const committedAt = consul.transactions.findIndex(
      ({ committed }) => committed,
    );
    expect(committedAt).toBeGreaterThanOrEqual(0);
    expect(
      consul.transactions
        .slice(committedAt + 1)
        .some(
          ({ operations, consistent }) =>
            consistent &&
            operations.every(({ KV }) => KV.Verb === 'get-or-empty'),
        ),
    ).toBe(true);
    const preparedIndex = consul.index(K.NEXT_TOKEN);
    await expect(caller.prepareRelay(input)).resolves.toEqual({
      success: true,
    });
    expectPrepared(candidate);
    await expect(
      caller.prepareRelay({ ...input, jwt: otherJwt }),
    ).rejects.toThrow();
    expect(consul.index(K.NEXT_TOKEN)).toBe(preparedIndex);
    expect(consul.index(K.HP_LICENSE_JWT)).toBe(jwtIndex);

    const reads = consul.transactions.filter(({ operations }) =>
      operations.every(({ KV }) => KV.Verb === 'get-or-empty'),
    );
    expect(reads.length).toBeGreaterThanOrEqual(2);
    for (const read of reads) {
      expect(read.consistent).toBe(true);
      expect(read.operations.map(({ KV }) => KV.Key).sort()).toEqual(
        [
          K.HP_LICENSE_JWT,
          K.NEXT_TOKEN,
          'LICENSE_PUBLIC_KEY',
          K.HP_LICENSE_SYNC_STATUS,
          K.HP_LICENSE_ID,
        ].sort(),
      );
    }
    expect(
      consul.transactions.find(({ committed }) => committed)?.operations,
    ).toEqual(
      expect.arrayContaining([
        { KV: { Verb: 'check-index', Key: K.HP_LICENSE_JWT, Index: jwtIndex } },
        {
          KV: {
            Verb: 'cas',
            Key: K.NEXT_TOKEN,
            Index: tokenIndex,
            Value: Buffer.from(candidate).toString('base64'),
          },
        },
      ]),
    );
  });

  it('rejects captured JWT/predecessor conflicts and index races without overwriting the durable winner', async () => {
    const candidate = await phaseOne();
    const initial = consul.snapshot();
    await expect(
      caller.prepareRelay({
        jwt: otherJwt,
        previousNextToken: T0,
        nextToken: candidate,
      }),
    ).rejects.toThrow();
    await expect(
      caller.prepareRelay({
        jwt: J0,
        previousNextToken: 'wrong-predecessor',
        nextToken: candidate,
      }),
    ).rejects.toThrow();
    expect(consul.snapshot()).toEqual(initial);

    consul.beforeNextWrite = () => consul.kv.set(K.HP_LICENSE_JWT, otherJwt);
    await expect(
      caller.prepareRelay({
        jwt: J0,
        previousNextToken: T0,
        nextToken: candidate,
      }),
    ).rejects.toThrow();
    expect(consul.beforeNextWrite).toBeUndefined();
    expect(consul.value(K.HP_LICENSE_JWT)).toBe(otherJwt);
    expect(consul.value(K.NEXT_TOKEN)).toBe(T0);

    consul.beforeNextWrite = () =>
      consul.kv.set(K.NEXT_TOKEN, 'concurrent-candidate');
    await expect(
      caller.prepareRelay({
        jwt: otherJwt,
        previousNextToken: T0,
        nextToken: candidate,
      }),
    ).rejects.toThrow();
    expect(consul.beforeNextWrite).toBeUndefined();
    expect(consul.value(K.HP_LICENSE_JWT)).toBe(otherJwt);
    expect(consul.value(K.NEXT_TOKEN)).toBe('concurrent-candidate');
    expect(consul.writes).not.toContainEqual({
      key: K.NEXT_TOKEN,
      value: candidate,
    });
    expect(db.license.isRevoked).toBe(false);
  });

  it('recovers a lost Phase 2 request using persisted T1 even when RAM still contains T0', async () => {
    transportFault = 'drop-request';
    expect((await performHeartbeat(context.redisClient)).success).toBe(false);
    const candidate = exchanges[0].response!.body.nextToken!;
    expectPrepared(candidate);
    expect(db.license).toMatchObject({
      expectedNextToken: T0,
      pendingNextToken: candidate,
      isRevoked: false,
    });
    expect(exchanges[1].response).toBeUndefined();

    manager.updateState(J0, T0);
    expect((await performHeartbeat(context.redisClient)).success).toBe(true);
    expect(exchanges.map(({ request }) => request.phase)).toEqual([1, 2, 1, 2]);
    expect(exchanges[2].request).toEqual({
      phase: 1,
      licenseId,
      jwt: J0,
      nextToken: candidate,
    });
    expect(exchanges[2].response).toEqual({
      status: 200,
      body: { nextToken: candidate },
    });
    expect(exchanges[3].response).toEqual({
      status: 200,
      body: { jwt: expect.any(String), limitUpdated: true },
    });
    expectPreparedBeforePhaseTwo();
    await expectSynced();
  });

  it('recovers a lost committed Phase 2 response after a manager restart without injecting a retry token', async () => {
    transportFault = 'drop-response';
    expect((await performHeartbeat(context.redisClient)).success).toBe(false);
    const candidate = exchanges[0].response!.body.nextToken!;
    expectPrepared(candidate);
    expect(exchanges[1].response?.status).toBe(200);
    expectValidJwt(exchanges[1].response!.body.jwt!);
    expect(db.license).toMatchObject({
      expectedNextToken: candidate,
      pendingNextToken: null,
      isRevoked: false,
    });

    Reflect.deleteProperty(LicenseManager, 'instance');
    manager = LicenseManager.getInstance();
    expect(manager.getRawJwt()).toBeNull();
    expect(manager.getLicenseId()).toBeNull();
    expect((await performHeartbeat(context.redisClient)).success).toBe(true);
    expect(exchanges[2].request).toEqual({
      phase: 1,
      licenseId,
      jwt: J0,
      nextToken: candidate,
    });
    expect(exchanges[2].response!.body.nextToken).not.toBe(candidate);
    expectPreparedBeforePhaseTwo();
    await expectSynced();

    Reflect.deleteProperty(LicenseManager, 'instance');
    manager = LicenseManager.getInstance();
    await syncLicenseAndSoftLimit(consul, manager);
    expect(manager.getRawJwt()).toBe(consul.value(K.HP_LICENSE_JWT));
    expect(manager.getNextToken()).toBe(consul.value(K.NEXT_TOKEN));
    expect(manager.getStatus()).toBe(Status.SYNCED);
  });

  it('retains the prepared pair after a final Consul JWT write failure, then heartbeats from that pair', async () => {
    consul.fault = { key: K.HP_LICENSE_JWT, mode: 'before-write' };
    expect((await performHeartbeat(context.redisClient)).success).toBe(false);
    const candidate = exchanges[0].response!.body.nextToken!;
    expect(consul.fault).toBeUndefined();
    expectPrepared(candidate);
    expect(db.license.expectedNextToken).toBe(candidate);
    expect(consul.writes).not.toContainEqual({ key: K.NEXT_TOKEN, value: T0 });
    expectPreparedBeforePhaseTwo();

    expect((await performHeartbeat(context.redisClient)).success).toBe(true);
    expect(exchanges[2].request.nextToken).toBe(candidate);
    await expectSynced();
  });

  it('does not roll back a final Consul transaction that committed before losing its acknowledgement', async () => {
    consul.fault = { key: K.HP_LICENSE_JWT, mode: 'ack-loss' };
    await performHeartbeat(context.redisClient);
    const candidate = exchanges[0].response!.body.nextToken!;
    const committedJwt = exchanges[1].response!.body.jwt!;
    expect(consul.fault).toBeUndefined();
    expect(consul.value(K.HP_LICENSE_JWT)).toBe(committedJwt);
    expect(consul.value(K.NEXT_TOKEN)).toBe(candidate);
    expect(manager.getNextToken()).toBe(candidate);
    expect(consul.writes).not.toContainEqual({ key: K.NEXT_TOKEN, value: T0 });
    expect(consul.writes).not.toContainEqual({
      key: K.HP_LICENSE_JWT,
      value: J0,
    });
    expect(db.license.isRevoked).toBe(false);

    expect((await performHeartbeat(context.redisClient)).success).toBe(true);
    expect(exchanges[2].request).toEqual({
      phase: 1,
      licenseId,
      jwt: committedJwt,
      nextToken: candidate,
    });
    await expectSynced();
  });

  it('keeps T1 when the returned ES256 JWT fails verification with both local and fetched public keys', async () => {
    transportFault = 'bad-signature';
    expect((await performHeartbeat(context.redisClient)).success).toBe(false);
    const candidate = exchanges[0].response!.body.nextToken!;
    expectPrepared(candidate);
    expect(publicKeyFetches).toBe(1);
    expect(consul.value('LICENSE_PUBLIC_KEY')).toBe(publicKey);
    expect(db.license.expectedNextToken).toBe(candidate);
    expectPreparedBeforePhaseTwo();

    expect((await performHeartbeat(context.redisClient)).success).toBe(true);
    expect(exchanges[2].request.nextToken).toBe(candidate);
    await expectSynced();
  });

  it('does not undo a finalized pair when Redis refresh notification fails', async () => {
    redis.failPublish = true;
    await performHeartbeat(context.redisClient);
    const candidate = exchanges[0].response!.body.nextToken!;
    const committedJwt = exchanges[1].response!.body.jwt!;
    expect(consul.value(K.HP_LICENSE_JWT)).toBe(committedJwt);
    expect(consul.value(K.NEXT_TOKEN)).toBe(candidate);
    expect(manager.getRawJwt()).toBe(committedJwt);
    expect(manager.getNextToken()).toBe(candidate);
    expect(consul.writes).not.toContainEqual({ key: K.NEXT_TOKEN, value: T0 });
    expect(db.license.isRevoked).toBe(false);
    expect(await redis.get(HP_LICENCE_HEARTBEAT_LOCK_KEY)).toBeNull();

    redis.failPublish = false;
    expect((await performHeartbeat(context.redisClient)).success).toBe(true);
    expect(exchanges[2].request.nextToken).toBe(candidate);
    await expectSynced();
  });

  it('submits through another replica without a stale-RAM rollback on atomic hint or public-key failure', async () => {
    const candidate = await phaseOne();
    await caller.prepareRelay({
      jwt: J0,
      previousNextToken: T0,
      nextToken: candidate,
    });
    const newJwt = await phaseTwo(candidate);
    const prepared = consul.snapshot();
    const firstReplica = manager;
    Reflect.deleteProperty(LicenseManager, 'instance');
    manager = LicenseManager.getInstance();
    manager.setPublicKey(publicKey);
    manager.updateState(J0, T0);
    manager.setHintStatus(Status.COURIER_REQUIRED);
    const otherCaller = licenseRouter.createCaller(context);
    // A different valid PEM encoding exercises the optional key write without rotating the signing key.
    const replacementPublicKey = publicKey.replace(
      /([A-Za-z0-9+/=])\n(?=[A-Za-z0-9+/=])/g,
      '$1',
    );
    const input = {
      jwt: newJwt,
      preparedFrom: J0,
      nextToken: candidate,
      publicKey: replacementPublicKey,
    };
    expect(manager).not.toBe(firstReplica);

    for (const key of [K.HP_LICENSE_SYNC_STATUS, 'LICENSE_PUBLIC_KEY']) {
      manager.updateState(J0, T0);
      consul.fault = { key, mode: 'before-write' };
      await expect(otherCaller.submitRelay(input)).rejects.toThrow();
      expect(consul.fault).toBeUndefined();
      expect(consul.snapshot()).toEqual(prepared);
      expectPrepared(candidate);
      expect(consul.writes).not.toContainEqual({
        key: K.NEXT_TOKEN,
        value: T0,
      });
      expect(db.license.isRevoked).toBe(false);
    }

    manager.updateState(J0, T0);
    await expect(otherCaller.getDeploymentConfig()).resolves.toEqual({
      licenseId,
      jwt: J0,
      nextToken: candidate,
      syncStatusIndex: consul.index(K.HP_LICENSE_SYNC_STATUS),
    });
    await expect(otherCaller.submitRelay(input)).resolves.toEqual({
      success: true,
    });
    expect(consul.value(K.HP_LICENSE_JWT)).toBe(newJwt);
    expect(consul.value('LICENSE_PUBLIC_KEY')).toBe(input.publicKey);
    expect(consul.value(K.HP_LICENSE_ID)).toBe(licenseId);
    await expectSynced();
  });

  it.each([
    ['malformed', 'not-a-jwt'],
    ['invalid JSON', malformedJsonJwt],
  ])('rejects a %s preparedFrom without changing the prepared pair', async (_kind, preparedFrom) => {
    const candidate = await phaseOne();
    await caller.prepareRelay({
      jwt: J0,
      previousNextToken: T0,
      nextToken: candidate,
    });
    const input = {
      jwt: await phaseTwo(candidate),
      nextToken: candidate,
      preparedFrom,
    };
    const before = consul.snapshot();
    const writes = structuredClone(consul.writes);
    const publications = structuredClone(redis.publications);
    const centralBefore = db.license;

    await expect(caller.submitRelay(input)).rejects.toMatchObject({
      code: 'CONFLICT',
    });

    expectPrepared(candidate);
    expect(consul.snapshot()).toEqual(before);
    expect(consul.writes).toEqual(writes);
    expect(redis.publications).toEqual(publications);
    expect(db.license).toEqual(centralBefore);
    expect(fetch).not.toHaveBeenCalled();
  });

  it('requires the persisted J0/T1 pair for prepared submit and cannot overwrite a concurrent prepared successor', async () => {
    const candidate = await phaseOne();
    const newJwt = await phaseTwo(candidate);
    manager.updateState(J0, candidate);
    const initial = consul.snapshot();
    await expect(
      caller.submitRelay({
        jwt: newJwt,
        preparedFrom: J0,
        nextToken: candidate,
      }),
    ).rejects.toThrow();
    expect(consul.snapshot()).toEqual(initial);

    await caller.prepareRelay({
      jwt: J0,
      previousNextToken: T0,
      nextToken: candidate,
    });
    const prepared = consul.snapshot();
    await expect(
      caller.submitRelay({
        jwt: newJwt,
        preparedFrom: otherJwt,
        nextToken: candidate,
      }),
    ).rejects.toThrow();
    await expect(
      caller.submitRelay({
        jwt: newJwt,
        preparedFrom: J0,
        nextToken: 'not-the-prepared-candidate',
      }),
    ).rejects.toThrow();
    expect(consul.snapshot()).toEqual(prepared);

    const successor = await central(1, candidate);
    expect(successor.status).toBe(200);
    expect(successor.body.nextToken).toEqual(expect.any(String));
    expect(successor.body.nextToken).not.toBe(candidate);
    consul.beforeNextWrite = () =>
      caller.prepareRelay({
        jwt: J0,
        previousNextToken: candidate,
        nextToken: successor.body.nextToken!,
      });
    await expect(
      caller.submitRelay({
        jwt: newJwt,
        preparedFrom: J0,
        nextToken: candidate,
      }),
    ).rejects.toThrow();
    expect(consul.beforeNextWrite).toBeUndefined();
    expectPrepared(successor.body.nextToken!);

    expect((await performHeartbeat(context.redisClient)).success).toBe(true);
    expect(exchanges[0].request).toEqual({
      phase: 1,
      licenseId,
      jwt: J0,
      nextToken: successor.body.nextToken,
    });
    await expectSynced();
  });

  it('returns a signed JWT without committing a legacy duplicate Phase 2 when no token is pending', async () => {
    const candidate = await phaseOne();
    await phaseTwo(candidate);
    const before = db.license;
    expect(before).toMatchObject({
      expectedNextToken: candidate,
      pendingNextToken: null,
      isRevoked: false,
    });
    const duplicate = await central(2, candidate);

    expect(duplicate).toEqual({
      status: 200,
      body: { jwt: expect.any(String), limitUpdated: true },
    });
    expectValidJwt(duplicate.body.jwt!);
    expect(db.license).toEqual(before);
    expect(db.transactions.at(-1)).toEqual({
      proposals: [undefined],
      committed: false,
    });
  });

  it('revokes a legacy duplicate Phase 2 while retaining the expected and newer pending tokens', async () => {
    const candidate = await phaseOne();
    const newJwt = await phaseTwo(candidate);
    const next = await central(1, candidate, newJwt);
    expect(next).toEqual({
      status: 200,
      body: { nextToken: expect.any(String) },
    });
    expect(next.body.nextToken).not.toBe(candidate);
    const before = db.license;
    expect(before).toMatchObject({
      expectedNextToken: candidate,
      pendingNextToken: next.body.nextToken,
      isRevoked: false,
    });
    const duplicate = await central(2, candidate);

    expect(duplicate).toEqual({
      status: 403,
      body: { error: 'Handshake failed. License revoked.' },
    });
    expect(duplicate.body).not.toHaveProperty('jwt');
    expect(db.license).toEqual({ ...before, isRevoked: true });
    expect(db.transactions.at(-1)).toEqual({
      proposals: [db.license],
      committed: true,
    });
  });

  it('still revokes a genuinely mismatched Phase 2 token', async () => {
    const candidate = await phaseOne();
    const result = await central(2, 'neither-expected-nor-pending');

    expect(result.status).toBe(403);
    expect(result.body).not.toHaveProperty('jwt');
    expect(db.license).toMatchObject({
      isRevoked: true,
      expectedNextToken: T0,
      pendingNextToken: candidate,
    });
    expect(db.transactions.at(-1)?.committed).toBe(true);
  });

  it('returns a legacy false 403 after discarding a stale Phase 1 expected-token proposal', async () => {
    const before = db.license;
    const stale = {
      ...before,
      expectedNextToken: 'stale-cache-predecessor',
    };
    db.rerunWith = stale;
    const result = await central(1, T0);

    expect(result).toEqual({
      status: 403,
      body: { error: 'Clone detected. License revoked.' },
    });
    expect(db.rerunWith).toBeUndefined();
    expect(db.license).toEqual({
      ...before,
      pendingNextToken: expect.any(String),
    });
    expect(db.license.pendingNextToken).not.toBe(T0);
    expect(db.transactions).toEqual([
      {
        proposals: [{ ...stale, isRevoked: true }, db.license],
        committed: true,
      },
    ]);
  });

  it('returns a legacy false 403 after discarding a stale Phase 2 pending-token proposal', async () => {
    const candidate = await phaseOne();
    const before = db.license;
    const stale = { ...before, pendingNextToken: 'stale-cache-pending' };
    db.rerunWith = stale;
    const result = await central(2, candidate);

    expect(result).toEqual({
      status: 403,
      body: { error: 'Handshake failed. License revoked.' },
    });
    expect(result.body).not.toHaveProperty('jwt');
    expect(db.rerunWith).toBeUndefined();
    expect(db.license).toEqual({
      ...before,
      isRevoked: false,
      expectedNextToken: candidate,
      pendingNextToken: null,
    });
    expect(db.transactions).toHaveLength(2);
    expect(db.transactions[1]).toEqual({
      proposals: [{ ...stale, isRevoked: true }, db.license],
      committed: true,
    });
  });
});

describe('revision-fenced recovery of a stale local REVOKED hint', () => {
  async function prepareCourier() {
    const configuration = await caller.getDeploymentConfig();
    const first = await central(
      1,
      configuration.nextToken!,
      configuration.jwt!,
    );
    expect(first.status).toBe(200);
    const nextToken = first.body.nextToken!;
    await caller.prepareRelay({
      jwt: configuration.jwt!,
      previousNextToken: configuration.nextToken!,
      nextToken,
      syncStatusIndex: configuration.syncStatusIndex,
    });
    return {
      preparedFrom: configuration.jwt!,
      nextToken,
      syncStatusIndex: configuration.syncStatusIndex,
    };
  }

  describe.each(['direct', 'report'])('%s revocation events', (mode) => {
    it.each([
      0,
      1,
      2 ** 40 + 6,
      Number.MAX_SAFE_INTEGER,
    ])('toggles only flag bit zero and fences old completion on every REVOKED event (flags %s)', async (initialFlags) => {
      await consul.kv.set(K.HP_LICENSE_SYNC_STATUS, Status.REVOKED, {
        flags: initialFlags,
      });
      const prepared = await prepareCourier();
      const input = { ...prepared, jwt: await phaseTwo(prepared.nextToken) };
      if (mode === 'direct')
        await db.ref(`/licenses/${licenseId}`).update({ isRevoked: true });
      let flags = initialFlags;
      let index = prepared.syncStatusIndex;
      for (let event = 0; event < 2; event++) {
        if (mode === 'direct') {
          expect(await performHeartbeat(context.redisClient)).toMatchObject({
            success: false,
            requiresCourier: false,
          });
        } else {
          await expect(caller.reportRevocation()).resolves.toEqual({
            success: true,
          });
        }
        flags += flags % 2 === 0 ? 1 : -1;
        expect(consul.flags(K.HP_LICENSE_SYNC_STATUS)).toBe(flags);
        expect(Math.floor(flags / 2)).toBe(Math.floor(initialFlags / 2));
        expect(consul.index(K.HP_LICENSE_SYNC_STATUS)).toBeGreaterThan(index);
        index = consul.index(K.HP_LICENSE_SYNC_STATUS);
        expect(consul.value(K.HP_LICENSE_SYNC_STATUS)).toBe(Status.REVOKED);
        await expect(caller.submitRelay(input)).rejects.toMatchObject({
          code: 'CONFLICT',
        });
        expect(manager.getStatus()).toBe(Status.REVOKED);
        expect(consul.value(K.HP_LICENSE_JWT)).toBe(J0);
        expect(consul.value(K.NEXT_TOKEN)).toBe(prepared.nextToken);
      }
      expect(flags).toBe(initialFlags);
    });
  });

  it.each([
    'ack-loss',
    'concurrent report',
  ])('only acknowledges a revocation event that was not knowingly rejected (%s)', async (kind) => {
    await consul.kv.set(K.HP_LICENSE_SYNC_STATUS, Status.REVOKED);
    const index = consul.index(K.HP_LICENSE_SYNC_STATUS);
    const writeFrom = consul.writes.length;
    if (kind === 'ack-loss') {
      consul.fault = { key: K.HP_LICENSE_SYNC_STATUS, mode: 'ack-loss' };
      await expect(caller.reportRevocation()).resolves.toEqual({
        success: true,
      });
    } else {
      consul.beforeNextWrite = () => caller.reportRevocation();
      await expect(caller.reportRevocation()).rejects.toMatchObject({
        code: 'CONFLICT',
      });
    }
    expect(consul.index(K.HP_LICENSE_SYNC_STATUS)).toBeGreaterThan(index);
    expect(consul.flags(K.HP_LICENSE_SYNC_STATUS)).toBe(1);
    expect(consul.writes.slice(writeFrom)).toEqual([
      { key: K.HP_LICENSE_SYNC_STATUS, value: Status.REVOKED },
    ]);
    expect(manager.getStatus()).toBe(Status.REVOKED);
    const nextIndex = consul.index(K.HP_LICENSE_SYNC_STATUS);
    await caller.reportRevocation();
    expect(consul.flags(K.HP_LICENSE_SYNC_STATUS)).toBe(0);
    expect(consul.index(K.HP_LICENSE_SYNC_STATUS)).toBeGreaterThan(nextIndex);
  });

  it('fails closed rather than truncating flags outside the safe-integer range', async () => {
    const flags = 2 ** 53;
    services.consul = consul = new DurableConsul(consul.snapshot(), {
      [K.HP_LICENSE_SYNC_STATUS]: flags,
    });
    const before = consul.snapshot();
    await expect(caller.reportRevocation()).rejects.toThrow(
      'Invalid sync-status flags',
    );
    expect(consul.snapshot()).toEqual(before);
    expect(consul.flags(K.HP_LICENSE_SYNC_STATUS)).toBe(flags);
    expect(consul.writes).toEqual([]);
    expect(manager.getStatus()).toBe(Status.REVOKED);
  });

  it('preserves sync-status flags through verified recovery, courier fallback and replacement', async () => {
    const flags = 2 ** 40 + 7;
    await consul.kv.set(K.HP_LICENSE_SYNC_STATUS, Status.REVOKED, { flags });
    const prepared = await prepareCourier();
    await caller.submitRelay({
      ...prepared,
      jwt: await phaseTwo(prepared.nextToken),
    });
    await expectSynced();
    expect(consul.flags(K.HP_LICENSE_SYNC_STATUS)).toBe(flags);
    onExchange = () => {
      throw new TypeError('Network unavailable');
    };
    expect(await performHeartbeat(context.redisClient)).toMatchObject({
      success: false,
      requiresCourier: true,
    });
    expect(consul.value(K.HP_LICENSE_SYNC_STATUS)).toBe(
      Status.COURIER_REQUIRED,
    );
    expect(consul.flags(K.HP_LICENSE_SYNC_STATUS)).toBe(flags);
    await caller.provision(replacement);
    expect(consul.value(K.HP_LICENSE_SYNC_STATUS)).toBe(Status.SYNCED);
    expect(consul.flags(K.HP_LICENSE_SYNC_STATUS)).toBe(flags);
  });

  describe.each([
    'Phase 1',
    'prepared Phase 1',
    'Phase 2',
    'prepared Phase 2',
  ])('legacy false 403 in %s', (kind) => {
    it.each([
      'stale RAM',
      'restart',
    ])('recovers through a fresh direct handshake after %s', async (replica) => {
      const committed = kind.endsWith('Phase 2');
      if (kind.startsWith('prepared')) await prepareCourier();
      if (committed) {
        onExchange = ({ request, response }) => {
          if (request.phase === 2 && !response) {
            db.rerunWith = {
              ...db.license,
              pendingNextToken: 'discarded-pending',
            };
          }
        };
      } else {
        db.rerunWith = {
          ...db.license,
          expectedNextToken: 'discarded-predecessor',
          pendingNextToken: 'discarded-pending',
        };
      }

      expect(await performHeartbeat(context.redisClient)).toMatchObject({
        success: false,
        requiresCourier: false,
      });
      expect(exchanges.at(-1)?.response?.status).toBe(403);
      const candidate = (
        committed ? db.license.expectedNextToken : db.license.pendingNextToken
      )!;
      const retained = kind === 'Phase 1' ? T0 : candidate;
      expectPrepared(retained, Status.REVOKED);
      expect(db.license).toMatchObject({
        isRevoked: false,
        expectedNextToken: committed ? candidate : T0,
        pendingNextToken: committed ? null : candidate,
      });
      expect(db.transactions.at(-1)?.proposals[0]).toMatchObject({
        isRevoked: true,
      });
      expect(await caller.status()).toMatchObject({
        status: Status.REVOKED,
        hintStatus: Status.REVOKED,
      });

      const syncStatusIndex = consul.index(K.HP_LICENSE_SYNC_STATUS);
      const hintFlags = consul.flags(K.HP_LICENSE_SYNC_STATUS);
      const writeFrom = consul.writes.length;
      const retryFrom = exchanges.length;
      if (replica === 'restart') {
        Reflect.deleteProperty(LicenseManager, 'instance');
        manager = LicenseManager.getInstance();
        expect(manager.getRawJwt()).toBeNull();
      } else {
        manager.updateState(J0, T0);
        manager.setHintStatus(Status.COURIER_REQUIRED);
      }
      onExchange = ({ request, response, durable, memory }) => {
        expect(Object.keys(request).sort()).toEqual([
          'jwt',
          'licenseId',
          'nextToken',
          'phase',
        ]);
        if (request.phase === 2 && !response) {
          expect(durable).toMatchObject({
            [K.HP_LICENSE_JWT]: J0,
            [K.NEXT_TOKEN]: request.nextToken,
            [K.HP_LICENSE_SYNC_STATUS]: Status.REVOKED,
          });
          expect(memory).toEqual({
            jwt: J0,
            nextToken: request.nextToken,
            hint: Status.REVOKED,
          });
          expect(consul.index(K.HP_LICENSE_SYNC_STATUS)).toBe(syncStatusIndex);
        }
      };

      expect((await performHeartbeat(context.redisClient)).success).toBe(true);
      const retry = exchanges.slice(retryFrom);
      expect(retry.map(({ request }) => request.phase)).toEqual([1, 2]);
      expect(retry[0].request.nextToken).toBe(retained);
      if (committed) {
        expect(retry[1].request.nextToken).not.toBe(candidate);
      } else {
        expect(retry[1].request.nextToken).toBe(candidate);
      }
      const writes = consul.writes.slice(writeFrom);
      expect(writes.filter(({ key }) => key === K.NEXT_TOKEN)).toHaveLength(
        kind === 'prepared Phase 1' ? 0 : 1,
      );
      expect(
        writes.filter(({ key }) => key === K.HP_LICENSE_SYNC_STATUS),
      ).toEqual([{ key: K.HP_LICENSE_SYNC_STATUS, value: Status.SYNCED }]);
      expect(
        consul.transactions.filter(({ committed }) => committed).at(-1)
          ?.operations,
      ).toContainEqual({
        KV: {
          Verb: 'cas',
          Key: K.HP_LICENSE_SYNC_STATUS,
          Index: syncStatusIndex,
          Value: Buffer.from(Status.SYNCED).toString('base64'),
          Flags: hintFlags,
        },
      });
      expect(consul.index(K.HP_LICENSE_JWT)).toBe(
        consul.index(K.HP_LICENSE_SYNC_STATUS),
      );
      await expectSynced();
    });
  });

  it.each([
    'normal',
    'ack-loss',
    'key retry',
  ])('completes the actual courier flow and acknowledges the exact pair (%s)', async (kind) => {
    db.rerunWith = {
      ...db.license,
      expectedNextToken: 'discarded-predecessor',
    };
    expect((await performHeartbeat(context.redisClient)).success).toBe(false);
    expect(await caller.acquireCourierLock()).toEqual({ success: true });
    const syncStatusIndex = consul.index(K.HP_LICENSE_SYNC_STATUS);
    if (kind === 'ack-loss')
      consul.fault = { key: K.NEXT_TOKEN, mode: 'ack-loss' };
    const prepared = await prepareCourier();
    expect(prepared.syncStatusIndex).toBe(syncStatusIndex);
    expectPrepared(prepared.nextToken, Status.REVOKED);
    expect(consul.index(K.HP_LICENSE_SYNC_STATUS)).toBe(syncStatusIndex);
    const input = {
      ...prepared,
      jwt: await phaseTwo(prepared.nextToken),
      publicKey,
    };
    const unchangedIndices = Object.fromEntries(
      [K.HP_LICENSE_ID, 'LICENSE_PUBLIC_KEY', K.NEXT_TOKEN].map((key) => [
        key,
        consul.index(key),
      ]),
    );
    if (kind === 'key retry') {
      const before = consul.snapshot();
      await expect(
        caller.submitRelay({ ...input, publicKey: 'invalid-key' }),
      ).rejects.toMatchObject({ code: 'BAD_REQUEST' });
      expect(consul.snapshot()).toEqual(before);
      expect(consul.index(K.HP_LICENSE_SYNC_STATUS)).toBe(syncStatusIndex);
    }
    if (kind === 'ack-loss')
      consul.fault = { key: K.HP_LICENSE_SYNC_STATUS, mode: 'ack-loss' };
    await expect(caller.submitRelay(input)).resolves.toEqual({ success: true });
    const writeCount = consul.writes.length;
    expect(consul.index(K.HP_LICENSE_SYNC_STATUS)).toBeGreaterThan(
      syncStatusIndex,
    );
    expect(consul.index(K.HP_LICENSE_JWT)).toBe(
      consul.index(K.HP_LICENSE_SYNC_STATUS),
    );
    for (const [key, index] of Object.entries(unchangedIndices))
      expect(consul.index(key)).toBe(index);
    expect(
      consul.transactions.filter(({ committed }) => committed).at(-1)
        ?.changedKeys,
    ).toEqual([K.HP_LICENSE_JWT, K.HP_LICENSE_SYNC_STATUS]);
    await expect(caller.submitRelay(input)).resolves.toEqual({ success: true });
    expect(consul.writes).toHaveLength(writeCount);
    await caller.releaseCourierLock();
    expect(await caller.status()).toMatchObject({
      status: Status.SYNCED,
      hintStatus: Status.SYNCED,
    });
    await expectSynced();

    await caller.reportRevocation();
    const revoked = consul.snapshot();
    for (const replay of [
      input,
      { ...input, syncStatusIndex: consul.index(K.HP_LICENSE_SYNC_STATUS) },
      {
        ...input,
        preparedFrom: input.jwt,
        syncStatusIndex: consul.index(K.HP_LICENSE_SYNC_STATUS),
      },
      {
        ...input,
        jwt: J0,
        preparedFrom: input.jwt,
        syncStatusIndex: consul.index(K.HP_LICENSE_SYNC_STATUS),
      },
    ]) {
      await expect(caller.submitRelay(replay)).rejects.toMatchObject({
        code: 'CONFLICT',
      });
      expect(consul.snapshot()).toEqual(revoked);
    }
    expect(manager.getStatus()).toBe(Status.REVOKED);
  });

  const races = [
    {
      kind: 'new revocation',
      hint: Status.COURIER_REQUIRED,
      key: K.HP_LICENSE_SYNC_STATUS,
      value: Status.REVOKED,
    },
    {
      kind: 'same-value revocation',
      hint: Status.REVOKED,
      key: K.HP_LICENSE_SYNC_STATUS,
      value: Status.REVOKED,
    },
    {
      kind: 'source replacement',
      hint: Status.REVOKED,
      key: K.HP_LICENSE_JWT,
      value: otherJwt,
    },
    {
      kind: 'token replacement',
      hint: Status.REVOKED,
      key: K.NEXT_TOKEN,
      value: 'winning-successor',
    },
  ].flatMap((race) =>
    ['before prepare', 'prepare CAS', 'Phase 2', 'final CAS'].map((stage) => ({
      ...race,
      stage,
    })),
  );

  describe.each(['direct', 'courier'])('%s races', (mode) => {
    it.each(races)('preserves $kind at $stage', async ({
      hint,
      key,
      value,
      stage,
    }) => {
      await consul.kv.set(K.HP_LICENSE_SYNC_STATUS, hint);
      const capturedIndex = consul.index(K.HP_LICENSE_SYNC_STATUS);
      let winner: Record<string, string> | undefined;
      const change = async () => {
        if (key === K.HP_LICENSE_SYNC_STATUS) await caller.reportRevocation();
        else await consul.kv.set(key, value);
        winner = consul.snapshot();
      };
      const early = stage === 'before prepare' || stage === 'prepare CAS';
      if (mode === 'direct') {
        onExchange = async ({ request, response }) => {
          if (request.phase === 1 && response) {
            if (stage === 'before prepare') await change();
            if (stage === 'prepare CAS') consul.beforeNextWrite = change;
          }
          if (request.phase === 2) {
            if (!response && stage === 'Phase 2') await change();
            if (response && stage === 'final CAS')
              consul.beforeNextWrite = change;
          }
        };
        expect(await performHeartbeat(context.redisClient)).toMatchObject({
          success: false,
          requiresCourier: false,
        });
        expect(exchanges.map(({ request }) => request.phase)).toEqual(
          early ? [1] : [1, 2],
        );
      } else {
        const configuration = await caller.getDeploymentConfig();
        expect(configuration.syncStatusIndex).toBe(capturedIndex);
        const first = await central(
          1,
          configuration.nextToken!,
          configuration.jwt!,
        );
        expect(first.status).toBe(200);
        const nextToken = first.body.nextToken!;
        const input = {
          jwt: configuration.jwt!,
          previousNextToken: configuration.nextToken!,
          nextToken,
          syncStatusIndex: configuration.syncStatusIndex,
        };
        if (stage === 'before prepare') await change();
        if (stage === 'prepare CAS') consul.beforeNextWrite = change;
        if (early) {
          await expect(caller.prepareRelay(input)).rejects.toMatchObject({
            code: 'CONFLICT',
          });
        } else {
          await caller.prepareRelay(input);
          if (stage === 'Phase 2') await change();
          const newJwt = await phaseTwo(nextToken);
          if (stage === 'final CAS') consul.beforeNextWrite = change;
          await expect(
            caller.submitRelay({
              jwt: newJwt,
              preparedFrom: configuration.jwt!,
              nextToken,
              syncStatusIndex: configuration.syncStatusIndex,
            }),
          ).rejects.toMatchObject({ code: 'CONFLICT' });
        }
      }
      expect(winner).toBeDefined();
      expect(consul.snapshot()).toEqual(winner);
      expect(consul.beforeNextWrite).toBeUndefined();
      expect(manager.getRawJwt()).toBe(consul.value(K.HP_LICENSE_JWT));
      expect(manager.getNextToken()).toBe(consul.value(K.NEXT_TOKEN));
      expect(manager.getHintStatus()).toBe(
        consul.value(K.HP_LICENSE_SYNC_STATUS),
      );
      expect(consul.writes).not.toContainEqual({
        key: K.HP_LICENSE_SYNC_STATUS,
        value: Status.SYNCED,
      });
      expect(db.license.isRevoked).toBe(false);
      expect(db.transactions).toHaveLength(early ? 1 : 2);
      if (key === K.HP_LICENSE_SYNC_STATUS)
        expect(consul.index(key)).toBeGreaterThan(capturedIndex);
    });
  });

  it.each([
    Status.COURIER_REQUIRED,
    Status.REVOKED,
  ])('does not acknowledge a prepared candidate across a newer revocation (%s)', async (hint) => {
    await consul.kv.set(K.HP_LICENSE_SYNC_STATUS, hint);
    onExchange = ({ request, response }) => {
      if (request.phase === 1 && response) {
        consul.beforeNextWrite = async () => {
          await consul.kv.set(K.NEXT_TOKEN, response.body.nextToken!);
          await caller.reportRevocation();
        };
      }
    };
    expect(await performHeartbeat(context.redisClient)).toMatchObject({
      success: false,
      requiresCourier: false,
    });
    expect(exchanges.map(({ request }) => request.phase)).toEqual([1]);
    expectPrepared(db.license.pendingNextToken!, Status.REVOKED);
  });

  function resign(token: string, patch: Record<string, unknown>) {
    return jwt.sign(
      { ...(jwt.decode(token) as object), ...patch },
      privateKey,
      { algorithm: 'ES256' },
    );
  }

  const invalidResults = [
    { kind: 'malformed JWT', token: () => 'not-a-jwt', code: 'BAD_REQUEST' },
    {
      kind: 'forged JWT',
      token: (token: string) =>
        jwt.sign(jwt.decode(token) as object, untrustedKey, {
          algorithm: 'ES256',
        }),
      code: 'BAD_REQUEST',
    },
    { kind: 'installed JWT replay', token: () => J0, code: 'CONFLICT' },
    ...(
      [
        ['expired at zero', { exp: 0 }, 'BAD_REQUEST'],
        ['expired JWT', { exp: 1 }, 'BAD_REQUEST'],
        ['wrong identity', { licenseId: 'wrong-license' }, 'CONFLICT'],
        [
          'same heartbeat in a new signature',
          {
            last_heartbeat_timestamp: originalPayload.last_heartbeat_timestamp,
          },
          'CONFLICT',
        ],
        [
          'regressing heartbeat',
          {
            last_heartbeat_timestamp:
              originalPayload.last_heartbeat_timestamp - 1,
          },
          'CONFLICT',
        ],
        [
          'missing heartbeat',
          { last_heartbeat_timestamp: undefined },
          'BAD_REQUEST',
        ],
        [
          'nonfinite heartbeat',
          { last_heartbeat_timestamp: Infinity },
          'BAD_REQUEST',
        ],
        ['negative heartbeat', { last_heartbeat_timestamp: -1 }, 'BAD_REQUEST'],
        [
          'exceeded grace',
          { last_heartbeat_timestamp: startedAt - 8 * 24 * 60 * 60 * 1000 },
          'BAD_REQUEST',
        ],
      ] as const
    ).map(([kind, patch, code]) => ({
      kind,
      token: (token: string) => resign(token, patch),
      code,
    })),
  ];

  describe.each(['direct', 'courier'])('%s validation', (mode) => {
    it.each(
      invalidResults,
    )('cannot clear REVOKED with $kind and the current revision', async ({
      token,
      code,
    }) => {
      await consul.kv.set(K.HP_LICENSE_SYNC_STATUS, Status.REVOKED);
      const syncStatusIndex = consul.index(K.HP_LICENSE_SYNC_STATUS);
      const writeFrom = consul.writes.length;
      if (mode === 'direct') {
        onExchange = ({ request, response }) => {
          if (request.phase === 2 && response)
            response.body.jwt = token(response.body.jwt!);
        };
        expect(await performHeartbeat(context.redisClient)).toMatchObject({
          success: false,
          requiresCourier: code !== 'CONFLICT',
        });
      } else {
        const prepared = await prepareCourier();
        const valid = await phaseTwo(prepared.nextToken);
        await expect(
          caller.submitRelay({ ...prepared, jwt: token(valid) }),
        ).rejects.toMatchObject({ code });
      }
      expectPrepared(db.license.expectedNextToken, Status.REVOKED);
      expect(consul.index(K.HP_LICENSE_SYNC_STATUS)).toBe(syncStatusIndex);
      expect(consul.writes.slice(writeFrom)).toEqual([
        { key: K.NEXT_TOKEN, value: db.license.expectedNextToken },
      ]);
      expect(manager.getStatus()).toBe(Status.REVOKED);
    });
  });

  it.each([
    undefined,
    null,
    'not-a-timestamp',
    -1,
  ])('requires a valid source heartbeat timestamp (%s)', async (timestamp) => {
    const source = resign(J0, { last_heartbeat_timestamp: timestamp });
    await consul.kv.set(K.HP_LICENSE_JWT, source);
    await consul.kv.set(K.HP_LICENSE_SYNC_STATUS, Status.REVOKED);
    const prepared = await prepareCourier();
    const before = consul.snapshot();
    const result = await central(2, prepared.nextToken, source);
    expect(result.status).toBe(200);
    await expect(
      caller.submitRelay({ ...prepared, jwt: result.body.jwt! }),
    ).rejects.toMatchObject({ code: 'CONFLICT' });
    expect(consul.snapshot()).toEqual(before);
    expect(manager.getStatus()).toBe(Status.REVOKED);
  });

  it.each([
    ['malformed', 'not-a-jwt'],
    ['invalid JSON', malformedJsonJwt],
  ])('rejects a %s installed source during strict prepared recovery', async (_kind, source) => {
    const prepared = await prepareCourier();
    const target = await phaseTwo(prepared.nextToken);
    await consul.kv.set(K.HP_LICENSE_JWT, source);
    await consul.kv.set(K.HP_LICENSE_SYNC_STATUS, Status.REVOKED);
    await readLicenseState(consul, manager);
    const before = consul.snapshot();
    const writes = structuredClone(consul.writes);
    const publications = structuredClone(redis.publications);
    const centralBefore = db.license;
    expect(manager.captureRecoveryContext().revoked).toBe(true);

    await expect(
      caller.submitRelay({
        ...prepared,
        jwt: target,
        syncStatusIndex: consul.index(K.HP_LICENSE_SYNC_STATUS),
      }),
    ).rejects.toMatchObject({ code: 'CONFLICT' });

    expect(consul.snapshot()).toEqual(before);
    expect(consul.writes).toEqual(writes);
    expect(redis.publications).toEqual(publications);
    expect(manager.getRawJwt()).toBe(source);
    expect(manager.getNextToken()).toBe(prepared.nextToken);
    expect(manager.getHintStatus()).toBe(Status.REVOKED);
    expect(manager.getStatus()).toBe(Status.REVOKED);
    expect(db.license).toEqual(centralBefore);
    expect(fetch).not.toHaveBeenCalled();
  });

  it.each([
    -1, 1,
  ])('uses source-relative refresh validation with a central clock offset of %s day', async (offset) => {
    const day = 24 * 60 * 60 * 1000;
    const source =
      offset < 0
        ? J0
        : resign(J0, { last_heartbeat_timestamp: startedAt + day / 2 });
    await consul.kv.set(K.HP_LICENSE_JWT, source);
    await consul.kv.set(K.HP_LICENSE_SYNC_STATUS, Status.REVOKED);
    const prepared = await prepareCourier();
    let result: Awaited<ReturnType<typeof central>>;
    const centralClock = vi
      .spyOn(Date, 'now')
      .mockReturnValue(startedAt + offset * day);
    try {
      result = await central(2, prepared.nextToken, source);
    } finally {
      centralClock.mockRestore();
    }
    expect(result.status).toBe(200);
    expect(
      jwt.verify(result.body.jwt!, publicKey, { algorithms: ['ES256'] }),
    ).toMatchObject({ last_heartbeat_timestamp: startedAt + offset * day });
    await expect(
      caller.submitRelay({ ...prepared, jwt: result.body.jwt! }),
    ).resolves.toEqual({ success: true });
    expect(consul.value(K.HP_LICENSE_JWT)).toBe(result.body.jwt);
    expect(manager.getStatus()).toBe(Status.SYNCED);
    expect(manager.getHintStatus()).toBe(Status.SYNCED);
  });

  it('rejects an expired result actually issued by the unchanged legacy handler before clearing the hint', async () => {
    await consul.kv.set(K.HP_LICENSE_SYNC_STATUS, Status.REVOKED);
    onExchange = async ({ request, response }) => {
      if (request.phase === 2 && !response)
        await db.ref(`/licenses/${licenseId}`).update({ expiryDate: 0 });
    };
    expect(await performHeartbeat(context.redisClient)).toMatchObject({
      success: false,
      requiresCourier: true,
    });
    expect(exchanges[1].response?.status).toBe(200);
    expect(jwt.decode(exchanges[1].response!.body.jwt!)).toMatchObject({
      exp: 0,
    });
    expectPrepared(db.license.expectedNextToken, Status.REVOKED);
  });

  it('keeps legacy no-index preparation and completion fail-closed for REVOKED', async () => {
    await consul.kv.set(K.HP_LICENSE_SYNC_STATUS, Status.REVOKED);
    const configuration = await caller.getDeploymentConfig();
    const nextToken = await phaseOne();
    const input = { jwt: J0, previousNextToken: T0, nextToken };
    await expect(caller.prepareRelay(input)).rejects.toMatchObject({
      code: 'CONFLICT',
    });
    expect(consul.value(K.NEXT_TOKEN)).toBe(T0);
    await caller.prepareRelay({
      ...input,
      syncStatusIndex: configuration.syncStatusIndex,
    });
    await expect(caller.prepareRelay(input)).rejects.toMatchObject({
      code: 'CONFLICT',
    });
    const completion = {
      jwt: await phaseTwo(nextToken),
      preparedFrom: J0,
      nextToken,
    };
    await expect(caller.submitRelay(completion)).rejects.toMatchObject({
      code: 'CONFLICT',
    });
    expectPrepared(nextToken, Status.REVOKED);
    await caller.submitRelay({
      ...completion,
      syncStatusIndex: configuration.syncStatusIndex,
    });
    await expect(caller.submitRelay(completion)).resolves.toEqual({
      success: true,
    });
    await expectSynced();
  });

  it.each([
    -1,
    0.5,
    Number.MAX_SAFE_INTEGER + 1,
    Infinity,
    NaN,
  ])('rejects an unsafe syncStatusIndex (%s) at both router inputs', async (syncStatusIndex) => {
    const before = consul.snapshot();
    await expect(
      caller.prepareRelay({
        jwt: J0,
        previousNextToken: T0,
        nextToken: 'candidate',
        syncStatusIndex,
      }),
    ).rejects.toMatchObject({ code: 'BAD_REQUEST' });
    await expect(
      caller.submitRelay({
        jwt: J0,
        preparedFrom: J0,
        nextToken: T0,
        syncStatusIndex,
      }),
    ).rejects.toMatchObject({ code: 'BAD_REQUEST' });
    expect(consul.snapshot()).toEqual(before);
    expect(consul.writes).toEqual([]);
  });

  describe.each([
    'direct',
    'courier',
  ])('%s recovery with absent keys', (mode) => {
    it.each([
      { missing: [K.HP_LICENSE_SYNC_STATUS] },
      { missing: ['LICENSE_PUBLIC_KEY'] },
      {
        missing: [
          K.HP_LICENSE_SYNC_STATUS,
          'LICENSE_PUBLIC_KEY',
          K.HP_LICENSE_ID,
        ],
      },
    ])('recovers using absence fences and an env key when missing $missing', async ({
      missing,
    }) => {
      const seed = consul.snapshot();
      seed[K.HP_LICENSE_SYNC_STATUS] = Status.REVOKED;
      for (const key of missing) delete seed[key];
      services.consul = consul = new DurableConsul(seed);
      manager.setHintStatus(Status.REVOKED);
      if (mode === 'direct') {
        expect((await performHeartbeat(context.redisClient)).success).toBe(
          true,
        );
      } else {
        const prepared = await prepareCourier();
        expect(prepared.syncStatusIndex).toBe(
          missing.includes(K.HP_LICENSE_SYNC_STATUS)
            ? 0
            : consul.index(K.HP_LICENSE_SYNC_STATUS),
        );
        await caller.submitRelay({
          ...prepared,
          jwt: await phaseTwo(prepared.nextToken),
        });
      }
      expectValidJwt(consul.value(K.HP_LICENSE_JWT)!);
      expect(manager.getRawJwt()).toBe(consul.value(K.HP_LICENSE_JWT));
      expect(manager.getNextToken()).toBe(db.license.expectedNextToken);
      expect(manager.getPublicKey()).toBe(publicKey);
      expect(manager.getHintStatus()).toBe(Status.SYNCED);
      expect(manager.getStatus()).toBe(Status.SYNCED);
      expect(consul.value('LICENSE_PUBLIC_KEY')).toBe(
        mode === 'courier' && missing.includes('LICENSE_PUBLIC_KEY')
          ? null
          : publicKey,
      );
      const checks = consul.transactions
        .flatMap(({ operations }) => operations)
        .filter(({ KV }) => KV.Verb.startsWith('check-'));
      expect(
        checks.some(({ KV }) => KV.Verb === 'check-index' && KV.Index === 0),
      ).toBe(false);
      for (const key of missing.filter((key) => key !== K.HP_LICENSE_ID)) {
        expect(checks).toContainEqual({
          KV: { Verb: 'check-not-exists', Key: key },
        });
      }
    });
  });

  it.each([
    K.HP_LICENSE_SYNC_STATUS,
    'LICENSE_PUBLIC_KEY',
  ])('rejects creation of absent %s during the preparation/final CAS', async (key) => {
    const seed = consul.snapshot();
    seed[K.HP_LICENSE_SYNC_STATUS] = Status.REVOKED;
    delete seed[key];
    services.consul = consul = new DurableConsul(seed);
    manager.setHintStatus(Status.REVOKED);
    if (key === K.HP_LICENSE_SYNC_STATUS) {
      onExchange = ({ request, response }) => {
        if (request.phase === 1 && response)
          consul.beforeNextWrite = () => caller.reportRevocation();
      };
      expect(await performHeartbeat(context.redisClient)).toMatchObject({
        success: false,
        requiresCourier: false,
      });
      expect(exchanges.map(({ request }) => request.phase)).toEqual([1]);
      expect(consul.value(K.NEXT_TOKEN)).toBe(T0);
    } else {
      const prepared = await prepareCourier();
      const input = { ...prepared, jwt: await phaseTwo(prepared.nextToken) };
      consul.beforeNextWrite = () => consul.kv.set(key, publicKey);
      await expect(caller.submitRelay(input)).rejects.toMatchObject({
        code: 'CONFLICT',
      });
      expect(consul.value(K.NEXT_TOKEN)).toBe(prepared.nextToken);
      expect(consul.value(key)).toBe(publicKey);
    }
    expect(consul.value(K.HP_LICENSE_JWT)).toBe(J0);
    expect(consul.value(K.HP_LICENSE_SYNC_STATUS)).toBe(Status.REVOKED);
    expect(manager.getStatus()).toBe(Status.REVOKED);
  });

  it('records direct revocation with absent hint/ID/public-key rows and an env verification key', async () => {
    services.consul = consul = new DurableConsul({
      [K.HP_LICENSE_JWT]: J0,
      [K.NEXT_TOKEN]: T0,
    });
    await db.ref(`/licenses/${licenseId}`).update({ isRevoked: true });
    expect(await performHeartbeat(context.redisClient)).toMatchObject({
      success: false,
      requiresCourier: false,
    });
    expect(consul.snapshot()).toEqual({
      [K.HP_LICENSE_JWT]: J0,
      [K.NEXT_TOKEN]: T0,
      [K.HP_LICENSE_SYNC_STATUS]: Status.REVOKED,
    });
    expect(consul.flags(K.HP_LICENSE_SYNC_STATUS)).toBe(1);
    expect(manager.getPublicKey()).toBe(publicKey);
    expect(manager.getStatus()).toBe(Status.REVOKED);
    const operations = consul.transactions.find(
      ({ committed }) => committed,
    )!.operations;
    for (const Key of [K.HP_LICENSE_ID, 'LICENSE_PUBLIC_KEY']) {
      expect(operations).toContainEqual({
        KV: { Verb: 'check-not-exists', Key },
      });
    }
  });

  it('returns the hint index from the JWT/token snapshot, not a subsequent hint read', async () => {
    const index = consul.index(K.HP_LICENSE_SYNC_STATUS);
    const create = consul.transaction.create;
    vi.spyOn(consul.transaction, 'create').mockImplementationOnce(
      async (...args) => {
        const result = await create(...args);
        await consul.kv.set(K.HP_LICENSE_SYNC_STATUS, Status.REVOKED);
        return result;
      },
    );
    const configuration = await caller.getDeploymentConfig();
    expect(configuration).toEqual({
      licenseId,
      jwt: J0,
      nextToken: T0,
      syncStatusIndex: index,
    });
    expect(consul.index(K.HP_LICENSE_SYNC_STATUS)).toBeGreaterThan(index);
    const nextToken = await phaseOne();
    await expect(
      caller.prepareRelay({
        jwt: configuration.jwt!,
        previousNextToken: configuration.nextToken!,
        nextToken,
        syncStatusIndex: configuration.syncStatusIndex,
      }),
    ).rejects.toMatchObject({ code: 'CONFLICT' });
    expect(db.transactions).toHaveLength(1);
    expectPrepared(T0, Status.REVOKED);
  });

  it.each([
    Status.SYNCED,
    Status.COURIER_REQUIRED,
    Status.REVOKED,
  ])('allows manual fallback after a network failure without clearing %s', async (hint) => {
    await consul.kv.set(K.HP_LICENSE_SYNC_STATUS, hint);
    const index = consul.index(K.HP_LICENSE_SYNC_STATUS);
    onExchange = ({ request, response }) => {
      if (request.phase === 1 && response)
        throw new TypeError('Phase 1 response lost');
    };
    expect(await performHeartbeat(context.redisClient)).toMatchObject({
      success: false,
      requiresCourier: true,
    });
    await expect(caller.sync()).resolves.toEqual({
      success: false,
      requiresCourier: true,
    });
    expectPrepared(
      T0,
      hint === Status.REVOKED ? hint : Status.COURIER_REQUIRED,
    );
    if (hint === Status.REVOKED)
      expect(consul.index(K.HP_LICENSE_SYNC_STATUS)).toBe(index);
    expect(db.license.pendingNextToken).toEqual(expect.any(String));
  });

  const replacement = {
    jwt: resign(J0, { licenseId: 'recovery-replacement' }),
    nextToken: 'replacement-predecessor',
    publicKey,
  };
  const errorRaces = [
    {
      kind: 'new revocation',
      hint: Status.SYNCED,
      change: () => caller.reportRevocation(),
    },
    {
      kind: 'same-value revocation',
      hint: Status.REVOKED,
      change: () => caller.reportRevocation(),
    },
    {
      kind: 'token successor',
      hint: Status.REVOKED,
      change: () => consul.kv.set(K.NEXT_TOKEN, 'concurrent-successor'),
    },
    {
      kind: 'replacement',
      hint: Status.REVOKED,
      change: () => caller.provision(replacement),
    },
  ].flatMap((race) =>
    ['Phase 1 loss', 'Phase 2 loss', 'invalid JWT'].map((fault) => ({
      ...race,
      fault,
    })),
  );

  it.each(
    errorRaces,
  )('does not overwrite $kind or enable fallback after $fault', async ({
    hint,
    change,
    fault,
  }) => {
    await consul.kv.set(K.HP_LICENSE_SYNC_STATUS, hint);
    let winner: Record<string, string> | undefined;
    let writes = 0;
    onExchange = async ({ request, response }) => {
      if (response && request.phase === (fault === 'Phase 1 loss' ? 1 : 2)) {
        await change();
        winner = consul.snapshot();
        writes = consul.writes.length;
        if (fault !== 'invalid JWT') throw new TypeError(fault);
        response.body.jwt = jwt.sign(
          jwt.decode(response.body.jwt!) as object,
          untrustedKey,
          { algorithm: 'ES256' },
        );
      }
    };
    expect(await performHeartbeat(context.redisClient)).toMatchObject({
      success: false,
      requiresCourier: false,
    });
    expect(winner).toBeDefined();
    expect(consul.snapshot()).toEqual(winner);
    expect(consul.writes).toHaveLength(writes);
    expect(manager.getRawJwt()).toBe(consul.value(K.HP_LICENSE_JWT));
    expect(manager.getNextToken()).toBe(consul.value(K.NEXT_TOKEN));
    expect(manager.getHintStatus()).toBe(
      consul.value(K.HP_LICENSE_SYNC_STATUS),
    );
    expect(db.license.isRevoked).toBe(false);
  });

  it.each([
    'revocation',
    'successor',
    'completed relay',
  ])('fences the fallback CAS against a concurrent %s', async (kind) => {
    await consul.kv.set(K.HP_LICENSE_SYNC_STATUS, Status.SYNCED);
    let winner: Record<string, string> | undefined;
    onExchange = ({ request, response }) => {
      if (request.phase === 1 && response) {
        consul.beforeNextWrite = async () => {
          if (kind === 'revocation') await caller.reportRevocation();
          if (kind === 'successor')
            await consul.kv.set(K.NEXT_TOKEN, 'winning-successor');
          if (kind === 'completed relay') {
            const prepared = await prepareCourier();
            await caller.submitRelay({
              ...prepared,
              jwt: await phaseTwo(prepared.nextToken),
            });
          }
          winner = consul.snapshot();
        };
        throw new TypeError('Phase 1 response lost');
      }
    };
    expect(await performHeartbeat(context.redisClient)).toMatchObject({
      success: false,
      requiresCourier: false,
    });
    expect(consul.beforeNextWrite).toBeUndefined();
    expect(winner).toBeDefined();
    expect(consul.snapshot()).toEqual(winner);
    expect(consul.writes).not.toContainEqual({
      key: K.HP_LICENSE_SYNC_STATUS,
      value: Status.COURIER_REQUIRED,
    });
    expect(manager.getRawJwt()).toBe(consul.value(K.HP_LICENSE_JWT));
    expect(manager.getNextToken()).toBe(consul.value(K.NEXT_TOKEN));
    expect(manager.getHintStatus()).toBe(
      consul.value(K.HP_LICENSE_SYNC_STATUS),
    );
  });

  it.each([
    'confirmation outage',
    'new revocation',
  ])('does not undo a committed finalization after %s', async (kind) => {
    await consul.kv.set(K.HP_LICENSE_SYNC_STATUS, Status.REVOKED);
    const syncStatusIndex = consul.index(K.HP_LICENSE_SYNC_STATUS);
    const create = consul.transaction.create;
    let failConfirmation = false;
    vi.spyOn(consul.transaction, 'create').mockImplementation(
      async (operations, options) => {
        if (failConfirmation) {
          failConfirmation = false;
          throw new TypeError(
            'Committed finalization confirmation unavailable',
          );
        }
        const result = await create(operations, options);
        if (
          operations.some(
            ({ KV }) => KV.Verb === 'cas' && KV.Key === K.HP_LICENSE_JWT,
          )
        ) {
          if (kind === 'new revocation') await caller.reportRevocation();
          else failConfirmation = true;
        }
        return result;
      },
    );
    expect(await performHeartbeat(context.redisClient)).toMatchObject({
      success: false,
      requiresCourier: false,
    });
    const input = {
      jwt: exchanges[1].response!.body.jwt!,
      preparedFrom: J0,
      nextToken: db.license.expectedNextToken,
      syncStatusIndex,
    };
    const before = consul.snapshot();
    const writes = consul.writes.length;
    expect(before[K.HP_LICENSE_JWT]).toBe(input.jwt);
    expect(before[K.NEXT_TOKEN]).toBe(input.nextToken);
    expect(manager.getRawJwt()).toBe(input.jwt);
    expect(manager.getHintStatus()).toBe(
      kind === 'new revocation' ? Status.REVOKED : Status.SYNCED,
    );
    if (kind === 'new revocation') {
      await expect(caller.submitRelay(input)).rejects.toMatchObject({
        code: 'CONFLICT',
      });
      await expect(
        caller.submitRelay({
          ...input,
          syncStatusIndex: consul.index(K.HP_LICENSE_SYNC_STATUS),
        }),
      ).rejects.toMatchObject({ code: 'CONFLICT' });
    } else {
      await expect(caller.submitRelay(input)).resolves.toEqual({
        success: true,
      });
    }
    expect(consul.snapshot()).toEqual(before);
    expect(consul.writes).toHaveLength(writes);
  });

  it.each([
    Status.SYNCED,
    Status.REVOKED,
  ])('keeps a newer revocation during public-key verification (%s)', async (hint) => {
    await consul.kv.set(K.HP_LICENSE_SYNC_STATUS, hint);
    const transport = vi.mocked(fetch).getMockImplementation()!;
    vi.mocked(fetch).mockImplementation(async (...args) => {
      if (args[0] === services.publicKeyUrl) {
        await caller.reportRevocation();
        await transport(...args);
        return Response.json(rotatedKeys.publicKey);
      }
      return transport(...args);
    });
    onExchange = ({ request, response }) => {
      if (request.phase === 2 && response) {
        response.body.jwt = jwt.sign(
          jwt.decode(response.body.jwt!) as object,
          rotatedKeys.privateKey,
          { algorithm: 'ES256' },
        );
      }
    };
    expect(await performHeartbeat(context.redisClient)).toMatchObject({
      success: false,
      requiresCourier: false,
    });
    expect(publicKeyFetches).toBe(1);
    expectPrepared(db.license.expectedNextToken, Status.REVOKED);
    expect(consul.value('LICENSE_PUBLIC_KEY')).toBe(publicKey);
  });

  it('does not let a key retry recapture and clear a newer REVOKED revision', async () => {
    await consul.kv.set(K.HP_LICENSE_SYNC_STATUS, Status.REVOKED);
    const prepared = await prepareCourier();
    const input = { ...prepared, jwt: await phaseTwo(prepared.nextToken) };
    await expect(
      caller.submitRelay({ ...input, publicKey: 'invalid-key' }),
    ).rejects.toMatchObject({ code: 'BAD_REQUEST' });
    await caller.reportRevocation();
    const before = consul.snapshot();
    await expect(
      caller.submitRelay({ ...input, publicKey }),
    ).rejects.toMatchObject({ code: 'CONFLICT' });
    expect(consul.snapshot()).toEqual(before);
    expectPrepared(prepared.nextToken, Status.REVOKED);
  });

  it.each([
    1, 2,
  ])('keeps genuine central revocation in Phase %s locked without courier fallback', async (phase) => {
    onExchange = async ({ request, response }) => {
      if (!response && request.phase === phase)
        await db.ref(`/licenses/${licenseId}`).update({ isRevoked: true });
    };
    expect(await performHeartbeat(context.redisClient)).toMatchObject({
      success: false,
      requiresCourier: false,
    });
    expect(exchanges.at(-1)?.response).toEqual({
      status: 403,
      body: { error: 'License has been revoked' },
    });
    const index = consul.index(K.HP_LICENSE_SYNC_STATUS);
    await expect(caller.sync()).rejects.toMatchObject({ code: 'BAD_REQUEST' });
    expect(consul.index(K.HP_LICENSE_SYNC_STATUS)).toBeGreaterThan(index);
    expect(manager.getStatus()).toBe(Status.REVOKED);
    expect(db.license.isRevoked).toBe(true);
  });

  it.each([
    'write failure',
    'read outage',
  ])('keeps genuine central revocation fail-closed in RAM after a %s', async (fault) => {
    await db.ref(`/licenses/${licenseId}`).update({ isRevoked: true });
    const before = consul.snapshot();
    onExchange = ({ response }) => {
      if (!response) return;
      if (fault === 'write failure') {
        consul.fault = { key: K.HP_LICENSE_SYNC_STATUS, mode: 'before-write' };
      } else {
        vi.spyOn(consul.transaction, 'create').mockRejectedValue(
          new Error('Consul reads unavailable after central revocation'),
        );
      }
    };
    expect(await performHeartbeat(context.redisClient)).toMatchObject({
      success: false,
      requiresCourier: false,
    });
    expect(exchanges[0].response).toEqual({
      status: 403,
      body: { error: 'License has been revoked' },
    });
    expect(consul.snapshot()).toEqual(before);
    expect(consul.writes).toEqual([]);
    expect(manager.getRawJwt()).toBe(J0);
    expect(manager.getNextToken()).toBe(T0);
    expect(manager.getHintStatus()).toBe(Status.REVOKED);
    expect(manager.getStatus()).toBe(Status.REVOKED);
  });

  it.each([
    1, 2,
  ])('does not enable fallback for HTTP 401 in Phase %s', async (phase) => {
    onExchange = async ({ request, response }) => {
      if (request.phase !== phase) return;
      if (!response)
        await db.ref(`/licenses/${licenseId}`).update({ isRevoked: true });
      else response.status = 401;
    };
    await expect(caller.sync()).rejects.toMatchObject({ code: 'BAD_REQUEST' });
    expect(exchanges.at(-1)?.response?.status).toBe(401);
    expect(manager.getStatus()).toBe(Status.REVOKED);
  });

  it('does not offer courier fallback for a CONFLICT even if the winning hint is COURIER_REQUIRED', async () => {
    onExchange = async ({ request, response }) => {
      if (request.phase === 1 && response)
        await consul.kv.set(K.HP_LICENSE_JWT, otherJwt);
    };
    await expect(caller.sync()).rejects.toMatchObject({
      code: 'BAD_REQUEST',
      message: expect.stringContaining('License state changed'),
    });
    expect(exchanges.map(({ request }) => request.phase)).toEqual([1]);
    expect(consul.value(K.HP_LICENSE_JWT)).toBe(otherJwt);
    expect(manager.getHintStatus()).toBe(Status.COURIER_REQUIRED);
  });

  it('preserves a known replacement conflict without a fallible second read after a late false 403', async () => {
    db.rerunWith = {
      ...db.license,
      expectedNextToken: 'discarded-predecessor',
    };
    let winner: Record<string, string> | undefined;
    let reads = 0;
    onExchange = async ({ response }) => {
      if (response) {
        expect(response.status).toBe(403);
        await caller.provision(replacement);
        winner = consul.snapshot();
        manager.updateState(J0, T0);
        manager.setHintStatus(Status.COURIER_REQUIRED);
        const create = consul.transaction.create;
        vi.spyOn(consul.transaction, 'create').mockImplementation((...args) => {
          if (++reads > 1)
            throw new Error('Read unavailable after known conflict');
          return create(...args);
        });
      }
    };
    expect(await performHeartbeat(context.redisClient)).toMatchObject({
      success: false,
      requiresCourier: false,
    });
    expect(consul.snapshot()).toEqual(winner);
    expect(manager.getRawJwt()).toBe(replacement.jwt);
    expect(manager.getNextToken()).toBe(replacement.nextToken);
    expect(manager.getHintStatus()).toBe(Status.SYNCED);
    expect(manager.getStatus()).toBe(Status.SYNCED);
    expect(reads).toBe(1);
    expect(db.license.isRevoked).toBe(false);
  });

  it.each([
    'HTTP 409',
    'result.Errors',
    'TRPC CONFLICT',
    'lost 409 response',
  ])('preserves a replacement winning during CAS without a fallible fallback read (%s)', async (kind) => {
    db.rerunWith = {
      ...db.license,
      expectedNextToken: 'discarded-predecessor',
    };
    let winner: Record<string, string> | undefined;
    let conflicted = false;
    let confirmationReads = 0;
    onExchange = ({ response }) => {
      if (!response) return;
      expect(response.status).toBe(403);
      consul.beforeNextWrite = async () => {
        await caller.provision(replacement);
        winner = consul.snapshot();
      };
      const create = consul.transaction.create;
      vi.spyOn(consul.transaction, 'create').mockImplementation(
        async (...args) => {
          if (conflicted) {
            confirmationReads++;
            if (kind === 'lost 409 response' && confirmationReads === 1) {
              return create(...args);
            }
            throw new Error('Confirmation and subsequent reads unavailable');
          }
          try {
            return await create(...args);
          } catch (error) {
            if (
              typeof error !== 'object' ||
              error === null ||
              !('statusCode' in error) ||
              error.statusCode !== 409
            )
              throw error;
            conflicted = true;
            if (kind === 'result.Errors')
              return {
                Results: [],
                Errors: [{ OpIndex: 0, What: 'Index conflict' }],
              };
            if (kind === 'TRPC CONFLICT')
              throw new TRPCError({ code: 'CONFLICT' });
            if (kind === 'lost 409 response')
              throw new TypeError('CAS rejection response lost');
            throw error;
          }
        },
      );
    };
    expect(await performHeartbeat(context.redisClient)).toMatchObject({
      success: false,
      requiresCourier: false,
    });
    expect(conflicted).toBe(true);
    expect(confirmationReads).toBe(1);
    expect(winner).toBeDefined();
    expect(consul.snapshot()).toEqual(winner);
    expect(manager.getRawJwt()).toBe(replacement.jwt);
    expect(manager.getNextToken()).toBe(replacement.nextToken);
    expect(manager.getHintStatus()).toBe(Status.SYNCED);
    expect(manager.getStatus()).toBe(Status.SYNCED);
    expect(consul.writes).not.toContainEqual({
      key: K.HP_LICENSE_SYNC_STATUS,
      value: Status.REVOKED,
    });
    expect(db.license.isRevoked).toBe(false);
  });
});

describe('fenced Phase 0 relay completion', () => {
  const replacementJwt = jwt.sign(
    { ...originalPayload, licenseId: 'phase0-replacement-license' },
    privateKey,
    { algorithm: 'ES256' },
  );
  const relayPublicKey = publicKey.replace(
    /([A-Za-z0-9+/=])\n(?=[A-Za-z0-9+/=])/g,
    '$1',
  );

  beforeEach(() => {
    const seed = consul.snapshot();
    delete seed[K.NEXT_TOKEN];
    services.consul = consul = new DurableConsul(seed);
    services.db = db = new DurableRtdb(licenseId, privateKey, {
      ...db.license,
      isInitialized: false,
      expectedNextToken: '',
    });
  });

  async function initialRelay() {
    const configuration = await caller.getDeploymentConfig();
    expect(configuration).toEqual({
      licenseId,
      jwt: J0,
      nextToken: null,
      syncStatusIndex: consul.index(K.HP_LICENSE_SYNC_STATUS),
    });
    const result = await centralHeartbeat({
      body: JSON.stringify({
        phase: 0,
        licenseId: configuration.licenseId,
        jwt: configuration.jwt,
        nextToken: configuration.nextToken,
      }),
    });
    expect(result.statusCode).toBe(200);
    const body = JSON.parse(result.body) as ResponseBody;
    expect(body).toEqual({
      jwt: expect.any(String),
      nextToken: expect.any(String),
      limitUpdated: true,
    });
    expectValidJwt(body.jwt!);
    return {
      jwt: body.jwt!,
      nextToken: body.nextToken!,
      initialFrom: configuration.jwt!,
    };
  }

  it.each([
    'absent token',
    'empty token',
    'ack-loss',
    'notification failure',
  ])('atomically completes and acknowledges duplicates without resetting state (%s)', async (kind) => {
    if (kind === 'empty token') await consul.kv.set(K.NEXT_TOKEN, '');
    const input = {
      ...(await initialRelay()),
      publicKey: kind === 'absent token' ? undefined : relayPublicKey,
    };
    const indices = Object.fromEntries(
      [...Object.keys(consul.snapshot()), K.NEXT_TOKEN].map((key) => [
        key,
        consul.index(key),
      ]),
    );
    const before = consul.snapshot();
    const writeFrom = consul.writes.length;
    const sequentialWrite = vi.spyOn(consul.kv, 'set');
    if (kind === 'ack-loss') {
      consul.fault = { key: K.HP_LICENSE_JWT, mode: 'ack-loss' };
    }
    redis.failPublish = kind === 'notification failure';

    await expect(caller.submitRelay(input)).resolves.toEqual({ success: true });

    const installed = {
      [K.HP_LICENSE_JWT]: input.jwt,
      [K.NEXT_TOKEN]: input.nextToken,
      [K.HP_LICENSE_ID]: licenseId,
      [K.HP_LICENSE_SYNC_STATUS]: Status.SYNCED,
      LICENSE_PUBLIC_KEY: input.publicKey ?? publicKey,
    };
    expect(consul.snapshot()).toEqual(installed);
    expect(consul.fault).toBeUndefined();
    const committed = consul.transactions.filter(({ committed }) => committed);
    expect(committed).toHaveLength(1);
    expect(committed[0].operations).toHaveLength(5);
    expect(committed[0].operations).toEqual(
      expect.arrayContaining(
        Object.entries(installed).map(([Key, value]) => ({
          KV: {
            Verb: 'cas',
            Key,
            Index: indices[Key],
            Value: Buffer.from(value).toString('base64'),
            ...(Key === K.HP_LICENSE_SYNC_STATUS ? { Flags: 0 } : {}),
          },
        })),
      ),
    );
    const changed = Object.entries(installed).filter(
      ([key, value]) => before[key] !== value,
    );
    expect(committed[0].changedKeys).toEqual(changed.map(([key]) => key));
    for (const [key, value] of Object.entries(installed)) {
      expect(consul.index(key)).toBe(
        before[key] === value ? indices[key] : consul.index(K.HP_LICENSE_JWT),
      );
    }
    expect(redis.publications).toHaveLength(redis.failPublish ? 0 : 1);

    redis.failPublish = false;
    await expect(caller.submitRelay(input)).resolves.toEqual({ success: true });
    expect(consul.snapshot()).toEqual(installed);
    expect(consul.writes.slice(writeFrom)).toEqual(
      changed.map(([key, value]) => ({ key, value })),
    );
    expect(
      consul.transactions.filter(({ committed }) => committed),
    ).toHaveLength(1);
    expect(sequentialWrite).not.toHaveBeenCalled();
    await expectSynced();

    expect((await performHeartbeat(context.redisClient)).success).toBe(true);
    expect(exchanges.map(({ request }) => request.phase)).toEqual([1, 2]);
    expect(exchanges[0].request).toEqual({
      phase: 1,
      licenseId,
      jwt: input.jwt,
      nextToken: input.nextToken,
    });
    expect(consul.value(K.NEXT_TOKEN)).not.toBe(input.nextToken);
    await expectSynced();
    const advanced = consul.snapshot();
    const writes = consul.writes.length;
    await expect(caller.submitRelay(input)).rejects.toMatchObject({
      code: 'CONFLICT',
    });
    expect(consul.snapshot()).toEqual(advanced);
    expect(consul.writes).toHaveLength(writes);
  });

  describe.each([false, true])('state changes during CAS: %s', (concurrent) => {
    it.each([
      ['reissued source', K.HP_LICENSE_JWT, otherJwt],
      ['different license', K.HP_LICENSE_JWT, replacementJwt],
      ['established token', K.NEXT_TOKEN, T0],
      ['revocation', K.HP_LICENSE_SYNC_STATUS, Status.REVOKED],
    ])('preserves %s rather than applying a late initial completion', async (_kind, key, value) => {
      const input = await initialRelay();
      const before = consul.snapshot();
      const centralBefore = db.license;
      if (concurrent) {
        consul.beforeNextWrite = () => consul.kv.set(key, value);
      } else {
        await consul.kv.set(key, value);
      }

      await expect(caller.submitRelay(input)).rejects.toMatchObject({
        code: 'CONFLICT',
      });

      expect(consul.beforeNextWrite).toBeUndefined();
      expect(consul.snapshot()).toEqual({ ...before, [key]: value });
      expect(consul.writes).toEqual([{ key, value }]);
      expect(manager.getRawJwt()).toBe(consul.value(K.HP_LICENSE_JWT));
      expect(manager.getNextToken()).toBe(consul.value(K.NEXT_TOKEN));
      expect(manager.getHintStatus()).toBe(
        consul.value(K.HP_LICENSE_SYNC_STATUS),
      );
      expect(redis.publications).toEqual([]);
      expect(db.license).toEqual(centralBefore);
      expect(fetch).not.toHaveBeenCalled();
    });
  });

  it.each([
    [
      'invalid signature',
      { jwt: jwt.sign(originalPayload, untrustedKey, { algorithm: 'ES256' }) },
      'BAD_REQUEST',
    ],
    ...[0, 1].map(
      (exp) =>
        [
          `expired JWT (exp: ${exp})`,
          {
            jwt: jwt.sign({ ...originalPayload, exp }, privateKey, {
              algorithm: 'ES256',
            }),
          },
          'BAD_REQUEST',
        ] as const,
    ),
    ['stale captured JWT', { initialFrom: otherJwt }, 'CONFLICT'],
    ['non-exact captured JWT', { initialFrom: ` ${J0}\n` }, 'CONFLICT'],
    ['malformed captured JWT', { initialFrom: 'not-a-jwt' }, 'CONFLICT'],
    [
      'invalid JSON captured JWT',
      { initialFrom: malformedJsonJwt },
      'CONFLICT',
    ],
    ['different target ID', { jwt: replacementJwt }, 'CONFLICT'],
    ['different source ID', { initialFrom: replacementJwt }, 'CONFLICT'],
    ['mixed markers', { preparedFrom: J0 }, 'BAD_REQUEST'],
    ['mixed empty marker', { preparedFrom: '' }, 'BAD_REQUEST'],
    ['invalid public key', { publicKey: 'not-a-key' }, 'BAD_REQUEST'],
    ['empty formatted public key', { publicKey: '""' }, 'BAD_REQUEST'],
  ] as const)('rejects %s without durable writes', async (_kind, patch, code) => {
    const input = await initialRelay();
    const before = consul.snapshot();
    await expect(
      caller.submitRelay({ ...input, ...patch }),
    ).rejects.toMatchObject({ code });
    expect(consul.snapshot()).toEqual(before);
    expect(consul.writes).toEqual([]);
    expect(redis.publications).toEqual([]);
    expect(db.license.isRevoked).toBe(false);
  });

  it.each([
    'jwt',
    'nextToken',
    'initialFrom',
    'publicKey',
  ] as const)('rejects empty or whitespace-only %s in the initial shape', async (field) => {
    const input = await initialRelay();
    const before = consul.snapshot();
    for (const value of ['', ' \n ']) {
      await expect(
        caller.submitRelay({ ...input, [field]: value }),
      ).rejects.toMatchObject({
        code: 'BAD_REQUEST',
      });
    }
    expect(consul.snapshot()).toEqual(before);
    expect(consul.writes).toEqual([]);
    expect(redis.publications).toEqual([]);
  });

  it('still accepts the legacy shape with an empty token and optional key', async () => {
    await expect(
      caller.submitRelay({ jwt: J0, nextToken: '', publicKey: '' }),
    ).resolves.toEqual({ success: true });
    expect(consul.value(K.HP_LICENSE_JWT)).toBe(J0);
    expect(consul.value(K.NEXT_TOKEN)).toBe('');
    expect(manager.getNextToken()).toBeNull();
    expect(manager.getHintStatus()).toBe(Status.SYNCED);
  });
});

describe('coherent courier configuration', () => {
  it('uses the persisted JWT identity after a replica misses a replacement notification', async () => {
    const replacementId = 'phase2-replacement-license';
    const replacementJwt = jwt.sign(
      { ...originalPayload, licenseId: replacementId },
      privateKey,
      { algorithm: 'ES256' },
    );
    const replacementToken = 'replacement-predecessor';
    await consul.kv.set(K.HP_LICENSE_JWT, replacementJwt);
    await consul.kv.set(K.NEXT_TOKEN, replacementToken);
    // Neither stale replica memory nor the separately indexed ID may supply the request ID.
    expect((await caller.status()).licenseId).toBe(licenseId);
    expect(consul.value(K.HP_LICENSE_ID)).toBe(licenseId);
    const configuration = await caller.getDeploymentConfig();
    expect(configuration).toEqual({
      licenseId: replacementId,
      jwt: replacementJwt,
      nextToken: replacementToken,
      syncStatusIndex: consul.index(K.HP_LICENSE_SYNC_STATUS),
    });

    services.db = db = new DurableRtdb(replacementId, privateKey, {
      ...db.license,
      expectedNextToken: replacementToken,
      pendingNextToken: null,
    });
    const prepared = await centralHeartbeat({
      body: JSON.stringify({
        phase: 1,
        licenseId: configuration.licenseId,
        jwt: configuration.jwt,
        nextToken: configuration.nextToken,
      }),
    });
    expect(prepared.statusCode).toBe(200);
    const candidate = JSON.parse(prepared.body).nextToken as string;
    await caller.prepareRelay({
      jwt: configuration.jwt!,
      previousNextToken: configuration.nextToken!,
      nextToken: candidate,
    });
    const committed = await centralHeartbeat({
      body: JSON.stringify({
        phase: 2,
        licenseId: configuration.licenseId,
        jwt: configuration.jwt,
        nextToken: candidate,
      }),
    });
    expect(committed.statusCode).toBe(200);
    await caller.submitRelay({
      jwt: JSON.parse(committed.body).jwt,
      nextToken: candidate,
      preparedFrom: configuration.jwt!,
    });
    expect((await caller.status()).licenseId).toBe(replacementId);
    expect(manager.getHintStatus()).toBe(Status.SYNCED);
    expect(consul.value(K.HP_LICENSE_ID)).toBe(replacementId);
    expect(consul.value(K.NEXT_TOKEN)).toBe(candidate);
    expect(db.license.isRevoked).toBe(false);
  });

  it.each([
    ['absent', ''],
    ['malformed', 'not-a-jwt'],
    ['invalid JSON', malformedJsonJwt],
    [
      'missing identity',
      jwt.sign({ ...originalPayload, licenseId: undefined }, privateKey, {
        algorithm: 'ES256',
      }),
    ],
  ])('does not substitute the indexed license ID for a JWT that is %s', async (_kind, token) => {
    await consul.kv.set(K.HP_LICENSE_JWT, token);
    const before = consul.snapshot();
    const writes = structuredClone(consul.writes);
    const configuration = await caller.getDeploymentConfig();
    expect(configuration).toEqual({
      licenseId: null,
      jwt: token || null,
      nextToken: T0,
      syncStatusIndex: consul.index(K.HP_LICENSE_SYNC_STATUS),
    });
    await expect(performHeartbeat(context.redisClient)).resolves.toMatchObject({
      success: false,
      message: 'Not provisioned yet',
    });
    expect(consul.snapshot()).toEqual(before);
    expect(consul.writes).toEqual(writes);
    expect(consul.value(K.HP_LICENSE_ID)).toBe(licenseId);
    expect(db.license.isRevoked).toBe(false);
    expect(exchanges).toEqual([]);
    expect(fetch).not.toHaveBeenCalled();
    expect(redis.publications).toEqual([]);
  });

  it('releases the heartbeat lock immediately for invalid persisted JSON', async () => {
    expect(() => jwt.decode(malformedJsonJwt)).toThrow();
    await consul.kv.set(K.HP_LICENSE_JWT, malformedJsonJwt);
    const before = consul.snapshot();
    const writes = structuredClone(consul.writes);
    const centralBefore = db.license;
    const held = consul.deferNextRead();
    const heartbeat = performHeartbeat(context.redisClient).catch(
      (error: unknown) => error,
    );
    const expected = {
      success: false,
      requiresCourier: false,
      message: 'Not provisioned yet',
    };
    try {
      await held.captured;
      expect(await redis.get(HP_LICENCE_HEARTBEAT_LOCK_KEY)).toBe('1');
      held.release();
      const result = await heartbeat;
      expect(await redis.get(HP_LICENCE_HEARTBEAT_LOCK_KEY)).toBeNull();
      expect(result).toEqual(expected);
    } finally {
      held.release();
      await heartbeat;
    }
    await expect(performHeartbeat(context.redisClient)).resolves.toEqual(
      expected,
    );
    await expect(caller.sync()).rejects.toMatchObject({
      code: 'BAD_REQUEST',
      message: 'Not provisioned yet',
    });
    expect(await redis.get(HP_LICENCE_HEARTBEAT_LOCK_KEY)).toBeNull();
    expect(manager.getStatus()).toBe(Status.LOCKED);
    expect(consul.snapshot()).toEqual(before);
    expect(consul.writes).toEqual(writes);
    expect(redis.publications).toEqual([]);
    expect(fetch).not.toHaveBeenCalled();
    expect(db.license).toEqual(centralBefore);
    expect(db.transactions).toEqual([]);
  });
});

describe('provision installs a different durable license identity', () => {
  const replacementId = 'phase2-provision-replacement';
  const replacementJwt = jwt.sign(
    {
      ...originalPayload,
      licenseId: replacementId,
      max_agents: 31,
      customerName: 'Replacement license',
    },
    privateKey,
    { algorithm: 'ES256' },
  );
  const replacementPublicKey = publicKey.replace(
    /([A-Za-z0-9+/=])\n(?=[A-Za-z0-9+/=])/g,
    '$1',
  );

  async function expectRejectedProvision(
    input: Parameters<typeof caller.provision>[0],
    code: 'CONFLICT' | 'BAD_REQUEST' = 'CONFLICT',
  ) {
    const snapshot = () => ({
      durable: consul.snapshot(),
      memory: structuredClone(manager),
      writes: structuredClone(consul.writes),
      publications: structuredClone(redis.publications),
      central: db.license,
      centralTransactions: structuredClone(db.transactions),
      exchanges: structuredClone(exchanges),
      fetchCalls: vi.mocked(fetch).mock.calls.length,
    });
    const before = snapshot();
    const readFrom = consul.transactions.length;
    // Validation must not hydrate RAM, even if the durable values are identical.
    const mutations = [
      vi.spyOn(manager, 'setPublicKey'),
      vi.spyOn(manager, 'updateState'),
      vi.spyOn(manager, 'setHintStatus'),
      vi.spyOn(manager, 'publishSnapshot'),
      vi.spyOn(manager, 'recordLocalRevocation'),
      vi.spyOn(manager, 'invalidatePublications'),
      vi.spyOn(manager, 'setBootstrapPublicKey'),
      vi.spyOn(manager, 'setSoftAgentLimit'),
      vi.spyOn(consul.kv, 'set'),
      vi.spyOn(redis, 'publish'),
    ];
    try {
      await expect(caller.provision(input)).rejects.toMatchObject({
        code,
        ...(code === 'CONFLICT'
          ? {
              message:
                'This license is already installed. Use Sync License to refresh its entitlements.',
            }
          : {}),
      });
      for (const mutation of mutations) expect(mutation).not.toHaveBeenCalled();
    } finally {
      for (const mutation of mutations) mutation.mockRestore();
    }
    expect(snapshot()).toEqual(before);
    const reads = consul.transactions.slice(readFrom);
    expect(reads.length).toBeGreaterThan(0);
    for (const read of reads) {
      expect(read.consistent).toBe(true);
      expect(read.committed).toBe(false);
      expect(
        read.operations.every(({ KV }) => KV.Verb === 'get-or-empty'),
      ).toBe(true);
      expect(read.operations.map(({ KV }) => KV.Key).sort()).toEqual(
        Object.keys(before.durable).sort(),
      );
    }
  }

  function expectInstalled(
    input: { jwt: string; nextToken?: string; publicKey: string },
    indices: Record<string, number>,
    previous: Record<string, string>,
  ) {
    const token = input.jwt.trim();
    const payload = jwt.verify(token, input.publicKey, {
      algorithms: ['ES256'],
    }) as jwt.JwtPayload;
    const hint = input.nextToken ? Status.SYNCED : Status.COURIER_REQUIRED;
    const fields = {
      [K.HP_LICENSE_JWT]: token,
      [K.NEXT_TOKEN]: input.nextToken ?? '',
      [K.HP_LICENSE_SYNC_STATUS]: hint,
      [K.HP_LICENSE_ID]: payload.licenseId as string,
      LICENSE_PUBLIC_KEY: input.publicKey,
    };
    expect(consul.snapshot()).toEqual(fields);
    const committed = consul.transactions.filter(({ committed }) => committed);
    expect(committed.at(-1)?.operations).toHaveLength(5);
    expect(committed.at(-1)?.operations).toEqual(
      expect.arrayContaining(
        Object.entries(fields).map(([Key, value]) => ({
          KV: {
            Verb: 'cas',
            Key,
            Index: indices[Key] ?? 0,
            Value: Buffer.from(value).toString('base64'),
            ...(Key === K.HP_LICENSE_SYNC_STATUS ? { Flags: 0 } : {}),
          },
        })),
      ),
    );
    const changed = Object.entries(fields).filter(
      ([key, value]) => previous[key] !== value,
    );
    expect(committed.at(-1)?.changedKeys).toEqual(changed.map(([key]) => key));
    for (const [key, value] of Object.entries(fields)) {
      expect(consul.index(key)).toBe(
        previous[key] === value ? indices[key] : consul.index(K.HP_LICENSE_JWT),
      );
    }
    expect(manager.getRawJwt()).toBe(token);
    expect(manager.getNextToken()).toBe(input.nextToken ?? null);
    expect(manager.getPublicKey()).toBe(input.publicKey);
    expect(manager.getHintStatus()).toBe(hint);
    expect(manager.getStatus()).toBe(Status.SYNCED);
    expect(manager.getLicenseId()).toBe(payload.licenseId);
    expect(manager.getMaxAgents()).toBe(payload.max_agents);
    expect(manager.getCustomerName()).toBe(payload.customerName);
    expect(manager.getExpiryDate()).toBe(payload.exp! * 1000);
    return changed.length;
  }

  it('rejects exact and reissued same-ID JWTs without clearing even a REVOKED hint', async () => {
    expect(otherJwt).not.toBe(J0);
    for (const [token, hint] of [
      [J0, Status.COURIER_REQUIRED],
      [otherJwt, Status.REVOKED],
    ] as const) {
      expect(
        jwt.verify(token, publicKey, { algorithms: ['ES256'] }),
      ).toMatchObject({ licenseId });
      await consul.kv.set(K.HP_LICENSE_SYNC_STATUS, hint);
      manager.setHintStatus(hint);
      await expectRejectedProvision({
        jwt: token,
        publicKey: replacementPublicKey,
      });
    }
  });

  it('does not let an explicit nextToken bypass the same-ID conflict or clear REVOKED', async () => {
    await consul.kv.set(K.HP_LICENSE_SYNC_STATUS, Status.REVOKED);
    manager.setHintStatus(Status.REVOKED);
    await expectRejectedProvision({
      jwt: otherJwt,
      nextToken: 'cannot-reset-the-installed-predecessor',
      publicKey: replacementPublicKey,
    });
  });

  it('rejects the initial JWT after a real heartbeat and heartbeats again with the preserved token', async () => {
    expect((await performHeartbeat(context.redisClient)).success).toBe(true);
    await expectSynced();
    const currentJwt = consul.value(K.HP_LICENSE_JWT)!;
    const preservedToken = consul.value(K.NEXT_TOKEN)!;
    expect(currentJwt).not.toBe(J0);
    expect(preservedToken).not.toBe(T0);

    await expectRejectedProvision({ jwt: J0 });

    expect((await performHeartbeat(context.redisClient)).success).toBe(true);
    expect(exchanges.map(({ request }) => request.phase)).toEqual([1, 2, 1, 2]);
    expect(exchanges[2].request).toEqual({
      phase: 1,
      licenseId,
      jwt: currentJwt,
      nextToken: preservedToken,
    });
    await expectSynced();
  });

  it('uses the durable JWT ID despite stale replica RAM and a stale indexed license ID', async () => {
    await consul.kv.set(K.HP_LICENSE_JWT, replacementJwt);
    await consul.kv.set(K.NEXT_TOKEN, 'durable-replacement-predecessor');
    await consul.kv.set(K.HP_LICENSE_SYNC_STATUS, Status.REVOKED);
    await consul.kv.set('LICENSE_PUBLIC_KEY', replacementPublicKey);
    expect(manager.getRawJwt()).toBe(J0);
    expect(manager.getNextToken()).toBe(T0);
    expect(manager.getLicenseId()).toBe(licenseId);
    expect(consul.value(K.HP_LICENSE_ID)).toBe(licenseId);

    await expectRejectedProvision({ jwt: replacementJwt });
  });

  it('rejects missing, non-string, empty IDs and forged signatures before writes or RAM hydration', async () => {
    manager.updateState(otherJwt, 'stale-replica-predecessor');
    manager.setHintStatus(Status.REVOKED);
    const invalidTokens = [undefined, 42, '', '   '].map((id) =>
      jwt.sign({ ...originalPayload, licenseId: id }, privateKey, {
        algorithm: 'ES256',
      }),
    );
    invalidTokens.push(
      jwt.sign(originalPayload, untrustedKey, { algorithm: 'ES256' }),
      malformedJsonJwt,
    );
    for (const token of invalidTokens) {
      await expectRejectedProvision(
        { jwt: token, publicKey: replacementPublicKey },
        'BAD_REQUEST',
      );
    }
  });

  it('atomically replaces a different ID, clearing an omitted token but honoring an explicit new token', async () => {
    const centralBefore = db.license;
    const sequentialWrite = vi.spyOn(consul.kv, 'set');
    for (const input of [
      { jwt: ` ${replacementJwt}\n`, publicKey: replacementPublicKey },
      { jwt: J0, nextToken: 'explicit-new-license-token', publicKey },
    ]) {
      const previous = consul.snapshot();
      const indices = Object.fromEntries(
        Object.keys(previous).map((key) => [key, consul.index(key)]),
      );
      const writeFrom = consul.writes.length;
      const publishFrom = redis.publications.length;
      const commitCount = consul.transactions.filter(
        ({ committed }) => committed,
      ).length;
      await expect(caller.provision(input)).resolves.toEqual({ success: true });
      const changed = expectInstalled(input, indices, previous);
      expect(consul.writes).toHaveLength(writeFrom + changed);
      expect(
        consul.transactions.filter(({ committed }) => committed),
      ).toHaveLength(commitCount + 1);
      expect(redis.publications.slice(publishFrom)).toEqual([
        { channel: HP_LICENCE_MEMORY_REFRESH_KEY, message: '1' },
      ]);
    }
    expect(sequentialWrite).not.toHaveBeenCalled();
    expect(fetch).not.toHaveBeenCalled();
    expect(db.license).toEqual(centralBefore);
    expect(db.transactions).toEqual([]);
  });

  it.each([
    false,
    true,
  ])('repairs invalid persisted JSON with a verified replacement (token: %s)', async (withToken) => {
    await consul.kv.set(K.HP_LICENSE_JWT, malformedJsonJwt);
    expect(manager.getRawJwt()).toBe(J0);
    expect(manager.getLicenseId()).toBe(licenseId);
    expect(consul.value(K.HP_LICENSE_ID)).toBe(licenseId);
    const previous = consul.snapshot();
    const indices = Object.fromEntries(
      Object.keys(previous).map((key) => [key, consul.index(key)]),
    );
    const writeFrom = consul.writes.length;
    const centralBefore = db.license;
    const sequentialWrite = vi.spyOn(consul.kv, 'set');
    const input = {
      jwt: replacementJwt,
      publicKey: replacementPublicKey,
      nextToken: withToken ? 'repaired-license-token' : undefined,
    };
    await expect(caller.provision(input)).resolves.toEqual({ success: true });
    const changed = expectInstalled(input, indices, previous);
    expect(consul.writes).toHaveLength(writeFrom + changed);
    expect(
      consul.transactions.filter(({ committed }) => committed),
    ).toHaveLength(1);
    expect(redis.publications).toEqual([
      { channel: HP_LICENCE_MEMORY_REFRESH_KEY, message: '1' },
    ]);
    expect(sequentialWrite).not.toHaveBeenCalled();
    expect(fetch).not.toHaveBeenCalled();
    expect(db.license).toEqual(centralBefore);
    expect(db.transactions).toEqual([]);
  });

  it('allows first activation with atomic index-zero CAS when no durable keys or RAM license exist', async () => {
    services.consul = consul = new DurableConsul({});
    Reflect.deleteProperty(LicenseManager, 'instance');
    manager = LicenseManager.getInstance();
    expect(manager.getRawJwt()).toBeNull();
    expect(manager.getPublicKey()).toBeNull();
    expect(manager.getStatus()).toBe(Status.LOCKED);
    const centralBefore = db.license;
    const input = { jwt: J0, publicKey };

    await expect(caller.provision(input)).resolves.toEqual({ success: true });

    expectInstalled(input, {}, {});
    expect(consul.writes).toHaveLength(5);
    expect(
      consul.transactions.filter(({ committed }) => committed),
    ).toHaveLength(1);
    expect(redis.publications).toEqual([
      { channel: HP_LICENCE_MEMORY_REFRESH_KEY, message: '1' },
    ]);
    expect(fetch).not.toHaveBeenCalled();
    expect(db.license).toEqual(centralBefore);
    expect(db.transactions).toEqual([]);
  });

  it('cannot reset a candidate advance or another installation that wins between the read and CAS', async () => {
    const candidate = await phaseOne();
    const initial = consul.snapshot();
    const centralBefore = db.license;
    const centralTransactions = structuredClone(db.transactions);
    consul.beforeNextWrite = () =>
      caller.prepareRelay({
        jwt: J0,
        previousNextToken: T0,
        nextToken: candidate,
      });

    await expect(
      caller.provision({ jwt: replacementJwt }),
    ).rejects.toMatchObject({
      code: 'CONFLICT',
    });

    expect(consul.beforeNextWrite).toBeUndefined();
    expectPrepared(candidate);
    expect(consul.snapshot()).toEqual({
      ...initial,
      [K.NEXT_TOKEN]: candidate,
    });
    expect(consul.writes).toEqual([{ key: K.NEXT_TOKEN, value: candidate }]);
    expect(redis.publications).toEqual([]);

    const winner = {
      jwt: jwt.sign(
        { ...originalPayload, licenseId: 'phase2-concurrent-installation' },
        privateKey,
        { algorithm: 'ES256' },
      ),
      nextToken: 'concurrent-installation-predecessor',
      publicKey: replacementPublicKey,
    };
    const previous = consul.snapshot();
    const indices = Object.fromEntries(
      Object.keys(previous).map((key) => [key, consul.index(key)]),
    );
    consul.beforeNextWrite = () => caller.provision(winner);

    await expect(
      caller.provision({ jwt: replacementJwt }),
    ).rejects.toMatchObject({
      code: 'CONFLICT',
    });

    expect(consul.beforeNextWrite).toBeUndefined();
    expectInstalled(winner, indices, previous);
    expect(consul.writes).toHaveLength(6);
    expect(consul.writes).not.toContainEqual({
      key: K.HP_LICENSE_JWT,
      value: replacementJwt,
    });
    expect(
      consul.transactions.filter(({ committed }) => committed),
    ).toHaveLength(2);
    expect(redis.publications).toEqual([
      { channel: HP_LICENCE_MEMORY_REFRESH_KEY, message: '1' },
    ]);
    expect(fetch).not.toHaveBeenCalled();
    expect(db.license).toEqual(centralBefore);
    expect(db.transactions).toEqual(centralTransactions);
  });
});

describe('atomic local license publication across real readers and mutations', () => {
  const replacement = {
    jwt: jwt.sign(
      {
        ...originalPayload,
        licenseId: 'hydration-replacement',
        max_agents: 31,
      },
      rotatedKeys.privateKey,
      { algorithm: 'ES256' },
    ),
    nextToken: 'hydration-replacement-token',
    publicKey: rotatedKeys.publicKey,
  };

  function memory(replica = manager) {
    return {
      publicKey: replica.getPublicKey(),
      jwt: replica.getRawJwt(),
      nextToken: replica.getNextToken(),
      hintStatus: replica.getHintStatus(),
      status: replica.getStatus(),
    };
  }

  async function failRevocation(replica?: LicenseManager) {
    const before = consul.snapshot();
    consul.fault = { key: K.HP_LICENSE_SYNC_STATUS, mode: 'before-write' };
    await expect(
      replica
        ? recordRevocation(
            consul as unknown as Parameters<typeof recordRevocation>[0],
            replica,
          )
        : caller.reportRevocation(),
    ).rejects.toThrow('before-write');
    expect(consul.snapshot()).toEqual(before);
    expect((replica ?? manager).getStatus()).toBe(Status.REVOKED);
  }

  async function prepareCourier() {
    const config = await caller.getDeploymentConfig();
    const first = await central(1, config.nextToken!, config.jwt!);
    expect(first.status).toBe(200);
    await caller.prepareRelay({
      jwt: config.jwt!,
      previousNextToken: config.nextToken!,
      nextToken: first.body.nextToken!,
      syncStatusIndex: config.syncStatusIndex,
    });
    return {
      preparedFrom: config.jwt!,
      nextToken: first.body.nextToken!,
      syncStatusIndex: config.syncStatusIndex,
    };
  }

  function deferConfirmation() {
    const ready = deferred<ReturnType<DurableConsul['deferNextRead']>>();
    consul.beforeNextWrite = () => ready.resolve(consul.deferNextRead());
    return ready.promise;
  }

  describe('source-bound revocation across different-license replacements', () => {
    async function persistCandidate(
      input: Partial<
        typeof replacement & { licenseId: string; hintStatus: Status }
      > = {},
    ) {
      const candidate = {
        ...replacement,
        licenseId: 'hydration-replacement',
        hintStatus: Status.SYNCED,
        ...input,
      };
      await consul.transaction.create(
        Object.entries({
          [K.HP_LICENSE_JWT]: candidate.jwt,
          [K.NEXT_TOKEN]: candidate.nextToken,
          [K.HP_LICENSE_ID]: candidate.licenseId,
          [K.HP_LICENSE_SYNC_STATUS]: candidate.hintStatus,
          LICENSE_PUBLIC_KEY: candidate.publicKey,
        }).map(([Key, value]) => ({
          KV: {
            Verb: 'set',
            Key,
            Value: Buffer.from(value).toString('base64'),
          },
        })),
      );
      return candidate;
    }

    function candidateJwt(
      overrides: jwt.JwtPayload = {},
      key: jwt.Secret = rotatedKeys.privateKey,
    ) {
      const payload: jwt.JwtPayload = {
        ...originalPayload,
        licenseId: 'hydration-replacement',
        ...overrides,
      };
      if (payload.exp === undefined) delete payload.exp;
      return jwt.sign(payload, key, { algorithm: 'ES256' });
    }

    const source = {
      jwt: J0,
      nextToken: T0,
      publicKey,
      licenseId,
      hintStatus: Status.COURIER_REQUIRED,
    };
    const sameKey = { jwt: candidateJwt({}, privateKey), publicKey };
    const outsideGrace = {
      last_heartbeat_timestamp: startedAt - 8 * 24 * 60 * 60 * 1000,
    };
    const revoked = { hintStatus: Status.REVOKED, status: Status.REVOKED };

    function holdRevocationWrite(jwtIndex: number, readOutage = false) {
      const started = deferred();
      const release = deferred();
      const create = vi.isMockFunction(consul.transaction.create)
        ? consul.transaction.create.getMockImplementation()!
        : consul.transaction.create;
      let held = false;
      let failedReads = 0;
      vi.spyOn(consul.transaction, 'create').mockImplementation(
        async (operations, options) => {
          if (
            held &&
            readOutage &&
            failedReads < 2 &&
            operations.every(({ KV }) => KV.Verb === 'get-or-empty')
          ) {
            failedReads++;
            throw new Error('Late revocation read unavailable');
          }
          const sourceIndex = operations.find(
            ({ KV }) => KV.Key === K.HP_LICENSE_JWT,
          )?.KV.Index;
          if (
            !held &&
            sourceIndex === jwtIndex &&
            operations.some(
              ({ KV }) =>
                KV.Key === K.HP_LICENSE_SYNC_STATUS &&
                KV.Value === Buffer.from(Status.REVOKED).toString('base64'),
            )
          ) {
            started.resolve();
            await release.promise;
            held = true;
            throw new Error('Held revocation write failed');
          }
          return create(operations, options);
        },
      );
      return {
        started: started.promise,
        release: () => release.resolve(),
        failedReads: () => failedReads,
      };
    }

    async function failSourceDiscovery() {
      const reads = vi
        .spyOn(consul.transaction, 'create')
        .mockRejectedValueOnce(new Error('Source discovery unavailable'))
        .mockRejectedValueOnce(new Error('Source discovery unavailable'));
      await expect(caller.reportRevocation()).rejects.toThrow(
        'Source discovery unavailable',
      );
      expect(reads).toHaveBeenCalledTimes(2);
      reads.mockRestore();
      expect(manager.getStatus()).toBe(Status.REVOKED);
    }

    it.each<[string, Parameters<typeof persistCandidate>[0], string?]>([
      [
        'same-ID reissue',
        {
          ...source,
          jwt: candidateJwt(
            { licenseId, last_heartbeat_timestamp: startedAt },
            privateKey,
          ),
        },
      ],
      [
        'same-ID key rotation',
        {
          ...source,
          jwt: candidateJwt({ licenseId }),
          publicKey: rotatedKeys.publicKey,
        },
      ],
      ['same-ID token change', { ...source, nextToken: 'changed-token' }],
      ['same-ID hint change', { ...source, hintStatus: Status.SYNCED }],
      ['indexed-ID mismatch', { licenseId }],
      ['forged signature', { jwt: candidateJwt({}, untrustedKey) }],
      ['wrong key', { publicKey }],
      ['expiry zero', { jwt: candidateJwt({ exp: 0 }) }],
      ['expired', { jwt: candidateJwt({ exp: 1 }) }],
      ['outside grace', { jwt: candidateJwt(outsideGrace) }],
      ['REVOKED hint', { hintStatus: Status.REVOKED }],
      ...[
        K.HP_LICENSE_JWT,
        K.NEXT_TOKEN,
        K.HP_LICENSE_ID,
        K.HP_LICENSE_SYNC_STATUS,
        'LICENSE_PUBLIC_KEY',
      ].map((key): [string, typeof sameKey, string] => [
        `missing ${key}`,
        sameKey,
        key,
      ]),
    ])('retains the old barrier after hydrating %s, then admits a corrected replacement', async (_kind, input, missing) => {
      await failRevocation();
      await persistCandidate(input);
      if (missing) await consul.kv.del(missing);
      const durable = consul.snapshot();
      const state = await readLicenseState(consul, manager);
      if (missing) expect(state.indices[missing]).toBe(0);
      expect(memory()).toMatchObject({
        jwt: durable[K.HP_LICENSE_JWT] ?? null,
        ...revoked,
      });
      await syncLicenseAndSoftLimit(consul, manager);
      expect(manager.getStatus()).toBe(Status.REVOKED);
      expect(consul.snapshot()).toEqual(durable);

      await persistCandidate({
        nextToken: '',
        hintStatus: Status.COURIER_REQUIRED,
      });
      await caller.getDeploymentConfig();
      const healed = memory();
      expect(healed).toEqual({
        ...replacement,
        nextToken: null,
        hintStatus: Status.COURIER_REQUIRED,
        status: Status.SYNCED,
      });
      await syncLicenseAndSoftLimit(consul, manager);
      expect(memory()).toEqual(healed);
      expect(consul.value(K.NEXT_TOKEN)).toBe('');
      expect(consul.index(K.NEXT_TOKEN)).toBeGreaterThan(0);
    });

    it.each([
      expiry,
      undefined,
    ])('accepts older same-key Y with an empty token (exp: %s)', async (exp) => {
      await failRevocation();
      const candidate = await persistCandidate({
        publicKey,
        jwt: candidateJwt(
          {
            exp,
            last_heartbeat_timestamp:
              originalPayload.last_heartbeat_timestamp - 1000,
          },
          privateKey,
        ),
        nextToken: '',
        hintStatus: Status.COURIER_REQUIRED,
      });
      await syncLicenseAndSoftLimit(consul, manager);
      expect(memory()).toEqual({
        publicKey,
        jwt: candidate.jwt,
        nextToken: null,
        hintStatus: Status.COURIER_REQUIRED,
        status: Status.SYNCED,
      });
      expect(manager.getExpiryDate()).toBe(
        exp === undefined ? null : exp * 1000,
      );
      expect(consul.value(K.NEXT_TOKEN)).toBe('');
      expect(consul.index(K.NEXT_TOKEN)).toBeGreaterThan(0);
    });

    it.each([
      false,
      true,
    ])('binds reports to returned Y, not RAM/index X (stale index: %s)', async (staleIndex) => {
      await persistCandidate(staleIndex ? { licenseId } : {});
      expect(manager.getRawJwt()).toBe(J0);
      const held = consul.deferNextRead();
      const report = caller.reportRevocation().catch((error: unknown) => error);
      try {
        await held.captured;
        await syncLicenseAndSoftLimit(consul, manager);
        expect(memory()).toEqual({ ...replacement, ...revoked });
        consul.fault = { key: K.HP_LICENSE_SYNC_STATUS, mode: 'before-write' };
        held.release();
        expect(await report).toMatchObject({
          message: expect.stringContaining('before-write'),
        });
      } finally {
        held.release();
        await report;
      }
      expect(consul.value(K.HP_LICENSE_SYNC_STATUS)).toBe(Status.SYNCED);
      await persistCandidate();
      for (let refresh = 0; refresh < 2; refresh++) {
        await syncLicenseAndSoftLimit(consul, manager);
        expect(await caller.status()).toMatchObject({
          licenseId: 'hydration-replacement',
          ...revoked,
        });
      }
    });

    it('keeps failed source discovery unknown across passive replacements but permits local provisioning', async () => {
      const before = consul.snapshot();
      await failSourceDiscovery();
      expect(consul.snapshot()).toEqual(before);
      for (const id of ['hydration-replacement', 'unknown-scope-successor']) {
        await persistCandidate({
          jwt: candidateJwt({ licenseId: id }),
          licenseId: id,
        });
        await syncLicenseAndSoftLimit(consul, manager);
        expect(manager.getLicenseId()).toBe(id);
        expect(manager.getStatus()).toBe(Status.REVOKED);
      }
      await expect(caller.provision(replacement)).resolves.toEqual({
        success: true,
      });
      expect(manager.getStatus()).toBe(Status.SYNCED);
      expect(consul.value(K.HP_LICENSE_JWT)).toBe(replacement.jwt);
      await syncLicenseAndSoftLimit(consul, manager);
      expect(manager.getStatus()).toBe(Status.SYNCED);
    });

    it.each([
      false,
      true,
    ])('binds malformed source JSON as unknown (captured snapshot: %s)', async (captured) => {
      await consul.kv.set(K.HP_LICENSE_JWT, malformedJsonJwt);
      const previous = await readLicenseState(consul, manager);
      const before = consul.snapshot();
      consul.fault = { key: K.HP_LICENSE_SYNC_STATUS, mode: 'before-write' };
      await expect(
        captured
          ? recordRevocation(
              consul as unknown as Parameters<typeof recordRevocation>[0],
              manager,
              previous,
            )
          : caller.reportRevocation(),
      ).rejects.toThrow('before-write');
      expect(consul.snapshot()).toEqual(before);
      expect(manager.getStatus()).toBe(Status.REVOKED);
      await persistCandidate();
      await syncLicenseAndSoftLimit(consul, manager);
      expect(memory()).toEqual({ ...replacement, ...revoked });
    });

    it.each([
      false,
      true,
    ])('retires a bound replica X report before late I/O (read outage: %s)', async (readOutage) => {
      const observer = Reflect.construct(LicenseManager, []) as LicenseManager;
      const previous = await readLicenseState(consul, observer);
      const held = holdRevocationWrite(
        consul.index(K.HP_LICENSE_JWT),
        readOutage,
      );
      const recorded = vi.spyOn(observer, 'recordLocalRevocation');
      const report = recordRevocation(
        consul as unknown as Parameters<typeof recordRevocation>[0],
        observer,
        previous,
      ).catch((error: unknown) => error);
      try {
        await held.started;
        expect(observer.getStatus()).toBe(Status.REVOKED);
        await expect(caller.provision(replacement)).resolves.toEqual({
          success: true,
        });
        const durable = consul.snapshot();
        const winner = memory();
        await syncLicenseAndSoftLimit(consul, observer);
        expect(memory(observer)).toEqual(winner);
        expect(winner.status).toBe(Status.SYNCED);
        held.release();
        expect(await report).toBeInstanceOf(Error);
        expect(held.failedReads()).toBe(readOutage ? 2 : 0);
        if (readOutage)
          expect(recorded.mock.results.map(({ value }) => value)).toEqual([
            false,
          ]);
        await syncLicenseAndSoftLimit(consul, observer);
        expect(memory(observer)).toEqual(winner);
        expect(memory()).toEqual(winner);
        expect(consul.snapshot()).toEqual(durable);
      } finally {
        held.release();
        await report;
      }
    });

    it.each([
      'X first',
      'Y first',
    ])('preserves overlapping report ownership (%s)', async (order) => {
      // The late X error must reach local recording, not stop at an index conflict.
      const x = holdRevocationWrite(consul.index(K.HP_LICENSE_JWT), true);
      const recorded = vi.spyOn(manager, 'recordLocalRevocation');
      const reportX = caller
        .reportRevocation()
        .catch((error: unknown) => error);
      let y: ReturnType<typeof holdRevocationWrite> | undefined;
      let reportY: Promise<unknown> | undefined;
      try {
        await x.started;
        await persistCandidate();
        y = holdRevocationWrite(consul.index(K.HP_LICENSE_JWT));
        reportY = caller.reportRevocation().catch((error: unknown) => error);
        await y.started;
        const reports = [
          { gate: x, report: reportX },
          { gate: y, report: reportY },
        ];
        if (order === 'Y first') reports.reverse();
        const [first, last] = reports;
        first.gate.release();
        expect(await first.report).toBeInstanceOf(Error);
        expect(manager.getStatus()).toBe(Status.REVOKED);
        // A candidate for the still-pending source cannot clear that report's guard.
        await persistCandidate(order === 'X first' ? {} : source);
        await syncLicenseAndSoftLimit(consul, manager);
        expect(manager.getStatus()).toBe(Status.REVOKED);
        await persistCandidate();
        last.gate.release();
        expect(await last.report).toBeInstanceOf(Error);
        expect(x.failedReads()).toBe(2);
        expect(recorded.mock.results.map(({ value }) => value)).toEqual([
          true,
          true,
        ]);
      } finally {
        x.release();
        y?.release();
        await Promise.all([reportX, reportY]);
      }
      expect(consul.value(K.HP_LICENSE_SYNC_STATUS)).toBe(Status.SYNCED);
      for (let refresh = 0; refresh < 2; refresh++) {
        await syncLicenseAndSoftLimit(consul, manager);
        expect(memory()).toEqual({ ...replacement, ...revoked });
      }
      await persistCandidate({
        jwt: candidateJwt({ licenseId: 'overlap-successor-Z' }),
        licenseId: 'overlap-successor-Z',
      });
      await syncLicenseAndSoftLimit(consul, manager);
      expect(manager.getLicenseId()).toBe('overlap-successor-Z');
      expect(manager.getStatus()).toBe(Status.SYNCED);
      await syncLicenseAndSoftLimit(consul, manager);
      expect(manager.getStatus()).toBe(Status.SYNCED);
    });

    it.each([
      'durable',
      'RAM-only',
      'pending',
    ])('fences an old passive Y read with new %s revocation', async (kind) => {
      const observer = Reflect.construct(LicenseManager, []) as LicenseManager;
      await readLicenseState(consul, observer);
      await failRevocation(observer);
      await caller.provision(replacement);
      const held = consul.deferNextRead();
      const oldRead = readLicenseState(consul, observer);
      let gate: ReturnType<typeof holdRevocationWrite> | undefined;
      let report: Promise<unknown> | undefined;
      try {
        await held.captured;
        expect(observer.getRawJwt()).toBe(J0);
        if (kind === 'RAM-only') await failRevocation(observer);
        else {
          if (kind === 'pending')
            gate = holdRevocationWrite(consul.index(K.HP_LICENSE_JWT));
          report = recordRevocation(
            consul as unknown as Parameters<typeof recordRevocation>[0],
            observer,
          ).catch((error: unknown) => error);
          if (gate) await gate.started;
          else await report;
        }
        const winner = memory(observer);
        const durable = consul.snapshot();
        expect(winner).toEqual({ ...replacement, ...revoked });
        held.release();
        expect(await oldRead).toMatchObject({ jwt: replacement.jwt });
        expect(memory(observer)).toEqual(winner);
        expect(consul.snapshot()).toEqual(durable);
        gate?.release();
        if (gate) expect(await report).toBeInstanceOf(Error);
        await syncLicenseAndSoftLimit(consul, observer);
        expect(memory(observer)).toEqual(winner);
        expect(consul.value(K.HP_LICENSE_SYNC_STATUS)).toBe(
          kind === 'durable' ? Status.REVOKED : Status.SYNCED,
        );
      } finally {
        held.release();
        gate?.release();
        await Promise.all([oldRead, report]);
      }
    });

    it.each([
      ['known X', 'JWT write'],
      ['known X', 'Redis publish'],
      ['unknown', 'JWT write'],
      ['unknown', 'Redis publish'],
    ])('restores %s, not cached Y, after Phase 0 %s failure', async (origin, failure) => {
      if (origin === 'known X') await failRevocation();
      else await failSourceDiscovery();
      const stale = await persistCandidate({
        ...sameKey,
        jwt: candidateJwt(outsideGrace, privateKey),
        nextToken: '',
        hintStatus: Status.COURIER_REQUIRED,
      });
      await syncLicenseAndSoftLimit(consul, manager);
      expect(memory()).toMatchObject({
        jwt: stale.jwt,
        publicKey,
        nextToken: null,
        ...revoked,
      });
      expect(manager.getLicenseId()).toBe(stale.licenseId);
      const before = consul.snapshot();
      services.db = db = new DurableRtdb(stale.licenseId, privateKey, {
        ...db.license,
        isInitialized: false,
        expectedNextToken: '',
      });
      if (failure === 'JWT write')
        consul.fault = { key: K.HP_LICENSE_JWT, mode: 'before-write' };
      else redis.failPublish = true;
      expect(await performHeartbeat(context.redisClient)).toMatchObject({
        success: false,
        message:
          failure === 'JWT write'
            ? `Consul before-write: ${K.HP_LICENSE_JWT}`
            : 'Redis notification unavailable',
      });
      expect(exchanges).toHaveLength(1);
      expect(exchanges[0]).toMatchObject({
        request: {
          phase: 0,
          licenseId: stale.licenseId,
          jwt: stale.jwt,
          nextToken: null,
        },
        response: { status: 200 },
      });
      const refreshed = exchanges[0].response!.body;
      const verified = jwt.verify(refreshed.jwt!, publicKey, {
        algorithms: ['ES256'],
      }) as jwt.JwtPayload;
      expect(verified.licenseId).toBe(stale.licenseId);
      expect(verified.last_heartbeat_timestamp).toBeGreaterThanOrEqual(
        startedAt,
      );
      expect(db.license).toMatchObject({
        isInitialized: true,
        isRevoked: false,
        expectedNextToken: refreshed.nextToken,
      });
      expect(consul.snapshot()).toEqual(before);
      expect(manager.getStatus()).toBe(Status.REVOKED);
      expect(await redis.get(HP_LICENCE_HEARTBEAT_LOCK_KEY)).toBeNull();

      await persistCandidate(source);
      await syncLicenseAndSoftLimit(consul, manager);
      expect(manager.getLicenseId()).toBe(licenseId);
      expect(manager.getStatus()).toBe(Status.REVOKED);
      await persistCandidate(sameKey);
      for (let refresh = 0; refresh < 2; refresh++) {
        await syncLicenseAndSoftLimit(consul, manager);
        expect(manager.getLicenseId()).toBe(stale.licenseId);
        expect(manager.getStatus()).toBe(
          origin === 'known X' ? Status.SYNCED : Status.REVOKED,
        );
      }
    });

    describe.each([
      Status.SYNCED,
      Status.COURIER_REQUIRED,
    ])('replica A has a RAM-only barrier over durable %s', (hint) => {
      it.each([
        true,
        false,
      ])("accepts replica B's rotated-key replacement through passive refresh (token: %s)", async (withToken) => {
        await consul.kv.set(K.HP_LICENSE_SYNC_STATUS, hint);
        const observer = Reflect.construct(
          LicenseManager,
          [],
        ) as LicenseManager;
        await readLicenseState(consul, observer);
        await failRevocation(observer);
        expect(manager.getStatus()).toBe(Status.SYNCED);
        const index = consul.index(K.HP_LICENSE_SYNC_STATUS);
        await caller.provision({
          ...replacement,
          nextToken: withToken ? replacement.nextToken : undefined,
        });
        const winner = memory();
        expect(winner.status).toBe(Status.SYNCED);
        expect(observer.getStatus()).toBe(Status.REVOKED);
        if (hint === winner.hintStatus)
          expect(consul.index(K.HP_LICENSE_SYNC_STATUS)).toBe(index);
        const durable = consul.snapshot();
        if (withToken) await readLicenseState(consul, observer);
        else await syncLicenseAndSoftLimit(consul, observer);
        expect(memory(observer)).toEqual(winner);
        expect(observer.getLicenseId()).toBe('hydration-replacement');
        expect(observer.getMaxAgents()).toBe(31);
        for (let refresh = 0; refresh < 2; refresh++) {
          await syncLicenseAndSoftLimit(consul, observer);
          expect(memory(observer)).toEqual(winner);
        }
        expect(consul.snapshot()).toEqual(durable);
      });
    });

    it.each([
      true,
      false,
    ])('accepts a committed local replacement after confirmation loss (token: %s)', async (withToken) => {
      await failRevocation();
      const revoked = memory();
      const input = {
        ...replacement,
        nextToken: withToken ? replacement.nextToken : undefined,
      };
      consul.beforeNextWrite = () => {
        vi.spyOn(consul.transaction, 'create').mockRejectedValueOnce(
          new Error('Confirmation read unavailable'),
        );
      };
      await expect(caller.provision(input)).rejects.toThrow(
        'Confirmation read unavailable',
      );
      expect(consul.value(K.HP_LICENSE_JWT)).toBe(input.jwt);
      expect(memory()).toEqual(revoked);
      await expect(caller.provision(input)).rejects.toMatchObject({
        code: 'CONFLICT',
      });
      expect(memory()).toEqual(revoked);
      const durable = consul.snapshot();
      await caller.getDeploymentConfig();
      expect(memory()).toEqual({
        publicKey: input.publicKey,
        jwt: input.jwt,
        nextToken: input.nextToken ?? null,
        hintStatus: withToken ? Status.SYNCED : Status.COURIER_REQUIRED,
        status: Status.SYNCED,
      });
      await syncLicenseAndSoftLimit(consul, manager);
      expect(manager.getStatus()).toBe(Status.SYNCED);
      expect(consul.snapshot()).toEqual(durable);
    });

    it('does not discharge the original barrier during legacy rollback I/O', async () => {
      await consul.kv.del(K.NEXT_TOKEN);
      services.db = db = new DurableRtdb(licenseId, privateKey, {
        ...db.license,
        isInitialized: false,
        expectedNextToken: '',
      });
      await failRevocation();
      redis.failPublish = true;
      const paused = deferred();
      const release = deferred();
      const set = consul.kv.set;
      vi.spyOn(consul.kv, 'set').mockImplementation(async (...args) => {
        if (args[0] === K.HP_LICENSE_JWT && args[1] === J0) {
          paused.resolve();
          await release.promise;
        }
        return set(...args);
      });
      const heartbeat = performHeartbeat(context.redisClient);
      await paused.promise;
      let during: Status | undefined;
      try {
        await persistCandidate({
          jwt: jwt.sign(
            { ...originalPayload, licenseId: 'hydration-replacement' },
            privateKey,
            { algorithm: 'ES256' },
          ),
          publicKey,
        });
        await syncLicenseAndSoftLimit(consul, manager);
        during = manager.getStatus();
      } finally {
        release.resolve();
        expect((await heartbeat).success).toBe(false);
      }
      expect(consul.value(K.HP_LICENSE_JWT)).toBe(J0);
      expect({ during, after: manager.getStatus() }).toEqual({
        during: Status.REVOKED,
        after: Status.REVOKED,
      });
      await syncLicenseAndSoftLimit(consul, manager);
      expect(manager.getStatus()).toBe(Status.REVOKED);
    });
  });

  it.each([
    'unchanged tuple',
    'rotated replacement',
  ])('cannot hydrate a held SYNCED config over an actual revocation (%s)', async (kind) => {
    await consul.kv.set(K.HP_LICENSE_SYNC_STATUS, Status.SYNCED);
    await caller.getDeploymentConfig();
    const held = consul.deferNextRead();
    const config = caller.getDeploymentConfig();
    await held.captured;
    if (kind === 'rotated replacement') await caller.provision(replacement);
    await caller.reportRevocation();
    const winner = memory();
    const admitted: ReturnType<typeof memory>[] = [];
    const publish = manager.publishSnapshot.bind(manager);
    vi.spyOn(manager, 'publishSnapshot').mockImplementation((...args) => {
      const applied = publish(...args);
      if (applied) admitted.push(memory());
      return applied;
    });

    held.release();
    expect(await config).toEqual({
      licenseId:
        kind === 'rotated replacement' ? 'hydration-replacement' : licenseId,
      jwt: winner.jwt,
      nextToken: winner.nextToken,
      syncStatusIndex: consul.index(K.HP_LICENSE_SYNC_STATUS),
    });
    expect(winner.status).toBe(Status.REVOKED);
    expect(memory()).toEqual(winner);
    expect(admitted).toEqual([winner]);
  });

  it.each([
    Status.SYNCED,
    Status.COURIER_REQUIRED,
  ])('keeps failed-write RAM revocation across held reads, config and poll/pubsub refreshes (%s)', async (hint) => {
    await consul.kv.set(K.HP_LICENSE_SYNC_STATUS, hint);
    await syncLicenseAndSoftLimit(consul, manager);
    const held = consul.deferNextRead();
    const oldPoll = syncLicenseAndSoftLimit(consul, manager);
    await held.captured;
    await failRevocation();
    const revoked = memory();
    const refresh = () => syncLicenseAndSoftLimit(consul, manager);
    for (const durableHint of [hint, Status.COURIER_REQUIRED, Status.SYNCED]) {
      await consul.kv.set(K.HP_LICENSE_SYNC_STATUS, durableHint);
      await caller.getDeploymentConfig();
      await refresh();
      await redis.publish(HP_LICENCE_MEMORY_REFRESH_KEY, '1');
      await refresh();
      const state = await readLicenseState(consul, manager);
      expect(state.hintStatus).toBe(durableHint);
      expect(memory()).toEqual(revoked);
    }
    held.release();
    await oldPoll;
    expect(memory()).toEqual(revoked);
    expect(await caller.status()).toMatchObject({
      status: Status.REVOKED,
      hintStatus: Status.REVOKED,
    });
  });

  describe.each([
    'durable',
    'RAM-only',
  ])('newer %s revocation during confirmation', (kind) => {
    it.each([
      ['prepared recovery', 'normal'],
      ['prepared recovery', 'ack-loss'],
      ['replacement', 'normal'],
      ['replacement', 'ack-loss'],
    ])('supersedes %s with %s without granting an exact-pair replay', async (mode, fault) => {
      await consul.kv.set(K.HP_LICENSE_SYNC_STATUS, Status.SYNCED);
      await failRevocation();
      const prepared =
        mode === 'prepared recovery' ? await prepareCourier() : null;
      const input = prepared
        ? { ...prepared, jwt: await phaseTwo(prepared.nextToken) }
        : null;
      const ready = deferConfirmation();
      if (fault === 'ack-loss')
        consul.fault = { key: K.HP_LICENSE_JWT, mode: 'ack-loss' };
      const pending = (
        input ? caller.submitRelay(input) : caller.provision(replacement)
      ).then(
        () => null,
        (error: unknown) => error,
      );
      const held = await ready;
      await held.captured;
      expect(consul.value(K.HP_LICENSE_JWT)).toBe(
        input?.jwt ?? replacement.jwt,
      );
      expect(manager.getRawJwt()).toBe(J0);
      expect(manager.getStatus()).toBe(Status.REVOKED);
      if (kind === 'durable') await caller.reportRevocation();
      else await failRevocation();
      const winner = memory();
      const durable = consul.snapshot();

      held.release();
      expect(await pending).toMatchObject({ code: 'CONFLICT' });
      expect(memory()).toEqual(winner);
      expect(consul.snapshot()).toEqual(durable);
      await syncLicenseAndSoftLimit(consul, manager);
      expect(memory()).toEqual(winner);
      if (input) {
        for (const replay of [
          input,
          { ...input, syncStatusIndex: consul.index(K.HP_LICENSE_SYNC_STATUS) },
          { ...input, preparedFrom: input.jwt },
        ]) {
          await expect(caller.submitRelay(replay)).rejects.toMatchObject({
            code: 'CONFLICT',
          });
        }
      } else {
        await expect(caller.provision(replacement)).rejects.toMatchObject({
          code: 'CONFLICT',
        });
      }
      expect(memory()).toEqual(winner);
    });
  });

  it.each([
    'direct',
    'courier',
    'replacement',
  ])('does not let a held old REVOKED read undo fresh verified %s', async (mode) => {
    await caller.reportRevocation();
    const recoveryContext = manager.captureRecoveryContext();
    for (let read = 0; read < 3; read++)
      await syncLicenseAndSoftLimit(consul, manager);
    expect(manager.isRecoveryCurrent(recoveryContext)).toBe(true);
    const held = consul.deferNextRead();
    const oldRead = caller.getDeploymentConfig();
    await held.captured;
    if (mode === 'direct') {
      expect((await performHeartbeat(context.redisClient)).success).toBe(true);
    } else if (mode === 'courier') {
      const prepared = await prepareCourier();
      await caller.submitRelay({
        ...prepared,
        jwt: await phaseTwo(prepared.nextToken),
      });
    } else {
      await caller.provision(replacement);
    }
    const winner = memory();
    expect(winner.status).toBe(Status.SYNCED);
    held.release();
    expect(await oldRead).toMatchObject({
      jwt: winner.jwt,
      nextToken: winner.nextToken,
    });
    expect(memory()).toEqual(winner);
  });

  describe.each([
    Status.SYNCED,
    Status.COURIER_REQUIRED,
  ])('RAM-only R with durable %s', (hint) => {
    it.each([
      'direct',
      'courier',
      'replacement',
      'replacement without token',
    ])('permits fresh verified %s', async (mode) => {
      await consul.kv.set(K.HP_LICENSE_SYNC_STATUS, hint);
      await failRevocation();
      const index = consul.index(K.HP_LICENSE_SYNC_STATUS);
      if (mode === 'direct') {
        expect((await performHeartbeat(context.redisClient)).success).toBe(
          true,
        );
      } else if (mode === 'courier') {
        const prepared = await prepareCourier();
        await expect(
          caller.submitRelay({ ...prepared, jwt: J0 }),
        ).rejects.toMatchObject({ code: 'CONFLICT' });
        await expect(
          caller.submitRelay({ ...prepared, jwt: otherJwt }),
        ).rejects.toMatchObject({ code: 'CONFLICT' });
        expect(manager.getStatus()).toBe(Status.REVOKED);
        await caller.submitRelay({
          ...prepared,
          jwt: await phaseTwo(prepared.nextToken),
        });
      } else {
        await caller.provision({
          ...replacement,
          nextToken: mode.endsWith('without token')
            ? undefined
            : replacement.nextToken,
        });
      }
      expect(manager.getStatus()).toBe(Status.SYNCED);
      expect(manager.getHintStatus()).toBe(
        mode.endsWith('without token')
          ? Status.COURIER_REQUIRED
          : Status.SYNCED,
      );
      if (hint === Status.SYNCED && !mode.endsWith('without token')) {
        // A no-op hint write must still be eligible to clear a captured local barrier.
        expect(consul.index(K.HP_LICENSE_SYNC_STATUS)).toBe(index);
      }
      await syncLicenseAndSoftLimit(consul, manager);
      expect(manager.getStatus()).toBe(Status.SYNCED);
    });
  });

  it('rejects an already-completed exact-pair read held across a new RAM-only revocation', async () => {
    const prepared = await prepareCourier();
    const input = { ...prepared, jwt: await phaseTwo(prepared.nextToken) };
    await caller.submitRelay(input);
    const held = consul.deferNextRead();
    const replay = caller.submitRelay(input).then(
      () => null,
      (error: unknown) => error,
    );
    await held.captured;
    await failRevocation();
    const winner = memory();
    held.release();
    expect(await replay).toMatchObject({ code: 'CONFLICT' });
    expect(memory()).toEqual(winner);
  });

  it('invalidates an older verified confirmation when revocation starts, before its failed write returns', async () => {
    await consul.kv.set(K.HP_LICENSE_SYNC_STATUS, Status.SYNCED);
    const prepared = await prepareCourier();
    const input = { ...prepared, jwt: await phaseTwo(prepared.nextToken) };
    const ready = deferConfirmation();
    const completion = caller.submitRelay(input).then(
      () => null,
      (error: unknown) => error,
    );
    const held = await ready;
    await held.captured;
    const started = deferred();
    const releaseRevocation = deferred();
    consul.beforeNextWrite = async () => {
      started.resolve();
      await releaseRevocation.promise;
    };
    consul.fault = { key: K.HP_LICENSE_SYNC_STATUS, mode: 'before-write' };
    const revocation = caller.reportRevocation().then(
      () => null,
      (error: unknown) => error,
    );
    await started.promise;
    held.release();
    expect(await completion).toMatchObject({ code: 'CONFLICT' });
    expect(manager.getStatus()).toBe(Status.REVOKED);
    releaseRevocation.resolve();
    expect(await revocation).toBeInstanceOf(Error);
    expect(consul.value(K.HP_LICENSE_SYNC_STATUS)).toBe(Status.SYNCED);
    await syncLicenseAndSoftLimit(consul, manager);
    expect(manager.getStatus()).toBe(Status.REVOKED);
  });

  it('keeps a failed new revocation event distinct from an initially unobserved durable R', async () => {
    await consul.kv.set(K.HP_LICENSE_SYNC_STATUS, Status.REVOKED);
    await failRevocation();
    await consul.kv.set(K.HP_LICENSE_SYNC_STATUS, Status.SYNCED);
    await syncLicenseAndSoftLimit(consul, manager);
    expect(manager.getStatus()).toBe(Status.REVOKED);
    expect((await performHeartbeat(context.redisClient)).success).toBe(true);
    expect(manager.getStatus()).toBe(Status.SYNCED);
  });

  it('requires the prepared recovery index fence for RAM-only R as well as durable R', async () => {
    await failRevocation();
    const config = await caller.getDeploymentConfig();
    const nextToken = await phaseOne();
    const preparation = { jwt: J0, previousNextToken: T0, nextToken };
    await expect(caller.prepareRelay(preparation)).rejects.toMatchObject({
      code: 'CONFLICT',
    });
    await caller.prepareRelay({
      ...preparation,
      syncStatusIndex: config.syncStatusIndex,
    });
    const input = {
      jwt: await phaseTwo(nextToken),
      nextToken,
      preparedFrom: J0,
    };
    await expect(caller.submitRelay(input)).rejects.toMatchObject({
      code: 'CONFLICT',
    });
    expect(manager.getStatus()).toBe(Status.REVOKED);
    await caller.submitRelay({
      ...input,
      syncStatusIndex: config.syncStatusIndex,
    });
    await expect(caller.submitRelay(input)).resolves.toEqual({ success: true });
  });

  it.each([
    ['malformed', 'not-a-jwt'],
    ['invalid JSON', malformedJsonJwt],
  ])('restores a %s raw source after an unmarked relay token-write failure', async (_kind, source) => {
    const nextToken = await phaseOne();
    const input = { jwt: await phaseTwo(nextToken), nextToken };
    await consul.kv.set(K.HP_LICENSE_JWT, source);
    await readLicenseState(consul, manager);
    manager.setHintStatus(Status.REVOKED);
    const before = consul.snapshot();
    const originalMemory = memory();
    const writeFrom = consul.writes.length;
    const centralBefore = db.license;
    expect(manager.captureRecoveryContext()).toMatchObject({
      revoked: true,
      revocationSources: [null],
    });
    expect(before[K.HP_LICENSE_ID]).toBe(licenseId);
    const publish = vi.spyOn(manager, 'publishSnapshot');
    const update = vi.spyOn(manager, 'updateState');
    consul.fault = { key: K.NEXT_TOKEN, mode: 'before-write' };

    await expect(caller.submitRelay(input)).rejects.toMatchObject({
      code: 'INTERNAL_SERVER_ERROR',
      message: `Failed to persist license config in Consul: Consul before-write: ${K.NEXT_TOKEN}`,
    });

    expect(consul.fault).toBeUndefined();
    // Legacy rollback derives the ID from the raw JWT, not the indexed metadata.
    expect(consul.snapshot()).toEqual({ ...before, [K.HP_LICENSE_ID]: '' });
    expect(consul.writes.slice(writeFrom)).toEqual([
      { key: K.HP_LICENSE_JWT, value: input.jwt },
      { key: K.HP_LICENSE_JWT, value: source },
      { key: K.HP_LICENSE_ID, value: '' },
    ]);
    expect(memory()).toEqual(originalMemory);
    expect(manager.getLicenseId()).toBeNull();
    expect(manager.getStatus()).toBe(Status.REVOKED);
    expect(update).not.toHaveBeenCalled();
    for (const [state] of publish.mock.calls) expect(state.jwt).toBe(source);
    expect(redis.publications).toEqual([]);
    expect(db.license).toEqual(centralBefore);
    expect(fetch).not.toHaveBeenCalled();
  });

  it.each([
    '',
    '""',
  ])('preserves legacy empty token/key inputs for an advancing verified recovery (%s)', async (key) => {
    await failRevocation();
    const refreshed = jwt.sign(
      { ...originalPayload, last_heartbeat_timestamp: startedAt },
      privateKey,
      { algorithm: 'ES256' },
    );
    await expect(
      caller.submitRelay({ jwt: refreshed, nextToken: '', publicKey: key }),
    ).resolves.toEqual({ success: true });
    expect(consul.value(K.NEXT_TOKEN)).toBe('');
    expect(manager.getNextToken()).toBeNull();
    expect(manager.getPublicKey()).toBe(publicKey);
    expect(manager.getStatus()).toBe(Status.SYNCED);
  });

  it.each([
    'coherent read',
    'soft-limit read',
    'soft-limit write',
  ])('cannot republish the old poller tuple after its %s await', async (stage) => {
    await consul.kv.set(K.HP_SOFT_AGENT_LIMIT, '100');
    const paused = deferred();
    const release = deferred();
    const held = stage === 'coherent read' ? consul.deferNextRead() : null;
    const get = consul.kv.get;
    const gets = vi
      .spyOn(consul.kv, 'get')
      .mockImplementation(async (...args) => {
        const result = await get(...args);
        if (stage === 'soft-limit read') {
          paused.resolve();
          await release.promise;
        }
        return result;
      });
    const set = consul.kv.set;
    vi.spyOn(consul.kv, 'set').mockImplementation(async (...args) => {
      const result = await set(...args);
      if (stage === 'soft-limit write' && args[0] === K.HP_SOFT_AGENT_LIMIT) {
        paused.resolve();
        await release.promise;
      }
      return result;
    });
    const poll = syncLicenseAndSoftLimit(consul, manager);
    await (held ? held.captured : paused.promise);
    await caller.provision(replacement);
    await caller.reportRevocation();
    const winner = memory();
    held?.release();
    release.resolve();
    await poll;
    expect(memory()).toEqual(winner);
    expect(manager.getMaxAgents()).toBe(31);
    expect(manager.getSoftAgentLimit()).toBe(
      stage === 'soft-limit write' ? 12 : 31,
    );
    expect(gets.mock.calls).toEqual([[K.HP_SOFT_AGENT_LIMIT]]);
    for (const read of consul.transactions.filter(
      ({ consistent }) => consistent,
    )) {
      expect(read.operations.map(({ KV }) => KV.Key).sort()).toEqual(
        [
          K.HP_LICENSE_JWT,
          K.NEXT_TOKEN,
          K.HP_LICENSE_SYNC_STATUS,
          K.HP_LICENSE_ID,
          'LICENSE_PUBLIC_KEY',
        ].sort(),
      );
    }
  });

  it.each([
    [undefined, 12, null],
    ['', 12, ''],
    ['invalid', 12, '12'],
    ['-1', 12, '12'],
    ['99', 12, '12'],
    ['0', 0, '0'],
    ['5', 5, '5'],
  ])('normalizes the separate soft limit %s without reading the whole KV tree', async (value, expected, persisted) => {
    if (value !== undefined)
      await consul.kv.set(K.HP_SOFT_AGENT_LIMIT, value as string);
    const get = vi.spyOn(consul.kv, 'get');
    await syncLicenseAndSoftLimit(consul, manager);
    expect(get.mock.calls).toEqual([[K.HP_SOFT_AGENT_LIMIT]]);
    expect(manager.getSoftAgentLimit()).toBe(expected);
    expect(consul.value(K.HP_SOFT_AGENT_LIMIT)).toBe(persisted);
  });

  it.each([
    K.HP_LICENSE_JWT,
    K.NEXT_TOKEN,
    K.HP_LICENSE_SYNC_STATUS,
    'LICENSE_PUBLIC_KEY',
    'all',
  ])('admits fresh absence/deletion of %s even when ModifyIndices decrease', async (key) => {
    await consul.kv.set(K.HP_LICENSE_SYNC_STATUS, Status.SYNCED);
    await caller.getDeploymentConfig();
    const held = consul.deferNextRead();
    const old = caller.getDeploymentConfig();
    await held.captured;
    const deleted = key === 'all' ? Object.keys(consul.snapshot()) : [key];
    for (const row of deleted) await consul.kv.del(row);
    const fresh = await readLicenseState(consul, manager);
    const winner = memory();
    for (const row of deleted) expect(fresh.indices[row]).toBe(0);
    expect(fresh.jwt).toBe(consul.value(K.HP_LICENSE_JWT));
    expect(fresh.nextToken).toBe(consul.value(K.NEXT_TOKEN));
    expect(fresh.publicKey).toBe(consul.value('LICENSE_PUBLIC_KEY'));
    expect(fresh.verificationKey).toBe(publicKey);
    expect(fresh.hintStatus).toBe(
      consul.value(K.HP_LICENSE_SYNC_STATUS) ?? Status.COURIER_REQUIRED,
    );
    held.release();
    expect(await old).toMatchObject({
      jwt: fresh.jwt,
      nextToken: fresh.nextToken,
      syncStatusIndex: fresh.indices[K.HP_LICENSE_SYNC_STATUS],
    });
    expect(memory()).toEqual(winner);
  });

  it('retries a fresher overlapping response after an identical admission with reversed read linearization', async () => {
    await caller.getDeploymentConfig();
    const readFrom = consul.transactions.length;
    const first = consul.deferNextRead(true);
    const firstResult = caller.getDeploymentConfig();
    await first.started;
    const second = consul.deferNextRead();
    const secondResult = readLicenseState(consul, manager);
    await second.captured;
    // No local publication accompanies these external durable changes. The first
    // request will linearize later, but that is not knowable from request order.
    await consul.kv.set(K.HP_LICENSE_JWT, replacement.jwt);
    await consul.kv.set('LICENSE_PUBLIC_KEY', replacement.publicKey);
    await consul.kv.del(K.NEXT_TOKEN);
    first.linearize();
    await first.captured;
    second.release();
    expect((await secondResult).jwt).toBe(J0);
    expect(manager.getRawJwt()).toBe(J0);
    first.release();
    expect(await firstResult).toMatchObject({
      licenseId: 'hydration-replacement',
      jwt: replacement.jwt,
      nextToken: null,
    });
    expect(memory()).toMatchObject({
      publicKey: replacement.publicKey,
      jwt: replacement.jwt,
      nextToken: null,
    });
    expect(consul.transactions.slice(readFrom)).toHaveLength(3);
  });

  it('returns a pure source-bound fallback snapshot even after RAM and its key change', async () => {
    await consul.kv.del('LICENSE_PUBLIC_KEY');
    const held = consul.deferNextRead();
    const pure = readLicenseState(consul, manager, { hydrate: false });
    await held.captured;
    await caller.provision(replacement);
    const winner = memory();
    held.release();
    expect(await pure).toMatchObject({
      jwt: J0,
      nextToken: T0,
      publicKey: null,
      verificationKey: publicKey,
    });
    expect(memory()).toEqual(winner);
  });

  it('guards delayed bootstrap/database key loads and retains the environment fallback', async () => {
    await consul.kv.del('LICENSE_PUBLIC_KEY');
    const bootstrap = manager.capturePublication();
    expect(manager.setBootstrapPublicKey(publicKey, bootstrap)).toBe(true);
    await syncLicenseAndSoftLimit(consul, manager);
    expect(manager.getPublicKey()).toBe(publicKey);
    expect(manager.getStatus()).toBe(Status.SYNCED);
    const ticket = manager.capturePublication();
    const keyRead = deferred<string>();
    const reload = keyRead.promise.then((key) =>
      manager.setBootstrapPublicKey(key, ticket),
    );
    await caller.provision(replacement);
    const winner = memory();
    keyRead.resolve(publicKey);
    expect(await reload).toBe(false);
    expect(memory()).toEqual(winner);
    expect(
      manager.setBootstrapPublicKey(publicKey, manager.capturePublication()),
    ).toBe(true);
    expect(memory()).toEqual(winner);
  });

  it.each([
    'direct Phase 0',
    'initial relay',
    'legacy relay',
  ])('does not clear a RAM-only barrier before persistence in %s', async (mode) => {
    await consul.kv.del(K.NEXT_TOKEN);
    services.db = db = new DurableRtdb(licenseId, privateKey, {
      ...db.license,
      isInitialized: false,
      expectedNextToken: '',
    });
    await failRevocation();
    const pendingWrite = deferred();
    const release = deferred();
    const set = consul.kv.set;
    let pending: Promise<unknown>;
    if (mode === 'direct Phase 0') {
      vi.spyOn(consul.kv, 'set').mockImplementation(async (...args) => {
        if (args[0] === K.HP_LICENSE_JWT) {
          pendingWrite.resolve();
          await release.promise;
        }
        return set(...args);
      });
      pending = performHeartbeat(context.redisClient);
    } else {
      const result = await centralHeartbeat({
        body: JSON.stringify({ phase: 0, licenseId, jwt: J0, nextToken: null }),
      });
      expect(result.statusCode).toBe(200);
      const { jwt: newJwt, nextToken } = JSON.parse(result.body) as {
        jwt: string;
        nextToken: string;
      };
      if (mode === 'initial relay') {
        consul.beforeNextWrite = async () => {
          pendingWrite.resolve();
          await release.promise;
        };
      } else {
        vi.spyOn(consul.kv, 'set').mockImplementation(async (...args) => {
          if (args[0] === K.HP_LICENSE_JWT) {
            pendingWrite.resolve();
            await release.promise;
          }
          return set(...args);
        });
      }
      pending = caller.submitRelay({
        jwt: newJwt,
        nextToken,
        ...(mode === 'initial relay' ? { initialFrom: J0 } : {}),
      });
    }
    await pendingWrite.promise;
    expect(consul.value(K.HP_LICENSE_JWT)).toBe(J0);
    expect(memory()).toMatchObject({
      publicKey,
      jwt: J0,
      nextToken: null,
      hintStatus: Status.REVOKED,
      status: Status.REVOKED,
    });
    await syncLicenseAndSoftLimit(consul, manager);
    expect(manager.getStatus()).toBe(Status.REVOKED);
    release.resolve();
    expect(await pending).toMatchObject({ success: true });
    expect(manager.getRawJwt()).not.toBe(J0);
    expect(manager.getStatus()).toBe(Status.SYNCED);
  });

  describe.each([
    'durable',
    'RAM-only',
  ])('new %s R during legacy/initial confirmation', (kind) => {
    it.each([
      'direct Phase 0',
      'initial relay',
      'legacy relay',
    ])('supersedes the confirmed %s tuple without stale rollback or clearance', async (mode) => {
      await consul.kv.del(K.NEXT_TOKEN);
      services.db = db = new DurableRtdb(licenseId, privateKey, {
        ...db.license,
        isInitialized: false,
        expectedNextToken: '',
      });
      await failRevocation();
      const ready = deferred<ReturnType<DurableConsul['deferNextRead']>>();
      if (mode === 'initial relay') {
        consul.beforeNextWrite = () => ready.resolve(consul.deferNextRead());
      } else {
        const set = consul.kv.set;
        let armed = true;
        vi.spyOn(consul.kv, 'set').mockImplementation(async (...args) => {
          const result = await set(...args);
          if (
            armed &&
            args[0] === K.HP_LICENSE_SYNC_STATUS &&
            args[1] === Status.SYNCED
          ) {
            armed = false;
            ready.resolve(consul.deferNextRead());
          }
          return result;
        });
      }
      let pending: Promise<unknown>;
      let relay: Parameters<typeof caller.submitRelay>[0] | undefined;
      if (mode === 'direct Phase 0') {
        pending = performHeartbeat(context.redisClient);
      } else {
        const result = await centralHeartbeat({
          body: JSON.stringify({
            phase: 0,
            licenseId,
            jwt: J0,
            nextToken: null,
          }),
        });
        expect(result.statusCode).toBe(200);
        const body = JSON.parse(result.body) as {
          jwt: string;
          nextToken: string;
        };
        relay = {
          ...body,
          ...(mode === 'initial relay' ? { initialFrom: J0 } : {}),
        };
        pending = caller.submitRelay(relay).then(
          () => null,
          (error: unknown) => error,
        );
      }
      const held = await ready.promise;
      await held.captured;
      if (kind === 'durable') await caller.reportRevocation();
      else await failRevocation();
      const winner = memory();
      const durable = consul.snapshot();
      held.release();
      expect(await pending).toMatchObject(
        mode === 'direct Phase 0'
          ? { success: false, requiresCourier: false }
          : { code: 'CONFLICT' },
      );
      expect(consul.snapshot()).toEqual(durable);
      expect(memory()).toEqual(winner);
      await syncLicenseAndSoftLimit(consul, manager);
      expect(memory()).toEqual(winner);
      if (relay)
        await expect(caller.submitRelay(relay)).rejects.toMatchObject({
          code: 'CONFLICT',
        });
    });
  });

  describe.each([
    'JWT write',
    'confirmation read',
    'refresh publish',
  ])('direct Phase 0 %s failure', (failure) => {
    it.each([
      'none',
      'RAM-only',
      'durable',
    ])('retains the legacy durable rollback without authorizing its source (%s R)', async (revocation) => {
      await consul.kv.del(K.NEXT_TOKEN);
      services.db = db = new DurableRtdb(licenseId, privateKey, {
        ...db.license,
        isInitialized: false,
        expectedNextToken: '',
      });
      if (revocation === 'RAM-only') await failRevocation();
      if (revocation === 'durable') await caller.reportRevocation();
      if (failure === 'JWT write') {
        consul.fault = { key: K.HP_LICENSE_JWT, mode: 'before-write' };
      } else if (failure === 'confirmation read') {
        onExchange = ({ response }) => {
          if (response) {
            vi.spyOn(consul.transaction, 'create').mockRejectedValueOnce(
              new Error('Confirmation read unavailable'),
            );
          }
        };
      } else {
        redis.failPublish = true;
      }
      expect((await performHeartbeat(context.redisClient)).success).toBe(false);
      expect(exchanges).toHaveLength(1);
      expect(exchanges[0]).toMatchObject({
        request: { phase: 0 },
        response: { status: 200 },
      });
      expect(consul.value(K.HP_LICENSE_JWT)).toBe(J0);
      expect(consul.value(K.NEXT_TOKEN)).toBe('');
      expect(consul.value(K.HP_LICENSE_SYNC_STATUS)).toBe(
        Status.COURIER_REQUIRED,
      );
      const expected = {
        publicKey,
        jwt: J0,
        nextToken: null,
        hintStatus:
          revocation === 'none' ? Status.COURIER_REQUIRED : Status.REVOKED,
        status: revocation === 'none' ? Status.SYNCED : Status.REVOKED,
      };
      expect(memory()).toEqual(expected);
      for (let refresh = 0; refresh < 2; refresh++) {
        await syncLicenseAndSoftLimit(consul, manager);
        expect(memory()).toEqual(expected);
      }
    });
  });
});
