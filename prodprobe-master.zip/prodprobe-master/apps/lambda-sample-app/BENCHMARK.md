# Lambda Benchmark

The service deploys identical baseline and HyperProbe workloads:

- `POST /benchmark/baseline`: no HyperProbe SDK import.
- `POST /benchmark/hyperprobe`: HyperProbe wrapper using the deployed broker.

Both handlers emit a `lambda-benchmark-invocation` JSON log for every request. It contains the benchmark request ID, internal handler duration, and start/end/delta values for RSS, heap used, heap total, and external memory.

## Deploy

Set a dedicated real HyperProbe benchmark identity before packaging:

```bash
export HYPERPROBE_BENCHMARK_SERVICE_ID="..."
export HYPERPROBE_BENCHMARK_ENVIRONMENT="benchmark"
export HYPERPROBE_BENCHMARK_BROKER_URL="https://logger.app.hyperprobe.co"
export HYPERPROBE_BENCHMARK_COMMIT_SHA="..."
```

Then build, package, attempt the map upload, and deploy the verified package:

```bash
pnpm --filter @hyperprobe/node-sdk run build
pnpm --filter lambda-sample-app run serverless-package
pnpm --filter lambda-sample-app run upload-maps
pnpm --filter lambda-sample-app run serverless-deploy
```

The source-map upload is best effort. Record and retry a failure, but it does not need to block the deployment.

## Run Requests

Run the request-level client benchmark once for each endpoint. The output JSON stores each request ID, returned request ID, status, and end-to-end response time.

```bash
BENCHMARK_SCENARIO=baseline \
BENCHMARK_URL="https://<api-id>.execute-api.<region>.amazonaws.com/benchmark/baseline" \
BENCHMARK_REQUESTS=100 \
BENCHMARK_CONCURRENCY=1 \
pnpm --filter benchmarks run lambda

BENCHMARK_SCENARIO=hyperprobe-idle \
BENCHMARK_URL="https://<api-id>.execute-api.<region>.amazonaws.com/benchmark/hyperprobe" \
BENCHMARK_REQUESTS=100 \
BENCHMARK_CONCURRENCY=1 \
pnpm --filter benchmarks run lambda
```

Create a scalar active probe on `itemCost` in `src/process-order.ts`, wait for telemetry to confirm it is active, then run the HyperProbe endpoint again with `BENCHMARK_SCENARIO=hyperprobe-active`.

Run each scenario at least three times. Start with concurrency one, then repeat all scenarios at the same higher concurrency. Treat cold starts separately: deploy a fresh version, make one request, and verify CloudWatch reports an `Init Duration` for that request.

## Correlate Memory

Use each request ID in the JSON output to query the Lambda CloudWatch logs for `lambda-benchmark-invocation`. The Lambda log supplies per-invocation internal duration and memory snapshots; the client file supplies end-to-end response time. CloudWatch `Max Memory Used` remains a container-level high-water mark and should be reported separately from the per-request snapshots.
