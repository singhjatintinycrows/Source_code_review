import { ApolloServer } from '@apollo/server';
import {
  handlers,
  startServerAndCreateLambdaHandler,
} from '@as-integrations/aws-lambda';
import { wrapLambda } from '@hyperprobe/node-sdk';

const server = new ApolloServer({
  typeDefs: `#graphql
    type Query {
      hello: String!
      probeTarget: Int!
    }
  `,
  resolvers: {
    Query: {
      hello: () => 'Hello from Apollo GraphQL on AWS Lambda!',
      probeTarget: () => {
        const baseValue = 40;
        const increment = 2;
        return baseValue + increment;
      },
    },
  },
});

const graphqlHandler = startServerAndCreateLambdaHandler(
  server,
  handlers.createAPIGatewayProxyEventV2RequestHandler(),
);

export const handler = wrapLambda(graphqlHandler, {
  serviceId:
    process.env.HYPERPROBE_SERVICE_ID || '8fad1ef4-75c9-4a07-857f-5e9cd7b07660',
  brokerUrl:
    process.env.HYPERPROBE_BROKER_URL || 'https://logger.app.hyperprobe.co',
  commitSha:
    process.env.GIT_COMMIT || '2035d64a68857694de94a75883f3a67ca0397f98',
  environment: process.env.HYPERPROBE_ENVIRONMENT || 'benchmark',
  distLocation: process.env.HYPERPROBE_DIST_LOCATION || 'dist',
  appRoot: process.env.HYPERPROBE_APP_ROOT || 'apps/lambda-sample-app',
});
