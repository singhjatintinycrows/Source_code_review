export type LambdaEvent = {
  body?: string;
  headers?: Record<string, string | undefined>;
  requestContext?: { requestId?: string };
};

export type LambdaContext = {
  awsRequestId?: string;
};

type MemoryUsage = Pick<
  NodeJS.MemoryUsage,
  'rss' | 'heapUsed' | 'heapTotal' | 'external'
>;

function memoryUsage(): MemoryUsage {
  const { rss, heapUsed, heapTotal, external } = process.memoryUsage();
  return { rss, heapUsed, heapTotal, external };
}

function memoryDelta(start: MemoryUsage, end: MemoryUsage): MemoryUsage {
  return {
    rss: end.rss - start.rss,
    heapUsed: end.heapUsed - start.heapUsed,
    heapTotal: end.heapTotal - start.heapTotal,
    external: end.external - start.external,
  };
}

export async function processOrder(event: LambdaEvent, context: LambdaContext) {
  const requestId =
    event.headers?.['x-benchmark-request-id'] ||
    event.requestContext?.requestId ||
    context.awsRequestId ||
    crypto.randomUUID();
  const startTime = performance.now();
  const startMemory = memoryUsage();
  const scenario =
    event.headers?.['x-benchmark-scenario'] ||
    process.env.BENCHMARK_SCENARIO ||
    'unknown';

  try {
    const body = JSON.parse(event.body || '{}');
    const items = body.items || [];

    // Keep the current demo workload so all benchmark variants allocate equally.
    const largeTestData: Record<string, unknown> = {};
    for (let i = 0; i < 5000; i++) {
      largeTestData[`item_${i}`] = {
        id: i,
        name: `Stress Test Item ${i}`,
        tags: Array.from({ length: 20 }, (_, j) => `tag_${i}_${j}`),
        metadata: {
          nestedLevel1: {
            nestedLevel2: {
              value: `Deep nested string value ${i}`,
              created: new Date().toISOString(),
            },
          },
        },
      };
    }

    let totalCost = 0;
    for (const item of items) {
      // Benchmark active probes should capture scalar values at this line.
      const itemCost = item.price * (item.quantity || 1);
      totalCost += itemCost;
    }

    return {
      statusCode: 200,
      headers: { 'x-benchmark-request-id': requestId },
      body: JSON.stringify({
        message: 'Hello from HyperProbe on AWS Lambda!',
        total: totalCost,
      }),
    };
  } finally {
    const endMemory = memoryUsage();
    console.log(
      JSON.stringify({
        type: 'lambda-benchmark-invocation',
        requestId,
        scenario,
        handlerMs: Number((performance.now() - startTime).toFixed(3)),
        memory: {
          start: startMemory,
          end: endMemory,
          delta: memoryDelta(startMemory, endMemory),
        },
      }),
    );
  }
}
