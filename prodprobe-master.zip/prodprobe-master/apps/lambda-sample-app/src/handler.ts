import { wrapLambda } from '@hyperprobe/node-sdk';
import {
  type LambdaContext,
  type LambdaEvent,
  processOrder,
} from './process-order.js';

export const handler: (
  event: LambdaEvent,
  context: LambdaContext,
) => Promise<unknown> = wrapLambda(processOrder, {
  serviceId:
    process.env.HYPERPROBE_SERVICE_ID || '8fad1ef4-75c9-4a07-857f-5e9cd7b07660',
  brokerUrl:
    process.env.HYPERPROBE_BROKER_URL || 'https://logger.app.hyperprobe.co',
  commitSha:
    process.env.GIT_COMMIT || '2035d64a68857694de94a75883f3a67ca0397f98',
  environment: process.env.HYPERPROBE_ENVIRONMENT || 'production',
  distLocation: process.env.HYPERPROBE_DIST_LOCATION || 'dist',
  appRoot: process.env.HYPERPROBE_APP_ROOT || 'apps/lambda-sample-app',
  syncIntervalMs: 1000,
});
