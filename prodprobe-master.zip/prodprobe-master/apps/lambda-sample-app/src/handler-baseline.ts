import { processOrder } from './process-order.js';

export const handler = processOrder;
