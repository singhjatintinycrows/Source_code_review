import { execFileSync } from 'node:child_process';
import { readdirSync } from 'node:fs';
import { join } from 'node:path';

const packageDir = '.serverless';
const archives = readdirSync(packageDir).filter((file) => file.endsWith('.zip'));

if (archives.length === 0) {
  throw new Error(`No deployment archive found in ${packageDir}`);
}

const expectedHandlers = new Set([
  'dist/baseline.js',
  'dist/hyperprobe.js',
  'dist/graphql.js',
]);

for (const archive of archives) {
  const entries = execFileSync('unzip', ['-Z1', join(packageDir, archive)], {
    encoding: 'utf8',
  }).split('\n');

  for (const handler of expectedHandlers) {
    if (entries.includes(handler)) {
      expectedHandlers.delete(handler);
    }
  }

  if (entries.some((entry) => entry.endsWith('.map'))) {
    throw new Error('Deployment archive must not include source map files');
  }
}

if (expectedHandlers.size > 0) {
  throw new Error(
    `Deployment archives do not include ${[...expectedHandlers].join(', ')}`,
  );
}

console.log('[lambda-sample-app] Deployment archive contains both handlers and excludes source maps.');
