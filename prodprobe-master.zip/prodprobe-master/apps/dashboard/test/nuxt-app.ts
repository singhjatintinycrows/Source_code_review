import { vi } from 'vitest';

export const navigateTo = vi.fn();
export const useNuxtApp = vi.fn();
export const useRuntimeConfig = vi.fn();
export const defineNuxtPlugin = <T>(plugin: T): T => plugin;
export const defineNuxtRouteMiddleware = <T>(middleware: T): T => middleware;
