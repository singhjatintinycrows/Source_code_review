import { TRPCClientError } from '@trpc/client';
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import { effectScope, isRef, nextTick, watch } from 'vue';
import { credentials, deferred, installStorage } from './auth-session';

const clearLicense = vi.hoisted(() => vi.fn());
vi.mock('../app/composables/useLicense', () => ({
  useLicense: () => ({ clearLicense }),
}));

let authModule: typeof import('../app/composables/useAuth');
let navigateTo: typeof import('./nuxt-app')['navigateTo'];
let useNuxtApp: typeof import('./nuxt-app')['useNuxtApp'];
let cancellation: typeof import('../app/utils/operation');
let browser: ReturnType<typeof installStorage>;
let stop: (() => void) | undefined;
const trpc = {
  refresh: { mutate: vi.fn() },
  verifySso: { mutate: vi.fn() },
  me: { query: vi.fn() },
};
const useAuth = () => authModule.useAuth();

const unauthorizedError = () =>
  Object.assign(new TRPCClientError('Invalid or expired refresh token'), {
    data: { code: 'UNAUTHORIZED' },
  });

beforeEach(async () => {
  vi.resetModules();
  vi.resetAllMocks();
  vi.spyOn(Date, 'now').mockReturnValue(Date.UTC(2026, 8, 14));
  ({ navigateTo, useNuxtApp } = await import('./nuxt-app'));
  browser = installStorage();
  useNuxtApp.mockReturnValue({ $trpc: trpc });
  trpc.me.query.mockResolvedValue({ email: 'A@example.test' });
  vi.spyOn(console, 'error').mockImplementation(() => undefined);
  authModule = await import('../app/composables/useAuth');
  cancellation = await import('../app/utils/operation');
});

afterEach(() => {
  stop?.();
  stop = undefined;
  vi.unstubAllGlobals();
  vi.restoreAllMocks();
});

describe('useAuth.refresh', () => {
  const mutate = trpc.refresh.mutate;

  it('retains tokens and does not redirect after a recoverable refresh error', async () => {
    const error = new Error('Network unavailable');
    mutate.mockRejectedValue(error);

    await expect(useAuth().refresh()).rejects.toBe(error);

    expect(useAuth().accessToken.value).toBe(credentials().accessToken);
    expect(useAuth().refreshToken.value).toBe(credentials().refreshToken);
    expect(navigateTo).not.toHaveBeenCalled();
  });

  it('clears tokens and redirects after an unauthorized refresh error', async () => {
    const error = unauthorizedError();
    mutate.mockRejectedValue(error);

    await expect(useAuth().refresh()).rejects.toBe(error);

    expect(useAuth().accessToken.value).toBe('');
    expect(useAuth().refreshToken.value).toBe('');
    expect(navigateTo).toHaveBeenCalledWith('/login');
  });

  it.each([
    'success',
    'unauthorized',
    'network',
  ] as const)('cancels a superseded explicit refresh %s without touching the new account', async (outcome) => {
    const old = deferred();
    mutate.mockReturnValueOnce(old.promise);
    const auth = useAuth();
    const pending = auth.refresh().catch((error) => error);
    const next = credentials('B');
    browser.replace(next, true);
    if (outcome === 'success') old.resolve(credentials('A', { iat: 100 }));
    else
      old.reject(
        outcome === 'unauthorized' ? unauthorizedError() : new Error('Offline'),
      );

    expect(cancellation.isCancelledOperation(await pending)).toBe(true);
    expect(auth.accessToken.value).toBe(next.accessToken);
    expect(auth.refreshToken.value).toBe(next.refreshToken);
    expect(navigateTo).not.toHaveBeenCalled();
  });

  it('does not let a pending refresh overwrite a same-session rotation', async () => {
    const old = deferred();
    mutate.mockReturnValueOnce(old.promise);
    const auth = useAuth();
    const current = auth.captureSession();
    const pending = auth.refresh().catch((error) => error);
    const rotated = credentials('A', {
      iat: Math.floor(Date.now() / 1000) + 1,
    });
    browser.replace(rotated, true);
    old.reject(unauthorizedError());

    expect(cancellation.isCancelledOperation(await pending)).toBe(true);
    expect(current()).toBe(true);
    expect(auth.accessToken.value).toBe(rotated.accessToken);
    expect(navigateTo).not.toHaveBeenCalled();
  });

  it('deduplicates refreshes by credentials and an old finally cannot release a newer slot', async () => {
    const old = deferred();
    const fresh = deferred();
    mutate.mockReturnValueOnce(old.promise).mockReturnValueOnce(fresh.promise);
    const auth = useAuth();
    const p1 = auth.refresh().catch((error) => error);
    browser.replace(credentials('B'), true);
    const p2 = auth.refresh();
    old.reject(unauthorizedError());
    expect(cancellation.isCancelledOperation(await p1)).toBe(true);
    const p3 = auth.refresh();
    expect(mutate).toHaveBeenCalledTimes(2);
    const rotated = credentials('B', {
      iat: Math.floor(Date.now() / 1000) + 1,
    });
    fresh.resolve(rotated);
    await expect(Promise.all([p2, p3])).resolves.toEqual([
      rotated.accessToken,
      rotated.accessToken,
    ]);
    expect(auth.accessToken.value).toBe(rotated.accessToken);
  });

  it('will not refresh an incomplete or mismatched pair or accept another account in a refresh response', async () => {
    const auth = useAuth();
    browser.change('accessToken', credentials('B').accessToken, true);
    await expect(auth.refresh()).rejects.toBeInstanceOf(
      cancellation.CancelledOperationError,
    );
    expect(mutate).not.toHaveBeenCalled();
    browser.replace(credentials('A'), true);
    mutate.mockResolvedValue(credentials('B'));
    await expect(auth.refresh()).rejects.toThrow();
    expect(auth.accessToken.value).toBe(credentials('A').accessToken);
  });
});

describe('useAuth.fetchUser', () => {
  const query = trpc.me.query;

  it('deduplicates concurrent requests', async () => {
    const auth = useAuth();
    const mockUser = { id: '1', email: 'test@example.com' } as any;
    query.mockResolvedValue(mockUser);

    const [u1, u2] = await Promise.all([auth.fetchUser(), auth.fetchUser()]);

    expect(u1).toBe(mockUser);
    expect(u2).toBe(mockUser);
    expect(query).toHaveBeenCalledTimes(1);
  });

  it('discards fetched user if logged out while query was in-flight', async () => {
    const auth = useAuth();
    let resolveQuery!: (val: any) => void;
    query.mockReturnValue(
      new Promise((resolve) => {
        resolveQuery = resolve;
      }),
    );

    const fetchPromise = auth.fetchUser();
    await auth.logout();

    resolveQuery({ id: '1', email: 'test@example.com' });
    await expect(fetchPromise).rejects.toBeInstanceOf(
      cancellation.CancelledOperationError,
    );

    expect(auth.user.value).toBeNull();
  });

  it.each([
    'success',
    'unauthorized',
  ] as const)('rejects stale user %s after a cross-tab account change before the event arrives', async (outcome) => {
    const old = deferred();
    query.mockReturnValueOnce(old.promise);
    const auth = useAuth();
    const pending = auth.fetchUser().catch((error) => error);
    browser.replace(credentials('B'), true);
    if (outcome === 'success') old.resolve({ email: 'A@example.test' });
    else old.reject(unauthorizedError());
    expect(cancellation.isCancelledOperation(await pending)).toBe(true);
    expect(auth.user.value).toBeNull();
    expect(auth.userFetchError.value).toBe(false);
  });

  it('does not join or release an old user request after permission claims change', async () => {
    const old = deferred();
    const fresh = deferred();
    query.mockReturnValueOnce(old.promise).mockReturnValueOnce(fresh.promise);
    const auth = useAuth();
    const pending = auth.fetchUser().catch((error) => error);
    browser.change(
      'accessToken',
      credentials('A', { permissions: { isAdmin: false, permissions: {} } })
        .accessToken,
      true,
    );
    const current = auth.fetchUser();
    old.resolve({ permissions: { isAdmin: true } });
    expect(cancellation.isCancelledOperation(await pending)).toBe(true);
    expect(auth.userFetchError.value).toBe(false);
    const joined = auth.fetchUser();
    expect(query).toHaveBeenCalledTimes(2);
    const viewer = { permissions: { isAdmin: false } } as any;
    fresh.resolve(viewer);
    await expect(Promise.all([current, joined])).resolves.toEqual([
      viewer,
      viewer,
    ]);
    expect(auth.user.value).toEqual(viewer);
  });
});

describe('useAuth.login', () => {
  const mutate = trpc.verifySso.mutate;

  it('resets cached user when logging in', async () => {
    const auth = useAuth();
    auth.user.value = { id: 'old-user' } as any;
    mutate.mockResolvedValue({
      success: true,
      ...credentials('B'),
    });

    await auth.login('token123');

    expect(auth.user.value).toBeNull();
    expect(auth.accessToken.value).toBe(credentials('B').accessToken);
    expect(auth.refreshToken.value).toBe(credentials('B').refreshToken);
  });

  it.each([
    'success',
    'unauthorized',
  ] as const)('cancels a superseded login %s, including a newer login to the same account', async (outcome) => {
    const old = deferred();
    mutate
      .mockReturnValueOnce(old.promise)
      .mockResolvedValueOnce({ success: true, ...credentials('A') });
    const auth = useAuth();
    const pending = auth.login('old').catch((error) => error);
    await expect(auth.login('new')).resolves.toBe(true);
    const version = auth.sessionVersion.value;
    if (outcome === 'success')
      old.resolve({ success: true, ...credentials('B') });
    else old.reject(unauthorizedError());
    expect(cancellation.isCancelledOperation(await pending)).toBe(true);
    expect(auth.accessToken.value).toBe(credentials('A').accessToken);
    expect(auth.sessionVersion.value).toBe(version);
    expect(console.error).not.toHaveBeenCalled();
  });

  it('establishes the login within its synchronously started epoch so its caller can guard the result', async () => {
    const auth = useAuth();
    const before = auth.captureSession();
    mutate.mockResolvedValue({ success: true, ...credentials('A') });
    const pending = auth.login('sso-token');
    const current = auth.captureSession();
    expect(before()).toBe(false);
    await expect(pending).resolves.toBe(true);
    expect(current()).toBe(true);
    expect(auth.isAuthenticated.value).toBe(true);
  });

  it('does not install failed or partial login results', async () => {
    mutate.mockResolvedValue({
      success: true,
      accessToken: credentials('B').accessToken,
    });
    const auth = useAuth();
    await expect(auth.login('bad-result')).resolves.toBe(false);
    expect(auth.isAuthenticated.value).toBe(false);
    expect(auth.accessToken.value).toBe('');
  });
});

describe('app-owned session observation', () => {
  function observe() {
    stop = authModule.observeAuthSession(trpc as any);
    clearLicense.mockClear();
    return useAuth();
  }

  it('shares reactive credentials and a single observer across consumers, even after their scopes stop', async () => {
    const auth = observe();
    const scopes = [effectScope(), effectScope()];
    const consumers = scopes.map((scope) => scope.run(useAuth)!);
    expect(consumers[0].accessToken).toBe(consumers[1].accessToken);
    expect(isRef(auth.sessionVersion)).toBe(true);
    const observed = vi.fn();
    const stopWatch = watch(auth.accessToken, observed);
    for (const scope of scopes) scope.stop();
    const rotated = credentials('A', {
      iat: Math.floor(Date.now() / 1000) + 1,
    });
    auth.accessToken.value = rotated.accessToken;
    await nextTick();
    expect(browser.storage.getItem('accessToken')).toBe(rotated.accessToken);
    expect(observed).toHaveBeenCalledTimes(1);
    expect(
      browser.addListener.mock.calls.filter(([event]) => event === 'storage'),
    ).toHaveLength(1);
    stopWatch();
  });

  it('clears both caches for A -> B, then again for B -> A', () => {
    const auth = observe();
    const original = auth.captureSession();
    auth.user.value = { email: 'A@example.test' } as any;
    browser.replace(credentials('B'));
    expect(auth.user.value).toBeNull();
    expect(auth.isAuthenticated.value).toBe(true);
    expect(original()).toBe(false);
    expect(clearLicense).toHaveBeenCalled();
    clearLicense.mockClear();
    const current = auth.captureSession();
    auth.user.value = { email: 'B@example.test' } as any;
    browser.replace(credentials('A'));
    expect(current()).toBe(false);
    expect(original()).toBe(false);
    expect(auth.user.value).toBeNull();
    expect(clearLicense).toHaveBeenCalled();
  });

  it('detects an A -> B -> A transition even when storage already holds A as queued events arrive', () => {
    const auth = observe();
    const original = auth.captureSession();
    auth.user.value = { email: 'A@example.test' } as any;
    browser.replace(credentials('B'), true);
    browser.replace(credentials('A'), true);
    browser.flushEvents();
    expect(original()).toBe(false);
    expect(auth.user.value).toBeNull();
    expect(auth.isAuthenticated.value).toBe(true);
    expect(auth.accessToken.value).toBe(credentials('A').accessToken);
  });

  it.each([
    'accessToken',
    'refreshToken',
  ] as const)('invalidates ownership immediately for a partial pair starting with %s without deleting new credentials', async (key) => {
    const auth = observe();
    const current = auth.captureSession();
    auth.user.value = { email: 'A@example.test' } as any;
    const next = credentials('B');
    browser.change(key, next[key]);
    expect(auth.user.value).toBeNull();
    expect(auth.isAuthenticated.value).toBe(false);
    expect(current()).toBe(false);
    expect(browser.storage.getItem(key)).toBe(next[key]);
    await expect(auth.fetchUser()).rejects.toBeInstanceOf(
      cancellation.CancelledOperationError,
    );
    await expect(auth.refresh()).rejects.toBeInstanceOf(
      cancellation.CancelledOperationError,
    );
    expect(trpc.me.query).not.toHaveBeenCalled();
    expect(trpc.refresh.mutate).not.toHaveBeenCalled();
    browser.change(
      key === 'accessToken' ? 'refreshToken' : 'accessToken',
      next[key === 'accessToken' ? 'refreshToken' : 'accessToken'],
    );
    expect(auth.isAuthenticated.value).toBe(true);
  });

  it.each([
    'remove',
    'clear',
  ] as const)('handles token %s without depending on route consumers', (action) => {
    const auth = observe();
    auth.user.value = { email: 'A@example.test' } as any;
    if (action === 'remove') browser.change('refreshToken', null);
    else browser.clear();
    expect(auth.isAuthenticated.value).toBe(false);
    expect(auth.user.value).toBeNull();
    expect(clearLicense).toHaveBeenCalled();
    if (action === 'remove')
      expect(browser.storage.getItem('accessToken')).toBe(
        credentials('A').accessToken,
      );
  });

  it('ignores unrelated/sessionStorage events and normalizes raw and JSON-quoted JWTs without invalidation', () => {
    const auth = observe();
    const current = auth.captureSession();
    auth.user.value = { email: 'A@example.test' } as any;
    browser.change('theme', 'dark');
    browser.emit(null, null, null, false, {} as Storage);
    browser.replace(credentials('A'), false, true);
    expect(auth.accessToken.value).toBe(credentials('A').accessToken);
    expect(auth.refreshToken.value).toBe(credentials('A').refreshToken);
    expect(auth.user.value).not.toBeNull();
    expect(current()).toBe(true);
    expect(clearLicense).not.toHaveBeenCalled();
    expect(trpc.me.query).not.toHaveBeenCalled();
  });

  it('preserves cache and epoch for access-only/full-pair rotations and semantically reordered permissions', async () => {
    const initial = credentials('A', {
      permissions: { isAdmin: false, permissions: { b: 2, a: 1 } },
    });
    browser.replace(initial);
    const auth = observe();
    const current = auth.captureSession();
    auth.user.value = { email: 'A@example.test' } as any;
    const originalUser = auth.user.value;
    const rotated = credentials('A', {
      iat: Math.floor(Date.now() / 1000) + 1,
      permissions: { permissions: { a: 1, b: 2 }, isAdmin: false },
    });
    browser.change('accessToken', rotated.accessToken);
    browser.change('refreshToken', rotated.refreshToken);
    await nextTick();
    expect(current()).toBe(true);
    expect(auth.user.value).toBe(originalUser);
    expect(clearLicense).not.toHaveBeenCalled();
    expect(trpc.me.query).not.toHaveBeenCalled();
  });

  it('revalidates changed authorization claims with the root-captured client but never resets license', async () => {
    const auth = observe();
    const pending = deferred();
    trpc.me.query.mockReturnValueOnce(pending.promise);
    auth.user.value = { permissions: { isAdmin: true } } as any;
    const current = auth.captureSession();
    useNuxtApp.mockImplementation(() => {
      throw new Error('No Nuxt context');
    });
    browser.change(
      'accessToken',
      credentials('A', { permissions: { isAdmin: false, permissions: {} } })
        .accessToken,
    );
    expect(auth.user.value).toBeNull();
    await nextTick();
    expect(trpc.me.query).toHaveBeenCalledTimes(1);
    expect(clearLicense).not.toHaveBeenCalled();
    expect(current()).toBe(true);
    pending.resolve({ permissions: { isAdmin: false } });
    await auth.fetchUser();
    expect(auth.user.value?.permissions.isAdmin).toBe(false);
  });

  it.each([
    'network failure',
    'current cancellation',
  ])('exposes claims revalidation %s until Retry succeeds without resetting the session', async (failure) => {
    const auth = observe();
    const pending = deferred();
    const retry = deferred();
    trpc.me.query
      .mockReturnValueOnce(pending.promise)
      .mockReturnValueOnce(retry.promise);
    auth.user.value = { permissions: { isAdmin: true } } as any;
    const version = auth.sessionVersion.value;
    const next = credentials('A', {
      permissions: { isAdmin: false, permissions: {} },
    });
    browser.change('accessToken', next.accessToken);
    await nextTick();
    expect(trpc.me.query).toHaveBeenCalledTimes(1);
    const background = auth.fetchUser();
    const error =
      failure === 'network failure'
        ? new Error('User status unavailable')
        : new cancellation.CancelledOperationError();
    pending.reject(error);
    await expect(background).rejects.toBe(error);
    expect(auth.user.value).toBeNull();
    expect(auth.userFetchError.value).toBe(true);
    expect(auth.isAuthenticated.value).toBe(true);
    expect(auth.sessionVersion.value).toBe(version);
    expect(clearLicense).not.toHaveBeenCalled();

    const recovery = auth.fetchUser(true);
    expect(auth.userFetchError.value).toBe(true);
    const viewer = { userId: 'A', permissions: { isAdmin: false } } as any;
    retry.resolve(viewer);
    await expect(recovery).resolves.toEqual(viewer);
    expect(auth.userFetchError.value).toBe(false);
    expect(auth.sessionVersion.value).toBe(version);
    expect(auth.accessToken.value).toBe(next.accessToken);
    expect(clearLicense).not.toHaveBeenCalled();
    expect(navigateTo).not.toHaveBeenCalled();
  });

  it('treats a changed userSecret as revocation, not ordinary refresh', () => {
    const auth = observe();
    const current = auth.captureSession();
    auth.user.value = { email: 'A@example.test' } as any;
    browser.change(
      'refreshToken',
      credentials('A', { userSecret: 'revoked-and-reissued' }).refreshToken,
    );
    expect(current()).toBe(false);
    expect(auth.user.value).toBeNull();
    expect(clearLicense).toHaveBeenCalled();
  });

  it('reconciles pageshow and observer restart, and an old disposer cannot stop the new observer', () => {
    const auth = observe();
    auth.user.value = { email: 'A@example.test' } as any;
    browser.replace(credentials('B'), true);
    browser.window.dispatchEvent(new Event('pageshow'));
    expect(auth.user.value).toBeNull();
    const oldStop = stop!;
    oldStop();
    auth.user.value = { email: 'B@example.test' } as any;
    browser.replace(credentials('A'));
    expect(auth.user.value).not.toBeNull();
    stop = authModule.observeAuthSession(trpc as any);
    expect(auth.user.value).toBeNull();
    oldStop();
    auth.user.value = { email: 'A@example.test' } as any;
    browser.clear();
    expect(auth.user.value).toBeNull();
    expect(
      browser.removeListener.mock.calls.filter(
        ([event]) => event === 'storage',
      ),
    ).toHaveLength(1);
  });

  it('clears state without ever acquiring a Nuxt client', async () => {
    useNuxtApp.mockImplementation(() => {
      throw new Error('No Nuxt context');
    });
    const auth = useAuth();
    auth.user.value = { email: 'A@example.test' } as any;
    const current = auth.captureSession();
    await auth.logout();
    expect(auth.user.value).toBeNull();
    expect(clearLicense).toHaveBeenCalled();
    expect(current()).toBe(false);
    expect(useNuxtApp).not.toHaveBeenCalled();
  });
});
