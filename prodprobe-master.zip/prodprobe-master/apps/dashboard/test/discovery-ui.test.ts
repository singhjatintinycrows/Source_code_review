import { readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { TRPCClientError } from '@trpc/client';
import ts from 'typescript';
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import * as Vue from 'vue';
import { compileScript, parse } from 'vue/compiler-sfc';
import { deferred } from './auth-session';

type Node = {
  type: string;
  text: string;
  props: Record<string, any>;
  parent: Node | null;
  children: Node[];
};

const makeNode = (type: string, text = ''): Node => ({
  type,
  text,
  props: {},
  parent: null,
  children: [],
});

function remove(node: Node) {
  if (!node.parent) return;
  const index = node.parent.children.indexOf(node);
  if (index < 0) throw new Error('Renderer node does not belong to parent');
  node.parent.children.splice(index, 1);
  node.parent = null;
}

const renderer = Vue.createRenderer<Node, Node>({
  createElement: (type) => makeNode(type),
  createText: (text) => makeNode('#text', text),
  createComment: (text) => makeNode('#comment', text),
  setText(node, text) {
    node.text = text;
  },
  setElementText(node, text) {
    for (const child of node.children) child.parent = null;
    node.children = [];
    node.text = text;
  },
  parentNode: (node) => node.parent,
  nextSibling: (node) =>
    node.parent?.children[node.parent.children.indexOf(node) + 1] ?? null,
  insert(node, parent, anchor = null) {
    if (node === anchor) return;
    remove(node);
    const index = anchor
      ? parent.children.indexOf(anchor)
      : parent.children.length;
    if (index < 0) throw new Error('Renderer anchor does not belong to parent');
    parent.children.splice(index, 0, node);
    node.parent = parent;
  },
  remove,
  patchProp(node, key, _previous, value) {
    node.props[key] = value;
  },
});

const nodes = (node: Node): Node[] => [node, ...node.children.flatMap(nodes)];
const text = (node: Node): string =>
  node.type === '#comment' ? '' : node.text + node.children.map(text).join('');
const button = (root: Node, label: string) =>
  nodes(root).find(
    (node) =>
      node.type === 'button' &&
      (text(node).trim() === label || node.props['aria-label'] === label),
  );

function click(root: Node, label: string) {
  const target = button(root, label);
  expect(target, `Expected a ${label} button`).toBeDefined();
  expect(target!.props.disabled).not.toBe(true);
  return target!.props.onClick();
}

function input(root: Node, label: string) {
  const field = nodes(root).find((node) => node.props.label === label)!;
  return nodes(field).find((node) => node.type === 'input')!;
}

function submit(root: Node) {
  return nodes(root)
    .find((node) => node.type === 'form')!
    .props.onSubmit({
      preventDefault() {},
    });
}

async function until(assertion: () => void) {
  for (let attempt = 0; attempt < 100; attempt++) {
    await Vue.nextTick();
    try {
      assertion();
      return;
    } catch (error) {
      if (attempt === 99) throw error;
    }
  }
}

const SlotStub = Vue.defineComponent({
  inheritAttrs: false,
  setup:
    (_, { attrs, slots }) =>
    () =>
      Vue.h(
        'div',
        attrs,
        ['header', 'default', 'footer', 'content'].flatMap(
          (name) => slots[name]?.() ?? [],
        ),
      ),
});
const ButtonStub = Vue.defineComponent({
  inheritAttrs: false,
  setup:
    (_, { attrs, slots }) =>
    () =>
      Vue.h(
        'button',
        {
          ...attrs,
          disabled: Boolean(attrs.disabled || attrs.loading),
        },
        slots.default?.(),
      ),
});
const InputStub = Vue.defineComponent({
  props: ['modelValue'],
  emits: ['update:modelValue'],
  setup:
    (props, { attrs, emit }) =>
    () =>
      Vue.h('input', {
        ...attrs,
        value: props.modelValue,
        onInput: (event: { target: { value: string } }) =>
          emit('update:modelValue', event.target.value),
      }),
});
const SelectStub = Vue.defineComponent({
  props: ['modelValue', 'items'],
  emits: ['update:modelValue'],
  setup:
    (props, { emit }) =>
    () =>
      Vue.h(
        'select',
        {
          value: props.modelValue,
          onChange: (event: { target: { value: string } }) =>
            emit('update:modelValue', event.target.value),
        },
        props.items.map((item: { value: string; label: string }) =>
          Vue.h('option', { value: item.value }, item.label),
        ),
      ),
});
const MenuStub = Vue.defineComponent({
  props: ['items'],
  setup:
    (props, { slots }) =>
    () =>
      Vue.h('div', [
        slots.default?.(),
        ...props.items
          .flat()
          .map(
            (item: {
              label: string;
              disabled?: boolean;
              onSelect: () => void;
            }) =>
              Vue.h(
                'button',
                { disabled: item.disabled, onClick: item.onSelect },
                item.label,
              ),
          ),
      ]),
});
const ModalStub = Vue.defineComponent({
  inheritAttrs: false,
  props: ['open'],
  setup:
    (props, { slots }) =>
    () =>
      props.open ? slots.content?.() : null,
});
const AlertStub = Vue.defineComponent({
  props: ['title', 'description'],
  setup:
    (props, { slots }) =>
    () =>
      Vue.h('div', [props.title, slots.description?.() ?? props.description]),
});

const serviceId = 'service-id';
const now = '2026-09-16T12:00:00.000Z';
const retryAt = '2026-09-16T12:00:30.000Z';
const retryLabel = () =>
  new Date(retryAt).toLocaleString(undefined, { timeZoneName: 'short' });
const connection = {
  id: 'sentry-main',
  serviceId,
  name: 'Sentry main',
  provider: 'SENTRY',
  publicConfig: {
    orgSlug: 'acme',
    projectId: '123',
    projectSlug: 'checkout',
    apiBaseUrl: 'https://sentry.io/api/0/',
  },
  configVersion: 1,
  enabled: true,
  supportedSignals: ['ERRORS', 'LOGS', 'TRACES', 'METRICS', 'ALERTS'],
  createdAt: new Date(now),
  updatedAt: new Date(now),
};
const refreshedConnection = {
  ...connection,
  publicConfig: { ...connection.publicConfig, projectSlug: 'checkout-renamed' },
  updatedAt: new Date('2026-09-16T12:00:01.000Z'),
};
const editedConnection = {
  ...connection,
  name: 'User edit',
  publicConfig: { ...connection.publicConfig, projectSlug: 'user-project' },
  updatedAt: new Date('2026-09-16T12:00:02.000Z'),
};
const rateFailure = {
  connectionId: connection.id,
  connectionName: connection.name,
  provider: connection.provider,
  section: 'alerts',
  code: 'RATE_LIMITED',
  reason: 'Alert discovery was rate limited.',
};
const rateError = () =>
  Object.assign(new TRPCClientError('Provider rate limit.'), {
    data: { code: 'TOO_MANY_REQUESTS', httpStatus: 429, retryAt },
  });

function readyResult(testedConnection = connection) {
  return {
    checkedAt: now,
    testedConnection,
    connection: { availability: 'AVAILABLE' },
    alerts: { availability: 'AVAILABLE', itemCount: 0 },
    environments: { availability: 'AVAILABLE', itemCount: 1 },
    releases: { availability: 'AVAILABLE', itemCount: 1 },
    tags: { availability: 'AVAILABLE', itemCount: 1 },
    sources: [],
    failures: [],
    warnings: [],
  };
}

const route = Vue.reactive({ params: { serviceId } });
const toast = { showSuccess: vi.fn(), showError: vi.fn() };
const integrations = {
  listProviders: { query: vi.fn() },
  listConnections: { query: vi.fn() },
  listCapabilityConnections: { query: vi.fn() },
  setCapabilityConnections: { mutate: vi.fn() },
  testConnection: { mutate: vi.fn() },
  upsertConnection: { mutate: vi.fn() },
  setConnectionEnabled: { mutate: vi.fn() },
  deleteConnection: { mutate: vi.fn() },
};
const trpc = {
  me: { query: vi.fn() },
  services: { list: { query: vi.fn() } },
  observabilityIntegrations: integrations,
};
const apps: Vue.App<Node>[] = [];

async function mountPage() {
  // Run the actual SFC and template in the same node-only renderer pattern as license-ui.test.ts.
  const filename = fileURLToPath(
    new URL(
      '../app/pages/services/[serviceId]/integrations.vue',
      import.meta.url,
    ),
  );
  const { descriptor } = parse(readFileSync(filename, 'utf8'), { filename });
  const script = compileScript(descriptor, {
    id: 'discovery-ui',
    inlineTemplate: true,
    templateOptions: { compilerOptions: { hoistStatic: false } },
  });
  const code = ts.transpileModule(script.content, {
    compilerOptions: {
      module: ts.ModuleKind.CommonJS,
      target: ts.ScriptTarget.ES2022,
    },
  }).outputText;
  const dependencies: Record<string, unknown> = {
    vue: Vue,
    '@trpc/client': { TRPCClientError },
    '#app': { useNuxtApp: () => ({ $trpc: trpc }), useRoute: () => route },
    '../../../composables/useAppToast': { useAppToast: () => toast },
  };
  const module = { exports: {} as { default: Vue.Component } };
  new Function('require', 'module', 'exports', code)(
    (name: string) => {
      if (!(name in dependencies))
        throw new Error(`Unmocked SFC import: ${name}`);
      return dependencies[name];
    },
    module,
    module.exports,
  );
  const root = makeNode('root');
  const app = renderer.createApp(module.exports.default);
  for (const [name, component] of Object.entries({
    UCard: SlotStub,
    UBadge: SlotStub,
    UFormField: SlotStub,
    UIcon: SlotStub,
    USkeleton: SlotStub,
    UButton: ButtonStub,
    UInput: InputStub,
    USelect: SelectStub,
    UDropdownMenu: MenuStub,
    UModal: ModalStub,
    UAlert: AlertStub,
  }))
    app.component(name, component);
  apps.push(app);
  app.mount(root);
  await until(() =>
    expect(button(root, `Test ${connection.name}`)).toBeDefined(),
  );
  return root;
}

beforeEach(() => {
  vi.resetAllMocks();
  vi.useFakeTimers();
  vi.setSystemTime(now);
  route.params.serviceId = serviceId;
  trpc.me.query.mockResolvedValue({
    permissions: { isAdmin: true, permissions: {} },
  });
  trpc.services.list.query.mockResolvedValue([
    { id: serviceId, name: 'Checkout' },
  ]);
  integrations.listProviders.query.mockResolvedValue([]);
  integrations.listConnections.query.mockResolvedValue([connection]);
  integrations.listCapabilityConnections.query.mockResolvedValue(
    connection.supportedSignals.map((signal) => ({
      signal,
      connectionId: signal === 'ERRORS' ? connection.id : null,
    })),
  );
  integrations.setCapabilityConnections.mutate.mockImplementation(
    async ({ capabilities }) => capabilities,
  );
  integrations.testConnection.mutate.mockResolvedValue(readyResult());
  vi.stubGlobal(
    'fetch',
    vi.fn().mockRejectedValue(new Error('Unexpected external request')),
  );
});

afterEach(() => {
  for (const app of apps.splice(0)) app.unmount();
  vi.clearAllTimers();
  vi.useRealTimers();
  vi.unstubAllGlobals();
  vi.restoreAllMocks();
});

describe('connection discovery results', () => {
  it('accepts older responses without additive failure details', async () => {
    const { failures: _failures, ...result } = readyResult();
    integrations.testConnection.mutate.mockResolvedValueOnce(result);
    const root = await mountPage();
    expect(await click(root, `Test ${connection.name}`)).toBe(true);
    await Vue.nextTick();
    expect(text(root)).toContain('All capability checks are available.');
    expect(toast.showError).not.toHaveBeenCalled();
  });

  it.each([
    undefined,
    '2026-09-16T12:00:05.000Z',
  ])('shows partial reasons, warnings and the effective retry time when section retryAt is %s', async (sectionRetryAt) => {
    const releaseFailure = {
      ...rateFailure,
      section: 'releases',
      code: 'AUTHENTICATION_FAILED',
      reason: 'Token lacks release scope.',
    };
    integrations.testConnection.mutate.mockResolvedValueOnce({
      ...readyResult(refreshedConnection),
      alerts: {
        availability: 'UNAVAILABLE',
        code: rateFailure.code,
        reason: rateFailure.reason,
        ...(sectionRetryAt ? { retryAt: sectionRetryAt } : {}),
      },
      releases: {
        availability: 'UNAVAILABLE',
        code: releaseFailure.code,
        reason: releaseFailure.reason,
      },
      failures: [{ ...rateFailure, retryAt }, releaseFailure],
      warnings: ['Tag discovery returned limited metadata.'],
    });
    const root = await mountPage();
    expect(await click(root, `Test ${connection.name}`)).toBe(true);
    await Vue.nextTick();

    expect(text(root)).toContain('Partially verified');
    expect(text(root)).toContain('2 of 4 capability checks are available');
    expect(text(root)).toContain('Unavailable: alerts, releases.');
    expect(text(root)).toContain(
      `Alerts (RATE_LIMITED): ${rateFailure.reason} Retry after ${retryLabel()}.`,
    );
    expect(text(root)).toContain(
      'Releases (AUTHENTICATION_FAILED): Token lacks release scope.',
    );
    expect(text(root)).toContain('Tag discovery returned limited metadata.');
    expect(text(root)).toContain('Sentry project: acme/checkout-renamed');
    expect(
      nodes(root).some(
        (node) =>
          node.type === 'option' && text(node).includes('(Partially verified)'),
      ),
    ).toBe(true);
    expect(toast.showError).not.toHaveBeenCalled();
    expect(integrations.testConnection.mutate).toHaveBeenCalledExactlyOnceWith({
      serviceId,
      connectionId: connection.id,
    });
    expect(integrations.listConnections.query).toHaveBeenCalledTimes(1);
    expect(vi.getTimerCount()).toBe(0);
    await vi.advanceTimersByTimeAsync(60_000);
    expect(integrations.testConnection.mutate).toHaveBeenCalledTimes(1);

    integrations.testConnection.mutate.mockResolvedValueOnce(
      readyResult(refreshedConnection),
    );
    expect(await click(root, `Test ${connection.name}`)).toBe(true);
    await Vue.nextTick();
    expect(text(root)).toContain('All capability checks are available.');
    expect(text(root)).not.toContain('View test details');
    expect(text(root)).not.toContain(rateFailure.reason);
    expect(text(root)).not.toContain(
      'Tag discovery returned limited metadata.',
    );
    expect(text(root)).not.toContain('Partially verified');
  });

  it.each([
    'failures',
    'warnings',
  ] as const)('does not hide %s when every section is available', async (detail) => {
    integrations.testConnection.mutate.mockResolvedValueOnce({
      ...readyResult(),
      [detail]:
        detail === 'failures'
          ? [{ ...rateFailure, retryAt }]
          : ['Some discovery values were redacted.'],
    });
    const root = await mountPage();
    await click(root, `Test ${connection.name}`);
    await Vue.nextTick();

    expect(text(root)).toContain('Partially verified');
    expect(text(root)).toContain('4 of 4 capability checks are available');
    expect(text(root)).toContain('review the test details below');
    expect(text(root)).toContain(
      detail === 'failures'
        ? rateFailure.reason
        : 'Some discovery values were redacted.',
    );
    expect(text(root)).not.toContain('Unavailable:');
    expect(text(root)).not.toContain('filtering for missing checks');
    expect(toast.showSuccess).toHaveBeenCalledWith(
      'Connection partially verified',
      expect.any(String),
    );
  });

  it('refreshes config after a rejected test without resetting drafts or another connection snapshot', async () => {
    const other = { ...connection, id: 'sentry-other', name: 'Sentry other' };
    const testedOther = {
      ...refreshedConnection,
      id: other.id,
      name: other.name,
      publicConfig: { ...other.publicConfig, projectSlug: 'other-refreshed' },
    };
    integrations.listConnections.query.mockResolvedValueOnce([
      connection,
      other,
    ]);
    integrations.testConnection.mutate
      .mockResolvedValueOnce(readyResult(testedOther))
      .mockRejectedValueOnce(rateError());
    const root = await mountPage();
    await click(root, `Test ${other.name}`);
    await Vue.nextTick();
    const selection = nodes(root).find((node) => node.type === 'select')!;
    selection.props.onChange({ target: { value: other.id } });
    click(root, 'Edit connection');
    await Vue.nextTick();
    input(root, 'Connection label (optional)').props.onInput({
      target: { value: 'Unsaved label' },
    });

    integrations.listConnections.query.mockResolvedValueOnce([
      refreshedConnection,
      other,
    ]);
    expect(await click(root, `Test ${connection.name}`)).toBe(false);
    await Vue.nextTick();
    expect(text(root)).toContain('Failed');
    expect(text(root)).toContain(
      `Provider rate limit. Retry after ${retryLabel()}.`,
    );
    expect(text(root)).toContain('Sentry project: acme/checkout-renamed');
    expect(text(root)).toContain('Sentry project: acme/other-refreshed');
    expect(text(button(root, `Test ${other.name}`)!)).toBe('Test again');
    expect(input(root, 'Connection label (optional)').props.value).toBe(
      'Unsaved label',
    );
    expect(
      nodes(root).find((node) => node.type === 'select')!.props.value,
    ).toBe(other.id);
    expect(integrations.listConnections.query).toHaveBeenCalledTimes(2);
    expect(trpc.services.list.query).toHaveBeenCalledTimes(1);
    expect(integrations.listCapabilityConnections.query).toHaveBeenCalledTimes(
      1,
    );
    expect(toast.showError).toHaveBeenCalledWith(
      'Connection could not be verified',
      `Provider rate limit. Retry after ${retryLabel()}.`,
    );
    expect(vi.getTimerCount()).toBe(0);
    await vi.advanceTimersByTimeAsync(60_000);
    expect(integrations.testConnection.mutate).toHaveBeenCalledTimes(2);

    click(root, 'Cancel');
    integrations.testConnection.mutate.mockResolvedValueOnce(
      readyResult(refreshedConnection),
    );
    expect(await click(root, `Test ${connection.name}`)).toBe(true);
    await Vue.nextTick();
    expect(text(root)).not.toContain('Provider rate limit.');
    expect(text(root)).toContain('Sentry project: acme/checkout-renamed');
  });

  it('keeps the original rejection and retry time if config reconciliation also fails', async () => {
    const root = await mountPage();
    integrations.testConnection.mutate.mockRejectedValueOnce(rateError());
    integrations.listConnections.query.mockRejectedValueOnce(
      new Error('Connection read unavailable.'),
    );
    expect(await click(root, `Test ${connection.name}`)).toBe(false);
    await Vue.nextTick();

    expect(text(root)).toContain(
      `Provider rate limit. Retry after ${retryLabel()}.`,
    );
    expect(text(root)).toContain(
      'Connection configuration could not be refreshed: Connection read unavailable.',
    );
    expect(text(root)).toContain(
      'Refresh the page before editing this connection.',
    );
    expect(text(root)).not.toContain('Partially verified');
    expect(button(root, `Test ${connection.name}`)?.props.disabled).toBe(false);
    expect(integrations.testConnection.mutate).toHaveBeenCalledTimes(1);
    expect(integrations.listConnections.query).toHaveBeenCalledTimes(2);
    expect(vi.getTimerCount()).toBe(0);
  });

  it('preserves non-rate-limit errors without inventing retry timing or successful checks', async () => {
    integrations.testConnection.mutate.mockRejectedValueOnce(
      Object.assign(new TRPCClientError('Sentry authentication failed.'), {
        data: { code: 'PRECONDITION_FAILED' },
      }),
    );
    const root = await mountPage();
    integrations.listConnections.query.mockResolvedValueOnce([
      refreshedConnection,
    ]);
    expect(await click(root, `Test ${connection.name}`)).toBe(false);
    await Vue.nextTick();

    expect(text(root)).toContain('Sentry authentication failed.');
    expect(text(root)).toContain('Sentry project: acme/checkout-renamed');
    expect(text(root)).not.toContain('Retry after');
    expect(text(root)).not.toContain('All capability checks are available.');
    expect(toast.showError).toHaveBeenCalledWith(
      'Connection could not be verified',
      'Sentry authentication failed.',
    );
    expect(toast.showSuccess).not.toHaveBeenCalled();
    expect(integrations.testConnection.mutate).toHaveBeenCalledTimes(1);
  });
});

describe('connection saves preserve capability drafts', () => {
  const other = { ...connection, id: 'sentry-other', name: 'Sentry other' };
  const savedOther = { ...editedConnection, id: other.id };
  const assignments = connection.supportedSignals.map((signal) => ({
    signal,
    connectionId: signal === 'LOGS' ? connection.id : null,
  }));

  beforeEach(() => {
    integrations.listConnections.query.mockResolvedValue([connection, other]);
    integrations.listCapabilityConnections.query.mockResolvedValue(assignments);
    integrations.upsertConnection.mutate.mockResolvedValue(savedOther);
    integrations.testConnection.mutate.mockImplementation(
      async ({ connectionId }) =>
        readyResult(
          connectionId === connection.id ? refreshedConnection : savedOther,
        ),
    );
  });

  it.each([
    'create',
    'edit',
  ] as const)('retains drafts and a pending test of A when saving B (%s)', async (action) => {
    if (action === 'create') {
      integrations.listConnections.query.mockResolvedValueOnce([connection]);
      integrations.listProviders.query.mockResolvedValue([
        {
          provider: 'SENTRY',
          displayName: 'Sentry',
          supportedSignals: connection.supportedSignals,
          credentialGuidance: 'Project read access.',
        },
      ]);
    }
    const root = await mountPage();
    await click(root, `Test ${connection.name}`);
    await Vue.nextTick();
    const [errors, logs] = nodes(root).filter((node) => node.type === 'select');
    errors!.props.onChange({ target: { value: connection.id } });
    logs!.props.onChange({ target: { value: '__unassigned__' } });
    const response = deferred();
    integrations.testConnection.mutate.mockReturnValueOnce(response.promise);
    const pendingTest = click(root, `Test ${connection.name}`);

    if (action === 'create') {
      click(root, 'Add connection');
      await until(() => expect(text(root)).toContain('Supports:'));
      nodes(root)
        .find(
          (node) => node.type === 'button' && text(node).includes('Supports:'),
        )!
        .props.onClick();
    } else {
      click(button(root, `Manage ${other.name}`)!.parent!, 'Edit connection');
    }
    await Vue.nextTick();
    input(root, 'Organization slug').props.onInput({
      target: { value: 'acme' },
    });
    input(root, 'Project ID').props.onInput({ target: { value: '123' } });
    input(root, 'Connection label (optional)').props.onInput({
      target: { value: savedOther.name },
    });
    if (action === 'create') {
      input(root, 'Auth token').props.onInput({
        target: { value: 'test-token' },
      });
    }
    await submit(root);
    await Vue.nextTick();

    expect(errors!.props.value).toBe(connection.id);
    expect(logs!.props.value).toBe('__unassigned__');
    expect(text(root)).toContain('Used for: Logs.');
    expect(text(root)).not.toContain('Used for: Errors.');
    expect(text(root)).toContain('Sentry project: acme/checkout-renamed');
    expect(button(root, `Test ${connection.name}`)?.props.disabled).toBe(true);
    expect(text(button(root, `Test ${savedOther.name}`)!)).toBe('Test again');
    expect(button(root, `Manage ${other.name}`)).toBeUndefined();
    expect(integrations.listConnections.query).toHaveBeenCalledTimes(1);
    expect(integrations.listCapabilityConnections.query).toHaveBeenCalledTimes(
      1,
    );
    expect(trpc.services.list.query).toHaveBeenCalledTimes(1);

    response.resolve(readyResult(refreshedConnection));
    expect(await pendingTest).toBe(true);
    await Vue.nextTick();
    await click(root, 'Save');
    expect(
      integrations.setCapabilityConnections.mutate,
    ).toHaveBeenCalledExactlyOnceWith({
      serviceId,
      capabilities: assignments.map(({ signal }) => ({
        signal,
        connectionId: signal === 'ERRORS' ? connection.id : null,
      })),
    });
    await Vue.nextTick();
    expect(text(root)).toContain('Used for: Errors.');
    expect(text(root)).not.toContain('Used for: Logs.');
    expect(toast.showSuccess).toHaveBeenCalledWith('RCA capabilities saved');
  });

  it.each([
    'save',
    'test',
  ] as const)('retains A and its test state when the %s of B fails', async (failure) => {
    const root = await mountPage();
    await click(root, `Test ${connection.name}`);
    await Vue.nextTick();
    const errors = nodes(root).find((node) => node.type === 'select')!;
    errors.props.onChange({ target: { value: connection.id } });
    click(button(root, `Manage ${other.name}`)!.parent!, 'Edit connection');
    await Vue.nextTick();
    if (failure === 'save') {
      integrations.upsertConnection.mutate.mockRejectedValueOnce(
        new Error('Save conflict.'),
      );
    } else {
      integrations.testConnection.mutate.mockRejectedValueOnce(rateError());
      integrations.listConnections.query.mockResolvedValueOnce([
        connection,
        savedOther,
      ]);
    }
    await submit(root);
    await Vue.nextTick();

    expect(errors.props.value).toBe(connection.id);
    expect(text(button(root, `Test ${connection.name}`)!)).toBe('Test again');
    expect(text(root)).toContain('Sentry project: acme/checkout-renamed');
    expect(text(root)).toContain(
      failure === 'save' ? 'Save conflict.' : 'Provider rate limit.',
    );
    expect(integrations.listConnections.query).toHaveBeenCalledTimes(
      failure === 'save' ? 1 : 2,
    );
    expect(integrations.listCapabilityConnections.query).toHaveBeenCalledTimes(
      1,
    );
    if (failure === 'save') {
      click(root, 'Cancel');
      await Vue.nextTick();
    }
    await click(root, 'Save');
    expect(
      integrations.setCapabilityConnections.mutate,
    ).toHaveBeenCalledExactlyOnceWith({
      serviceId,
      capabilities: assignments.map(({ signal }) => ({
        signal,
        connectionId:
          signal === 'ERRORS' || signal === 'LOGS' ? connection.id : null,
      })),
    });
  });

  it('keeps the saved baseline distinct from preserved drafts', async () => {
    const root = await mountPage();
    await click(root, `Test ${connection.name}`);
    await Vue.nextTick();
    const errors = nodes(root).find((node) => node.type === 'select')!;
    errors.props.onChange({ target: { value: connection.id } });
    click(button(root, `Manage ${other.name}`)!.parent!, 'Edit connection');
    await Vue.nextTick();
    await submit(root);
    integrations.testConnection.mutate.mockResolvedValueOnce({
      ...readyResult(refreshedConnection),
      connection: { availability: 'UNAVAILABLE', reason: 'Access revoked.' },
    });
    await click(root, `Test ${connection.name}`);
    await Vue.nextTick();
    await click(root, 'Save');
    expect(integrations.setCapabilityConnections.mutate).not.toHaveBeenCalled();
    await Vue.nextTick();
    expect(text(root)).toContain(
      `Test ${connection.name} before assigning it to Errors.`,
    );

    errors.props.onChange({ target: { value: '__unassigned__' } });
    await click(root, 'Save');
    expect(
      integrations.setCapabilityConnections.mutate,
    ).toHaveBeenCalledExactlyOnceWith({
      serviceId,
      capabilities: assignments,
    });
  });

  it.each([
    'service change',
    'unmount',
  ] as const)('ignores a pending connection save after %s', async (action) => {
    const response = deferred();
    integrations.upsertConnection.mutate.mockReturnValueOnce(response.promise);
    const root = await mountPage();
    click(button(root, `Manage ${other.name}`)!.parent!, 'Edit connection');
    await Vue.nextTick();
    const saving = submit(root);
    if (action === 'service change') route.params.serviceId = 'other-service';
    else apps.pop()!.unmount();
    response.resolve(savedOther);
    await saving;
    await Vue.nextTick();

    expect(text(root)).not.toContain(savedOther.name);
    expect(integrations.testConnection.mutate).not.toHaveBeenCalled();
    expect(integrations.listConnections.query).toHaveBeenCalledTimes(1);
    expect(toast.showSuccess).not.toHaveBeenCalled();
    expect(toast.showError).not.toHaveBeenCalled();
  });

  it.each([
    'deletion',
    'newer revision',
  ] as const)('does not restore a connection when its %s overtakes a save response', async (action) => {
    const response = deferred();
    integrations.upsertConnection.mutate.mockReturnValueOnce(response.promise);
    const root = await mountPage();
    const menu = button(root, `Manage ${other.name}`)!.parent!;
    const logs = nodes(root).filter((node) => node.type === 'select')[1]!;
    logs.props.onChange({ target: { value: '__unassigned__' } });
    click(menu, 'Edit connection');
    await Vue.nextTick();
    const saving = submit(root);
    if (action === 'deletion') {
      integrations.deleteConnection.mutate.mockResolvedValueOnce({
        id: other.id,
      });
      integrations.listConnections.query.mockResolvedValueOnce([connection]);
      click(menu, 'Delete connection');
      await Vue.nextTick();
      await click(root, 'Delete and unassign');
    } else {
      integrations.setConnectionEnabled.mutate.mockResolvedValueOnce({
        ...other,
        enabled: false,
        updatedAt: new Date('2026-09-16T12:00:03.000Z'),
      });
      click(menu, 'Disable');
      await until(() =>
        expect(toast.showSuccess).toHaveBeenCalledWith(
          'Connection disabled',
          expect.any(String),
        ),
      );
    }
    response.resolve(savedOther);
    await saving;
    await Vue.nextTick();

    expect(text(root)).not.toContain(savedOther.name);
    expect(integrations.testConnection.mutate).not.toHaveBeenCalled();
    if (action === 'deletion') {
      expect(button(root, `Manage ${other.name}`)).toBeUndefined();
      expect(logs.props.value).toBe(connection.id);
      expect(
        integrations.listCapabilityConnections.query,
      ).toHaveBeenCalledTimes(2);
    } else {
      expect(logs.props.value).toBe('__unassigned__');
      expect(button(root, `Test ${other.name}`)?.props.disabled).toBe(true);
      expect(button(root, 'Enable')).toBeDefined();
    }
  });
});

describe('connection toggle request ownership', () => {
  const initial = {
    ...connection,
    publicConfig: { ...connection.publicConfig, projectId: '42' },
  };
  const saved = {
    ...editedConnection,
    publicConfig: { ...editedConnection.publicConfig, projectId: '43' },
  };

  beforeEach(() => {
    integrations.listConnections.query.mockResolvedValue([initial]);
    integrations.upsertConnection.mutate.mockResolvedValue(saved);
    integrations.testConnection.mutate.mockResolvedValue(readyResult(saved));
  });

  it.each([
    'older response',
    'same-ms edit',
    'rejection',
  ] as const)('preserves a newer edit, test and other connection drafts after a toggle %s', async (outcome) => {
    const other = { ...connection, id: 'sentry-other', name: 'Sentry other' };
    const edited =
      outcome === 'same-ms edit'
        ? { ...saved, updatedAt: initial.updatedAt }
        : saved;
    const response = deferred();
    integrations.listConnections.query.mockResolvedValueOnce([initial, other]);
    integrations.upsertConnection.mutate.mockResolvedValueOnce(edited);
    integrations.testConnection.mutate
      .mockResolvedValueOnce(readyResult(other))
      .mockResolvedValueOnce(readyResult(edited));
    integrations.setConnectionEnabled.mutate.mockReturnValueOnce(
      response.promise,
    );
    const root = await mountPage();
    await click(root, `Test ${other.name}`);
    await Vue.nextTick();
    const selection = nodes(root).find((node) => node.type === 'select')!;
    selection.props.onChange({ target: { value: other.id } });

    click(root, 'Disable');
    await Vue.nextTick();
    expect(button(root, `Test ${initial.name}`)?.props.disabled).toBe(true);
    expect(button(root, `Test ${other.name}`)?.props.disabled).toBe(false);
    expect(await button(root, `Test ${initial.name}`)!.props.onClick()).toBe(
      false,
    );
    expect(integrations.testConnection.mutate).toHaveBeenCalledTimes(1);
    click(root, 'Edit connection');
    await Vue.nextTick();
    input(root, 'Project ID').props.onInput({ target: { value: '43' } });
    input(root, 'Connection label (optional)').props.onInput({
      target: { value: saved.name },
    });
    await submit(root);
    await Vue.nextTick();
    expect(text(button(root, `Test ${saved.name}`)!)).toBe('Test again');
    expect(button(root, `Test ${saved.name}`)?.props.disabled).toBe(false);
    expect(button(root, 'Disable')?.props.disabled).toBe(true);
    button(root, 'Disable')!.props.onClick();
    expect(integrations.setConnectionEnabled.mutate).toHaveBeenCalledTimes(1);

    if (outcome === 'rejection') {
      response.reject(new Error('Obsolete toggle failed.'));
      await expect(response.promise).rejects.toThrow('Obsolete toggle failed.');
    } else {
      response.resolve({
        ...initial,
        enabled: false,
        updatedAt:
          outcome === 'same-ms edit'
            ? initial.updatedAt
            : refreshedConnection.updatedAt,
      });
      await response.promise;
    }
    await Vue.nextTick();

    expect(text(root)).toContain('Sentry project: acme/user-project');
    expect(text(button(root, `Test ${saved.name}`)!)).toBe('Test again');
    expect(button(root, `Test ${saved.name}`)?.props.disabled).toBe(false);
    expect(text(button(root, `Test ${other.name}`)!)).toBe('Test again');
    expect(selection.props.value).toBe(other.id);
    expect(toast.showSuccess).toHaveBeenCalledTimes(2);
    expect(toast.showError).not.toHaveBeenCalled();
    expect(integrations.listConnections.query).toHaveBeenCalledTimes(1);
    expect(integrations.listCapabilityConnections.query).toHaveBeenCalledTimes(
      1,
    );
    expect(
      integrations.upsertConnection.mutate,
    ).toHaveBeenCalledExactlyOnceWith(
      expect.objectContaining({
        connectionId: initial.id,
        publicConfig: expect.objectContaining({ projectId: '43' }),
      }),
    );
    click(root, 'Edit connection');
    await Vue.nextTick();
    expect(input(root, 'Project ID').props.value).toBe('43');
  });

  it.each([
    'older',
    'same-ms',
    'newer',
  ] as const)('compares an owned %s toggle response with an edit that was already saving', async (order) => {
    const saveResponse = deferred();
    const toggleResponse = deferred();
    integrations.upsertConnection.mutate.mockReturnValueOnce(
      saveResponse.promise,
    );
    integrations.setConnectionEnabled.mutate.mockReturnValueOnce(
      toggleResponse.promise,
    );
    const root = await mountPage();
    click(root, 'Edit connection');
    await Vue.nextTick();
    input(root, 'Project ID').props.onInput({ target: { value: '43' } });
    input(root, 'Connection label (optional)').props.onInput({
      target: { value: saved.name },
    });
    const saving = submit(root);
    click(root, 'Disable');
    saveResponse.resolve(saved);
    await saving;
    await Vue.nextTick();
    expect(text(root)).toContain('Sentry project: acme/user-project');
    expect(text(button(root, `Test ${saved.name}`)!)).toBe('Test again');
    expect(button(root, 'Disable')?.props.disabled).toBe(true);

    toggleResponse.resolve({
      ...(order === 'newer' ? saved : initial),
      enabled: false,
      updatedAt: new Date(
        saved.updatedAt.getTime() +
          (order === 'older' ? -1 : order === 'newer' ? 1 : 0),
      ),
    });
    await toggleResponse.promise;
    await Vue.nextTick();

    expect(text(root)).toContain('Sentry project: acme/user-project');
    expect(button(root, `Test ${saved.name}`)?.props.disabled).toBe(
      order === 'newer',
    );
    expect(
      button(root, order === 'newer' ? 'Enable' : 'Disable')?.props.disabled,
    ).toBe(false);
    expect(text(button(root, `Test ${saved.name}`)!)).toBe(
      order === 'newer' ? 'Test connection' : 'Test again',
    );
    if (order === 'newer') {
      expect(toast.showSuccess).toHaveBeenCalledWith(
        'Connection disabled',
        `${saved.name} remains assigned but RCA will not use it.`,
      );
    }
    expect(toast.showSuccess).toHaveBeenCalledWith(
      'Connection verified',
      expect.any(String),
    );
    expect(toast.showSuccess).toHaveBeenCalledTimes(order === 'newer' ? 2 : 1);
    expect(toast.showError).not.toHaveBeenCalled();
  });

  it.each([
    'success',
    'rejection',
    'failure refetch',
  ] as const)('applies a newer toggle started before an edit and ignores its obsolete test %s', async (outcome) => {
    const toggleResponse = deferred();
    const testResponse = deferred();
    const refreshResponse = deferred();
    integrations.setConnectionEnabled.mutate.mockReturnValueOnce(
      toggleResponse.promise,
    );
    const root = await mountPage();
    click(root, 'Disable');
    click(root, 'Edit connection');
    await Vue.nextTick();
    input(root, 'Project ID').props.onInput({ target: { value: '43' } });
    input(root, 'Connection label (optional)').props.onInput({
      target: { value: saved.name },
    });
    await submit(root);
    await Vue.nextTick();
    expect(text(button(root, `Test ${saved.name}`)!)).toBe('Test again');

    integrations.testConnection.mutate.mockReturnValueOnce(
      testResponse.promise,
    );
    const testing = click(root, `Test ${saved.name}`);
    await Vue.nextTick();
    expect(button(root, `Test ${saved.name}`)?.props.loading).toBe(true);
    if (outcome === 'failure refetch') {
      integrations.listConnections.query.mockReturnValueOnce(
        refreshResponse.promise,
      );
      testResponse.reject(rateError());
      await until(() =>
        expect(integrations.listConnections.query).toHaveBeenCalledTimes(2),
      );
    }
    toggleResponse.resolve({
      ...saved,
      enabled: false,
      updatedAt: new Date(saved.updatedAt.getTime() + 1),
    });
    await toggleResponse.promise;
    await Vue.nextTick();

    expect(button(root, 'Enable')?.props.disabled).toBe(false);
    expect(button(root, `Test ${saved.name}`)?.props.disabled).toBe(true);
    expect(button(root, `Test ${saved.name}`)?.props.loading).toBe(false);
    expect(text(root)).toContain('Sentry project: acme/user-project');
    expect(toast.showSuccess).toHaveBeenCalledWith(
      'Connection disabled',
      `${saved.name} remains assigned but RCA will not use it.`,
    );

    if (outcome === 'success') testResponse.resolve(readyResult(saved));
    else if (outcome === 'rejection') testResponse.reject(rateError());
    else refreshResponse.resolve([initial]);
    expect(await testing).toBe(false);
    await Vue.nextTick();
    expect(button(root, 'Enable')?.props.disabled).toBe(false);
    expect(button(root, `Test ${saved.name}`)?.props.disabled).toBe(true);
    expect(button(root, `Test ${saved.name}`)?.props.loading).toBe(false);
    expect(text(button(root, `Test ${saved.name}`)!)).toBe('Test connection');
    expect(text(root)).toContain('Sentry project: acme/user-project');
    expect(text(root)).not.toContain('Provider rate limit.');
    expect(toast.showSuccess).toHaveBeenCalledTimes(2);
    expect(toast.showError).not.toHaveBeenCalled();
    expect(integrations.listConnections.query).toHaveBeenCalledTimes(
      outcome === 'failure refetch' ? 2 : 1,
    );
    click(root, 'Edit connection');
    await Vue.nextTick();
    expect(input(root, 'Project ID').props.value).toBe('43');
  });

  it('keeps replacement toggle ownership after navigation and normal success/error behavior', async () => {
    const original = deferred();
    const replacement = deferred();
    integrations.setConnectionEnabled.mutate
      .mockReturnValueOnce(original.promise)
      .mockReturnValueOnce(replacement.promise);
    const root = await mountPage();
    click(root, 'Disable');
    click(root, 'Edit connection');
    await Vue.nextTick();
    input(root, 'Project ID').props.onInput({ target: { value: '43' } });
    input(root, 'Connection label (optional)').props.onInput({
      target: { value: saved.name },
    });
    await submit(root);
    await Vue.nextTick();
    expect(button(root, 'Disable')?.props.disabled).toBe(true);
    route.params.serviceId = 'other-service';
    route.params.serviceId = serviceId;
    await Vue.nextTick();
    click(root, 'Disable');
    original.reject(new Error('Obsolete toggle failed.'));
    await expect(original.promise).rejects.toThrow('Obsolete toggle failed.');
    await Vue.nextTick();

    expect(button(root, 'Disable')?.props.disabled).toBe(true);
    expect(button(root, `Test ${saved.name}`)?.props.disabled).toBe(true);
    expect(text(button(root, `Test ${saved.name}`)!)).toBe('Test again');
    expect(toast.showError).not.toHaveBeenCalled();
    expect(integrations.setConnectionEnabled.mutate).toHaveBeenCalledTimes(2);

    replacement.resolve({
      ...saved,
      enabled: false,
      updatedAt: new Date(saved.updatedAt.getTime() + 1),
    });
    await replacement.promise;
    await Vue.nextTick();
    expect(button(root, 'Enable')?.props.disabled).toBe(false);
    expect(text(root)).not.toContain('All capability checks are available.');
    expect(toast.showSuccess).toHaveBeenCalledWith(
      'Connection disabled',
      expect.any(String),
    );

    const enabled = {
      ...saved,
      updatedAt: new Date(saved.updatedAt.getTime() + 2),
    };
    integrations.setConnectionEnabled.mutate.mockResolvedValueOnce(enabled);
    click(root, 'Enable');
    await until(() =>
      expect(button(root, 'Disable')?.props.disabled).toBe(false),
    );
    expect(button(root, `Test ${saved.name}`)?.props.disabled).toBe(false);
    expect(text(button(root, `Test ${saved.name}`)!)).toBe('Test connection');
    expect(toast.showSuccess).toHaveBeenCalledWith(
      'Connection enabled',
      expect.any(String),
    );
    integrations.testConnection.mutate.mockResolvedValueOnce(
      readyResult(enabled),
    );
    expect(await click(root, `Test ${saved.name}`)).toBe(true);

    integrations.setConnectionEnabled.mutate.mockRejectedValueOnce(
      new Error('Toggle unavailable.'),
    );
    click(root, 'Disable');
    await until(() =>
      expect(toast.showError).toHaveBeenCalledExactlyOnceWith(
        'Could not disable connection',
        'Toggle unavailable.',
      ),
    );
    await Vue.nextTick();
    expect(button(root, 'Disable')?.props.disabled).toBe(false);
    expect(button(root, `Test ${saved.name}`)?.props.disabled).toBe(false);
    expect(text(button(root, `Test ${saved.name}`)!)).toBe('Test again');
    expect(
      integrations.setConnectionEnabled.mutate.mock.calls.map(
        ([value]) => value,
      ),
    ).toEqual(
      [false, false, true, false].map((enabled) => ({
        serviceId,
        connectionId: initial.id,
        enabled,
      })),
    );
  });

  it.each([
    'delete',
    'service change and return',
    'unmount',
  ] as const)('cancels a pending toggle on %s', async (action) => {
    const response = deferred();
    const deletion = deferred();
    integrations.setConnectionEnabled.mutate.mockReturnValueOnce(
      response.promise,
    );
    const root = await mountPage();
    click(root, 'Disable');
    let deleting: Promise<void> | undefined;
    if (action === 'delete') {
      integrations.deleteConnection.mutate.mockReturnValueOnce(
        deletion.promise,
      );
      integrations.listConnections.query.mockResolvedValueOnce([]);
      click(root, 'Delete connection');
      await Vue.nextTick();
      deleting = click(root, 'Delete and unassign');
    } else if (action === 'service change and return') {
      route.params.serviceId = 'other-service';
      route.params.serviceId = serviceId;
    } else apps.pop()!.unmount();

    response.resolve({ ...refreshedConnection, enabled: false });
    await response.promise;
    await Vue.nextTick();
    expect(text(root)).not.toContain('acme/checkout-renamed');
    expect(toast.showSuccess).not.toHaveBeenCalled();
    expect(toast.showError).not.toHaveBeenCalled();
    if (action !== 'unmount') {
      expect(button(root, 'Disable')?.props.disabled).toBe(false);
      expect(button(root, `Test ${initial.name}`)?.props.disabled).toBe(false);
    }
    if (action === 'delete') {
      deletion.resolve({ id: initial.id });
      await deleting;
      await Vue.nextTick();
      expect(button(root, `Manage ${initial.name}`)).toBeUndefined();
    }
  });
});

describe('connection test request ownership', () => {
  it.each([
    'success',
    'rejection',
  ] as const)('ignores an old test %s after a newer edit and test', async (outcome) => {
    const response = deferred();
    integrations.testConnection.mutate.mockReturnValueOnce(response.promise);
    const root = await mountPage();
    const oldTest = click(root, `Test ${connection.name}`);
    click(root, 'Edit connection');
    await Vue.nextTick();
    input(root, 'Connection label (optional)').props.onInput({
      target: { value: editedConnection.name },
    });
    integrations.upsertConnection.mutate.mockResolvedValueOnce(
      editedConnection,
    );
    integrations.testConnection.mutate.mockResolvedValueOnce(
      readyResult(editedConnection),
    );
    await submit(root);

    if (outcome === 'success')
      response.resolve(readyResult(refreshedConnection));
    else response.reject(rateError());
    expect(await oldTest).toBe(false);
    await Vue.nextTick();
    expect(text(root)).toContain('User edit');
    expect(text(root)).toContain('Sentry project: acme/user-project');
    expect(text(root)).not.toContain('acme/checkout-renamed');
    expect(text(root)).not.toContain('Provider rate limit.');
    expect(text(root)).toContain('All capability checks are available.');
    expect(toast.showSuccess).toHaveBeenCalledTimes(1);
    expect(toast.showError).not.toHaveBeenCalled();
    expect(integrations.listConnections.query).toHaveBeenCalledTimes(1);
  });

  it('does not apply a failed test refetch over an edit saved while that refetch was pending', async () => {
    const refresh = deferred();
    const root = await mountPage();
    integrations.testConnection.mutate.mockRejectedValueOnce(rateError());
    integrations.listConnections.query.mockReturnValueOnce(refresh.promise);
    const oldTest = click(root, `Test ${connection.name}`);
    await until(() =>
      expect(integrations.listConnections.query).toHaveBeenCalledTimes(2),
    );
    click(root, 'Edit connection');
    await Vue.nextTick();
    integrations.upsertConnection.mutate.mockResolvedValueOnce(
      editedConnection,
    );
    integrations.testConnection.mutate.mockResolvedValueOnce(
      readyResult(editedConnection),
    );
    await submit(root);
    refresh.resolve([refreshedConnection]);
    expect(await oldTest).toBe(false);
    await Vue.nextTick();

    expect(text(root)).toContain('Sentry project: acme/user-project');
    expect(text(root)).not.toContain('acme/checkout-renamed');
    expect(text(root)).not.toContain('Provider rate limit.');
    expect(text(root)).toContain('All capability checks are available.');
    expect(toast.showSuccess).toHaveBeenCalledTimes(1);
    expect(toast.showError).not.toHaveBeenCalled();
  });

  it('does not let an obsolete rejection finish a replacement test of the same revision', async () => {
    const original = deferred();
    const replacement = deferred();
    integrations.testConnection.mutate
      .mockReturnValueOnce(original.promise)
      .mockReturnValueOnce(replacement.promise);
    const root = await mountPage();
    const oldTest = click(root, `Test ${connection.name}`);
    click(root, 'Edit connection');
    await Vue.nextTick();
    integrations.upsertConnection.mutate.mockRejectedValueOnce(
      new Error('Save conflict.'),
    );
    await submit(root);
    click(root, 'Cancel');
    await Vue.nextTick();
    const currentTest = click(root, `Test ${connection.name}`);
    original.reject(rateError());
    expect(await oldTest).toBe(false);
    await Vue.nextTick();

    expect(button(root, `Test ${connection.name}`)?.props.disabled).toBe(true);
    expect(toast.showError).not.toHaveBeenCalled();
    expect(toast.showSuccess).not.toHaveBeenCalled();
    expect(integrations.listConnections.query).toHaveBeenCalledTimes(1);
    replacement.resolve(readyResult(refreshedConnection));
    expect(await currentTest).toBe(true);
    await Vue.nextTick();
    expect(text(root)).toContain('All capability checks are available.');
    expect(integrations.testConnection.mutate).toHaveBeenCalledTimes(2);
  });

  it.each([
    'disable',
    'delete',
    'unmount',
  ] as const)('invalidates a pending test on %s', async (action) => {
    const response = deferred();
    integrations.testConnection.mutate.mockReturnValueOnce(response.promise);
    const root = await mountPage();
    const oldTest = click(root, `Test ${connection.name}`);
    if (action === 'disable') {
      integrations.setConnectionEnabled.mutate.mockResolvedValueOnce({
        ...editedConnection,
        enabled: false,
      });
      click(root, 'Disable');
      await until(() =>
        expect(toast.showSuccess).toHaveBeenCalledWith(
          'Connection disabled',
          expect.any(String),
        ),
      );
    } else if (action === 'delete') {
      integrations.deleteConnection.mutate.mockResolvedValueOnce({
        id: connection.id,
      });
      integrations.listConnections.query.mockResolvedValueOnce([]);
      click(root, 'Delete connection');
      await Vue.nextTick();
      await click(root, 'Delete and unassign');
    } else apps.pop()!.unmount();
    response.resolve(readyResult(refreshedConnection));
    expect(await oldTest).toBe(false);
    await Vue.nextTick();

    expect(text(root)).not.toContain('acme/checkout-renamed');
    expect(text(root)).not.toContain('All capability checks are available.');
    expect(toast.showSuccess).not.toHaveBeenCalledWith(
      'Connection verified',
      expect.any(String),
    );
    expect(toast.showError).not.toHaveBeenCalled();
  });
});
