import { vi } from 'vitest';

export function jwt(claims: Record<string, unknown>) {
  return `${Buffer.from('{"alg":"HS256"}').toString('base64url')}.${Buffer.from(
    JSON.stringify(claims),
  ).toString('base64url')}.signature`;
}

export function credentials(
  userId = 'A',
  options: {
    userSecret?: string;
    iat?: number;
    exp?: number;
    refreshExp?: number;
    email?: string;
    permissions?: Record<string, unknown>;
  } = {},
) {
  const iat = options.iat ?? Math.floor(Date.now() / 1000);
  return {
    accessToken: jwt({
      userId,
      email: options.email ?? `${userId}@example.test`,
      permissions: options.permissions ?? { isAdmin: true, permissions: {} },
      iat,
      exp: options.exp ?? iat + 900,
    }),
    refreshToken: jwt({
      userId,
      userSecret: options.userSecret ?? `revocation-version-${userId}`,
      iat,
      exp: options.refreshExp ?? iat + 86400,
    }),
  };
}

export function deferred<T = any>() {
  let resolve!: (value: T) => void;
  let reject!: (error: unknown) => void;
  const promise = new Promise<T>((res, rej) => {
    resolve = res;
    reject = rej;
  });
  return { promise, resolve, reject };
}

export async function until(assertion: () => void) {
  for (let attempt = 0; attempt < 100; attempt++) {
    await new Promise((resolve) => setTimeout(resolve, 0));
    try {
      assertion();
      return;
    } catch (error) {
      if (attempt === 99) throw error;
    }
  }
}

export function installStorage(initial = credentials()) {
  const items = new Map<string, string>(Object.entries(initial));
  const storage: Storage = {
    get length() {
      return items.size;
    },
    key: (index) => [...items.keys()][index] ?? null,
    getItem: (key) => items.get(key) ?? null,
    setItem: vi.fn((key: string, value: string) => {
      items.set(key, String(value));
    }),
    removeItem: vi.fn((key: string) => {
      items.delete(key);
    }),
    clear: () => items.clear(),
  };
  const window = Object.assign(new EventTarget(), {
    localStorage: storage,
    location: {
      href: 'http://localhost/dashboard/#/services',
      origin: 'http://localhost',
      pathname: '/dashboard/',
    },
    close: vi.fn(),
  });
  const addListener = vi.spyOn(window, 'addEventListener');
  const removeListener = vi.spyOn(window, 'removeEventListener');
  const events: Event[] = [];
  const emit = (
    key: string | null,
    oldValue: string | null,
    newValue: string | null,
    queued = false,
    storageArea: Storage | null = storage,
  ) => {
    const event = Object.assign(new Event('storage'), {
      key,
      oldValue,
      newValue,
      storageArea,
    });
    if (queued) events.push(event);
    else window.dispatchEvent(event);
  };
  const change = (key: string, value: string | null, queued = false) => {
    const previous = storage.getItem(key);
    if (value === null) storage.removeItem(key);
    else storage.setItem(key, value);
    emit(key, previous, value, queued);
  };
  const replace = (pair: typeof initial, queued = false, quoted = false) => {
    change(
      'accessToken',
      quoted ? JSON.stringify(pair.accessToken) : pair.accessToken,
      queued,
    );
    change(
      'refreshToken',
      quoted ? JSON.stringify(pair.refreshToken) : pair.refreshToken,
      queued,
    );
  };
  vi.stubGlobal('localStorage', storage);
  vi.stubGlobal('window', window);
  return {
    storage,
    window,
    addListener,
    removeListener,
    emit,
    change,
    replace,
    clear(queued = false) {
      storage.clear();
      emit(null, null, null, queued);
    },
    flushEvents() {
      for (const event of events.splice(0)) window.dispatchEvent(event);
    },
  };
}
