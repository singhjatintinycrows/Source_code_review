import { TRPCClientError } from '@trpc/client';
import superjson from 'superjson';
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import { credentials, deferred, installStorage, until } from './auth-session';
import { signedCredentials, verifyAuthToken } from './signed-auth';

const clearLicense = vi.hoisted(() => vi.fn());
vi.mock('../app/composables/useLicense', () => ({
  useLicense: () => ({ clearLicense }),
}));

const unauthorized = () =>
  Object.assign(new TRPCClientError('Session expired'), {
    data: { code: 'UNAUTHORIZED', httpStatus: 401 },
  });
const handlers = {
  me: vi.fn(),
  refreshAuthToken: vi.fn(),
  refresh: vi.fn(),
  verifySso: vi.fn(),
  getUserCount: vi.fn(),
  'license.submitRelay': vi.fn(),
  'license.acquireCourierLock': vi.fn(),
  'license.releaseCourierLock': vi.fn(),
};
type Request = { paths: string[]; authorization: string | null; inputs: any[] };
let requests: Request[];
let browser: ReturnType<typeof installStorage>;
let authModule: typeof import('../app/composables/useAuth');
let useNuxtApp: typeof import('./nuxt-app')['useNuxtApp'];
let useRuntimeConfig: typeof import('./nuxt-app')['useRuntimeConfig'];
let cancellation: typeof import('../app/utils/operation');
let submitInitialRelay: typeof import('../app/utils/initialRelay')['submitInitialRelay'];
let trpc: ReturnType<
  typeof import('../app/plugins/trpc').default
>['provide']['trpc'];
let stop: (() => void) | undefined;

beforeEach(async () => {
  vi.resetModules();
  vi.resetAllMocks();
  vi.spyOn(Date, 'now').mockReturnValue(Date.UTC(2026, 8, 14));
  ({ useNuxtApp, useRuntimeConfig } = await import('./nuxt-app'));
  browser = installStorage();
  requests = [];
  useRuntimeConfig.mockReturnValue({
    public: { trpcUrl: 'http://localhost/trpc' },
  });
  handlers.me.mockImplementation((_input, request: Request) => ({
    bearer: request.authorization,
  }));
  handlers.getUserCount.mockResolvedValue(1);
  handlers['license.submitRelay'].mockResolvedValue({ success: true });
  vi.stubGlobal(
    'fetch',
    vi.fn(async (urlString: string, init: RequestInit) => {
      const url = new URL(urlString);
      const paths = url.pathname.replace('/trpc/', '').split(',');
      const batch = url.searchParams.get('batch') === '1';
      const rawInput = JSON.parse(
        String(init.body ?? url.searchParams.get('input') ?? 'null'),
      );
      const inputs = paths.map((_path, index) => {
        const input = batch ? rawInput?.[index] : rawInput;
        return input ? superjson.deserialize(input) : undefined;
      });
      const request = {
        paths,
        inputs,
        authorization: new Headers(init.headers).get('authorization'),
      };
      requests.push(request);
      const values = await Promise.all(
        paths.map(async (path, index) => {
          const handler = handlers[path as keyof typeof handlers];
          if (!handler) throw new Error(`Unexpected RPC: ${path}`);
          const value = await handler(inputs[index], request);
          return value instanceof TRPCClientError
            ? {
                error: superjson.serialize({
                  message: value.message,
                  code: -32001,
                  data: value.data,
                }),
              }
            : { result: { data: superjson.serialize(value) } };
        }),
      );
      return new Response(JSON.stringify(batch ? values : values[0]), {
        headers: { 'content-type': 'application/json' },
      });
    }),
  );
  authModule = await import('../app/composables/useAuth');
  cancellation = await import('../app/utils/operation');
  ({ submitInitialRelay } = await import('../app/utils/initialRelay'));
  const plugin = (await import('../app/plugins/trpc')).default;
  trpc = plugin({} as any).provide.trpc;
  useNuxtApp.mockReturnValue({ $trpc: trpc });
});

afterEach(() => {
  stop?.();
  stop = undefined;
  vi.unstubAllGlobals();
  vi.restoreAllMocks();
});

describe('session-bound tRPC transport', () => {
  it.each([
    'account change',
    'logout',
  ])('preserves confirmed lock ownership for cleanup after %s', async (change) => {
    const owner = credentials();
    const granted = deferred();
    const courierLease = {};
    handlers['license.acquireCourierLock'].mockReturnValueOnce(granted.promise);
    handlers['license.releaseCourierLock'].mockResolvedValue({ success: true });
    const acquisition = trpc.license.acquireCourierLock.mutate(undefined, {
      context: { courierLease },
    });
    await until(() =>
      expect(handlers['license.acquireCourierLock']).toHaveBeenCalledTimes(1),
    );
    if (change === 'logout') browser.clear(true);
    else browser.replace(credentials('B'), true);
    granted.resolve({ success: true });
    await expect(acquisition).resolves.toEqual({ success: true });

    await trpc.license.releaseCourierLock.mutate(undefined, {
      context: { courierLease },
    });
    const releases = requests.filter((request) =>
      request.paths.includes('license.releaseCourierLock'),
    );
    expect(releases).toEqual([
      {
        paths: ['license.releaseCourierLock'],
        inputs: [undefined],
        authorization: `Bearer ${owner.accessToken}`,
      },
    ]);
    expect(browser.storage.getItem('accessToken')).toBe(
      change === 'logout' ? null : credentials('B').accessToken,
    );
    expect(handlers.refreshAuthToken).not.toHaveBeenCalled();
    if (change === 'logout') {
      const secondRelease = await trpc.license.releaseCourierLock
        .mutate(undefined, {
          context: { courierLease },
        })
        .catch((error) => error);
      expect(cancellation.isCancelledOperation(secondRelease)).toBe(true);
      expect(handlers['license.releaseCourierLock']).toHaveBeenCalledTimes(1);
    }
  });

  it.each([
    false,
    true,
  ])('uses the normalized bearer with quoted storage = %s before root initialization', async (quoted) => {
    const pair = credentials();
    browser.replace(pair, true, quoted);
    const result = await trpc.me.query();
    expect(result).toEqual({ bearer: `Bearer ${pair.accessToken}` });
    expect(handlers.refreshAuthToken).not.toHaveBeenCalled();
  });

  it('captures the session at dispatch, isolates A from B, and never replays the A request under B', async () => {
    const old = trpc.me.query().catch((error) => error);
    const pair = credentials('B');
    browser.replace(pair, true);
    const fresh = trpc.me.query();
    expect(cancellation.isCancelledOperation(await old)).toBe(true);
    await expect(fresh).resolves.toEqual({
      bearer: `Bearer ${pair.accessToken}`,
    });
    expect(requests.filter((request) => request.paths.includes('me'))).toEqual([
      {
        paths: ['me'],
        inputs: [undefined],
        authorization: `Bearer ${pair.accessToken}`,
      },
    ]);
  });

  it('also separates ordinary same-session credential generations before request dispatch', async () => {
    const old = trpc.me.query().catch((error) => error);
    const rotated = credentials('A', {
      iat: Math.floor(Date.now() / 1000) + 1,
    });
    browser.replace(rotated, true);
    const fresh = trpc.me.query();
    expect(cancellation.isCancelledOperation(await old)).toBe(true);
    await expect(fresh).resolves.toEqual({
      bearer: `Bearer ${rotated.accessToken}`,
    });
    expect(requests.flatMap((request) => request.paths)).toEqual(['me']);
  });

  it('sends separate requests for operations from the same credential generation', async () => {
    await Promise.all([trpc.me.query(), trpc.me.query()]);
    expect(requests.map((request) => request.paths)).toEqual([['me'], ['me']]);
    for (const [url] of vi.mocked(fetch).mock.calls) {
      expect(new URL(String(url)).searchParams.has('batch')).toBe(false);
    }
  });

  it.each([
    'success',
    'unauthorized',
  ] as const)('rejects an obsolete in-flight API %s instead of delivering it to the new account', async (outcome) => {
    const response = deferred();
    handlers.me.mockReturnValueOnce(response.promise);
    const old = trpc.me.query().catch((error) => error);
    await until(() => expect(handlers.me).toHaveBeenCalledTimes(1));
    browser.replace(credentials('B'), true);
    response.resolve(outcome === 'success' ? { old: true } : unauthorized());
    expect(cancellation.isCancelledOperation(await old)).toBe(true);
    expect(browser.storage.getItem('accessToken')).toBe(
      credentials('B').accessToken,
    );
  });

  it('does not expose an unauthorized response for a replaced bearer in the same session', async () => {
    const response = deferred();
    handlers.me.mockReturnValueOnce(response.promise);
    const old = trpc.me.query().catch((error) => error);
    await until(() => expect(handlers.me).toHaveBeenCalledTimes(1));
    browser.replace(
      credentials('A', { iat: Math.floor(Date.now() / 1000) + 1 }),
      true,
    );
    response.resolve(unauthorized());
    expect(cancellation.isCancelledOperation(await old)).toBe(true);
  });

  it('remembers the actual bearer of an earlier request when a later request renews the same session', async () => {
    const now = Date.now();
    const original = credentials('A', { exp: Math.floor(now / 1000) + 65 });
    browser.replace(original, true);
    const response = deferred();
    handlers.me.mockReturnValueOnce(response.promise);
    const old = trpc.me.query().catch((error) => error);
    await until(() => expect(handlers.me).toHaveBeenCalledTimes(1));
    vi.mocked(Date.now).mockReturnValue(now + 10_000);
    const rotated = credentials();
    handlers.refreshAuthToken.mockResolvedValue(rotated);
    await expect(trpc.me.query()).resolves.toEqual({
      bearer: `Bearer ${rotated.accessToken}`,
    });
    response.resolve(unauthorized());
    expect(cancellation.isCancelledOperation(await old)).toBe(true);
  });

  it('does not bootstrap or refresh a partial pair, but still permits public login calls without a bearer', async () => {
    browser.change('accessToken', credentials('B').accessToken, true);
    const error = await trpc.me.query().catch((error) => error);
    expect(cancellation.isCancelledOperation(error)).toBe(true);
    expect(handlers.me).not.toHaveBeenCalled();
    expect(handlers.refreshAuthToken).not.toHaveBeenCalled();
    await expect(trpc.getUserCount.query()).resolves.toBe(1);
    expect(requests).toHaveLength(1);
    expect(requests[0].authorization).toBeNull();
  });
});

describe('courier cleanup authentication', () => {
  async function acquireLease() {
    const now = Date.now();
    const owner = signedCredentials('A', {
      exp: Math.floor(now / 1000) + 65,
    });
    const context = { courierLease: {} };
    let expiresAt = 0;
    let deletions = 0;
    // The backend authorizes JWTs before global Redis NX/EX or DEL, not bearer ownership.
    const server = (action: 'acquire' | 'release', bearer: string | null) => {
      try {
        verifyAuthToken(bearer?.startsWith('Bearer ') ? bearer.slice(7) : '');
      } catch {
        return unauthorized();
      }
      if (action === 'acquire') {
        if (expiresAt > Date.now()) return { success: false };
        expiresAt = Date.now() + 300_000;
      } else {
        deletions++;
        expiresAt = 0;
      }
      return { success: true };
    };
    handlers['license.acquireCourierLock'].mockImplementation(
      (_input, request: Request) => server('acquire', request.authorization),
    );
    handlers['license.releaseCourierLock'].mockImplementation(
      (_input, request: Request) => server('release', request.authorization),
    );
    browser.replace(owner, true);
    const current = authModule.useAuth().captureSession();
    expect(verifyAuthToken(owner.accessToken)).toMatchObject({
      userId: 'A',
      exp: Math.floor(now / 1000) + 65,
    });
    expect(verifyAuthToken(owner.refreshToken)).toMatchObject({
      userId: 'A',
      userSecret: 'revocation-version-A',
    });
    await expect(
      trpc.license.acquireCourierLock.mutate(undefined, { context }),
    ).resolves.toEqual({ success: true });
    expect(handlers.refreshAuthToken).not.toHaveBeenCalled();
    const contender = signedCredentials('B');
    const contend = () => server('acquire', `Bearer ${contender.accessToken}`);
    expect(contend()).toEqual({ success: false });
    return {
      now,
      owner,
      current,
      contend,
      advance(seconds: number) {
        vi.mocked(Date.now).mockReturnValue(now + seconds * 1000);
        if (seconds >= 65)
          expect(() => verifyAuthToken(owner.accessToken)).toThrowError(
            expect.objectContaining({
              name: 'TokenExpiredError',
              message: 'jwt expired',
              expiredAt: new Date(now + 65_000),
            }),
          );
      },
      release: () =>
        trpc.license.releaseCourierLock.mutate(undefined, { context }),
      releasedWith(accessToken: string) {
        expect(
          requests.filter((request) =>
            request.paths.includes('license.releaseCourierLock'),
          ),
        ).toEqual([
          {
            paths: ['license.releaseCourierLock'],
            inputs: [undefined],
            authorization: `Bearer ${accessToken}`,
          },
        ]);
        expect(verifyAuthToken(accessToken).userId).toBe('A');
        expect(handlers['license.releaseCourierLock']).toHaveBeenCalledTimes(1);
        expect(deletions).toBe(1);
        expect(expiresAt).toBe(0);
        expect(Date.now()).toBeLessThan(now + 300_000);
        expect(contend()).toEqual({ success: true });
      },
      expectHeld() {
        expect(deletions).toBe(0);
        expect(expiresAt).toBe(now + 300_000);
        expect(Date.now()).toBeLessThan(expiresAt);
        expect(contend()).toEqual({ success: false });
      },
    };
  }

  it.each([
    'unchanged',
    'access-only',
    'full-pair',
  ])('releases with the valid %s owner without redundant renewal', async (rotation) => {
    const lease = await acquireLease();
    lease.advance(rotation === 'unchanged' ? 1 : 70);
    const current =
      rotation === 'unchanged' ? lease.owner : signedCredentials();
    if (rotation === 'access-only')
      authModule.useAuth().accessToken.value = current.accessToken;
    else browser.replace(current, true);

    await expect(lease.release()).resolves.toEqual({ success: true });
    lease.releasedWith(current.accessToken);
    expect(lease.current()).toBe(true);
    expect(handlers.refreshAuthToken).not.toHaveBeenCalled();
    expect(browser.storage.getItem('refreshToken')).toBe(
      rotation === 'access-only'
        ? lease.owner.refreshToken
        : current.refreshToken,
    );
  });

  it.each([
    'starts renewal',
    'joins normal renewal',
  ])('renews an expired current pair with its current refresh token: %s', async (mode) => {
    const lease = await acquireLease();
    lease.advance(70);
    const current = signedCredentials('A', {
      exp: Math.floor(Date.now() / 1000) - 1,
    });
    browser.replace(current, true);
    const renewal = deferred();
    handlers.refreshAuthToken.mockReturnValueOnce(renewal.promise);
    const me = mode === 'joins normal renewal' ? trpc.me.query() : undefined;
    if (me)
      await until(() =>
        expect(handlers.refreshAuthToken).toHaveBeenCalledTimes(1),
      );
    const pending = lease.release();
    await until(() =>
      expect(handlers.refreshAuthToken).toHaveBeenCalledTimes(1),
    );
    expect(handlers['license.releaseCourierLock']).not.toHaveBeenCalled();
    lease.expectHeld();
    const renewed = signedCredentials();
    renewal.resolve({ accessToken: renewed.accessToken });

    await expect(pending).resolves.toEqual({ success: true });
    if (me)
      await expect(me).resolves.toEqual({
        bearer: `Bearer ${renewed.accessToken}`,
      });
    lease.releasedWith(renewed.accessToken);
    expect(lease.current()).toBe(true);
    expect(
      requests.filter((request) => request.paths.includes('refreshAuthToken')),
    ).toEqual([
      {
        paths: ['refreshAuthToken'],
        inputs: [{ refreshToken: current.refreshToken }],
        authorization: null,
      },
    ]);
    expect(browser.storage.getItem('accessToken')).toBe(renewed.accessToken);
    expect(browser.storage.getItem('refreshToken')).toBe(current.refreshToken);
  });

  describe.each([
    'valid bearer',
    'successive renewal',
  ])('same-session rotation to %s', (rotation) => {
    it.each([
      'success',
      'unauthorized',
      'network',
    ])('resolves cleanup credentials after stale renewal %s without replaying release', async (outcome) => {
      const lease = await acquireLease();
      lease.advance(70);
      const oldRenewal = deferred();
      const newRenewal = deferred();
      handlers.refreshAuthToken
        .mockReturnValueOnce(oldRenewal.promise)
        .mockReturnValueOnce(newRenewal.promise);
      const oldMe = trpc.me.query().catch((error) => error);
      await until(() =>
        expect(handlers.refreshAuthToken).toHaveBeenCalledTimes(1),
      );
      const pending = lease.release();
      const successive = rotation === 'successive renewal';
      const rotated = signedCredentials('A', {
        exp: Math.floor(Date.now() / 1000) + (successive ? -1 : 900),
      });
      browser.replace(rotated, true);
      const fresh = successive ? trpc.me.query() : undefined;
      if (fresh)
        await until(() =>
          expect(handlers.refreshAuthToken).toHaveBeenCalledTimes(2),
        );
      if (outcome === 'network') oldRenewal.reject(new Error('Offline'));
      else
        oldRenewal.resolve(
          outcome === 'unauthorized'
            ? unauthorized()
            : signedCredentials('A', { iat: Math.floor(lease.now / 1000) + 1 }),
        );
      expect(cancellation.isCancelledOperation(await oldMe)).toBe(true);

      let sent = rotated;
      if (fresh) {
        // The stale finally must not clear the newer slot joined by cleanup and me.
        const joined = trpc.me.query();
        sent = signedCredentials();
        newRenewal.resolve({ accessToken: sent.accessToken });
        await expect(Promise.all([fresh, joined])).resolves.toEqual([
          { bearer: `Bearer ${sent.accessToken}` },
          { bearer: `Bearer ${sent.accessToken}` },
        ]);
      }
      await expect(pending).resolves.toEqual({ success: true });
      lease.releasedWith(sent.accessToken);
      expect(lease.current()).toBe(true);
      expect(
        handlers.refreshAuthToken.mock.calls.map(([input]) => input),
      ).toEqual(
        (successive
          ? [lease.owner.refreshToken, rotated.refreshToken]
          : [lease.owner.refreshToken]
        ).map((refreshToken) => ({ refreshToken })),
      );
      expect(handlers.me).toHaveBeenCalledTimes(successive ? 2 : 0);
      expect(browser.storage.getItem('accessToken')).toBe(sent.accessToken);
      expect(browser.storage.getItem('refreshToken')).toBe(
        rotated.refreshToken,
      );
      expect(browser.window.location.href).not.toContain('#/login');
    });
  });

  describe.each([
    { stage: 'before cleanup', seconds: 10 },
    { stage: 'during renewal', seconds: 10 },
    { stage: 'before cleanup', seconds: 70 },
    { stage: 'during renewal', seconds: 70 },
  ])('session loss $stage at t0 + $seconds seconds', ({ stage, seconds }) => {
    it.each([
      'logout',
      'account change',
      'secret boundary',
    ])('uses only acquisition credentials after %s, never renewing a successor', async (change) => {
      const lease = await acquireLease();
      lease.advance(seconds);
      const renewal = deferred();
      handlers.refreshAuthToken.mockReturnValueOnce(renewal.promise);
      const duringRenewal = stage === 'during renewal';
      let pending = duringRenewal
        ? lease.release().catch((error) => error)
        : undefined;
      if (duringRenewal)
        await until(() =>
          expect(handlers.refreshAuthToken).toHaveBeenCalledTimes(1),
        );
      const next = signedCredentials(change === 'account change' ? 'B' : 'A', {
        userSecret: 'successor-secret',
        exp: Math.floor(Date.now() / 1000) + 10,
      });
      if (change === 'logout') void authModule.useAuth().logout();
      else browser.replace(next, true);
      const accessToken = browser.storage.getItem('accessToken');
      const refreshToken = browser.storage.getItem('refreshToken');
      pending ??= lease.release().catch((error) => error);
      renewal.resolve(signedCredentials());

      if (seconds === 10) {
        await expect(pending).resolves.toEqual({ success: true });
        lease.releasedWith(lease.owner.accessToken);
      } else {
        expect(await pending).toMatchObject({
          data: { code: 'UNAUTHORIZED', httpStatus: 401 },
        });
        lease.expectHeld();
        expect(
          requests.filter((request) =>
            request.paths.includes('license.releaseCourierLock'),
          ),
        ).toEqual([
          {
            paths: ['license.releaseCourierLock'],
            inputs: [undefined],
            authorization: `Bearer ${lease.owner.accessToken}`,
          },
        ]);
      }
      expect(lease.current()).toBe(false);
      expect(
        handlers.refreshAuthToken.mock.calls.map(([input]) => input),
      ).toEqual(
        duringRenewal ? [{ refreshToken: lease.owner.refreshToken }] : [],
      );
      expect(browser.storage.getItem('accessToken')).toBe(accessToken);
      expect(browser.storage.getItem('refreshToken')).toBe(refreshToken);
      expect(browser.window.location.href).not.toContain('#/login');
    });
  });

  it.each([
    'capture',
    'renewal commit',
  ])('rechecks session ownership after %s before choosing the cleanup bearer', async (stage) => {
    const lease = await acquireLease();
    lease.advance(10);
    const next = signedCredentials('B', {
      exp: Math.floor(Date.now() / 1000) + 10,
    });
    if (stage === 'capture') {
      const capture = authModule.captureAuthCredentials;
      vi.spyOn(authModule, 'captureAuthCredentials').mockImplementationOnce(
        () => {
          browser.replace(next, true);
          return capture();
        },
      );
    } else {
      const renewed = signedCredentials();
      handlers.refreshAuthToken.mockResolvedValueOnce(renewed);
      const originalSet = vi
        .mocked(browser.storage.setItem)
        .getMockImplementation()!;
      vi.spyOn(browser.storage, 'setItem').mockImplementation((key, value) => {
        originalSet(key, value);
        if (key === 'accessToken' && value === renewed.accessToken)
          queueMicrotask(() => browser.replace(next, true));
      });
    }

    await expect(lease.release()).resolves.toEqual({ success: true });
    lease.releasedWith(lease.owner.accessToken);
    expect(lease.current()).toBe(false);
    expect(
      handlers.refreshAuthToken.mock.calls.map(([input]) => input),
    ).toEqual(
      stage === 'capture' ? [] : [{ refreshToken: lease.owner.refreshToken }],
    );
    expect(browser.storage.getItem('accessToken')).toBe(next.accessToken);
    expect(browser.storage.getItem('refreshToken')).toBe(next.refreshToken);
  });

  it('reselects a same-session bearer rotated between capture and credential resolution', async () => {
    const lease = await acquireLease();
    lease.advance(1);
    const rotated = signedCredentials();
    const capture = authModule.captureAuthCredentials;
    vi.spyOn(authModule, 'captureAuthCredentials').mockImplementationOnce(
      () => {
        const current = capture();
        queueMicrotask(() => browser.replace(rotated, true));
        return current;
      },
    );

    await expect(lease.release()).resolves.toEqual({ success: true });
    lease.releasedWith(rotated.accessToken);
    expect(lease.current()).toBe(true);
    expect(handlers.refreshAuthToken).not.toHaveBeenCalled();
  });

  it('keeps the resolved owner bearer across a session change before request dispatch', async () => {
    const lease = await acquireLease();
    lease.advance(70);
    const current = signedCredentials();
    browser.replace(current, true);
    const pending = lease.release();
    // Resolve cleanup credentials before the transport dispatches the request.
    await Promise.resolve();
    await Promise.resolve();
    expect(handlers['license.releaseCourierLock']).not.toHaveBeenCalled();
    const next = signedCredentials('B', {
      exp: Math.floor(Date.now() / 1000) + 10,
    });
    browser.replace(next, true);

    await expect(pending).resolves.toEqual({ success: true });
    lease.releasedWith(current.accessToken);
    expect(lease.current()).toBe(false);
    expect(handlers.refreshAuthToken).not.toHaveBeenCalled();
    expect(browser.storage.getItem('accessToken')).toBe(next.accessToken);
    expect(browser.storage.getItem('refreshToken')).toBe(next.refreshToken);
  });

  it.each([
    { state: 'valid', remaining: 10, failedAt: 70 },
    { state: 'expired', remaining: -1, failedAt: 70 },
    { state: 'expires during renewal', remaining: 10, failedAt: 81 },
  ])('handles renewal network failure when the current bearer is $state', async ({
    state,
    remaining,
    failedAt,
  }) => {
    const lease = await acquireLease();
    lease.advance(70);
    const current = signedCredentials('A', {
      exp: Math.floor(Date.now() / 1000) + remaining,
    });
    browser.replace(current, true);
    const failure = new Error('Renewal offline');
    const renewal = deferred();
    handlers.refreshAuthToken.mockReturnValueOnce(renewal.promise);
    const pending = lease.release();
    await until(() =>
      expect(handlers.refreshAuthToken).toHaveBeenCalledTimes(1),
    );
    expect(handlers['license.releaseCourierLock']).not.toHaveBeenCalled();
    lease.advance(failedAt);
    renewal.reject(failure);

    if (state === 'valid') {
      await expect(pending).resolves.toEqual({ success: true });
      lease.releasedWith(current.accessToken);
    } else {
      await expect(pending).rejects.toMatchObject({ cause: failure });
      expect(handlers['license.releaseCourierLock']).not.toHaveBeenCalled();
      expect(requests.flatMap((request) => request.paths)).toEqual([
        'license.acquireCourierLock',
        'refreshAuthToken',
      ]);
      lease.expectHeld();
      lease.advance(299);
      expect(lease.contend()).toEqual({ success: false });
      lease.advance(300);
      expect(lease.contend()).toEqual({ success: true });
    }
    expect(lease.current()).toBe(true);
    expect(
      handlers.refreshAuthToken.mock.calls.map(([input]) => input),
    ).toEqual([{ refreshToken: current.refreshToken }]);
    expect(browser.storage.getItem('accessToken')).toBe(current.accessToken);
    expect(browser.storage.getItem('refreshToken')).toBe(current.refreshToken);
  });

  it.each([
    'network',
    'serialized server',
  ])('reselects cleanup credentials rotated during renewal error propagation: %s', async (outcome) => {
    const lease = await acquireLease();
    lease.advance(70);
    const rotated = signedCredentials();
    const failure =
      outcome === 'network'
        ? new Error('Renewal offline')
        : Object.assign(new TRPCClientError('Renewal unavailable'), {
            data: { code: 'INTERNAL_SERVER_ERROR', httpStatus: 500 },
          });
    const renewal = deferred();
    handlers.refreshAuthToken.mockReturnValueOnce(renewal.promise);
    const pending = lease.release().catch((error) => error);
    await until(() =>
      expect(handlers.refreshAuthToken).toHaveBeenCalledTimes(1),
    );
    lease.expectHeld();
    const read = browser.storage.getItem;
    let checkedRefresh: string | null | undefined;
    let checkStack: string | undefined;
    const getItem = vi
      .spyOn(browser.storage, 'getItem')
      .mockImplementation((key) => {
        const value = read(key);
        if (key === 'refreshToken' && checkedRefresh === undefined) {
          checkedRefresh = value;
          checkStack = new Error().stack;
          // Let the inner catch accept the old generation before rotation reaches the outer catch.
          queueMicrotask(() => browser.replace(rotated, true));
        }
        return value;
      });
    let result: unknown;
    try {
      if (outcome === 'network') renewal.reject(failure);
      else renewal.resolve(failure);
      result = await pending;
    } finally {
      getItem.mockRestore();
    }

    expect(checkedRefresh).toBe(lease.owner.refreshToken);
    expect(checkStack).toContain('isUnchanged');
    expect(lease.current()).toBe(true);
    expect(browser.storage.getItem('accessToken')).toBe(rotated.accessToken);
    expect(browser.storage.getItem('refreshToken')).toBe(rotated.refreshToken);
    expect(verifyAuthToken(rotated.accessToken).userId).toBe('A');
    expect(handlers.refreshAuthToken).toHaveBeenCalledTimes(1);
    expect(cancellation.isCancelledOperation(result)).toBe(false);
    expect({
      result,
      releases: handlers['license.releaseCourierLock'].mock.calls.length,
    }).toEqual({ result: { success: true }, releases: 1 });
    lease.releasedWith(rotated.accessToken);
  });

  it.each([
    'unchanged',
    'same-session rotation',
    'account change',
  ])('never retries an ambiguous release failure after DEL with %s', async (change) => {
    const lease = await acquireLease();
    lease.advance(70);
    const current = signedCredentials();
    browser.replace(current, true);
    const response = deferred();
    const release =
      handlers['license.releaseCourierLock'].getMockImplementation()!;
    handlers['license.releaseCourierLock'].mockImplementationOnce(
      (input, request) => {
        expect(release(input, request)).toEqual({ success: true });
        return response.promise;
      },
    );
    const pending = lease.release().catch((error) => error);
    await until(() =>
      expect(handlers['license.releaseCourierLock']).toHaveBeenCalledTimes(1),
    );
    // A different courier gets the global key while the DEL response is still in flight.
    lease.releasedWith(current.accessToken);
    if (change !== 'unchanged')
      browser.replace(
        signedCredentials(change === 'account change' ? 'B' : 'A', {
          exp: Math.floor(Date.now() / 1000) + 10,
        }),
        true,
      );
    const failure = new Error('Lost response after DEL');
    response.reject(failure);

    expect(await pending).toMatchObject({ cause: failure });
    expect(handlers['license.releaseCourierLock']).toHaveBeenCalledTimes(1);
    expect(
      requests.filter((request) =>
        request.paths.includes('license.releaseCourierLock'),
      ),
    ).toHaveLength(1);
    expect(handlers.refreshAuthToken).not.toHaveBeenCalled();
    expect(lease.contend()).toEqual({ success: false });
  });
});

describe('automatic renewal ownership', () => {
  function expiring(userId = 'A') {
    const pair = credentials(userId, {
      exp: Math.floor(Date.now() / 1000) + 10,
    });
    browser.replace(pair, true);
    return pair;
  }

  it('renews once and writes through shared state without clearing same-account caches', async () => {
    const original = expiring();
    const auth = authModule.useAuth();
    stop = authModule.observeAuthSession(trpc);
    auth.user.value = { email: 'A@example.test' } as any;
    const current = auth.captureSession();
    const rotated = credentials();
    handlers.refreshAuthToken.mockResolvedValue({
      accessToken: rotated.accessToken,
    });
    clearLicense.mockClear();
    await expect(
      Promise.all([trpc.me.query(), trpc.me.query()]),
    ).resolves.toEqual([
      { bearer: `Bearer ${rotated.accessToken}` },
      { bearer: `Bearer ${rotated.accessToken}` },
    ]);
    expect(handlers.refreshAuthToken).toHaveBeenCalledTimes(1);
    expect(handlers.refreshAuthToken.mock.calls[0][0]).toEqual({
      refreshToken: original.refreshToken,
    });
    expect(requests.map((request) => request.paths)).toEqual([
      ['refreshAuthToken'],
      ['me'],
      ['me'],
    ]);
    for (const [url] of vi.mocked(fetch).mock.calls) {
      expect(new URL(String(url)).searchParams.has('batch')).toBe(false);
    }
    expect(auth.accessToken.value).toBe(rotated.accessToken);
    expect(auth.user.value?.email).toBe('A@example.test');
    expect(current()).toBe(true);
    expect(clearLicense).not.toHaveBeenCalled();
  });

  it.each([
    'success',
    'unauthorized',
    'network',
  ] as const)('cancels stale renewal %s and its finally cannot clear a newer pending slot', async (outcome) => {
    expiring();
    const oldRenewal = deferred();
    const newRenewal = deferred();
    handlers.refreshAuthToken
      .mockReturnValueOnce(oldRenewal.promise)
      .mockReturnValueOnce(newRenewal.promise);
    const old = trpc.me.query().catch((error) => error);
    await until(() =>
      expect(handlers.refreshAuthToken).toHaveBeenCalledTimes(1),
    );
    const next = expiring('B');
    const fresh = trpc.me.query();
    await until(() =>
      expect(handlers.refreshAuthToken).toHaveBeenCalledTimes(2),
    );
    if (outcome === 'network') oldRenewal.reject(new Error('Offline'));
    else
      oldRenewal.resolve(
        outcome === 'unauthorized' ? unauthorized() : credentials(),
      );
    expect(cancellation.isCancelledOperation(await old)).toBe(true);
    expect(browser.storage.getItem('accessToken')).toBe(next.accessToken);
    expect(browser.storage.getItem('refreshToken')).toBe(next.refreshToken);
    expect(browser.window.location.href).not.toContain('#/login');
    const joined = trpc.me.query();
    const rotated = credentials('B');
    newRenewal.resolve({ accessToken: rotated.accessToken });
    await expect(Promise.all([fresh, joined])).resolves.toEqual([
      { bearer: `Bearer ${rotated.accessToken}` },
      { bearer: `Bearer ${rotated.accessToken}` },
    ]);
    expect(handlers.refreshAuthToken).toHaveBeenCalledTimes(2);
    expect(
      requests
        .filter((request) => request.paths.includes('me'))
        .every(
          (request) =>
            request.authorization === `Bearer ${rotated.accessToken}`,
        ),
    ).toBe(true);
  });

  it.each([
    'success',
    'unauthorized',
  ] as const)('does not overwrite or clear a same-account full rotation after stale renewal %s', async (outcome) => {
    expiring();
    const auth = authModule.useAuth();
    const current = auth.captureSession();
    const renewal = deferred();
    handlers.refreshAuthToken.mockReturnValueOnce(renewal.promise);
    const old = trpc.me.query().catch((error) => error);
    await until(() =>
      expect(handlers.refreshAuthToken).toHaveBeenCalledTimes(1),
    );
    const rotated = credentials('A', {
      iat: Math.floor(Date.now() / 1000) + 1,
    });
    browser.replace(rotated, true);
    renewal.resolve(
      outcome === 'unauthorized' ? unauthorized() : credentials(),
    );
    expect(cancellation.isCancelledOperation(await old)).toBe(true);
    expect(current()).toBe(true);
    expect(auth.accessToken.value).toBe(rotated.accessToken);
    expect(auth.refreshToken.value).toBe(rotated.refreshToken);
    expect(handlers.me).not.toHaveBeenCalled();
  });

  it('checks ownership again at fetch, not just when async headers resolve', async () => {
    expiring();
    const rotated = credentials();
    const next = credentials('B');
    handlers.refreshAuthToken.mockResolvedValue(rotated);
    const originalSet = vi
      .mocked(browser.storage.setItem)
      .getMockImplementation()!;
    vi.spyOn(browser.storage, 'setItem').mockImplementation((key, value) => {
      originalSet(key, value);
      if (key === 'accessToken' && value === rotated.accessToken) {
        queueMicrotask(() => browser.replace(next, true));
      }
    });
    const error = await trpc.me.query().catch((error) => error);
    expect(cancellation.isCancelledOperation(error)).toBe(true);
    expect(handlers.me).not.toHaveBeenCalled();
    expect(browser.storage.getItem('accessToken')).toBe(next.accessToken);
  });

  it('will not send or persist another user returned by renewal', async () => {
    const initial = expiring();
    handlers.refreshAuthToken.mockResolvedValue(credentials('B'));
    await expect(trpc.me.query()).rejects.toThrow();
    expect(browser.storage.getItem('accessToken')).toBe(initial.accessToken);
    expect(handlers.me).not.toHaveBeenCalled();
  });

  it('invalidates shared caches and redirects only for a current unauthorized renewal', async () => {
    expiring();
    const auth = authModule.useAuth();
    auth.user.value = { email: 'A@example.test' } as any;
    handlers.refreshAuthToken.mockResolvedValue(unauthorized());
    useNuxtApp.mockImplementation(() => {
      throw new Error('Plugin has no component context');
    });
    await expect(trpc.me.query()).rejects.toThrow();
    expect(auth.accessToken.value).toBe('');
    expect(auth.refreshToken.value).toBe('');
    expect(auth.user.value).toBeNull();
    expect(clearLicense).toHaveBeenCalled();
    expect(browser.window.location.href).toBe('/dashboard/#/login');
  });

  it('does not automatically renew before explicit refresh or login and keeps login result guards valid', async () => {
    expiring();
    const rotated = credentials();
    handlers.refresh.mockResolvedValue(rotated);
    const auth = authModule.useAuth();
    await expect(auth.refresh()).resolves.toBe(rotated.accessToken);
    handlers.verifySso.mockResolvedValue({
      success: true,
      ...credentials('B'),
    });
    const pending = auth.login('sso');
    const current = auth.captureSession();
    await expect(pending).resolves.toBe(true);
    expect(current()).toBe(true);
    expect(handlers.refreshAuthToken).not.toHaveBeenCalled();
    expect(requests.every((request) => request.authorization === null)).toBe(
      true,
    );
  });
});

describe('initial relay credential rotation recovery', () => {
  const input = Object.freeze({
    jwt: ' first-relay.jwt ',
    nextToken: 'first-rolling-token',
    initialFrom: ' original-license.jwt ',
  });

  it.each([
    'access-only',
    'full-pair',
  ])('retries a queued %s rotation with the exact initial input', async (rotation) => {
    const auth = authModule.useAuth();
    const current = auth.captureSession();
    const value = Object.freeze({
      ...input,
      ...(rotation === 'full-pair'
        ? { publicKey: 'rotated-public-key\\n' }
        : {}),
    });
    const submit = vi.fn(trpc.license.submitRelay.mutate);
    const pending = submitInitialRelay(submit, value, vi.fn());
    // Let sessionLink resolve credentials before the transport dispatches the RPC.
    await Promise.resolve();
    const rotated = credentials('A', {
      iat: Math.floor(Date.now() / 1000) + 1,
    });
    if (rotation === 'access-only')
      auth.accessToken.value = rotated.accessToken;
    else browser.replace(rotated, true);

    await expect(pending).resolves.toEqual({ success: true });
    expect(current()).toBe(true);
    expect(submit).toHaveBeenCalledTimes(2);
    expect(submit.mock.calls.every(([attempt]) => attempt === value)).toBe(
      true,
    );
    expect(requests).toEqual([
      {
        paths: ['license.submitRelay'],
        inputs: [value],
        authorization: `Bearer ${rotated.accessToken}`,
      },
    ]);
    expect(handlers['license.submitRelay']).toHaveBeenCalledTimes(1);
  });

  it('still cancels a plain queued submitRelay instead of retrying it', async () => {
    const pending = trpc.license.submitRelay
      .mutate(input)
      .catch((error) => error);
    await Promise.resolve();
    browser.replace(
      credentials('A', { iat: Math.floor(Date.now() / 1000) + 1 }),
      true,
    );
    expect(cancellation.isCancelledOperation(await pending)).toBe(true);
    expect(requests).toEqual([]);
    expect(handlers['license.submitRelay']).not.toHaveBeenCalled();
  });

  it.each([
    'success',
    'unauthorized',
  ] as const)('joins pending automatic renewal without replaying its current %s', async (outcome) => {
    const original = credentials('A', {
      exp: Math.floor(Date.now() / 1000) + 10,
    });
    browser.replace(original, true);
    const renewal = deferred();
    handlers.refreshAuthToken.mockReturnValueOnce(renewal.promise);
    handlers['license.submitRelay'].mockResolvedValueOnce(
      outcome === 'success' ? { success: true } : unauthorized(),
    );
    const me = trpc.me.query();
    await until(() =>
      expect(handlers.refreshAuthToken).toHaveBeenCalledTimes(1),
    );
    const submit = vi.fn(trpc.license.submitRelay.mutate);
    const pending = submitInitialRelay(submit, input, vi.fn());
    const rotated = credentials();
    renewal.resolve({ accessToken: rotated.accessToken });

    if (outcome === 'success')
      await expect(pending).resolves.toEqual({ success: true });
    else
      await expect(pending).rejects.toMatchObject({
        data: { code: 'UNAUTHORIZED', httpStatus: 401 },
      });
    await expect(me).resolves.toEqual({
      bearer: `Bearer ${rotated.accessToken}`,
    });
    expect(submit).toHaveBeenCalledTimes(1);
    expect(handlers.refreshAuthToken).toHaveBeenCalledTimes(1);
    expect(
      requests.filter((request) => request.authorization !== null),
    ).toEqual([
      {
        paths: ['me'],
        inputs: [undefined],
        authorization: `Bearer ${rotated.accessToken}`,
      },
      {
        paths: ['license.submitRelay'],
        inputs: [input],
        authorization: `Bearer ${rotated.accessToken}`,
      },
    ]);
  });

  it.each([
    'success',
    'unauthorized',
    'network',
  ] as const)('retries after same-session rotation supersedes pending renewal %s', async (outcome) => {
    const original = credentials('A', {
      exp: Math.floor(Date.now() / 1000) + 10,
    });
    browser.replace(original, true);
    const renewal = deferred();
    handlers.refreshAuthToken.mockReturnValueOnce(renewal.promise);
    const submit = vi.fn(trpc.license.submitRelay.mutate);
    const pending = submitInitialRelay(submit, input, vi.fn());
    await until(() =>
      expect(handlers.refreshAuthToken).toHaveBeenCalledTimes(1),
    );
    const rotated = credentials('A', {
      iat: Math.floor(Date.now() / 1000) + 1,
    });
    browser.replace(rotated, true);
    if (outcome === 'network') renewal.reject(new Error('Offline'));
    else
      renewal.resolve(outcome === 'success' ? credentials() : unauthorized());

    await expect(pending).resolves.toEqual({ success: true });
    expect(submit).toHaveBeenCalledTimes(2);
    expect(submit.mock.calls.every(([attempt]) => attempt === input)).toBe(
      true,
    );
    expect(requests).toEqual([
      {
        paths: ['refreshAuthToken'],
        inputs: [{ refreshToken: original.refreshToken }],
        authorization: null,
      },
      {
        paths: ['license.submitRelay'],
        inputs: [input],
        authorization: `Bearer ${rotated.accessToken}`,
      },
    ]);
    expect(authModule.useAuth().refreshToken.value).toBe(rotated.refreshToken);
    expect(browser.window.location.href).not.toContain('#/login');
  });

  it('retries a rotation in the headers-to-fetch microtask gap', async () => {
    const rotated = credentials('A', {
      iat: Math.floor(Date.now() / 1000) + 1,
    });
    let scheduled = false;
    const value = Object.freeze({
      ...input,
      get jwt() {
        if (!scheduled) {
          scheduled = true;
          // tRPC serializes before headers, then awaits headers before fetch.
          queueMicrotask(() => browser.replace(rotated, true));
        }
        return input.jwt;
      },
    });
    const submit = vi.fn(trpc.license.submitRelay.mutate);
    await expect(submitInitialRelay(submit, value, vi.fn())).resolves.toEqual({
      success: true,
    });
    expect(submit).toHaveBeenCalledTimes(2);
    expect(submit.mock.calls.every(([attempt]) => attempt === value)).toBe(
      true,
    );
    expect(requests).toEqual([
      {
        paths: ['license.submitRelay'],
        inputs: [input],
        authorization: `Bearer ${rotated.accessToken}`,
      },
    ]);
  });

  it('can progress through successive actual rotations without changing the initial pair', async () => {
    const rotations = [1, 2, 3].map((offset) =>
      credentials('A', { iat: Math.floor(Date.now() / 1000) + offset }),
    );
    const final = rotations[2];
    const submit = vi.fn((value: Parameters<typeof submitInitialRelay>[1]) => {
      const pending = trpc.license.submitRelay.mutate(value);
      const rotated = rotations.shift();
      if (rotated) queueMicrotask(() => browser.replace(rotated, true));
      return pending;
    });
    await expect(submitInitialRelay(submit, input, vi.fn())).resolves.toEqual({
      success: true,
    });
    expect(submit).toHaveBeenCalledTimes(4);
    expect(submit.mock.calls.every(([attempt]) => attempt === input)).toBe(
      true,
    );
    expect(requests).toEqual([
      {
        paths: ['license.submitRelay'],
        inputs: [input],
        authorization: `Bearer ${final.accessToken}`,
      },
    ]);
  });

  it('stops when a retried attempt is cancelled without another credential rotation', async () => {
    handlers['license.submitRelay'].mockRejectedValueOnce(
      new cancellation.CancelledOperationError(),
    );
    const submit = vi.fn(trpc.license.submitRelay.mutate);
    const pending = submitInitialRelay(submit, input, vi.fn()).catch(
      (error) => error,
    );
    await Promise.resolve();
    browser.replace(
      credentials('A', { iat: Math.floor(Date.now() / 1000) + 1 }),
      true,
    );
    expect(cancellation.isCancelledOperation(await pending)).toBe(true);
    expect(submit).toHaveBeenCalledTimes(2);
    expect(handlers['license.submitRelay']).toHaveBeenCalledTimes(1);
    expect(requests).toHaveLength(1);
  });

  it.each([
    'success',
    'unauthorized',
  ] as const)('handles in-flight %s after same-session rotation without losing or duplicating the initial pair', async (outcome) => {
    const original = credentials();
    const response = deferred();
    handlers['license.submitRelay'].mockReturnValueOnce(response.promise);
    const submit = vi.fn(trpc.license.submitRelay.mutate);
    const pending = submitInitialRelay(submit, input, vi.fn());
    await until(() =>
      expect(handlers['license.submitRelay']).toHaveBeenCalledTimes(1),
    );
    const rotated = credentials('A', {
      iat: Math.floor(Date.now() / 1000) + 1,
    });
    browser.replace(rotated, true);
    response.resolve(
      outcome === 'success' ? { success: true } : unauthorized(),
    );

    await expect(pending).resolves.toEqual({ success: true });
    const bearers = [original.accessToken];
    if (outcome === 'unauthorized') bearers.push(rotated.accessToken);
    expect(submit).toHaveBeenCalledTimes(bearers.length);
    expect(submit.mock.calls.every(([attempt]) => attempt === input)).toBe(
      true,
    );
    expect(requests).toEqual(
      bearers.map((bearer) => ({
        paths: ['license.submitRelay'],
        inputs: [input],
        authorization: `Bearer ${bearer}`,
      })),
    );
    expect(authModule.useAuth().accessToken.value).toBe(rotated.accessToken);
  });

  it.each([
    { outcome: 'cancellation', rotate: false },
    { outcome: 'unauthorized', rotate: false },
    { outcome: 'network', rotate: false },
    { outcome: 'network', rotate: true },
    { outcome: 'conflict', rotate: false },
    { outcome: 'conflict', rotate: true },
    { outcome: 'lookalike', rotate: true },
  ] as const)('does not retry $outcome with rotation = $rotate', async ({
    outcome,
    rotate,
  }) => {
    const failure = {
      cancellation: new cancellation.CancelledOperationError(),
      unauthorized: unauthorized(),
      network: new Error('Offline'),
      conflict: Object.assign(new TRPCClientError('License state changed'), {
        data: { code: 'CONFLICT', httpStatus: 409 },
      }),
      lookalike: Object.assign(new Error('Not a classified cancellation'), {
        name: 'CancelledOperationError',
      }),
    }[outcome];
    const response = deferred();
    handlers['license.submitRelay'].mockReturnValueOnce(response.promise);
    const submit = vi.fn(trpc.license.submitRelay.mutate);
    const pending = submitInitialRelay(submit, input, vi.fn()).catch(
      (error) => error,
    );
    await until(() =>
      expect(handlers['license.submitRelay']).toHaveBeenCalledTimes(1),
    );
    if (rotate)
      browser.replace(
        credentials('A', { iat: Math.floor(Date.now() / 1000) + 1 }),
        true,
      );
    if (failure instanceof TRPCClientError) response.resolve(failure);
    else response.reject(failure);

    const error = await pending;
    expect(error).toBeInstanceOf(TRPCClientError);
    expect(error.message).toBe(failure.message);
    expect(cancellation.isCancelledOperation(error)).toBe(
      outcome === 'cancellation',
    );
    if (failure instanceof TRPCClientError)
      expect(error.data).toEqual(failure.data);
    else expect(error.cause).toBe(failure);
    expect(submit).toHaveBeenCalledTimes(1);
    expect(handlers['license.submitRelay']).toHaveBeenCalledTimes(1);
    expect(requests).toHaveLength(1);
  });

  describe.each([
    'queued',
    'renewal',
    'in-flight',
  ])('session boundary while %s', (stage) => {
    it.each([
      'logout',
      'logout and restore',
      'account change',
      'revocation version',
      'invalid pair',
      'expired refresh',
    ])('does not submit under new credentials after %s', async (change) => {
      const original = credentials('A', {
        exp: Math.floor(Date.now() / 1000) + (stage === 'renewal' ? 10 : 900),
      });
      browser.replace(original, true);
      const auth = authModule.useAuth();
      const response = deferred();
      const handler =
        stage === 'renewal'
          ? handlers.refreshAuthToken
          : handlers['license.submitRelay'];
      handler.mockReturnValueOnce(response.promise);
      const submit = vi.fn(trpc.license.submitRelay.mutate);
      const pending = submitInitialRelay(submit, input, vi.fn()).catch(
        (error) => error,
      );
      if (stage === 'queued') await Promise.resolve();
      else await until(() => expect(handler).toHaveBeenCalledTimes(1));

      if (change.startsWith('logout')) {
        void auth.logout();
        if (change === 'logout and restore') browser.replace(original, true);
      } else if (change === 'account change') {
        browser.replace(credentials('B'), true);
      } else if (change === 'revocation version') {
        browser.replace(credentials('A', { userSecret: 'revoked-A' }), true);
      } else if (change === 'invalid pair') {
        browser.change('accessToken', credentials('B').accessToken, true);
      } else {
        browser.replace(
          credentials('A', { refreshExp: Math.floor(Date.now() / 1000) - 1 }),
          true,
        );
      }
      const accessToken = browser.storage.getItem('accessToken');
      const refreshToken = browser.storage.getItem('refreshToken');
      response.resolve(stage === 'renewal' ? credentials() : { success: true });

      expect(cancellation.isCancelledOperation(await pending)).toBe(true);
      expect(submit).toHaveBeenCalledTimes(1);
      expect(requests).toEqual(
        stage === 'queued'
          ? []
          : [
              {
                paths: [
                  stage === 'renewal'
                    ? 'refreshAuthToken'
                    : 'license.submitRelay',
                ],
                inputs: [
                  stage === 'renewal'
                    ? { refreshToken: original.refreshToken }
                    : input,
                ],
                authorization:
                  stage === 'renewal' ? null : `Bearer ${original.accessToken}`,
              },
            ],
      );
      expect(browser.storage.getItem('accessToken')).toBe(accessToken);
      expect(browser.storage.getItem('refreshToken')).toBe(refreshToken);
    });
  });

  it('does not start with unusable credentials', async () => {
    browser.change('refreshToken', null, true);
    const submit = vi.fn(trpc.license.submitRelay.mutate);
    await expect(
      submitInitialRelay(submit, input, vi.fn()),
    ).rejects.toBeInstanceOf(cancellation.CancelledOperationError);
    expect(submit).not.toHaveBeenCalled();
    expect(requests).toEqual([]);
  });

  it.each([
    'before submit',
    'before retry',
    'after success',
  ])('stops when caller ownership is lost %s', async (stage) => {
    let owned = stage !== 'before submit';
    const failure = new cancellation.CancelledOperationError();
    const assertCurrent = () => {
      if (!owned) throw failure;
    };
    const response = deferred();
    handlers['license.submitRelay'].mockReturnValueOnce(response.promise);
    const submit = vi.fn(trpc.license.submitRelay.mutate);
    const pending = submitInitialRelay(submit, input, assertCurrent).catch(
      (error) => error,
    );
    if (stage === 'after success')
      await until(() =>
        expect(handlers['license.submitRelay']).toHaveBeenCalledTimes(1),
      );
    else await Promise.resolve();
    owned = false;
    browser.replace(
      credentials('A', { iat: Math.floor(Date.now() / 1000) + 1 }),
      true,
    );
    response.resolve({ success: true });

    expect(await pending).toBe(failure);
    expect(submit).toHaveBeenCalledTimes(stage === 'before submit' ? 0 : 1);
    expect(requests).toHaveLength(stage === 'after success' ? 1 : 0);
  });

  it('rechecks the original session after the transport has already resolved', async () => {
    const auth = authModule.useAuth();
    const submit = vi.fn(
      async (value: Parameters<typeof submitInitialRelay>[1]) => {
        const result = await trpc.license.submitRelay.mutate(value);
        void auth.logout();
        browser.replace(credentials(), true);
        return result;
      },
    );
    await expect(
      submitInitialRelay(submit, input, vi.fn()),
    ).rejects.toBeInstanceOf(cancellation.CancelledOperationError);
    expect(submit).toHaveBeenCalledTimes(1);
    expect(handlers['license.submitRelay']).toHaveBeenCalledTimes(1);
    expect(requests).toHaveLength(1);
  });
});
