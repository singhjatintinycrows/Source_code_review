import { readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { TRPCClientError } from '@trpc/client';
import ts from 'typescript';
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import * as Vue from 'vue';
import { compileScript, parse } from 'vue/compiler-sfc';
import { credentials, deferred, installStorage } from './auth-session';

vi.mock('../app/composables/useLicense', () => ({
  useLicense: () => ({ clearLicense: vi.fn() }),
}));

let authModule: typeof import('../app/composables/useAuth');
let operation: typeof import('../app/utils/operation');
let nuxt: typeof import('./nuxt-app');
let browser: ReturnType<typeof installStorage>;
let middleware: typeof import('../app/middleware/auth.global').default;
const route = Vue.reactive({ query: {} as Record<string, string> });
const router = { push: vi.fn() };
const trpc = {
  getUserCount: { query: vi.fn() },
  verifySso: { mutate: vi.fn() },
  authorizeVsc: { mutate: vi.fn() },
  me: { query: vi.fn() },
};
const apps: Vue.App[] = [];

// The real SFC setup and lifecycle run in Vue without a DOM library or Nuxt compiler plugin.
const renderer = Vue.createRenderer({
  createElement: () => ({}),
  createText: () => ({}),
  createComment: () => ({}),
  insert: () => {},
  remove: () => {},
  setText: () => {},
  setElementText: () => {},
  parentNode: () => null,
  nextSibling: () => null,
  patchProp: () => {},
});

function mountScript(relativePath: string) {
  const filename = fileURLToPath(new URL(relativePath, import.meta.url));
  const { descriptor } = parse(readFileSync(filename, 'utf8'), { filename });
  const script = compileScript(descriptor, { id: relativePath });
  const code = ts.transpileModule(script.content, {
    compilerOptions: {
      module: ts.ModuleKind.CommonJS,
      target: ts.ScriptTarget.ES2022,
    },
  }).outputText;
  const dependencies: Record<string, unknown> = {
    vue: Vue,
    '#app': nuxt,
    'vue-router': { useRoute: () => route, useRouter: () => router },
    '../composables/useAuth': authModule,
    './composables/useAuth': authModule,
    '../utils/operation': operation,
  };
  const module = { exports: {} as { default: Vue.Component } };
  new Function('require', 'module', 'exports', 'definePageMeta', code)(
    (name: string) => {
      if (!(name in dependencies))
        throw new Error(`Unmocked SFC import: ${name}`);
      return dependencies[name];
    },
    module,
    module.exports,
    () => {},
  );
  const app = renderer.createApp({
    ...module.exports.default,
    render: () => null,
  });
  apps.push(app);
  const instance = app.mount({});
  return { app, state: (instance.$ as any).setupState };
}

async function flush() {
  for (let index = 0; index < 20; index++) await Vue.nextTick();
}

beforeEach(async () => {
  vi.resetModules();
  vi.resetAllMocks();
  vi.useFakeTimers();
  browser = installStorage();
  nuxt = await import('./nuxt-app');
  nuxt.useNuxtApp.mockReturnValue({ $trpc: trpc });
  nuxt.useRuntimeConfig.mockReturnValue({
    public: { ssoUrl: 'https://sso.example.test' },
  });
  trpc.getUserCount.query.mockResolvedValue(1);
  vi.spyOn(console, 'error').mockImplementation(() => undefined);
  route.query = {};
  authModule = await import('../app/composables/useAuth');
  operation = await import('../app/utils/operation');
  middleware = (await import('../app/middleware/auth.global')).default;
});

afterEach(() => {
  for (const app of apps.splice(0)) app.unmount();
  vi.clearAllTimers();
  vi.useRealTimers();
  vi.unstubAllGlobals();
  vi.restoreAllMocks();
});

describe('root session lifecycle', () => {
  it('owns storage observation independently of route consumers and disposes/restarts it', () => {
    const root = mountScript('../app/app.vue');
    const auth = authModule.useAuth();
    auth.user.value = { email: 'A@example.test' } as any;
    browser.replace(credentials('B'));
    expect(auth.user.value).toBeNull();
    auth.user.value = { email: 'B@example.test' } as any;
    root.app.unmount();
    apps.splice(apps.indexOf(root.app), 1);
    browser.replace(credentials('A'));
    expect(auth.user.value).not.toBeNull();
    mountScript('../app/app.vue');
    expect(auth.user.value).toBeNull();
    expect(
      browser.addListener.mock.calls.filter(([event]) => event === 'storage'),
    ).toHaveLength(2);
    expect(
      browser.removeListener.mock.calls.filter(
        ([event]) => event === 'storage',
      ),
    ).toHaveLength(1);
  });
});

describe('login continuation ownership', () => {
  it.each([
    'success',
    'unauthorized',
  ] as const)('does not mark VSC authorized or show an obsolete %s after account replacement', async (outcome) => {
    route.query = { identifier: 'editor-login' };
    const response = deferred();
    trpc.authorizeVsc.mutate.mockReturnValue(response.promise);
    mountScript('../app/app.vue');
    const { state } = mountScript('../app/pages/login.vue');
    await flush();
    expect(trpc.authorizeVsc.mutate).toHaveBeenCalledTimes(1);
    browser.replace(credentials('B'));
    if (outcome === 'success') response.resolve({ success: true });
    else
      response.reject(
        Object.assign(new TRPCClientError('Old session expired'), {
          data: { code: 'UNAUTHORIZED' },
        }),
      );
    await flush();
    expect(state.isClientAuthorized).toBe(false);
    expect(state.errorMsg).toBeNull();
    expect(state.isLoading).toBe(false);
    expect(vi.getTimerCount()).toBe(0);
  });

  it('does not mark a failed authorizeVsc response successful', async () => {
    route.query = { identifier: 'editor-login' };
    trpc.authorizeVsc.mutate.mockResolvedValue({ success: false });
    mountScript('../app/app.vue');
    const { state } = mountScript('../app/pages/login.vue');
    await flush();
    expect(state.isClientAuthorized).toBe(false);
    expect(vi.getTimerCount()).toBe(0);
  });

  it.each([
    false,
    true,
  ])('honors a false login result for identifier flow = %s', async (identifier) => {
    route.query = {
      token: 'sso-token',
      ...(identifier ? { identifier: 'editor-login' } : {}),
    };
    browser.clear();
    const auth = authModule.useAuth();
    vi.spyOn(authModule, 'useAuth').mockReturnValue({
      ...auth,
      login: vi.fn().mockResolvedValue(false),
    });
    mountScript('../app/app.vue');
    const { state } = mountScript('../app/pages/login.vue');
    await flush();
    expect(state.isClientAuthorized).toBe(false);
    expect(router.push).not.toHaveBeenCalled();
    expect(vi.getTimerCount()).toBe(0);
  });

  it.each([
    false,
    true,
  ])('only completes the current SSO login for identifier flow = %s', async (identifier) => {
    route.query = {
      token: 'sso-token',
      ...(identifier ? { identifier: 'editor-login' } : {}),
    };
    trpc.verifySso.mutate.mockResolvedValue({
      success: true,
      ...credentials('B'),
    });
    mountScript('../app/app.vue');
    const { state } = mountScript('../app/pages/login.vue');
    await flush();
    expect(trpc.verifySso.mutate).toHaveBeenCalledTimes(1);
    expect(trpc.authorizeVsc.mutate).not.toHaveBeenCalled();
    expect(state.isClientAuthorized).toBe(identifier);
    if (!identifier) expect(router.push).toHaveBeenCalledWith('/');
  });

  it('does not start SSO after the user-count await belongs to an obsolete session', async () => {
    route.query = { token: 'sso-token' };
    const count = deferred();
    trpc.getUserCount.query.mockReturnValue(count.promise);
    mountScript('../app/app.vue');
    mountScript('../app/pages/login.vue');
    browser.replace(credentials('B'));
    count.resolve(1);
    await flush();
    expect(trpc.verifySso.mutate).not.toHaveBeenCalled();
    expect(router.push).not.toHaveBeenCalled();
  });

  it('checks the login epoch at the caller even when the login promise already returned true', async () => {
    route.query = { token: 'sso-token', identifier: 'editor-login' };
    browser.clear();
    const auth = authModule.useAuth();
    trpc.verifySso.mutate.mockResolvedValue({
      success: true,
      ...credentials('A'),
    });
    vi.spyOn(authModule, 'useAuth').mockReturnValue({
      ...auth,
      login: async (token, identifier) => {
        const success = await auth.login(token, identifier);
        browser.replace(credentials('B'));
        return success;
      },
    });
    mountScript('../app/app.vue');
    const { state } = mountScript('../app/pages/login.vue');
    await flush();
    expect(state.isClientAuthorized).toBe(false);
    expect(state.errorMsg).toBeNull();
    expect(vi.getTimerCount()).toBe(0);
  });

  it('does not continue a superseded pending login or mutate an unmounted login page', async () => {
    route.query = { token: 'sso-token', identifier: 'editor-login' };
    browser.clear();
    const response = deferred();
    trpc.verifySso.mutate.mockReturnValue(response.promise);
    mountScript('../app/app.vue');
    const { app, state } = mountScript('../app/pages/login.vue');
    await flush();
    expect(trpc.verifySso.mutate).toHaveBeenCalledTimes(1);
    browser.replace(credentials('B'));
    app.unmount();
    apps.splice(apps.indexOf(app), 1);
    response.resolve({ success: true, ...credentials('A') });
    await flush();
    expect(state.isClientAuthorized).toBe(false);
    expect(state.errorMsg).toBeNull();
    expect(router.push).not.toHaveBeenCalled();
    expect(vi.getTimerCount()).toBe(0);
  });

  it('stops an authorization countdown on session replacement', async () => {
    route.query = { identifier: 'editor-login' };
    trpc.authorizeVsc.mutate.mockResolvedValue({ success: true });
    mountScript('../app/app.vue');
    const { state } = mountScript('../app/pages/login.vue');
    await flush();
    expect(state.isClientAuthorized).toBe(true);
    browser.replace(credentials('B'));
    await flush();
    vi.advanceTimersByTime(6000);
    expect(state.isClientAuthorized).toBe(false);
    expect(browser.window.close).not.toHaveBeenCalled();
    expect(vi.getTimerCount()).toBe(0);
  });
});

describe('auth middleware coherence', () => {
  const go = (path: string, query = {}) =>
    middleware({ path, query } as any, {} as any);

  it('preserves the /login?identifier exception and normal authenticated redirects', () => {
    go('/login', { identifier: 'editor-login' });
    expect(nuxt.navigateTo).not.toHaveBeenCalled();
    go('/login');
    expect(nuxt.navigateTo).toHaveBeenLastCalledWith('/services');
    go('/');
    expect(nuxt.navigateTo).toHaveBeenLastCalledWith('/services');
  });

  it('redirects an incomplete pair without clearing its credentials, even when the old refresh token expired', () => {
    const pair = {
      accessToken: credentials('B').accessToken,
      refreshToken: credentials('A', { refreshExp: 100 }).refreshToken,
    };
    browser.replace(pair);
    go('/services');
    expect(nuxt.navigateTo).toHaveBeenCalledWith('/login');
    expect(browser.storage.getItem('accessToken')).toBe(pair.accessToken);
    expect(browser.storage.getItem('refreshToken')).toBe(pair.refreshToken);
  });

  it.each([
    false,
    true,
  ])('clears a coherently expired session, with quoted tokens = %s, without a login redirect loop', (quoted) => {
    browser.replace(credentials('A', { refreshExp: 100 }), false, quoted);
    go('/login');
    expect(browser.storage.getItem('accessToken')).toBeNull();
    expect(browser.storage.getItem('refreshToken')).toBeNull();
    expect(nuxt.navigateTo).not.toHaveBeenCalled();
    go('/services');
    expect(nuxt.navigateTo).toHaveBeenCalledWith('/login');
  });
});
