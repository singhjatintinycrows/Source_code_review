import { createRequire } from 'node:module';
import { credentials } from './auth-session';

const jwt = createRequire(
  new URL('../../backend/package.json', import.meta.url),
)('jsonwebtoken');
const secret = 'dashboard-courier-auth-test-secret';

export function signedCredentials(...args: Parameters<typeof credentials>) {
  const pair = credentials(...args);
  return {
    accessToken: jwt.sign(jwt.decode(pair.accessToken), secret, {
      algorithm: 'HS256',
    }) as string,
    refreshToken: jwt.sign(jwt.decode(pair.refreshToken), secret, {
      algorithm: 'HS256',
    }) as string,
  };
}

export function verifyAuthToken(token: string) {
  return jwt.verify(token, secret, { algorithms: ['HS256'] }) as {
    userId: string;
    exp: number;
    userSecret?: string;
  };
}
