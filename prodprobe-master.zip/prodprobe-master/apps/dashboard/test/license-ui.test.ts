import { readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { TRPCClientError } from '@trpc/client';
import superjson from 'superjson';
import ts from 'typescript';
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import * as Vue from 'vue';
import { compileScript, parse } from 'vue/compiler-sfc';
import * as authModule from '../app/composables/useAuth';
import * as licenseModule from '../app/composables/useLicense';
import trpcPlugin from '../app/plugins/trpc';
import * as initialRelay from '../app/utils/initialRelay';
import * as operation from '../app/utils/operation';
import * as tokenUtils from '../app/utils/token';
import * as trpcUtils from '../app/utils/trpc';
import {
  credentials,
  installStorage,
  jwt as makeJwt,
  until as untilTransport,
} from './auth-session';
import * as nuxtApp from './nuxt-app';
import { signedCredentials, verifyAuthToken } from './signed-auth';

type LicenseStatus = NonNullable<
  ReturnType<typeof licenseModule.useLicense>['licenseStatus']['value']
>;
type User = {
  email: string;
  teams: string[];
  permissions: { isAdmin: boolean };
};
type Node = {
  type: string;
  text: string;
  props: Record<string, any>;
  parent: Node | null;
  children: Node[];
};

const makeNode = (type: string, text = ''): Node => ({
  type,
  text,
  props: {},
  parent: null,
  children: [],
});

function remove(node: Node) {
  if (!node.parent) return;
  const index = node.parent.children.indexOf(node);
  if (index < 0) throw new Error('Renderer node does not belong to parent');
  node.parent.children.splice(index, 1);
  node.parent = null;
}

const renderer = Vue.createRenderer<Node, Node>({
  createElement: (type) => makeNode(type),
  createText: (text) => makeNode('#text', text),
  createComment: (text) => makeNode('#comment', text),
  setText(node, text) {
    node.text = text;
  },
  setElementText(node, text) {
    for (const child of node.children) child.parent = null;
    node.children = [];
    node.text = text;
  },
  parentNode: (node) => node.parent,
  nextSibling: (node) =>
    node.parent?.children[node.parent.children.indexOf(node) + 1] ?? null,
  insert(node, parent, anchor = null) {
    if (node === anchor) return;
    remove(node);
    const index = anchor
      ? parent.children.indexOf(anchor)
      : parent.children.length;
    if (index < 0) throw new Error('Renderer anchor does not belong to parent');
    parent.children.splice(index, 0, node);
    node.parent = parent;
  },
  remove,
  patchProp(node, key, _previous, value) {
    node.props[key] = value;
  },
});

const nodes = (node: Node): Node[] => [node, ...node.children.flatMap(nodes)];
const text = (node: Node): string =>
  node.type === '#comment' ? '' : node.text + node.children.map(text).join('');
const button = (root: Node, label: string) =>
  nodes(root).find(
    (node) => node.type === 'button' && text(node).trim() === label,
  );
const input = (root: Node) => nodes(root).find((node) => node.type === 'input');

function click(root: Node, label: string) {
  const target = button(root, label);
  expect(Boolean(target), `Expected a ${label} button`).toBe(true);
  expect(target!.props.disabled).not.toBe(true);
  return target!.props.onClick();
}

function deferred<T>() {
  let resolve!: (value: T) => void;
  let reject!: (error: unknown) => void;
  const promise = new Promise<T>((res, rej) => {
    resolve = res;
    reject = rej;
  });
  return { promise, resolve, reject };
}

async function until(assertion: () => void) {
  for (let attempt = 0; attempt < 100; attempt++) {
    await Vue.nextTick();
    try {
      assertion();
      return;
    } catch (error) {
      if (attempt === 99) throw error;
    }
  }
}

async function enterJwt(root: Node, value = 'signed-license-jwt') {
  await until(() =>
    expect(nodes(root).find((node) => node.type === 'textarea')).toBeDefined(),
  );
  const textarea = nodes(root).find((node) => node.type === 'textarea')!;
  textarea.props.onInput({ target: { value } });
  await Vue.nextTick();
}

const SlotStub = Vue.defineComponent({
  inheritAttrs: false,
  setup:
    (_, { slots }) =>
    () =>
      Vue.h(
        'div',
        ['header', 'default', 'footer', 'content'].flatMap(
          (name) => slots[name]?.() ?? [],
        ),
      ),
});
const ButtonStub = Vue.defineComponent({
  inheritAttrs: false,
  setup:
    (_, { attrs, slots }) =>
    () =>
      Vue.h(
        'button',
        {
          ...attrs,
          disabled: Boolean(attrs.disabled || attrs.loading),
        },
        slots.default?.() ?? String(attrs.label ?? ''),
      ),
});
const TextareaStub = Vue.defineComponent({
  inheritAttrs: false,
  props: ['modelValue'],
  emits: ['update:modelValue'],
  setup:
    (props, { attrs, emit }) =>
    () =>
      Vue.h('textarea', {
        ...attrs,
        value: props.modelValue,
        onInput: (event: { target: { value: string } }) =>
          emit('update:modelValue', event.target.value),
      }),
});
const ModalStub = Vue.defineComponent({
  props: ['open'],
  setup:
    (props, { slots }) =>
    () =>
      props.open ? slots.content?.() : null,
});

const admin: User = {
  email: 'admin@example.test',
  teams: [],
  permissions: { isAdmin: true },
};
const cachedStatus = {
  isProvisioned: true,
  status: 'SYNCED',
  hintStatus: 'SYNCED',
  customerName: 'Cached customer',
  licenseId: 'license-original',
  maxAgents: 5,
  softAgentLimit: 10,
  expiryDate: Date.UTC(2099, 0, 1),
  upgradeRequired: false,
} as LicenseStatus;
const license = licenseModule.useLicense();
const accessToken = Vue.ref('access-token');
const auth = {
  user: Vue.ref<User | null>(null),
  userFetchError: Vue.ref(false),
  accessToken,
  sessionVersion: Vue.ref(0),
  isAuthenticated: Vue.computed(() => Boolean(accessToken.value)),
  captureSession(): () => boolean {
    const version = auth.sessionVersion.value;
    return () =>
      version === auth.sessionVersion.value && auth.isAuthenticated.value;
  },
  fetchUser: vi.fn(),
  logout: vi.fn(),
};

function changeSession(token = '') {
  auth.sessionVersion.value++;
  auth.accessToken.value = token;
  auth.user.value = null;
  auth.userFetchError.value = false;
  license.clearLicense();
}

const route = Vue.reactive({ path: '/services' });
const router = { replace: vi.fn() };
const toast = { add: vi.fn() };
const fetchMock = vi.fn();
const licensingUrl = 'https://licensing.example.test';
const publicKeyUrl = `${licensingUrl}/public-key`;
const trpc = {
  me: { query: vi.fn() },
  license: {
    status: { query: vi.fn() },
    provision: { mutate: vi.fn() },
    sync: { mutate: vi.fn() },
    prepareRelay: { mutate: vi.fn() },
    submitRelay: { mutate: vi.fn() },
    reportRevocation: { mutate: vi.fn() },
    acquireCourierLock: { mutate: vi.fn() },
    releaseCourierLock: { mutate: vi.fn() },
    getDeploymentConfig: { query: vi.fn() },
  },
};
const apps: Vue.App<Node>[] = [];
let authProvider: () => typeof auth | ReturnType<typeof authModule.useAuth> =
  () => auth;
let stopAuthObserver: (() => void) | undefined;

function mountSfc(relativePath: string, child?: Vue.Component) {
  // Compile the actual SFC in memory: these node-only tests have no Nuxt/Vite DOM plugin.
  const filename = fileURLToPath(new URL(relativePath, import.meta.url));
  const { descriptor } = parse(readFileSync(filename, 'utf8'), { filename });
  const script = compileScript(descriptor, {
    id: relativePath,
    inlineTemplate: true,
    templateOptions: { compilerOptions: { hoistStatic: false } },
  });
  const code = ts.transpileModule(script.content, {
    compilerOptions: {
      module: ts.ModuleKind.CommonJS,
      target: ts.ScriptTarget.ES2022,
    },
  }).outputText;
  const dependencies: Record<string, unknown> = {
    vue: Vue,
    '#app': nuxtApp,
    'vue-router': { useRoute: () => route, useRouter: () => router },
    '@hyperprobe/constants': {
      getLicensingServerUrl: async () => licensingUrl,
      HYPERPROBE_LICENSING_PUBLIC_KEY_URL: publicKeyUrl,
    },
    '../composables/useLicense': licenseModule,
    '../../composables/useLicense': licenseModule,
    '../composables/useAuth': { useAuth: authProvider },
    '../../composables/useAuth': { useAuth: authProvider },
    '../utils/trpc': trpcUtils,
    '../../utils/trpc': trpcUtils,
    '../utils/operation': operation,
    '../../utils/operation': operation,
    '../utils/initialRelay': initialRelay,
    '../../utils/initialRelay': initialRelay,
    '../../utils/token': tokenUtils,
    '../../components/CopyToClipboard.vue': { default: SlotStub },
  };
  const module = { exports: {} as { default: Vue.Component } };
  new Function(
    'require',
    'module',
    'exports',
    'useRuntimeConfig',
    'useToast',
    code,
  )(
    (name: string) => {
      if (!(name in dependencies))
        throw new Error(`Unmocked SFC import: ${name}`);
      return dependencies[name];
    },
    module,
    module.exports,
    () => ({ app: { baseURL: '/' }, public: { platformVersion: 'test' } }),
    () => toast,
  );
  const root = makeNode('root');
  const app = renderer.createApp({
    render: () =>
      Vue.h(
        module.exports.default,
        null,
        child ? { default: () => Vue.h(child) } : undefined,
      ),
  });
  for (const [name, component] of Object.entries({
    UCard: SlotStub,
    UBadge: SlotStub,
    UFormField: SlotStub,
    UIcon: (props: Record<string, unknown>) => Vue.h('i', props),
    UNavigationMenu: SlotStub,
    UButton: ButtonStub,
    UTextarea: TextareaStub,
    UModal: ModalStub,
  }))
    app.component(name, component);
  apps.push(app);
  app.mount(root);
  return root;
}

function mountLayout() {
  const lifecycle = { mounts: 0, unmounts: 0 };
  const DraftPage = Vue.defineComponent({
    setup() {
      const draft = Vue.ref('');
      Vue.onMounted(() => {
        lifecycle.mounts++;
      });
      Vue.onUnmounted(() => {
        lifecycle.unmounts++;
      });
      return () =>
        Vue.h('input', {
          value: draft.value,
          onInput: (event: { target: { value: string } }) => {
            draft.value = event.target.value;
          },
        });
    },
  });
  return { root: mountSfc('../app/layouts/default.vue', DraftPage), lifecycle };
}

beforeEach(() => {
  vi.resetAllMocks();
  vi.useFakeTimers();
  authProvider = () => auth;
  const pair = credentials();
  installStorage(pair);
  authModule.writeAuthTokens(pair, undefined, { boundary: true });
  changeSession('access-token');
  license.licenseStatus.value = cachedStatus;
  auth.user.value = admin;
  route.path = '/services';
  nuxtApp.useNuxtApp.mockReturnValue({ $trpc: trpc });
  trpc.me.query.mockResolvedValue(admin);
  trpc.license.status.query.mockResolvedValue(cachedStatus);
  trpc.license.prepareRelay.mutate.mockResolvedValue({ success: true });
  trpc.license.acquireCourierLock.mutate.mockResolvedValue({ success: true });
  trpc.license.releaseCourierLock.mutate.mockResolvedValue({ success: true });
  auth.fetchUser.mockImplementation(async (force = false) => {
    if (!force && auth.user.value) return auth.user.value;
    const isCurrent = auth.captureSession();
    try {
      const user = await trpc.me.query();
      if (!isCurrent()) throw new operation.CancelledOperationError();
      auth.user.value = user;
      auth.userFetchError.value = false;
      return user;
    } catch (error) {
      if (!isCurrent()) throw new operation.CancelledOperationError();
      auth.userFetchError.value = true;
      throw error;
    }
  });
  auth.logout.mockImplementation(async () => {
    changeSession();
  });
  fetchMock.mockRejectedValue(new Error('Unexpected external request'));
  vi.stubGlobal('fetch', fetchMock);
  vi.spyOn(console, 'error').mockImplementation(() => undefined);
});

afterEach(() => {
  for (const app of apps.splice(0)) app.unmount();
  stopAuthObserver?.();
  stopAuthObserver = undefined;
  license.clearLicense();
  vi.clearAllTimers();
  vi.useRealTimers();
  vi.unstubAllGlobals();
  vi.restoreAllMocks();
});

describe('observed auth in the license UI', () => {
  const userA = {
    userId: 'A',
    email: 'A@example.test',
    permissions: { isAdmin: true, permissions: {} },
    teams: ['Administrators A'],
  };

  function installRealAuth(pair = credentials()) {
    const browser = installStorage(pair);
    authModule.writeAuthTokens(pair, undefined, { boundary: true });
    stopAuthObserver = authModule.observeAuthSession(trpc as any);
    authProvider = authModule.useAuth;
    const realAuth = authModule.useAuth();
    realAuth.user.value = userA;
    license.licenseStatus.value = cachedStatus;
    trpc.me.query.mockResolvedValue(userA);
    vi.mocked(browser.storage.setItem).mockClear();
    vi.spyOn(browser.storage, 'clear');
    return { ...browser, realAuth };
  }

  function expectSignIn(root: Node) {
    expect(text(root)).toContain('Sign In Required');
    expect(button(root, 'Sign In')?.props).toMatchObject({
      to: '/login',
      disabled: false,
    });
    expect(button(root, 'Sign In')?.props.onClick).toBeUndefined();
    expect(button(root, 'Sign out')).toBeUndefined();
    expect(button(root, 'Retry')).toBeUndefined();
    expect(input(root)).toBeUndefined();
    expect(vi.getTimerCount()).toBe(0);
    expect(trpc.me.query).not.toHaveBeenCalled();
    expect(trpc.license.status.query).not.toHaveBeenCalled();
    expect(nuxtApp.navigateTo).not.toHaveBeenCalled();
    expect(router.replace).not.toHaveBeenCalled();
  }

  describe('license page blocking-error reconciliation', () => {
    async function startRevalidation(isAdmin: boolean, licenseFails = false) {
      const pair = credentials();
      const browser = installRealAuth(pair);
      const { realAuth, storage } = browser;
      // installRealAuth seeds both caches; the page must own a cold initial read.
      realAuth.user.value = null;
      license.clearLicense();
      const version = realAuth.sessionVersion.value;
      const currentSession = realAuth.captureSession();
      const currentLicense = license.captureLicenseOperation();
      const original = deferred<User>();
      const replacement = deferred<User>();
      const nextUser = {
        ...userA,
        permissions: { isAdmin, permissions: { licenses: ['read'] } },
      };
      const next = credentials('A', { permissions: nextUser.permissions });
      trpc.me.query
        .mockReturnValueOnce(original.promise)
        .mockReturnValueOnce(replacement.promise);
      if (licenseFails) {
        trpc.license.status.query.mockRejectedValueOnce(
          new Error('License status unavailable'),
        );
      }
      const root = mountSfc('../app/pages/license/index.vue');
      const originalRead = realAuth.fetchUser().catch((error) => error);
      await vi.advanceTimersByTimeAsync(0);
      expect(trpc.me.query).toHaveBeenCalledTimes(1);
      expect(trpc.license.status.query).toHaveBeenCalledTimes(1);
      expect(realAuth.user.value).toBeNull();
      expect(license.licenseStatus.value).toEqual(
        licenseFails ? null : cachedStatus,
      );
      expect(license.licenseFetchError.value).toBe(licenseFails);
      const snapshot = license.licenseStatus.value;

      browser.change('accessToken', next.accessToken);
      await vi.advanceTimersByTimeAsync(0);
      await until(() => expect(trpc.me.query).toHaveBeenCalledTimes(2));
      expect(realAuth.user.value).toBeNull();
      expect(realAuth.userFetchError.value).toBe(false);

      return {
        browser,
        root,
        original,
        originalRead,
        replacement,
        nextUser,
        currentSession,
        currentLicense,
        expectCurrent() {
          expect(realAuth.isAuthenticated.value).toBe(true);
          expect(realAuth.sessionVersion.value).toBe(version);
          expect(currentSession()).toBe(true);
          expect(currentLicense()).toBe(true);
          expect(license.licenseStatus.value).toBe(snapshot);
          expect(license.licenseFetchError.value).toBe(licenseFails);
          expect(trpc.me.query).toHaveBeenCalledTimes(2);
          expect(trpc.license.status.query).toHaveBeenCalledTimes(1);
          expect(vi.getTimerCount()).toBe(0);
          expect(storage.getItem('accessToken')).toBe(next.accessToken);
          expect(storage.getItem('refreshToken')).toBe(pair.refreshToken);
          expect(vi.mocked(storage.setItem).mock.calls).toEqual([
            ['accessToken', next.accessToken],
          ]);
          expect(storage.removeItem).not.toHaveBeenCalled();
          expect(storage.clear).not.toHaveBeenCalled();
          expect(trpc.license.provision.mutate).not.toHaveBeenCalled();
          expect(fetchMock).not.toHaveBeenCalled();
        },
      };
    }

    afterEach(() => {
      for (const mock of [
        auth.fetchUser,
        trpc.license.sync.mutate,
        trpc.license.getDeploymentConfig.query,
        trpc.license.acquireCourierLock.mutate,
        trpc.license.prepareRelay.mutate,
        trpc.license.submitRelay.mutate,
        trpc.license.reportRevocation.mutate,
        trpc.license.releaseCourierLock.mutate,
        toast.add,
        nuxtApp.navigateTo,
        router.replace,
      ]) {
        expect(mock).not.toHaveBeenCalled();
      }
    });

    it.each([
      { role: 'admin', isAdmin: true },
      { role: 'viewer', isAdmin: false },
    ])('recovers $role when initial cancellation drains before replacement success', async ({
      isAdmin,
    }) => {
      const state = await startRevalidation(isAdmin);
      const { root, original, originalRead, replacement, nextUser, browser } =
        state;
      try {
        original.resolve(userA);
        expect(await originalRead).toBeInstanceOf(
          operation.CancelledOperationError,
        );
        await vi.advanceTimersByTimeAsync(0);
        expect(browser.realAuth.user.value).toBeNull();
        expect(browser.realAuth.userFetchError.value).toBe(false);
        expect(button(root, 'Retry')?.props.disabled).toBe(false);

        replacement.resolve(nextUser);
        await vi.advanceTimersByTimeAsync(0);
        expect(browser.realAuth.user.value).toEqual(nextUser);
        expect(browser.realAuth.userFetchError.value).toBe(false);
        state.expectCurrent();
        expect(text(root)).not.toContain(
          'Failed to Load License or User Status',
        );
        expect(button(root, 'Retry')).toBeUndefined();
        if (isAdmin) {
          expect(text(root)).toContain('Current Entitlements');
          expect(text(root)).toContain(cachedStatus.customerName);
          expect(button(root, 'Update JWT')?.props.disabled).toBe(false);
          expect(text(root)).not.toContain('Access Denied');
        } else {
          expect(text(root)).toContain('Access Denied');
          expect(text(root)).not.toContain('Current Entitlements');
          expect(button(root, 'Update JWT')).toBeUndefined();
          expect(button(root, 'Sync License')).toBeUndefined();
          expect(button(root, 'Activate License')).toBeUndefined();
        }
      } finally {
        original.resolve(userA);
        replacement.resolve(nextUser);
        await vi.advanceTimersByTimeAsync(0);
      }
    });

    it('keeps a failed current user replacement retryable, not denied or unlocked', async () => {
      const state = await startRevalidation(false);
      const { root, original, originalRead, replacement, nextUser, browser } =
        state;
      try {
        original.resolve(userA);
        expect(await originalRead).toBeInstanceOf(
          operation.CancelledOperationError,
        );
        await vi.advanceTimersByTimeAsync(0);
        expect(button(root, 'Retry')).toBeDefined();
        replacement.reject(new Error('Current permissions unavailable'));
        await vi.advanceTimersByTimeAsync(0);
        expect(browser.realAuth.user.value).toBeNull();
        expect(browser.realAuth.userFetchError.value).toBe(true);
        state.expectCurrent();
        expect(text(root)).toContain('Failed to Load License or User Status');
        expect(button(root, 'Retry')?.props.disabled).toBe(false);
        expect(text(root)).not.toContain('Access Denied');
        expect(text(root)).not.toContain('Current Entitlements');
        expect(button(root, 'Update JWT')).toBeUndefined();
        expect(button(root, 'Activate License')).toBeUndefined();
      } finally {
        original.resolve(userA);
        replacement.resolve(nextUser);
        await vi.advanceTimersByTimeAsync(0);
      }
    });

    it('keeps a confirmed viewer denied after stale UNAUTHORIZED with absent license data', async () => {
      const state = await startRevalidation(false, true);
      const { root, original, originalRead, replacement, nextUser, browser } =
        state;
      try {
        replacement.resolve(nextUser);
        await vi.advanceTimersByTimeAsync(0);
        expect(browser.realAuth.user.value).toEqual(nextUser);
        original.reject(
          Object.assign(new TRPCClientError('Obsolete session expired'), {
            data: { code: 'UNAUTHORIZED' },
          }),
        );
        expect(await originalRead).toBeInstanceOf(
          operation.CancelledOperationError,
        );
        await vi.advanceTimersByTimeAsync(0);
        state.expectCurrent();
        expect(browser.realAuth.user.value).toEqual(nextUser);
        expect(browser.realAuth.userFetchError.value).toBe(false);
        expect(text(root)).not.toContain(
          'Failed to Load License or User Status',
        );
        expect(button(root, 'Retry')).toBeUndefined();
        expect(text(root)).toContain('Access Denied');
        expect(text(root)).not.toContain('Current Entitlements');
        expect(button(root, 'Update JWT')).toBeUndefined();
        expect(button(root, 'Sync License')).toBeUndefined();
        expect(button(root, 'Activate License')).toBeUndefined();
      } finally {
        original.resolve(userA);
        replacement.resolve(nextUser);
        await vi.advanceTimersByTimeAsync(0);
      }
    });

    it('keeps an admin retryable when user revalidation succeeds without license data', async () => {
      const state = await startRevalidation(true, true);
      const { root, original, originalRead, replacement, nextUser, browser } =
        state;
      try {
        original.resolve(userA);
        expect(await originalRead).toBeInstanceOf(
          operation.CancelledOperationError,
        );
        await vi.advanceTimersByTimeAsync(0);
        expect(button(root, 'Retry')).toBeDefined();
        replacement.resolve(nextUser);
        await vi.advanceTimersByTimeAsync(0);
        expect(browser.realAuth.user.value).toEqual(nextUser);
        expect(browser.realAuth.userFetchError.value).toBe(false);
        state.expectCurrent();
        expect(text(root)).toContain('Failed to Load License or User Status');
        expect(button(root, 'Retry')?.props.disabled).toBe(false);
        expect(text(root)).not.toContain('Access Denied');
        expect(text(root)).not.toContain('Current Entitlements');
        expect(button(root, 'Update JWT')).toBeUndefined();
        expect(button(root, 'Activate License')).toBeUndefined();
      } finally {
        original.resolve(userA);
        replacement.resolve(nextUser);
        await vi.advanceTimersByTimeAsync(0);
      }
    });

    it('preserves License applied through user-only success while verification is pending and then failed', async () => {
      const pair = credentials();
      const browser = installRealAuth(pair);
      const { realAuth, storage } = browser;
      const version = realAuth.sessionVersion.value;
      const currentSession = realAuth.captureSession();
      const verification = deferred<LicenseStatus>();
      const pendingUser = deferred<User>();
      const failedUser = deferred<User>();
      trpc.license.provision.mutate.mockResolvedValueOnce({ success: true });
      fetchMock.mockResolvedValueOnce(Response.json('test-public-key'));
      const root = mountSfc('../app/pages/license/index.vue');
      await vi.advanceTimersByTimeAsync(0);
      expect(trpc.me.query).toHaveBeenCalledTimes(1);
      expect(trpc.license.status.query).toHaveBeenCalledTimes(1);
      const snapshot = license.licenseStatus.value;
      trpc.license.status.query.mockReturnValueOnce(verification.promise);
      click(root, 'Update JWT');
      await enterJwt(root);
      const action = click(root, 'Update License');
      try {
        await until(() => {
          expect(trpc.me.query).toHaveBeenCalledTimes(2);
          expect(trpc.license.status.query).toHaveBeenCalledTimes(2);
        });
        await vi.advanceTimersByTimeAsync(0);
        expect(realAuth.user.value).toEqual(userA);
        const currentLicense = license.captureLicenseOperation(true);
        trpc.me.query
          .mockReturnValueOnce(pendingUser.promise)
          .mockReturnValueOnce(failedUser.promise);
        const tokens: string[] = [];
        for (const [index, replacement] of [
          pendingUser,
          failedUser,
        ].entries()) {
          if (index) {
            verification.reject(new Error('Applied status unavailable'));
            await action;
            await vi.advanceTimersByTimeAsync(0);
          }
          expect(text(root)).toContain('License applied;');
          const nextUser = {
            ...userA,
            permissions: {
              isAdmin: true,
              permissions: { licenses: index ? ['read', 'write'] : ['read'] },
            },
          };
          const next = credentials('A', { permissions: nextUser.permissions });
          tokens.push(next.accessToken);
          browser.change('accessToken', next.accessToken);
          await vi.advanceTimersByTimeAsync(0);
          expect(realAuth.user.value).toBeNull();
          expect(trpc.me.query).toHaveBeenCalledTimes(3 + index);
          replacement.resolve(nextUser);
          await vi.advanceTimersByTimeAsync(0);
          expect(realAuth.user.value).toEqual(nextUser);
          expect(realAuth.userFetchError.value).toBe(false);
          expect(realAuth.sessionVersion.value).toBe(version);
          expect(currentSession()).toBe(true);
          expect(currentLicense()).toBe(true);
          expect(license.licenseStatus.value).toBe(snapshot);
          expect(license.licenseFetchError.value).toBe(Boolean(index));
          expect(license.isLicenseUpdating.value).toBe(!index);
          expect(text(root)).toContain(
            index
              ? 'License applied; latest status could not be loaded'
              : 'License applied; refreshing status...',
          );
          expect(button(root, 'Retry')).toBeUndefined();
          expect(button(root, 'Retry Status')).toBeDefined();
          expect(button(root, 'Update JWT')?.props.disabled).toBe(true);
          expect(button(root, 'Sync License')?.props.disabled).toBe(true);
          expect(button(root, 'Update License')).toBeUndefined();
          expect(trpc.me.query).toHaveBeenCalledTimes(3 + index);
          expect(trpc.license.status.query).toHaveBeenCalledTimes(2);
          expect(trpc.license.provision.mutate).toHaveBeenCalledExactlyOnceWith(
            {
              jwt: 'signed-license-jwt',
              publicKey: 'test-public-key',
            },
          );
          expect(fetchMock).toHaveBeenCalledTimes(1);
          expect(toast.add).not.toHaveBeenCalled();
          expect(vi.getTimerCount()).toBe(0);
        }
        expect(vi.mocked(storage.setItem).mock.calls).toEqual(
          tokens.map((token) => ['accessToken', token]),
        );
        expect(storage.getItem('accessToken')).toBe(tokens[1]);
        expect(storage.getItem('refreshToken')).toBe(pair.refreshToken);
        expect(storage.removeItem).not.toHaveBeenCalled();
        expect(storage.clear).not.toHaveBeenCalled();
      } finally {
        verification.reject(new Error('Applied status unavailable'));
        pendingUser.resolve(userA);
        failedUser.resolve(userA);
        await action;
        await vi.advanceTimersByTimeAsync(0);
      }
    });

    it.each([
      'account change',
      'unmount',
    ])('ignores late initial and replacement reads after %s', async (change) => {
      const state = await startRevalidation(true);
      const { root, original, originalRead, replacement, nextUser, browser } =
        state;
      const { realAuth, storage } = browser;
      const pairB = credentials('B');
      const userB = { ...userA, userId: 'B', email: 'B@example.test' };
      const statusB = {
        ...cachedStatus,
        licenseId: 'license-b',
        customerName: 'Customer B',
      };
      try {
        state.expectCurrent();
        if (change === 'account change') {
          trpc.me.query.mockResolvedValue(userB);
          trpc.license.status.query.mockResolvedValue(statusB);
          browser.replace(pairB);
          await vi.advanceTimersByTimeAsync(0);
          expect(state.currentSession()).toBe(false);
          expect(state.currentLicense()).toBe(false);
          expect(realAuth.user.value).toEqual(userB);
          expect(license.licenseStatus.value).toEqual(statusB);
          expect(text(root)).toContain('Customer B');
        } else {
          apps.pop()!.unmount();
          expect(root.children).toEqual([]);
        }
        const version = realAuth.sessionVersion.value;
        const currentSession = realAuth.captureSession();
        const currentLicense = license.captureLicenseOperation();
        original.reject(
          Object.assign(new TRPCClientError('Obsolete session expired'), {
            data: { code: 'UNAUTHORIZED' },
          }),
        );
        expect(await originalRead).toBeInstanceOf(
          operation.CancelledOperationError,
        );
        await vi.advanceTimersByTimeAsync(0);
        replacement.resolve(nextUser);
        await vi.advanceTimersByTimeAsync(0);
        expect(realAuth.userFetchError.value).toBe(false);
        expect(realAuth.sessionVersion.value).toBe(version);
        expect(realAuth.isAuthenticated.value).toBe(true);
        expect(currentSession()).toBe(true);
        expect(currentLicense()).toBe(true);
        if (change === 'account change') {
          expect(realAuth.user.value).toEqual(userB);
          expect(license.licenseStatus.value).toEqual(statusB);
          expect(license.licenseFetchError.value).toBe(false);
          expect(text(root)).toContain('Customer B');
          expect(text(root)).not.toContain(cachedStatus.customerName);
          expect(button(root, 'Retry')).toBeUndefined();
          expect(button(root, 'Update JWT')?.props.disabled).toBe(false);
          expect(trpc.me.query).toHaveBeenCalledTimes(3);
          expect(trpc.license.status.query).toHaveBeenCalledTimes(2);
          expect(storage.getItem('accessToken')).toBe(pairB.accessToken);
          expect(storage.getItem('refreshToken')).toBe(pairB.refreshToken);
          expect(storage.setItem).toHaveBeenCalledTimes(3);
          expect(storage.removeItem).not.toHaveBeenCalled();
          expect(storage.clear).not.toHaveBeenCalled();
        } else {
          // The observer may fill the current shared cache, but not restore the page.
          expect(realAuth.user.value).toEqual(nextUser);
          state.expectCurrent();
          expect(root.children).toEqual([]);
        }
        expect(trpc.license.provision.mutate).not.toHaveBeenCalled();
        expect(fetchMock).not.toHaveBeenCalled();
        expect(vi.getTimerCount()).toBe(0);
      } finally {
        original.resolve(userA);
        replacement.resolve(nextUser);
        await vi.advanceTimersByTimeAsync(0);
      }
    });
  });

  it.each([
    '/services',
    '/license',
  ])('keeps an observed permission revalidation failure retryable on mounted %s', async (path) => {
    const pair = credentials();
    const browser = installRealAuth(pair);
    const { realAuth, storage } = browser;
    const version = realAuth.sessionVersion.value;
    const currentLicense = license.captureLicenseOperation();
    const isLicensePage = path === '/license';
    route.path = path;
    const layout = isLicensePage
      ? { root: mountSfc('../app/layouts/default.vue'), lifecycle: undefined }
      : mountLayout();
    const root = isLicensePage
      ? mountSfc('../app/pages/license/index.vue')
      : layout.root;
    await vi.advanceTimersByTimeAsync(0);
    expect(vi.getTimerCount()).toBe(1);
    const cachedContent = isLicensePage
      ? nodes(root).find(
          (node) => node.type === 'h3' && text(node) === 'Current Entitlements',
        )
      : input(root);
    expect(cachedContent).toBeDefined();

    trpc.me.query.mockRejectedValueOnce(new Error('User refresh unavailable'));
    await expect(realAuth.fetchUser(true)).rejects.toThrow(
      'User refresh unavailable',
    );
    await Vue.nextTick();
    expect(realAuth.userFetchError.value).toBe(true);
    expect(nodes(root)).toContain(cachedContent);
    expect(
      button(root, isLicensePage ? 'Retry Status' : 'Retry'),
    ).toBeDefined();

    const viewer = {
      ...userA,
      permissions: { isAdmin: false, permissions: {} },
      teams: ['Readers A'],
    };
    const next = credentials('A', { permissions: viewer.permissions });
    const pending = deferred<User>();
    const reads = trpc.me.query.mock.calls.length;
    trpc.me.query
      .mockReturnValueOnce(pending.promise)
      .mockRejectedValueOnce(new Error('Still unavailable'))
      .mockResolvedValue(viewer);
    try {
      browser.change('accessToken', next.accessToken);
      await vi.advanceTimersByTimeAsync(0);
      expect(trpc.me.query).toHaveBeenCalledTimes(reads + 1);
      expect(realAuth.userFetchError.value).toBe(false);
      expect(
        nodes(root).find(
          (node) =>
            node.type === 'i' &&
            String(node.props.class).includes('animate-spin'),
        ),
      ).toBeDefined();
      expect(nodes(root)).not.toContain(cachedContent);
      expect(text(root)).not.toContain('Access Denied');
      expect(vi.getTimerCount()).toBe(0);

      pending.reject(new Error('Permissions revalidation unavailable'));
      for (let failure = 0; failure < 2; failure++) {
        if (failure) await click(root, 'Retry');
        await vi.advanceTimersByTimeAsync(0);
        expect(trpc.me.query).toHaveBeenCalledTimes(reads + failure + 1);
        expect(realAuth.userFetchError.value).toBe(true);
        expect(realAuth.user.value).toBeNull();
        expect(button(root, 'Retry')?.props.disabled).toBe(false);
        expect(text(root)).toContain(
          isLicensePage
            ? 'Failed to Load License or User Status'
            : 'Failed to Load Deployment Status',
        );
        expect(input(root)).toBeUndefined();
        expect(button(root, 'Update JWT')).toBeUndefined();
        expect(text(root)).not.toContain('Access Denied');
        expect(text(layout.root)).not.toContain(userA.email);
        expect(license.licenseStatus.value).toEqual(cachedStatus);
      }

      await click(root, 'Retry');
      await vi.advanceTimersByTimeAsync(0);
      expect(realAuth.user.value).toEqual(viewer);
      expect(realAuth.userFetchError.value).toBe(false);
      expect(button(root, 'Retry')).toBeUndefined();
      expect(text(layout.root)).toContain(viewer.email);
      nodes(layout.root)
        .find((node) => node.props.title === 'View your teams')!
        .props.onClick();
      await Vue.nextTick();
      expect(text(layout.root)).toContain(viewer.teams[0]);
      expect(text(layout.root)).not.toContain(userA.teams[0]);
      if (isLicensePage) {
        expect(text(root)).toContain('Access Denied');
        expect(text(root)).not.toContain('Current Entitlements');
        expect(button(root, 'Update JWT')).toBeUndefined();
      } else {
        expect(input(root)).toBeDefined();
        expect(layout.lifecycle).toEqual({ mounts: 2, unmounts: 1 });
      }
      expect(vi.getTimerCount()).toBe(1);
      const statusReads = trpc.license.status.query.mock.calls.length;
      await vi.advanceTimersByTimeAsync(60_000);
      expect(trpc.license.status.query).toHaveBeenCalledTimes(statusReads + 1);
      expect(trpc.me.query).toHaveBeenCalledTimes(reads + 3);
      expect(realAuth.isAuthenticated.value).toBe(true);
      expect(realAuth.sessionVersion.value).toBe(version);
      expect(currentLicense()).toBe(true);
      expect(license.licenseStatus.value).toEqual(cachedStatus);
      expect(storage.getItem('accessToken')).toBe(next.accessToken);
      expect(storage.getItem('refreshToken')).toBe(pair.refreshToken);
      expect(vi.mocked(storage.setItem).mock.calls).toEqual([
        ['accessToken', next.accessToken],
      ]);
      expect(storage.removeItem).not.toHaveBeenCalled();
      expect(storage.clear).not.toHaveBeenCalled();
      expect(nuxtApp.navigateTo).not.toHaveBeenCalled();
      expect(router.replace).not.toHaveBeenCalled();
    } finally {
      pending.resolve(viewer);
      await vi.advanceTimersByTimeAsync(0);
    }
  });

  it('shows a non-destructive Sign In link when the real layout poll detects expiry', async () => {
    const pair = credentials('A', {
      refreshExp: Math.floor(Date.now() / 1000) + 30,
    });
    const { realAuth, storage } = installRealAuth(pair);
    const { root, lifecycle } = mountLayout();
    await vi.advanceTimersByTimeAsync(0);
    expect(input(root)).toBeDefined();
    expect(vi.getTimerCount()).toBe(1);

    await vi.advanceTimersByTimeAsync(60_000);
    expectSignIn(root);
    expect(realAuth.isAuthenticated.value).toBe(false);
    expect(realAuth.user.value).toBeNull();
    expect(realAuth.userFetchError.value).toBe(false);
    expect(license.licenseStatus.value).toBeNull();
    expect(lifecycle).toEqual({ mounts: 1, unmounts: 1 });
    await vi.advanceTimersByTimeAsync(60_000);
    expectSignIn(root);
    expect(storage.getItem('accessToken')).toBe(pair.accessToken);
    expect(storage.getItem('refreshToken')).toBe(pair.refreshToken);
    expect(storage.setItem).not.toHaveBeenCalled();
    expect(storage.removeItem).not.toHaveBeenCalled();
    expect(storage.clear).not.toHaveBeenCalled();
    expect(fetchMock).not.toHaveBeenCalled();
  });

  it('waits non-destructively after storage.clear and a partial B pair, then bootstraps B without remounting', async () => {
    const browser = installRealAuth();
    const { realAuth, storage } = browser;
    const { root, lifecycle } = mountLayout();
    await vi.advanceTimersByTimeAsync(0);
    expect(input(root)).toBeDefined();
    browser.clear();
    await vi.advanceTimersByTimeAsync(0);
    expectSignIn(root);
    expect(storage.length).toBe(0);
    expect(license.licenseStatus.value).toBeNull();
    expect(realAuth.user.value).toBeNull();

    const pairB = credentials('B');
    browser.change('accessToken', pairB.accessToken);
    await vi.advanceTimersByTimeAsync(60_000);
    expectSignIn(root);
    expect(storage.length).toBe(1);
    expect(storage.getItem('accessToken')).toBe(pairB.accessToken);
    expect(storage.getItem('refreshToken')).toBeNull();
    expect(realAuth.userFetchError.value).toBe(false);

    const userB = {
      ...userA,
      userId: 'B',
      email: 'B@example.test',
      teams: ['Team B'],
    };
    const statusB = {
      ...cachedStatus,
      licenseId: 'license-b',
      customerName: 'Customer B',
    };
    const pendingUser = deferred<User>();
    const pendingStatus = deferred<LicenseStatus>();
    trpc.me.query
      .mockReturnValueOnce(pendingUser.promise)
      .mockResolvedValue(userB);
    trpc.license.status.query
      .mockReturnValueOnce(pendingStatus.promise)
      .mockResolvedValue(statusB);
    try {
      browser.change('refreshToken', pairB.refreshToken);
      await until(() => {
        expect(trpc.me.query).toHaveBeenCalledTimes(1);
        expect(trpc.license.status.query).toHaveBeenCalledTimes(1);
      });
      pendingStatus.resolve(statusB);
      await vi.advanceTimersByTimeAsync(0);
      expect(input(root)).toBeUndefined();
      expect(text(root)).not.toContain(userA.email);
      pendingUser.resolve(userB);
      await vi.advanceTimersByTimeAsync(0);
      expect(input(root)).toBeDefined();
      expect(text(root)).toContain(userB.email);
      expect(text(root)).not.toContain(userA.email);
      expect(text(root)).not.toContain('Sign In Required');
      expect(realAuth.user.value).toEqual(userB);
      expect(realAuth.isAuthenticated.value).toBe(true);
      expect(license.licenseStatus.value).toEqual(statusB);
      expect(lifecycle).toEqual({ mounts: 2, unmounts: 1 });
      expect(vi.getTimerCount()).toBe(1);
      await vi.advanceTimersByTimeAsync(60_000);
      expect(trpc.license.status.query).toHaveBeenCalledTimes(2);
      expect(trpc.me.query).toHaveBeenCalledTimes(1);
      expect(storage.getItem('accessToken')).toBe(pairB.accessToken);
      expect(storage.getItem('refreshToken')).toBe(pairB.refreshToken);
      expect(vi.mocked(storage.setItem).mock.calls).toEqual([
        ['accessToken', pairB.accessToken],
        ['refreshToken', pairB.refreshToken],
      ]);
      expect(storage.removeItem).not.toHaveBeenCalled();
      expect(storage.clear).toHaveBeenCalledTimes(1);
      expect(nuxtApp.navigateTo).not.toHaveBeenCalled();
      expect(router.replace).not.toHaveBeenCalled();
    } finally {
      pendingUser.resolve(userB);
      pendingStatus.resolve(statusB);
      await vi.advanceTimersByTimeAsync(0);
    }
  });
});

describe('default layout license status', () => {
  it('keeps automatic REVOKED polls status-only, including on mount', async () => {
    const revoked = {
      ...cachedStatus,
      status: 'REVOKED',
      hintStatus: 'REVOKED',
    } as LicenseStatus;
    license.licenseStatus.value = revoked;
    trpc.license.status.query.mockResolvedValue(revoked);
    const currentLicense = license.captureLicenseOperation();
    const { root, lifecycle } = mountLayout();
    await vi.advanceTimersByTimeAsync(0);
    expect(text(root)).toContain('Cloning Detected');
    expect(trpc.license.status.query).not.toHaveBeenCalled();

    await vi.advanceTimersByTimeAsync(120_000);
    expect(trpc.license.status.query).toHaveBeenCalledTimes(2);
    expect(license.licenseStatus.value).toEqual(revoked);
    expect(text(root)).toContain('Cloning Detected');
    expect(input(root)).toBeDefined();
    expect(lifecycle).toEqual({ mounts: 1, unmounts: 0 });
    expect(currentLicense()).toBe(true);
    expect(license.isLicenseSyncing.value).toBe(false);
    expect(vi.getTimerCount()).toBe(1);
    for (const mock of [
      trpc.license.sync.mutate,
      trpc.license.getDeploymentConfig.query,
      trpc.license.acquireCourierLock.mutate,
      trpc.license.prepareRelay.mutate,
      trpc.license.submitRelay.mutate,
      trpc.license.reportRevocation.mutate,
      trpc.license.releaseCourierLock.mutate,
      fetchMock,
      toast.add,
      auth.logout,
      router.replace,
      nuxtApp.navigateTo,
    ]) {
      expect(mock).not.toHaveBeenCalled();
    }
  });

  it.each([
    'me',
    'status',
  ])('offers Retry if a same-session token rotation cancels the initial %s read', async (source) => {
    license.clearLicense();
    auth.user.value = null;
    const query = source === 'me' ? trpc.me.query : trpc.license.status.query;
    query.mockRejectedValueOnce(new operation.CancelledOperationError());
    const { root, lifecycle } = mountLayout();
    await vi.advanceTimersByTimeAsync(0);
    expect(button(root, 'Retry')).toBeDefined();
    expect(input(root)).toBeUndefined();
    expect(auth.logout).not.toHaveBeenCalled();
    await click(root, 'Retry');
    await vi.advanceTimersByTimeAsync(0);
    expect(input(root)).toBeDefined();
    expect(button(root, 'Retry')).toBeUndefined();
    expect(lifecycle).toEqual({ mounts: 1, unmounts: 0 });
  });

  it.each([
    'Retry',
    'next poll',
  ] as const)('preserves the page and its draft through a failed background poll and %s recovery', async (recovery) => {
    const failed = deferred<LicenseStatus>();
    const refreshed = deferred<LicenseStatus>();
    trpc.license.status.query
      .mockReturnValueOnce(failed.promise)
      .mockReturnValueOnce(refreshed.promise);
    const { root, lifecycle } = mountLayout();
    await until(() => expect(vi.getTimerCount()).toBe(1));
    const originalInput = input(root)!;
    originalInput.props.onInput({ target: { value: 'Unsaved license draft' } });
    await until(() =>
      expect(input(root)?.props.value).toBe('Unsaved license draft'),
    );

    vi.advanceTimersByTime(60_000);
    await until(() =>
      expect(trpc.license.status.query).toHaveBeenCalledTimes(1),
    );
    failed.reject(new Error('Temporary status outage'));
    await until(() => {
      expect(license.licenseFetchError.value).toBe(true);
      expect(button(root, 'Retry')).toBeDefined();
    });
    expect
      .soft(
        nodes(root).includes(originalInput),
        'cached content must stay mounted',
      )
      .toBe(true);
    expect.soft(lifecycle).toEqual({ mounts: 1, unmounts: 0 });

    const retry = recovery === 'Retry' ? click(root, 'Retry') : undefined;
    if (recovery === 'next poll') vi.advanceTimersByTime(60_000);
    await until(() =>
      expect(trpc.license.status.query).toHaveBeenCalledTimes(2),
    );
    refreshed.resolve({ ...cachedStatus, customerName: 'Recovered customer' });
    await retry;
    await until(() => {
      expect(license.licenseFetchError.value).toBe(false);
      expect(license.licenseStatus.value?.customerName).toBe(
        'Recovered customer',
      );
      expect(button(root, 'Retry')).toBeUndefined();
    });
    expect
      .soft(
        nodes(root).includes(originalInput),
        'recovery must not replace the page',
      )
      .toBe(true);
    expect.soft(input(root)?.props.value).toBe('Unsaved license draft');
    expect.soft(lifecycle).toEqual({ mounts: 1, unmounts: 0 });
    expect(auth.logout).not.toHaveBeenCalled();
  });

  it('blocks a cold failed user fetch despite a provisioned license, then mounts only after Retry succeeds', async () => {
    license.clearLicense();
    auth.user.value = null;
    const initialStatus = deferred<LicenseStatus>();
    const initialUser = deferred<User>();
    const retryStatus = deferred<LicenseStatus>();
    const retryUser = deferred<User>();
    trpc.license.status.query
      .mockReturnValueOnce(initialStatus.promise)
      .mockReturnValueOnce(retryStatus.promise);
    trpc.me.query
      .mockReturnValueOnce(initialUser.promise)
      .mockReturnValueOnce(retryUser.promise);
    const { root, lifecycle } = mountLayout();
    expect(text(root)).toContain('Loading deployment status...');

    initialStatus.resolve(cachedStatus);
    await until(() =>
      expect(license.licenseStatus.value?.isProvisioned).toBe(true),
    );
    initialUser.reject(new Error('Temporary me outage'));
    await until(() => expect(button(root, 'Retry')).toBeDefined());
    expect(Boolean(input(root))).toBe(false);
    expect
      .soft(lifecycle, 'a license alone must not mount the protected page')
      .toEqual({ mounts: 0, unmounts: 0 });
    expect(auth.logout).not.toHaveBeenCalled();

    const retry = click(root, 'Retry');
    await until(() => {
      expect(trpc.me.query).toHaveBeenCalledTimes(2);
      expect(trpc.license.status.query).toHaveBeenCalledTimes(2);
    });
    expect
      .soft(Boolean(input(root)), 'Retry must still wait for the user')
      .toBe(false);
    retryStatus.resolve(cachedStatus);
    retryUser.resolve(admin);
    await retry;
    await until(() => expect(input(root)).toBeDefined());
    expect(button(root, 'Retry')).toBeUndefined();
    expect(text(root)).not.toContain('Loading deployment status...');
    expect.soft(lifecycle).toEqual({ mounts: 1, unmounts: 0 });
  });

  it.each([
    'initial user fetch',
    'background status poll',
  ] as const)('still logs out on an unauthorized %s', async (source) => {
    const error = Object.assign(new TRPCClientError('Session expired'), {
      data: { code: 'UNAUTHORIZED' },
    });
    if (source === 'initial user fetch') {
      auth.user.value = null;
      trpc.me.query.mockRejectedValueOnce(error);
    } else {
      trpc.license.status.query.mockRejectedValueOnce(error);
    }
    const { root } = mountLayout();
    if (source === 'background status poll') {
      await until(() => expect(vi.getTimerCount()).toBe(1));
      vi.advanceTimersByTime(60_000);
    }
    await until(() => {
      expect(auth.logout).toHaveBeenCalledTimes(1);
      expect(Boolean(input(root))).toBe(false);
    });
    expect(auth.accessToken.value).toBe('');
  });

  it.each([
    { path: '/services', isAdmin: true, destination: '/license' },
    { path: '/license', isAdmin: false, destination: '/services' },
  ])('waits for the user before guarding an unprovisioned $path route (admin: $isAdmin)', async ({
    path,
    isAdmin,
    destination,
  }) => {
    license.clearLicense();
    auth.user.value = null;
    route.path = path;
    const pendingUser = deferred<User>();
    trpc.me.query.mockReturnValueOnce(pendingUser.promise);
    trpc.license.status.query.mockResolvedValueOnce({
      ...cachedStatus,
      isProvisioned: false,
    });
    mountLayout();
    await until(() =>
      expect(license.licenseStatus.value?.isProvisioned).toBe(false),
    );
    expect(router.replace).not.toHaveBeenCalled();

    pendingUser.resolve({ ...admin, permissions: { isAdmin } });
    await until(() => expect(router.replace).toHaveBeenCalledWith(destination));
    expect(router.replace).toHaveBeenCalledTimes(1);
  });

  it('bootstraps session B while mounted after clearing A, but preserves A during ordinary token rotation', async () => {
    const pendingUser = deferred<User>();
    const pendingStatus = deferred<LicenseStatus>();
    const userB = { ...admin, email: 'session-b@example.test' };
    const statusB = { ...cachedStatus, licenseId: 'license-b' };
    const { root, lifecycle } = mountLayout();
    await until(() => expect(vi.getTimerCount()).toBe(1));
    const originalInput = input(root)!;
    originalInput.props.onInput({ target: { value: 'Session A draft' } });
    const version = auth.sessionVersion.value;
    auth.accessToken.value = 'rotated-access-token';
    await vi.advanceTimersByTimeAsync(0);
    expect(auth.sessionVersion.value).toBe(version);
    expect(input(root)).toBe(originalInput);
    expect(input(root)?.props.value).toBe('Session A draft');
    expect(trpc.me.query).not.toHaveBeenCalled();
    expect(trpc.license.status.query).not.toHaveBeenCalled();

    changeSession();
    await vi.advanceTimersByTimeAsync(0);
    expect(input(root)).toBeUndefined();
    expect(vi.getTimerCount()).toBe(0);
    expect(trpc.me.query).not.toHaveBeenCalled();
    expect(trpc.license.status.query).not.toHaveBeenCalled();

    trpc.me.query.mockReturnValueOnce(pendingUser.promise);
    trpc.license.status.query.mockReturnValueOnce(pendingStatus.promise);
    try {
      changeSession('session-b-token');
      await until(() => {
        expect(trpc.me.query).toHaveBeenCalledTimes(1);
        expect(trpc.license.status.query).toHaveBeenCalledTimes(1);
      });
      pendingStatus.resolve(statusB);
      await vi.advanceTimersByTimeAsync(0);
      expect(input(root)).toBeUndefined();
      pendingUser.resolve(userB);
      await until(() => expect(input(root)).toBeDefined());
      expect(text(root)).toContain(userB.email);
      expect(license.licenseStatus.value).toEqual(statusB);
      expect(lifecycle).toEqual({ mounts: 2, unmounts: 1 });
      expect(vi.getTimerCount()).toBe(1);
      expect(auth.logout).not.toHaveBeenCalled();
    } finally {
      pendingUser.resolve(userB);
      pendingStatus.resolve(statusB);
      await vi.advanceTimersByTimeAsync(0);
    }
  });

  it.each(
    ['pending Update JWT', 'applied Update JWT', 'invalidation'].flatMap(
      (change) =>
        ['COURIER_REQUIRED', 'UNAUTHORIZED', 'outage'].map((result) => ({
          change,
          result,
        })),
    ),
  )('ignores an obsolete real timer result ($result) after replacement $change', async ({
    change,
    result,
  }) => {
    const stale = deferred<LicenseStatus>();
    const mutation = deferred<{ success: boolean }>();
    const updatedStatus = {
      ...cachedStatus,
      licenseId: 'replacement-license',
      maxAgents: 42,
    };
    const courierStatus = {
      ...cachedStatus,
      hintStatus: 'COURIER_REQUIRED',
    } as LicenseStatus;
    const query = trpc.license.status.query;
    trpc.license.provision.mutate.mockReturnValueOnce(mutation.promise);
    trpc.license.getDeploymentConfig.query.mockResolvedValue({
      licenseId: updatedStatus.licenseId,
      jwt: 'replacement-jwt',
      nextToken: null,
    });
    trpc.license.sync.mutate.mockResolvedValue({ requiresCourier: true });
    trpc.license.submitRelay.mutate.mockResolvedValue({ success: true });
    fetchMock.mockImplementation(
      async (url) =>
        new Response(
          JSON.stringify(
            url === publicKeyUrl
              ? 'test-public-key'
              : { jwt: 'relay-jwt', nextToken: 'relay-token' },
          ),
        ),
    );
    route.path = '/license';
    mountLayout();
    await until(() => expect(vi.getTimerCount()).toBe(1));
    const root = mountSfc('../app/pages/license/index.vue');
    await vi.advanceTimersByTimeAsync(0);
    expect(query).toHaveBeenCalledTimes(1);
    query.mockReturnValueOnce(stale.promise).mockResolvedValue(updatedStatus);
    vi.advanceTimersByTime(60_000);
    await until(() => expect(query).toHaveBeenCalledTimes(2));
    expect(license.isLicenseSyncing.value).toBe(false);
    expect(license.isLicenseUpdating.value).toBe(false);

    let update: Promise<unknown> | undefined;
    try {
      if (change === 'invalidation') {
        license.invalidateLicenseStatus();
        await license.fetchLicenseStatus(true);
      } else {
        click(root, 'Update JWT');
        await enterJwt(root);
        update = click(root, 'Update License');
        await until(() =>
          expect(trpc.license.provision.mutate).toHaveBeenCalledTimes(1),
        );
        if (change === 'applied Update JWT') {
          mutation.resolve({ success: true });
          await update;
        }
      }

      const reads = query.mock.calls.length;
      if (result === 'COURIER_REQUIRED') stale.resolve(courierStatus);
      else
        stale.reject(
          result === 'UNAUTHORIZED'
            ? Object.assign(new TRPCClientError('Old session expired'), {
                data: { code: 'UNAUTHORIZED' },
              })
            : new Error('Obsolete status outage'),
        );
      await vi.advanceTimersByTimeAsync(0);
      expect
        .soft(query, 'obsolete polls must not refresh after courier work')
        .toHaveBeenCalledTimes(reads);
      expect.soft(license.licenseFetchError.value).toBe(false);

      if (change === 'pending Update JWT') {
        // Neither a new timer tick nor an available Sync control may start work.
        const syncButton = button(root, 'Sync License');
        if (syncButton && !syncButton.props.disabled) {
          await click(root, 'Sync License');
        }
        query.mockResolvedValue(courierStatus);
        vi.advanceTimersByTime(60_000);
        await vi.advanceTimersByTimeAsync(0);
        query.mockResolvedValue(updatedStatus);
      }
      for (const [name, mock] of Object.entries({
        acquisition: trpc.license.acquireCourierLock.mutate,
        config: trpc.license.getDeploymentConfig.query,
        sync: trpc.license.sync.mutate,
        preparation: trpc.license.prepareRelay.mutate,
        relay: trpc.license.submitRelay.mutate,
        revocation: trpc.license.reportRevocation.mutate,
        release: trpc.license.releaseCourierLock.mutate,
        logout: auth.logout,
      })) {
        expect
          .soft(mock, `obsolete status must not cause ${name}`)
          .not.toHaveBeenCalled();
      }
      expect
        .soft(fetchMock.mock.calls.filter(([url]) => url !== publicKeyUrl))
        .toEqual([]);
      expect.soft(license.licenseFetchError.value).toBe(false);
      mutation.resolve({ success: true });
      await update;
      expect(license.licenseStatus.value).toEqual(updatedStatus);
      expect(text(root)).toContain('Current Entitlements');
    } finally {
      mutation.resolve({ success: true });
      stale.resolve(courierStatus);
      await update;
      await vi.advanceTimersByTimeAsync(0);
    }
  });

  it.each([
    { phase: 0, httpStatus: 200 },
    { phase: 2, httpStatus: 200 },
    { phase: 0, httpStatus: 401 },
    { phase: 0, httpStatus: 403 },
    { phase: 1, httpStatus: 401 },
    { phase: 1, httpStatus: 403 },
    { phase: 2, httpStatus: 401 },
    { phase: 2, httpStatus: 403 },
  ])('refreshes after automatic Courier phase $phase (HTTP $httpStatus) without reusing a pending read', async ({
    phase,
    httpStatus,
  }) => {
    const revoked = httpStatus !== 200;
    const stale = deferred<LicenseStatus>();
    const fresh = deferred<LicenseStatus>();
    const mutation = deferred<{ success: boolean }>();
    const courierStatus = {
      ...cachedStatus,
      hintStatus: 'COURIER_REQUIRED',
    } as LicenseStatus;
    const freshStatus = {
      ...cachedStatus,
      status: revoked ? 'REVOKED' : 'SYNCED',
      hintStatus: revoked ? 'REVOKED' : 'SYNCED',
      maxAgents: 42,
      upgradeRequired: true,
    } as LicenseStatus;
    const banner = revoked ? 'Cloning Detected' : 'Upgrade Required';
    const query = trpc.license.status.query;
    query
      .mockResolvedValueOnce(courierStatus)
      .mockReturnValueOnce(stale.promise)
      .mockReturnValueOnce(fresh.promise);
    const mutationMock = revoked
      ? trpc.license.reportRevocation.mutate
      : trpc.license.submitRelay.mutate;
    mutationMock.mockReturnValueOnce(mutation.promise);
    trpc.license.getDeploymentConfig.query.mockResolvedValue({
      licenseId: cachedStatus.licenseId,
      jwt: 'current-jwt',
      nextToken: phase === 0 ? null : 'current-token',
    });
    const relayBody = JSON.stringify({
      jwt: 'renewed-jwt',
      nextToken: 'renewed-token',
    });
    fetchMock.mockImplementation(async () => new Response(relayBody));
    if (revoked) {
      if (phase === 2) fetchMock.mockResolvedValueOnce(new Response(relayBody));
      fetchMock.mockResolvedValueOnce(
        new Response(null, { status: httpStatus }),
      );
    }

    let oldPoll: Promise<PromiseSettledResult<LicenseStatus>[]> | undefined;
    try {
      const { root } = mountLayout();
      await until(() => expect(vi.getTimerCount()).toBe(1));
      vi.advanceTimersByTime(60_000);
      await until(() => expect(mutationMock).toHaveBeenCalledTimes(1));
      expect(fetchMock).toHaveBeenCalledTimes(phase === 2 ? 2 : 1);
      expect(trpc.license.prepareRelay.mutate).toHaveBeenCalledTimes(
        phase === 2 ? 1 : 0,
      );
      if (!revoked) {
        expect(mutationMock.mock.calls[0]![0]).toStrictEqual({
          jwt: 'renewed-jwt',
          nextToken: 'renewed-token',
          ...(phase === 2
            ? { preparedFrom: 'current-jwt' }
            : { initialFrom: 'current-jwt' }),
          publicKey: undefined,
        });
      }

      oldPoll = Promise.allSettled([license.fetchLicenseStatus(true)]);
      expect(query).toHaveBeenCalledTimes(2);
      mutation.resolve({ success: true });
      await until(() =>
        expect(
          query,
          'automatic Courier refresh must not join the pre-mutation read',
        ).toHaveBeenCalledTimes(3),
      );

      fresh.resolve(freshStatus);
      await until(() => {
        expect(license.licenseStatus.value).toEqual(freshStatus);
        expect(text(root)).toContain(banner);
        expect(trpc.license.releaseCourierLock.mutate).toHaveBeenCalledTimes(1);
      });
      stale.resolve(courierStatus);
      expect(await oldPoll).toEqual([
        {
          status: 'rejected',
          reason: expect.any(operation.CancelledOperationError),
        },
      ]);
      await Vue.nextTick();
      expect(license.licenseStatus.value).toEqual(freshStatus);
      expect(text(root)).toContain(banner);
      expect(auth.logout).not.toHaveBeenCalled();
    } finally {
      mutation.resolve({ success: true });
      fresh.resolve(freshStatus);
      stale.resolve(courierStatus);
      await oldPoll;
      if (trpc.license.acquireCourierLock.mutate.mock.calls.length) {
        await until(() =>
          expect(trpc.license.releaseCourierLock.mutate).toHaveBeenCalledTimes(
            1,
          ),
        );
      }
    }
  });
});

describe.each([
  'automatic',
  'manual',
] as const)('%s courier continuations', (mode) => {
  it.each(
    [undefined, 0, 41].flatMap((syncStatusIndex) =>
      [false, true].map((publicKeyRetry) => ({
        syncStatusIndex,
        publicKeyRetry,
      })),
    ),
  )('completes both phases with deployment tuple B despite cached license A (index: $syncStatusIndex, key retry: $publicKeyRetry)', async ({
    syncStatusIndex,
    publicKeyRetry,
  }) => {
    const precondition =
      syncStatusIndex === undefined ? {} : { syncStatusIndex };
    const config = Object.freeze({
      licenseId: 'license-b',
      jwt: 'durable-jwt-b',
      nextToken: 'durable-token-b',
      ...precondition,
    });
    const refreshed = { ...cachedStatus, licenseId: config.licenseId };
    trpc.license.sync.mutate.mockResolvedValue({ requiresCourier: true });
    trpc.license.getDeploymentConfig.query.mockResolvedValue(config);
    trpc.license.submitRelay.mutate.mockResolvedValue({ success: true });
    if (publicKeyRetry) {
      trpc.license.submitRelay.mutate.mockRejectedValueOnce(
        new Error('No public key available for verification'),
      );
    }
    fetchMock.mockImplementation(async (url, init) => {
      if (url === publicKeyUrl) return Response.json('rotated-public-key');
      expect(url).toBe(`${licensingUrl}/api/heartbeat`);
      const body = JSON.parse(init.body);
      if (body.licenseId !== config.licenseId || body.jwt !== config.jwt) {
        return Response.json({ error: 'LicenseMismatch' }, { status: 403 });
      }
      if (body.phase === 1)
        return Response.json({ nextToken: 'prepared-token-b' });
      if (body.phase === 2) return Response.json({ jwt: 'renewed-jwt-b' });
      throw new Error('Unexpected heartbeat phase');
    });

    const root =
      mode === 'automatic'
        ? mountLayout().root
        : mountSfc('../app/pages/license/index.vue');
    await vi.advanceTimersByTimeAsync(0);
    expect(license.licenseStatus.value?.licenseId).toBe(cachedStatus.licenseId);
    trpc.license.status.query.mockResolvedValue(refreshed);
    if (mode === 'automatic') {
      trpc.license.status.query.mockResolvedValueOnce({
        ...cachedStatus,
        hintStatus: 'COURIER_REQUIRED',
      });
      await vi.advanceTimersByTimeAsync(60_000);
    } else {
      await click(root, 'Sync License');
    }
    await vi.advanceTimersByTimeAsync(0);

    expect(fetchMock).toHaveBeenCalledTimes(publicKeyRetry ? 3 : 2);
    expect(
      fetchMock.mock.calls
        .filter(([url]) => url !== publicKeyUrl)
        .map(([, init]) => JSON.parse(init.body)),
    ).toStrictEqual([
      {
        phase: 1,
        licenseId: config.licenseId,
        jwt: config.jwt,
        nextToken: config.nextToken,
      },
      {
        phase: 2,
        licenseId: config.licenseId,
        jwt: config.jwt,
        nextToken: 'prepared-token-b',
      },
    ]);
    expect(trpc.license.prepareRelay.mutate.mock.calls).toStrictEqual([
      [
        {
          jwt: config.jwt,
          previousNextToken: config.nextToken,
          nextToken: 'prepared-token-b',
          ...precondition,
        },
      ],
    ]);
    expect(trpc.license.submitRelay.mutate.mock.calls).toStrictEqual(
      (publicKeyRetry ? [undefined, 'rotated-public-key'] : [undefined]).map(
        (publicKey) => [
          {
            jwt: 'renewed-jwt-b',
            nextToken: 'prepared-token-b',
            preparedFrom: config.jwt,
            publicKey,
            ...precondition,
          },
        ],
      ),
    );
    expect(trpc.license.getDeploymentConfig.query).toHaveBeenCalledTimes(1);
    expect(trpc.license.acquireCourierLock.mutate).toHaveBeenCalledTimes(1);
    expect(trpc.license.releaseCourierLock.mutate).toHaveBeenCalledTimes(1);
    expect(
      trpc.license.releaseCourierLock.mutate.mock.calls[0]![1].context
        .courierLease,
    ).toBe(
      trpc.license.acquireCourierLock.mutate.mock.calls[0]![1].context
        .courierLease,
    );
    expect(trpc.license.reportRevocation.mutate).not.toHaveBeenCalled();
    expect(license.licenseStatus.value).toEqual(refreshed);
    expect(license.licenseFetchError.value).toBe(false);
    expect(vi.getTimerCount()).toBe(mode === 'automatic' ? 1 : 0);
    if (mode === 'manual')
      expect(button(root, 'Sync License')?.props.disabled).toBe(false);
    expect(auth.logout).not.toHaveBeenCalled();
  });

  it.each([
    'licenseId',
    'jwt',
  ] as const)('fails closed on missing %s and keeps status retries read-only', async (missing) => {
    const config =
      missing === 'licenseId'
        ? { jwt: 'durable-jwt-b', nextToken: 'durable-token-b' }
        : { licenseId: 'license-b', nextToken: 'durable-token-b' };
    const message =
      'Deployment configuration is incomplete. Retry loading status.';
    const currentLicense = license.captureLicenseOperation();
    const query = trpc.license.status.query;
    trpc.license.sync.mutate.mockResolvedValue({ requiresCourier: true });
    trpc.license.getDeploymentConfig.query.mockResolvedValue(config);
    const root =
      mode === 'automatic'
        ? mountLayout().root
        : mountSfc('../app/pages/license/index.vue');
    await vi.advanceTimersByTimeAsync(0);
    if (mode === 'automatic') {
      query.mockResolvedValueOnce({
        ...cachedStatus,
        hintStatus: 'COURIER_REQUIRED',
      });
    }
    query.mockRejectedValueOnce(new Error('Status temporarily unavailable'));
    if (mode === 'automatic') await vi.advanceTimersByTimeAsync(60_000);
    else await click(root, 'Sync License');
    await vi.advanceTimersByTimeAsync(0);

    expect(console.error).toHaveBeenCalledWith(
      'Courier relay failed',
      new Error(message),
    );
    expect(trpc.license.releaseCourierLock.mutate).toHaveBeenCalledTimes(1);
    expect(
      trpc.license.releaseCourierLock.mutate.mock.calls[0]![1].context
        .courierLease,
    ).toBe(
      trpc.license.acquireCourierLock.mutate.mock.calls[0]![1].context
        .courierLease,
    );
    expect(license.licenseStatus.value?.licenseId).toBe(cachedStatus.licenseId);
    expect(currentLicense()).toBe(true);
    expect(vi.getTimerCount()).toBe(mode === 'automatic' ? 1 : 0);
    if (mode === 'manual') {
      expect(toast.add).toHaveBeenCalledWith({
        title: 'Courier Failed',
        description: message,
        color: 'red',
      });
      expect(button(root, 'Sync License')?.props.disabled).toBe(false);
    } else {
      await vi.advanceTimersByTimeAsync(60_000);
    }

    expect(license.licenseFetchError.value).toBe(true);
    const retryLabel = mode === 'automatic' ? 'Retry' : 'Retry Status';
    const reads = [trpc.me.query.mock.calls.length, query.mock.calls.length];
    await click(root, retryLabel);
    await vi.advanceTimersByTimeAsync(0);
    expect([trpc.me.query.mock.calls.length, query.mock.calls.length]).toEqual(
      reads.map((count) => count + 1),
    );
    expect(button(root, retryLabel)).toBeUndefined();
    expect(license.licenseStatus.value).toEqual(cachedStatus);
    expect(license.licenseFetchError.value).toBe(false);
    expect(currentLicense()).toBe(true);
    expect(trpc.license.sync.mutate).toHaveBeenCalledTimes(
      mode === 'manual' ? 1 : 0,
    );
    expect(trpc.license.acquireCourierLock.mutate).toHaveBeenCalledTimes(1);
    expect(trpc.license.getDeploymentConfig.query).toHaveBeenCalledTimes(1);
    expect(trpc.license.releaseCourierLock.mutate).toHaveBeenCalledTimes(1);
    expect(fetchMock).not.toHaveBeenCalled();
    expect(trpc.license.prepareRelay.mutate).not.toHaveBeenCalled();
    expect(trpc.license.submitRelay.mutate).not.toHaveBeenCalled();
    expect(trpc.license.reportRevocation.mutate).not.toHaveBeenCalled();
    expect(trpc.license.provision.mutate).not.toHaveBeenCalled();
    expect(
      toast.add.mock.calls.filter(([notice]) =>
        ['green', 'success'].includes(notice.color),
      ),
    ).toEqual([]);
    expect(auth.logout).not.toHaveBeenCalled();
  });

  it('persists Phase 0 through remount and access rotation before releasing the original lease', async () => {
    const config = Object.freeze({
      licenseId: 'deployment-license-b',
      jwt: 'exact-initial-jwt-b',
      nextToken: null,
      syncStatusIndex: 41,
    });
    const relay = {
      jwt: 'initialized-jwt-b',
      nextToken: 'initialized-token-b',
    };
    const courierStatus = {
      ...cachedStatus,
      hintStatus: 'COURIER_REQUIRED',
    } as LicenseStatus;
    const refreshed = {
      ...cachedStatus,
      licenseId: config.licenseId,
      customerName: 'Initialized customer',
      maxAgents: 42,
      upgradeRequired: true,
    };
    const heartbeat = deferred<Response>();
    const body = deferred<typeof relay>();
    const key = deferred<Response>();
    const keyBody = deferred<string>();
    const persistence = deferred<{ success: true }>();
    const refresh = deferred<LicenseStatus>();
    const release = deferred<{ success: true }>();
    const response = Response.json(relay);
    const readBody = vi.spyOn(response, 'json').mockReturnValue(body.promise);
    const keyResponse = Response.json('rotated-public-key');
    const readKey = vi
      .spyOn(keyResponse, 'json')
      .mockReturnValue(keyBody.promise);
    let persisted = false;
    let heldLease: object | undefined;
    const query = trpc.license.status.query;
    query.mockImplementation(() =>
      persisted ? refresh.promise : Promise.resolve(courierStatus),
    );
    license.licenseStatus.value = courierStatus;
    trpc.license.sync.mutate.mockResolvedValue({ requiresCourier: true });
    trpc.license.getDeploymentConfig.query.mockResolvedValue(config);
    trpc.license.acquireCourierLock.mutate.mockImplementation(
      async (_, { context }) => {
        if (heldLease) return { success: false };
        heldLease = context.courierLease;
        return { success: true };
      },
    );
    trpc.license.releaseCourierLock.mutate.mockImplementation(
      async (_, { context }) => {
        const result = await release.promise;
        if (heldLease === context.courierLease) heldLease = undefined;
        return result;
      },
    );
    trpc.license.submitRelay.mutate
      .mockRejectedValueOnce(
        new Error('No public key available for verification'),
      )
      .mockImplementation(async () => {
        const result = await persistence.promise;
        persisted = true;
        return result;
      });
    fetchMock
      .mockReturnValueOnce(heartbeat.promise)
      .mockReturnValueOnce(key.promise);

    let action: Promise<unknown> | undefined;
    try {
      const root =
        mode === 'automatic'
          ? mountLayout().root
          : mountSfc('../app/pages/license/index.vue');
      await vi.advanceTimersByTimeAsync(0);
      if (mode === 'manual') action = click(root, 'Sync License');
      await until(() => expect(fetchMock).toHaveBeenCalledTimes(1));
      expect(fetchMock.mock.calls[0]![0]).toBe(`${licensingUrl}/api/heartbeat`);
      expect(JSON.parse(fetchMock.mock.calls[0]![1].body)).toStrictEqual({
        licenseId: config.licenseId,
        jwt: config.jwt,
        nextToken: null,
      });
      expect(license.licenseStatus.value?.licenseId).toBe(
        cachedStatus.licenseId,
      );
      const signal = fetchMock.mock.calls[0]![1].signal as AbortSignal;
      const originalLease =
        trpc.license.acquireCourierLock.mutate.mock.calls[0]![1].context
          .courierLease;
      const currentSession = auth.captureSession();
      const currentLicense = license.captureLicenseOperation();
      const version = auth.sessionVersion.value;
      apps.pop()!.unmount();
      expect(root.children).toEqual([]);
      expect(signal).toBeInstanceOf(AbortSignal);
      expect(signal.aborted).toBe(false);
      auth.accessToken.value = 'rotated-access-token';
      await vi.advanceTimersByTimeAsync(0);
      expect(auth.sessionVersion.value).toBe(version);
      expect(currentSession()).toBe(true);
      expect(currentLicense()).toBe(true);

      const remounted =
        mode === 'automatic'
          ? mountLayout().root
          : mountSfc('../app/pages/license/index.vue');
      await vi.advanceTimersByTimeAsync(0);
      expect(license.isLicenseSyncing.value).toBe(true);
      expect(license.beginLicenseUpdate()).toBeUndefined();
      if (mode === 'manual') {
        const sync = button(remounted, 'Sync License')!;
        expect(sync.props.disabled).toBe(true);
        await sync.props.onClick();
        expect(trpc.license.sync.mutate).toHaveBeenCalledTimes(1);
      }
      expect(trpc.license.acquireCourierLock.mutate).toHaveBeenCalledTimes(1);
      expect(heldLease).toBe(originalLease);
      expect(trpc.license.getDeploymentConfig.query).toHaveBeenCalledTimes(1);
      expect(fetchMock).toHaveBeenCalledTimes(1);
      expect(trpc.license.releaseCourierLock.mutate).not.toHaveBeenCalled();
      expect(signal.aborted).toBe(false);
      const uiEffects = [
        auth.fetchUser,
        trpc.me.query,
        toast.add,
        auth.logout,
        router.replace,
        nuxtApp.navigateTo,
      ];
      const uiCalls = uiEffects.map((mock) => mock.mock.calls.length);
      const reads = query.mock.calls.length;

      heartbeat.resolve(response);
      await until(() => expect(readBody).toHaveBeenCalledTimes(1));
      expect(trpc.license.submitRelay.mutate).not.toHaveBeenCalled();
      body.resolve(relay);
      await until(() => expect(fetchMock).toHaveBeenCalledTimes(2));
      expect(fetchMock.mock.calls[1]![0]).toBe(publicKeyUrl);
      const keySignal = fetchMock.mock.calls[1]![1].signal as AbortSignal;
      expect(keySignal).toBeInstanceOf(AbortSignal);
      expect(keySignal.aborted).toBe(false);
      key.resolve(keyResponse);
      await until(() => expect(readKey).toHaveBeenCalledTimes(1));
      expect(trpc.license.submitRelay.mutate).toHaveBeenCalledTimes(1);
      keyBody.resolve('rotated-public-key');
      await until(() =>
        expect(trpc.license.submitRelay.mutate).toHaveBeenCalledTimes(2),
      );
      await vi.advanceTimersByTimeAsync(0);
      expect(trpc.license.submitRelay.mutate.mock.calls).toStrictEqual(
        [undefined, 'rotated-public-key'].map((publicKey) => [
          { ...relay, initialFrom: config.jwt, publicKey },
        ]),
      );
      expect(persisted).toBe(false);
      expect(query).toHaveBeenCalledTimes(reads);
      expect(trpc.license.releaseCourierLock.mutate).not.toHaveBeenCalled();
      expect(currentLicense()).toBe(true);

      persistence.resolve({ success: true });
      if (mode === 'automatic') {
        await until(() => expect(query).toHaveBeenCalledTimes(reads + 1));
        expect(trpc.license.releaseCourierLock.mutate).not.toHaveBeenCalled();
        expect(license.licenseStatus.value).toEqual(courierStatus);
        refresh.resolve(refreshed);
      }
      await until(() =>
        expect(trpc.license.releaseCourierLock.mutate).toHaveBeenCalledTimes(1),
      );
      expect(persisted).toBe(true);
      expect(license.isLicenseSyncing.value).toBe(true);
      expect(heldLease).toBe(originalLease);
      expect(
        trpc.license.releaseCourierLock.mutate.mock.calls[0]![1].context
          .courierLease,
      ).toBe(originalLease);
      if (mode === 'manual') {
        expect(query).toHaveBeenCalledTimes(reads);
        expect(license.licenseStatus.value).toEqual(courierStatus);
      } else {
        expect(license.licenseStatus.value).toEqual(refreshed);
        expect(text(remounted)).toContain('Upgrade Required');
      }
      release.resolve({ success: true });
      await until(() => expect(query).toHaveBeenCalledTimes(reads + 1));
      if (mode === 'manual') refresh.resolve(refreshed);
      await action;
      await vi.advanceTimersByTimeAsync(0);

      expect(license.licenseStatus.value).toEqual(refreshed);
      expect(license.licenseFetchError.value).toBe(false);
      expect(text(remounted)).toContain(
        mode === 'automatic' ? 'Upgrade Required' : refreshed.customerName,
      );
      if (mode === 'manual') {
        expect(button(remounted, 'Sync License')?.props.disabled).toBe(false);
      }
      expect(query.mock.calls.slice(reads)).toStrictEqual([[]]);
      expect(uiEffects.map((mock) => mock.mock.calls.length)).toEqual(uiCalls);
      expect(currentSession()).toBe(true);
      expect(currentLicense()).toBe(false);
      expect(heldLease).toBeUndefined();
      expect(license.isLicenseSyncing.value).toBe(false);
      expect(trpc.license.releaseCourierLock.mutate).toHaveBeenCalledTimes(1);
      expect(trpc.license.getDeploymentConfig.query).toHaveBeenCalledTimes(1);
      expect(fetchMock).toHaveBeenCalledTimes(2);
      expect(trpc.license.prepareRelay.mutate).not.toHaveBeenCalled();
      expect(trpc.license.reportRevocation.mutate).not.toHaveBeenCalled();
      expect(trpc.license.provision.mutate).not.toHaveBeenCalled();
      expect(signal.aborted).toBe(false);
      expect(keySignal.aborted).toBe(false);
    } finally {
      heartbeat.resolve(response);
      body.resolve(relay);
      key.resolve(keyResponse);
      keyBody.resolve('rotated-public-key');
      persistence.resolve({ success: true });
      refresh.resolve(refreshed);
      release.resolve({ success: true });
      await action;
      await vi.advanceTimersByTimeAsync(0);
    }
  });

  it.each(
    [
      { wait: 'acquired lock', phase: 0, httpStatus: 200 },
      { wait: 'denied lock', phase: 0, httpStatus: 200 },
      { wait: 'lock error', phase: 0, httpStatus: 200 },
      { wait: 'deployment config', phase: 0, httpStatus: 200 },
      { wait: 'config error', phase: 0, httpStatus: 200 },
      ...[0, 1, 2].flatMap((phase) =>
        [200, 401, 403].map((httpStatus) => ({
          wait: 'heartbeat',
          phase,
          httpStatus,
        })),
      ),
      ...[0, 1, 2].map((phase) => ({
        wait: 'heartbeat body',
        phase,
        httpStatus: 200,
      })),
      { wait: 'rotation rejection', phase: 0, httpStatus: 200 },
      { wait: 'rotation fetch', phase: 0, httpStatus: 200 },
      { wait: 'rotation body', phase: 0, httpStatus: 200 },
      { wait: 'relay submission', phase: 0, httpStatus: 200 },
      { wait: 'revocation submission', phase: 0, httpStatus: 403 },
    ]
      .flatMap((row) =>
        ['license invalidation', 'session change', 'unmount'].map((change) => ({
          ...row,
          change,
        })),
      )
      .concat([
        {
          wait: 'heartbeat',
          phase: 0,
          httpStatus: 200,
          change: 'session change after unmount',
        },
        {
          wait: 'rotation body',
          phase: 0,
          httpStatus: 200,
          change: 'external license replacement after unmount',
        },
        {
          wait: 'relay submission',
          phase: 0,
          httpStatus: 200,
          change: 'session change after unmount',
        },
        {
          wait: mode === 'automatic' ? 'status refresh' : 'lease release',
          phase: 0,
          httpStatus: 200,
          change: 'external license replacement after unmount',
        },
      ]),
  )('respects ownership after $change during $wait, phase $phase HTTP $httpStatus', async ({
    wait,
    phase,
    httpStatus,
    change,
  }) => {
    const continuesInitial =
      change === 'unmount' &&
      phase === 0 &&
      httpStatus === 200 &&
      [
        'heartbeat',
        'heartbeat body',
        'rotation rejection',
        'rotation fetch',
        'rotation body',
        'relay submission',
      ].includes(wait);
    const pending = deferred<unknown>();
    const relay = { jwt: 'renewed-jwt', nextToken: 'renewed-token' };
    const config = {
      licenseId: cachedStatus.licenseId,
      jwt: 'operation-jwt',
      nextToken: phase === 0 ? null : 'operation-token',
    };
    const unauthorized = Object.assign(
      new TRPCClientError('Obsolete session'),
      {
        data: { code: 'UNAUTHORIZED' },
      },
    );
    const keyError = new Error('Invalid, forged, or expired license token');
    let value: unknown = { success: true };
    let rejection: Error | undefined;
    let reached = () =>
      expect(trpc.license.acquireCourierLock.mutate).toHaveBeenCalledTimes(1);
    trpc.license.sync.mutate.mockResolvedValue({ requiresCourier: true });
    trpc.license.getDeploymentConfig.query.mockResolvedValue(config);
    trpc.license.submitRelay.mutate.mockResolvedValue({ success: true });
    trpc.license.reportRevocation.mutate.mockResolvedValue({ success: true });
    fetchMock.mockImplementation(async (url) =>
      Response.json(url === publicKeyUrl ? 'rotated-public-key' : relay),
    );

    if (wait.includes('lock')) {
      trpc.license.acquireCourierLock.mutate.mockReturnValueOnce(
        pending.promise,
      );
      value = { success: wait !== 'denied lock' };
      if (wait === 'lock error') rejection = unauthorized;
    } else if (wait.includes('config')) {
      trpc.license.getDeploymentConfig.query.mockReturnValueOnce(
        pending.promise,
      );
      reached = () =>
        expect(trpc.license.getDeploymentConfig.query).toHaveBeenCalledTimes(1);
      value = config;
      if (wait === 'config error') rejection = unauthorized;
    } else if (wait.startsWith('heartbeat')) {
      if (phase === 2) {
        fetchMock.mockResolvedValueOnce(new Response(JSON.stringify(relay)));
      }
      if (wait === 'heartbeat body') {
        const response = new Response(JSON.stringify(relay));
        const json = vi
          .spyOn(response, 'json')
          .mockReturnValue(pending.promise);
        fetchMock.mockResolvedValueOnce(response);
        reached = () => expect(json).toHaveBeenCalledTimes(1);
        value = relay;
      } else {
        fetchMock.mockReturnValueOnce(pending.promise);
        reached = () =>
          expect(fetchMock).toHaveBeenCalledTimes(phase === 2 ? 2 : 1);
        value = new Response(
          httpStatus === 200 ? JSON.stringify(relay) : null,
          { status: httpStatus },
        );
      }
    } else if (wait === 'rotation rejection' || wait === 'relay submission') {
      trpc.license.submitRelay.mutate.mockReturnValueOnce(pending.promise);
      reached = () =>
        expect(trpc.license.submitRelay.mutate).toHaveBeenCalledTimes(1);
      if (wait === 'rotation rejection') rejection = keyError;
    } else if (wait === 'revocation submission') {
      fetchMock.mockResolvedValueOnce(
        new Response(null, { status: httpStatus }),
      );
      trpc.license.reportRevocation.mutate.mockReturnValueOnce(pending.promise);
      reached = () =>
        expect(trpc.license.reportRevocation.mutate).toHaveBeenCalledTimes(1);
    } else if (wait === 'status refresh') {
      trpc.license.status.query.mockReturnValue(pending.promise);
      reached = () =>
        expect(trpc.license.status.query).toHaveBeenCalledTimes(2);
      value = cachedStatus;
    } else if (wait === 'lease release') {
      trpc.license.releaseCourierLock.mutate.mockReturnValueOnce(
        pending.promise,
      );
      reached = () =>
        expect(trpc.license.releaseCourierLock.mutate).toHaveBeenCalledTimes(1);
    } else {
      trpc.license.submitRelay.mutate.mockRejectedValueOnce(keyError);
      const response = new Response(JSON.stringify('rotated-public-key'));
      if (wait === 'rotation body') {
        const json = vi
          .spyOn(response, 'json')
          .mockReturnValue(pending.promise);
        reached = () => expect(json).toHaveBeenCalledTimes(1);
        value = 'rotated-public-key';
      } else {
        reached = () => expect(fetchMock).toHaveBeenCalledTimes(2);
        value = response;
      }
      fetchMock.mockImplementation(async (url) => {
        if (url === publicKeyUrl) {
          return wait === 'rotation body' ? response : pending.promise;
        }
        return new Response(JSON.stringify(relay));
      });
    }

    let action: Promise<unknown> | undefined;
    try {
      if (mode === 'automatic') {
        mountLayout();
        await until(() => expect(vi.getTimerCount()).toBe(1));
        trpc.license.status.query.mockResolvedValueOnce({
          ...cachedStatus,
          hintStatus: 'COURIER_REQUIRED',
        });
        vi.advanceTimersByTime(60_000);
      } else {
        const root = mountSfc('../app/pages/license/index.vue');
        await vi.advanceTimersByTimeAsync(0);
        action = click(root, 'Sync License');
      }
      await until(reached);
      expect(trpc.license.releaseCourierLock.mutate).toHaveBeenCalledTimes(
        wait === 'lease release' ? 1 : 0,
      );
      if (change.includes('unmount')) {
        apps.pop()!.unmount();
        if (phase === 0 && httpStatus === 200) {
          for (const [, init] of fetchMock.mock.calls) {
            expect(init.signal.aborted).toBe(false);
          }
        }
      }
      if (change.startsWith('session change')) {
        const userB = {
          ...admin,
          email: 'session-b@example.test',
        };
        const statusB = {
          ...cachedStatus,
          licenseId: 'license-b',
        };
        trpc.me.query.mockResolvedValue(userB);
        trpc.license.status.query.mockResolvedValue(statusB);
        if (change === 'session change after unmount') {
          // Isolate the session fence: no license invalidation or old component watcher.
          auth.sessionVersion.value++;
          auth.accessToken.value = 'session-b-token';
          auth.user.value = userB;
          license.licenseStatus.value = statusB;
        } else {
          changeSession('session-b-token');
        }
      } else if (change === 'external license replacement after unmount') {
        expect(license.isLicenseSyncing.value).toBe(true);
        expect(license.beginLicenseUpdate()).toBeUndefined();
        license.invalidateLicenseStatus();
        license.licenseStatus.value = { ...cachedStatus, maxAgents: 99 };
      } else if (change === 'license invalidation') {
        license.invalidateLicenseStatus();
        license.licenseStatus.value = { ...cachedStatus, maxAgents: 99 };
      }
      await vi.advanceTimersByTimeAsync(0);

      // Already-sent mutations stay sent; only their obsolete continuations are forbidden.
      const effects = {
        acquire: trpc.license.acquireCourierLock.mutate,
        config: trpc.license.getDeploymentConfig.query,
        fetch: fetchMock,
        provision: trpc.license.provision.mutate,
        sync: trpc.license.sync.mutate,
        preparation: trpc.license.prepareRelay.mutate,
        relay: trpc.license.submitRelay.mutate,
        revocation: trpc.license.reportRevocation.mutate,
        status: trpc.license.status.query,
        me: trpc.me.query,
        fetchUser: auth.fetchUser,
        toast: toast.add,
        logout: auth.logout,
        redirect: router.replace,
        navigation: nuxtApp.navigateTo,
      };
      const calls = Object.fromEntries(
        Object.entries(effects).map(([name, mock]) => [
          name,
          mock.mock.calls.length,
        ]),
      );
      if (continuesInitial) {
        calls.status!++;
        if (wait !== 'relay submission') calls.relay!++;
        if (wait === 'rotation rejection') calls.fetch!++;
      }
      const status = license.licenseStatus.value;
      const currentGeneration = license.captureLicenseOperation(true);
      const updating = license.isLicenseUpdating.value;
      const user = auth.user.value;
      const token = auth.accessToken.value;
      if (rejection) pending.reject(rejection);
      else pending.resolve(value);
      await action;
      await vi.advanceTimersByTimeAsync(0);
      expect
        .soft(
          Object.fromEntries(
            Object.entries(effects).map(([name, mock]) => [
              name,
              mock.mock.calls.length,
            ]),
          ),
        )
        .toEqual(calls);
      expect(trpc.license.releaseCourierLock.mutate).toHaveBeenCalledTimes(
        wait === 'denied lock' || wait === 'lock error' ? 0 : 1,
      );
      if (wait !== 'denied lock' && wait !== 'lock error') {
        expect(
          trpc.license.releaseCourierLock.mutate.mock.calls[0]![1].context
            .courierLease,
        ).toBe(
          trpc.license.acquireCourierLock.mutate.mock.calls[0]![1].context
            .courierLease,
        );
      }
      if (continuesInitial) {
        expect(trpc.license.submitRelay.mutate.mock.calls).toStrictEqual(
          (wait.startsWith('rotation')
            ? [undefined, 'rotated-public-key']
            : [undefined]
          ).map((publicKey) => [
            { ...relay, initialFrom: config.jwt, publicKey },
          ]),
        );
      }
      expect(license.licenseStatus.value).toEqual(
        continuesInitial ? cachedStatus : status,
      );
      expect(currentGeneration()).toBe(!continuesInitial);
      expect(license.isLicenseUpdating.value).toBe(updating);
      expect(license.isLicenseSyncing.value).toBe(false);
      expect(auth.user.value).toBe(user);
      expect(auth.accessToken.value).toBe(token);
      expect(auth.logout).not.toHaveBeenCalled();
      if (change.includes('unmount')) {
        expect(vi.getTimerCount()).toBe(0);
        if (phase === 0 && httpStatus === 200) {
          for (const [, init] of fetchMock.mock.calls) {
            expect(init.signal.aborted).toBe(false);
          }
        }
      }
    } finally {
      pending.resolve(value);
      await action;
      await vi.advanceTimersByTimeAsync(0);
    }
  });

  it.each([
    'success',
    'failure',
  ] as const)('waits for durable preparation before Phase 2 (%s)', async (result) => {
    const preparation = deferred<{ success: true }>();
    const phase2 = deferred<Response>();
    const currentLicense = license.captureLicenseOperation();
    trpc.license.sync.mutate.mockResolvedValue({ requiresCourier: true });
    trpc.license.getDeploymentConfig.query.mockResolvedValue({
      licenseId: cachedStatus.licenseId,
      jwt: 'captured-jwt',
      nextToken: 'previous-token',
    });
    trpc.license.prepareRelay.mutate.mockReturnValueOnce(preparation.promise);
    trpc.license.submitRelay.mutate
      .mockRejectedValueOnce(
        new Error('No public key available for verification'),
      )
      .mockResolvedValue({ success: true });
    fetchMock
      .mockResolvedValueOnce(
        new Response(JSON.stringify({ nextToken: 'prepared-token' })),
      )
      .mockReturnValueOnce(phase2.promise)
      .mockResolvedValueOnce(
        new Response(JSON.stringify('rotated-public-key')),
      );

    let action: Promise<unknown> | undefined;
    try {
      if (mode === 'automatic') {
        mountLayout();
        await until(() => expect(vi.getTimerCount()).toBe(1));
        trpc.license.status.query.mockResolvedValueOnce({
          ...cachedStatus,
          hintStatus: 'COURIER_REQUIRED',
        });
        vi.advanceTimersByTime(60_000);
      } else {
        const root = mountSfc('../app/pages/license/index.vue');
        await vi.advanceTimersByTimeAsync(0);
        action = click(root, 'Sync License');
      }
      await until(() =>
        expect(trpc.license.prepareRelay.mutate).toHaveBeenCalledTimes(1),
      );
      expect(trpc.license.prepareRelay.mutate).toHaveBeenCalledWith({
        jwt: 'captured-jwt',
        previousNextToken: 'previous-token',
        nextToken: 'prepared-token',
      });
      expect(JSON.parse(fetchMock.mock.calls[0]![1].body)).toEqual({
        phase: 1,
        licenseId: cachedStatus.licenseId,
        jwt: 'captured-jwt',
        nextToken: 'previous-token',
      });
      await vi.advanceTimersByTimeAsync(10_001);
      expect(fetchMock).toHaveBeenCalledTimes(1);
      expect(vi.getTimerCount()).toBe(mode === 'automatic' ? 1 : 0);
      expect(trpc.license.submitRelay.mutate).not.toHaveBeenCalled();
      expect(trpc.license.releaseCourierLock.mutate).not.toHaveBeenCalled();
      expect(currentLicense()).toBe(true);

      if (result === 'failure') {
        preparation.reject(new Error('Preparation unavailable'));
      } else {
        preparation.resolve({ success: true });
        await until(() => expect(fetchMock).toHaveBeenCalledTimes(2));
        expect(JSON.parse(fetchMock.mock.calls[1]![1].body)).toEqual({
          phase: 2,
          licenseId: cachedStatus.licenseId,
          jwt: 'captured-jwt',
          nextToken: 'prepared-token',
        });
        expect(fetchMock.mock.calls[1]![1].signal.aborted).toBe(false);
        expect(vi.getTimerCount()).toBe(mode === 'automatic' ? 2 : 1);
        expect(currentLicense()).toBe(true);
        phase2.resolve(new Response(JSON.stringify({ jwt: 'renewed-jwt' })));
      }
      await action;
      await vi.advanceTimersByTimeAsync(0);
      expect(trpc.license.prepareRelay.mutate).toHaveBeenCalledTimes(1);
      expect(trpc.license.releaseCourierLock.mutate).toHaveBeenCalledTimes(1);
      expect(trpc.license.reportRevocation.mutate).not.toHaveBeenCalled();
      if (result === 'failure') {
        expect(fetchMock).toHaveBeenCalledTimes(1);
        expect(trpc.license.submitRelay.mutate).not.toHaveBeenCalled();
        expect(currentLicense()).toBe(true);
      } else {
        expect(trpc.license.submitRelay.mutate.mock.calls).toStrictEqual(
          [undefined, 'rotated-public-key'].map((publicKey) => [
            {
              jwt: 'renewed-jwt',
              nextToken: 'prepared-token',
              preparedFrom: 'captured-jwt',
              publicKey,
            },
          ]),
        );
        expect(currentLicense()).toBe(false);
      }
    } finally {
      preparation.resolve({ success: true });
      phase2.resolve(new Response(JSON.stringify({ jwt: 'renewed-jwt' })));
      await action;
      await vi.advanceTimersByTimeAsync(0);
    }
  });

  it('never mixes a live license ID into the captured heartbeat JWT snapshot', async () => {
    const phase1 = deferred<Response>();
    const relay = { jwt: 'renewed-jwt', nextToken: 'renewed-token' };
    trpc.license.sync.mutate.mockResolvedValue({ requiresCourier: true });
    trpc.license.getDeploymentConfig.query.mockResolvedValue({
      licenseId: cachedStatus.licenseId,
      jwt: 'captured-jwt',
      nextToken: 'captured-token',
    });
    trpc.license.submitRelay.mutate.mockResolvedValue({ success: true });
    fetchMock
      .mockReturnValueOnce(phase1.promise)
      .mockImplementation(async () => new Response(JSON.stringify(relay)));
    let action: Promise<unknown> | undefined;
    try {
      if (mode === 'automatic') {
        mountLayout();
        await until(() => expect(vi.getTimerCount()).toBe(1));
        trpc.license.status.query.mockResolvedValueOnce({
          ...cachedStatus,
          hintStatus: 'COURIER_REQUIRED',
        });
        vi.advanceTimersByTime(60_000);
      } else {
        const root = mountSfc('../app/pages/license/index.vue');
        await vi.advanceTimersByTimeAsync(0);
        action = click(root, 'Sync License');
      }
      await until(() => expect(fetchMock).toHaveBeenCalledTimes(1));
      license.licenseStatus.value = {
        ...cachedStatus,
        licenseId: 'different-live-license',
      };
      phase1.resolve(new Response(JSON.stringify(relay)));
      await action;
      await vi.advanceTimersByTimeAsync(0);
      const heartbeats = fetchMock.mock.calls.map(([, init]) =>
        JSON.parse(init.body),
      );
      // Cancellation may suppress phase 2 entirely; any sent phase must use the original pair.
      expect(heartbeats.length).toBeGreaterThan(0);
      for (const heartbeat of heartbeats) {
        expect(heartbeat).toMatchObject({
          licenseId: cachedStatus.licenseId,
          jwt: 'captured-jwt',
        });
      }
      expect(trpc.license.releaseCourierLock.mutate).toHaveBeenCalledTimes(1);
    } finally {
      phase1.resolve(new Response(JSON.stringify(relay)));
      await action;
      await vi.advanceTimersByTimeAsync(0);
    }
  });

  it.each([
    'Phase 1',
    'Phase 2',
    'public-key retry',
  ] as const)('keeps the captured tuple on a late %s conflict without clearing newer REVOKED status', async (wait) => {
    const pending = deferred<Response>();
    const config = {
      licenseId: cachedStatus.licenseId,
      jwt: 'captured-jwt',
      nextToken: 'captured-token',
      syncStatusIndex: 41,
    };
    const captured = { ...config };
    const revoked = {
      ...cachedStatus,
      licenseId: 'newer-revoked-license',
      customerName: 'Newer revoked customer',
      status: 'REVOKED',
      hintStatus: 'REVOKED',
      maxAgents: 99,
    } as LicenseStatus;
    const conflict = Object.assign(
      new TRPCClientError(
        'License state changed; reload the deployment configuration before retrying',
      ),
      { data: { code: 'CONFLICT', httpStatus: 409 } },
    );
    const response = () =>
      Response.json(
        wait === 'Phase 1'
          ? { nextToken: 'prepared-token' }
          : wait === 'Phase 2'
            ? { jwt: 'renewed-jwt' }
            : 'rotated-public-key',
      );
    const currentLicense = license.captureLicenseOperation();
    trpc.license.sync.mutate.mockResolvedValue({ requiresCourier: true });
    trpc.license.getDeploymentConfig.query.mockResolvedValue(config);
    trpc.license.submitRelay.mutate.mockResolvedValue({ success: true });
    if (wait === 'public-key retry') {
      trpc.license.submitRelay.mutate.mockRejectedValueOnce(
        new Error('No public key available for verification'),
      );
    }
    fetchMock.mockImplementation(async (url, init) => {
      if (url === publicKeyUrl) return pending.promise;
      expect(url).toBe(`${licensingUrl}/api/heartbeat`);
      const { phase } = JSON.parse(init.body);
      if (wait === `Phase ${phase}`) return pending.promise;
      return Response.json(
        phase === 1 ? { nextToken: 'prepared-token' } : { jwt: 'renewed-jwt' },
      );
    });
    let action: Promise<unknown> | undefined;
    try {
      const root =
        mode === 'automatic'
          ? mountLayout().root
          : mountSfc('../app/pages/license/index.vue');
      await vi.advanceTimersByTimeAsync(0);
      if (mode === 'automatic') {
        trpc.license.status.query.mockResolvedValueOnce({
          ...cachedStatus,
          hintStatus: 'COURIER_REQUIRED',
        });
        vi.advanceTimersByTime(60_000);
      } else {
        action = click(root, 'Sync License');
      }
      const requests = wait === 'Phase 1' ? 1 : wait === 'Phase 2' ? 2 : 3;
      await until(() => expect(fetchMock).toHaveBeenCalledTimes(requests));

      // Change the cached config object too, not just the next query result.
      Object.assign(config, {
        licenseId: revoked.licenseId,
        jwt: 'newer-jwt',
        nextToken: 'newer-token',
        syncStatusIndex: captured.syncStatusIndex + 1,
      });
      trpc.license.status.query.mockResolvedValue(revoked);
      await license.fetchLicenseStatus(true);
      expect(license.licenseStatus.value).toEqual(revoked);
      expect(currentLicense()).toBe(true);
      const rejectedMutation =
        wait === 'Phase 1'
          ? trpc.license.prepareRelay.mutate
          : trpc.license.submitRelay.mutate;
      rejectedMutation.mockRejectedValueOnce(conflict);
      pending.resolve(response());
      await action;
      await vi.advanceTimersByTimeAsync(0);

      expect(fetchMock).toHaveBeenCalledTimes(requests);
      expect(
        fetchMock.mock.calls
          .filter(([url]) => url !== publicKeyUrl)
          .map(([, init]) => JSON.parse(init.body)),
      ).toStrictEqual([
        {
          phase: 1,
          licenseId: captured.licenseId,
          jwt: captured.jwt,
          nextToken: captured.nextToken,
        },
        ...(wait === 'Phase 1'
          ? []
          : [
              {
                phase: 2,
                licenseId: captured.licenseId,
                jwt: captured.jwt,
                nextToken: 'prepared-token',
              },
            ]),
      ]);
      expect(trpc.license.prepareRelay.mutate.mock.calls).toStrictEqual([
        [
          {
            jwt: captured.jwt,
            previousNextToken: captured.nextToken,
            nextToken: 'prepared-token',
            syncStatusIndex: captured.syncStatusIndex,
          },
        ],
      ]);
      expect(trpc.license.submitRelay.mutate.mock.calls).toStrictEqual(
        (wait === 'Phase 1'
          ? []
          : wait === 'Phase 2'
            ? [undefined]
            : [undefined, 'rotated-public-key']
        ).map((publicKey) => [
          {
            jwt: 'renewed-jwt',
            nextToken: 'prepared-token',
            preparedFrom: captured.jwt,
            syncStatusIndex: captured.syncStatusIndex,
            publicKey,
          },
        ]),
      );
      expect(trpc.license.getDeploymentConfig.query).toHaveBeenCalledTimes(1);
      expect(trpc.license.acquireCourierLock.mutate).toHaveBeenCalledTimes(1);
      expect(trpc.license.releaseCourierLock.mutate).toHaveBeenCalledTimes(1);
      expect(
        trpc.license.releaseCourierLock.mutate.mock.calls[0]![1].context
          .courierLease,
      ).toBe(
        trpc.license.acquireCourierLock.mutate.mock.calls[0]![1].context
          .courierLease,
      );
      expect(console.error).toHaveBeenCalledWith(
        'Courier relay failed',
        conflict,
      );
      expect(license.licenseStatus.value).toEqual(revoked);
      expect(currentLicense()).toBe(true);
      expect(license.isLicenseSyncing.value).toBe(false);
      expect(license.licenseFetchError.value).toBe(false);
      expect(text(root)).toContain(
        mode === 'automatic' ? 'Cloning Detected' : 'REVOKED',
      );
      if (mode === 'manual') {
        expect(toast.add).toHaveBeenCalledWith(
          expect.objectContaining({ title: 'Courier Failed', color: 'red' }),
        );
        expect(button(root, 'Sync License')?.props.disabled).toBe(false);
      }
      expect(
        toast.add.mock.calls.filter(([notice]) =>
          ['green', 'success'].includes(notice.color),
        ),
      ).toEqual([]);
      expect(trpc.license.reportRevocation.mutate).not.toHaveBeenCalled();
      expect(trpc.license.provision.mutate).not.toHaveBeenCalled();
      expect(auth.logout).not.toHaveBeenCalled();
      expect(router.replace).not.toHaveBeenCalled();
      expect(nuxtApp.navigateTo).not.toHaveBeenCalled();
      expect(vi.getTimerCount()).toBe(mode === 'automatic' ? 1 : 0);
    } finally {
      pending.resolve(response());
      await action;
      await vi.advanceTimersByTimeAsync(0);
    }
  });
});

describe('same-license update rejection', () => {
  it.each([
    { name: 'initial JWT', licenseId: cachedStatus.licenseId, maxAgents: 5 },
    {
      name: 'changed JWT with the same ID',
      licenseId: cachedStatus.licenseId,
      maxAgents: 50,
    },
    {
      name: 'duplicate hidden by stale cached identity',
      licenseId: 'durable-license-b',
      maxAgents: 50,
    },
  ])('reserves preflight for $name without discarding pending status or input', async ({
    licenseId,
    maxAgents,
  }) => {
    const incoming = makeJwt({ licenseId, max_agents: maxAgents });
    const config = {
      licenseId,
      jwt: incoming,
      nextToken: 'current-rolling-token',
    };
    const precheck = deferred<typeof config>();
    trpc.license.getDeploymentConfig.query.mockReturnValueOnce(
      precheck.promise,
    );
    const root = mountSfc('../app/pages/license/index.vue');
    await vi.advanceTimersByTimeAsync(0);
    const snapshot = license.licenseStatus.value;
    const current = license.captureLicenseOperation(true);
    const pending = deferred<LicenseStatus>();
    trpc.license.status.query.mockReturnValueOnce(pending.promise);
    const read = Promise.allSettled([license.fetchLicenseStatus(true)]);
    let update: Promise<unknown> | undefined;
    try {
      click(root, 'Update JWT');
      await enterJwt(root, incoming);
      update = click(root, 'Update License');
      await until(() =>
        expect(trpc.license.getDeploymentConfig.query).toHaveBeenCalledTimes(1),
      );
      expect(license.isLicenseUpdating.value).toBe(true);
      expect(license.isLicenseSyncing.value).toBe(false);
      expect(current()).toBe(true);
      expect(button(root, 'Update License')?.props.disabled).toBe(true);
      expect(button(root, 'Sync License')?.props.disabled).toBe(true);
      await button(root, 'Update License')!.props.onClick();
      await button(root, 'Sync License')!.props.onClick();
      precheck.resolve(config);
      await update;
      await Vue.nextTick();
      expect(text(root)).toContain(
        'This license is already installed. Use Sync License to refresh its entitlements.',
      );
      expect(
        nodes(root).find((node) => node.type === 'textarea')?.props.value,
      ).toBe(incoming);
      expect(button(root, 'Update License')?.props.disabled).toBe(false);
      expect(trpc.license.getDeploymentConfig.query).toHaveBeenCalledTimes(1);
      expect(trpc.license.provision.mutate).not.toHaveBeenCalled();
      expect(trpc.license.prepareRelay.mutate).not.toHaveBeenCalled();
      expect(trpc.license.sync.mutate).not.toHaveBeenCalled();
      expect(fetchMock).not.toHaveBeenCalled();
      expect(toast.add).not.toHaveBeenCalled();
      expect(license.licenseStatus.value).toBe(snapshot);
      expect(license.isLicenseUpdating.value).toBe(false);
      expect(current()).toBe(true);
      pending.resolve(cachedStatus);
      expect(await read).toEqual([
        { status: 'fulfilled', value: cachedStatus },
      ]);
    } finally {
      precheck.resolve(config);
      pending.resolve(cachedStatus);
      await Promise.all([update, read]);
    }
  });

  it('does not reject a real replacement merely because the UI cache has the incoming ID', async () => {
    const incoming = makeJwt({ licenseId: cachedStatus.licenseId });
    trpc.license.getDeploymentConfig.query.mockResolvedValue({
      licenseId: 'durable-license-b',
      jwt: 'durable-jwt-b',
      nextToken: 'durable-token-b',
    });
    trpc.license.provision.mutate.mockResolvedValue({ success: true });
    fetchMock.mockResolvedValueOnce(Response.json('test-public-key'));
    const root = mountSfc('../app/pages/license/index.vue');
    await vi.advanceTimersByTimeAsync(0);
    click(root, 'Update JWT');
    await enterJwt(root, incoming);
    await click(root, 'Update License');
    expect(trpc.license.getDeploymentConfig.query).toHaveBeenCalledTimes(1);
    expect(trpc.license.provision.mutate).toHaveBeenCalledExactlyOnceWith({
      jwt: incoming,
      publicKey: 'test-public-key',
    });
    expect(text(root)).not.toContain('This license is already installed.');
    expect(toast.add).toHaveBeenCalledWith(
      expect.objectContaining({ title: 'License Activated' }),
    );
  });
});

describe('shared license UI ownership', () => {
  it.each([
    'automatic',
    'manual',
  ] as const)('reserves at %s courier entry, before the first mutation resolves', async (mode) => {
    route.path = '/license';
    const root = mountSfc('../app/pages/license/index.vue');
    await vi.advanceTimersByTimeAsync(0);
    click(root, 'Update JWT');
    const incoming = makeJwt({ licenseId: 'replacement-license' });
    await enterJwt(root, incoming);
    const provision = button(root, 'Update License')!.props.onClick;
    const sync = button(root, 'Sync License')!.props.onClick;
    const current = license.captureLicenseOperation(true);
    const pending = deferred<{ success: boolean; requiresCourier: boolean }>();
    const firstMutation =
      mode === 'automatic'
        ? trpc.license.acquireCourierLock.mutate
        : trpc.license.sync.mutate;
    firstMutation.mockReturnValueOnce(pending.promise);
    let action: Promise<unknown> | undefined;
    try {
      if (mode === 'automatic') {
        license.licenseStatus.value = {
          ...cachedStatus,
          hintStatus: 'COURIER_REQUIRED',
        } as LicenseStatus;
        mountSfc('../app/layouts/default.vue');
      } else {
        action = sync();
      }
      await until(() => expect(firstMutation).toHaveBeenCalledTimes(1));
      expect(license.isLicenseSyncing.value).toBe(true);
      expect(license.isLicenseUpdating.value).toBe(false);
      expect(button(root, 'Update License')?.props.disabled).toBe(true);
      expect(button(root, 'Cancel Update')?.props.disabled).toBe(true);
      expect(button(root, 'Sync License')?.props.disabled).toBe(true);
      expect(text(root)).toContain(
        'License synchronization is in progress. JWT replacement is temporarily unavailable.',
      );
      await provision();
      await sync();
      expect(firstMutation).toHaveBeenCalledTimes(1);
      expect(trpc.license.provision.mutate).not.toHaveBeenCalled();
      expect(trpc.license.getDeploymentConfig.query).not.toHaveBeenCalled();
      expect(trpc.license.sync.mutate).toHaveBeenCalledTimes(
        mode === 'manual' ? 1 : 0,
      );
      expect(current()).toBe(true);
      expect(
        nodes(root).find((node) => node.type === 'textarea')?.props,
      ).toMatchObject({ value: incoming, disabled: true });
      pending.resolve({ success: false, requiresCourier: false });
      await action;
      await vi.advanceTimersByTimeAsync(0);
      expect(license.isLicenseSyncing.value).toBe(false);
      expect(license.isLicenseUpdating.value).toBe(false);
      expect(button(root, 'Update License')?.props.disabled).toBe(false);
      expect(trpc.license.provision.mutate).not.toHaveBeenCalled();
      expect(trpc.license.releaseCourierLock.mutate).not.toHaveBeenCalled();
      expect(
        nodes(root).find((node) => node.type === 'textarea')?.props.value,
      ).toBe(incoming);
    } finally {
      pending.resolve({ success: false, requiresCourier: false });
      await action;
      await vi.advanceTimersByTimeAsync(0);
    }
  });

  it.each(
    (['precheck', 'verification'] as const).flatMap((wait) =>
      [false, true].map((remount) => ({ wait, remount })),
    ),
  )('blocks couriers throughout provision $wait (remount: $remount), then permits a new sync', async ({
    wait,
    remount,
  }) => {
    const config = {
      licenseId: cachedStatus.licenseId,
      jwt: 'installed-initial-jwt',
      nextToken: null,
    };
    const courierStatus = {
      ...cachedStatus,
      hintStatus: 'COURIER_REQUIRED',
    } as LicenseStatus;
    const pending = deferred<unknown>();
    const failure = new Error(
      wait === 'precheck'
        ? 'Deployment precheck unavailable'
        : 'Invalid, forged, or expired license token',
    );
    const incoming = makeJwt({ licenseId: 'rejected-replacement' });
    const relay = { jwt: 'initialized-jwt', nextToken: 'initialized-token' };
    const blocked =
      wait === 'precheck'
        ? trpc.license.getDeploymentConfig.query
        : trpc.license.provision.mutate;
    trpc.license.getDeploymentConfig.query.mockResolvedValue(config);
    blocked.mockReturnValueOnce(pending.promise);
    trpc.license.sync.mutate.mockResolvedValue({ requiresCourier: true });
    trpc.license.submitRelay.mutate.mockResolvedValue({ success: true });
    fetchMock.mockImplementation(async (url) =>
      Response.json(url === publicKeyUrl ? 'test-public-key' : relay),
    );
    route.path = '/license';
    mountSfc('../app/layouts/default.vue');
    let root = mountSfc('../app/pages/license/index.vue');
    await vi.advanceTimersByTimeAsync(0);
    click(root, 'Update JWT');
    await enterJwt(root, incoming);
    const generation = license.captureLicenseOperation(true);
    const update = click(root, 'Update License');
    try {
      await until(() => expect(blocked).toHaveBeenCalledTimes(1));
      expect(license.isLicenseUpdating.value).toBe(true);
      expect(license.isLicenseSyncing.value).toBe(false);
      expect(generation()).toBe(wait === 'precheck');
      trpc.license.status.query.mockResolvedValue(courierStatus);
      if (remount) {
        apps.pop()!.unmount();
        expect(license.isLicenseUpdating.value).toBe(true);
        root = mountSfc('../app/pages/license/index.vue');
        await vi.advanceTimersByTimeAsync(0);
        expect(button(root, 'Update JWT')?.props.disabled).toBe(true);
      } else {
        expect(button(root, 'Update License')?.props.disabled).toBe(true);
        await button(root, 'Update License')!.props.onClick();
      }
      await vi.advanceTimersByTimeAsync(60_000);
      const sync = button(root, 'Sync License')!;
      expect(sync.props.disabled).toBe(true);
      await sync.props.onClick();
      expect(license.isLicenseUpdating.value).toBe(true);
      expect(license.isLicenseSyncing.value).toBe(false);
      expect(trpc.license.acquireCourierLock.mutate).not.toHaveBeenCalled();
      expect(trpc.license.sync.mutate).not.toHaveBeenCalled();
      expect(trpc.license.submitRelay.mutate).not.toHaveBeenCalled();
      expect(
        fetchMock.mock.calls.filter(([url]) => url !== publicKeyUrl),
      ).toEqual([]);
      expect(trpc.license.getDeploymentConfig.query).toHaveBeenCalledTimes(1);
      expect(trpc.license.provision.mutate).toHaveBeenCalledTimes(
        wait === 'verification' ? 1 : 0,
      );

      pending.reject(failure);
      await update;
      await vi.advanceTimersByTimeAsync(0);
      expect(license.isLicenseUpdating.value).toBe(false);
      expect(license.isLicenseSyncing.value).toBe(false);
      expect(button(root, 'Sync License')?.props.disabled).toBe(false);
      expect(trpc.license.acquireCourierLock.mutate).not.toHaveBeenCalled();
      expect(trpc.license.sync.mutate).not.toHaveBeenCalled();
      if (!remount) {
        expect(text(root)).toContain(failure.message);
        expect(
          nodes(root).find((node) => node.type === 'textarea')?.props.value,
        ).toBe(incoming);
      }
      trpc.license.status.query.mockResolvedValue(cachedStatus);
      await click(root, 'Sync License');
      await vi.advanceTimersByTimeAsync(0);
      expect(trpc.license.sync.mutate).toHaveBeenCalledTimes(1);
      expect(trpc.license.acquireCourierLock.mutate).toHaveBeenCalledTimes(1);
      expect(trpc.license.releaseCourierLock.mutate).toHaveBeenCalledTimes(1);
      expect(trpc.license.submitRelay.mutate).toHaveBeenCalledExactlyOnceWith({
        ...relay,
        initialFrom: config.jwt,
        publicKey: undefined,
      });
      expect(license.isLicenseSyncing.value).toBe(false);
      expect(license.isLicenseUpdating.value).toBe(false);
      expect(license.licenseStatus.value).toEqual(cachedStatus);
      expect(auth.logout).not.toHaveBeenCalled();
    } finally {
      pending.resolve(config);
      await update;
      await vi.advanceTimersByTimeAsync(0);
    }
  });
});

describe('real transport license couriers', () => {
  type Request = {
    paths: string[];
    inputs: any[];
    authorization: string | null;
  };
  type RelayInput = Parameters<typeof initialRelay.submitInitialRelay>[1];

  function installCourierTransport(pair = signedCredentials()) {
    vi.useRealTimers();
    const session = verifyAuthToken(pair.refreshToken);
    const browser = installStorage(pair);
    authModule.writeAuthTokens(pair, undefined, { boundary: true });
    authProvider = authModule.useAuth;
    const realAuth = authModule.useAuth();
    const user = {
      ...admin,
      userId: 'A',
      email: 'A@example.test',
      permissions: { isAdmin: true, permissions: {} },
    };
    const record = {
      licenseId: cachedStatus.licenseId!,
      jwt: ' original-license.jwt ',
      nextToken: null as string | null,
    };
    const central = {
      jwt: ' issued-license.jwt ',
      nextToken: 'first-rolling-token',
      issuances: 0,
    };
    const heartbeat = vi.fn(async (_input: typeof record) =>
      Response.json({ jwt: central.jwt, nextToken: central.nextToken }),
    );
    // Redis SET NX EX 300 and DEL do not bind the lock to an access token.
    const lease = { expiresAt: 0, deletions: 0 };
    const handlers = {
      refreshAuthToken: vi.fn(() => ({
        accessToken: signedCredentials(session.userId).accessToken,
      })),
      me: vi.fn(() => user),
      'license.status': vi.fn(async () => ({
        ...cachedStatus,
        licenseId: record.licenseId,
        hintStatus: record.nextToken ? 'SYNCED' : 'COURIER_REQUIRED',
      })),
      'license.getDeploymentConfig': vi.fn(() => ({ ...record })),
      'license.provision': vi.fn(() =>
        Object.assign(
          new TRPCClientError('Invalid, forged, or expired license token'),
          { data: { code: 'BAD_REQUEST', httpStatus: 400 } },
        ),
      ),
      'license.sync': vi.fn(() => ({ requiresCourier: true })),
      'license.acquireCourierLock': vi.fn((_input, _request: Request) => {
        if (lease.expiresAt > Date.now()) return { success: false };
        lease.expiresAt = Date.now() + 300_000;
        return { success: true };
      }),
      'license.releaseCourierLock': vi.fn(() => {
        if (lease.expiresAt > Date.now()) lease.deletions++;
        lease.expiresAt = 0;
        return { success: true };
      }),
      'license.submitRelay': vi.fn(async (value: RelayInput) => {
        if (record.nextToken !== null || value.initialFrom !== record.jwt) {
          return Object.assign(
            new TRPCClientError('Deployment state changed'),
            { data: { code: 'CONFLICT', httpStatus: 409 } },
          );
        }
        record.jwt = value.jwt;
        record.nextToken = value.nextToken;
        return { success: true };
      }),
    };
    const requests: Request[] = [];
    fetchMock.mockImplementation(
      async (urlString: string, init: RequestInit) => {
        if (urlString === publicKeyUrl)
          return Response.json('rotated-public-key');
        if (urlString === `${licensingUrl}/api/heartbeat`) {
          const body = JSON.parse(String(init.body));
          expect(body).toStrictEqual({ ...record, nextToken: null });
          expect(central.issuances).toBe(0);
          central.issuances++;
          return heartbeat(body);
        }
        const url = new URL(urlString);
        expect(url.origin).toBe('http://localhost');
        const paths = url.pathname.replace('/trpc/', '').split(',');
        const batch = url.searchParams.get('batch') === '1';
        const rawInput = JSON.parse(
          String(init.body ?? url.searchParams.get('input') ?? 'null'),
        );
        const inputs = paths.map((_path, index) => {
          const value = batch ? rawInput?.[index] : rawInput;
          return value ? superjson.deserialize(value) : undefined;
        });
        const request = {
          paths,
          inputs,
          authorization: new Headers(init.headers).get('authorization'),
        };
        requests.push(request);
        const values = await Promise.all(
          paths.map(async (path, index) => {
            const handler = handlers[path as keyof typeof handlers];
            if (!handler) throw new Error(`Unexpected RPC: ${path}`);
            try {
              const refresh = path === 'refreshAuthToken';
              const claims = verifyAuthToken(
                refresh
                  ? (inputs[index]?.refreshToken ?? '')
                  : (request.authorization?.replace(/^Bearer /, '') ?? ''),
              );
              if (
                refresh &&
                (claims.userId !== session.userId ||
                  claims.userSecret !== session.userSecret)
              ) {
                throw new Error('Invalid refresh session');
              }
            } catch {
              return {
                error: superjson.serialize({
                  message: 'Invalid or expired auth token',
                  code: -32001,
                  data: { code: 'UNAUTHORIZED', httpStatus: 401 },
                }),
              };
            }
            const value = await handler(inputs[index], request);
            return value instanceof TRPCClientError
              ? {
                  error: superjson.serialize({
                    message: value.message,
                    code: -32000,
                    data: value.data,
                  }),
                }
              : { result: { data: superjson.serialize(value) } };
          }),
        );
        return Response.json(batch ? values : values[0]);
      },
    );
    nuxtApp.useRuntimeConfig.mockReturnValue({
      public: { trpcUrl: 'http://localhost/trpc' },
    });
    const rpc = trpcPlugin({}).provide.trpc;
    const submitRelay = vi.fn(rpc.license.submitRelay.mutate);
    // Only this seam schedules rotation; every attempt still uses the real client.
    nuxtApp.useNuxtApp.mockReturnValue({
      $trpc: {
        me: rpc.me,
        license: {
          status: rpc.license.status,
          getDeploymentConfig: rpc.license.getDeploymentConfig,
          provision: rpc.license.provision,
          sync: rpc.license.sync,
          acquireCourierLock: rpc.license.acquireCourierLock,
          releaseCourierLock: rpc.license.releaseCourierLock,
          submitRelay: { mutate: submitRelay },
          prepareRelay: rpc.license.prepareRelay,
          reportRevocation: rpc.license.reportRevocation,
        },
      },
    });
    stopAuthObserver = authModule.observeAuthSession(rpc);
    realAuth.user.value = user;
    license.licenseStatus.value = cachedStatus;
    route.path = '/license';
    return {
      pair,
      browser,
      realAuth,
      record,
      central,
      heartbeat,
      lease,
      handlers,
      requests,
      rpc,
      submitRelay,
    };
  }

  it.each(
    (['automatic', 'manual'] as const).flatMap((mode) =>
      [false, true].map((publicKeyRetry) => ({ mode, publicKeyRetry })),
    ),
  )('persists $mode initial relay after queued credential rotation (public-key retry: $publicKeyRetry)', async ({
    mode,
    publicKeyRetry,
  }) => {
    const {
      pair,
      browser,
      realAuth,
      record,
      central,
      heartbeat,
      handlers,
      requests,
      rpc,
      submitRelay,
    } = installCourierTransport();
    const initial = { ...record };
    const currentSession = realAuth.captureSession();
    const version = realAuth.sessionVersion.value;
    const rotated = signedCredentials('A', {
      iat: Math.floor(Date.now() / 1000) + 1,
    });
    if (publicKeyRetry) {
      handlers['license.submitRelay'].mockResolvedValueOnce(
        Object.assign(
          new TRPCClientError('No public key available for verification'),
          { data: { code: 'BAD_REQUEST', httpStatus: 400 } },
        ),
      );
    }
    let scheduled = false;
    submitRelay.mockImplementation((value) => {
      const pending = rpc.license.submitRelay.mutate(value);
      if (!scheduled && Boolean(value.publicKey) === publicKeyRetry) {
        scheduled = true;
        queueMicrotask(() => {
          if (publicKeyRetry) browser.replace(rotated, true);
          else browser.change('accessToken', rotated.accessToken, true);
        });
      }
      return pending;
    });
    const root = mountSfc('../app/pages/license/index.vue');
    await untilTransport(() =>
      expect(license.licenseStatus.value?.hintStatus).toBe('COURIER_REQUIRED'),
    );
    if (mode === 'automatic') mountSfc('../app/layouts/default.vue');
    else await click(root, 'Sync License');
    await untilTransport(() => {
      expect(record.nextToken).toBe(central.nextToken);
      expect(handlers['license.releaseCourierLock']).toHaveBeenCalledTimes(1);
      expect(license.isLicenseSyncing.value).toBe(false);
    });

    const firstInput = {
      jwt: central.jwt,
      nextToken: central.nextToken,
      initialFrom: initial.jwt,
      publicKey: undefined,
    };
    const finalInput = {
      ...firstInput,
      publicKey: publicKeyRetry ? 'rotated-public-key' : undefined,
    };
    expect(submitRelay.mock.calls).toStrictEqual(
      (publicKeyRetry
        ? [firstInput, finalInput, finalInput]
        : [firstInput, firstInput]
      ).map((value) => [value]),
    );
    const cancelledAttempt = publicKeyRetry ? 1 : 0;
    expect(submitRelay.mock.calls[cancelledAttempt]![0]).toBe(
      submitRelay.mock.calls[cancelledAttempt + 1]![0],
    );
    expect(
      requests.filter((request) =>
        request.paths.includes('license.submitRelay'),
      ),
    ).toStrictEqual([
      ...(publicKeyRetry
        ? [
            {
              paths: ['license.submitRelay'],
              inputs: [firstInput],
              authorization: `Bearer ${pair.accessToken}`,
            },
          ]
        : []),
      {
        paths: ['license.submitRelay'],
        inputs: [finalInput],
        authorization: `Bearer ${rotated.accessToken}`,
      },
    ]);
    expect(handlers['license.submitRelay']).toHaveBeenCalledTimes(
      publicKeyRetry ? 2 : 1,
    );
    expect(central.issuances).toBe(1);
    expect(heartbeat).toHaveBeenCalledExactlyOnceWith(initial);
    expect(record).toEqual({
      ...initial,
      jwt: central.jwt,
      nextToken: central.nextToken,
    });
    expect(license.licenseStatus.value?.hintStatus).toBe('SYNCED');
    expect(license.isLicenseUpdating.value).toBe(false);
    expect(handlers['license.acquireCourierLock']).toHaveBeenCalledTimes(1);
    expect(
      requests.find((request) =>
        request.paths.includes('license.acquireCourierLock'),
      ),
    ).toMatchObject({ authorization: `Bearer ${pair.accessToken}` });
    const cleanup = requests.find((request) =>
      request.paths.includes('license.releaseCourierLock'),
    )!;
    expect(cleanup.authorization).toBe(`Bearer ${rotated.accessToken}`);
    expect(verifyAuthToken(cleanup.authorization!.slice(7)).userId).toBe('A');
    expect(currentSession()).toBe(true);
    expect(realAuth.sessionVersion.value).toBe(version);
    expect(realAuth.user.value?.email).toBe('A@example.test');
    expect(realAuth.isAuthenticated.value).toBe(true);
    expect(browser.storage.getItem('accessToken')).toBe(rotated.accessToken);
    expect(browser.storage.getItem('refreshToken')).toBe(
      publicKeyRetry ? rotated.refreshToken : pair.refreshToken,
    );
    expect(browser.storage.removeItem).not.toHaveBeenCalled();
    expect(handlers['license.provision']).not.toHaveBeenCalled();
    expect(nuxtApp.navigateTo).not.toHaveBeenCalled();
    expect(router.replace).not.toHaveBeenCalled();
    expect(button(root, 'Sync License')?.props.disabled).toBe(false);
    if (mode === 'manual') {
      expect(toast.add).toHaveBeenCalledWith(
        expect.objectContaining({ title: 'License Synced', color: 'green' }),
      );
    }
  });

  it.each(
    (['automatic', 'manual'] as const).flatMap((mode) =>
      (['installed', 'renewed'] as const).map((cleanupAuth) => ({
        mode,
        cleanupAuth,
      })),
    ),
  )('releases the $mode courier at +70s with $cleanupAuth same-session credentials after its acquisition JWT expires', async ({
    mode,
    cleanupAuth,
  }) => {
    vi.useRealTimers();
    const startedAt = Math.floor(Date.now() / 1000) * 1000;
    const clock = vi.spyOn(Date, 'now').mockReturnValue(startedAt);
    const pair = signedCredentials('A', { exp: startedAt / 1000 + 65 });
    const {
      browser,
      realAuth,
      record,
      central,
      heartbeat,
      lease,
      handlers,
      requests,
      rpc,
      submitRelay,
    } = installCourierTransport(pair);
    const initial = { ...record };
    const currentSession = realAuth.captureSession();
    const version = realAuth.sessionVersion.value;
    const pending = deferred<void>();
    // Both RPCs authenticate before expiry; only their acknowledgements wait.
    if (mode === 'automatic') {
      const status = handlers['license.status'].getMockImplementation()!;
      handlers['license.status'].mockImplementation(async () => {
        const response = await status();
        if (record.nextToken) await pending.promise;
        return response;
      });
    } else {
      const persist = handlers['license.submitRelay'].getMockImplementation()!;
      handlers['license.submitRelay'].mockImplementationOnce(async (value) => {
        const response = await persist(value);
        await pending.promise;
        return response;
      });
    }
    const root = mountSfc('../app/pages/license/index.vue');
    let action: Promise<unknown> | undefined;
    try {
      await untilTransport(() =>
        expect(license.licenseStatus.value?.hintStatus).toBe(
          'COURIER_REQUIRED',
        ),
      );
      if (mode === 'automatic') mountSfc('../app/layouts/default.vue');
      else action = click(root, 'Sync License');
      await untilTransport(() => {
        expect(record.nextToken).toBe(central.nextToken);
        expect(handlers['license.status']).toHaveBeenCalledTimes(
          mode === 'automatic' ? 2 : 1,
        );
      });
      expect(
        requests.find((request) =>
          request.paths.includes('license.acquireCourierLock'),
        ),
      ).toEqual({
        paths: ['license.acquireCourierLock'],
        inputs: [undefined],
        authorization: `Bearer ${pair.accessToken}`,
      });
      expect(verifyAuthToken(pair.accessToken)).toMatchObject({
        userId: 'A',
        exp: startedAt / 1000 + 65,
      });
      expect(license.isLicenseSyncing.value).toBe(true);
      expect(button(root, 'Sync License')?.props.disabled).toBe(true);
      // Probe before advancing the clock so it cannot renew on cleanup's behalf.
      await expect(rpc.license.acquireCourierLock.mutate()).resolves.toEqual({
        success: false,
      });
      expect(lease).toEqual({ expiresAt: startedAt + 300_000, deletions: 0 });
      expect(handlers.refreshAuthToken).not.toHaveBeenCalled();
      expect(realAuth.accessToken.value).toBe(pair.accessToken);

      clock.mockReturnValue(startedAt + 70_000);
      expect(() => verifyAuthToken(pair.accessToken)).toThrowError(
        expect.objectContaining({ name: 'TokenExpiredError' }),
      );
      expect(verifyAuthToken(pair.refreshToken)).toMatchObject({
        userId: 'A',
        userSecret: 'revocation-version-A',
      });
      expect(lease.expiresAt).toBeGreaterThan(Date.now());
      expect(handlers['license.releaseCourierLock']).not.toHaveBeenCalled();
      const fresh = signedCredentials();
      if (cleanupAuth === 'installed') browser.replace(fresh);
      else {
        handlers.refreshAuthToken.mockReturnValueOnce({
          accessToken: fresh.accessToken,
        });
      }
      const cleanupStart = requests.length;
      pending.resolve();
      await action;
      await untilTransport(() => {
        expect(handlers['license.releaseCourierLock']).toHaveBeenCalledTimes(1);
        expect(license.isLicenseSyncing.value).toBe(false);
        expect(license.licenseStatus.value?.hintStatus).toBe('SYNCED');
      });

      expect(central.issuances).toBe(1);
      expect(heartbeat).toHaveBeenCalledExactlyOnceWith(initial);
      expect(submitRelay).toHaveBeenCalledExactlyOnceWith({
        jwt: central.jwt,
        nextToken: central.nextToken,
        initialFrom: initial.jwt,
        publicKey: undefined,
      });
      expect(handlers['license.submitRelay']).toHaveBeenCalledTimes(1);
      expect(record).toEqual({
        ...initial,
        jwt: central.jwt,
        nextToken: central.nextToken,
      });
      const cleanup = requests.filter((request) =>
        request.paths.includes('license.releaseCourierLock'),
      );
      expect(cleanup).toEqual([
        {
          paths: ['license.releaseCourierLock'],
          inputs: [undefined],
          authorization: `Bearer ${fresh.accessToken}`,
        },
      ]);
      expect(verifyAuthToken(cleanup[0]!.authorization!.slice(7)).userId).toBe(
        'A',
      );
      expect(
        requests.filter((request) =>
          request.paths.includes('refreshAuthToken'),
        ),
      ).toEqual(
        cleanupAuth === 'renewed'
          ? [
              {
                paths: ['refreshAuthToken'],
                inputs: [{ refreshToken: pair.refreshToken }],
                authorization: null,
              },
            ]
          : [],
      );
      expect(
        requests.slice(cleanupStart).flatMap((request) => request.paths),
      ).toEqual([
        ...(cleanupAuth === 'renewed' ? ['refreshAuthToken'] : []),
        'license.releaseCourierLock',
        ...(mode === 'manual' ? ['me', 'license.status'] : []),
      ]);
      expect(currentSession()).toBe(true);
      expect(realAuth.sessionVersion.value).toBe(version);
      expect(realAuth.user.value?.userId).toBe('A');
      expect(realAuth.isAuthenticated.value).toBe(true);
      expect(realAuth.accessToken.value).toBe(fresh.accessToken);
      expect(browser.storage.getItem('accessToken')).toBe(fresh.accessToken);
      expect(browser.storage.getItem('refreshToken')).toBe(
        cleanupAuth === 'installed' ? fresh.refreshToken : pair.refreshToken,
      );
      expect(browser.storage.removeItem).not.toHaveBeenCalled();
      expect(license.isLicenseUpdating.value).toBe(false);
      expect(button(root, 'Sync License')?.props.disabled).toBe(false);
      expect(console.error).not.toHaveBeenCalled();
      expect(nuxtApp.navigateTo).not.toHaveBeenCalled();
      expect(lease).toEqual({ expiresAt: 0, deletions: 1 });
      expect(Date.now()).toBe(startedAt + 70_000);
      await expect(rpc.license.acquireCourierLock.mutate()).resolves.toEqual({
        success: true,
      });
      expect(lease).toEqual({ expiresAt: startedAt + 370_000, deletions: 1 });
      expect(handlers['license.acquireCourierLock']).toHaveBeenCalledTimes(3);
      expect(handlers['license.releaseCourierLock']).toHaveBeenCalledTimes(1);
    } finally {
      pending.resolve();
      await action;
      await untilTransport(() =>
        expect(license.isLicenseSyncing.value).toBe(false),
      );
    }
  });

  it.each([
    'invalid',
    'expired',
  ] as const)('refuses replacement during automatic Phase 0, then preserves its token after an %s different-ID provision', async (kind) => {
    const { record, central, heartbeat, handlers, realAuth } =
      installCourierTransport();
    const initial = { ...record };
    const response = deferred<Response>();
    heartbeat.mockReturnValueOnce(response.promise);
    const currentSession = realAuth.captureSession();
    const root = mountSfc('../app/pages/license/index.vue');
    await untilTransport(() =>
      expect(license.licenseStatus.value?.hintStatus).toBe('COURIER_REQUIRED'),
    );
    click(root, 'Update JWT');
    const incoming = makeJwt({
      licenseId: 'rejected-different-license',
      exp: Math.floor(Date.now() / 1000) + (kind === 'expired' ? -1 : 900),
    });
    await enterJwt(root, incoming);
    const provision = button(root, 'Update License')!.props.onClick;
    click(root, 'Cancel Update');
    await Vue.nextTick();
    const showUpdate = button(root, 'Update JWT')!.props.onClick;
    mountSfc('../app/layouts/default.vue');
    try {
      await untilTransport(() => expect(heartbeat).toHaveBeenCalledTimes(1));
      expect(central.issuances).toBe(1);
      const snapshot = license.licenseStatus.value;
      const current = license.captureLicenseOperation(true);
      expect(license.isLicenseSyncing.value).toBe(true);
      expect(button(root, 'Update JWT')?.props.disabled).toBe(true);
      expect(button(root, 'Sync License')?.props.disabled).toBe(true);
      expect(text(root)).toContain(
        'License synchronization is in progress. JWT replacement is temporarily unavailable.',
      );
      // Bypass disabled controls, including the previously captured provision handler.
      showUpdate();
      await Vue.nextTick();
      expect(button(root, 'Update License')?.props.disabled).toBe(true);
      await provision();
      await button(root, 'Sync License')!.props.onClick();
      expect(handlers['license.provision']).not.toHaveBeenCalled();
      expect(handlers['license.sync']).not.toHaveBeenCalled();
      expect(handlers['license.getDeploymentConfig']).toHaveBeenCalledTimes(1);
      expect(handlers['license.submitRelay']).not.toHaveBeenCalled();
      expect(current()).toBe(true);
      expect(license.licenseStatus.value).toBe(snapshot);
      expect(license.isLicenseUpdating.value).toBe(false);
      expect(record).toEqual(initial);
      expect(
        nodes(root).find((node) => node.type === 'textarea')?.props,
      ).toMatchObject({ value: incoming, disabled: true });

      response.resolve(
        Response.json({ jwt: central.jwt, nextToken: central.nextToken }),
      );
      await untilTransport(() => {
        expect(record.nextToken).toBe(central.nextToken);
        expect(license.isLicenseSyncing.value).toBe(false);
        expect(button(root, 'Update License')?.props.disabled).toBe(false);
      });
      expect(handlers['license.releaseCourierLock']).toHaveBeenCalledTimes(1);
      expect(handlers['license.provision']).not.toHaveBeenCalled();
      expect(current()).toBe(false);
      const established = { ...record };
      expect(established).toEqual({
        ...initial,
        jwt: central.jwt,
        nextToken: central.nextToken,
      });
      expect(
        nodes(root).find((node) => node.type === 'textarea')?.props.value,
      ).toBe(incoming);

      await click(root, 'Update License');
      await Vue.nextTick();
      expect(text(root)).toContain('Invalid, forged, or expired license token');
      expect(handlers['license.provision']).toHaveBeenCalledExactlyOnceWith(
        { jwt: incoming, publicKey: 'rotated-public-key' },
        expect.objectContaining({ paths: ['license.provision'] }),
      );
      expect(handlers['license.getDeploymentConfig']).toHaveBeenCalledTimes(2);
      expect(record).toEqual(established);
      expect(central.issuances).toBe(1);
      expect(handlers['license.submitRelay']).toHaveBeenCalledTimes(1);
      expect(license.isLicenseUpdating.value).toBe(false);
      expect(license.isLicenseSyncing.value).toBe(false);
      expect(button(root, 'Update License')?.props.disabled).toBe(false);
      expect(
        nodes(root).find((node) => node.type === 'textarea')?.props.value,
      ).toBe(incoming);
      expect(currentSession()).toBe(true);
      expect(realAuth.isAuthenticated.value).toBe(true);
      expect(nuxtApp.navigateTo).not.toHaveBeenCalled();
    } finally {
      response.resolve(
        Response.json({ jwt: central.jwt, nextToken: central.nextToken }),
      );
      await untilTransport(() =>
        expect(license.isLicenseSyncing.value).toBe(false),
      );
    }
  });

  it.each(
    (['automatic', 'manual'] as const).flatMap((mode) =>
      (['account change', 'logout', 'conflict'] as const).map((change) => ({
        mode,
        change,
      })),
    ),
  )('does not replay $mode initial relay after real $change and releases for the acquiring session', async ({
    mode,
    change,
  }) => {
    const {
      pair,
      browser,
      realAuth,
      record,
      central,
      handlers,
      requests,
      rpc,
      submitRelay,
    } = installCourierTransport();
    const initial = { ...record };
    const currentSession = realAuth.captureSession();
    const replacement = {
      licenseId: 'external-license',
      jwt: 'external-jwt',
      nextToken: 'external-token',
    };
    const nextPair = signedCredentials(
      change === 'account change' ? 'B' : 'A',
      { iat: Math.floor(Date.now() / 1000) + 1 },
    );
    if (change === 'conflict') {
      const persist = handlers['license.submitRelay'].getMockImplementation()!;
      handlers['license.submitRelay'].mockImplementationOnce((value) => {
        Object.assign(record, replacement);
        browser.replace(nextPair, true);
        return persist(value);
      });
    } else {
      submitRelay.mockImplementation((value) => {
        const pending = rpc.license.submitRelay.mutate(value);
        queueMicrotask(() => {
          for (const app of apps.splice(0)) app.unmount();
          if (change === 'logout') void realAuth.logout();
          else browser.replace(nextPair, true);
        });
        return pending;
      });
    }
    const root = mountSfc('../app/pages/license/index.vue');
    await untilTransport(() =>
      expect(license.licenseStatus.value?.hintStatus).toBe('COURIER_REQUIRED'),
    );
    if (mode === 'automatic') mountSfc('../app/layouts/default.vue');
    else await click(root, 'Sync License');
    await untilTransport(() => {
      expect(handlers['license.releaseCourierLock']).toHaveBeenCalledTimes(1);
      expect(license.isLicenseSyncing.value).toBe(false);
    });
    expect(submitRelay).toHaveBeenCalledExactlyOnceWith({
      jwt: central.jwt,
      nextToken: central.nextToken,
      initialFrom: initial.jwt,
      publicKey: undefined,
    });
    expect(handlers['license.submitRelay']).toHaveBeenCalledTimes(
      change === 'conflict' ? 1 : 0,
    );
    expect(record).toEqual(change === 'conflict' ? replacement : initial);
    expect(central.issuances).toBe(1);
    expect(handlers['license.acquireCourierLock']).toHaveBeenCalledTimes(1);
    const cleanup = requests.filter((request) =>
      request.paths.includes('license.releaseCourierLock'),
    );
    expect(cleanup).toEqual([
      {
        paths: ['license.releaseCourierLock'],
        inputs: [undefined],
        authorization: `Bearer ${change === 'conflict' ? nextPair.accessToken : pair.accessToken}`,
      },
    ]);
    expect(verifyAuthToken(cleanup[0]!.authorization!.slice(7)).userId).toBe(
      'A',
    );
    expect(
      requests.filter((request) => request.paths.includes('refreshAuthToken')),
    ).toEqual([]);
    expect(license.isLicenseUpdating.value).toBe(false);
    expect(currentSession()).toBe(change === 'conflict');
    expect(realAuth.isAuthenticated.value).toBe(change !== 'logout');
    expect(browser.storage.getItem('accessToken')).toBe(
      change === 'logout' ? null : nextPair.accessToken,
    );
    expect(browser.storage.getItem('refreshToken')).toBe(
      change === 'logout' ? null : nextPair.refreshToken,
    );
    expect(nuxtApp.navigateTo).toHaveBeenCalledTimes(
      change === 'logout' ? 1 : 0,
    );
    expect(
      toast.add.mock.calls.filter(([notice]) =>
        ['green', 'success'].includes(notice.color),
      ),
    ).toEqual([]);
    if (change === 'conflict') {
      expect(console.error).toHaveBeenCalledWith(
        'Courier relay failed',
        expect.objectContaining({
          message: 'Deployment state changed',
          data: { code: 'CONFLICT', httpStatus: 409 },
        }),
      );
    }
  });
});

describe('license page mutation refresh', () => {
  it('keeps displayed REVOKED through manual Courier fallback until persistence and status verification', async () => {
    const revoked = {
      ...cachedStatus,
      status: 'REVOKED',
      hintStatus: 'REVOKED',
    } as LicenseStatus;
    const recovered = {
      ...cachedStatus,
      customerName: 'Recovered customer',
      maxAgents: 42,
    };
    const config = Object.freeze({
      licenseId: cachedStatus.licenseId,
      jwt: 'revoked-source-jwt',
      nextToken: 'current-token',
      syncStatusIndex: 41,
    });
    const preparation = deferred<{ success: true }>();
    const phase2 = deferred<Response>();
    const persistence = deferred<{ success: true }>();
    const refresh = deferred<LicenseStatus>();
    let persisted = false;
    license.licenseStatus.value = revoked;
    trpc.license.status.query.mockImplementation(() =>
      persisted ? refresh.promise : Promise.resolve(revoked),
    );
    trpc.license.sync.mutate.mockResolvedValue({
      success: false,
      requiresCourier: true,
    });
    trpc.license.getDeploymentConfig.query.mockResolvedValue(config);
    trpc.license.prepareRelay.mutate.mockReturnValueOnce(preparation.promise);
    trpc.license.submitRelay.mutate.mockImplementation(async () => {
      const result = await persistence.promise;
      persisted = true;
      return result;
    });
    fetchMock
      .mockResolvedValueOnce(Response.json({ nextToken: 'prepared-token' }))
      .mockReturnValueOnce(phase2.promise);

    const root = mountSfc('../app/pages/license/index.vue');
    await vi.advanceTimersByTimeAsync(0);
    expect(text(root)).toContain('REVOKED');
    expect(button(root, 'Sync License')?.props.disabled).toBe(false);
    expect(trpc.license.getDeploymentConfig.query).not.toHaveBeenCalled();
    const action = click(root, 'Sync License');
    try {
      await until(() =>
        expect(trpc.license.prepareRelay.mutate).toHaveBeenCalledTimes(1),
      );
      expect(trpc.license.sync.mutate).toHaveBeenCalledTimes(1);
      expect(toast.add).toHaveBeenCalledExactlyOnceWith({
        title: 'Network Unreachable',
        description: 'Attempting to sync via Courier Relay...',
        color: 'orange',
      });
      expect(trpc.license.prepareRelay.mutate.mock.calls).toStrictEqual([
        [
          {
            jwt: config.jwt,
            previousNextToken: config.nextToken,
            nextToken: 'prepared-token',
            syncStatusIndex: config.syncStatusIndex,
          },
        ],
      ]);
      expect(fetchMock).toHaveBeenCalledTimes(1);
      expect(trpc.license.submitRelay.mutate).not.toHaveBeenCalled();
      expect(license.licenseStatus.value).toEqual(revoked);
      expect(text(root)).toContain('REVOKED');

      preparation.resolve({ success: true });
      await until(() => expect(fetchMock).toHaveBeenCalledTimes(2));
      expect(license.licenseStatus.value).toEqual(revoked);
      expect(text(root)).toContain('REVOKED');
      phase2.resolve(Response.json({ jwt: 'recovered-jwt' }));
      await until(() =>
        expect(trpc.license.submitRelay.mutate).toHaveBeenCalledTimes(1),
      );
      expect(trpc.license.submitRelay.mutate.mock.calls).toStrictEqual([
        [
          {
            jwt: 'recovered-jwt',
            nextToken: 'prepared-token',
            preparedFrom: config.jwt,
            syncStatusIndex: config.syncStatusIndex,
            publicKey: undefined,
          },
        ],
      ]);
      expect(persisted).toBe(false);
      expect(trpc.license.status.query).toHaveBeenCalledTimes(1);
      expect(license.licenseStatus.value).toEqual(revoked);
      expect(text(root)).toContain('REVOKED');
      expect(toast.add).toHaveBeenCalledTimes(1);

      persistence.resolve({ success: true });
      await until(() =>
        expect(trpc.license.status.query).toHaveBeenCalledTimes(2),
      );
      expect(persisted).toBe(true);
      expect(license.licenseStatus.value).toEqual(revoked);
      expect(text(root)).toContain('REVOKED');
      expect(toast.add).toHaveBeenCalledTimes(1);
      expect(button(root, 'Sync License')?.props.disabled).toBe(true);
      refresh.resolve(recovered);
      await action;
      await Vue.nextTick();

      expect(license.licenseStatus.value).toEqual(recovered);
      expect(text(root)).toContain('SYNCED');
      expect(text(root)).not.toContain('REVOKED');
      expect(text(root)).toContain(recovered.customerName);
      expect(toast.add).toHaveBeenLastCalledWith({
        title: 'License Synced',
        description: 'License synced successfully via Courier Relay.',
        color: 'green',
      });
      expect(toast.add).toHaveBeenCalledTimes(2);
      expect(
        fetchMock.mock.calls.map(([, init]) => JSON.parse(init.body)),
      ).toStrictEqual([
        {
          phase: 1,
          licenseId: config.licenseId,
          jwt: config.jwt,
          nextToken: config.nextToken,
        },
        {
          phase: 2,
          licenseId: config.licenseId,
          jwt: config.jwt,
          nextToken: 'prepared-token',
        },
      ]);
      expect(trpc.license.getDeploymentConfig.query).toHaveBeenCalledTimes(1);
      expect(trpc.license.acquireCourierLock.mutate).toHaveBeenCalledTimes(1);
      expect(trpc.license.releaseCourierLock.mutate).toHaveBeenCalledTimes(1);
      expect(trpc.license.reportRevocation.mutate).not.toHaveBeenCalled();
      expect(trpc.license.provision.mutate).not.toHaveBeenCalled();
      expect(license.isLicenseSyncing.value).toBe(false);
      expect(license.licenseFetchError.value).toBe(false);
      expect(button(root, 'Sync License')?.props.disabled).toBe(false);
      expect(auth.logout).not.toHaveBeenCalled();
      expect(router.replace).not.toHaveBeenCalled();
      expect(nuxtApp.navigateTo).not.toHaveBeenCalled();
      expect(vi.getTimerCount()).toBe(0);
    } finally {
      preparation.resolve({ success: true });
      phase2.resolve(Response.json({ jwt: 'recovered-jwt' }));
      persistence.resolve({ success: true });
      refresh.resolve(recovered);
      await action;
      await vi.advanceTimersByTimeAsync(0);
    }
  });

  it.each([
    { name: 'provision', kind: 'provision', phase: 0 },
    { name: 'first activation', kind: 'activation', phase: 0 },
    { name: 'direct sync', kind: 'sync', phase: 0 },
    { name: 'initial courier relay', kind: 'relay', phase: 0 },
    { name: 'two-phase courier relay', kind: 'relay', phase: 2 },
    { name: 'initial courier revocation', kind: 'revocation', phase: 0 },
    { name: 'first-phase courier revocation', kind: 'revocation', phase: 1 },
    { name: 'second-phase courier revocation', kind: 'revocation', phase: 2 },
  ] as const)('fetches new status after $name without joining or being overwritten by an older poll', async ({
    kind,
    phase,
  }) => {
    const activating = kind === 'activation';
    const provisioning = activating || kind === 'provision';
    const initial = deferred<LicenseStatus>();
    const stale = deferred<LicenseStatus>();
    const fresh = deferred<LicenseStatus>();
    const mutation = deferred<{ success: boolean; requiresCourier: boolean }>();
    const query = trpc.license.status.query;
    query
      .mockReturnValueOnce(initial.promise)
      .mockReturnValueOnce(stale.promise)
      .mockReturnValueOnce(fresh.promise);
    const mutationMock = provisioning
      ? trpc.license.provision.mutate
      : kind === 'sync'
        ? trpc.license.sync.mutate
        : kind === 'relay'
          ? trpc.license.submitRelay.mutate
          : trpc.license.reportRevocation.mutate;
    mutationMock.mockReturnValueOnce(mutation.promise);
    if (provisioning) {
      fetchMock.mockResolvedValueOnce(
        new Response(JSON.stringify('test-public-key')),
      );
    } else if (kind !== 'sync') {
      trpc.license.sync.mutate.mockResolvedValue({ requiresCourier: true });
      trpc.license.getDeploymentConfig.query.mockResolvedValue({
        licenseId: cachedStatus.licenseId,
        jwt: 'current-jwt',
        nextToken: phase === 0 ? null : 'current-token',
      });
      const relayBody = JSON.stringify({
        jwt: 'renewed-jwt',
        nextToken: 'renewed-token',
      });
      fetchMock.mockImplementation(async () => new Response(relayBody));
      if (kind === 'revocation') {
        if (phase === 2)
          fetchMock.mockResolvedValueOnce(new Response(relayBody));
        fetchMock.mockResolvedValueOnce(new Response(null, { status: 403 }));
      }
    }

    const initialStatus = {
      ...cachedStatus,
      customerName: 'Current customer',
      ...(activating
        ? {
            isProvisioned: false,
            status: 'LOCKED',
            licenseId: null,
            customerName: null,
          }
        : {}),
    } as LicenseStatus;
    const freshStatus = {
      ...cachedStatus,
      customerName: 'New customer',
      licenseId: 'license-new',
      maxAgents: 42,
      status: kind === 'revocation' ? 'REVOKED' : cachedStatus.status,
    } as LicenseStatus;
    const staleStatus = activating
      ? initialStatus
      : { ...cachedStatus, customerName: 'Stale customer', maxAgents: 1 };
    let oldPoll: Promise<PromiseSettledResult<LicenseStatus>[]> | undefined;
    let action: Promise<unknown> | undefined;
    try {
      if (activating) license.licenseStatus.value = initialStatus;
      const root = mountSfc('../app/pages/license/index.vue');
      await until(() => expect(query).toHaveBeenCalledTimes(1));
      initial.resolve(initialStatus);
      await initial.promise;
      await until(() =>
        expect(text(root)).toContain(
          activating ? 'System Provisioning' : 'Current customer',
        ),
      );
      if (activating) {
        expect(Boolean(button(root, 'Activate License'))).toBe(true);
        expect(Boolean(button(root, 'Update JWT'))).toBe(false);
        expect(text(root)).not.toContain('Current Entitlements');
      }
      oldPoll = Promise.allSettled([license.fetchLicenseStatus(true)]);
      expect(query).toHaveBeenCalledTimes(2);
      if (provisioning) {
        if (!activating) click(root, 'Update JWT');
        await enterJwt(root);
        action = click(
          root,
          activating ? 'Activate License' : 'Update License',
        );
      } else {
        action = click(root, 'Sync License');
      }
      await until(() => expect(mutationMock).toHaveBeenCalledTimes(1));
      expect(trpc.license.prepareRelay.mutate).toHaveBeenCalledTimes(
        phase === 2 ? 1 : 0,
      );
      if (provisioning) {
        expect(mutationMock).toHaveBeenCalledWith({
          jwt: 'signed-license-jwt',
          publicKey: 'test-public-key',
        });
      } else if (kind === 'relay') {
        expect(mutationMock.mock.calls[0]![0]).toStrictEqual({
          jwt: 'renewed-jwt',
          nextToken: 'renewed-token',
          ...(phase === 2
            ? { preparedFrom: 'current-jwt' }
            : { initialFrom: 'current-jwt' }),
          publicKey: undefined,
        });
      }
      expect(query).toHaveBeenCalledTimes(2);
      mutation.resolve({ success: true, requiresCourier: false });
      await until(() =>
        expect(
          query,
          'post-mutation refresh must start before the old poll resolves',
        ).toHaveBeenCalledTimes(3),
      );

      fresh.resolve(freshStatus);
      await action;
      await until(() => expect(text(root)).toContain('New customer'));
      expect(license.licenseStatus.value).toEqual(freshStatus);
      expect(text(root)).toContain('Current Entitlements');
      expect(Boolean(button(root, 'Activate License'))).toBe(false);

      stale.resolve(staleStatus);
      expect(await oldPoll).toEqual([
        {
          status: 'rejected',
          reason: expect.any(operation.CancelledOperationError),
        },
      ]);
      await Vue.nextTick();
      expect(license.licenseStatus.value).toEqual(freshStatus);
      expect(text(root)).toContain('New customer');
      expect(text(root)).toContain('Current Entitlements');
      expect(Boolean(button(root, 'Activate License'))).toBe(false);
      expect(text(root)).not.toContain('Stale customer');
    } finally {
      initial.resolve(initialStatus);
      mutation.resolve({ success: true, requiresCourier: false });
      fresh.resolve(freshStatus);
      stale.resolve(staleStatus);
      await Promise.all([action, oldPoll]);
    }
  });
});

describe('activation status recovery', () => {
  it.each([
    { recovery: 'Retry Status', failedRetries: 0, failure: 'network' },
    { recovery: 'Retry Status', failedRetries: 1, failure: 'network' },
    { recovery: 'background poll', failedRetries: 0, failure: 'network' },
    { recovery: 'background poll', failedRetries: 1, failure: 'network' },
    { recovery: 'Retry Status', failedRetries: 0, failure: 'cancellation' },
  ])('keeps License applied visible after $failure through $failedRetries failed retries, then recovers via $recovery without another mutation', async ({
    recovery,
    failedRetries,
    failure,
  }) => {
    const unprovisioned = {
      ...cachedStatus,
      isProvisioned: false,
      licenseId: null,
      customerName: null,
      status: 'LOCKED',
    } as LicenseStatus;
    const query = trpc.license.status.query;
    license.licenseStatus.value = unprovisioned;
    query
      .mockResolvedValueOnce(unprovisioned)
      .mockRejectedValue(
        failure === 'cancellation'
          ? new operation.CancelledOperationError()
          : new Error('Status temporarily unavailable'),
      );
    trpc.license.provision.mutate.mockResolvedValue({ success: true });
    fetchMock.mockResolvedValueOnce(
      new Response(JSON.stringify('test-public-key')),
    );
    if (recovery === 'background poll') {
      route.path = '/license';
      mountLayout();
      await until(() => expect(vi.getTimerCount()).toBe(1));
    }
    const root = mountSfc('../app/pages/license/index.vue');
    await vi.advanceTimersByTimeAsync(0);
    expect(text(root)).toContain('System Provisioning');
    await enterJwt(root);
    await click(root, 'Activate License');
    await vi.advanceTimersByTimeAsync(0);
    expect(trpc.license.provision.mutate).toHaveBeenCalledTimes(1);
    expect(license.licenseStatus.value).toEqual(unprovisioned);
    expect
      .soft(
        toast.add.mock.calls.filter(([notice]) =>
          ['green', 'success'].includes(notice.color),
        ),
      )
      .toEqual([]);
    expect.soft(text(root)).toMatch(/License applied/i);
    expect(button(root, 'Retry Status')).toBeDefined();
    expect(text(root)).not.toContain('Current Entitlements');

    const mutations = [
      trpc.license.provision.mutate,
      trpc.license.sync.mutate,
      trpc.license.acquireCourierLock.mutate,
      trpc.license.releaseCourierLock.mutate,
      trpc.license.prepareRelay.mutate,
      trpc.license.submitRelay.mutate,
      trpc.license.reportRevocation.mutate,
    ];
    const writes = mutations.map((mock) => mock.mock.calls.length);
    expect(writes).toEqual([1, 0, 0, 0, 0, 0, 0]);
    await vi.advanceTimersByTimeAsync(60_000);
    expect(text(root)).toMatch(/License applied/i);
    expect(button(root, 'Retry Status')).toBeDefined();

    for (let attempt = 0; attempt < failedRetries; attempt++) {
      const reads = [trpc.me.query.mock.calls.length, query.mock.calls.length];
      await click(root, 'Retry Status');
      await vi.advanceTimersByTimeAsync(0);
      expect([
        trpc.me.query.mock.calls.length,
        query.mock.calls.length,
      ]).toEqual(reads.map((count) => count + 1));
      expect(mutations.map((mock) => mock.mock.calls.length)).toEqual(writes);
      expect(text(root)).toMatch(/License applied/i);
      expect(button(root, 'Retry Status')?.props.disabled).not.toBe(true);
      expect(
        toast.add.mock.calls.filter(([notice]) =>
          ['green', 'success'].includes(notice.color),
        ),
      ).toEqual([]);
    }

    const fresh = deferred<LicenseStatus>();
    const recovered = {
      ...cachedStatus,
      customerName: 'Activated customer',
      maxAgents: 42,
    };
    query.mockReturnValueOnce(fresh.promise);
    const reads = [trpc.me.query.mock.calls.length, query.mock.calls.length];
    const retry =
      recovery === 'Retry Status' ? click(root, 'Retry Status') : undefined;
    if (recovery === 'background poll') vi.advanceTimersByTime(60_000);
    try {
      await until(() => expect(query).toHaveBeenCalledTimes(reads[1]! + 1));
      expect(trpc.me.query).toHaveBeenCalledTimes(
        reads[0]! + (recovery === 'Retry Status' ? 1 : 0),
      );
      expect(text(root)).toMatch(/License applied/i);
      expect(mutations.map((mock) => mock.mock.calls.length)).toEqual(writes);
      fresh.resolve(recovered);
      await retry;
      await until(() => expect(text(root)).toContain('Activated customer'));
      expect(text(root)).toContain('Current Entitlements');
      expect(text(root)).not.toMatch(/License applied/i);
      expect(button(root, 'Retry Status')).toBeUndefined();
      expect(button(root, 'Activate License')).toBeUndefined();
      expect(license.licenseStatus.value).toEqual(recovered);
      expect(mutations.map((mock) => mock.mock.calls.length)).toEqual(writes);
      expect(trpc.license.getDeploymentConfig.query).not.toHaveBeenCalled();
      expect(fetchMock).toHaveBeenCalledTimes(1);
      expect(auth.logout).not.toHaveBeenCalled();
    } finally {
      fresh.resolve(recovered);
      await retry;
      await vi.advanceTimersByTimeAsync(0);
    }
  });

  it.each([
    'post-provision status',
    'post-provision me',
    'Retry Status',
  ])('logs out on unauthorized %s without subsequent success or partial-success feedback', async (source) => {
    const unprovisioned = {
      ...cachedStatus,
      isProvisioned: false,
      licenseId: null,
    } as LicenseStatus;
    const unauthorized = Object.assign(new TRPCClientError('Session expired'), {
      data: { code: 'UNAUTHORIZED' },
    });
    license.licenseStatus.value = unprovisioned;
    trpc.license.status.query.mockResolvedValue(unprovisioned);
    trpc.license.provision.mutate.mockResolvedValue({ success: true });
    fetchMock.mockResolvedValueOnce(
      new Response(JSON.stringify('test-public-key')),
    );
    const root = mountSfc('../app/pages/license/index.vue');
    await vi.advanceTimersByTimeAsync(0);
    await enterJwt(root);
    if (source === 'post-provision me') {
      trpc.me.query.mockRejectedValueOnce(unauthorized);
    } else {
      trpc.license.status.query.mockRejectedValueOnce(
        source === 'Retry Status'
          ? new Error('Temporary outage')
          : unauthorized,
      );
    }
    await click(root, 'Activate License');
    if (source === 'Retry Status') {
      expect(text(root)).toMatch(/License applied/i);
      toast.add.mockClear();
      trpc.license.status.query.mockRejectedValueOnce(unauthorized);
      await click(root, 'Retry Status');
    }
    await until(() => expect(auth.logout).toHaveBeenCalledTimes(1));
    await vi.advanceTimersByTimeAsync(0);
    expect(auth.isAuthenticated.value).toBe(false);
    expect(license.licenseStatus.value).toBeNull();
    expect(text(root)).not.toMatch(/License applied/i);
    expect(button(root, 'Retry Status')).toBeUndefined();
    expect(toast.add).not.toHaveBeenCalled();
    expect(trpc.license.provision.mutate).toHaveBeenCalledTimes(1);
    expect(trpc.license.sync.mutate).not.toHaveBeenCalled();
    expect(trpc.license.acquireCourierLock.mutate).not.toHaveBeenCalled();
  });
});
