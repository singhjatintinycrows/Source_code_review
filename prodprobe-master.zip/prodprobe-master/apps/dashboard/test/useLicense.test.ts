import { beforeEach, describe, expect, it, vi } from 'vitest';
import { useLicense } from '../app/composables/useLicense';
import { CancelledOperationError } from '../app/utils/operation';
import { useNuxtApp } from './nuxt-app';

type LicenseStatus = NonNullable<
  ReturnType<typeof useLicense>['licenseStatus']['value']
>;

function deferred<T>() {
  let resolve!: (value: T) => void;
  let reject!: (error: unknown) => void;
  const promise = new Promise<T>((res, rej) => {
    resolve = res;
    reject = rej;
  });
  return { promise, resolve, reject };
}

const cachedStatus = {
  isProvisioned: true,
  status: 'SYNCED',
  hintStatus: 'SYNCED',
  licenseId: 'test-license',
  customerName: 'Test customer',
  maxAgents: 5,
  softAgentLimit: 10,
  expiryDate: null,
  upgradeRequired: false,
} as LicenseStatus;

describe('useLicense', () => {
  const query = vi.fn();

  beforeEach(() => {
    query.mockReset();
    useNuxtApp.mockReturnValue({ $trpc: { license: { status: { query } } } });
    useLicense().clearLicense();
  });

  it('fetches license status and caches result', async () => {
    const license = useLicense();
    const mockStatus = { isProvisioned: true, status: 'SYNCED' } as any;
    query.mockResolvedValue(mockStatus);

    const res1 = await license.fetchLicenseStatus();
    expect(res1).toStrictEqual(mockStatus);
    expect(license.licenseStatus.value).toStrictEqual(mockStatus);
    expect(license.licenseFetchError.value).toBe(false);

    // Second call without force should return cached value without querying again
    const res2 = await license.fetchLicenseStatus();
    expect(res2).toStrictEqual(mockStatus);
    expect(query).toHaveBeenCalledTimes(1);
  });

  it('deduplicates concurrent in-flight fetch requests', async () => {
    const license = useLicense();
    const mockStatus = { isProvisioned: false } as any;
    query.mockResolvedValue(mockStatus);

    const [s1, s2] = await Promise.all([
      license.fetchLicenseStatus(),
      license.fetchLicenseStatus(),
    ]);

    expect(s1).toStrictEqual(mockStatus);
    expect(s2).toStrictEqual(mockStatus);
    expect(query).toHaveBeenCalledTimes(1);
  });

  it('sets licenseFetchError on query failure and resets on success', async () => {
    const license = useLicense();
    const error = new Error('Network error');
    query.mockRejectedValue(error);

    await expect(license.fetchLicenseStatus()).rejects.toBe(error);
    expect(license.licenseFetchError.value).toBe(true);

    const mockStatus = { isProvisioned: true } as any;
    query.mockResolvedValue(mockStatus);

    const recovered = await license.fetchLicenseStatus(true);
    expect(recovered).toStrictEqual(mockStatus);
    expect(license.licenseFetchError.value).toBe(false);
  });

  it('clears state with clearLicense', async () => {
    const license = useLicense();
    const mockStatus = { isProvisioned: true } as any;
    query.mockResolvedValue(mockStatus);

    await license.fetchLicenseStatus();
    expect(license.licenseStatus.value).toStrictEqual(mockStatus);

    license.clearLicense();
    expect(license.licenseStatus.value).toBeNull();
    expect(license.licenseFetchError.value).toBe(false);
  });

  it('discards fetched license if clearLicense was called while query was in-flight', async () => {
    const license = useLicense();
    let resolveQuery!: (val: any) => void;
    query.mockReturnValue(
      new Promise((resolve) => {
        resolveQuery = resolve;
      }),
    );

    const fetchPromise = license.fetchLicenseStatus();
    license.clearLicense();

    resolveQuery({ isProvisioned: true, status: 'SYNCED' });
    await expect(fetchPromise).rejects.toBeInstanceOf(CancelledOperationError);

    expect(license.licenseStatus.value).toBeNull();
  });

  it('deduplicates concurrent refreshes even when cached data exists', async () => {
    const license = useLicense();
    query.mockResolvedValueOnce(cachedStatus);
    await license.fetchLicenseStatus();

    const pending = deferred<LicenseStatus>();
    query.mockReturnValueOnce(pending.promise);
    const first = license.fetchLicenseStatus(true);
    const second = license.fetchLicenseStatus(true);
    expect(query).toHaveBeenCalledTimes(2);

    const refreshed = { ...cachedStatus, maxAgents: 20 };
    pending.resolve(refreshed);
    expect(await first).toEqual(refreshed);
    expect(await second).toEqual(refreshed);
    expect(license.licenseStatus.value).toEqual(refreshed);
  });

  it('keeps a refresh failure visible when reading the cached snapshot', async () => {
    const license = useLicense();
    query.mockResolvedValueOnce(cachedStatus);
    await license.fetchLicenseStatus();
    const error = new Error('Temporary outage');
    query.mockRejectedValueOnce(error);

    await expect(license.fetchLicenseStatus(true)).rejects.toBe(error);
    expect(await license.fetchLicenseStatus()).toEqual(cachedStatus);
    expect(query).toHaveBeenCalledTimes(2);
    expect(license.licenseFetchError.value).toBe(true);
  });

  it.each([
    'sync',
    'update',
  ] as const)('shares a non-invalidating reservation across instances with %s first', async (owner) => {
    const first = useLicense();
    const second = useLicense();
    query.mockResolvedValueOnce(cachedStatus);
    await first.fetchLicenseStatus();
    const current = first.captureLicenseOperation(true);
    const pending = deferred<LicenseStatus>();
    query.mockReturnValueOnce(pending.promise);
    const read = first.fetchLicenseStatus(true);
    const finish =
      owner === 'sync' ? first.beginLicenseSync() : first.beginLicenseUpdate();

    try {
      expect(finish).toBeTypeOf('function');
      for (const instance of [first, second]) {
        expect(instance.isLicenseSyncing.value).toBe(owner === 'sync');
        expect(instance.isLicenseUpdating.value).toBe(owner === 'update');
        expect(instance.beginLicenseSync()).toBeUndefined();
        expect(instance.beginLicenseUpdate()).toBeUndefined();
      }
      expect(current()).toBe(true);
      expect(first.licenseStatus.value).toEqual(cachedStatus);
      const joined = second.fetchLicenseStatus(true);
      expect(query).toHaveBeenCalledTimes(2);
      const refreshed = { ...cachedStatus, maxAgents: 42 };
      pending.resolve(refreshed);
      expect(await read).toEqual(refreshed);
      expect(await joined).toEqual(refreshed);
      expect(second.licenseStatus.value).toEqual(refreshed);
      expect(second.licenseFetchError.value).toBe(false);

      finish!();
      expect(first.isLicenseSyncing.value).toBe(false);
      expect(first.isLicenseUpdating.value).toBe(false);
      const successor =
        owner === 'sync'
          ? second.beginLicenseUpdate()
          : second.beginLicenseSync();
      expect(successor).toBeTypeOf('function');
      finish!();
      expect(first.isLicenseSyncing.value).toBe(owner === 'update');
      expect(first.isLicenseUpdating.value).toBe(owner === 'sync');
      successor!();
      expect(first.isLicenseSyncing.value).toBe(false);
      expect(first.isLicenseUpdating.value).toBe(false);
      expect(current()).toBe(true);
    } finally {
      pending.resolve(cachedStatus);
      await read;
      finish?.();
    }
  });

  it('discards a preflight status read only when the update caller explicitly invalidates', async () => {
    const license = useLicense();
    query.mockResolvedValueOnce(cachedStatus);
    await license.fetchLicenseStatus();
    const current = license.captureLicenseOperation(true);
    const pending = deferred<LicenseStatus>();
    query.mockReturnValueOnce(pending.promise);
    const read = Promise.allSettled([license.fetchLicenseStatus(true)]);
    const finish = license.beginLicenseUpdate();
    try {
      expect(finish).toBeTypeOf('function');
      expect(current()).toBe(true);
      expect(await license.fetchLicenseStatus()).toEqual(cachedStatus);
      expect(query).toHaveBeenCalledTimes(2);

      license.invalidateLicenseStatus();
      expect(current()).toBe(false);
      expect(license.isLicenseUpdating.value).toBe(true);
      expect(license.licenseStatus.value).toEqual(cachedStatus);
      const updated = { ...cachedStatus, licenseId: 'replacement-license' };
      query.mockResolvedValueOnce(updated);
      expect(await license.fetchLicenseStatus()).toEqual(updated);
      expect(query).toHaveBeenCalledTimes(3);
      pending.resolve(cachedStatus);
      expect(await read).toEqual([
        { status: 'rejected', reason: expect.any(CancelledOperationError) },
      ]);
      expect(license.licenseStatus.value).toEqual(updated);
      expect(license.licenseFetchError.value).toBe(false);
    } finally {
      pending.resolve(cachedStatus);
      await read;
      finish?.();
    }
  });

  it.each(
    (['beginLicenseSync', 'beginLicenseUpdate'] as const).flatMap((owner) =>
      (['beginLicenseSync', 'beginLicenseUpdate'] as const).map(
        (successor) => ({
          owner,
          successor,
        }),
      ),
    ),
  )('clear resets $owner and its stale cleanup cannot finish $successor', async ({
    owner,
    successor,
  }) => {
    const first = useLicense();
    const second = useLicense();
    first.licenseStatus.value = cachedStatus;
    first.licenseFetchError.value = true;
    const current = first.captureLicenseOperation(true);
    const pending = deferred<LicenseStatus>();
    query.mockReturnValueOnce(pending.promise);
    const read = Promise.allSettled([first.fetchLicenseStatus(true)]);
    const finish = first[owner]();
    try {
      expect(finish).toBeTypeOf('function');
      second.clearLicense();
      expect(first.isLicenseSyncing.value).toBe(false);
      expect(first.isLicenseUpdating.value).toBe(false);
      expect(first.licenseStatus.value).toBeNull();
      expect(first.licenseFetchError.value).toBe(false);
      expect(current()).toBe(false);

      const finishSuccessor = second[successor]();
      expect(finishSuccessor).toBeTypeOf('function');
      finish!();
      finish!();
      expect(first.isLicenseSyncing.value).toBe(
        successor === 'beginLicenseSync',
      );
      expect(first.isLicenseUpdating.value).toBe(
        successor === 'beginLicenseUpdate',
      );
      expect(first.beginLicenseSync()).toBeUndefined();
      expect(first.beginLicenseUpdate()).toBeUndefined();
      pending.resolve(cachedStatus);
      expect(await read).toEqual([
        { status: 'rejected', reason: expect.any(CancelledOperationError) },
      ]);
      expect(second.licenseStatus.value).toBeNull();
      expect(second.licenseFetchError.value).toBe(false);
      finishSuccessor!();
      expect(first.isLicenseSyncing.value).toBe(false);
      expect(first.isLicenseUpdating.value).toBe(false);
    } finally {
      pending.resolve(cachedStatus);
      await read;
      finish?.();
    }
  });

  it.each([
    { outcome: 'resolve', order: 'before' },
    { outcome: 'reject', order: 'before' },
    { outcome: 'resolve', order: 'after' },
    { outcome: 'reject', order: 'after' },
  ] as const)('ignores an invalidated read that will $outcome $order the post-mutation read', async ({
    outcome,
    order,
  }) => {
    const license = useLicense();
    query.mockResolvedValueOnce(cachedStatus);
    await license.fetchLicenseStatus();

    const stale = deferred<LicenseStatus>();
    const fresh = deferred<LicenseStatus>();
    query.mockReturnValueOnce(stale.promise).mockReturnValueOnce(fresh.promise);
    const oldRead = license.fetchLicenseStatus(true).catch((error) => {
      expect(error).toBeInstanceOf(CancelledOperationError);
    });
    const updatedStatus = { ...cachedStatus, maxAgents: 42 };
    let newRead: Promise<LicenseStatus> | undefined;

    try {
      license.invalidateLicenseStatus();
      expect(license.licenseStatus.value).toEqual(cachedStatus);
      newRead = license.fetchLicenseStatus();
      expect(query).toHaveBeenCalledTimes(3);

      if (order === 'after') {
        fresh.resolve(updatedStatus);
        await newRead;
      }

      if (outcome === 'resolve') stale.resolve(cachedStatus);
      else stale.reject(new Error('Stale request failed'));
      await oldRead;
      expect(license.licenseFetchError.value).toBe(false);

      if (order === 'before') {
        const joinedRead = license.fetchLicenseStatus(true);
        expect(query).toHaveBeenCalledTimes(3);
        fresh.resolve(updatedStatus);
        expect(await joinedRead).toEqual(updatedStatus);
      }

      expect(await newRead).toEqual(updatedStatus);
      expect(license.licenseStatus.value).toEqual(updatedStatus);
      expect(license.licenseFetchError.value).toBe(false);
      expect(query).toHaveBeenCalledTimes(3);
    } finally {
      stale.resolve(cachedStatus);
      fresh.resolve(updatedStatus);
      await Promise.all([oldRead, newRead]);
    }
  });
});
