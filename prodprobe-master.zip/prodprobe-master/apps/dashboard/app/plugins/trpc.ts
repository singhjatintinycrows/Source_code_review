import {
  createTRPCProxyClient,
  httpLink,
  TRPCClientError,
  type TRPCLink,
} from '@trpc/client';
import { observable } from '@trpc/server/observable';
import superjson from 'superjson';
import { defineNuxtPlugin, useRuntimeConfig } from '#app';
import type { AppRouter } from '../../../backend/src/index';
import {
  type AuthCredentials,
  captureAuthCredentials,
  writeAuthTokens,
} from '../composables/useAuth';
import { CancelledOperationError } from '../utils/operation';
import { isTokenExpired, isTokenExpiringSoon } from '../utils/token';
import { isUnauthorizedError } from '../utils/trpc';

export default defineNuxtPlugin((_nuxtApp: any) => {
  const { trpcUrl } = useRuntimeConfig().public;

  const authClient = createTRPCProxyClient<AppRouter>({
    transformer: superjson,
    links: [
      httpLink({
        url: trpcUrl,
      }),
    ],
  });

  let renewal: { version: number; promise: Promise<AuthCredentials> } | null =
    null;

  async function ensureValidAccessToken(origin: AuthCredentials) {
    if (!origin.isUnchanged() || !origin.isAuthenticated)
      throw new CancelledOperationError();
    if (!isTokenExpiringSoon(origin.accessToken)) return origin;
    if (renewal?.version === origin.version) return renewal.promise;
    const pending = authClient.refreshAuthToken
      .mutate({ refreshToken: origin.refreshToken })
      .then((response) => {
        if (!origin.isUnchanged()) throw new CancelledOperationError();
        if (!response.accessToken) throw new Error('Failed to refresh token');
        return writeAuthTokens({ accessToken: response.accessToken }, origin);
      })
      .catch((error) => {
        if (!origin.isUnchanged()) throw new CancelledOperationError();
        if (isUnauthorizedError(error)) {
          writeAuthTokens({ accessToken: '', refreshToken: '' }, origin, {
            boundary: true,
          });
          window.location.href = '/dashboard/#/login';
        }
        throw error;
      })
      .finally(() => {
        if (renewal?.promise === pending) renewal = null;
      });
    renewal = { version: origin.version, promise: pending };
    return pending;
  }

  async function ensureCleanupAccessToken(owner: AuthCredentials) {
    // Resolve authentication before dispatch; an ambiguous lock release must not be replayed.
    while (owner.isCurrent()) {
      const current = captureAuthCredentials();
      if (!owner.isCurrent()) break;
      try {
        const sent = await ensureValidAccessToken(current);
        if (!owner.isCurrent()) break;
        if (!sent.isUnchanged()) continue;
        return sent;
      } catch (error) {
        if (!owner.isCurrent()) break;
        if (!current.isUnchanged()) continue;
        // A failed proactive renewal need not prevent cleanup with a still-valid bearer.
        if (!isTokenExpired(current.accessToken)) return current;
        throw error;
      }
    }
    return owner;
  }

  const sessionLink: TRPCLink<AppRouter> = (runtime) => {
    const courierLeases = new WeakMap<object, AuthCredentials>();
    let transport:
      | {
          key: string;
          link: ReturnType<TRPCLink<AppRouter>>;
        }
      | undefined;
    return ({ op, next }) => {
      // Capture before asynchronous authentication or transport work starts.
      const lease = op.context.courierLease;
      const leaseHandle =
        lease && typeof lease === 'object' ? lease : undefined;
      const cleanup =
        op.path === 'license.releaseCourierLock' && leaseHandle
          ? courierLeases.get(leaseHandle)
          : undefined;
      if (cleanup && leaseHandle) courierLeases.delete(leaseHandle);
      const origin = cleanup ?? captureAuthCredentials();
      const anonymous = [
        'verifySso',
        'refresh',
        'refreshAuthToken',
        'getUserCount',
        'pollLogin',
      ].includes(op.path);
      return observable((observer) => {
        let disposed = false;
        let subscription: { unsubscribe: () => void } | undefined;
        const authorization = cleanup
          ? ensureCleanupAccessToken(cleanup)
          : anonymous
            ? Promise.resolve(origin)
            : ensureValidAccessToken(origin);
        void authorization
          .then((sent) => {
            if (disposed) return;
            if (!cleanup && (!origin.isCurrent() || !sent.isUnchanged()))
              throw new CancelledOperationError();
            const key = `${sent.version}:${anonymous}:${Boolean(cleanup)}`;
            if (transport?.key !== key) {
              transport = {
                key,
                link: httpLink<AppRouter>({
                  url: trpcUrl,
                  headers: () => {
                    if (!cleanup && !sent.isUnchanged())
                      throw new CancelledOperationError();
                    return anonymous
                      ? {}
                      : { authorization: `Bearer ${sent.accessToken}` };
                  },
                  fetch: (url, options) => {
                    // tRPC awaits headers before fetch; reconcile again across that async gap.
                    if (!cleanup && !sent.isUnchanged())
                      return Promise.reject(new CancelledOperationError());
                    return fetch(url, options);
                  },
                })(runtime),
              };
            }
            subscription = transport.link({ op, next }).subscribe({
              next(value) {
                const data =
                  'data' in value.result ? value.result.data : undefined;
                const acquired =
                  op.path === 'license.acquireCourierLock' &&
                  leaseHandle &&
                  data &&
                  typeof data === 'object' &&
                  'success' in data &&
                  data.success === true;
                // Only confirmed lease cleanup may use the original bearer after cancellation.
                if (acquired) courierLeases.set(leaseHandle, sent);
                if (!origin.isCurrent() && !acquired && !cleanup)
                  observer.error(
                    TRPCClientError.from(new CancelledOperationError()),
                  );
                else observer.next(value);
              },
              error(error) {
                observer.error(
                  !cleanup &&
                    (!origin.isCurrent() ||
                      (isUnauthorizedError(error) && !sent.isUnchanged()))
                    ? TRPCClientError.from(new CancelledOperationError())
                    : error,
                );
              },
              complete() {
                observer.complete();
              },
            });
          })
          .catch((error) => {
            observer.error(
              TRPCClientError.from(
                cleanup || origin.isCurrent()
                  ? error
                  : new CancelledOperationError(),
              ),
            );
          });
        return () => {
          disposed = true;
          subscription?.unsubscribe();
        };
      });
    };
  };

  const trpc = createTRPCProxyClient<AppRouter>({
    transformer: superjson,
    links: [sessionLink],
  });

  return {
    provide: {
      trpc,
    },
  };
});
