import { defineNuxtRouteMiddleware, navigateTo } from '#app';
import {
  captureAuthCredentials,
  useAuth,
  writeAuthTokens,
} from '../composables/useAuth';
import { isTokenExpired } from '../utils/token';

export default defineNuxtRouteMiddleware((to, _from) => {
  const { isAuthenticated, refreshToken, logout } = useAuth();
  const origin = captureAuthCredentials();

  // If refresh token is expired, log out and redirect to login page
  if (origin.sessionKey && isTokenExpired(refreshToken.value)) {
    if (to.path === '/login') {
      writeAuthTokens({ accessToken: '', refreshToken: '' }, origin, {
        boundary: true,
      });
    } else {
      return logout();
    }
  }

  // If user tries to access a protected route without a token
  if (!isAuthenticated.value && to.path !== '/login') {
    return navigateTo('/login');
  }

  // If user is already logged in and tries to hit the login page
  if (isAuthenticated.value && to.path === '/login' && !to.query.identifier) {
    return navigateTo('/services');
  }

  if (isAuthenticated.value && to.path === '/') {
    return navigateTo('/services');
  }
});
