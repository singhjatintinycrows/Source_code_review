<template>
  <div class="space-y-6">
      <div class="flex flex-col gap-4">
        <div class="flex justify-between items-center">
          <h1 class="text-2xl font-bold text-gray-900 dark:text-white">Users</h1>
          <div class="flex items-center gap-2">
            <UButton color="neutral" variant="outline" icon="i-heroicons-arrow-path" @click="refreshUsers"
              :loading="isLoadingUsers">Refresh</UButton>
            <UButton color="secondary" @click="openCreateModal" icon="i-heroicons-user-plus">Add User</UButton>
          </div>
        </div>
        <div
          class="flex items-center gap-4 flex-wrap bg-white dark:bg-gray-900 p-4 rounded-lg border border-gray-200 dark:border-gray-800">
          <UFormField label="Email">
            <UInput v-model="filters.email" icon="i-heroicons-magnifying-glass" placeholder="Filter by Email"
              class="w-48" @update:model-value="onSearch" />
          </UFormField>
          <UFormField label="Teams">
            <USelectMenu v-model="filters.teamIds" :items="allTeams" value-key="id" label-key="name" multiple
              placeholder="Filter by Teams" class="w-48" @update:model-value="onSearch" />
          </UFormField>
        </div>
      </div>

      <UCard>
        <div class="overflow-x-auto">
          <table class="w-full text-left text-sm text-gray-500 dark:text-gray-400">
            <thead class="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-800 dark:text-gray-400">
              <tr>
                <th scope="col" class="px-6 py-3">Email</th>
                <th scope="col" class="px-6 py-3">Teams</th>
                <th scope="col" class="px-6 py-3 text-right">Actions</th>
              </tr>
            </thead>
            <tbody>
              <tr v-for="user in users" :key="user.id"
                class="bg-white border-b dark:bg-gray-900 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-800">
                <td class="px-6 py-4 text-gray-900 dark:text-white flex items-center gap-1 group">
                  {{ user.email }}
                  <CopyToClipboard :text="user.email" title="Email" />
                </td>
                <td class="px-6 py-4 space-x-1">
                  <UBadge v-for="ut in user.teams" :key="ut.teamId"
                    :color="ut.team?.isAdminTeam ? 'success' : 'neutral'" variant="subtle">
                    {{ ut.team?.name || 'Unknown Team' }}
                  </UBadge>
                </td>
                <td class="px-6 py-4 text-right space-x-2">
                  <UButton size="sm" color="neutral" variant="ghost" icon="i-heroicons-pencil"
                    @click="openEditModal(user)" />
                  <UButton size="sm" color="error" variant="ghost" icon="i-heroicons-trash"
                    @click="openDeleteModal(user)" />
                </td>
              </tr>
              <tr v-if="users.length === 0">
                <td colspan="3" class="px-6 py-4 text-center">No users found.</td>
              </tr>
            </tbody>
          </table>
        </div>
        <div class="flex justify-end py-4 border-t border-gray-200 dark:border-gray-800" v-if="totalUsers > 0">
          <p class="text-sm text-gray-500 dark:text-gray-400 mt-1.5">Total: {{ totalUsers }}</p>
          &nbsp;&nbsp;&nbsp;
          <UPagination v-model:page="currentPage" :items-per-page="limit" :total="totalUsers"
            @update:page="loadUsers" />
        </div>
      </UCard>

      <!-- Create / Edit Modal -->
      <UModal v-model:open="isModalOpen">
        <template #content>
          <UCard :ui="{ divide: 'divide-y divide-gray-100 dark:divide-gray-800' }">
            <template #header>
              <div class="flex items-center justify-between">
                <h3 class="text-base font-semibold leading-6 text-gray-900 dark:text-white">
                  {{ isEditing ? 'Edit User' : 'Add User' }}
                </h3>
                <UButton color="neutral" variant="ghost" icon="i-heroicons-x-mark-20-solid" class="-my-1"
                  @click="isModalOpen = false" />
              </div>
            </template>

            <form @submit.prevent="saveUser" class="space-y-4">
              <UFormField label="User Email" required>
                <UInput v-model="formState.email" type="email" placeholder="user@example.com" required
                  class="w-[240px]" />
              </UFormField>

              <UFormField label="Assign Teams" required>
                <USelectMenu v-model="formState.selectedTeams" :items="allTeams" value-key="id" label-key="name"
                  multiple placeholder="Select teams..." class="w-[240px]" />
              </UFormField>

              <div v-if="validationError" class="text-red-500 text-sm mt-2">
                {{ validationError }}
              </div>

              <div class="flex justify-end pt-4 space-x-3">
                <UButton color="neutral" variant="soft" @click="isModalOpen = false">Cancel</UButton>
                <UButton type="submit" color="secondary" :loading="isSaving">Save</UButton>
              </div>
            </form>
          </UCard>
        </template>
      </UModal>

      <!-- Delete Confirmation Modal -->
      <CommonDeleteModal v-model:open="isDeleteModalOpen" title="Delete User" :loading="isDeleting"
        @confirm="confirmDelete">
        Are you sure you want to delete the user <strong class="text-gray-900 dark:text-white">{{ userToDelete?.email
          }}</strong>? This action cannot be undone.
      </CommonDeleteModal>
      <Loader :loading="isLoadingUsers" label="Loading users..." />
    </div>
</template>

<script setup lang="ts">
import type { inferRouterOutputs } from '@trpc/server';
import { useDebounceFn } from '@vueuse/core';
import { computed, onMounted, ref, watch } from 'vue';
import { useNuxtApp, useRoute, useRouter } from '#app';
import type { AppRouter } from '../../../../backend/src/index';
import CopyToClipboard from '../../components/CopyToClipboard.vue';
import Loader from '../../components/Loader.vue';
import { useAppToast } from '../../composables/useAppToast';
import { useTeamsStore } from '../../stores/teams';

type RouterOutput = inferRouterOutputs<AppRouter>;
const { $trpc } = useNuxtApp();
const route = useRoute();
const router = useRouter();
const toast = useAppToast();

const users = ref<RouterOutput['users']['list']['data']>([]);
const teamsStore = useTeamsStore();
const allTeams = computed(() => teamsStore.teams);

const parseArray = (val: any) => {
  if (!val) return [];
  return Array.isArray(val) ? val : [val];
};

const filters = ref({
  email: (route.query.email as string) || '',
  teamIds: parseArray(route.query.teamIds),
});

const currentPage = ref(Number(route.query.page) || 1);
const limit = ref(10);
const totalUsers = ref(0);

watch(
  [filters, currentPage],
  () => {
    const query = { ...route.query };

    if (filters.value.email) query.email = filters.value.email;
    else delete query.email;

    const parsedTeamIds = filters.value.teamIds.map((t: any) =>
      typeof t === 'object' ? t.id : t,
    );
    if (parsedTeamIds.length > 0) query.teamIds = parsedTeamIds;
    else delete query.teamIds;

    if (currentPage.value > 1) query.page = String(currentPage.value);
    else delete query.page;

    router.replace({ query });
  },
  { deep: true },
);

const isModalOpen = ref(false);
const isEditing = ref(false);
const isSaving = ref(false);
const validationError = ref('');

const isDeleteModalOpen = ref(false);
const isDeleting = ref(false);
const userToDelete = ref<RouterOutput['users']['list'][0] | null>(null);

const formState = ref({
  id: '',
  email: '',
  selectedTeams: [] as string[],
});

const isLoadingUsers = ref(false);

const refreshUsers = async () => {
  isLoadingUsers.value = true;
  try {
    await loadUsers(false);
    await teamsStore.fetchTeams();
    toast.showSuccess('Success', 'Users data refreshed successfully');
  } catch (error) {
    console.error('Failed to refresh users:', error);
    toast.showError('Error', 'Failed to refresh users data.');
  } finally {
    isLoadingUsers.value = false;
  }
};

const loadUsers = async (setLoading = true) => {
  if (setLoading) {
    isLoadingUsers.value = true;
  }
  try {
    const parsedTeamIds = filters.value.teamIds.map((t: any) =>
      typeof t === 'object' ? t.id : t,
    );

    const response = await $trpc.users.list.query({
      email: filters.value.email || undefined,
      teamIds: parsedTeamIds.length > 0 ? parsedTeamIds : undefined,
      limit: limit.value,
      offset: (currentPage.value - 1) * limit.value,
    });

    users.value = response.data;
    totalUsers.value = response.total;
  } catch (error) {
    console.error('Failed to load users:', error);
    toast.showError('Error', 'Failed to load users data.');
  } finally {
    if (setLoading) {
      isLoadingUsers.value = false;
    }
  }
};

const onSearch = useDebounceFn(async () => {
  currentPage.value = 1;
  await loadUsers();
}, 300);

onMounted(async () => {
  await loadUsers();
  await teamsStore.fetchTeams();
});

const openCreateModal = () => {
  isEditing.value = false;
  formState.value = { id: '', email: '', selectedTeams: [] };
  validationError.value = '';
  isModalOpen.value = true;
};

const openEditModal = (user: RouterOutput['users']['list'][0]) => {
  isEditing.value = true;
  formState.value = {
    id: user.id,
    email: user.email,
    selectedTeams: user.teams.map((t) => t.teamId),
  };
  validationError.value = '';
  isModalOpen.value = true;
};

const saveUser = async () => {
  validationError.value = '';
  if (!formState.value.email.trim()) return;
  if (formState.value.selectedTeams.length === 0) {
    validationError.value = 'Please select at least one team.';
    return;
  }

  isSaving.value = true;
  try {
    if (isEditing.value) {
      await $trpc.users.update.mutate({
        userId: formState.value.id,
        email: formState.value.email,
        teamIds: formState.value.selectedTeams,
      });
      toast.showSuccess('Success', 'User updated successfully');
    } else {
      await $trpc.users.create.mutate({
        email: formState.value.email,
        teamIds: formState.value.selectedTeams,
      });
      toast.showSuccess('Success', 'User created successfully');
    }
    isModalOpen.value = false;
    await loadUsers();
  } catch (error: any) {
    console.error('Failed to save user:', error);
    validationError.value = (error as Error).message || 'Failed to save user.';
    toast.showError('Operation Failed', validationError.value);
  } finally {
    isSaving.value = false;
  }
};

const openDeleteModal = (user: RouterOutput['users']['list'][0]) => {
  userToDelete.value = user;
  isDeleteModalOpen.value = true;
};

const confirmDelete = async () => {
  if (!userToDelete.value) return;

  isDeleting.value = true;
  try {
    await $trpc.users.delete.mutate({ userId: userToDelete.value.id });
    toast.showSuccess('Success', 'User deleted successfully');
    isDeleteModalOpen.value = false;
    userToDelete.value = null;
    await loadUsers();
  } catch (error: any) {
    console.error('Failed to delete user:', error);
    toast.showError(
      'Deletion Failed',
      (error as Error).message || 'An error occurred while deleting the user.',
    );
  } finally {
    isDeleting.value = false;
  }
};
</script>
