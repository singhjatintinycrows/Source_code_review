<template>
  <!-- Loading State -->
  <div v-if="loading || (isAuthenticated && !user && !userFetchError && !pageFetchError)" class="flex justify-center p-12 mt-12">
    <UIcon name="i-heroicons-arrow-path" class="w-8 h-8 animate-spin text-gray-400" />
  </div>

  <!-- Fetch Error View -->
  <div v-else-if="pageFetchError || (isAuthenticated && !user && userFetchError)" class="max-w-2xl mx-auto mt-12">
    <UCard>
      <div class="text-center py-8">
        <UIcon name="i-heroicons-exclamation-triangle" class="w-16 h-16 text-red-500 mx-auto mb-4" />
        <h2 class="text-xl font-bold text-gray-900 dark:text-white mb-2">Failed to Load License or User Status</h2>
        <p class="text-gray-500 mb-4">Unable to retrieve license status or user permissions from the server. Please check your connection.</p>
        <UButton @click="handleRetry" :loading="retrying" color="primary" variant="solid" icon="i-heroicons-arrow-path">Retry</UButton>
      </div>
    </UCard>
  </div>

  <!-- Active Admin Layout -->
  <div v-else-if="user?.permissions?.isAdmin" class="space-y-6">
    <div class="flex justify-between items-center">
      <h1 class="text-2xl font-bold text-gray-900 dark:text-white">License Info</h1>
      <div v-if="licenseStatus?.isProvisioned" class="flex gap-2">
        <UButton @click="isUpdatingJwt = !isUpdatingJwt" :disabled="provisioning || syncing || isLicenseUpdating || isLicenseSyncing || appliedUnverified" color="white" variant="solid" icon="i-heroicons-key">
          {{ isUpdatingJwt ? 'Cancel Update' : 'Update JWT' }}
        </UButton>
        <UButton @click="syncLicense" :loading="syncing" :disabled="provisioning || isLicenseUpdating || isLicenseSyncing || appliedUnverified" color="primary" variant="solid" icon="i-heroicons-arrow-path">
          Sync License
        </UButton>
      </div>
    </div>

    <p v-if="isLicenseSyncing" role="status" class="text-sm text-gray-500">
      License synchronization is in progress. JWT replacement is temporarily unavailable.
    </p>

    <div v-if="appliedUnverified || statusRefreshError || licenseFetchError || userFetchError" role="alert" class="rounded-lg border border-orange-300 bg-orange-50 p-4 text-orange-800 dark:border-orange-800 dark:bg-orange-950 dark:text-orange-200">
      <p class="mb-3">{{ appliedUnverified ? (provisioning ? 'License applied; refreshing status...' : 'License applied; latest status could not be loaded') : 'Latest license or user status could not be loaded. Showing the last available status.' }}</p>
      <UButton @click="handleRetry" :loading="retrying" :disabled="provisioning || syncing" color="primary" variant="solid" icon="i-heroicons-arrow-path">Retry Status</UButton>
    </div>

    <!-- View B: Entitlements (Provisioned) -->
    <UCard v-if="licenseStatus?.isProvisioned && !isUpdatingJwt">
      <template #header>
        <div class="flex justify-between items-center">
          <h3 class="text-lg font-medium">Current Entitlements</h3>
          <UBadge :color="statusColor" variant="subtle">{{ licenseStatus.status }}</UBadge>
        </div>
      </template>

      <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div>
          <div class="text-sm text-gray-500 mb-1">Customer Name</div>
          <div class="flex items-center gap-1.5 font-mono text-sm break-all group">
            <span>{{ licenseStatus.customerName || 'N/A' }}</span>
            <CopyToClipboard v-if="licenseStatus.customerName" :text="licenseStatus.customerName"
              title="Customer Name" />
          </div>
        </div>
        <div>
          <div class="text-sm text-gray-500 mb-1">License ID</div>
          <div class="flex items-center gap-1.5 font-mono text-sm break-all group">
            <span>{{ licenseStatus.licenseId }}</span>
            <CopyToClipboard :text="licenseStatus.licenseId" title="License ID" />
          </div>
        </div>
        <div>
          <div class="text-sm text-gray-500 mb-1">Max Agents</div>
          <div class="font-medium text-lg">{{ licenseStatus.maxAgents }}</div>
        </div>
        <div>
          <div class="text-sm text-gray-500 mb-1">Expiry Date</div>
          <div class="font-medium text-lg" :class="{ 'text-red-500': isExpired }">{{ formattedExpiry }}</div>
        </div>
      </div>
    </UCard>

    <!-- View A: Activation (Unprovisioned or Updating) -->
    <UCard v-else-if="!appliedUnverified" class="max-w-2xl mx-auto mt-8">
      <template #header>
        <div class="text-xl font-bold">{{ isUpdatingJwt ? 'Update License' : 'System Provisioning' }}</div>
        <div class="text-sm text-gray-500">Please enter your license JWT to activate this deployment.</div>
      </template>

      <UFormField label="License JWT" class="mb-4">
        <UTextarea v-model="provisionJwt" :disabled="provisioning || syncing || isLicenseUpdating || isLicenseSyncing" placeholder="eyJhbGci..." :rows="6" />
      </UFormField>

      <UButton @click="handleProvision" :loading="provisioning" :disabled="syncing || isLicenseUpdating || isLicenseSyncing" block color="primary">
        {{ isUpdatingJwt ? 'Update License' : 'Activate License' }}
      </UButton>
      <div v-if="provisionError" class="mt-4 text-red-500 text-sm text-center">{{ provisionError }}</div>
    </UCard>
  </div>

  <!-- Permission Denied View (Fail closed) -->
  <div v-else class="max-w-2xl mx-auto mt-12">
    <UCard>
      <div class="text-center py-8">
        <UIcon name="i-heroicons-shield-exclamation" class="w-16 h-16 text-red-500 mx-auto mb-4" />
        <h2 class="text-xl font-bold text-gray-900 dark:text-white mb-2">Access Denied</h2>
        <p class="text-gray-500 mb-6">You do not have administrative permissions to view or configure licenses.</p>
        <UButton to="/services" color="gray" variant="solid" icon="i-heroicons-arrow-left">
          Back to Dashboard
        </UButton>
      </div>
    </UCard>
  </div>
</template>

<script lang="ts">
let cachedPublicKey: string | undefined;
</script>

<script setup lang="ts">
import {
  getLicensingServerUrl,
  HYPERPROBE_LICENSING_PUBLIC_KEY_URL,
} from '@hyperprobe/constants';
import type { inferRouterOutputs } from '@trpc/server';
import { computed, onMounted, onUnmounted, ref, watch } from 'vue';
import { useNuxtApp } from '#app';
import type { AppRouter } from '../../../../backend/src/index';
import CopyToClipboard from '../../components/CopyToClipboard.vue';
import { useAuth } from '../../composables/useAuth';
import { useLicense } from '../../composables/useLicense';
import { submitInitialRelay } from '../../utils/initialRelay';
import { CancelledOperationError, isCancelledOperation } from '../../utils/operation';
import { decodeJwtPayload } from '../../utils/token';
import { isUnauthorizedError } from '../../utils/trpc';

type RouterOutput = inferRouterOutputs<AppRouter>;

const { $trpc } = useNuxtApp();
const toast = useToast();
const { user, userFetchError, logout, fetchUser, sessionVersion, isAuthenticated, captureSession } = useAuth();
const {
  licenseStatus,
  licenseFetchError,
  fetchLicenseStatus,
  invalidateLicenseStatus,
  captureLicenseOperation,
  beginLicenseUpdate,
  isLicenseUpdating,
  beginLicenseSync,
  isLicenseSyncing,
} = useLicense();

const loading = ref(true);
const pageFetchError = ref(false);
const retrying = ref(false);
const syncing = ref(false);
const isUpdatingJwt = ref(false);

const provisionJwt = ref('');
const provisioning = ref(false);
const provisionError = ref('');
const statusRefreshError = ref(false);
const appliedUnverified = ref(false);
let mounted = false;
let pageSessionVersion = sessionVersion.value;

const capturePageSession = () => {
  const version = pageSessionVersion;
  const isSessionCurrent = captureSession();
  return () =>
    mounted && isSessionCurrent() &&
    version === sessionVersion.value && isAuthenticated.value;
};

const loadStatus = async (force = false): Promise<boolean | null> => {
  const isPageCurrent = capturePageSession();
  const isLicenseCurrent = captureLicenseOperation(true);
  if (!isPageCurrent() || !isLicenseCurrent()) return null;
  const [userResult, licenseResult] = await Promise.allSettled([
    fetchUser(force),
    fetchLicenseStatus(force),
  ]);

  if (!isPageCurrent() || !isLicenseCurrent()) return null;
  const results = [userResult, licenseResult];
  if (results.some((result) =>
    result.status === 'rejected' && isUnauthorizedError(result.reason),
  )) {
    await logout();
    return null;
  }
  if (results.some((result) =>
    result.status === 'rejected' && isCancelledOperation(result.reason),
  )) {
    statusRefreshError.value = true;
    pageFetchError.value = !user.value ||
      Boolean(user.value.permissions?.isAdmin && !licenseStatus.value);
    return false;
  }

  if (userResult.status === 'rejected') {
    console.error('Failed to fetch user in license page:', userResult.reason);
  }

  if (licenseResult.status === 'rejected') {
    console.error(
      'Failed to fetch license status in license page:',
      licenseResult.reason,
    );
  }

  statusRefreshError.value = results.some((result) => result.status === 'rejected');
  if (!user.value) {
    pageFetchError.value = true;
    return false;
  }

  // If user is a confirmed non-admin, prioritize Access Denied view
  if (!user.value.permissions?.isAdmin) {
    pageFetchError.value = false;
  } else {
    pageFetchError.value = !licenseStatus.value;
  }

  if (statusRefreshError.value) return false;
  if (force) appliedUnverified.value = false;
  return true;
};

const fetchStatus = async () => {
  const isPageCurrent = capturePageSession();
  if (!isPageCurrent()) {
    if (mounted) loading.value = false;
    return;
  }
  const cached = Boolean(licenseStatus.value && user.value);
  loading.value = !cached;
  try {
    await loadStatus(cached);
  } finally {
    if (isPageCurrent()) loading.value = false;
  }
};

const handleRetry = async () => {
  const isPageCurrent = capturePageSession();
  if (!isPageCurrent() || retrying.value) return;
  retrying.value = true;
  try {
    await loadStatus(true);
  } finally {
    if (isPageCurrent()) retrying.value = false;
  }
};

watch([user, userFetchError, licenseStatus], ([currentUser, failed, status]) => {
  if (
    mounted && isAuthenticated.value && currentUser && !failed &&
    (!currentUser.permissions?.isAdmin || status)
  ) {
    pageFetchError.value = false;
  }
});

watch([licenseStatus, licenseFetchError], ([status, failed]) => {
  // Successful shared reads replace the snapshot; invalidation retains it.
  if (mounted && isAuthenticated.value && status && !failed) {
    statusRefreshError.value = false;
    appliedUnverified.value = false;
  }
});

watch([sessionVersion, isAuthenticated], () => {
  pageSessionVersion = sessionVersion.value;
  loading.value = isAuthenticated.value;
  pageFetchError.value = false;
  retrying.value = false;
  syncing.value = false;
  isUpdatingJwt.value = false;
  provisionJwt.value = '';
  provisioning.value = false;
  provisionError.value = '';
  statusRefreshError.value = false;
  appliedUnverified.value = false;
  if (mounted && isAuthenticated.value) void fetchStatus();
});

onMounted(() => {
  mounted = true;
  void fetchStatus();
});

onUnmounted(() => {
  mounted = false;
  // Pending actions release shared ownership in finally, not on navigation.
});

const statusColor = computed(() => {
  if (!licenseStatus.value) return 'gray';
  switch (licenseStatus.value.status) {
    case 'SYNCED':
      return 'green';
    case 'COURIER_REQUIRED':
      return 'orange';
    case 'REVOKED':
      return 'red';
    case 'LOCKED':
      return 'red';
    default:
      return 'gray';
  }
});

const formattedExpiry = computed(() => {
  if (!licenseStatus.value?.expiryDate) return 'N/A';
  return new Date(licenseStatus.value.expiryDate).toLocaleDateString(
    undefined,
    {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
    },
  );
});

const isExpired = computed(() => {
  if (!licenseStatus.value?.expiryDate) return false;
  return licenseStatus.value.expiryDate < Date.now();
});

const config = useRuntimeConfig();

const syncLicense = async () => {
  const isPageCurrent = capturePageSession();
  const isSessionCurrent = captureSession();
  let isLicenseCurrent = captureLicenseOperation();
  const isCurrent = () => isPageCurrent() && isLicenseCurrent();
  if (!isCurrent() || syncing.value || provisioning.value || appliedUnverified.value) return;
  const finishSync = beginLicenseSync();
  if (!finishSync) return;
  const assertCurrent = (allowUnmount = false) => {
    if (
      !(allowUnmount ? isSessionCurrent() && isAuthenticated.value : isPageCurrent()) ||
      !isLicenseCurrent()
    ) throw new CancelledOperationError();
  };
  const invalidateAfterMutation = (allowUnmount = false) => {
    assertCurrent(allowUnmount);
    invalidateLicenseStatus();
    // Keep this run valid for its own post-mutation read, but cancel older work.
    isLicenseCurrent = captureLicenseOperation();
  };
  syncing.value = true;
  try {
    const response = await $trpc.license.sync.mutate();
    assertCurrent();

    if (response.requiresCourier) {
      toast.add({
        title: 'Network Unreachable',
        description: 'Attempting to sync via Courier Relay...',
        color: 'orange',
      });

      const courierLease = {};
      const lockRes = await $trpc.license.acquireCourierLock.mutate(undefined, {
        context: { courierLease },
      });
      if (!lockRes.success) {
        assertCurrent();
        toast.add({
          title: 'Courier Busy',
          description: 'Another process is currently syncing the license.',
          color: 'gray',
        });
        return;
      }

      let courierSynced = false;
      let initialRelayCompleted = false;
      try {
        // A late successful acquisition must enter finally even when cancelled.
        assertCurrent();
        const deploymentConfig =
          await $trpc.license.getDeploymentConfig.query();
        assertCurrent();
        const { jwt, licenseId, nextToken, syncStatusIndex } = deploymentConfig;
        if (!jwt || !licenseId) {
          throw new Error('Deployment configuration is incomplete. Retry loading status.');
        }
        const syncPrecondition = syncStatusIndex === undefined ? {} : { syncStatusIndex };

        const licensingServerUrl = await getLicensingServerUrl();
        assertCurrent();

        const submitRelayOnDemand = async (jwtVal: string, tokenVal: string) => {
          const assertRelayCurrent = () => assertCurrent(!nextToken);
          const submit = (publicKey?: string) => {
            const input = { jwt: jwtVal, nextToken: tokenVal, publicKey };
            return nextToken
              ? $trpc.license.submitRelay.mutate({ ...input, preparedFrom: jwt, ...syncPrecondition })
              : submitInitialRelay(
                $trpc.license.submitRelay.mutate,
                { ...input, initialFrom: jwt },
                assertRelayCurrent,
              );
          };
          assertRelayCurrent();
          try {
            // Attempt 1: Fast Sync (No outbound Firebase query!)
            await submit(cachedPublicKey || undefined);
            assertRelayCurrent();
          } catch (err) {
            assertRelayCurrent();
            if (isCancelledOperation(err) || isUnauthorizedError(err)) throw err;
            const errorMsg = err instanceof Error ? err.message : String(err || '');
            if (
              errorMsg.includes('No public key available for verification') ||
              errorMsg.includes('Invalid, forged, or expired license token')
            ) {
              // Key rotation detected! Fetch fresh public key on-demand
              let fetchedKey: string | undefined;
              const controller = new AbortController();
              const id = setTimeout(() => controller.abort(), 5000);
              try {
                const pubKeyRes = await fetch(HYPERPROBE_LICENSING_PUBLIC_KEY_URL, { signal: controller.signal });
                assertRelayCurrent();
                if (pubKeyRes.ok) {
                  const parsed = await pubKeyRes.json();
                  assertRelayCurrent();
                  if (parsed && typeof parsed === 'string') {
                    fetchedKey = parsed;
                    cachedPublicKey = parsed;
                  }
                }
              } catch (fetchErr) {
                assertRelayCurrent();
                if (isCancelledOperation(fetchErr)) throw fetchErr;
                console.error('Failed to fetch public key on-demand:', fetchErr);
              } finally {
                clearTimeout(id);
              }

              if (fetchedKey) {
                // Retry submitting with the rotated public key
                await submit(fetchedKey);
                assertRelayCurrent();
              } else {
                throw err;
              }
            } else {
              throw err;
            }
          }
          invalidateAfterMutation(!nextToken);
        };

        if (!nextToken) {
          const controller0 = new AbortController();
          const id0 = setTimeout(() => controller0.abort(), 10000);
          try {
            const res = await fetch(`${licensingServerUrl}/api/heartbeat`, {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({
                licenseId,
                jwt,
                nextToken: null,
              }),
              signal: controller0.signal,
            });
            // Initialization is already committed centrally; navigation must not discard its token.
            assertCurrent(res.ok);
            if (res.status === 403 || res.status === 401) {
              await $trpc.license.reportRevocation.mutate();
              invalidateAfterMutation();
              await loadStatus(true);
              assertCurrent();
              return;
            }
            if (!res.ok) {
              throw new Error(
                `Licensing server error: ${res.statusText || res.status}`,
              );
            }
            const data = await res.json();
            assertCurrent(true);
            await submitRelayOnDemand(data.jwt, data.nextToken);
            assertCurrent(true);
            courierSynced = true;
            initialRelayCompleted = true;
          } finally {
            clearTimeout(id0);
          }
        } else {
          const controller1 = new AbortController();
          const id1 = setTimeout(() => controller1.abort(), 10000);
          let res1: Response;
          try {
            res1 = await fetch(`${licensingServerUrl}/api/heartbeat`, {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({
                phase: 1,
                licenseId,
                jwt,
                nextToken,
              }),
              signal: controller1.signal,
            });
            assertCurrent();
          } finally {
            clearTimeout(id1);
          }
          if (res1.status === 403 || res1.status === 401) {
            await $trpc.license.reportRevocation.mutate();
            invalidateAfterMutation();
            await loadStatus(true);
            assertCurrent();
            return;
          }
          if (!res1.ok) {
            throw new Error(
              `Licensing server error (Phase 1): ${res1.statusText || res1.status}`,
            );
          }
          const data1 = await res1.json();
          assertCurrent();
          await $trpc.license.prepareRelay.mutate({
            jwt,
            previousNextToken: nextToken,
            nextToken: data1.nextToken,
            ...syncPrecondition,
          });
          assertCurrent();
          const controller2 = new AbortController();
          const id2 = setTimeout(() => controller2.abort(), 10000);
          let res2: Response;
          try {
            res2 = await fetch(`${licensingServerUrl}/api/heartbeat`, {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({
                phase: 2,
                licenseId,
                jwt,
                nextToken: data1.nextToken,
              }),
              signal: controller2.signal,
            });
            assertCurrent();
          } finally {
            clearTimeout(id2);
          }
          if (res2.status === 403 || res2.status === 401) {
            await $trpc.license.reportRevocation.mutate();
            invalidateAfterMutation();
            await loadStatus(true);
            assertCurrent();
            return;
          }
          if (!res2.ok) {
            throw new Error(
              `Licensing server error (Phase 2): ${res2.statusText || res2.status}`,
            );
          }
          const data2 = await res2.json();
          assertCurrent();
          await submitRelayOnDemand(data2.jwt, data1.nextToken);
          assertCurrent();
          courierSynced = true;
        }
      } catch (e) {
        if (!isCurrent() || isCancelledOperation(e)) return;
        if (isUnauthorizedError(e)) {
          await logout();
          return;
        }
        console.error('Courier relay failed', e);
        const errorMsg = (e as Error).message || '';
        const description =
          errorMsg.includes('license') || errorMsg.includes('token')
            ? 'License validation failed. The token is invalid or expired.'
            : errorMsg || 'Unable to reach the Central Licensing Server.';
        toast.add({
          title: 'Courier Failed',
          description,
          color: 'red',
        });
      } finally {
        try {
          await $trpc.license.releaseCourierLock.mutate(undefined, {
            context: { courierLease },
          });
        } catch (e) {
          if (isCancelledOperation(e)) throw e;
          if (isCurrent()) console.error('Failed to release courier lock', e);
        }
      }

      if (initialRelayCompleted && !isPageCurrent()) {
        assertCurrent(true);
        await fetchLicenseStatus(true);
        return;
      }
      assertCurrent();
      const isSynced = await loadStatus(true);
      assertCurrent();
      if (isSynced === null) return;
      if (courierSynced) {
        if (isSynced) {
          toast.add({
            title: 'License Synced',
            description: 'License synced successfully via Courier Relay.',
            color: 'green',
          });
        } else {
          toast.add({
            title: 'Sync Warning',
            description:
              'License synced via Courier Relay, but failed to retrieve updated status.',
            color: 'orange',
          });
        }
      }
    } else {
      invalidateAfterMutation();
      const isSynced = await loadStatus(true);
      assertCurrent();
      if (isSynced === null) return;
      if (isSynced) {
        toast.add({
          title: 'License Synced',
          description:
            'Your license limits and status have been updated successfully.',
          color: 'green',
        });
      } else {
        toast.add({
          title: 'Sync Warning',
          description:
            'License synced on server, but failed to retrieve updated status.',
          color: 'orange',
        });
      }
    }
  } catch (err) {
    if (!isCurrent() || isCancelledOperation(err)) return;
    if (isUnauthorizedError(err)) {
      await logout();
      return;
    }
    console.error('Failed to sync license:', err);
    toast.add({
      title: 'Sync Failed',
      description:
        (err as Error).message ||
        'An unexpected error occurred while syncing the license.',
      color: 'red',
    });
  } finally {
    finishSync();
    if (isPageCurrent()) syncing.value = false;
  }
};

const handleProvision = async () => {
  const isPageCurrent = capturePageSession();
  if (!isPageCurrent() || provisioning.value || syncing.value || isLicenseUpdating.value || isLicenseSyncing.value || appliedUnverified.value) return;
  const jwt = provisionJwt.value;
  if (!jwt.trim()) {
    provisionError.value = 'Please provide a valid JWT.';
    return;
  }

  const finishUpdate = beginLicenseUpdate();
  if (!finishUpdate) return;
  provisioning.value = true;
  provisionError.value = '';
  let isLicenseCurrent = captureLicenseOperation(true);
  const isCurrent = () => isPageCurrent() && isLicenseCurrent();
  const assertCurrent = () => {
    if (!isCurrent()) throw new CancelledOperationError();
  };
  try {
    assertCurrent();
    let incomingLicenseId: string | undefined;
    try {
      const payload = decodeJwtPayload(jwt);
      if (typeof payload?.licenseId === 'string' && payload.licenseId.trim()) {
        incomingLicenseId = payload.licenseId;
      }
    } catch {
      // The backend remains responsible for signature and payload validation.
    }
    if (incomingLicenseId) {
      const current = await $trpc.license.getDeploymentConfig.query();
      assertCurrent();
      if (incomingLicenseId === current.licenseId) {
        provisionError.value = 'This license is already installed. Use Sync License to refresh its entitlements.';
        return;
      }
    }
    // Reserve before preflight, but preserve pending reads when the JWT is a duplicate.
    invalidateLicenseStatus();
    isLicenseCurrent = captureLicenseOperation(true);
    let publicKey: string | undefined;
    const controller = new AbortController();
    const id = setTimeout(() => controller.abort(), 5000);
    try {
      const pubKeyRes = await fetch(HYPERPROBE_LICENSING_PUBLIC_KEY_URL, {
        signal: controller.signal,
      });
      assertCurrent();
      if (pubKeyRes.ok) {
        const parsed = await pubKeyRes.json();
        assertCurrent();
        if (parsed && typeof parsed === 'string') {
          publicKey = parsed;
        }
      }
    } catch (err) {
      assertCurrent();
      if (isCancelledOperation(err)) throw err;
      console.error('Failed to fetch public key during provision:', err);
    } finally {
      clearTimeout(id);
    }

    await $trpc.license.provision.mutate({
      jwt,
      publicKey: publicKey || undefined,
    });
    assertCurrent();
    invalidateLicenseStatus();
    isLicenseCurrent = captureLicenseOperation(true);
    isUpdatingJwt.value = false;
    provisionJwt.value = '';
    appliedUnverified.value = true;
    const refreshed = await loadStatus(true);
    assertCurrent();
    if (!refreshed) {
      appliedUnverified.value = true;
      return;
    }
    appliedUnverified.value = false;
    toast.add({
      title: 'License Activated',
      description: 'Your license has been successfully applied.',
      color: 'green',
    });
  } catch (err) {
    if (!isCurrent() || isCancelledOperation(err)) return;
    if (isUnauthorizedError(err)) {
      await logout();
      return;
    }
    provisionError.value =
      (err as Error).message || 'Failed to provision license';
  } finally {
    finishUpdate();
    if (isPageCurrent()) provisioning.value = false;
  }
};
</script>
