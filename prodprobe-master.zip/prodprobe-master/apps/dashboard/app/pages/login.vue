<template>
  <div class="flex items-center justify-center min-h-screen bg-gray-50 dark:bg-gray-900">
    <UCard class="w-full max-w-md p-6">
      <template #header>
        <div class="text-center">
          <h1 class="text-2xl font-bold text-gray-900 dark:text-white">Welcome to Hyper Probe</h1>
          <p class="text-sm text-gray-500 mt-2">Sign in to your dashboard</p>
        </div>
      </template>

      <div v-if="errorMsg" class="mb-4">
        <UAlert title="Authentication Failed" :description="errorMsg" color="error" variant="subtle"
          icon="i-heroicons-exclamation-triangle" />
      </div>

      <div v-if="isClientAuthorized" class="flex flex-col items-center justify-center py-8 text-center">
        <UIcon name="i-heroicons-check-circle" class="w-12 h-12 text-green-500 mb-4" />
        <h2 class="text-xl font-semibold text-gray-900 dark:text-white mb-2">
          {{ client === 'mcp' ? 'MCP Server' : 'VS Code' }} Authorized
        </h2>
        <p class="text-sm text-gray-600 dark:text-gray-300 mb-4">
          Successfully authorized {{ client === 'mcp' ? 'MCP Server' : 'VS Code' }}. You can close this window and
          return to
          your editor.
        </p>

        <p v-if="countdown > 0" class="text-sm text-gray-500 dark:text-gray-400 mb-4">
          This tab will close in {{ countdown }}...
        </p>
        <p v-else-if="closeBlocked" class="text-sm text-amber-500 font-medium mb-4">
          Automatic tab closing was blocked by your browser. You can safely close this tab manually.
        </p>

        <UButton color="neutral" variant="link" size="sm" class="p-0 text-sm text-primary-500 hover:underline"
          @click="attemptClose">Close tab now</UButton>
      </div>

      <div v-else-if="isLoading" class="flex flex-col items-center justify-center py-8">
        <UIcon name="i-heroicons-arrow-path" class="w-8 h-8 animate-spin text-primary-500 mb-4" />
        <p class="text-sm text-gray-600">Verifying your login...</p>
      </div>

      <div v-else class="space-y-6 mt-4">
        <UButton block size="xl"
          class="bg-[#4285F4] hover:bg-[#357ABD] text-white shadow-md border-none flex justify-center py-3"
          @click="loginWith('google')">
          <template #leading>
            <UIcon name="i-logos-google-icon" class="w-6 h-6 brightness-0 invert mr-2" />
          </template>
          <span class="text-base font-medium">Continue with Google</span>
        </UButton>

        <UButton block size="xl"
          class="bg-[#F25022] hover:bg-[#da481e] text-white shadow-md border-none flex justify-center py-3"
          @click="loginWith('microsoft')">
          <template #leading>
            <UIcon name="i-logos-microsoft-icon" class="w-6 h-6 brightness-0 invert mr-2" />
          </template>
          <span class="text-base font-medium">Continue with Microsoft</span>
        </UButton>

        <UButton block size="xl"
          class="bg-white hover:bg-gray-50 text-[#FF4D4F] shadow-md border border-gray-100 flex justify-center py-3"
          @click="loginWith('github')">
          <template #leading>
            <UIcon name="i-logos-github-icon" class="w-6 h-6 mr-2" />
          </template>
          <span class="text-base font-medium">Continue with GitHub</span>
        </UButton>
      </div>
      <template v-if="areNoUsersPresent" #footer>
        <p class="text-xs text-center text-gray-400">
          <UIcon name="i-lucide-lightbulb" style="vertical-align: bottom; background-color:#1976d2;" class="size-5"
            color="secondary" />
          No users found, you will be made admin.
        </p>
      </template>
      <template v-if="identifier" #footer>
        <p class="text-xs text-center text-gray-400">
          {{ client === 'mcp' ? 'MCP Server' : 'VS Code Extension' }} Login Initiated
        </p>
      </template>
    </UCard>
  </div>
</template>

<script setup lang="ts">
definePageMeta({
  layout: false,
});

import { onBeforeUnmount, onMounted, ref, watch } from 'vue';
import { useRoute, useRouter } from 'vue-router';
import { useNuxtApp, useRuntimeConfig } from '#app';
import { useAuth } from '../composables/useAuth';
import { isCancelledOperation } from '../utils/operation';

const route = useRoute();
const router = useRouter();
const { $trpc } = useNuxtApp();
const { ssoUrl } = useRuntimeConfig().public;
const { login, isAuthenticated, sessionVersion, captureSession } = useAuth();
let active = true;
let authorizationIsCurrent = () => false;
let closeTimeout: ReturnType<typeof setTimeout> | undefined;

const identifier = ref<string | null>(null);
const isLoading = ref(false);
const errorMsg = ref<string | null>(null);
const areNoUsersPresent = ref(false);
const isClientAuthorized = ref(false);
const client = ref<string | null>(null);

const countdown = ref(5);
const countdownInterval = ref<ReturnType<typeof setInterval> | null>(null);
const closeBlocked = ref(false);

const stopCountdown = () => {
  if (countdownInterval.value) {
    clearInterval(countdownInterval.value);
    countdownInterval.value = null;
  }
  clearTimeout(closeTimeout);
};

const attemptClose = () => {
  if (!authorizationIsCurrent()) return;
  stopCountdown();
  countdown.value = 0;
  window.close();
  closeTimeout = setTimeout(() => {
    if (authorizationIsCurrent()) closeBlocked.value = true;
  }, 100);
};

const startCountdown = () => {
  countdown.value = 5;
  closeBlocked.value = false;
  stopCountdown();
  countdownInterval.value = setInterval(() => {
    if (!authorizationIsCurrent()) {
      stopCountdown();
      return;
    }
    if (countdown.value > 1) {
      countdown.value--;
    } else {
      countdown.value = 0;
      attemptClose();
    }
  }, 1000);
};

onBeforeUnmount(() => {
  active = false;
  stopCountdown();
});

watch(
  sessionVersion,
  () => {
    stopCountdown();
    isClientAuthorized.value = false;
    isLoading.value = false;
    errorMsg.value = null;
  },
  { flush: 'sync' },
);

onMounted(async () => {
  let sessionIsCurrent = captureSession();
  const current = () => active && sessionIsCurrent();
  // Capture identifier from query if present
  if (route.query.identifier) {
    identifier.value = route.query.identifier as string;
  }

  // Capture client from query if present
  if (route.query.client) {
    client.value = route.query.client as string;
  }

  const token = route.query.token as string | undefined;

  // An explicit SSO callback takes precedence over an existing dashboard login.
  if (isAuthenticated.value && identifier.value && !token) {
    isLoading.value = true;
    try {
      const response = await $trpc.authorizeVsc.mutate({
        identifier: identifier.value,
      });
      if (!current()) return;
      if (!response.success)
        throw new Error('Client authorization was not completed.');
      authorizationIsCurrent = current;
      isClientAuthorized.value = true;
      startCountdown();
    } catch (err) {
      if (!current() || isCancelledOperation(err)) return;
      const clientName = client.value === 'mcp' ? 'MCP Server' : 'VS Code';
      console.error(`${clientName} Authorization failed`, err);
      errorMsg.value =
        (err as Error).message ||
        `An unexpected error occurred during ${clientName} authorization.`;
    } finally {
      if (current()) isLoading.value = false;
    }
    return; // Don't proceed with normal login flow or user count checks if doing VSC auth
  }

  try {
    const userCount = await $trpc.getUserCount.query();
    if (!current()) return;
    areNoUsersPresent.value = userCount === 0;
  } catch (err) {
    if (!current() || isCancelledOperation(err)) return;
    console.error('Failed to load user count', err);
  }

  if (token) {
    errorMsg.value = null;

    try {
      const pending = login(token, identifier.value || undefined);
      // login() starts its epoch synchronously, before the verification await.
      sessionIsCurrent = captureSession();
      isLoading.value = true;
      const success = await pending;
      if (!current()) return;
      if (!success || !isAuthenticated.value) {
        errorMsg.value = 'Login could not be verified. Please try again.';
        return;
      }
      if (identifier.value) {
        authorizationIsCurrent = current;
        isClientAuthorized.value = true;
        startCountdown();
      } else {
        // Redirect to main dashboard
        router.push('/');
      }
    } catch (err) {
      if (!current() || isCancelledOperation(err)) return;
      console.error('SSO Verification failed', err);
      // Display the exact error message returned from the backend TRPCError
      errorMsg.value =
        (err as Error).message || 'An unexpected error occurred during login.';
    } finally {
      if (current()) isLoading.value = false;
    }
  }
});

const loginWith = (provider: 'google' | 'github' | 'microsoft') => {
  // Notice the parameters are now AFTER the #/login
  // This ensures Vue Router sees them as part of the current route
  const params = new URLSearchParams();
  if (identifier.value) {
    params.set('identifier', identifier.value);
  }
  if (client.value) {
    params.set('client', client.value);
  }
  const queryString = params.toString();
  const callbackUrl = queryString
    ? `${window.location.origin}${window.location.pathname}#/login?${queryString}`
    : `${window.location.origin}${window.location.pathname}#/login`;

  const encodedCallback = encodeURIComponent(callbackUrl);

  let targetUrl = `${ssoUrl}?redirectUrl=${encodedCallback}`;
  targetUrl += `&sso-provider=${provider}`;

  window.location.href = targetUrl;
};
</script>
