<template>
  <div class="space-y-6">
      <!-- Page Header -->
      <div class="border-b border-gray-200 dark:border-gray-800 pb-5 space-y-4">
        <!-- Title and Main Actions -->
        <div class="flex flex-col md:flex-row md:justify-between md:items-center gap-4">
          <div>
            <div class="flex items-center gap-3">
              <h1 class="text-2xl font-bold text-gray-900 dark:text-white">Live Agents</h1>

              <!-- Clean Global Agents Badge -->
              <div
                class="group flex items-center bg-gray-100 dark:bg-gray-800 transition-colors px-2.5 py-1 rounded-full text-xs font-medium text-gray-600 dark:text-gray-300 gap-2 border border-gray-200 dark:border-gray-700 mt-0.5">
                <UIcon name="i-heroicons-cpu-chip" class="w-3.5 h-3.5 text-purple-500" />
                <span>
                  {{ agents.length }} Active Agent{{ agents.length > 1 ? 's' : '' }}
                </span>
              </div>
            </div>
            <p class="text-sm text-gray-500 dark:text-gray-400 mt-1">
              Explore active monitoring agents grouped by service, environment, and commit.
            </p>
          </div>
          <!-- Action Buttons (Refresh, Expand/Collapse All) -->
          <div class="flex items-center gap-2">
            <UButton color="neutral" variant="ghost"
              :icon="allExpanded ? 'i-heroicons-arrows-pointing-in' : 'i-heroicons-arrows-pointing-out'"
              :label="allExpanded ? 'Collapse All' : 'Expand All'" @click="toggleAllExpanded" />
            <UButton color="secondary" icon="i-heroicons-arrow-path" :loading="isLoadingSources" label="Refresh"
              @click="refreshAll" />
          </div>

          <Loader :loading="isLoadingSources" label="Loading agents..." />
        </div>

        <CustomDropdown :items="services" :selected-items="selectedServiceIds" value-key="id" label-key="name"
          :on-selected="onServiceSelected" placeholder="Select Services..." class="min-w-[27rem] max-w-md" />
      </div>

      <!-- If no services selected, show placeholder prompting service selection -->
      <!-- <div v-if="selectedServiceIds.length === 0"
        class="flex items-center justify-center h-[calc(100vh-200px)] border border-gray-200 dark:border-gray-800 rounded-lg bg-gray-50 dark:bg-gray-900/50 text-gray-500">
        <div class="flex flex-col items-center">
          <UIcon name="i-heroicons-server" class="text-5xl mb-4 opacity-50" />
          <p class="text-lg">Select at least one service to see the agents.</p>
        </div>
      </div> -->

      <div class="relative space-y-6 min-h-[400px]">
        <!-- Reusable Search Filter Component -->
        <SourceSearchFilter v-model="searchQuery" v-model:activeTags="activeTags"
          placeholder="Filter live agents... (e.g. 'staging' or 'environment: staging')" :candidates="agents"
          :tag-key-to-label="AGENT_TAG_KEY_TO_LABEL" />

        <!-- Main Tree Content -->
        <div>
          <div v-if="Object.keys(deepGroupedFiltered).length > 0" class="space-y-4">
            <div v-for="(envs, serviceId) in deepGroupedFiltered" :key="serviceId"
              class="border border-gray-200 dark:border-gray-800 rounded-lg overflow-hidden bg-white dark:bg-gray-950">
              <!-- Service Header -->
              <div
                class="flex items-center justify-between p-4 bg-gray-50 dark:bg-gray-900 border-b border-gray-200 dark:border-gray-800 cursor-pointer select-none hover:bg-gray-100 dark:hover:bg-gray-800/50 transition-colors"
                @click="toggleNode(`service:${serviceId}`)">
                <div class="flex items-center space-x-3">
                  <UIcon
                    :name="isExpanded(`service:${serviceId}`) ? 'i-heroicons-chevron-down' : 'i-heroicons-chevron-right'"
                    class="w-5 h-5 text-gray-400" />
                  <UIcon name="i-heroicons-server" class="w-5 h-5 text-secondary-500" />
                  <div class="flex flex-col sm:flex-row sm:items-center">
                    <span class="font-semibold text-gray-950 dark:text-gray-50">{{ serviceNames[serviceId] || serviceId
                    }}</span>
                    <div class="flex items-center gap-1 sm:ml-2 mt-1.5 group">
                      <span class="text-xs text-gray-500 dark:text-gray-400 font-mono">({{ serviceId }})</span>
                      <CopyToClipboard :text="serviceId" title="Service ID" />
                    </div>
                  </div>
                </div>

                <!-- Teams Tags -->
                <ServiceTeamsList :team-services="serviceTeamServicesMap[serviceId] || []"
                  :service-name="serviceNames[serviceId] || serviceId" />
              </div>

              <!-- Service Body / Environments list -->
              <div v-show="isExpanded(`service:${serviceId}`)" class="divide-y divide-gray-100 dark:divide-gray-850">
                <div v-for="(commits, envName) in envs" :key="envName" class="bg-white dark:bg-gray-950">
                  <!-- Env Header -->
                  <div
                    class="flex items-center justify-between px-6 py-3 border-b border-gray-100 dark:border-gray-850 cursor-pointer select-none hover:bg-gray-50 dark:hover:bg-gray-900/50 transition-colors"
                    @click="toggleNode(`service:${serviceId}:env:${envName}`)">
                    <div class="flex items-center space-x-3">
                      <UIcon
                        :name="isExpanded(`service:${serviceId}:env:${envName}`) ? 'i-heroicons-chevron-down' : 'i-heroicons-chevron-right'"
                        class="w-4 h-4 text-gray-400" />
                      <UIcon name="i-heroicons-globe-alt" class="w-4 h-4 text-sky-500" />
                      <span class="text-sm font-medium text-gray-700 dark:text-gray-300">
                        ENVIRONMENT: <span class="font-semibold">{{ envName }}</span>
                      </span>
                    </div>
                  </div>

                  <!-- Env Body / Commits list -->
                  <div v-show="isExpanded(`service:${serviceId}:env:${envName}`)"
                    class="divide-y divide-gray-50 dark:divide-gray-900">
                    <div v-for="(agentsList, commitSha) in commits" :key="commitSha"
                      class="bg-gray-50/10 dark:bg-gray-950/10">
                      <!-- Commit Row -->
                      <div
                        class="flex items-center justify-between pl-10 pr-6 py-2.5 border-b border-gray-50 dark:border-gray-900 cursor-pointer select-none hover:bg-gray-50 dark:hover:bg-gray-900 transition-colors"
                        @click="openAgentsModal(serviceId, envName, commitSha)">
                        <div class="flex items-center space-x-3">
                          <UIcon name="i-heroicons-code-bracket" class="w-4 h-4 text-emerald-500" />
                          <span class="text-xs font-mono text-gray-600 dark:text-gray-400 mt-1 flex items-center gap-1 group">
                            COMMIT: <span class="font-semibold select-all">{{ commitSha.substring(0, 8) }}</span>
                            <CopyToClipboard :text="commitSha" title="Commit SHA" />
                          </span>
                        </div>
                        <div class="flex items-center gap-2">
                          <UBadge v-if="getCommitSdkVersion(agentsList)" color="neutral" variant="subtle" size="sm"
                            class="text-[11px] px-2.5 py-0.5 font-mono">
                            {{ getCommitSdkVersion(agentsList) }}
                          </UBadge>
                          <UBadge color="neutral" variant="subtle" size="sm"
                            class="text-[11px] px-3 py-0.5 hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors cursor-pointer">
                            {{ agentsList.length }} Agent(s)
                          </UBadge>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <!-- Empty State -->
          <UCard v-else class="text-center py-12">
            <div class="flex flex-col items-center justify-center space-y-4">
              <UIcon name="i-heroicons-cpu-chip" class="w-16 h-16 text-gray-300 dark:text-gray-700" />
              <h3 class="text-lg font-bold text-gray-900 dark:text-white">No Active Agents Found</h3>
              <p class="text-sm text-gray-500 dark:text-gray-400 max-w-md">
                We couldn't find any active monitoring agents for the selected service(s). Run agents in your services
                or check your setup to start monitoring.
              </p>
              <div class="pt-2">
                <UButton color="secondary" @click="refreshAll" icon="i-heroicons-arrow-path">Check Again</UButton>
              </div>
            </div>
          </UCard>
        </div>
      </div>
    </div>

    <!-- Agents Modal -->
    <UModal v-model:open="isAgentsModalOpen">
      <template #content>
        <UCard :ui="{ divide: 'divide-y divide-gray-100 dark:divide-gray-800' }">
          <template #header>
            <div class="flex items-center justify-between">
              <h3 class="text-base font-semibold leading-6 text-gray-900 dark:text-white flex items-center gap-2">
                <UIcon name="i-heroicons-cpu-chip" class="w-5 h-5 text-purple-500" />
                Agents for Commit: <span class="font-mono text-sm bg-gray-100 dark:bg-gray-800 px-1.5 py-0.5 rounded">{{
                  selectedAgentsModalCommitSha?.substring(0, 8) }}</span>
              </h3>
              <UButton color="neutral" variant="ghost" icon="i-heroicons-x-mark-20-solid" class="-my-1"
                @click="isAgentsModalOpen = false" />
            </div>
          </template>
          <div class="py-2 space-y-3">
            <div v-if="sortedSelectedAgentsModalList.length > 0" class="space-y-2 max-h-[300px] overflow-y-auto pr-1">
              <div v-for="agent in sortedSelectedAgentsModalList" :key="agent.agentId"
                class="group flex items-center justify-between p-2.5 rounded-lg bg-gray-50 dark:bg-gray-900 border border-gray-100 dark:border-gray-800 hover:border-gray-200 dark:hover:border-gray-700 transition-all">
                <div class="flex items-center space-x-2.5">
                  <UIcon name="i-heroicons-cpu-chip" class="w-4 h-4 text-purple-500" />
                  <span class="text-xs font-mono font-medium text-gray-800 dark:text-gray-200 select-all">
                    {{ agent.agentId }}
                  </span>
                  <CopyToClipboard :text="agent.agentId" title="Agent ID" />
                </div>
                <div v-if="formatSdkVersion(agent.sdkVersion)" class="flex items-center">
                  <UBadge color="neutral" variant="subtle" size="sm"
                    class="text-[11px] px-2 py-0.5 font-mono">
                    {{ formatSdkVersion(agent.sdkVersion) }}
                  </UBadge>
                </div>
              </div>
            </div>
            <div v-else class="text-center text-sm text-gray-500 py-4">
              No active agents found for this commit.
            </div>
          </div>
        </UCard>
      </template>
    </UModal>
</template>

<script setup lang="ts">
import { useDebounceFn } from '@vueuse/core';
import { computed, onMounted, onUnmounted, ref, watch } from 'vue';
import { useNuxtApp, useRoute, useRouter } from '#app';
import CopyToClipboard from '../../components/CopyToClipboard.vue';
import CustomDropdown from '../../components/CustomDropdown.vue';
import Loader from '../../components/Loader.vue';
import SourceSearchFilter from '../../components/SourceSearchFilter.vue';
import { AGENT_TAG_KEY_TO_LABEL } from '../../constants/appConstants';
import { useServicesStore } from '../../stores/services';

interface ActiveAgent {
  agentId: string;
  serviceId: string;
  environment: string;
  commitSha: string;
  sdkVersion?: string;
}

const { $trpc } = useNuxtApp();
const route = useRoute();
const router = useRouter();

const servicesStore = useServicesStore();
const services = computed(() => servicesStore.services);

const routeServices = route.query.selectedServiceIds
  ? Array.isArray(route.query.selectedServiceIds)
    ? route.query.selectedServiceIds
    : [route.query.selectedServiceIds]
  : [];
const selectedServiceIds = ref<string[]>(routeServices as string[]);

interface FilterTag {
  type: string;
  label: string;
  value: string;
}

const agents = ref<ActiveAgent[]>([]);
const isLoadingSources = ref(false);
const searchQuery = ref('');
const expandedNodes = ref<Record<string, boolean>>({});
const allExpanded = ref(true);

const routeSourceSearchTags = route.query.sourceSearchTags
  ? Array.isArray(route.query.sourceSearchTags)
    ? route.query.sourceSearchTags
    : [route.query.sourceSearchTags]
  : [];

const sourceSearchTags = ref<string[]>(routeSourceSearchTags as string[]);

const activeTags = ref<FilterTag[]>(
  sourceSearchTags.value
    .map((t) => {
      const [type, ...valParts] = t.split(':');
      const lower = type?.trim().toLowerCase();
      const canonicalType = Object.keys(AGENT_TAG_KEY_TO_LABEL).find(
        (k) => k.toLowerCase() === lower,
      );
      if (!canonicalType) return null;
      return {
        type: canonicalType,
        label: AGENT_TAG_KEY_TO_LABEL[canonicalType] || canonicalType,
        value: valParts.join(':').trim(),
      };
    })
    .filter((t): t is FilterTag => t !== null),
);

let pollingInterval: any = null;

const serviceNames = computed(() => {
  const map: Record<string, string> = {};
  for (const s of services.value) {
    map[s.id] = s.name;
  }
  return map;
});

const serviceTeamServicesMap = computed(() => {
  const map: Record<string, any[]> = {};
  for (const s of services.value) {
    map[s.id] = s.teamServices || [];
  }
  return map;
});

const isAgentsModalOpen = ref(false);
const selectedAgentsModalServiceId = ref<string | null>(null);
const selectedAgentsModalEnvName = ref<string | null>(null);
const selectedAgentsModalCommitSha = ref<string | null>(null);

const openAgentsModal = (
  serviceId: string,
  envName: string,
  commitSha: string,
) => {
  selectedAgentsModalServiceId.value = serviceId;
  selectedAgentsModalEnvName.value = envName;
  selectedAgentsModalCommitSha.value = commitSha;
  isAgentsModalOpen.value = true;
};

const sortedSelectedAgentsModalList = computed(() => {
  if (
    !selectedAgentsModalServiceId.value ||
    !selectedAgentsModalEnvName.value ||
    !selectedAgentsModalCommitSha.value
  ) {
    return [];
  }
  const agentsList =
    deepGroupedFiltered.value[selectedAgentsModalServiceId.value]?.[
      selectedAgentsModalEnvName.value
    ]?.[selectedAgentsModalCommitSha.value] || [];

  return [...agentsList].sort((a, b) => a.agentId.localeCompare(b.agentId));
});

const normalizeSdkVersion = (version?: string) => {
  if (!version) return '';
  return version.trim().toLowerCase().replace(/^v/, '');
};

const formatSdkVersion = (version?: string) => {
  const normalized = normalizeSdkVersion(version);
  if (!normalized) return '';
  return `v${normalized}`;
};

const getCommitSdkVersion = (agentsList: ActiveAgent[]) => {
  const versions = Array.from(
    new Set(
      agentsList
        .map((a) => (a.sdkVersion ? formatSdkVersion(a.sdkVersion) : ''))
        .filter(Boolean),
    ),
  );
  if (versions.length === 0) return null;
  versions.sort((a, b) => a.localeCompare(b));
  return versions.join(', ');
};

const isExpanded = (path: string) => {
  return expandedNodes.value[path] !== false; // default to expanded if not explicitly collapsed
};

const toggleNode = (path: string) => {
  expandedNodes.value[path] = !isExpanded(path);
};

const expandAll = () => {
  expandedNodes.value = {};
};

const collapseAll = () => {
  const collapsed: Record<string, boolean> = {};
  for (const serviceId of Object.keys(deepGroupedFiltered.value)) {
    collapsed[`service:${serviceId}`] = false;
    for (const envName of Object.keys(deepGroupedFiltered.value[serviceId])) {
      collapsed[`service:${serviceId}:env:${envName}`] = false;
      for (const commitSha of Object.keys(
        deepGroupedFiltered.value[serviceId][envName],
      )) {
        collapsed[`service:${serviceId}:env:${envName}:commit:${commitSha}`] =
          false;
      }
    }
  }
  expandedNodes.value = collapsed;
};

const toggleAllExpanded = () => {
  if (allExpanded.value) {
    collapseAll();
    allExpanded.value = false;
  } else {
    expandAll();
    allExpanded.value = true;
  }
};

const fetchAgentsOnly = async () => {
  try {
    const activeAgents = await $trpc.listActiveAgents.query({
      serviceIds:
        selectedServiceIds.value.length > 0
          ? selectedServiceIds.value
          : undefined,
    });
    agents.value = activeAgents as ActiveAgent[];
  } catch (error) {
    console.error('Failed to fetch active agents:', error);
  }
};

const refreshAll = async () => {
  isLoadingSources.value = true;
  try {
    await servicesStore.fetchServices();
    await fetchAgentsOnly();
  } catch (error) {
    console.error('Refresh failed:', error);
  } finally {
    isLoadingSources.value = false;
  }
};

const startPolling = () => {
  if (pollingInterval) return;
  pollingInterval = setInterval(fetchAgentsOnly, 15000); // Poll agents every 15s
};

const stopPolling = () => {
  if (pollingInterval) {
    clearInterval(pollingInterval);
    pollingInterval = null;
  }
};

const onServiceSelected = useDebounceFn(async (val: string[]) => {
  isLoadingSources.value = true;
  selectedServiceIds.value = val;
  await fetchAgentsOnly();
  isLoadingSources.value = false;
}, 1000);

watch(
  activeTags,
  (newTags) => {
    sourceSearchTags.value = newTags.map((t) => `${t.type}:${t.value}`);
  },
  { deep: true },
);

watch(
  [selectedServiceIds, sourceSearchTags],
  () => {
    const query = { ...route.query };

    if (selectedServiceIds.value.length > 0) {
      query.selectedServiceIds = selectedServiceIds.value;
    } else {
      delete query.selectedServiceIds;
    }

    if (sourceSearchTags.value.length > 0) {
      query.sourceSearchTags = sourceSearchTags.value;
    } else {
      delete query.sourceSearchTags;
    }

    router.replace({ query });
  },
  { deep: true },
);

onMounted(async () => {
  isLoadingSources.value = true;
  if (servicesStore.services.length === 0) {
    await servicesStore.fetchServices();
  }
  await fetchAgentsOnly();
  isLoadingSources.value = false;
  startPolling();
});

onUnmounted(() => {
  stopPolling();
});

const filteredAgents = computed(() => {
  return agents.value.filter((agent) => {
    for (const tag of activeTags.value) {
      if (
        (tag.type === 'environment' || tag.type === 'env') &&
        agent.environment.toLowerCase() !== tag.value.toLowerCase()
      )
        return false;
      if (tag.type === 'serviceId' && agent.serviceId !== tag.value)
        return false;

      // Allow partial match on commitSha in case they only typed the first 8 chars
      if (
        (tag.type === 'commitSha' || tag.type === 'commit') &&
        !agent.commitSha.toLowerCase().startsWith(tag.value.toLowerCase())
      )
        return false;

      // Add serviceName tag filter support
      if (tag.type === 'serviceName') {
        const name = serviceNames.value[agent.serviceId] || agent.serviceId;
        if (name.toLowerCase() !== tag.value.toLowerCase()) return false;
      }

      // Add sdkVersion tag filter support
      if (
        tag.type === 'sdkVersion' ||
        tag.type === 'sdk' ||
        tag.type === 'version'
      ) {
        const val = normalizeSdkVersion(tag.value);
        const agentVer = normalizeSdkVersion(agent.sdkVersion);
        if (!agentVer || agentVer !== val) return false;
      }
    }

    return true;
  });
});

const deepGroupedFiltered = computed(() => {
  const grouped: Record<
    string,
    Record<string, Record<string, ActiveAgent[]>>
  > = {};

  for (const agent of filteredAgents.value) {
    if (!grouped[agent.serviceId]) {
      grouped[agent.serviceId] = {};
    }
    if (!grouped[agent.serviceId][agent.environment]) {
      grouped[agent.serviceId][agent.environment] = {};
    }
    if (!grouped[agent.serviceId][agent.environment][agent.commitSha]) {
      grouped[agent.serviceId][agent.environment][agent.commitSha] = [];
    }
    grouped[agent.serviceId][agent.environment][agent.commitSha].push(agent);
  }
  return grouped;
});
</script>
