<template>
  <div class="p-8">
    <h1 class="text-3xl font-bold mb-4 text-gray-900 dark:text-white">Dashboard</h1>
    <p class="text-gray-600 dark:text-gray-400">Welcome to HyperProbe! Please select a section from the sidebar.</p>
  </div>
</template>

<script setup lang="ts">
import { navigateTo } from '#app';

await navigateTo('/services', { replace: true });
</script>