<template>
  <div class="space-y-6">
      <div class="flex flex-col gap-4">
        <div class="flex justify-between items-center">
          <h1 class="text-2xl font-bold text-gray-900 dark:text-white">Services</h1>
          <div class="flex items-center gap-2">
            <UButton color="neutral" variant="outline" icon="i-heroicons-arrow-path" @click="refreshServices(true)"
              :loading="isLoadingServices">Refresh</UButton>
            <UButton color="secondary" @click="openCreateModal" icon="i-heroicons-plus">Create Service</UButton>
          </div>
        </div>
        <div
          class="flex items-center gap-4 flex-wrap bg-white dark:bg-gray-900 p-4 rounded-lg border border-gray-200 dark:border-gray-800">
          <UFormField label="Name">
            <UInput v-model="filters.name" icon="i-heroicons-magnifying-glass" placeholder="Filter by Name" class="w-48"
              @update:model-value="onSearch" />
          </UFormField>
          <UFormField label="ID">
            <UInput v-model="filters.id" icon="i-heroicons-hashtag" placeholder="Filter by ID" class="w-48"
              @update:model-value="onSearch" />
          </UFormField>
          <UFormField label="Teams">
            <USelectMenu v-model="filters.teamIds" :items="allTeams" value-key="id" label-key="name" multiple
              placeholder="Filter by Teams" class="w-48" @update:model-value="onSearch" />
          </UFormField>
        </div>
      </div>

      <UCard>
        <div class="overflow-x-auto">
          <table class="w-full text-left text-sm text-gray-500 dark:text-gray-400">
            <thead class="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-800 dark:text-gray-400 sticky">
              <tr>
                <th scope="col" class="px-6 py-3">Name</th>
                <th scope="col" class="px-6 py-3">ID</th>
                <th scope="col" class="px-6 py-3">Source Maps</th>
                <th v-if="isAdmin" scope="col" class="px-6 py-3">Agent Limit</th>
                <th scope="col" class="px-6 py-3">Teams Access</th>
                <th scope="col" class="px-6 py-3 text-right">Actions</th>
              </tr>
            </thead>
            <tbody>
              <tr v-for="service in services" :key="service.id"
                class="bg-white border-b dark:bg-gray-900 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-800">
                <td class="px-6 py-4 font-medium text-gray-900 dark:text-white">
                  <div class="flex items-center gap-2.5 group">
                    <UIcon :name="getLanguageIcon(service.language)" class="w-5 h-5 flex-shrink-0" />
                    <span>{{ service.name }}</span>
                    <CopyToClipboard :text="service.name" title="Service Name" />
                  </div>
                </td>
                <td class="px-6 py-4 font-mono text-sm text-gray-500 dark:text-gray-400">
                  <div class="flex items-center space-x-2 group">
                    <span>{{ service.id }}</span>
                    <CopyToClipboard :text="service.id" title="Service ID" />
                  </div>
                </td>
                <td class="px-6 py-4">
                  <UBadge :color="service.sourceMapRequired ? 'success' : 'neutral'" variant="subtle">
                    {{ service.sourceMapRequired ? 'Required' : 'No' }}
                  </UBadge>
                </td>
                <td v-if="isAdmin" class="px-6 py-4">
                  <span v-if="service.agentLimit != null" class="font-semibold">{{ service.agentLimit }}</span>
                  <span v-else class="text-gray-400">Inherit</span>
                </td>
                <td class="px-6 py-4 space-x-1">
                  <ServiceTeamsList :team-services="service.teamServices || []" :service-name="service.name"
                    show-roles />
                </td>
                <td class="px-6 py-4 text-right space-x-2">
                  <UButton
                    size="sm"
                    color="secondary"
                    variant="ghost"
                    icon="i-heroicons-puzzle-piece"
                    type="button"
                    :to="`/services/${service.id}/integrations`"
                    :title="canEdit(service) ? 'Configure Observability Integrations' : 'View Observability Integrations'"
                  />
                  <UButton :disabled="!canEdit(service)" size="sm" color="neutral" variant="ghost"
                    icon="i-heroicons-pencil" @click="openEditModal(service)"
                    :title="canEdit(service) ? 'Edit Service' : 'Only admins and managers can edit a service'" />
                  <UButton :disabled="!isAdmin" size="sm" color="info" variant="ghost" icon="i-heroicons-key"
                    @click="openAccessModal(service)"
                    :title="isAdmin ? 'Manage Access' : 'Only admins can manage access to a service'" />
                  <UButton :disabled="!canEdit(service)" size="sm" color="error" variant="ghost"
                    icon="i-heroicons-trash" @click="openDeleteModal(service)"
                    :title="canEdit(service) ? 'Delete Service' : 'Only admins and managers can delete a service'" />
                </td>
              </tr>
              <tr v-if="services.length === 0">
                <td :colspan="isAdmin ? 6 : 5" class="px-6 py-4 text-center">No services found.</td>
              </tr>
            </tbody>
          </table>
        </div>
        <div class="flex justify-end py-4 border-t border-gray-200 dark:border-gray-800" v-if="serviceCount > 0">
          <p class="text-sm text-gray-500 dark:text-gray-400 mt-1.5">Total: {{ serviceCount }}</p>
          &nbsp;&nbsp;&nbsp;
          <UPagination v-model:page="currentPage" :items-per-page="limit" :total="serviceCount"
            @update:page="updateServicesList" />
        </div>
      </UCard>

      <!-- Create/Edit Modal -->
      <UModal v-model:open="isModalOpen">
        <template #content>
          <UCard :ui="{ divide: 'divide-y divide-gray-100 dark:divide-gray-800' }">
            <template #header>
              <div class="flex items-center justify-between">
                <h3 class="text-base font-semibold leading-6 text-gray-900 dark:text-white">
                  {{ isEditing ? 'Edit Service' : 'Create Service' }}
                </h3>
                <UButton color="neutral" variant="ghost" icon="i-heroicons-x-mark-20-solid" class="-my-1"
                  @click="isModalOpen = false" />
              </div>
            </template>

            <form @submit.prevent="saveService" class="space-y-4">
              <div class="grid grid-cols-12 gap-4">
                <UFormField label="Service Name" required class="col-span-8">
                  <UInput v-model="formState.name" placeholder="Enter service name..." class="w-full" />
                </UFormField>

                <UFormField label="Language" required class="col-span-4">
                  <USelectMenu v-model="formState.language" :items="languageOptions" value-key="value" label-key="label"
                    placeholder="Select language..." class="w-full" :disabled="isEditing">
                    <template #leading>
                      <UIcon :name="getLanguageIcon(formState.language)" class="w-4 h-4 flex-shrink-0" />
                    </template>
                  </USelectMenu>
                </UFormField>
              </div>

              <UFormField v-if="!isEditing" label="Assign Teams (Manager Access)" required class="w-full">
                <USelectMenu v-model="formState.selectedTeams" :items="teamsWithAdminDisabled" value-key="id" label-key="name"
                  multiple placeholder="Select teams..." class="w-full">
                  <template #item-label="{ item }">
                    <div class="flex items-center justify-between" :title="item.isAdminTeam ? 'The global admin team inherently has access to all services and cannot be selected.' : ''">
                      <span>{{ item.name }}</span>
                      <UBadge v-if="item.isAdminTeam" color="primary" size="xs" variant="solid" class="font-semibold text-[9px] px-2 opacity-60">
                        Admin
                      </UBadge>
                    </div>
                  </template>
                </USelectMenu>
              </UFormField>

              <UFormField v-if="isAdmin" label="Agent Limit (Optional)" class="w-full">
                <UInput v-model="formState.agentLimit" type="number" min="0" placeholder="Inherit global soft limit"
                  class="w-full" />
              </UFormField>

              <UCheckbox v-if="formState.language === 'NODE'" v-model="formState.sourceMapRequired"
                description="Production JS line numbers differ from your TS source code. Source maps bridge this gap for accurate debugging.">
                <template #label>
                  <div class="flex items-center gap-2">
                    <span class="font-medium">Are source maps required?</span>
                  </div>
                </template>
              </UCheckbox>

              <div class="flex justify-end pt-4 space-x-3">
                <UButton color="neutral" variant="soft" @click="isModalOpen = false">Cancel</UButton>
                <UButton type="submit" color="secondary" :loading="isSaving">Save</UButton>
              </div>
            </form>
          </UCard>
        </template>
      </UModal>

      <!-- Access Management Modal -->
      <UModal v-model:open="isAccessModalOpen">
        <template #content>
          <UCard v-if="activeService">
            <template #header>
              <h3 class="text-base font-semibold">Manage Access: {{ activeService.name }}</h3>
            </template>
            <div class="space-y-4 max-h-[calc(100vh-232px)] overflow-y-auto pr-1">
              <template v-for="team in allTeams">
                <div v-if="!team.isAdminTeam" :key="team.id"
                  class="flex items-center justify-between p-2 border border-gray-100 dark:border-gray-800 rounded">
                  <div class="flex items-center gap-3">
                    <span class="text-sm font-medium">{{ team.name }}</span>
                    <USelectMenu v-model="teamRoles[team.id]" :items="roleOptions" value-key="value" label-key="label"
                      placeholder="No Access" @update:model-value="(val) => updateTeamRole(team.id, val)" />
                  </div>
                  <!-- Remove Access Button -->
                  <UButton v-if="teamRoles[team.id] != null" size="xs" color="error" variant="ghost"
                    icon="i-heroicons-trash" @click="openRevokeModal(team)" title="Remove Team Access" />
                </div>
              </template>
            </div>
            <template #footer>
              <UButton color="secondary" block @click="isAccessModalOpen = false">Close</UButton>
            </template>
          </UCard>
        </template>
      </UModal>

      <!-- Delete Confirmation Modal -->
      <CommonDeleteModal v-model:open="isDeleteModalOpen" title="Delete Service" :loading="isDeleting"
        @confirm="confirmDelete">
        Are you sure you want to delete the service <strong class="text-gray-900 dark:text-white">{{
          serviceToDelete?.name
        }}</strong>? This action cannot be undone.
      </CommonDeleteModal>

      <!-- Revoke Access Modal -->
      <CommonDeleteModal v-model:open="isRevokeModalOpen" title="Revoke Team Access" :loading="isRevoking"
        @confirm="confirmRevoke">
        Are you sure you want to revoke access for the team <strong class="text-gray-900 dark:text-white">{{
          teamToRevoke?.name }}</strong> from this service?
      </CommonDeleteModal>
      <Loader :loading="isLoadingServices" label="Loading services..." />
    </div>
</template>

<script setup lang="ts">
import type { inferRouterOutputs } from '@trpc/server';
import { computed, onMounted, ref, watch } from 'vue';
import { useNuxtApp, useRoute, useRouter } from '#app';
import type { AppRouter } from '../../../../backend/src/index';
import CopyToClipboard from '../../components/CopyToClipboard.vue';
import Loader from '../../components/Loader.vue';
import { useAppToast } from '../../composables/useAppToast';
import { useAuth } from '../../composables/useAuth';
import { useServicesStore } from '../../stores/services';
import { useTeamsStore } from '../../stores/teams';

type RouterOutput = inferRouterOutputs<AppRouter>;
const { $trpc } = useNuxtApp();
const route = useRoute();
const router = useRouter();
const { refresh } = useAuth();
const servicesStore = useServicesStore();
const teamsStore = useTeamsStore();
const toast = useAppToast();

const services = ref<RouterOutput['services']['list']>([]);
const serviceCount = ref(0);
const isLoadingServices = computed(() => servicesStore.isLoadingServices);
const allTeams = computed(() => teamsStore.teams);

const teamsWithAdminDisabled = computed(() => {
  return allTeams.value.map((team: RouterOutput['teams']['list'][0]) => ({
    ...team,
    disabled: team.isAdminTeam,
  }));
});
const currentUser = ref<RouterOutput['me']['query']>(null);

const parseArray = (val: any) => {
  if (!val) return [];
  return Array.isArray(val) ? val : [val];
};

const filters = ref({
  name: (route.query.name as string) || '',
  id: (route.query.id as string) || '',
  teamIds: parseArray(route.query.teamIds),
});

const currentPage = ref(Number(route.query.page) || 1);
const limit = ref(10);

function updateServicesList() {
  const { name, id, teamIds } = filters.value;
  const parsedTeamIds = teamIds.map((t: any) =>
    typeof t === 'object' ? t.id : t,
  );

  const filteredServices = servicesStore.services.filter((service: any) => {
    return (
      (!name || service.name.toLowerCase().includes(name.toLowerCase())) &&
      (!id || service.id.toLowerCase().includes(id.toLowerCase())) &&
      (parsedTeamIds.length === 0 ||
        service.teamServices.some((ts: any) =>
          parsedTeamIds.includes(ts.teamId),
        ))
    );
  });

  serviceCount.value = filteredServices.length;

  services.value = filteredServices.slice(
    (currentPage.value - 1) * limit.value,
    currentPage.value * limit.value,
  );
}

watch(
  [filters, currentPage],
  () => {
    const query = { ...route.query };

    if (filters.value.name) query.name = filters.value.name;
    else delete query.name;

    if (filters.value.id) query.id = filters.value.id;
    else delete query.id;

    const parsedTeamIds = filters.value.teamIds.map((t: any) =>
      typeof t === 'object' ? t.id : t,
    );
    if (parsedTeamIds.length > 0) query.teamIds = parsedTeamIds;
    else delete query.teamIds;

    if (currentPage.value > 1) query.page = String(currentPage.value);
    else delete query.page;

    router.replace({ query });
  },
  { deep: true },
);

const isModalOpen = ref(false);
const isAccessModalOpen = ref(false);
const isEditing = ref(false);
const isSaving = ref(false);
const activeService = ref<RouterOutput['services']['list'][0] | null>(null);

const isDeleteModalOpen = ref(false);
const isDeleting = ref(false);
const serviceToDelete = ref<RouterOutput['services']['list'][0] | null>(null);

// Revoke Access Modal State
const isRevokeModalOpen = ref(false);
const isRevoking = ref(false);
const teamToRevoke = ref<RouterOutput['teams']['list'][0] | null>(null);

const teamRoles = ref<Record<string, number | null>>({});

const formState = ref({
  id: '',
  name: '',
  language: 'NODE' as 'JAVA' | 'NODE' | 'PYTHON' | 'RUBY',
  selectedTeams: [] as { id: string }[],
  sourceMapRequired: false,
  agentLimit: null as number | null,
});

const roleOptions = [
  { label: 'Viewer', value: 10 },
  { label: 'Editor', value: 30 },
  { label: 'Manager', value: 50 },
];

const languageOptions = [
  { label: 'Java', value: 'JAVA', icon: 'i-logos-java' },
  { label: 'Node.js', value: 'NODE', icon: 'i-logos-nodejs-icon' },
  { label: 'Python', value: 'PYTHON', icon: 'i-logos-python' },
  { label: 'Ruby', value: 'RUBY', icon: 'i-logos-ruby' },
];

const getLanguageIcon = (lang: string) => {
  if (lang === 'JAVA') return 'i-logos-java';
  if (lang === 'NODE') return 'i-logos-nodejs-icon';
  if (lang === 'PYTHON') return 'i-logos-python';
  if (lang === 'RUBY') return 'i-logos-ruby';
  return 'i-heroicons-code-bracket';
};

async function refreshServices(showToast = false) {
  await servicesStore.fetchServices();
  updateServicesList();
  if (showToast) {
    toast.showSuccess('Success', 'Services data refreshed successfully');
  }
}

const loadUserAndTeams = async () => {
  try {
    currentUser.value = await $trpc.me.query();
    // Load teams for dropdowns
    await teamsStore.fetchTeams();
  } catch (error) {
    console.error('Failed to load data:', error);
  }
};

const onSearch = () => {
  currentPage.value = 1;
  updateServicesList();
};

onMounted(async () => {
  await loadUserAndTeams();
  await refreshServices();
});

const isAdmin = computed(
  () => currentUser.value?.permissions?.isAdmin === true,
);

const roleLabel = (role: number) => {
  if (role >= 50) return 'Manager';
  if (role >= 30) return 'Editor';
  return 'Viewer';
};

const canEdit = (service: RouterOutput['services']['list'][0]) => {
  if (isAdmin.value) return true;
  const myRole = currentUser.value?.permissions?.permissions[service.id];
  return myRole && myRole >= 50;
};

const openCreateModal = () => {
  isEditing.value = false;
  formState.value = {
    id: '',
    name: '',
    language: 'NODE' as 'JAVA' | 'NODE' | 'PYTHON' | 'RUBY',
    selectedTeams: [],
    sourceMapRequired: false,
    agentLimit: null,
  };
  isModalOpen.value = true;
};

const openEditModal = (service: RouterOutput['services']['list'][0]) => {
  isEditing.value = true;
  formState.value = {
    id: service.id,
    name: service.name,
    language: service.language as 'JAVA' | 'NODE' | 'PYTHON' | 'RUBY',
    selectedTeams: [],
    sourceMapRequired: service.sourceMapRequired ?? false,
    agentLimit: service.agentLimit ?? null,
  };
  isModalOpen.value = true;
};

const openAccessModal = (service: RouterOutput['services']['list'][0]) => {
  activeService.value = service;
  teamRoles.value = {};

  // Pre-fill current roles
  service.teamServices.forEach(
    (ts: RouterOutput['services']['list'][0]['teamServices'][0]) => {
      teamRoles.value[ts.teamId] = ts.role;
    },
  );

  isAccessModalOpen.value = true;
};

const updateTeamRole = async (teamId: string, roleValue: number | null) => {
  if (!activeService.value || roleValue === null) return;
  try {
    await servicesStore.updateServiceAccess({
      serviceId: activeService.value.id,
      teamId,
      role: roleValue,
    });
    // Reload services in background to reflect change
    updateServicesList();
  } catch (error) {
    console.error('Failed to update access:', error);
    useAppToast().showError('Error', (error as Error).message);
  }
};

const saveService = async () => {
  if (!formState.value.name.trim()) return;
  if (!isEditing.value && formState.value.selectedTeams.length === 0) {
    useAppToast().showError(
      'Validation Error',
      'Please select at least one team.',
    );
    return;
  }

  isSaving.value = true;
  try {
    const parsedTeamIds = formState.value.selectedTeams.map((t) =>
      typeof t === 'object' ? t.id : t,
    );
    const rawLimit = formState.value.agentLimit;
    const limitVal =
      isAdmin.value &&
      rawLimit !== '' &&
      rawLimit !== null &&
      rawLimit !== undefined
        ? Number(rawLimit)
        : null;
    if (isEditing.value) {
      await servicesStore.updateService({
        serviceId: formState.value.id,
        name: formState.value.name,
        sourceMapRequired:
          formState.value.language === 'NODE'
            ? formState.value.sourceMapRequired
            : false,
        ...(isAdmin.value ? { agentLimit: limitVal } : {}),
      });
    } else {
      await servicesStore.createService({
        name: formState.value.name,
        teamIds: parsedTeamIds,
        language: formState.value.language,
        sourceMapRequired:
          formState.value.language === 'NODE'
            ? formState.value.sourceMapRequired
            : false,
        ...(isAdmin.value ? { agentLimit: limitVal } : {}),
      });
    }

    await refresh();

    isModalOpen.value = false;
    updateServicesList();
    useAppToast().showSuccess('Service updated successfully');
  } catch (error) {
    console.error('Failed to save service:', error);
    useAppToast().showError('Error', (error as Error).message);
  } finally {
    isSaving.value = false;
  }
};

const openDeleteModal = (service: RouterOutput['services']['list'][0]) => {
  serviceToDelete.value = service;
  isDeleteModalOpen.value = true;
};

const confirmDelete = async () => {
  if (!serviceToDelete.value) return;

  isDeleting.value = true;
  try {
    await servicesStore.deleteService(serviceToDelete.value.id);
    isDeleteModalOpen.value = false;
    serviceToDelete.value = null;
    updateServicesList();
    useAppToast().showSuccess('Service deleted successfully');
  } catch (error) {
    console.error('Failed to delete service:', error);
    useAppToast().showError('Error', 'Failed to delete service.');
  } finally {
    isDeleting.value = false;
  }
};

// Revoke Access Modal Methods
const openRevokeModal = (team: RouterOutput['teams']['list'][0]) => {
  teamToRevoke.value = team;
  isRevokeModalOpen.value = true;
};

const confirmRevoke = async () => {
  if (!activeService.value || !teamToRevoke.value) return;

  isRevoking.value = true;
  try {
    await servicesStore.removeServiceAccess({
      serviceId: activeService.value.id,
      teamId: teamToRevoke.value.id,
    });
    teamRoles.value[teamToRevoke.value.id] = null;
    isRevokeModalOpen.value = false;
    teamToRevoke.value = null;

    updateServicesList();

    useAppToast().showSuccess('Team access revoked successfully');
  } catch (error) {
    console.error('Failed to revoke access:', error);
    useAppToast().showError(
      'Error',
      (error as Error).message || 'Failed to revoke team access',
    );
  } finally {
    isRevoking.value = false;
  }
};
</script>
