<template>
  <div class="mx-auto w-full max-w-4xl space-y-6 px-4 py-6 sm:px-6 lg:px-8">
      <div class="flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between">
        <div class="flex items-start gap-3">
          <UButton
            to="/services"
            color="neutral"
            variant="ghost"
            icon="i-heroicons-arrow-left"
            aria-label="Back to services"
          />
          <div>
            <p class="text-sm text-gray-500 dark:text-gray-400">Service observability</p>
            <h1 class="text-2xl font-semibold text-gray-900 dark:text-white">
              {{ service?.name || 'Observability' }}
            </h1>
            <p class="mt-1 max-w-2xl text-sm text-gray-600 dark:text-gray-300">
              Add a provider connection, test it, then choose which RCA capabilities may use it.
            </p>
          </div>
        </div>
        <UButton
          color="secondary"
          icon="i-heroicons-plus"
          :disabled="!canManage"
          @click="openProviderPicker"
        >
          Add connection
        </UButton>
      </div>

      <UAlert
        v-if="!canManage && !isLoadingPage"
        color="neutral"
        variant="soft"
        icon="i-heroicons-lock-closed"
        title="You have read-only access to this service's observability settings."
      />

      <div v-if="isLoadingPage" class="space-y-4">
        <USkeleton class="h-48 w-full" />
        <USkeleton class="h-48 w-full" />
      </div>

      <UAlert
        v-else-if="pageError"
        color="error"
        variant="soft"
        icon="i-heroicons-exclamation-circle"
        :title="pageError"
      >
        <template #description>
          <UButton color="error" variant="soft" class="mt-3" :loading="isRefreshing" @click="loadPage(true)">
            Try again
          </UButton>
        </template>
      </UAlert>

      <template v-else>
        <UCard :ui="{ root: 'overflow-visible' }">
          <template #header>
            <div class="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
              <div>
                <h2 class="text-base font-semibold text-gray-900 dark:text-white">Connections</h2>
                <p class="mt-1 text-sm text-gray-500 dark:text-gray-400">
                  Credentials are encrypted before storage and are never shown after saving.
                </p>
              </div>
            </div>
          </template>

          <UAlert
            v-if="connectionsLoadError"
            color="error"
            variant="soft"
            icon="i-heroicons-exclamation-circle"
            title="Connections could not be loaded"
            :description="connectionsLoadError"
          >
            <template #description>
              <p>{{ connectionsLoadError }}</p>
              <UButton color="error" variant="soft" class="mt-3" :loading="isRefreshing" @click="loadPage(true)">
                Try again
              </UButton>
            </template>
          </UAlert>

          <div v-else-if="connections.length" class="space-y-3">
            <div
              v-for="connection in connections"
              :key="connection.id"
              class="flex flex-col gap-4 rounded-lg border border-gray-200 p-4 dark:border-gray-800 sm:flex-row sm:items-start sm:justify-between"
            >
              <div class="relative min-w-0 pl-11">
                <div class="absolute left-0 top-0 flex size-8 items-center justify-center rounded-md bg-gray-950 text-white dark:bg-gray-800" aria-hidden="true">
                  <UIcon
                    :name="connection.provider === 'SENTRY' ? 'i-heroicons-exclamation-triangle' : 'i-heroicons-square-3-stack-3d'"
                    class="size-4"
                  />
                </div>
                <div class="flex flex-wrap items-center gap-2">
                  <p class="font-medium text-gray-900 dark:text-white">{{ connection.name }}</p>
                  <UBadge color="neutral" variant="subtle">
                    {{ providerDisplayName(connection.provider) }}
                  </UBadge>
                  <UBadge :color="connection.enabled ? 'success' : 'warning'" variant="subtle">
                    {{ connection.enabled ? 'Enabled' : 'Disabled' }}
                  </UBadge>
                  <UBadge :color="connectionTestStatusColor(connection)" variant="subtle">
                    {{ connectionTestStatusLabel(connection) }}
                  </UBadge>
                </div>
                <p class="mt-1 text-sm text-gray-600 dark:text-gray-300">
                  {{ connectionSummary(connection) }}
                </p>
                <p class="mt-1 text-xs text-gray-500 dark:text-gray-400">
                  {{ connectionCapabilitySummary(connection) }}
                </p>
                <p
                  v-if="connectionTestDetail(connection)"
                  class="mt-1 text-xs text-gray-500 dark:text-gray-400"
                >
                  {{ connectionTestDetail(connection) }}
                </p>
                <details
                  v-if="connectionTestUnavailableChecks(connection).length || connectionTestMessages(connection).length"
                  class="mt-2 text-xs text-gray-500 dark:text-gray-400"
                >
                  <summary class="cursor-pointer">View test details</summary>
                  <p v-if="connectionTestUnavailableChecks(connection).length" class="mt-1">
                    Unavailable: {{ connectionTestUnavailableChecks(connection).join(', ') }}.
                  </p>
                  <ul class="mt-1 space-y-1">
                    <li v-for="(message, index) in connectionTestMessages(connection)" :key="index">
                      {{ message }}
                    </li>
                  </ul>
                </details>
                <p
                  v-if="connectionTestFailure(connection)"
                  class="mt-1 text-xs text-red-600 dark:text-red-400"
                >
                  {{ connectionTestFailure(connection) }}
                </p>
              </div>

              <div v-if="canManage" class="flex shrink-0 flex-wrap items-start gap-2">
                <UButton
                  color="neutral"
                  variant="soft"
                  :loading="isTestingConnection(connection)"
                  :disabled="!connection.enabled || connectionEnabledUpdates[connection.id]?.snapshot === connection"
                  :aria-label="`Test ${connection.name}`"
                  @click="runConnectionTest(connection)"
                >
                  {{ connectionTestSucceeded(connection) ? 'Test again' : 'Test connection' }}
                </UButton>
                <UDropdownMenu
                  :items="getConnectionMenuItems(connection)"
                  :content="{ align: 'end' }"
                  :modal="false"
                >
                  <UButton
                    color="neutral"
                    variant="soft"
                    trailing-icon="i-heroicons-chevron-down-20-solid"
                    :aria-label="`Manage ${connection.name}`"
                  >
                    Manage
                  </UButton>
                </UDropdownMenu>
              </div>
            </div>
          </div>

          <div v-else class="space-y-4">
            <UAlert
              :color="canManage ? 'primary' : 'neutral'"
              variant="soft"
              icon="i-heroicons-information-circle"
              title="Add an observability connection"
              :description="canManage ? 'Choose a provider, save its project details, and test it before assigning it to RCA capabilities.' : 'A service manager can add and test a provider connection.'"
            />
            <UButton
              v-if="canManage"
              color="secondary"
              icon="i-heroicons-plus"
              :loading="isLoadingProviders"
              @click="openProviderPicker"
            >
              Add connection
            </UButton>
          </div>
        </UCard>

        <UCard>
          <template #header>
            <div class="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
              <div>
                <h2 class="text-base font-semibold text-gray-900 dark:text-white">RCA capabilities</h2>
                <p class="mt-1 text-sm text-gray-500 dark:text-gray-400">
                  Choose one tested connection for each type of evidence RCA may use.
                </p>
              </div>
              <UButton
                v-if="canManage"
                color="secondary"
                :loading="isSavingCapabilities"
                :disabled="Boolean(capabilityConnectionsLoadError || connectionsLoadError) || isSavingConnection"
                @click="saveCapabilityConnections"
              >
                Save
              </UButton>
            </div>
          </template>

          <UAlert
            v-if="capabilityConnectionsLoadError"
            color="error"
            variant="soft"
            icon="i-heroicons-exclamation-circle"
            title="RCA capabilities could not be loaded"
            :description="capabilityConnectionsLoadError"
          >
            <template #description>
              <p>{{ capabilityConnectionsLoadError }}</p>
              <UButton color="error" variant="soft" class="mt-3" :loading="isRefreshing" @click="loadPage(true)">
                Try again
              </UButton>
            </template>
          </UAlert>

          <div v-else class="space-y-3">
            <UAlert
              v-if="connections.length && !hasTestedConnection"
              color="warning"
              variant="soft"
              icon="i-heroicons-exclamation-triangle"
              title="Test a connection before assigning it"
              description="Test results are kept while this page is open. Existing assignments remain unchanged until you save new choices."
            />
            <UAlert
              v-else-if="!connections.length"
              color="neutral"
              variant="soft"
              icon="i-heroicons-information-circle"
              title="No tested connections yet"
              description="Add and test a provider connection before assigning RCA capabilities."
            />
            <UAlert
              v-if="capabilitySaveError"
              color="error"
              variant="soft"
              icon="i-heroicons-exclamation-circle"
              :title="capabilitySaveError"
            />

            <div
              v-for="capability in capabilityRows"
              :key="capability.signal"
              class="flex flex-col gap-3 rounded-lg border border-gray-200 p-4 dark:border-gray-800 sm:flex-row sm:items-center sm:justify-between"
            >
              <div class="relative min-w-0 pl-11">
                <div class="absolute left-0 top-0 flex size-8 items-center justify-center rounded-md bg-gray-100 text-gray-500 dark:bg-gray-800 dark:text-gray-400" aria-hidden="true">
                  <UIcon :name="capability.icon" class="size-4" />
                </div>
                <div class="flex items-center gap-2">
                  <p class="font-medium text-gray-900 dark:text-white">{{ capability.label }}</p>
                  <UBadge :color="capabilityStatusColor(capability)" variant="subtle">
                    {{ capabilityStatusLabel(capability) }}
                  </UBadge>
                </div>
                <p class="mt-1 text-xs text-gray-500 dark:text-gray-400">
                  {{ capability.description }}
                </p>
              </div>
              <USelect
                v-model="capabilitySelections[capability.signal]"
                class="w-full min-w-0 sm:w-72"
                :items="capability.options"
                value-key="value"
                label-key="label"
                :disabled="!canManage || isSavingCapabilities || isSavingConnection || Boolean(connectionsLoadError)"
              />
            </div>
          </div>
        </UCard>

        <UCard>
          <details>
            <summary class="cursor-pointer font-medium text-gray-900 dark:text-white">
              How RCA uses these choices
            </summary>
            <p class="mt-3 text-sm text-gray-600 dark:text-gray-300">
              RCA uses only the connection selected for the evidence capability it needs. A capability without a connection is never queried.
            </p>
          </details>
        </UCard>
      </template>

      <UModal v-model:open="isProviderPickerOpen" scrollable>
        <template #content>
          <UCard class="w-full sm:max-w-xl">
            <template #header>
              <div class="flex items-start justify-between gap-3">
                <div>
                  <h3 class="text-base font-semibold text-gray-900 dark:text-white">Choose a provider</h3>
                  <p class="mt-1 text-sm text-gray-500 dark:text-gray-400">
                    Add a connection for a provider available to this service.
                  </p>
                </div>
                <UButton
                  color="neutral"
                  variant="ghost"
                  icon="i-heroicons-x-mark"
                  aria-label="Close provider selection"
                  @click="isProviderPickerOpen = false"
                />
              </div>
            </template>

            <div v-if="isLoadingProviders" class="space-y-3">
              <USkeleton class="h-24 w-full" />
            </div>
            <UAlert
              v-else-if="providerLoadError"
              color="error"
              variant="soft"
              icon="i-heroicons-exclamation-circle"
              title="Available providers could not be loaded"
              :description="providerLoadError"
            />
            <UAlert
              v-else-if="!providers.length"
              color="warning"
              variant="soft"
              icon="i-heroicons-information-circle"
              title="No providers are available"
              description="Try refreshing shortly."
            />
            <div v-else class="space-y-3">
              <UButton
                v-for="provider in providers"
                :key="provider.provider"
                color="neutral"
                variant="outline"
                class="h-auto w-full justify-start p-4 text-left"
                @click="selectProvider(provider)"
              >
                <div class="min-w-0 space-y-1">
                  <p class="font-medium text-gray-900 dark:text-white">{{ provider.displayName }}</p>
                  <p class="text-xs text-gray-600 dark:text-gray-300">
                    Supports: {{ provider.supportedSignals.map(formatSignal).join(', ') || 'No advertised capabilities' }}
                  </p>
                  <p class="text-xs text-gray-500 dark:text-gray-400">{{ provider.credentialGuidance }}</p>
                </div>
              </UButton>
            </div>
          </UCard>
        </template>
      </UModal>

      <UModal
        v-model:open="isConnectionModalOpen"
        :title="connectionForm.connectionId ? 'Edit Sentry connection' : 'Connect Sentry'"
        description="Link one Sentry project so error data can flow in. We'll save and test the connection."
        :dismissible="!isSavingConnection"
        :ui="{ content: 'md:max-w-xl rounded-xl' }"
        scrollable
        @after:leave="isAuthTokenVisible = false"
      >
        <template #content>
          <UCard
            class="w-full rounded-xl"
            :ui="{ root: 'ring-0 shadow-none', header: 'px-5 py-5 sm:px-6', body: 'p-5 sm:p-6' }"
          >
            <template #header>
              <div class="flex items-start justify-between gap-3">
                <div class="flex items-start gap-3">
                  <div class="mt-0.5 flex size-8 shrink-0 items-center justify-center rounded-md bg-gray-950 text-white dark:bg-gray-800">
                    <UIcon name="i-heroicons-exclamation-triangle" class="size-4" />
                  </div>
                  <div>
                    <h3 class="text-sm font-semibold text-gray-900 dark:text-white">
                      {{ connectionForm.connectionId ? 'Edit Sentry connection' : 'Connect Sentry' }}
                    </h3>
                    <p class="mt-1 max-w-100 text-xs leading-relaxed text-gray-500 dark:text-gray-400">
                      Link one Sentry project so error data can flow in. We'll save and test the connection.
                    </p>
                  </div>
                </div>
                <UButton
                  color="neutral"
                  variant="ghost"
                  size="xs"
                  class="-mr-1 -mt-1 shrink-0 text-gray-400"
                  icon="i-heroicons-x-mark"
                  aria-label="Close Sentry connection dialog"
                  :disabled="isSavingConnection"
                  @click="isConnectionModalOpen = false"
                />
              </div>
            </template>

            <form class="space-y-4" @submit.prevent="saveConnection">
              <div class="space-y-2">
                <div class="grid grid-cols-1 gap-3 sm:grid-cols-2">
                  <UFormField label="Organization slug" size="sm" required>
                    <UInput v-model="connectionForm.orgSlug" class="w-full" size="sm" placeholder="acme" aria-describedby="sentry-project-help" required>
                      <template #leading>
                        <span class="text-gray-400" aria-hidden="true">/</span>
                      </template>
                    </UInput>
                  </UFormField>
                  <UFormField label="Project ID" size="sm" required>
                    <UInput v-model="connectionForm.projectId" class="w-full" size="sm" inputmode="numeric" placeholder="123456" aria-describedby="sentry-project-help" required />
                  </UFormField>
                </div>
                <p id="sentry-project-help" class="text-xs leading-relaxed text-gray-400 dark:text-gray-500">
                  Find both in Sentry under <span class="font-medium text-secondary-600 dark:text-secondary-400">Project Settings &gt; General Settings</span>.
                  The project ID stays fixed even if the slug is renamed later, so we use it to keep the connection stable.
                </p>
              </div>
              <div class="space-y-2">
                <UFormField label="Auth token" size="sm" :required="!connectionForm.connectionId">
                  <UInput
                    v-model="connectionForm.authToken"
                    class="w-full"
                    size="sm"
                    :type="isAuthTokenVisible ? 'text' : 'password'"
                    :ui="{ trailing: 'pe-1', base: 'pe-14' }"
                    autocomplete="off"
                    aria-describedby="sentry-token-help"
                    :placeholder="connectionForm.connectionId ? 'Leave blank to keep the current token' : 'Paste a token with project read access'"
                    :required="!connectionForm.connectionId"
                  >
                    <template #trailing>
                      <UButton
                        type="button"
                        color="neutral"
                        variant="link"
                        size="xs"
                        :aria-label="isAuthTokenVisible ? 'Hide auth token' : 'Show auth token'"
                        :aria-pressed="isAuthTokenVisible"
                        @click="isAuthTokenVisible = !isAuthTokenVisible"
                      >
                        {{ isAuthTokenVisible ? 'Hide' : 'Show' }}
                      </UButton>
                    </template>
                  </UInput>
                </UFormField>
                <p id="sentry-token-help" class="flex items-start gap-1.5 text-xs leading-relaxed text-gray-400 dark:text-gray-500">
                  <UIcon name="i-heroicons-lock-closed" class="mt-0.5 size-3 shrink-0" />
                  <span>Encrypted at rest. We can't display it again after saving, only replace it.</span>
                </p>
              </div>

              <details
                :open="isAdvancedConnectionFormOpen"
                class="group border-t border-gray-100 pt-3 dark:border-gray-800"
                @toggle="setAdvancedConnectionFormOpen"
              >
                <summary class="flex min-h-11 cursor-pointer list-none items-center justify-between gap-3 rounded-md border border-gray-200 bg-gray-50 px-3 py-2 text-xs font-medium text-gray-700 transition-colors hover:border-secondary-300 hover:bg-secondary-50 hover:text-secondary-700 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-secondary dark:border-gray-700 dark:bg-gray-800/50 dark:text-gray-200 dark:hover:border-secondary-600 dark:hover:bg-secondary-950 dark:hover:text-secondary-300 [&::-webkit-details-marker]:hidden">
                  <span>Using self-hosted Sentry or a custom label?</span>
                  <UIcon name="i-heroicons-chevron-down" class="size-4 shrink-0 transition-transform group-open:rotate-180" aria-hidden="true" />
                </summary>
                <div class="mt-3 space-y-4">
                  <UFormField label="Connection label (optional)" size="sm">
                    <UInput v-model="connectionForm.name" class="w-full" size="sm" placeholder="Defaults to organization / project" />
                  </UFormField>
                  <UFormField label="Sentry API URL" size="sm" required>
                    <UInput v-model="connectionForm.apiBaseUrl" class="w-full" size="sm" type="url" required />
                  </UFormField>
                  <p class="text-xs text-gray-500 dark:text-gray-400">
                    Custom URLs must use HTTPS and be allowed by the deployment configuration.
                  </p>
                </div>
              </details>

              <UAlert v-if="connectionFormError" color="error" variant="soft" :title="connectionFormError" />
              <div class="flex flex-wrap justify-end gap-3 pt-2">
                <UButton type="button" color="neutral" variant="ghost" size="sm" :disabled="isSavingConnection" @click="isConnectionModalOpen = false">
                  Cancel
                </UButton>
                <UButton type="submit" color="secondary" size="sm" :loading="isSavingConnection">
                  Save and test connection
                </UButton>
              </div>
            </form>
          </UCard>
        </template>
      </UModal>

      <UModal v-model:open="isDeleteModalOpen" :dismissible="!isDeletingConnection">
        <template #content>
          <UCard class="w-full sm:max-w-lg">
            <template #header>
              <div class="flex items-center justify-between gap-3">
                <h3 class="text-base font-semibold text-gray-900 dark:text-white">
                  Delete connection
                </h3>
                <UButton
                  color="neutral"
                  variant="ghost"
                  icon="i-heroicons-x-mark"
                  aria-label="Close delete connection dialog"
                  :disabled="isDeletingConnection"
                  @click="isDeleteModalOpen = false"
                />
              </div>
            </template>

            <div class="space-y-3 text-sm text-gray-600 dark:text-gray-300">
              <p>
                Delete <strong>{{ connectionToDelete?.name }}</strong>? Its credentials and configuration will be removed.
              </p>
              <p v-if="deleteAffectedCapabilities.length">
                This also unassigns: {{ deleteAffectedCapabilities.join(', ') }}.
              </p>
              <p v-else-if="capabilityConnectionsLoadError">
                RCA capability assignments could not be loaded. Reload this page before deleting the connection.
              </p>
              <p v-else>No RCA capabilities currently use this connection.</p>
              <p>RCA audit history remains until the service is deleted.</p>
            </div>

            <template #footer>
              <div class="flex flex-wrap justify-end gap-3">
                <UButton color="neutral" variant="soft" :disabled="isDeletingConnection" @click="isDeleteModalOpen = false">
                  Cancel
                </UButton>
                <UButton
                  color="error"
                  :loading="isDeletingConnection"
                  :disabled="Boolean(capabilityConnectionsLoadError)"
                  @click="deleteConnection"
                >
                  Delete and unassign
                </UButton>
              </div>
            </template>
          </UCard>
        </template>
      </UModal>
    </div>
</template>

<script setup lang="ts">
import { TRPCClientError } from '@trpc/client';
import type { inferRouterInputs, inferRouterOutputs } from '@trpc/server';
import { computed, onBeforeUnmount, onMounted, ref, watch } from 'vue';
import { useNuxtApp, useRoute } from '#app';
import type { AppRouter } from '../../../../../backend/src/index';
import { useAppToast } from '../../../composables/useAppToast';

type RouterOutput = inferRouterOutputs<AppRouter>;
type RouterInput = inferRouterInputs<AppRouter>;
type Connection =
  RouterOutput['observabilityIntegrations']['listConnections'][number];
type CapabilityConnection =
  RouterOutput['observabilityIntegrations']['listCapabilityConnections'][number];
type CapabilityConnectionInput =
  RouterInput['observabilityIntegrations']['setCapabilityConnections']['capabilities'][number];
type CapabilitySignal = CapabilityConnection['signal'];
type ProviderMetadata =
  RouterOutput['observabilityIntegrations']['listProviders'][number];
type ConnectionTestState = {
  connectionRevision: string;
  status: 'not-tested' | 'checking' | 'ready' | 'partial' | 'failed';
  testedAt?: Date;
  availableChecks?: number;
  unavailableChecks?: string[];
  failures?: RouterOutput['observabilityIntegrations']['testConnection']['failures'];
  warnings?: string[];
  error?: string;
  retryAt?: string;
};
type ConnectionTestStatus = ConnectionTestState['status'] | 'disabled';
type BadgeColor = 'neutral' | 'success' | 'warning' | 'error';

const DEFAULT_SENTRY_API_URL = 'https://sentry.io/api/0/';
const UNASSIGNED_CONNECTION = '__unassigned__';

const { $trpc } = useNuxtApp();
const route = useRoute();
const toast = useAppToast();
const serviceId = computed(() => {
  const value = route.params.serviceId;
  return Array.isArray(value) ? value[0] || '' : String(value || '');
});

const service = ref<RouterOutput['services']['list'][number] | null>(null);
const currentUser = ref<RouterOutput['me'] | null>(null);
const connections = ref<Connection[]>([]);
const providers = ref<ProviderMetadata[]>([]);
const capabilityConnections = ref<CapabilityConnection[]>([]);
const capabilitySelections = ref<Record<CapabilitySignal, string>>(
  {} as Record<CapabilitySignal, string>,
);
const savedCapabilitySelections = ref<Record<CapabilitySignal, string>>(
  {} as Record<CapabilitySignal, string>,
);
const connectionTestStates = ref<Record<string, ConnectionTestState>>({});
const connectionEnabledUpdates = ref<
  Record<string, { token: symbol; snapshot: Connection }>
>({});
const isLoadingPage = ref(true);
const isRefreshing = ref(false);
const pageError = ref('');
const connectionsLoadError = ref('');
const capabilityConnectionsLoadError = ref('');
const isLoadingProviders = ref(false);
const providerLoadError = ref('');
const isSavingCapabilities = ref(false);
const capabilitySaveError = ref('');
const isProviderPickerOpen = ref(false);
const isConnectionModalOpen = ref(false);
const isAuthTokenVisible = ref(false);
const isSavingConnection = ref(false);
const isAdvancedConnectionFormOpen = ref(false);
const connectionFormError = ref('');
const isDeleteModalOpen = ref(false);
const isDeletingConnection = ref(false);
const connectionToDelete = ref<Connection | null>(null);
let isPageActive = true;

const canManage = computed(() => {
  if (currentUser.value?.permissions?.isAdmin) return true;
  const role = currentUser.value?.permissions?.permissions[serviceId.value];
  return role !== undefined && role >= 50;
});

const CAPABILITY_DETAILS: Record<
  CapabilitySignal,
  { label: string; description: string; icon: string }
> = {
  ERRORS: {
    label: 'Errors',
    description: 'Application exceptions and error events.',
    icon: 'i-heroicons-exclamation-triangle',
  },
  LOGS: {
    label: 'Logs',
    description: 'Structured log events and messages.',
    icon: 'i-heroicons-bars-3-bottom-left',
  },
  TRACES: {
    label: 'Traces',
    description: 'Distributed trace and span evidence.',
    icon: 'i-heroicons-share',
  },
  METRICS: {
    label: 'Metrics',
    description: 'Throughput and failure-rate time series.',
    icon: 'i-heroicons-arrow-trending-up',
  },
  ALERTS: {
    label: 'Alerts',
    description: 'Provider alert state and notification history.',
    icon: 'i-heroicons-bell',
  },
};

function formatSignal(signal: string) {
  return signal.charAt(0).toUpperCase() + signal.slice(1).toLowerCase();
}

function providerDisplayName(provider: string) {
  const metadata = providers.value.find(
    (candidate) => candidate.provider === provider,
  );
  if (metadata) return metadata.displayName;
  return provider
    .toLowerCase()
    .split(/[_-]/)
    .map((part) => part.charAt(0).toUpperCase() + part.slice(1))
    .join(' ');
}

function connectionRevision(connection: Connection) {
  return connection.updatedAt.toISOString();
}

function connectionTestState(connection: Connection) {
  const state = connectionTestStates.value[connection.id];
  return state?.connectionRevision === connectionRevision(connection)
    ? state
    : undefined;
}

function connectionTestStatus(connection: Connection): ConnectionTestStatus {
  if (!connection.enabled) return 'disabled';
  return connectionTestState(connection)?.status ?? 'not-tested';
}

function connectionTestStatusLabel(connection: Connection) {
  const labels: Record<ConnectionTestStatus, string> = {
    'not-tested': 'Not tested',
    checking: 'Testing',
    ready: 'Verified',
    partial: 'Partially verified',
    failed: 'Failed',
    disabled: 'Disabled',
  };
  return labels[connectionTestStatus(connection)];
}

function connectionTestStatusColor(connection: Connection): BadgeColor {
  const colors: Record<ConnectionTestStatus, BadgeColor> = {
    'not-tested': 'neutral',
    checking: 'warning',
    ready: 'success',
    partial: 'warning',
    failed: 'error',
    disabled: 'warning',
  };
  return colors[connectionTestStatus(connection)];
}

function connectionTestSucceeded(connection: Connection) {
  const status = connectionTestState(connection)?.status;
  return status === 'ready' || status === 'partial';
}

function isTestingConnection(connection: Connection) {
  return connectionTestState(connection)?.status === 'checking';
}

function isUpdatingConnectionEnabled(connectionId: string) {
  return Boolean(connectionEnabledUpdates.value[connectionId]);
}

function connectionTestDetail(connection: Connection) {
  const state = connectionTestState(connection);
  if (state?.status === 'ready') return 'All capability checks are available.';
  if (state?.status === 'partial') {
    const missing = state.unavailableChecks?.length
      ? ` (${state.unavailableChecks.join(', ')} unavailable)`
      : '';
    const guidance = missing
      ? 'evidence filtering for missing checks may be limited'
      : 'review the test details below';
    return `${state.availableChecks ?? 1} of 4 capability checks are available${missing}. You can assign this connection, but ${guidance}.`;
  }
  return '';
}

function connectionTestUnavailableChecks(connection: Connection) {
  return connectionTestState(connection)?.unavailableChecks ?? [];
}

function formatRetryAt(retryAt: string) {
  const date = new Date(retryAt);
  return Number.isNaN(date.getTime())
    ? retryAt
    : date.toLocaleString(undefined, { timeZoneName: 'short' });
}

function connectionTestMessages(connection: Connection) {
  const state = connectionTestState(connection);
  return [
    ...(state?.failures ?? []).map(
      (failure) =>
        `${failure.section ? formatSignal(failure.section) : failure.connectionName} (${failure.code}): ${failure.reason}${failure.retryAt ? ` Retry after ${formatRetryAt(failure.retryAt)}.` : ''}`,
    ),
    ...(state?.warnings ?? []),
  ];
}

function connectionTestFailure(connection: Connection) {
  const state = connectionTestState(connection);
  if (state?.status !== 'failed') return '';
  const message = state.error || 'Connection test failed.';
  return `${message}${state.retryAt ? ` Retry after ${formatRetryAt(state.retryAt)}.` : ''}`;
}

function connectionSummary(connection: Connection) {
  if (connection.provider === 'SENTRY') {
    const config = connection.publicConfig;
    if (
      typeof config === 'object' &&
      config !== null &&
      !Array.isArray(config)
    ) {
      const orgSlug = (config as Record<string, unknown>).orgSlug;
      const projectSlug = (config as Record<string, unknown>).projectSlug;
      if (typeof orgSlug === 'string' && typeof projectSlug === 'string') {
        return `Sentry project: ${orgSlug}/${projectSlug}`;
      }
    }
  }
  return `Configuration version ${connection.configVersion}`;
}

function assignedCapabilityLabels(connectionId: string) {
  return capabilityConnections.value
    .filter((capability) => capability.connectionId === connectionId)
    .map((capability) => CAPABILITY_DETAILS[capability.signal].label);
}

function connectionCapabilitySummary(connection: Connection) {
  const capabilities = assignedCapabilityLabels(connection.id);
  if (!capabilities.length) return 'Not assigned to an RCA capability.';
  return connection.enabled
    ? `Used for: ${capabilities.join(', ')}.`
    : `RCA is paused for: ${capabilities.join(', ')}.`;
}

function capabilityStatusLabel(capability: CapabilityConnection) {
  if (!capability.connectionId) return 'Not enabled';
  const connection = connections.value.find(
    (candidate) => candidate.id === capability.connectionId,
  );
  return connection?.enabled === false ? 'Paused' : 'Enabled';
}

function capabilityStatusColor(capability: CapabilityConnection): BadgeColor {
  if (!capability.connectionId) return 'neutral';
  return capabilityStatusLabel(capability) === 'Paused' ? 'warning' : 'success';
}

const hasTestedConnection = computed(() =>
  connections.value.some(
    (connection) => connection.enabled && connectionTestSucceeded(connection),
  ),
);

const capabilityRows = computed(() =>
  capabilityConnections.value.map((capability) => {
    const selection =
      capabilitySelections.value[capability.signal] ?? UNASSIGNED_CONNECTION;
    const selectedConnection = connections.value.find(
      (connection) => connection.id === selection,
    );
    const testedConnections = connections.value.filter(
      (connection) =>
        connection.enabled &&
        connectionTestSucceeded(connection) &&
        (connection.supportedSignals as readonly string[]).includes(
          capability.signal,
        ),
    );
    const options = [
      { label: 'Not enabled', value: UNASSIGNED_CONNECTION },
      ...testedConnections.map((connection) => {
        const isPartial = connectionTestState(connection)?.status === 'partial';
        return {
          label: `${providerDisplayName(connection.provider)} - ${connection.name}${isPartial ? ' (Partially verified)' : ''}`,
          value: connection.id,
        };
      }),
    ];
    if (
      selectedConnection &&
      !testedConnections.some(
        (connection) => connection.id === selectedConnection.id,
      )
    ) {
      options.push({
        label: `${providerDisplayName(selectedConnection.provider)} - ${selectedConnection.name} (current assignment)`,
        value: selectedConnection.id,
      });
    }
    return {
      ...capability,
      ...CAPABILITY_DETAILS[capability.signal],
      options,
    };
  }),
);

const deleteAffectedCapabilities = computed(() => {
  const connectionId = connectionToDelete.value?.id;
  return connectionId ? assignedCapabilityLabels(connectionId) : [];
});

function applyCapabilityConnections(assignments: CapabilityConnection[]) {
  capabilityConnections.value = assignments;
  const selections = Object.fromEntries(
    assignments.map((assignment) => [
      assignment.signal,
      assignment.connectionId ?? UNASSIGNED_CONNECTION,
    ]),
  ) as Record<CapabilitySignal, string>;
  capabilitySelections.value = selections;
  savedCapabilitySelections.value = { ...selections };
}

function defaultConnectionName(orgSlug: string, projectId: string) {
  const name = `${orgSlug} / ${projectId}`;
  if (name.length <= 128) return name;
  return `${orgSlug.slice(0, 62)} / ${projectId.slice(0, 63)}`;
}

function errorMessage(error: unknown, fallback: string) {
  return error instanceof Error && error.message.trim()
    ? error.message
    : fallback;
}

async function loadPage(refresh = false) {
  if (refresh) isRefreshing.value = true;
  else isLoadingPage.value = true;
  pageError.value = '';
  connectionsLoadError.value = '';
  capabilityConnectionsLoadError.value = '';
  void loadProviders();
  try {
    const [servicesResult, userResult, connectionsResult, capabilitiesResult] =
      await Promise.allSettled([
        $trpc.services.list.query(),
        $trpc.me.query(),
        $trpc.observabilityIntegrations.listConnections.query({
          serviceId: serviceId.value,
        }),
        $trpc.observabilityIntegrations.listCapabilityConnections.query({
          serviceId: serviceId.value,
        }),
      ]);
    if (servicesResult.status !== 'fulfilled') throw servicesResult.reason;
    if (userResult.status !== 'fulfilled') throw userResult.reason;
    service.value =
      servicesResult.value.find(
        (candidate) => candidate.id === serviceId.value,
      ) ?? null;
    if (!service.value) {
      throw new Error('Service not found or you do not have access to it.');
    }
    currentUser.value = userResult.value;

    if (connectionsResult.status === 'fulfilled') {
      connections.value = connectionsResult.value;
      const currentTestStates: Record<string, ConnectionTestState> = {};
      for (const connection of connections.value) {
        const state = connectionTestState(connection);
        if (state) currentTestStates[connection.id] = state;
      }
      connectionTestStates.value = currentTestStates;
    } else {
      connections.value = [];
      connectionsLoadError.value = errorMessage(
        connectionsResult.reason,
        'Could not load provider connections.',
      );
    }

    if (capabilitiesResult.status === 'fulfilled') {
      applyCapabilityConnections(capabilitiesResult.value);
    } else {
      capabilityConnections.value = [];
      capabilitySelections.value = {} as Record<CapabilitySignal, string>;
      savedCapabilitySelections.value = {} as Record<CapabilitySignal, string>;
      capabilityConnectionsLoadError.value = errorMessage(
        capabilitiesResult.reason,
        'Could not load RCA capabilities.',
      );
    }
  } catch (error) {
    pageError.value = errorMessage(
      error,
      'Could not load service observability settings.',
    );
  } finally {
    isLoadingPage.value = false;
    isRefreshing.value = false;
  }
}

async function loadProviders() {
  isLoadingProviders.value = true;
  providerLoadError.value = '';
  try {
    providers.value =
      await $trpc.observabilityIntegrations.listProviders.query();
  } catch (error) {
    providerLoadError.value = errorMessage(
      error,
      'Could not load available providers.',
    );
  } finally {
    isLoadingProviders.value = false;
  }
}

function openProviderPicker() {
  isProviderPickerOpen.value = true;
  if (!isLoadingProviders.value) void loadProviders();
}

function selectProvider(provider: ProviderMetadata) {
  if (provider.provider !== 'SENTRY') {
    toast.showError(
      'Provider setup is not available yet',
      `${provider.displayName} cannot be connected from this version of the dashboard.`,
    );
    return;
  }
  isProviderPickerOpen.value = false;
  connectionForm.value = {
    connectionId: null,
    name: '',
    authToken: '',
    orgSlug: '',
    projectId: '',
    apiBaseUrl: DEFAULT_SENTRY_API_URL,
  };
  isAdvancedConnectionFormOpen.value = false;
  connectionFormError.value = '';
  isConnectionModalOpen.value = true;
}

function publicConfigString(connection: Connection, key: string) {
  const config = connection.publicConfig;
  if (typeof config !== 'object' || config === null || Array.isArray(config)) {
    return '';
  }
  const value = (config as Record<string, unknown>)[key];
  return typeof value === 'string' ? value : '';
}

function openEditConnection(connection: Connection) {
  if (connection.provider !== 'SENTRY') return;
  connectionForm.value = {
    connectionId: connection.id,
    name: connection.name,
    authToken: '',
    orgSlug: publicConfigString(connection, 'orgSlug'),
    projectId: publicConfigString(connection, 'projectId'),
    apiBaseUrl:
      publicConfigString(connection, 'apiBaseUrl') || DEFAULT_SENTRY_API_URL,
  };
  isAdvancedConnectionFormOpen.value = true;
  connectionFormError.value = '';
  isConnectionModalOpen.value = true;
}

const connectionForm = ref({
  connectionId: null as string | null,
  name: '',
  authToken: '',
  orgSlug: '',
  projectId: '',
  apiBaseUrl: DEFAULT_SENTRY_API_URL,
});

function setAdvancedConnectionFormOpen(event: Event) {
  isAdvancedConnectionFormOpen.value = (
    event.currentTarget as HTMLDetailsElement
  ).open;
}

async function saveConnection() {
  connectionFormError.value = '';
  const form = connectionForm.value;
  if (!form.orgSlug.trim() || !form.projectId.trim()) {
    connectionFormError.value =
      'Organization slug and project ID are required.';
    return;
  }
  if (!form.connectionId && !form.authToken.trim()) {
    connectionFormError.value =
      'A Sentry auth token is required for a new connection.';
    return;
  }

  const requestServiceId = serviceId.value;
  const isCurrentSave = () =>
    isPageActive && serviceId.value === requestServiceId;
  if (form.connectionId) {
    clearConnectionTestState(form.connectionId);
  }
  isSavingConnection.value = true;
  try {
    const input: RouterInput['observabilityIntegrations']['upsertConnection'] =
      {
        serviceId: requestServiceId,
        ...(form.connectionId ? { connectionId: form.connectionId } : {}),
        name:
          form.name.trim() ||
          defaultConnectionName(form.orgSlug.trim(), form.projectId.trim()),
        provider: 'SENTRY',
        publicConfig: {
          apiBaseUrl: form.apiBaseUrl.trim(),
          orgSlug: form.orgSlug.trim(),
          projectId: form.projectId.trim(),
        },
        ...(form.authToken.trim() ? { authToken: form.authToken.trim() } : {}),
      };
    const connection =
      await $trpc.observabilityIntegrations.upsertConnection.mutate(input);
    if (!isCurrentSave()) return;
    isConnectionModalOpen.value = false;
    const currentConnection = connections.value.find(
      (candidate) => candidate.id === connection.id,
    );
    if (
      (form.connectionId && !currentConnection) ||
      (currentConnection &&
        currentConnection.updatedAt.getTime() > connection.updatedAt.getTime())
    ) {
      return;
    }
    // Saving a connection must not reload capability drafts or other test states.
    connections.value = currentConnection
      ? connections.value.map((candidate) =>
          candidate.id === connection.id ? connection : candidate,
        )
      : [...connections.value, connection];
    await runConnectionTest(connection);
  } catch (error) {
    if (!isCurrentSave()) return;
    connectionFormError.value = errorMessage(
      error,
      'Could not save the Sentry connection.',
    );
  } finally {
    isSavingConnection.value = false;
  }
}

async function saveCapabilityConnections() {
  if (
    !canManage.value ||
    isSavingCapabilities.value ||
    isSavingConnection.value ||
    connectionsLoadError.value ||
    capabilityConnectionsLoadError.value
  ) {
    return;
  }
  capabilitySaveError.value = '';
  const capabilities: CapabilityConnectionInput[] = [];
  for (const capability of capabilityConnections.value) {
    const connectionId =
      capabilitySelections.value[capability.signal] ?? UNASSIGNED_CONNECTION;
    const connection = connections.value.find(
      (candidate) => candidate.id === connectionId,
    );
    if (
      connectionId !== UNASSIGNED_CONNECTION &&
      connectionId !== savedCapabilitySelections.value[capability.signal] &&
      (!connection || !connectionTestSucceeded(connection))
    ) {
      capabilitySaveError.value = `Test ${connection?.name ?? 'this connection'} before assigning it to ${CAPABILITY_DETAILS[capability.signal].label}.`;
      return;
    }
    capabilities.push({
      signal: capability.signal,
      connectionId:
        connectionId === UNASSIGNED_CONNECTION ? null : connectionId,
    });
  }

  isSavingCapabilities.value = true;
  try {
    const assignments =
      await $trpc.observabilityIntegrations.setCapabilityConnections.mutate({
        serviceId: serviceId.value,
        capabilities,
      });
    applyCapabilityConnections(assignments);
    toast.showSuccess('RCA capabilities saved');
  } catch (error) {
    capabilitySaveError.value = errorMessage(
      error,
      'Could not save RCA capability choices.',
    );
  } finally {
    isSavingCapabilities.value = false;
  }
}

function setConnectionTestState(
  connection: Connection,
  state: Omit<ConnectionTestState, 'connectionRevision'>,
) {
  connectionTestStates.value = {
    ...connectionTestStates.value,
    [connection.id]: {
      ...state,
      connectionRevision: connectionRevision(connection),
    },
  };
}

function clearConnectionTestState(connectionId: string) {
  const { [connectionId]: _discarded, ...remaining } =
    connectionTestStates.value;
  connectionTestStates.value = remaining;
}

async function runConnectionTest(connection: Connection) {
  const currentConnection = connections.value.find(
    (candidate) => candidate.id === connection.id,
  );
  // A pending toggle blocks tests of its snapshot, not a subsequently saved edit.
  if (
    !currentConnection ||
    connectionRevision(currentConnection) !== connectionRevision(connection) ||
    !connection.enabled ||
    isTestingConnection(connection) ||
    connectionEnabledUpdates.value[connection.id]?.snapshot ===
      currentConnection
  ) {
    return false;
  }
  const requestServiceId = serviceId.value;
  setConnectionTestState(connection, { status: 'checking' });
  const requestState = connectionTestStates.value[connection.id]!;
  const isCurrentTest = () =>
    serviceId.value === requestServiceId &&
    connections.value.some(
      (candidate) =>
        candidate.id === connection.id &&
        connectionTestState(candidate) === requestState,
    );
  try {
    const result = await $trpc.observabilityIntegrations.testConnection.mutate({
      serviceId: requestServiceId,
      connectionId: connection.id,
    });
    if (!isCurrentTest()) return false;
    const testedConnection = result.testedConnection;
    connections.value = connections.value.map((candidate) =>
      candidate.id === testedConnection.id ? testedConnection : candidate,
    );
    const checks = [
      { label: 'alerts', result: result.alerts },
      { label: 'environments', result: result.environments },
      { label: 'releases', result: result.releases },
      { label: 'tags', result: result.tags },
    ];
    const availableChecks = checks.filter(
      ({ result }) => result.availability === 'AVAILABLE',
    ).length;
    const failures = result.failures ?? [];
    const partial =
      availableChecks < 4 || failures.length > 0 || result.warnings.length > 0;
    const details = {
      testedAt: new Date(),
      availableChecks,
      unavailableChecks: checks
        .filter(({ result }) => result.availability === 'UNAVAILABLE')
        .map(({ label }) => label),
      failures,
      warnings: result.warnings,
    };
    if (result.connection.availability === 'AVAILABLE') {
      setConnectionTestState(testedConnection, {
        ...details,
        status: partial ? 'partial' : 'ready',
      });
      toast.showSuccess(
        partial ? 'Connection partially verified' : 'Connection verified',
        partial
          ? `${availableChecks} of 4 capability checks are available. You can now assign this connection to RCA capabilities.`
          : 'You can now assign this connection to RCA capabilities.',
      );
      return true;
    }
    setConnectionTestState(testedConnection, {
      ...details,
      status: 'failed',
      error: result.connection.reason,
    });
    toast.showError(
      'Connection could not be verified',
      result.connection.reason,
    );
    return false;
  } catch (error) {
    if (!isCurrentTest()) return false;
    const message = errorMessage(error, 'Could not test this connection.');
    const retryAt =
      error instanceof TRPCClientError &&
      typeof error.data?.retryAt === 'string'
        ? error.data.retryAt
        : undefined;
    let failedConnection = connection;
    const warnings: string[] = [];
    try {
      // Testing can persist resolved config before discovery rejects. Do not reload drafts or other connections.
      const refreshed =
        await $trpc.observabilityIntegrations.listConnections.query({
          serviceId: requestServiceId,
        });
      if (!isCurrentTest()) return false;
      const latest = refreshed.find(
        (candidate) => candidate.id === connection.id,
      );
      if (!latest) {
        connections.value = connections.value.filter(
          (candidate) => candidate.id !== connection.id,
        );
        clearConnectionTestState(connection.id);
        toast.showError('Connection could not be verified', message);
        return false;
      }
      failedConnection = latest;
      connections.value = connections.value.map((candidate) =>
        candidate.id === connection.id ? latest : candidate,
      );
    } catch (refreshError) {
      if (!isCurrentTest()) return false;
      warnings.push(
        `Connection configuration could not be refreshed: ${errorMessage(refreshError, 'Request failed.')} Refresh the page before editing this connection.`,
      );
    }
    setConnectionTestState(failedConnection, {
      status: 'failed',
      testedAt: new Date(),
      error: message,
      retryAt,
      warnings,
    });
    toast.showError(
      'Connection could not be verified',
      connectionTestFailure(failedConnection),
    );
    return false;
  }
}

async function updateConnectionEnabled(
  connection: Connection,
  enabled: boolean,
) {
  if (
    !isPageActive ||
    connection.serviceId !== serviceId.value ||
    !connections.value.includes(connection) ||
    isUpdatingConnectionEnabled(connection.id)
  ) {
    return false;
  }
  const requestServiceId = serviceId.value;
  const request = Symbol();
  if (isTestingConnection(connection)) clearConnectionTestState(connection.id);
  connectionEnabledUpdates.value[connection.id] = {
    token: request,
    snapshot: connection,
  };
  const currentConnection = () =>
    isPageActive &&
    serviceId.value === requestServiceId &&
    connectionEnabledUpdates.value[connection.id]?.token === request
      ? connections.value.find((candidate) => candidate.id === connection.id)
      : undefined;
  try {
    const updated =
      await $trpc.observabilityIntegrations.setConnectionEnabled.mutate({
        serviceId: requestServiceId,
        connectionId: connection.id,
        enabled,
      });
    const current = currentConnection();
    // Only an unchanged snapshot can safely accept a timestamp tie.
    if (
      !current ||
      current.updatedAt.getTime() > updated.updatedAt.getTime() ||
      (current !== connection &&
        current.updatedAt.getTime() === updated.updatedAt.getTime())
    ) {
      return false;
    }
    connections.value = connections.value.map((candidate) =>
      candidate.id === connection.id ? updated : candidate,
    );
    setConnectionTestState(updated, { status: 'not-tested' });
    toast.showSuccess(
      enabled ? 'Connection enabled' : 'Connection disabled',
      enabled
        ? `${updated.name} can be tested and assigned again.`
        : `${updated.name} remains assigned but RCA will not use it.`,
    );
    return true;
  } catch (error) {
    if (currentConnection() !== connection) return false;
    toast.showError(
      `Could not ${enabled ? 'enable' : 'disable'} connection`,
      errorMessage(error, 'Please try again.'),
    );
    return false;
  } finally {
    if (connectionEnabledUpdates.value[connection.id]?.token === request) {
      delete connectionEnabledUpdates.value[connection.id];
    }
  }
}

function openDeleteConnection(connection: Connection) {
  connectionToDelete.value = connection;
  isDeleteModalOpen.value = true;
}

async function deleteConnection() {
  if (!connectionToDelete.value || capabilityConnectionsLoadError.value) return;
  delete connectionEnabledUpdates.value[connectionToDelete.value.id];
  if (isTestingConnection(connectionToDelete.value)) {
    clearConnectionTestState(connectionToDelete.value.id);
  }
  isDeletingConnection.value = true;
  try {
    await $trpc.observabilityIntegrations.deleteConnection.mutate({
      serviceId: serviceId.value,
      connectionId: connectionToDelete.value.id,
    });
    isDeleteModalOpen.value = false;
    connectionToDelete.value = null;
    toast.showSuccess('Connection deleted and capabilities unassigned');
    await loadPage(true);
  } catch (error) {
    toast.showError(
      'Could not delete connection',
      errorMessage(error, 'Please try again.'),
    );
  } finally {
    isDeletingConnection.value = false;
  }
}

function getConnectionMenuItems(connection: Connection) {
  const actions = [];

  if (connection.provider === 'SENTRY') {
    actions.push({
      label: 'Edit connection',
      icon: 'i-heroicons-pencil-square',
      onSelect: () => openEditConnection(connection),
    });
  }

  actions.push({
    label: connection.enabled ? 'Disable' : 'Enable',
    icon: connection.enabled ? 'i-heroicons-pause' : 'i-heroicons-play',
    color: (connection.enabled ? 'warning' : 'success') as
      | 'warning'
      | 'success',
    disabled: isUpdatingConnectionEnabled(connection.id),
    loading: isUpdatingConnectionEnabled(connection.id),
    onSelect: () => {
      void updateConnectionEnabled(connection, !connection.enabled);
    },
  });

  const destructiveActions = [
    {
      label: 'Delete connection',
      icon: 'i-heroicons-trash',
      color: 'error' as const,
      onSelect: () => openDeleteConnection(connection),
    },
  ];

  return [actions, destructiveActions];
}

watch(
  serviceId,
  () => {
    connectionEnabledUpdates.value = {};
  },
  { flush: 'sync' },
);

onMounted(loadPage);
onBeforeUnmount(() => {
  isPageActive = false;
  connectionEnabledUpdates.value = {};
  connectionTestStates.value = {};
});
</script>
