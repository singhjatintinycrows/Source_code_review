<template>
  <div class="space-y-6">
      <div class="flex flex-col gap-4">
        <div class="flex justify-between items-center">
          <h1 class="text-2xl font-bold text-gray-900 dark:text-white">Teams</h1>
          <div class="flex items-center gap-2">
            <UButton color="neutral" variant="outline" icon="i-heroicons-arrow-path" @click="refreshTeams(true)"
              :loading="isLoadingTeams">Refresh</UButton>
            <UButton color="secondary" @click="openCreateModal" icon="i-heroicons-plus">Create Team</UButton>
          </div>
        </div>
        <div
          class="flex items-center gap-4 flex-wrap bg-white dark:bg-gray-900 p-4 rounded-lg border border-gray-200 dark:border-gray-800">
          <UFormField label="Team Name">
            <UInput v-model="filters.name" icon="i-heroicons-magnifying-glass" placeholder="Filter by Name" class="w-48"
              @update:model-value="onSearch" />
          </UFormField>
          <div
            class="flex items-center gap-2 mt-6 p-1 border border-gray-200 dark:border-gray-800 rounded-lg bg-gray-50 dark:bg-gray-800/50">
            <UButton size="xs" :color="filters.isAdminTeam === null ? 'secondary' : 'gray'"
              :variant="filters.isAdminTeam === null ? 'subtle' : 'ghost'"
              @click="() => { filters.isAdminTeam = null; onSearch() }">All Teams</UButton>
            <UButton size="xs" :color="filters.isAdminTeam === true ? 'secondary' : 'gray'"
              :variant="filters.isAdminTeam === true ? 'subtle' : 'ghost'"
              @click="() => { filters.isAdminTeam = true; onSearch() }">Admin Only</UButton>
            <UButton size="xs" :color="filters.isAdminTeam === false ? 'secondary' : 'gray'"
              :variant="filters.isAdminTeam === false ? 'subtle' : 'ghost'"
              @click="() => { filters.isAdminTeam = false; onSearch() }">Standard Only</UButton>
          </div>
        </div>
      </div>

      <UCard>
        <div class="overflow-x-auto">
          <table class="w-full text-left text-sm text-gray-500 dark:text-gray-400">
            <thead class="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-800 dark:text-gray-400">
              <tr>
                <th scope="col" class="px-6 py-3">Team Name</th>
                <th scope="col" class="px-6 py-3">Global Admin</th>
                <th scope="col" class="px-6 py-3 text-right">Actions</th>
              </tr>
            </thead>
            <tbody>
              <tr v-for="team in teams" :key="team.id"
                class="bg-white border-b dark:bg-gray-900 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-800">
                <td class="px-6 py-4 font-medium text-gray-900 dark:text-white flex items-center gap-1 group">
                  {{ team.name }}
                  <CopyToClipboard :text="team.name" title="Team Name" />
                </td>
                <td class="px-6 py-4">
                  <UBadge :color="team.isAdminTeam ? 'success' : 'neutral'" variant="subtle">
                    {{ team.isAdminTeam ? 'Yes' : 'No' }}
                  </UBadge>
                </td>
                <td class="px-6 py-4 text-right space-x-2">
                  <UButton size="sm" color="neutral" variant="ghost" icon="i-heroicons-pencil"
                    @click="openEditModal(team)" :disabled="team.isAdminTeam" />
                  <UButton size="sm" color="error" variant="ghost" icon="i-heroicons-trash"
                    @click="openDeleteModal(team)" :disabled="team.isAdminTeam" />
                </td>
              </tr>
              <tr v-if="teams.length === 0">
                <td colspan="3" class="px-6 py-4 text-center">No teams found.</td>
              </tr>
            </tbody>
          </table>
        </div>
        <div class="flex justify-end py-4 border-t border-gray-200 dark:border-gray-800" v-if="teamsCount > 0">
          <p class="text-sm text-gray-500 dark:text-gray-400 mt-1.5">Total: {{ teamsCount }}</p>
          &nbsp;&nbsp;&nbsp;
          <UPagination v-model:page="currentPage" :items-per-page="limit" :total="teamsCount"
            @update:page="updateTeamsList" />
        </div>
      </UCard>

      <!-- Create/Edit Modal -->
      <UModal v-model:open="isModalOpen">
        <template #content>
          <UCard :ui="{ divide: 'divide-y divide-gray-100 dark:divide-gray-800' }">
            <template #header>
              <div class="flex items-center justify-between">
                <h3 class="text-base font-semibold leading-6 text-gray-900 dark:text-white">
                  {{ isEditing ? 'Edit Team' : 'Create Team' }}
                </h3>
                <UButton color="neutral" variant="ghost" icon="i-heroicons-x-mark-20-solid" class="-my-1"
                  @click="isModalOpen = false" />
              </div>
            </template>

            <form @submit.prevent="saveTeam" class="space-y-4">
              <UFormField label="Team Name" required>
                <UInput v-model="formState.name" placeholder="Enter team name..." />
              </UFormField>

              <UFormField v-if="!isEditing" label="Admin Team">
                <UCheckbox v-model="formState.isAdminTeam" label="Is this a Global Admin team?" />
              </UFormField>

              <div class="flex justify-end pt-4 space-x-3">
                <UButton color="neutral" variant="soft" @click="isModalOpen = false">Cancel</UButton>
                <UButton type="submit" color="secondary" :loading="isSaving">Save</UButton>
              </div>
            </form>
          </UCard>
        </template>
      </UModal>

      <!-- Delete Confirmation Modal -->
      <CommonDeleteModal v-model:open="isDeleteModalOpen" title="Delete Team" :loading="isDeleting"
        @confirm="confirmDelete">
        Are you sure you want to delete the team <strong class="text-gray-900 dark:text-white">{{ teamToDelete?.name
        }}</strong>? This action cannot be undone.
      </CommonDeleteModal>
      <Loader :loading="isLoadingTeams" label="Loading teams..." />
    </div>
</template>

<script setup lang="ts">
import type { inferRouterOutputs } from '@trpc/server';
import { computed, onMounted, ref, watch } from 'vue';
import { useNuxtApp, useRoute, useRouter } from '#app';
import type { AppRouter } from '../../../../backend/src/index';
import CopyToClipboard from '../../components/CopyToClipboard.vue';
import Loader from '../../components/Loader.vue';
import { useAppToast } from '../../composables/useAppToast';
import { useTeamsStore } from '../../stores/teams';

type RouterOutput = inferRouterOutputs<AppRouter>;
const toast = useAppToast();
const { $trpc } = useNuxtApp();
const teams = ref<RouterOutput['teams']['list']>([]);
const route = useRoute();
const router = useRouter();

const teamsStore = useTeamsStore();
const teamsCount = ref(0);
const isLoadingTeams = computed(() => teamsStore.isLoadingTeams);

const parseBooleanFilter = (val: any) => {
  if (val === 'true') return true;
  if (val === 'false') return false;
  return null;
};

const filters = ref({
  name: (route.query.name as string) || '',
  isAdminTeam: parseBooleanFilter(route.query.isAdminTeam),
});

const currentPage = ref(Number(route.query.page) || 1);
const limit = ref(10);

watch(
  [filters, currentPage],
  () => {
    const query = { ...route.query };

    if (filters.value.name) query.name = filters.value.name;
    else delete query.name;

    if (filters.value.isAdminTeam !== null)
      query.isAdminTeam = String(filters.value.isAdminTeam);
    else delete query.isAdminTeam;

    if (currentPage.value > 1) query.page = String(currentPage.value);
    else delete query.page;

    router.replace({ query });
  },
  { deep: true },
);

function onSearch() {
  currentPage.value = 1;
  updateTeamsList();
}

const isDeleteModalOpen = ref(false);
const isDeleting = ref(false);
const isModalOpen = ref(false);
const isEditing = ref(false);
const isSaving = ref(false);
const teamToDelete = ref<RouterOutput['teams']['list'][0] | null>(null);
const formState = ref({
  id: '',
  name: '',
  isAdminTeam: false,
});

const openDeleteModal = (team: RouterOutput['teams']['list'][0]) => {
  teamToDelete.value = team;
  isDeleteModalOpen.value = true;
};

function updateTeamsList() {
  const { name, isAdminTeam } = filters.value;

  const filteredTeams = teamsStore.teams.filter((team: any) => {
    return (
      (!name || team.name.toLowerCase().includes(name.toLowerCase())) &&
      (isAdminTeam === null || team.isAdminTeam === isAdminTeam)
    );
  });

  teamsCount.value = filteredTeams.length;

  teams.value = filteredTeams.slice(
    (currentPage.value - 1) * limit.value,
    currentPage.value * limit.value,
  );
}

async function refreshTeams(showToast = false) {
  await teamsStore.fetchTeams();
  updateTeamsList();
  if (showToast) {
    toast.showSuccess('Success', 'Teams data refreshed successfully');
  }
}

onMounted(() => {
  refreshTeams();
});

const openCreateModal = () => {
  isEditing.value = false;
  formState.value = { id: '', name: '', isAdminTeam: false };
  isModalOpen.value = true;
};

const openEditModal = (team: RouterOutput['teams']['list'][0]) => {
  if (team.isAdminTeam) return;
  isEditing.value = true;
  formState.value = {
    id: team.id,
    name: team.name,
    isAdminTeam: team.isAdminTeam,
  };
  isModalOpen.value = true;
};

const confirmDelete = async () => {
  if (!teamToDelete.value) return;

  isDeleting.value = true;
  try {
    await $trpc.teams.delete.mutate({ id: teamToDelete.value.id });
    toast.showSuccess('Success', 'Team deleted successfully');
    isDeleteModalOpen.value = false;
    teamToDelete.value = null;
    await refreshTeams();
  } catch (error: any) {
    toast.showError(
      'Deletion Failed',
      error.message || 'An error occurred while deleting the team.',
    );
  } finally {
    isDeleting.value = false;
  }
};

const saveTeam = async () => {
  if (!formState.value.name.trim()) return;

  isSaving.value = true;
  try {
    if (isEditing.value) {
      await $trpc.teams.update.mutate({
        id: formState.value.id,
        name: formState.value.name,
      });
    } else {
      await $trpc.teams.create.mutate({
        name: formState.value.name,
        isAdminTeam: formState.value.isAdminTeam,
      });
    }
    isModalOpen.value = false;
    await refreshTeams();
  } catch (error: any) {
    toast.showError(
      'Failed to save team',
      error.message || 'An error occurred while saving the team.',
    );
  } finally {
    isSaving.value = false;
  }
};
</script>
