<template>
  <div class="space-y-6">
      <h1 class="text-2xl font-bold text-gray-900 dark:text-white mb-4">Probes</h1>
      <div class="flex items-center gap-3 mb-4">
        <span class="text-sm font-medium text-gray-700 dark:text-gray-300">Services:</span>
        <CustomDropdown :items="services" :selected-items="selectedServiceIds" value-key="id" label-key="name"
          :on-selected="onServiceSelected" placeholder="Select Services..." class="min-w-[27rem] max-w-md" />
      </div>

      <div class="relative h-[calc(100vh-160px)] w-full">
        <div v-if="selectedServiceIds.length === 0"
          class="flex items-center justify-center h-full border border-gray-200 dark:border-gray-800 rounded-lg bg-gray-50 dark:bg-gray-900/50 text-gray-500">
          <div class="flex flex-col items-center">
            <UIcon name="i-heroicons-server" class="text-5xl mb-4 opacity-50" />
            <p class="text-lg">Select at least one service to see the probes.</p>
          </div>
        </div>

        <div v-else class="grid grid-cols-12 h-full">

          <!-- Probes List -->
          <div
            class="col-span-4 flex flex-col bg-white border border-gray-200 dark:border-gray-800 rounded-lg dark:bg-gray-950 overflow-y-auto">
            <div class="px-4 pt-4 pb-2 border-b border-gray-200 dark:border-gray-800 flex-shrink-0 flex flex-col gap-3">
              <div class="flex items-center justify-between">
                <div class="font-bold text-lg mb-1">Probes ({{ probes.length }})</div>
                <div class="flex items-center justify-between">
                  <USelectMenu v-model="statusFilter" size="xs" tabindex="0"
                    :items="['ALL', 'ACTIVE', 'INACTIVE', 'COMPLETED', 'EXPIRED', 'ERROR']" placeholder="Status"
                    class="w-28 text-gray-500 mr-2"
                    @update:model-value="() => { currentPage = 1; getProbesAndCount(); }" />
                  <USelect v-model="sortBy" tabindex="0"
                    :items="[{ label: 'Newest', value: 'createdAt' }, { label: 'File Name', value: 'uiFilePath' }]"
                    option-attribute="label" size="xs" variant="none" class="w-20 text-gray-500"
                    @update:model-value="() => { currentPage = 1; getProbes(); }" />
                </div>
              </div>
              <SourceSearchFilter v-model="sourceSearch" v-model:activeTags="activeTags" :candidates="probes"
                :tag-key-to-label="PROBE_TAG_KEY_TO_LABEL"
                placeholder="Filter probes... (e.g. 'staging' or 'environment: staging')" />
            </div>
            <div class="flex-1 overflow-y-auto p-4 space-y-2">
              <div v-if="probes.length === 0"
                class="flex flex-col items-center justify-center h-full text-gray-500 text-center py-8">
                <UIcon name="i-heroicons-magnifying-glass" class="text-4xl mb-2 opacity-50" />
                <p class="text-sm">No probes found.</p>
              </div>
              <template v-else>
                <UCard v-for="probe in probes" :key="probe.id" role="button" :tabindex="0"
                  :ui="{ body: { padding: 'px-4 py-3 sm:px-4 sm:py-3' } }" :class="['transition', 'cursor-pointer hover:bg-gray-50 dark:hover:bg-gray-900',
                    selectedProbe?.id === probe.id ? 'ring-2 ring-primary-500' : '']" @click="selectProbe(probe)"
                  @keydown.enter.prevent="selectProbe(probe)" @keydown.space.prevent="selectProbe(probe)">
                  <div class="flex items-start justify-between gap-4">
                    <div class="flex gap-3 flex-1 min-w-0">
                      <UIcon :name="getIconForType(probe.type)" class="text-lg mt-1 text-gray-500 flex-shrink-0" />
                      <div class="min-w-0 flex-1">
                        <div class="flex items-center gap-2 font-medium truncate justify-between">
                          <span class="truncate text-left" dir="rtl"
                            :title="`${probe.uiFilePath}:${probe.uiLineNumber}`">
                            <bdi dir="ltr">{{ probe.uiFilePath }}:{{ probe.uiLineNumber }}</bdi>
                          </span>

                          <div class="text-xs font-medium inline-flex pt-1"
                            :style="{ color: getStatusColor(probe.status) }">
                            {{ probe.status }}
                            <div v-if="probe.status === 'ACTIVE'" class="pl-2">
                              <UIcon v-if="probe.isLive" name="i-heroicons-check-circle-solid"
                                class="text-green-500 flex-shrink-0 text-sm" />
                              <UIcon v-else name="i-heroicons-clock" class="text-yellow-500 flex-shrink-0 text-sm" />
                            </div>
                          </div>
                        </div>
                        <div class="text-[11px] text-gray-500 mt-1 flex items-center justify-between overflow-hidden">
                          <div class="flex items-center gap-0.5 mt-1 overflow-hidden min-w-0 group pr-2">
                            <span class="text-gray-400 dark:text-gray-600 flex-shrink-0">#</span>
                            <span
                              class="font-mono bg-gray-100 dark:bg-gray-800 pl-1.5 py-0.5 rounded text-gray-600 dark:text-gray-300 truncate min-w-0"
                              :title="`ID: ${probe.id}`">
                              {{ probe.id }}
                            </span>
                            <CopyToClipboard :text="probe.id" title="Probe ID" />
                          </div>
                          <span
                            class="text-gray-400 dark:text-gray-500 font-mono text-[10px] whitespace-nowrap flex-shrink-0"
                            :title="probe.createdAt ? `Created at: ${new Date(probe.createdAt).toLocaleString()}` : ''">
                            {{ probe.createdAt ? new Date(probe.createdAt).toLocaleString() : '' }}
                          </span>
                        </div>
                        <div class="text-[11px] text-gray-500 mt-1 truncate flex justify-between">
                          <span class="font-semibold text-xs">Source</span>&nbsp;
                          <span>
                            Service: <span class="font-medium" :title="`Service ID: ${probe.serviceId}`">
                              {{services.find(s => s.id === probe.serviceId)?.name || probe.serviceId}}</span>
                            &nbsp; | &nbsp;
                            Env: <span class="font-medium" :title="`Environment: ${probe.environment}`">
                              {{ probe.environment }}</span>
                            &nbsp; | &nbsp;
                            Commit: <span class="font-medium" :title="`Commit: ${probe.commitSha}`">
                              {{ probe.commitSha.substring(0, 7) }}
                            </span>

                          </span>
                        </div>
                      </div>
                    </div>
                  </div>
                </UCard>
              </template>
            </div>
            <div
              class="p-3 border-t border-gray-200 dark:border-gray-800 flex items-center justify-center bg-white dark:bg-gray-950 flex-shrink-0">
              <UPagination v-model:page="currentPage" :items-per-page="limit" :total="totalProbes"
                @update:page="getProbes" size="sm" active-color="secondary" active-variant="subtle" :sibling-count="1"
                show-edges />
            </div>
          </div>

          <!-- Inspector -->
          <div
            class="col-span-8 flex flex-col ml-6 overflow-auto h-full border border-gray-200 dark:border-gray-800 rounded-lg bg-white dark:bg-gray-950">
            <div
              class="p-4 font-bold text-lg border-b border-gray-200 dark:border-gray-800 text-center bg-white dark:bg-gray-950 flex-shrink-0 flex items-center justify-between">
              <div class="flex items-center gap-3">
                <span>Inspector</span>
                <span v-if="selectedProbe"
                  class="text-xs font-normal text-gray-500 bg-gray-100 dark:bg-gray-800 px-2 py-1 rounded">
                  {{ selectedProbe.uiFilePath }}:{{ selectedProbe.uiLineNumber }}
                </span>
              </div>
            </div>

            <!-- Hits Pagination Bar -->
            <div v-if="selectedHit && !isLoadingHits"
              class="flex items-center justify-between px-4 py-2 bg-white dark:bg-gray-950 border-b border-gray-200 dark:border-gray-800">
              <div class="flex items-center gap-2">
                <UButton icon="i-heroicons-arrow-left" color="neutral" variant="ghost"
                  :disabled="currentHitIndex === totalHits - 1" @click="goPrevHit" />
                <span class="text-xs font-bold text-gray-500">HIT</span>
                <input type="text"
                  class="w-12 text-center text-sm border border-gray-300 dark:border-gray-700 rounded bg-gray-50 dark:bg-gray-900 text-gray-900 dark:text-gray-100 py-1"
                  :value="totalHits - currentHitIndex" @keydown.enter="jumpToHit" @blur="jumpToHit" />
                <span class="text-sm text-gray-500">/ {{ totalHits }}</span>
                <UButton icon="i-heroicons-arrow-right" color="neutral" variant="ghost"
                  :disabled="currentHitIndex === 0" @click="goNextHit" />
              </div>

              <div class="flex items-center gap-4 text-xs text-gray-500">
                <div class="flex items-center gap-1 group">
                  <span class="truncate max-w-[200px]" :title="selectedHit.id">ID: {{ selectedHit.id }}</span>
                  <CopyToClipboard :text="selectedHit.id" title="Hit ID" />
                </div>
                <span class="flex items-center gap-1">
                  <UIcon v-if="selectedProbe.type === 'LOG'" name="i-heroicons-document-text"
                    class="text-orange-500 size-4" />
                  <UIcon v-else name="i-heroicons-camera" class="text-blue-500 size-4" />
                </span>
              </div>
            </div>

            <div class="flex-1 overflow-y-auto p-4">
              <div v-if="isLoadingHits" class="flex flex-col items-center justify-center h-full">
                <UIcon name="i-heroicons-arrow-path" class="animate-spin text-4xl text-gray-400 mb-2" />
                <p class="text-sm text-gray-500">Loading snapshots...</p>
              </div>
              <div v-else-if="!selectedProbe" class="flex flex-col items-center justify-center h-full text-gray-500">
                <UIcon name="i-heroicons-magnifying-glass" class="text-4xl mb-2 opacity-50" />
                <p class="text-sm">Select a probe to view its hits</p>
              </div>
              <div v-else-if="!selectedHit" class="flex flex-col items-center justify-center h-full text-gray-500">
                <UIcon name="i-heroicons-camera" class="text-4xl mb-2 opacity-50" />
                <p class="text-sm">No hits recorded yet for this probe</p>
              </div>
              <div v-else class="space-y-4">

                <!-- Basic Metadata -->
                <div
                  class="bg-white dark:bg-gray-950 p-4 rounded-lg border border-gray-200 dark:border-gray-800 text-sm shadow-sm">
                  <div class="grid grid-cols-2 lg:grid-cols-4 gap-4">
                    <div>
                      <span class="text-gray-500 block text-xs mb-1 uppercase tracking-wider">Source (Service ID)</span>
                      <div class="flex items-center gap-1 group">
                        <span class="font-mono text-gray-900 dark:text-gray-100 truncate block" :title="agentName">{{
                          agentName
                        }}</span>
                        <CopyToClipboard :text="agentName" title="Service ID" />
                      </div>
                    </div>
                    <div v-if="selectedProbe.commitSha">
                      <span class="text-gray-500 block text-xs mb-1 uppercase tracking-wider">Commit</span>
                      <div class="flex items-center gap-1 group">
                        <span class="font-mono text-gray-900 dark:text-gray-100 truncate block"
                          :title="selectedProbe.commitSha">{{
                            selectedProbe.commitSha.substring(0, 7)
                          }}</span>
                        <CopyToClipboard :text="selectedProbe.commitSha" title="Commit SHA" />
                      </div>
                    </div>
                    <div v-if="selectedProbe.environment">
                      <span class="text-gray-500 block text-xs mb-1 uppercase tracking-wider">Environment</span>
                      <span class="text-gray-900 dark:text-gray-100 truncate block"
                        :title="selectedProbe.environment">{{
                          selectedProbe.environment
                        }}</span>
                    </div>
                    <!-- <div v-if="selectedProbe.type === 'SNAPSHOT'">
                      <span class="text-gray-500 block text-xs mb-1 uppercase tracking-wider">Capture Closures</span>
                      <span class="text-gray-900 dark:text-gray-100 truncate block">{{ selectedProbe.captureClosures ? 'Enabled' : 'Disabled' }}</span>
                    </div> -->
                    <div>
                      <span class="text-gray-500 block text-xs mb-1 uppercase tracking-wider">Time</span>
                      <span class="text-gray-900 dark:text-gray-100">{{ new
                        Date(selectedHit.capturedAt).toLocaleString()
                        }}</span>
                    </div>
                  </div>
                </div>

                <!-- Log specific view -->
                <div v-if="selectedProbe.type === 'LOG'"
                  class="bg-gray-900 text-green-400 font-mono text-sm p-4 rounded-lg shadow-sm overflow-x-auto">
                  <div :class="{ 'text-red-400 font-bold': selectedHit.message?.startsWith('[Error') }">
                    {{ selectedHit.message || 'No log message available' }}
                  </div>
                </div>

                <!-- Snapshot specific view -->
                <template v-if="selectedProbe.type === 'SNAPSHOT'">

                  <!-- Watch Expressions -->
                  <div v-if="selectedHit.payload?.watch && Object.keys(selectedHit.payload.watch).length > 0"
                    class="bg-white dark:bg-gray-950 rounded-lg border border-gray-200 dark:border-gray-800 shadow-sm overflow-hidden">
                    <div
                      class="bg-gray-50 dark:bg-gray-900 px-4 py-2 border-b border-gray-200 dark:border-gray-800 font-semibold text-xs tracking-wider uppercase text-gray-700 dark:text-gray-300">
                      Watch Expressions
                    </div>
                    <div class="p-4 font-mono text-sm max-h-60 overflow-y-auto">
                      <VariableTree v-for="(val, key) in selectedHit.payload.watch" :key="key" :name="key"
                        :value="val" />
                    </div>
                  </div>

                  <!-- Variables -->
                  <div v-if="currentFrameVariables && currentFrameVariables.length > 0"
                    class="bg-white dark:bg-gray-950 rounded-lg border border-gray-200 dark:border-gray-800 shadow-sm overflow-hidden">
                    <div
                      class="bg-gray-50 dark:bg-gray-900 px-4 py-2 border-b border-gray-200 dark:border-gray-800 font-semibold text-xs tracking-wider uppercase text-gray-700 dark:text-gray-300">
                      Variables
                    </div>
                    <div class="p-4 font-mono text-sm max-h-80 overflow-y-auto space-y-4">
                      <div v-for="scope in currentFrameVariables" :key="scope.name || scope.type">
                        <div class="font-bold text-gray-500 mb-2 uppercase text-xs tracking-wider">
                          {{ scope.name || scope.type }}
                        </div>
                        <div class="pl-2 border-l-2 border-gray-100 dark:border-gray-800">
                          <VariableTree v-for="(val, key) in scope.vars" :key="key" :name="key" :value="val" />
                        </div>
                      </div>
                    </div>
                  </div>

                  <!-- Call Stack -->
                  <div v-if="selectedHit.payload?.stack && selectedHit.payload.stack.length > 0"
                    class="bg-white dark:bg-gray-950 rounded-lg border border-gray-200 dark:border-gray-800 shadow-sm overflow-hidden">
                    <div
                      class="bg-gray-50 dark:bg-gray-900 px-4 py-2 border-b border-gray-200 dark:border-gray-800 font-semibold text-xs tracking-wider uppercase text-gray-700 dark:text-gray-300">
                      Call Stack
                    </div>
                    <div class="divide-y divide-gray-100 dark:divide-gray-800 max-h-60 overflow-y-auto">
                      <div v-for="(frame, idx) in selectedHit.payload.stack" :key="idx" role="button" tabindex="0"
                        @click="activeFrameIndex = Number(idx)" @keydown.enter.prevent="activeFrameIndex = Number(idx)"
                        @keydown.space.prevent="activeFrameIndex = Number(idx)"
                        :class="['px-4 py-2 text-sm cursor-pointer flex justify-between items-center transition',
                          activeFrameIndex === idx ? 'bg-primary-50 dark:bg-primary-900/20 text-primary-700 dark:text-primary-300' : 'hover:bg-gray-50 dark:hover:bg-gray-900']">
                        <span class="font-mono truncate mr-4">{{ frame.functionName || '(anonymous)' }}</span>
                        <span class="text-xs text-gray-500 flex-shrink-0 flex items-center">
                          <span class="truncate max-w-[150px] block">{{ frame.file?.split('/').pop() ||
                            frame.fileName?.split('/').pop() || 'unknown' }}</span>
                          <span class="bg-gray-200 dark:bg-gray-700 px-1.5 py-0.5 rounded ml-2 font-mono">{{ frame.line
                            ||
                            frame.lineNumber || '?' }}</span>
                        </span>
                      </div>
                    </div>
                  </div>

                </template>
              </div>
            </div>
          </div>

        </div>

        <Loader :loading="isLoadingProbes" label="Loading probes..." />
      </div>
    </div>
</template>

<script setup lang="ts">
import { useClipboard, useDebounceFn } from '@vueuse/core';
import { computed, onMounted, provide, ref, watch } from 'vue';
import { useNuxtApp, useRoute, useRouter } from '#app';
import CopyToClipboard from '../../components/CopyToClipboard.vue';
import CustomDropdown from '../../components/CustomDropdown.vue';
import Loader from '../../components/Loader.vue';
import SourceSearchFilter from '../../components/SourceSearchFilter.vue';
import VariableTree from '../../components/VariableTree.vue';
import { useAppToast } from '../../composables/useAppToast';
import { PROBE_TAG_KEY_TO_LABEL } from '../../constants/appConstants';
import { useServicesStore } from '../../stores/services';

const { $trpc } = useNuxtApp();
const toast = useAppToast();
const route = useRoute();
const router = useRouter();
const { copy } = useClipboard();

const servicesStore = useServicesStore();

const copyToClipboard = async (text: string, label: string) => {
  await copy(text);
  toast.showSuccess('Copied', `${label} copied to clipboard`);
};

const routeServices = route.query.selectedServiceIds
  ? Array.isArray(route.query.selectedServiceIds)
    ? route.query.selectedServiceIds
    : [route.query.selectedServiceIds]
  : [];
const routeSourceSearchTags = route.query.sourceSearchTags
  ? Array.isArray(route.query.sourceSearchTags)
    ? route.query.sourceSearchTags
    : [route.query.sourceSearchTags]
  : [];

// Services
const services = computed(() => servicesStore.services || []);
const selectedServiceIds = ref<string[]>(routeServices as string[]);

type SortBy = 'createdAt' | 'uiFilePath';

// Probes list
const probes = ref<any[]>([]);
const sourceSearch = ref('');
const isLoadingProbes = ref(false);

interface FilterTag {
  type: string;
  label: string;
  value: string;
}

const sourceSearchTags = ref<string[]>(routeSourceSearchTags as string[]);

const activeTags = ref<FilterTag[]>(
  sourceSearchTags.value
    .map((t) => {
      const [type, ...valParts] = t.split(':');
      const lower = type?.trim().toLowerCase();
      const canonicalType = Object.keys(PROBE_TAG_KEY_TO_LABEL).find(
        (k) => k.toLowerCase() === lower,
      );
      if (!canonicalType) return null;
      return {
        type: canonicalType,
        label: PROBE_TAG_KEY_TO_LABEL[canonicalType] || canonicalType,
        value: valParts.join(':').trim(),
      };
    })
    .filter((t): t is FilterTag => t !== null),
);

watch(
  activeTags,
  (newTags) => {
    sourceSearchTags.value = newTags.map((t) => `${t.type}:${t.value}`);
    currentPage.value = 1;
    getProbesAndCount();
  },
  { deep: true },
);
const statusFilter = ref((route.query.statusFilter as string) || 'ALL');
const routeSortBy = Array.isArray(route.query.sortBy)
  ? route.query.sortBy[0]
  : route.query.sortBy;
const sortBy = ref<SortBy>(
  ['uiFilePath', 'createdAt'].includes(routeSortBy) ? routeSortBy : 'createdAt',
);

const routePage = Array.isArray(route.query.page)
  ? route.query.page[0]
  : route.query.page;
const currentPage = ref(Number(routePage ?? '1'));
const limit = ref(10);
const totalProbes = ref(0);

// Selection State
const selectedProbe = ref<any>(null);
const probeHits = ref<any[]>([]);
const isLoadingHits = ref(false);
const activeFrameIndex = ref(0);
const currentHitIndex = ref(0);

watch(
  [
    selectedServiceIds,
    selectedProbe,
    statusFilter,
    sourceSearchTags,
    sortBy,
    currentPage,
  ],
  () => {
    const query = { ...route.query };

    if (selectedServiceIds.value.length > 0) {
      query.selectedServiceIds = selectedServiceIds.value;
    } else {
      delete query.selectedServiceIds;
    }

    if (selectedProbe.value) {
      query.selectedProbeId = selectedProbe.value.id;
    } else {
      delete query.selectedProbeId;
    }

    if (statusFilter.value && statusFilter.value !== 'ALL') {
      query.statusFilter = statusFilter.value;
    } else {
      delete query.statusFilter;
    }

    if (sourceSearchTags.value.length > 0) {
      query.sourceSearchTags = sourceSearchTags.value;
    } else {
      delete query.sourceSearchTags;
    }

    if (sortBy.value !== 'createdAt') {
      query.sortBy = sortBy.value;
    } else {
      delete query.sortBy;
    }

    if (currentPage.value > 1) {
      query.page = String(currentPage.value);
    } else {
      delete query.page;
    }

    router.replace({ query });
  },
  { deep: true },
);

const totalHits = computed(() => probeHits.value.length);

const selectedHit = computed(() => {
  if (probeHits.value.length === 0) return null;
  const index = Math.min(currentHitIndex.value, probeHits.value.length - 1);
  return probeHits.value[index];
});

const resolutionCache = new WeakMap<any, Map<string, any>>();
provide('resolutionCache', resolutionCache);

provide(
  'hitPayload',
  computed(() => selectedHit.value?.payload || null),
);

const getStatusColor = (status: string) => {
  switch (status) {
    case 'ACTIVE':
      return 'green';
    case 'INACTIVE':
      return 'gray';
    case 'ERROR':
      return 'red';
    case 'COMPLETED':
      return 'blue';
    case 'EXPIRED':
      return 'orange';
    default:
      return 'yellow';
  }
};

function getIconForType(type: string) {
  switch (type) {
    case 'SNAPSHOT':
      return 'i-heroicons-camera';
    case 'LOG':
      return 'i-heroicons-document-text';
    case 'COUNTER':
      return 'i-heroicons-hashtag';
    case 'DURATION':
      return 'i-heroicons-clock';
    case 'METRIC':
      return 'i-heroicons-chart-bar';
    default:
      return 'i-heroicons-bolt';
  }
}

const currentFrameVariables = computed(() => {
  if (!selectedHit.value || !Array.isArray(selectedHit.value.payload?.vars))
    return [];
  const frameVars =
    selectedHit.value.payload.vars[activeFrameIndex.value] || [];
  return frameVars;
});

const agentName = computed(() => {
  const serviceId =
    selectedProbe.value?.serviceId || selectedHit.value?.serviceId;
  return serviceId || 'Unknown';
});

async function fetchProbesCount() {
  try {
    totalProbes.value = await $trpc.getProbesCount.query({
      serviceIds: selectedServiceIds.value,
      sourceSearchTags: sourceSearchTags.value,
      status: statusFilter.value === 'ALL' ? undefined : statusFilter.value,
    });
  } catch (error) {
    console.error('Failed to load data:', error);
    toast.showError('Error', 'Failed to load probes count.');
  }
}

const fetchProbesList = async () => {
  try {
    probes.value = await $trpc.listProbes.query({
      serviceIds: selectedServiceIds.value,
      sourceSearchTags: sourceSearchTags.value,
      status: statusFilter.value === 'ALL' ? undefined : statusFilter.value,
      sortBy: sortBy.value,
      offset: (currentPage.value - 1) * limit.value,
      limit: limit.value,
    });

    // Auto-select first probe if available and no probe is selected
    if (
      !selectedProbe.value ||
      !probes.value.find((p) => p.id === selectedProbe.value.id)
    ) {
      const firstSelectable = probes.value[0];
      if (firstSelectable) {
        await selectProbe(firstSelectable);
      } else {
        selectedProbe.value = null;
        probeHits.value = [];
        currentHitIndex.value = 0;
      }
    }
  } catch (error) {
    console.error('Failed to load data:', error);
    toast.showError('Error', 'Failed to load probes data.');
  }
};

async function getProbes() {
  isLoadingProbes.value = true;
  try {
    await fetchProbesList();
  } finally {
    isLoadingProbes.value = false;
  }
}

async function getProbesAndCount() {
  if (selectedServiceIds.value.length === 0) {
    probes.value = [];
    selectedProbe.value = null;
    probeHits.value = [];
    currentHitIndex.value = 0;
    totalProbes.value = 0;
    return;
  }

  isLoadingProbes.value = true;
  try {
    await fetchProbesList();
    await fetchProbesCount();
  } finally {
    isLoadingProbes.value = false;
  }
}

const onServiceSelected = useDebounceFn((val: string[]) => {
  selectedServiceIds.value = val;
  currentPage.value = 1;
  getProbesAndCount();
}, 1000);

const selectProbe = async (probe: any) => {
  selectedProbe.value = probe;
  probeHits.value = [];
  isLoadingHits.value = true;
  activeFrameIndex.value = 0;
  currentHitIndex.value = 0;

  try {
    let hits = [];
    if (probe.type === 'LOG') {
      hits = await $trpc.listLogs.query({ probeId: probe.id });
    } else if (probe.type === 'SNAPSHOT') {
      hits = await $trpc.listSnapshots.query({ probeId: probe.id });
    }
    probeHits.value = hits || [];
  } catch (error) {
    console.error('Failed to load hits:', error);
    const errorMessage =
      probe.type === 'LOG'
        ? 'Failed to load log data.'
        : probe.type === 'SNAPSHOT'
          ? 'Failed to load snapshot data.'
          : 'Failed to load probe data.';
    toast.showError('Error', errorMessage);
  } finally {
    isLoadingHits.value = false;
  }
};

function goNextHit() {
  if (currentHitIndex.value > 0) {
    currentHitIndex.value--;
    activeFrameIndex.value = 0;
  }
}

function goPrevHit() {
  if (currentHitIndex.value < totalHits.value - 1) {
    currentHitIndex.value++;
    activeFrameIndex.value = 0;
  }
}

function jumpToHit(event: Event) {
  const target = event.target as HTMLInputElement;
  const val = parseInt(target.value, 10);
  if (!Number.isNaN(val) && val >= 1 && val <= totalHits.value) {
    currentHitIndex.value = totalHits.value - val;
    activeFrameIndex.value = 0;
  } else {
    target.value = String(totalHits.value - currentHitIndex.value);
  }
}

onMounted(async () => {
  if (servicesStore.services.length === 0) {
    await servicesStore.fetchServices();
  }
  if (selectedServiceIds.value.length > 0) {
    await getProbesAndCount();
  }
  const selectedProbeId =
    typeof route.query.selectedProbeId === 'string'
      ? route.query.selectedProbeId
      : undefined;
  if (selectedProbeId) {
    const probe = probes.value.find((p) => p.id === selectedProbeId);
    if (probe) {
      await selectProbe(probe);
    }
  }
});
</script>
