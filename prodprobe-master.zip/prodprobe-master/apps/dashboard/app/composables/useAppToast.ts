export function useAppToast() {
  const toast = useToast();

  return {
    showSuccess(title: string, description?: string) {
      toast.add({
        title,
        description,
        color: 'success',
        icon: 'i-heroicons-check-circle',
      });
    },
    showError(title: string, description?: string) {
      toast.add({
        title,
        description,
        color: 'error',
        icon: 'i-heroicons-exclamation-circle',
      });
    },
  };
}
