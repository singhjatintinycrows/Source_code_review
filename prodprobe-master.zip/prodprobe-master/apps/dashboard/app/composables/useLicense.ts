import type { inferRouterOutputs } from '@trpc/server';
import { computed, ref } from 'vue';
import { useNuxtApp } from '#app';
import type { AppRouter } from '../../../backend/src/index';
import {
  CancelledOperationError,
  isCancelledOperation,
} from '../utils/operation';

type RouterOutput = inferRouterOutputs<AppRouter>;

const licenseStatus = ref<RouterOutput['license']['status'] | null>(null);
const licenseFetchError = ref(false);
let statusPromise: Promise<RouterOutput['license']['status']> | null = null;
let statusFetchGeneration = 0;
let statusInvalidated = false;
const licenseUpdate = ref<symbol | null>(null);
const isLicenseUpdating = computed(() => licenseUpdate.value !== null);
const licenseSync = ref<symbol | null>(null);
const isLicenseSyncing = computed(() => licenseSync.value !== null);

export const useLicense = () => {
  const invalidateLicenseStatus = () => {
    // Keep the displayed snapshot, but discard reads started before a mutation.
    statusFetchGeneration++;
    statusPromise = null;
    statusInvalidated = true;
  };

  const captureLicenseOperation = (allowUpdate = false) => {
    const generation = statusFetchGeneration;
    return () =>
      generation === statusFetchGeneration &&
      (allowUpdate || !isLicenseUpdating.value);
  };

  const beginLicenseUpdate = () => {
    if (isLicenseUpdating.value || isLicenseSyncing.value) return;
    const update = Symbol();
    licenseUpdate.value = update;
    return () => {
      if (licenseUpdate.value === update) licenseUpdate.value = null;
    };
  };

  const beginLicenseSync = () => {
    if (isLicenseUpdating.value || isLicenseSyncing.value) return;
    const sync = Symbol();
    licenseSync.value = sync;
    return () => {
      if (licenseSync.value === sync) licenseSync.value = null;
    };
  };

  const clearLicense = () => {
    invalidateLicenseStatus();
    licenseUpdate.value = null;
    licenseSync.value = null;
    licenseStatus.value = null;
    licenseFetchError.value = false;
    statusInvalidated = false;
  };

  const fetchLicenseStatus = async (
    force = false,
  ): Promise<RouterOutput['license']['status']> => {
    if (!force && !statusInvalidated && licenseStatus.value) {
      return licenseStatus.value;
    }
    if (statusPromise) {
      return statusPromise;
    }

    const { $trpc } = useNuxtApp();
    const currentGen = statusFetchGeneration;
    statusPromise = (async () => {
      try {
        const res = await $trpc.license.status.query();
        if (currentGen !== statusFetchGeneration)
          throw new CancelledOperationError();
        licenseStatus.value = res;
        licenseFetchError.value = false;
        statusInvalidated = false;
        return res;
      } catch (err) {
        if (currentGen !== statusFetchGeneration || isCancelledOperation(err))
          throw new CancelledOperationError();
        licenseFetchError.value = true;
        throw err;
      } finally {
        if (currentGen === statusFetchGeneration) {
          statusPromise = null;
        }
      }
    })();

    return statusPromise;
  };

  return {
    licenseStatus,
    licenseFetchError,
    fetchLicenseStatus,
    invalidateLicenseStatus,
    captureLicenseOperation,
    isLicenseUpdating,
    beginLicenseUpdate,
    isLicenseSyncing,
    beginLicenseSync,
    clearLicense,
  };
};
