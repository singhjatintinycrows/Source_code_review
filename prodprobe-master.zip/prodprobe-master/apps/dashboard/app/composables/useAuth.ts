import type { CreateTRPCProxyClient } from '@trpc/client';
import type { inferRouterOutputs } from '@trpc/server';
import { computed, ref, shallowRef } from 'vue';
import { navigateTo, useNuxtApp } from '#app';
import type { AppRouter } from '../../../backend/src/index';
import {
  CancelledOperationError,
  isCancelledOperation,
} from '../utils/operation';
import { decodeJwtPayload, normalizeToken } from '../utils/token';
import { isUnauthorizedError } from '../utils/trpc';
import { useLicense } from './useLicense';

type RouterOutput = inferRouterOutputs<AppRouter>;
type AuthClient = CreateTRPCProxyClient<AppRouter>;
type Tokens = { accessToken: string; refreshToken: string };

export type AuthCredentials = Tokens & {
  sessionKey: string | null;
  version: number;
  isAuthenticated: boolean;
  isCurrent: () => boolean;
  isUnchanged: () => boolean;
};

const emptyTokens: Tokens = { accessToken: '', refreshToken: '' };
const sessionVersion = ref(0);
const credentials = shallowRef(describeCredentials(emptyTokens));
const user = ref<RouterOutput['me'] | null>(null);
const userFetchError = ref(false);
let userPromise: Promise<RouterOutput['me']> | null = null;
let userFetchGeneration = 0;
let credentialVersion = 0;
let refreshPromise: { version: number; promise: Promise<string> } | null = null;
let authClient: AuthClient | undefined;
let stopObserver: (() => void) | undefined;

function describeCredentials(tokens: Tokens) {
  let sessionKey: string | null = null;
  let claimsKey: string | null = null;
  let usable = false;
  try {
    const access = decodeJwtPayload(tokens.accessToken);
    const refresh = decodeJwtPayload(tokens.refreshToken);
    if (
      typeof refresh.userId === 'string' &&
      refresh.userId &&
      typeof refresh.userSecret === 'string' &&
      refresh.userSecret &&
      access.userId === refresh.userId &&
      Number.isFinite(access.exp) &&
      Number.isFinite(refresh.exp)
    ) {
      // Unverified claims identify caches only. The server still authorizes every request.
      sessionKey = JSON.stringify([refresh.userId, refresh.userSecret]);
      usable = refresh.exp * 1000 > Date.now();
      claimsKey = JSON.stringify(
        [access.email, access.permissions],
        (_key, value) =>
          value && typeof value === 'object' && !Array.isArray(value)
            ? Object.fromEntries(
                Object.keys(value)
                  .sort()
                  .map((key) => [key, value[key]]),
              )
            : value,
      );
    }
  } catch {
    // Missing, malformed, or mismatched pairs cannot own cached state.
  }
  return { ...tokens, sessionKey, claimsKey, usable };
}

function applyCredentials(
  next: ReturnType<typeof describeCredentials>,
  { boundary = false, completeLogin = false, claimsChanged = false } = {},
) {
  const previous = credentials.value;
  const changed =
    previous.accessToken !== next.accessToken ||
    previous.refreshToken !== next.refreshToken;
  const newSession =
    boundary ||
    (!completeLogin &&
      (previous.sessionKey !== next.sessionKey ||
        previous.usable !== next.usable ||
        (changed && !next.sessionKey)));
  const newClaims =
    claimsChanged ||
    (previous.sessionKey !== null &&
      previous.sessionKey === next.sessionKey &&
      previous.claimsKey !== next.claimsKey);
  if (!changed && !newSession && !newClaims) return;

  credentialVersion++;
  credentials.value = next;
  if (newSession || newClaims) {
    userFetchGeneration++;
    user.value = null;
    userFetchError.value = false;
    userPromise = null;
  }
  if (newSession) {
    useLicense().clearLicense();
    sessionVersion.value++;
  } else if (newClaims && stopObserver) {
    const observer = stopObserver;
    const generation = userFetchGeneration;
    queueMicrotask(() => {
      if (
        stopObserver !== observer ||
        generation !== userFetchGeneration ||
        !credentials.value.usable
      )
        return;
      const current = captureSession();
      void fetchUser().catch((error) => {
        if (
          !current() ||
          generation !== userFetchGeneration ||
          stopObserver !== observer ||
          isCancelledOperation(error)
        )
          return;
        console.error('Failed to revalidate user', error);
      });
    });
  }
}

function reconcileAuth() {
  if (typeof window === 'undefined') return;
  applyCredentials(
    describeCredentials({
      accessToken: normalizeToken(window.localStorage.getItem('accessToken')),
      refreshToken: normalizeToken(window.localStorage.getItem('refreshToken')),
    }),
  );
}

export function captureAuthCredentials(): AuthCredentials {
  reconcileAuth();
  const epoch = sessionVersion.value;
  const version = credentialVersion;
  const isCurrent = () => {
    reconcileAuth();
    return epoch === sessionVersion.value;
  };
  return {
    accessToken: credentials.value.accessToken,
    refreshToken: credentials.value.refreshToken,
    sessionKey: credentials.value.sessionKey,
    version,
    isAuthenticated: credentials.value.usable,
    isCurrent,
    isUnchanged: () => isCurrent() && version === credentialVersion,
  };
}

function captureSession(): () => boolean {
  // Ownership guards survive ordinary rotation; token writers also check the credential version.
  return captureAuthCredentials().isCurrent;
}

export function writeAuthTokens(
  update: Partial<Tokens>,
  origin?: AuthCredentials,
  options: { boundary?: boolean; completeLogin?: boolean } = {},
): AuthCredentials {
  reconcileAuth();
  if (origin && !origin.isUnchanged()) throw new CancelledOperationError();
  const next = describeCredentials({
    accessToken: normalizeToken(
      update.accessToken ?? credentials.value.accessToken,
    ),
    refreshToken: normalizeToken(
      update.refreshToken ?? credentials.value.refreshToken,
    ),
  });
  if (
    origin &&
    (next.accessToken || next.refreshToken) &&
    (!next.usable ||
      (origin.sessionKey && origin.sessionKey !== next.sessionKey))
  ) {
    throw new Error('Invalid credentials returned by authentication server');
  }
  try {
    for (const key of ['accessToken', 'refreshToken'] as const) {
      if (update[key] === undefined) continue;
      if (next[key]) window.localStorage.setItem(key, next[key]);
      else window.localStorage.removeItem(key);
    }
  } catch (error) {
    reconcileAuth();
    throw error;
  }
  // Publish our full pair at once; no component-scoped storage watchers are involved.
  applyCredentials(next, options);
  const written = captureAuthCredentials();
  if (
    written.accessToken !== next.accessToken ||
    written.refreshToken !== next.refreshToken
  )
    throw new CancelledOperationError();
  return written;
}

export function observeAuthSession(client: AuthClient): () => void {
  stopObserver?.();
  authClient = client;
  const onStorage = (event: StorageEvent) => {
    if (event.storageArea && event.storageArea !== window.localStorage) return;
    if (
      event.key !== null &&
      event.key !== 'accessToken' &&
      event.key !== 'refreshToken'
    )
      return;
    reconcileAuth();
    if (event.key === null) {
      applyCredentials(credentials.value, { boundary: true });
    } else {
      // Queued events may describe an intermediate A -> B -> A or clear -> A.
      // Use that evidence to invalidate, but never write an old event back to storage.
      const intermediate = describeCredentials({
        ...credentials.value,
        [event.key]: normalizeToken(event.newValue),
      });
      const boundary =
        intermediate.sessionKey !== credentials.value.sessionKey ||
        intermediate.usable !== credentials.value.usable;
      const claimsChanged =
        !boundary && intermediate.claimsKey !== credentials.value.claimsKey;
      if (boundary || claimsChanged)
        applyCredentials(credentials.value, { boundary, claimsChanged });
    }
  };
  const onPageShow = () => reconcileAuth();
  let stopped = false;
  const stop = () => {
    if (stopped) return;
    stopped = true;
    window.removeEventListener('storage', onStorage);
    window.removeEventListener('pageshow', onPageShow);
    if (stopObserver === stop) {
      stopObserver = undefined;
      authClient = undefined;
    }
  };
  stopObserver = stop;
  window.addEventListener('storage', onStorage);
  window.addEventListener('pageshow', onPageShow);
  reconcileAuth();
  return stop;
}

const accessToken = computed({
  get: () => credentials.value.accessToken,
  set: (value: string) => {
    writeAuthTokens({ accessToken: value });
  },
});
const refreshToken = computed({
  get: () => credentials.value.refreshToken,
  set: (value: string) => {
    writeAuthTokens({ refreshToken: value });
  },
});
const isAuthenticated = computed(() => credentials.value.usable);

async function login(token: string, identifier?: string): Promise<boolean> {
  const client = authClient ?? useNuxtApp().$trpc;
  const origin = writeAuthTokens(emptyTokens, undefined, { boundary: true });
  try {
    const response = await client.verifySso.mutate({ token, identifier });
    if (!origin.isUnchanged()) throw new CancelledOperationError();
    if (!response.success || !response.accessToken || !response.refreshToken)
      return false;
    // This result belongs to the epoch started synchronously by login(), not a second login.
    writeAuthTokens(response, origin, { completeLogin: true });
    return true;
  } catch (error) {
    if (!origin.isCurrent()) throw new CancelledOperationError();
    if (!isCancelledOperation(error)) console.error('Login failed', error);
    throw error;
  }
}

async function logout() {
  writeAuthTokens(emptyTokens, undefined, { boundary: true });
  return navigateTo('/login');
}

async function fetchUser(force = false): Promise<RouterOutput['me']> {
  const origin = captureAuthCredentials();
  if (!origin.isAuthenticated) throw new CancelledOperationError();
  if (!force && user.value) return user.value;
  if (userPromise) return userPromise;
  const client = authClient ?? useNuxtApp().$trpc;
  const generation = userFetchGeneration;
  const current = () =>
    origin.isCurrent() && generation === userFetchGeneration;
  const pending = client.me
    .query()
    .then((response) => {
      if (!current()) throw new CancelledOperationError();
      user.value = response;
      userFetchError.value = false;
      return response;
    })
    .catch((error) => {
      if (!current()) throw new CancelledOperationError();
      userFetchError.value = true;
      if (isUnauthorizedError(error) && !origin.isUnchanged())
        throw new CancelledOperationError();
      throw error;
    })
    .finally(() => {
      if (userPromise === pending) userPromise = null;
    });
  userPromise = pending;
  return pending;
}

async function refresh(): Promise<string> {
  const origin = captureAuthCredentials();
  if (!origin.isAuthenticated) throw new CancelledOperationError();
  if (refreshPromise?.version === origin.version) return refreshPromise.promise;
  const client = authClient ?? useNuxtApp().$trpc;
  const pending = client.refresh
    .mutate({ refreshToken: origin.refreshToken })
    .then((response) => {
      if (!origin.isUnchanged()) throw new CancelledOperationError();
      if (!response.accessToken || !response.refreshToken)
        throw new Error('Failed to refresh token');
      return writeAuthTokens(response, origin).accessToken;
    })
    .catch(async (error) => {
      if (!origin.isUnchanged()) throw new CancelledOperationError();
      if (isUnauthorizedError(error)) {
        console.error('Refresh token expired or invalid', error);
        const cleared = writeAuthTokens(emptyTokens, origin, {
          boundary: true,
        });
        await navigateTo('/login');
        if (!cleared.isCurrent()) throw new CancelledOperationError();
      }
      throw error;
    })
    .finally(() => {
      if (refreshPromise?.promise === pending) refreshPromise = null;
    });
  refreshPromise = { version: origin.version, promise: pending };
  return pending;
}

export const useAuth = () => {
  reconcileAuth();
  return {
    accessToken,
    refreshToken,
    user,
    userFetchError,
    sessionVersion,
    isAuthenticated,
    captureSession,
    login,
    logout,
    refresh,
    fetchUser,
  };
};
