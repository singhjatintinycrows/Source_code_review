import { defineStore } from 'pinia';
import { ref } from 'vue';
import { useNuxtApp } from '#app';
import { useAppToast } from '../composables/useAppToast';

export const useTeamsStore = defineStore('teams', () => {
  const { $trpc } = useNuxtApp();
  const toast = useAppToast();

  const teams = ref([]);
  const isLoadingTeams = ref(false);

  // Fetch all teams
  async function fetchTeams() {
    isLoadingTeams.value = true;
    try {
      teams.value = await $trpc.teams.list.query();
    } catch (error) {
      console.error('Failed to load teams:', error);
      toast.showError('Error', 'Failed to load teams.');
    } finally {
      isLoadingTeams.value = false;
    }
  }

  return {
    teams,
    isLoadingTeams,
    fetchTeams,
  };
});
