import type { inferRouterOutputs } from '@trpc/server';
import { defineStore } from 'pinia';
import { ref } from 'vue';
import { useNuxtApp } from '#app';
import type { AppRouter } from '../../../backend/src/index';
import { useAppToast } from '../composables/useAppToast';

type RouterOutput = inferRouterOutputs<AppRouter>;
export type Service = RouterOutput['services']['list'][0];

export const useServicesStore = defineStore('services', () => {
  const { $trpc } = useNuxtApp();
  const toast = useAppToast();

  const services = ref<Service[]>([]);
  const isLoadingServices = ref(false);

  // Fetch all services
  const fetchServices = async () => {
    isLoadingServices.value = true;
    try {
      services.value = await $trpc.services.list.query();
    } catch (error) {
      console.error('Failed to load services:', error);
      toast.showError('Error', 'Failed to load services.');
    } finally {
      isLoadingServices.value = false;
    }
  };

  // Create a new service
  const createService = async (payload: {
    name: string;
    teamIds: string[];
    language?: 'JAVA' | 'NODE' | 'PYTHON' | 'RUBY';
    sourceMapRequired: boolean;
    agentLimit?: number | null;
  }) => {
    isLoadingServices.value = true;
    try {
      const result = await $trpc.services.create.mutate(payload);
      await fetchServices();
      return result;
    } catch (error) {
      console.error('Failed to create service:', error);
      throw error;
    } finally {
      isLoadingServices.value = false;
    }
  };

  // Update a service name or configurations
  const updateService = async (payload: {
    serviceId: string;
    name: string;
    sourceMapRequired: boolean;
    agentLimit?: number | null;
  }) => {
    isLoadingServices.value = true;
    try {
      const result = await $trpc.services.update.mutate(payload);
      await fetchServices();
      return result;
    } catch (error) {
      console.error('Failed to update service:', error);
      throw error;
    } finally {
      isLoadingServices.value = false;
    }
  };

  // Delete a service
  const deleteService = async (serviceId: string) => {
    isLoadingServices.value = true;
    try {
      const result = await $trpc.services.delete.mutate({ serviceId });
      await fetchServices();
      return result;
    } catch (error) {
      console.error('Failed to delete service:', error);
      throw error;
    } finally {
      isLoadingServices.value = false;
    }
  };

  // Update a team's role access level on a service
  const updateServiceAccess = async (payload: {
    serviceId: string;
    teamId: string;
    role: number;
  }) => {
    isLoadingServices.value = true;
    try {
      const result = await $trpc.services.updateAccess.mutate(payload);
      await fetchServices();
      return result;
    } catch (error) {
      console.error('Failed to update service access:', error);
      throw error;
    } finally {
      isLoadingServices.value = false;
    }
  };

  // Revoke a team's access level from a service
  const removeServiceAccess = async (payload: {
    serviceId: string;
    teamId: string;
  }) => {
    isLoadingServices.value = true;
    try {
      const result = await $trpc.services.removeAccess.mutate(payload);
      await fetchServices();
      return result;
    } catch (error) {
      console.error('Failed to revoke service access:', error);
      throw error;
    } finally {
      isLoadingServices.value = false;
    }
  };

  const getServiceById = (id: string) => {
    return services.value.find((s) => s.id === id);
  };

  return {
    services,
    isLoadingServices,
    fetchServices,
    createService,
    updateService,
    deleteService,
    updateServiceAccess,
    removeServiceAccess,
    getServiceById,
  };
});
