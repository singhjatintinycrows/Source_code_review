<template>
  <div class="flex h-screen bg-gray-50 dark:bg-gray-900">
    <!-- Sidebar -->
    <div class="w-64 border-r border-gray-200 dark:border-gray-800 bg-white dark:bg-gray-950 flex flex-col">
      <div class="p-4 font-bold text-lg border-b border-gray-200 dark:border-gray-800 flex items-center gap-2"
        style="padding-left: 24px;">
        <img :src="`${config.app.baseURL}ht-logo.png`" alt="HyperProbe Logo" width="24" height="24" loading="eager"
          style="margin-top: 0.1rem;" />
        HyperProbe
      </div>
      <div class="flex-1 overflow-y-auto p-4">
        <UNavigationMenu color="secondary" orientation="vertical" :items="menuItems" />
      </div>
      <div v-if="user" class="px-4 mb-2 text-center max-w-full overflow-hidden">
        <div
          class="flex items-center justify-center gap-1.5 text-sm font-medium text-gray-700 dark:text-gray-300 max-w-full"
          :title="user.email">
          <UIcon name="i-heroicons-user-circle" class="w-4 h-4 text-gray-500 dark:text-gray-400 flex-shrink-0" />
          <span class="truncate">{{ user.email }}</span>

          <!-- Explicit Teams Icon Button -->
          <UButton v-if="user.teams && user.teams.length > 0" variant="solid" size="xs"
            icon="i-heroicons-users" class="bg-blue-300 hover:bg-blue-400 dark:hover:bg-blue-800 cursor-pointer pl-2 pr-2 pt-0.5 pb-0.5"
            @click="isTeamsModalOpen = true" title="View your teams" />
        </div>
      </div>
      <div class="p-4 border-t border-gray-200 dark:border-gray-800">
        <div class="text-xs text-gray-500 dark:text-gray-400 mb-3 text-center">
          v{{ config.public.platformVersion }}
        </div>
        <UButton v-if="isAuthenticated" @click="handleLogout" color="error" variant="soft" block icon="i-heroicons-arrow-left-on-rectangle">
          Sign out
        </UButton>
      </div>
    </div>

    <!-- Main content -->
    <div class="flex-1 flex flex-col overflow-hidden">
      <!-- License Banners -->
      <div v-if="licenseStatus && licenseStatus.isProvisioned">
        <div v-if="licenseStatus.status === 'LOCKED'"
          class="bg-red-500 text-white p-3 text-center font-semibold text-sm">
          License Expired. The system is currently locked. Please update your license.
        </div>
        <div v-else-if="licenseStatus.status === 'REVOKED'"
          class="bg-red-600 text-white p-3 text-center font-semibold text-sm">
          Cloning Detected - Contact Support immediately. The system is locked.
        </div>
        <div v-else-if="licenseStatus.upgradeRequired"
          class="bg-orange-500 text-white p-3 text-center font-semibold text-sm">
          Upgrade Required: Agent limit ({{ licenseStatus.maxAgents }}) reached. New agents will be rejected.
        </div>
      </div>

      <div v-if="!isLicensePage && isDeploymentReady && (licenseFetchError || userFetchError || initError)"
        role="status" class="flex flex-wrap items-center gap-3 bg-amber-50 px-4 py-3 text-sm text-amber-900 dark:bg-amber-950 dark:text-amber-200">
        <span class="flex-1">Unable to refresh deployment status. Showing the last known status.</span>
        <UButton @click="handleRetryInit" :loading="retryingLicense" color="neutral" variant="outline" icon="i-heroicons-arrow-path">
          Retry
        </UButton>
      </div>

      <main class="flex-1 overflow-y-auto p-8 flex items-center justify-center"
        v-if="!isAuthenticated">
        <UCard class="w-full max-w-md">
          <template #header>
            <div class="text-xl font-bold text-center">Sign In Required</div>
          </template>
          <p class="mb-4 text-center text-gray-600 dark:text-gray-400">
            Your session is unavailable. Sign in to continue.
          </p>
          <UButton to="/login" color="primary" block icon="i-heroicons-arrow-right-on-rectangle">
            Sign In
          </UButton>
        </UCard>
      </main>

      <main class="flex-1 overflow-y-auto p-8 flex items-center justify-center"
        v-else-if="!isLicensePage && !isDeploymentReady && (licenseFetchError || userFetchError || initError)">
        <UCard class="w-[500px]">
          <template #header>
            <div class="text-xl font-bold text-center text-red-500">Failed to Load Deployment Status</div>
          </template>

          <div class="text-center text-gray-600 dark:text-gray-400 mb-4">
            Unable to verify deployment license or user status. Please check your network connection or server status.
          </div>

          <div class="flex justify-center">
            <UButton @click="handleRetryInit" :loading="retryingLicense" color="primary" variant="solid" icon="i-heroicons-arrow-path">
              Retry
            </UButton>
          </div>
        </UCard>
      </main>

      <main class="flex-1 overflow-y-auto p-8" v-else-if="isDeploymentReady || isLicensePage">
        <slot />
      </main>

      <main class="flex-1 overflow-y-auto p-8 flex items-center justify-center"
        v-else-if="licenseStatus && !licenseStatus.isProvisioned && user && !user.permissions?.isAdmin">
        <UCard class="w-[500px]">
          <template #header>
            <div class="text-xl font-bold text-center">License Required</div>
          </template>

          <div class="text-center text-gray-600 dark:text-gray-400">
            Please contact your administrator to activate the HyperProbe license for this deployment.
          </div>
        </UCard>
      </main>

      <main class="flex-1 overflow-y-auto p-8 flex flex-col items-center justify-center gap-3"
        v-else>
        <UIcon name="i-heroicons-arrow-path" class="w-8 h-8 animate-spin text-gray-400" />
        <div class="text-center text-sm text-gray-600 dark:text-gray-300">
          Loading deployment status...
        </div>
      </main>

      <!-- User Teams Modal -->
      <UModal v-model:open="isTeamsModalOpen">
        <template #content>
          <UCard :ui="{ divide: 'divide-y divide-gray-100 dark:divide-gray-800' }">
            <template #header>
              <div class="flex items-center justify-between">
                <h3 class="text-base font-semibold leading-6 text-gray-900 dark:text-white flex items-center gap-2">
                  <UIcon name="i-heroicons-users" class="w-5 h-5 text-secondary-500" />
                  Your Teams
                </h3>
                <UButton color="neutral" variant="ghost" icon="i-heroicons-x-mark-20-solid" class="-my-1"
                  @click="isTeamsModalOpen = false" />
              </div>
            </template>
            <div class="py-2 space-y-3">
              <div v-if="user?.teams && user.teams.length > 0" class="space-y-2 max-h-[300px] overflow-y-auto pr-1">
                <div v-for="teamName in user.teams" :key="teamName"
                  class="flex items-center gap-2.5 px-3 py-2 rounded-lg bg-gray-50 dark:bg-gray-900 border border-gray-100 dark:border-gray-800 font-medium text-sm text-gray-700 dark:text-gray-300">
                  <UIcon name="i-heroicons-user-group" class="w-4 h-4 text-gray-400" />
                  <span>{{ teamName }}</span>
                </div>
              </div>
              <div v-else class="text-center text-sm text-gray-500 py-4">
                You are not assigned to any teams.
              </div>
            </div>
          </UCard>
        </template>
      </UModal>
    </div>
  </div>
</template>

<script lang="ts">
let cachedPublicKey: string | undefined;
</script>

<script setup lang="ts">
import { getLicensingServerUrl, HYPERPROBE_LICENSING_PUBLIC_KEY_URL } from '@hyperprobe/constants';
import { computed, onMounted, onUnmounted, ref, watch } from 'vue';
import { useRoute, useRouter } from 'vue-router';
import { useNuxtApp } from '#app';
import { useAuth } from '../composables/useAuth';
import { useLicense } from '../composables/useLicense';
import { submitInitialRelay } from '../utils/initialRelay';
import { CancelledOperationError, isCancelledOperation } from '../utils/operation';
import { isUnauthorizedError } from '../utils/trpc';

const router = useRouter();
const route = useRoute();
const { $trpc } = useNuxtApp();
const {
  accessToken, user, userFetchError, logout, fetchUser,
  sessionVersion, isAuthenticated, captureSession,
} = useAuth();
const {
  licenseStatus,
  licenseFetchError,
  fetchLicenseStatus,
  invalidateLicenseStatus,
  captureLicenseOperation,
  beginLicenseSync,
} = useLicense();
const config = useRuntimeConfig();

const initError = ref(false);
const retryingLicense = ref(false);
const isTeamsModalOpen = ref(false);

const isLicensePage = computed(() => {
  const path = (route.path || '').replace(/\/$/, '');
  return path === '/license' || path.startsWith('/license/');
});

const isDeploymentReady = computed(() =>
  Boolean(isAuthenticated.value && user.value && licenseStatus.value?.isProvisioned),
);

watch(
  [() => route.path, () => licenseStatus.value, () => user.value, () => accessToken.value],
  () => {
    if (
      !accessToken.value ||
      !licenseStatus.value ||
      licenseStatus.value.isProvisioned ||
      !user.value
    ) {
      return;
    }

    if (user.value.permissions?.isAdmin) {
      if (!isLicensePage.value) {
        router.replace('/license');
      }
    } else if (isLicensePage.value) {
      router.replace('/services');
    }
  },
  { immediate: true },
);

watch([licenseStatus, user], ([status, u]) => {
  if (status && u) {
    initError.value = false;
    startStatusInterval();
  } else if (statusInterval) {
    clearInterval(statusInterval);
    statusInterval = undefined;
  }
});

watch([sessionVersion, isAuthenticated], () => {
  initError.value = false;
  if (isMounted && isAuthenticated.value) void initLayout();
});

const handleRetryInit = async () => {
  retryingLicense.value = true;
  try {
    await initLayout(true);
  } finally {
    retryingLicense.value = false;
  }
};

const checkLicenseAndCourier = async (force = false) => {
  const currentSession = captureSession();
  let currentLicense = captureLicenseOperation();
  const assertCurrent = (allowUnmount = false) => {
    if ((!allowUnmount && !isMounted) || !currentSession() || !isAuthenticated.value || !currentLicense()) {
      throw new CancelledOperationError();
    }
  };
  const refreshAfterMutation = async (allowUnmount = false) => {
    assertCurrent(allowUnmount);
    invalidateLicenseStatus();
    currentLicense = captureLicenseOperation();
    await fetchLicenseStatus(true);
    assertCurrent(allowUnmount);
  };
  try {
    assertCurrent();
    const statusObj = await fetchLicenseStatus(force);
    assertCurrent();

    // Phase 3: Optional Courier (Proxy)
    if (statusObj.hintStatus === 'COURIER_REQUIRED') {
      const finishSync = beginLicenseSync();
      if (!finishSync) return;
      let lockAcquired = false;
      const courierLease = {};
      try {
        const lockRes = await $trpc.license.acquireCourierLock.mutate(undefined, {
          context: { courierLease },
        });
        lockAcquired = lockRes.success;
        assertCurrent();
        if (!lockAcquired) return;
        const deploymentConfig =
          await $trpc.license.getDeploymentConfig.query();
        assertCurrent();
        const { jwt, licenseId, nextToken, syncStatusIndex } = deploymentConfig;
        if (jwt && licenseId) {
          const syncPrecondition = syncStatusIndex === undefined ? {} : { syncStatusIndex };
          const licensingServerUrl = await getLicensingServerUrl();
          assertCurrent();

          const submitRelayOnDemand = async (jwtVal: string, tokenVal: string) => {
            const assertRelayCurrent = () => assertCurrent(!nextToken);
            const submit = (publicKey?: string) => {
              const input = { jwt: jwtVal, nextToken: tokenVal, publicKey };
              return nextToken
                ? $trpc.license.submitRelay.mutate({ ...input, preparedFrom: jwt, ...syncPrecondition })
                : submitInitialRelay(
                  $trpc.license.submitRelay.mutate,
                  { ...input, initialFrom: jwt },
                  assertRelayCurrent,
                );
            };
            assertRelayCurrent();
            try {
              // Attempt 1: Fast Sync (No outbound Firebase query!)
              await submit(cachedPublicKey || undefined);
            } catch (err) {
              assertRelayCurrent();
              const errorMsg = err instanceof Error ? err.message : String(err || '');
              if (
                errorMsg.includes('No public key available for verification') ||
                errorMsg.includes('Invalid, forged, or expired license token')
              ) {
                // Key rotation detected! Fetch fresh public key on-demand
                let fetchedKey: string | undefined;
                const controller = new AbortController();
                const id = setTimeout(() => controller.abort(), 5000);
                try {
                  const pubKeyRes = await fetch(HYPERPROBE_LICENSING_PUBLIC_KEY_URL, { signal: controller.signal });
                  assertRelayCurrent();
                  if (pubKeyRes.ok) {
                    const parsed = await pubKeyRes.json();
                    assertRelayCurrent();
                    if (parsed && typeof parsed === 'string') {
                      fetchedKey = parsed;
                      cachedPublicKey = parsed;
                    }
                  }
                } catch (fetchErr) {
                  assertRelayCurrent();
                  console.error('Failed to fetch public key on-demand:', fetchErr);
                } finally {
                  clearTimeout(id);
                }

                if (fetchedKey) {
                  assertRelayCurrent();
                  // Retry submitting with the rotated public key
                  await submit(fetchedKey);
                } else {
                  throw err;
                }
              } else {
                throw err;
              }
            }
            await refreshAfterMutation(!nextToken);
          };

          if (!nextToken) {
            // Phase 0: Lazy Init Relay
            const controller0 = new AbortController();
            const id0 = setTimeout(() => controller0.abort(), 10000);
            try {
              const response = await fetch(
                `${licensingServerUrl}/api/heartbeat`,
                {
                  method: 'POST',
                  headers: { 'Content-Type': 'application/json' },
                  body: JSON.stringify({
                    licenseId,
                    jwt,
                    nextToken: null,
                  }),
                  signal: controller0.signal,
                },
              );
              // Initialization is already committed centrally; navigation must not discard its token.
              assertCurrent(response.ok);
              if (response.status === 403 || response.status === 401) {
                await $trpc.license.reportRevocation.mutate();
                await refreshAfterMutation();
                return;
              }
              if (response.ok) {
                const data = await response.json();
                assertCurrent(true);
                await submitRelayOnDemand(data.jwt, data.nextToken);
              }
            } finally {
              clearTimeout(id0);
            }
          } else {
            // Full 2-Phase Relay
            const controller1 = new AbortController();
            const id1 = setTimeout(() => controller1.abort(), 10000);
            let res1: Response;
            try {
              res1 = await fetch(`${licensingServerUrl}/api/heartbeat`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                  phase: 1,
                  licenseId,
                  jwt,
                  nextToken,
                }),
                signal: controller1.signal,
              });
            } finally {
              clearTimeout(id1);
            }
            assertCurrent();
            if (res1.status === 403 || res1.status === 401) {
              await $trpc.license.reportRevocation.mutate();
              await refreshAfterMutation();
              return;
            }
            if (res1.ok) {
              const data1 = await res1.json();
              assertCurrent();
              await $trpc.license.prepareRelay.mutate({
                jwt,
                previousNextToken: nextToken,
                nextToken: data1.nextToken,
                ...syncPrecondition,
              });
              assertCurrent();
              const controller2 = new AbortController();
              const id2 = setTimeout(() => controller2.abort(), 10000);
              let res2: Response;
              try {
                res2 = await fetch(`${licensingServerUrl}/api/heartbeat`, {
                  method: 'POST',
                  headers: { 'Content-Type': 'application/json' },
                  body: JSON.stringify({
                    phase: 2,
                    licenseId,
                    jwt,
                    nextToken: data1.nextToken,
                  }),
                  signal: controller2.signal,
                });
              } finally {
                clearTimeout(id2);
              }
              assertCurrent();
              if (res2.status === 403 || res2.status === 401) {
                await $trpc.license.reportRevocation.mutate();
                await refreshAfterMutation();
                return;
              }
              if (res2.ok) {
                const data2 = await res2.json();
                assertCurrent();
                await submitRelayOnDemand(data2.jwt, data1.nextToken);
              }
            }
          }
        } else {
          throw new Error('Deployment configuration is incomplete. Retry loading status.');
        }
      } catch (e) {
        assertCurrent();
        if (isCancelledOperation(e)) throw e;
        console.error('Courier relay failed', e);
      } finally {
        try {
          if (lockAcquired) await $trpc.license.releaseCourierLock.mutate(undefined, {
            context: { courierLease },
          });
        } catch (e) {
          console.error('Failed to release courier lock', e);
        } finally {
          finishSync();
        }
      }
    }
  } catch (err) {
    if (!isMounted || !currentSession() || !currentLicense() || isCancelledOperation(err)) {
      throw new CancelledOperationError();
    }
    console.error('Failed to fetch license status:', err);
    throw err;
  }
};

let statusInterval: ReturnType<typeof setInterval> | undefined;
let isMounted = false;

const startStatusInterval = () => {
  if (isMounted && isAuthenticated.value && !statusInterval && licenseStatus.value && user.value) {
    statusInterval = setInterval(() => {
      const currentSession = captureSession();
      checkLicenseAndCourier(true).catch((err) => {
        if (!isMounted || !currentSession() || isCancelledOperation(err)) return;
        if (isUnauthorizedError(err)) {
          logout();
        }
      });
    }, 60000);
  }
};

const initLayout = async (force = false) => {
  if (!isMounted || !isAuthenticated.value) return;
  const currentSession = captureSession();
  initError.value = false;
  try {
    await Promise.all([fetchUser(force), checkLicenseAndCourier(force)]);
    if (!isMounted || !currentSession()) return;
    initError.value = false;
    startStatusInterval();
  } catch (err) {
    if (!isMounted || !currentSession()) return;
    if (isCancelledOperation(err)) {
      initError.value = !user.value || !licenseStatus.value;
      return;
    }
    console.error('Failed to initialize layout:', err);
    if (isUnauthorizedError(err)) {
      await logout();
    } else {
      initError.value = true;
    }
  }
};

onMounted(async () => {
  isMounted = true;
  await initLayout();
});

onUnmounted(() => {
  isMounted = false;
  if (statusInterval) {
    clearInterval(statusInterval);
    statusInterval = undefined;
  }
});

const menuItems = computed(() => {
  const items: Array<{
    label: string;
    to: string;
    icon: string;
    disabled?: boolean;
  }> = [];
  const isUnprovisioned = Boolean(
    licenseStatus.value && !licenseStatus.value.isProvisioned,
  );

  if (user.value?.permissions?.isAdmin) {
    items.push({
      label: 'Teams',
      to: '/teams',
      icon: 'i-heroicons-users',
      disabled: isUnprovisioned,
    });
    items.push({
      label: 'Users',
      to: '/users',
      icon: 'i-heroicons-user-group',
      disabled: isUnprovisioned,
    });
    items.push({
      label: 'License Info',
      to: '/license',
      icon: 'i-heroicons-key',
    });
  }

  items.push({
    label: 'Services',
    to: '/services',
    icon: 'i-heroicons-server',
    disabled: isUnprovisioned,
  });
  items.push({
    label: 'Live Agents',
    to: '/sources',
    icon: 'i-heroicons-code-bracket',
    disabled: isUnprovisioned,
  });
  items.push({
    label: 'Probes',
    to: '/probes',
    icon: 'i-heroicons-camera',
    disabled: isUnprovisioned,
  });
  // Add Settings later if needed

  return items;
});

const handleLogout = async () => {
  await logout();
};
</script>
