<template>
  <UModal :open="open" @update:open="$emit('update:open', $event)">
    <template #content>
      <UCard>
        <template #header>
          <div class="flex items-center justify-between">
            <h3 class="text-base font-semibold leading-6 text-gray-900 dark:text-white">
              {{ title }}
            </h3>
            <UButton 
              color="neutral" 
              variant="ghost" 
              icon="i-heroicons-x-mark-20-solid" 
              class="-my-1" 
              @click="$emit('update:open', false)" 
            />
          </div>
        </template>
        
        <div class="py-4 text-gray-600 dark:text-gray-400">
          <slot>
            Are you sure you want to delete this item? This action cannot be undone.
          </slot>
        </div>
        
        <template #footer>
          <div class="flex justify-end space-x-3">
            <UButton color="neutral" variant="soft" @click="$emit('update:open', false)">Cancel</UButton>
            <UButton color="error" :loading="loading" @click="$emit('confirm')">Delete</UButton>
          </div>
        </template>
      </UCard>
    </template>
  </UModal>
</template>

<script setup lang="ts">
defineProps<{
  open: boolean;
  title: string;
  loading?: boolean;
}>();

defineEmits<{
  (e: 'update:open', value: boolean): void;
  (e: 'confirm'): void;
}>();
</script>
