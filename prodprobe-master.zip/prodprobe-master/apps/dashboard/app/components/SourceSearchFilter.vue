<template>
  <div class="space-y-3 SearchFilter">
    <div class="relative max-w-md search-container">
      <UInput :model-value="modelValue" @update:model-value="onQueryUpdated" icon="i-heroicons-magnifying-glass"
        :placeholder="placeholder" class="w-full animate-none" @focus="showAutocomplete = true"
        @keydown.enter="handleSearchEnter">
        <template #trailing>
          <UIcon v-if="modelValue" name="i-heroicons-x-mark"
            class="w-4 h-4 text-gray-400 hover:text-gray-600 dark:hover:text-gray-200 cursor-pointer"
            @click="clearQuery" />
        </template>
      </UInput>

      <!-- Autocomplete Suggestions Dropdown -->
      <div v-if="showAutocomplete && suggestedTags.length > 0 && modelValue"
        class="absolute z-50 top-full left-0 right-0 mt-1 bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 rounded-lg shadow-lg overflow-hidden max-h-60 overflow-y-auto">
        <div v-for="tag in suggestedTags" :key="tag.type + ':' + tag.value"
          class="flex items-center gap-2 px-4 py-2.5 text-sm cursor-pointer hover:bg-gray-50 dark:hover:bg-gray-800 border-b border-gray-100 dark:border-gray-850 last:border-0"
          @click="addTag(tag)">
          <span class="font-semibold text-primary-500 dark:text-primary-400 min-w-[5.5rem] text-xs tracking-wider">
            {{ tag.label }}:
          </span>
          <span class="text-gray-700 dark:text-gray-300 font-medium">
            {{ tag.value }}
          </span>
        </div>
      </div>
    </div>

    <!-- Active Tag Pills -->
    <div v-if="activeTags.length > 0" class="flex flex-wrap items-center gap-2">
      <div v-for="tag in activeTags" :key="tag.type + ':' + tag.value"
        class="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-medium bg-gray-100 dark:bg-gray-800 text-gray-700 dark:text-gray-300 border border-gray-200 dark:border-gray-700">
        <span>
          <span class="opacity-70 font-semibold text-[10px] tracking-wider">{{ tag.label }}:</span>
          <span class="ml-1 font-semibold">{{ tag.value }}</span>
        </span>
        <UButton icon="i-heroicons-x-mark" size="xs" color="neutral" variant="ghost"
          class="rounded-full h-3.5 w-3.5 p-0 hover:bg-gray-200 dark:hover:bg-gray-700" @click="removeTag(tag)" />
      </div>
      <UButton color="neutral" variant="link" size="sm"
        class="p-0 text-xs text-primary-600 dark:text-primary-400 hover:underline cursor-pointer" @click="clearAllTags">
        Clear all
      </UButton>
    </div>
  </div>
</template>

<script setup lang="ts">
import { computed, onMounted, onUnmounted, ref } from 'vue';
import { PROBE_TAG_KEY_TO_LABEL } from '../constants/appConstants';
import { useServicesStore } from '../stores/services';

interface FilterTag {
  type: string;
  label: string;
  value: string;
}

const props = withDefaults(
  defineProps<{
    modelValue: string;
    activeTags: FilterTag[];
    candidates?: any[];
    placeholder?: string;
    tagKeyToLabel?: Record<string, string>;
  }>(),
  {
    candidates: () => [],
    tagKeyToLabel: () => PROBE_TAG_KEY_TO_LABEL,
  },
);

const emit = defineEmits<{
  'update:modelValue': [value: string];
  'update:activeTags': [value: FilterTag[]];
}>();

const servicesStore = useServicesStore();
const serviceNames = computed(() => {
  const map: Record<string, string> = {};
  for (const s of servicesStore.services) {
    map[s.id] = s.name;
  }
  return map;
});

const showAutocomplete = ref(false);

const getCanonicalTagType = (type: string): string | null => {
  if (!props.tagKeyToLabel || !type) return null;
  const trimmed = type.trim().toLowerCase();
  for (const key of Object.keys(props.tagKeyToLabel)) {
    if (key.toLowerCase() === trimmed) {
      return key;
    }
  }
  return null;
};

const isTagTypeAllowed = (type: string) => {
  return getCanonicalTagType(type) !== null;
};

const suggestedTags = computed(() => {
  const query = props.modelValue.trim();
  if (!query) return [];

  const matches: FilterTag[] = [];
  const uniqueValues = new Set<string>();

  // If query is formatted like "type: value" or "type:"
  if (query.includes(':')) {
    const [typePart, ...valParts] = query.split(':');
    const valPart = valParts.join(':').trim();
    const valLower = valPart.toLowerCase();
    const canonicalType = getCanonicalTagType(typePart || '');

    if (canonicalType) {
      const targetLabel = props.tagKeyToLabel?.[canonicalType] || canonicalType;

      // Scan candidates for this specific tag type
      props.candidates.forEach((c) => {
        let candidateVal: string | undefined;
        let matchType = canonicalType;

        if (canonicalType === 'environment' || canonicalType === 'env') {
          candidateVal = c.environment;
          matchType = 'environment';
        } else if (
          canonicalType === 'commitSha' ||
          canonicalType === 'commit'
        ) {
          candidateVal = c.commitSha;
          matchType = 'commitSha';
        } else if (canonicalType === 'serviceId') {
          candidateVal = c.serviceId;
        } else if (canonicalType === 'serviceName') {
          candidateVal = serviceNames.value[c.serviceId];
        } else if (
          canonicalType === 'sdkVersion' ||
          canonicalType === 'sdk' ||
          canonicalType === 'version'
        ) {
          candidateVal = c.sdkVersion;
          matchType = 'sdkVersion';
        }

        if (candidateVal) {
          const cValLower = candidateVal.toLowerCase();
          const matchesVal =
            !valLower ||
            cValLower.includes(valLower) ||
            (matchType === 'sdkVersion' &&
              cValLower.replace(/^v/, '').includes(valLower.replace(/^v/, '')));

          const key = `${matchType}:${candidateVal}`;
          if (matchesVal && !uniqueValues.has(key)) {
            uniqueValues.add(key);
            matches.push({
              type: matchType,
              label: props.tagKeyToLabel?.[matchType] || targetLabel,
              value: candidateVal,
            });
          }
        }
      });

      // If user typed a custom non-empty value that isn't already suggested, offer it as a tag
      if (valPart && !matches.some((m) => m.value.toLowerCase() === valLower)) {
        matches.unshift({
          type: canonicalType,
          label: targetLabel,
          value: valPart,
        });
      }

      return matches.slice(0, 10);
    }
  }

  const lowerQuery = query.toLowerCase();

  // Helper to add if unique
  const addMatch = (type: string, label: string, value: string) => {
    if (!isTagTypeAllowed(type)) return;

    const key = `${type}:${value}`;
    const valLower = value.toLowerCase();
    const labelLower = label.toLowerCase();
    const typeLower = type.toLowerCase();

    // Check if query matches the tag type/label (e.g. typing "env" matches "environment" / "Environment")
    const tagMatchesQuery =
      labelLower.startsWith(lowerQuery) ||
      typeLower.startsWith(lowerQuery) ||
      (typeLower === 'environment' && 'env'.startsWith(lowerQuery)) ||
      (typeLower === 'commitsha' && 'commit'.startsWith(lowerQuery)) ||
      (typeLower === 'sdkversion' &&
        ('sdk'.startsWith(lowerQuery) || 'version'.startsWith(lowerQuery)));

    // Check if query matches the candidate's value (e.g. "staging" matches value "staging")
    const valueMatchesQuery =
      valLower.includes(lowerQuery) ||
      (type === 'sdkVersion' &&
        valLower.replace(/^v/, '').includes(lowerQuery.replace(/^v/, '')));

    const isMatch = valueMatchesQuery || tagMatchesQuery;

    if (!uniqueValues.has(key) && isMatch) {
      uniqueValues.add(key);
      matches.push({ type, label, value });
    }
  };

  // Scan candidates
  props.candidates.forEach((c) => {
    if (c.environment)
      addMatch(
        'environment',
        props.tagKeyToLabel?.environment || 'Environment',
        c.environment,
      );
    if (c.serviceId) {
      addMatch(
        'serviceId',
        props.tagKeyToLabel?.serviceId || 'Service Id',
        c.serviceId,
      );
      const sName = serviceNames.value[c.serviceId];
      if (sName && sName !== c.serviceId) {
        addMatch(
          'serviceName',
          props.tagKeyToLabel?.serviceName || 'Service Name',
          sName,
        );
      }
    }
    if (c.commitSha)
      addMatch(
        'commitSha',
        props.tagKeyToLabel?.commitSha || 'Commit',
        c.commitSha,
      );
    if (c.sdkVersion)
      addMatch(
        'sdkVersion',
        props.tagKeyToLabel?.sdkVersion || 'SDK Version',
        c.sdkVersion,
      );
  });

  return matches.slice(0, 10); // Max 10 suggestions
});

const onQueryUpdated = (val: string) => {
  emit('update:modelValue', val);
  showAutocomplete.value = true;
};

const clearQuery = () => {
  emit('update:modelValue', '');
  showAutocomplete.value = false;
};

const addTag = (tag: FilterTag) => {
  const updatedTags = [...props.activeTags];
  if (!updatedTags.some((t) => t.type === tag.type && t.value === tag.value)) {
    updatedTags.push({ ...tag });
    emit('update:activeTags', updatedTags);
  }
  emit('update:modelValue', ''); // Clear search when a tag is selected
  showAutocomplete.value = false;
};

const removeTag = (tag: FilterTag) => {
  const updatedTags = props.activeTags.filter(
    (t) => !(t.type === tag.type && t.value === tag.value),
  );
  emit('update:activeTags', updatedTags);
};

const clearAllTags = () => {
  emit('update:activeTags', []);
  emit('update:modelValue', '');
  showAutocomplete.value = false;
};

const handleSearchEnter = () => {
  const query = props.modelValue.trim();
  if (!query) return;

  if (suggestedTags.value.length > 0) {
    addTag(suggestedTags.value[0]);
  } else if (query.includes(':')) {
    const [type, ...valParts] = query.split(':');
    const val = valParts.join(':').trim();
    const canonicalType = getCanonicalTagType(type || '');
    if (canonicalType && val) {
      addTag({
        type: canonicalType,
        label: props.tagKeyToLabel?.[canonicalType] || canonicalType,
        value: val,
      });
    }
  }
};

const closeAutocomplete = (e: MouseEvent) => {
  const target = e.target as HTMLElement;
  if (!target.closest('.SearchFilter')) {
    showAutocomplete.value = false;
  }
};

onMounted(() => {
  document.addEventListener('click', closeAutocomplete);
});

onUnmounted(() => {
  document.removeEventListener('click', closeAutocomplete);
});
</script>
