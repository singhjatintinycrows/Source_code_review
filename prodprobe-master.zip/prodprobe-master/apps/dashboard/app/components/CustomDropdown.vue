<template>
  <div class="flex items-center gap-3 bg-gray-50 dark:bg-gray-900/50 p-2 rounded-xl max-w-xl shadow-sm">
    <UIcon name="i-heroicons-server" class="w-5 h-5 text-secondary-500 flex-shrink-0" />
    <span class="text-sm font-semibold text-gray-800 dark:text-gray-200 whitespace-nowrap">Services:</span>
    <USelectMenu v-model="selections" :items="filteredItems" :value-key="valueKey" :label-key="labelKey" tabindex="0"
      :placeholder="placeholder || 'Select Services to start monitoring...'" multiple
      class="flex-1 max-w-md ring-2 ring-primary-500/10 focus-within:ring-primary-500" searchable
      :searchable-placeholder="placeholder || 'Search services...'" v-model:search-term="searchQuery"
      @update:model-value="handleSelectionChange">
      <template #label>
        <div class="flex flex-wrap gap-1 w-full" v-if="selections.length > 0">
          <UBadge v-for="id in selections" :key="id" color="primary" variant="subtle" size="sm" class="font-medium">
            {{items.find(s => s[valueKey] === id)?.[labelKey] || id}}
          </UBadge>
        </div>
        <span v-else class="truncate text-gray-500 font-medium">Select Services to see active agents...</span>
      </template>
    </USelectMenu>
  </div>
</template>

<script setup lang="ts">
import { computed, type Ref, ref, watch } from 'vue';

const props = defineProps<{
  selectedItems: string[];
  items: Record<string, unknown>[];
  valueKey: string;
  labelKey: string;
  placeholder?: string;
  onSelected: (items: string[]) => void;
}>();

const searchQuery = ref('');
const selections: Ref<string[]> = ref(props.selectedItems || []);

const filteredItems: Ref<Record<string, unknown>[]> = computed(() => {
  const selectedIds = new Set(selections.value);
  const selectedItems = props.items.filter((item) =>
    selectedIds.has(item[props.valueKey] as string),
  );
  const remainingItems = props.items.filter(
    (item) =>
      !selectedIds.has(item[props.valueKey] as string) &&
      (item[props.labelKey] as string)
        .toLowerCase()
        .includes(searchQuery.value.toLowerCase()),
  );

  // Keep every selection available so its label and remove action remain usable.
  return [...selectedItems, ...remainingItems.slice(0, 10)];
});

const handleSelectionChange = (items: string[]) => {
  searchQuery.value = '';
  props.onSelected(items);
};

watch(
  () => props.selectedItems,
  () => {
    selections.value = [...props.selectedItems];
  },
  { deep: true },
);
</script>
