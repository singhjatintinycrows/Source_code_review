<template>
  <div class="flex items-center gap-1.5" @click.stop>
    <UBadge v-for="ts in teamServices.slice(0, 2)" :key="ts.teamId || ts.team?.id || ts.team?.name"
      :color="showRoles && ts.role === 50 ? 'primary' : 'neutral'" variant="subtle">
      {{ ts.team?.name }}<span v-if="showRoles"> ({{ roleLabel(ts.role) }})</span>
    </UBadge>
    <UButton v-if="teamServices.length > 2" color="secondary" variant="link" size="sm"
      class="p-0 pl-1 hover:underline cursor-pointer" @click.stop="isTeamsModalOpen = true">
      + more
    </UButton>

    <!-- Teams Modal -->
    <UModal v-model:open="isTeamsModalOpen">
      <template #content>
        <UCard :ui="{ divide: 'divide-y divide-gray-100 dark:divide-gray-800' }">
          <template #header>
            <div class="flex items-center justify-between">
              <h3 class="text-base font-semibold leading-6 text-gray-900 dark:text-white flex items-center gap-2">
                <UIcon name="i-heroicons-users" class="w-5 h-5 text-secondary-500" />
                Teams of {{ serviceName }}
              </h3>
              <UButton color="neutral" variant="ghost" icon="i-heroicons-x-mark-20-solid" class="-my-1"
                @click="isTeamsModalOpen = false" />
            </div>
          </template>
          <div class="py-2 space-y-3">
            <div v-if="teamServices.length > 0" class="space-y-2 max-h-[300px] overflow-y-auto pr-1">
              <div v-for="ts in teamServices" :key="ts.teamId || ts.team?.id || ts.team?.name"
                class="flex items-center justify-between px-3 py-2 rounded-lg bg-gray-50 dark:bg-gray-900 border border-gray-100 dark:border-gray-800 font-medium text-sm text-gray-700 dark:text-gray-300">
                <div class="flex items-center gap-2.5">
                  <UIcon name="i-heroicons-user-group" class="w-4 h-4 text-gray-400" />
                  <span>{{ ts.team?.name }}</span>
                </div>
                <UBadge v-if="showRoles" :color="ts.role === 50 ? 'primary' : 'neutral'" variant="subtle" size="sm">
                  {{ roleLabel(ts.role) }}
                </UBadge>
              </div>
            </div>
            <div v-else class="text-center text-sm text-gray-500 py-4">
              No teams found for this service.
            </div>
          </div>
        </UCard>
      </template>
    </UModal>
  </div>
</template>

<script setup lang="ts">
import { ref } from 'vue';

interface Team {
  id?: string;
  name: string;
}

interface TeamService {
  teamId?: string;
  role: number;
  team?: Team;
}

withDefaults(
  defineProps<{
    teamServices: TeamService[];
    serviceName: string;
    showRoles?: boolean;
  }>(),
  {
    showRoles: false,
  },
);

const isTeamsModalOpen = ref(false);

const roleLabel = (role: number) => {
  if (role >= 50) return 'Manager';
  if (role >= 30) return 'Editor';
  return 'Viewer';
};
</script>
