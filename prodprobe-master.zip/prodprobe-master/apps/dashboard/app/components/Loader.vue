<template>
  <div
    v-if="loading"
    class="absolute inset-0 bg-white/50 dark:bg-gray-950/50 flex flex-col items-center justify-center z-40 backdrop-blur-[1px] rounded-lg"
  >
    <UIcon name="i-heroicons-arrow-path" class="animate-spin text-primary-500 mb-4" :class="size" />
    <p v-if="label" class="text-lg font-semibold text-gray-700 dark:text-gray-300">{{ label }}</p>
  </div>
</template>

<script setup lang="ts">
withDefaults(
  defineProps<{
    loading: boolean;
    label?: string;
    size?: string;
  }>(),
  {
    label: 'Loading...',
    size: 'text-5xl',
  },
);
</script>
