<template>
  <UButton size="xs" color="secondary" variant="ghost" icon="i-heroicons-clipboard-document"
    @click.stop="copyToClipboard" :title="`Copy ${title}`" :aria-label="`Copy ${title}`"
    class="opacity-0 group-hover:opacity-100 focus-visible:opacity-100 transition-opacity duration-150 flex-shrink-0" />
</template>

<script setup lang="ts">
import { useClipboard } from '@vueuse/core';
import { useAppToast } from '../composables/useAppToast';

const toast = useAppToast();
const props = defineProps<{
  text: string;
  title: string;
}>();

const { copy } = useClipboard();

const copyToClipboard = async () => {
  try {
    await copy(props.text);
    toast.showSuccess(`${props.title} copied to clipboard!`);
  } catch (err) {
    console.error('Failed to copy text: ', err);
    toast.showError(`Failed to copy ${props.title}.`);
  }
};
</script>
