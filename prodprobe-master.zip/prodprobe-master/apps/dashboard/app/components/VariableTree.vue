<template>
  <div class="variable-tree">
    <div class="flex items-start">
      <!-- Toggle Icon -->
      <button v-if="isExpandable" type="button" @click="isOpen = !isOpen" :aria-expanded="isOpen"
        :aria-label="isOpen ? 'Collapse variable' : 'Expand variable'"
        class="cursor-pointer mr-1 text-gray-500 hover:text-gray-700 dark:hover:text-gray-300">
        <UIcon :name="isOpen ? 'i-heroicons-chevron-down' : 'i-heroicons-chevron-right'" class="w-4 h-4 translate-y-0.5"
          aria-hidden="true" />
      </button>
      <div v-else class="w-5 flex-shrink-0"></div> <!-- Spacer -->

      <!-- Content -->
      <div class="flex-1 min-w-0 flex items-baseline whitespace-nowrap overflow-hidden">
        <span class="text-blue-600 dark:text-blue-400 font-medium">{{ name }}</span>
        <span class="text-gray-400 mx-1">:</span>
        <span class="text-purple-600 dark:text-purple-400 text-xs">{{ displayType }}</span>
        <span v-if="refPath" class="text-gray-500 dark:text-gray-400 text-xs italic ml-1.5 opacity-80">[REF -> {{ refPath }}]</span>

        <template v-if="!(isOpen && isExpandable) && displayValue !== ''">
          <span class="text-gray-400 mx-1">=</span>
          <span class="truncate" :class="valueClass">{{ displayValue }}</span>
        </template>
      </div>
    </div>

    <!-- Children -->
    <div v-if="isOpen && isExpandable" class="ml-5 mt-1 border-l border-gray-200 dark:border-gray-800 pl-2">
      <VariableTree v-for="(val, key) in resolvedValue" :key="key" :name="key" :value="val" :ancestorPaths="nextAncestorPaths" />
    </div>
  </div>
</template>

<script setup lang="ts">
import { resolvePath } from '@hyperprobe/constants';
import { computed, inject, ref } from 'vue';

const props = defineProps({
  name: { type: [String, Number], required: true },
  value: { type: null, required: true },
  ancestorPaths: { type: Array as () => string[], default: () => [] },
});

const hitPayload = inject<any>('hitPayload', null);
const resolutionCache = inject<WeakMap<any, Map<string, any>> | null>(
  'resolutionCache',
  null,
);

const isOpen = ref(false);

function getResolvedPath(payload: any, path: string): any {
  if (!payload || typeof payload !== 'object') return undefined;

  const cache = resolutionCache;
  if (cache) {
    let payloadCache = cache.get(payload);
    if (!payloadCache) {
      payloadCache = new Map<string, any>();
      cache.set(payload, payloadCache);
    }
    if (payloadCache.has(path)) {
      return payloadCache.get(path);
    }
    const resolved = resolvePath(payload, path);
    payloadCache.set(path, resolved);
    return resolved;
  }
  return resolvePath(payload, path);
}

// Compute if this node is a reference string
const refPath = computed(() => {
  if (typeof props.value === 'string') {
    const match = props.value.match(/^\[REF - (.+)\]$/);
    if (match) {
      return match[1];
    }
  }
  return null;
});

// Resolve reference with cycle/loop protection
const resolvedValueResult = computed(() => {
  if (!refPath.value) {
    return { value: props.value, resolved: false };
  }

  if (props.ancestorPaths.includes(refPath.value)) {
    return { value: props.value, resolved: false, cyclic: true };
  }

  const resolved = getResolvedPath(hitPayload?.value, refPath.value);
  if (resolved !== undefined) {
    return { value: resolved, resolved: true };
  }

  return { value: props.value, resolved: false };
});

const resolvedValue = computed(() => resolvedValueResult.value.value);

const nextAncestorPaths = computed(() => {
  if (refPath.value) {
    return [...props.ancestorPaths, refPath.value];
  }
  return props.ancestorPaths;
});

const isExpandable = computed(() => {
  return (
    typeof resolvedValue.value === 'object' &&
    resolvedValue.value !== null &&
    Object.keys(resolvedValue.value).length > 0
  );
});

const displayType = computed(() => {
  if (resolvedValue.value === undefined) return 'undefined';
  if (resolvedValue.value === null) return 'object';
  if (Array.isArray(resolvedValue.value))
    return `Array[${resolvedValue.value.length}]`;
  if (typeof resolvedValue.value === 'object') return 'Object';
  return typeof resolvedValue.value;
});

const displayValue = computed(() => {
  if (resolvedValue.value === undefined) return 'undefined';
  if (resolvedValue.value === null) return 'null';
  if (typeof resolvedValue.value === 'string')
    return `"${resolvedValue.value}"`;
  if (
    typeof resolvedValue.value === 'number' ||
    typeof resolvedValue.value === 'boolean'
  )
    return String(resolvedValue.value);
  if (typeof resolvedValue.value === 'object') {
    try {
      let str = JSON.stringify(resolvedValue.value);
      if (str.length > 50) return `${str.substring(0, 47)}...`;
      return str;
    } catch (e) {
      return Array.isArray(resolvedValue.value) ? 'Array' : 'Object';
    }
  }
  return String(resolvedValue.value);
});

const valueClass = computed(() => {
  if (resolvedValue.value === undefined || resolvedValue.value === null)
    return 'text-gray-500';
  if (typeof resolvedValue.value === 'string')
    return 'text-green-600 dark:text-green-400';
  if (typeof resolvedValue.value === 'number')
    return 'text-orange-600 dark:text-orange-400';
  if (typeof resolvedValue.value === 'boolean')
    return 'text-red-600 dark:text-red-400';
  return 'text-gray-600 dark:text-gray-300';
});
</script>
