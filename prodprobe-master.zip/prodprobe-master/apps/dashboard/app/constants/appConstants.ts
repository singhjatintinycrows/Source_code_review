const PROBE_TAG_KEY_TO_LABEL: Record<string, string> = {
  env: 'Environment',
  environment: 'Environment',
  commit: 'Commit',
  commitSha: 'Commit',
  serviceId: 'Service Id',
  serviceName: 'Service Name',
};

const AGENT_TAG_KEY_TO_LABEL: Record<string, string> = {
  ...PROBE_TAG_KEY_TO_LABEL,
  sdk: 'SDK Version',
  version: 'SDK Version',
  sdkVersion: 'SDK Version',
};

const TAG_KEY_TO_LABEL = PROBE_TAG_KEY_TO_LABEL;

export { AGENT_TAG_KEY_TO_LABEL, PROBE_TAG_KEY_TO_LABEL, TAG_KEY_TO_LABEL };
