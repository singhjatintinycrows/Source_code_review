import type { RouterConfig } from '@nuxt/schema';
import { createWebHashHistory } from 'vue-router';

export default (<RouterConfig>{
  // Omit passing the base explicitly to prevent duplicate '#' on refreshes
  history: () => createWebHashHistory(),
});
