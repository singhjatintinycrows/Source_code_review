<script setup lang="ts">
import { onBeforeUnmount } from 'vue';
import { useNuxtApp } from '#app';
import { observeAuthSession } from './composables/useAuth';

const stopAuthObserver = observeAuthSession(useNuxtApp().$trpc);
onBeforeUnmount(stopAuthObserver);
</script>

<template>
  <UApp>
    <NuxtLayout>
      <NuxtPage />
    </NuxtLayout>
  </UApp>
</template>
