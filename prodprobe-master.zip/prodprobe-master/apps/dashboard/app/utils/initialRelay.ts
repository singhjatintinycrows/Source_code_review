import { captureAuthCredentials } from '../composables/useAuth';
import { CancelledOperationError, isCancelledOperation } from './operation';

type InitialRelayInput = {
  jwt: string;
  nextToken: string;
  initialFrom: string;
  publicKey?: string;
  preparedFrom?: never;
};

export async function submitInitialRelay<T>(
  submit: (input: InitialRelayInput) => Promise<T>,
  input: InitialRelayInput,
  assertCurrent: () => void,
): Promise<T> {
  const session = captureAuthCredentials();
  while (true) {
    assertCurrent();
    if (!session.isCurrent()) throw new CancelledOperationError();
    const attempt = captureAuthCredentials();
    if (!attempt.isAuthenticated) throw new CancelledOperationError();

    let result: T;
    try {
      result = await submit(input);
    } catch (error) {
      // Only a new credential generation can make a cancelled submission progress.
      if (
        !isCancelledOperation(error) ||
        !session.isCurrent() ||
        attempt.isUnchanged()
      )
        throw error;
      continue;
    }

    assertCurrent();
    if (!session.isCurrent()) throw new CancelledOperationError();
    return result;
  }
}
