export function normalizeToken(value: string | null | undefined): string {
  const token = value?.trim() ?? '';
  if (!token.startsWith('"')) return token;
  try {
    const parsed = JSON.parse(token);
    return typeof parsed === 'string' ? parsed.trim() : '';
  } catch {
    return '';
  }
}

export function decodeJwtPayload(token: string): any {
  const base64Url = normalizeToken(token).split('.')[1];
  if (!base64Url) {
    throw new Error('Invalid token format');
  }
  // Convert URL-safe Base64URL characters to standard Base64 for atob()
  const base64 = base64Url.replace(/-/g, '+').replace(/_/g, '/');
  const pad = base64.length % 4;
  const padded = pad ? base64 + '='.repeat(4 - pad) : base64;
  const bytes = Uint8Array.from(atob(padded), (character) =>
    character.charCodeAt(0),
  );
  return JSON.parse(new TextDecoder().decode(bytes));
}

export function isTokenExpired(token: string): boolean {
  try {
    const payload = decodeJwtPayload(token);
    if (!payload || !Number.isFinite(payload.exp)) {
      return true;
    }
    return payload.exp * 1000 <= Date.now();
  } catch {
    return true;
  }
}

export function isTokenExpiringSoon(token: string, bufferMinutes = 1): boolean {
  try {
    const payload = decodeJwtPayload(token);
    if (!payload || !Number.isFinite(payload.exp)) {
      return true;
    }
    const exp = payload.exp; // seconds
    const now = Math.floor(Date.now() / 1000);
    const buffer = bufferMinutes * 60;
    return exp - now <= buffer;
  } catch {
    return true;
  }
}
