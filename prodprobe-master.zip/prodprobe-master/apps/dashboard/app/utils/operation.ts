export class CancelledOperationError extends Error {
  constructor() {
    super('Operation superseded by a newer session or license state');
    this.name = 'CancelledOperationError';
  }
}

export function isCancelledOperation(error: unknown): boolean {
  return (
    error instanceof CancelledOperationError ||
    (error instanceof Error && error.cause instanceof CancelledOperationError)
  );
}
