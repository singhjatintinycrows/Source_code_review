import fs from 'node:fs';
import path from 'node:path';

const pkg = JSON.parse(
  fs.readFileSync(path.resolve(process.cwd(), '../../package.json'), 'utf-8'),
);

// https://nuxt.com/docs/api/configuration/nuxt-config
// biome-ignore lint/correctness/noUndeclaredVariables: exported for nuxt
export default defineNuxtConfig({
  runtimeConfig: {
    public: {
      trpcUrl: process.env.BACKEND_URL || '/trpc',
      ssoUrl: process.env.SSO_URL || 'https://sso.public.hypertest.co',
      platformVersion: pkg.version,
      licenseServerUrl:
        process.env.LICENSING_SERVER_URL || 'https://licensing.hyperprobe.co',
    },
  },
  compatibilityDate: '2024-11-01',
  future: {
    compatibilityVersion: 4,
  },
  modules: ['@nuxt/ui', '@pinia/nuxt'],
  css: ['~/assets/css/main.css'],
  app: {
    baseURL: '/dashboard/',
    head: {
      link: [{ rel: 'icon', type: 'image/x-icon', href: 'favicon.ico' }],
    },
  },
  ssr: false, // SPA mode
  devServer: {
    port: Number(process.env.DASHBOARD_PORT) || 8569,
  },
  colorMode: {
    preference: 'light',
  },
  sourcemap: {
    server: true,
    client: true,
  },
  router: {
    options: {
      hashMode: true,
    },
  },
  vite: {
    server: {
      hmr: {
        clientPort: Number(process.env.DASHBOARD_PORT) || 8569,
      },
    },
    optimizeDeps: {
      include: ['@trpc/client', 'superjson'],
    },
  },
});
