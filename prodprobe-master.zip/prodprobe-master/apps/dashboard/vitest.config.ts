import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { defineConfig } from 'vitest/config';

const dirname = path.dirname(fileURLToPath(import.meta.url));

export default defineConfig({
  resolve: {
    alias: {
      '#app': path.resolve(dirname, 'test/nuxt-app.ts'),
    },
  },
  test: {
    environment: 'node',
  },
});
