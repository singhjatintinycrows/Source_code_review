import {
  getConfig,
  getConsul,
  getLogger,
  resolvePathWithOverlap,
  watchLogLevel,
} from '@hyperprobe/common';
import {
  NATS_TELEMETRY_STREAM,
  NATS_TELEMETRY_SUBJECT,
} from '@hyperprobe/constants';
import {
  ProbeType as DbProbeType,
  getDatabase,
  initDatabase,
  ProbeStatus,
} from '@hyperprobe/database';
import { TelemetryBatch } from '@hyperprobe/protos';
import { SourceMapConsumer } from '@jridgewell/source-map';
import { LRUCache } from 'lru-cache';
import { AckPolicy, connect } from 'nats';
import path from 'path';
import { createClient } from 'redis';

const REDIS_KEY_PREFIX = 'probe';
const getHitKey = (id: string) => `${REDIS_KEY_PREFIX}:hits:${id}`;
const getLimitKey = (id: string) => `${REDIS_KEY_PREFIX}:limit:${id}`;
const _getRetiredKey = (id: string) => `${REDIS_KEY_PREFIX}:retired:${id}`;

let redisClient: any;

function sanitizePayloadKeys(obj: any): any {
  if (obj === null || typeof obj !== 'object') {
    return obj;
  }

  if (Array.isArray(obj)) {
    return obj.map(sanitizePayloadKeys);
  }

  const sanitized: any = {};
  for (const key of Object.keys(obj)) {
    let newKey = key;
    if (key === 'constructor' || key === '__proto__' || key === 'prototype') {
      newKey = `<${key}>`;
    }
    sanitized[newKey] = sanitizePayloadKeys(obj[key]);
  }
  return sanitized;
}

async function start() {
  const config = await getConfig();
  initDatabase(config.databaseUrl);
  const logger = getLogger();
  watchLogLevel(getConsul());

  const natsUrl = config.natsUrl;
  let nc: unknown;

  redisClient = createClient({ url: config.redisUrl });
  redisClient.on('error', (err: any) =>
    logger.error({ err }, 'Redis Client Error'),
  );
  await redisClient.connect();
  logger.info('Connected to Redis');

  // Exponential backoff for connection
  for (let i = 0; i < 10; i++) {
    try {
      nc = await connect({ servers: natsUrl });
      break;
    } catch (err) {
      if (i === 9) throw err;
      logger.warn(`Failed to connect to NATS, retrying in ${2 ** i}ms...`);
      await new Promise((r) => setTimeout(r, 2 ** i));
    }
  }
  if (!nc) return;

  const js = nc.jetstream();
  const jm = await nc.jetstreamManager();

  logger.info('Logger Consumer starting...');

  // 1. Ensure Stream exists
  let streamInfo: unknown;
  for (let i = 0; i < 20; i++) {
    try {
      streamInfo = await jm.streams.info(NATS_TELEMETRY_STREAM);
      break;
    } catch (err: any) {
      if (err.message.includes('stream not found') || err.code === '404') {
        logger.warn('Stream not found, waiting for broker to create it...');
        await new Promise((r) => setTimeout(r, 1000));
        continue;
      }
      throw err;
    }
  }

  if (!streamInfo) {
    logger.error('Stream not found after retries. Exiting.');
    process.exit(1);
  }

  // 2. Get or Create Durable Consumer
  const durableName = 'logger_consumer';
  const desiredConfig = {
    durable_name: durableName,
    ack_policy: AckPolicy.Explicit,
    filter_subject: NATS_TELEMETRY_SUBJECT,
  };

  let consumerInfo: unknown;
  try {
    consumerInfo = await jm.consumers.info(NATS_TELEMETRY_STREAM, durableName);
  } catch (err: any) {
    if (err.message.includes('consumer not found') || err.code === '404') {
      consumerInfo = null;
    } else {
      throw err;
    }
  }

  if (!consumerInfo) {
    logger.info({ durableName }, 'Creating new durable consumer');
    await jm.consumers.add(NATS_TELEMETRY_STREAM, desiredConfig);
  } else {
    const isMatch =
      consumerInfo.config.ack_policy === desiredConfig.ack_policy &&
      consumerInfo.config.filter_subject === desiredConfig.filter_subject;

    if (isMatch) {
      logger.info(
        { durableName },
        'Durable consumer already exists with correct configuration',
      );
    } else {
      logger.info(
        { durableName },
        'Updating configuration for durable consumer (re-creating)',
      );
      // Delete and re-add to handle immutable field changes or clean slate
      await jm.consumers.delete(NATS_TELEMETRY_STREAM, durableName);
      await jm.consumers.add(NATS_TELEMETRY_STREAM, desiredConfig);
    }
  }

  // Get the Consumer object to start consuming
  const consumer = await js.consumers.get(NATS_TELEMETRY_STREAM, durableName);

  // 3. Consume messages with backpressure handling
  const messages = await consumer.consume({
    max_messages: 50,
  });

  (async () => {
    for await (const m of messages) {
      try {
        logger.debug('Received message from NATS');
        const batch = TelemetryBatch.decode(m.data);
        logger.info(
          { agentId: batch.agentId, eventCount: batch.events.length },
          'Decoded telemetry batch',
        );

        await processBatch(batch);

        m.ack();
        logger.debug('Processed and ACKed batch');
      } catch (err) {
        logger.error({ err }, 'Error processing message');
        // NAK allows the message to be retried by this or another replica
        m.nak();
      }
    }
  })();
}

const consumerCache = new LRUCache<string, SourceMapConsumer>({
  max: 500,
});

const sourceMapsCache = new LRUCache<
  string,
  { id: string; fileName: string }[]
>({
  max: 100,
});

async function getSourceMapsForCommit(
  prisma: any,
  serviceId: string,
  environment: string,
  commitSha: string,
) {
  const cacheKey = `${serviceId}_${environment}_${commitSha}`;
  let sms = sourceMapsCache.get(cacheKey);
  if (!sms) {
    sms = await prisma.sourceMap.findMany({
      where: { serviceId, environment, commitSha },
      select: { id: true, fileName: true },
    });
    sourceMapsCache.set(cacheKey, sms);
  }
  return sms;
}

async function resolveOriginalStackFrame(
  prisma: any,
  frame: any,
  serviceId: string,
  environment: string,
  commitSha: string,
  logger: any,
) {
  if (!frame.fileName) return frame;

  const sms = await getSourceMapsForCommit(
    prisma,
    serviceId,
    environment,
    commitSha,
  );

  let matchedSm = null;
  const frameFileNormalized = frame.fileName.replace(/\\/g, '/');

  for (const sm of sms || []) {
    let smRuntimeLoc = sm.fileName;
    if (smRuntimeLoc.endsWith('.map')) {
      smRuntimeLoc = smRuntimeLoc.slice(0, -4);
    }

    if (
      frameFileNormalized === smRuntimeLoc ||
      frameFileNormalized.endsWith(`/${smRuntimeLoc}`)
    ) {
      matchedSm = sm;
      break;
    }
  }

  if (!matchedSm) {
    logger.debug(
      { frameFileNormalized, sms: sms?.map((s) => s.fileName) },
      'No matched source map found for stack frame',
    );
    return frame;
  }

  let consumer = consumerCache.get(matchedSm.id);
  if (!consumer) {
    try {
      const fullSm = await prisma.sourceMap.findUnique({
        where: { id: matchedSm.id },
        select: { content: true },
      });
      if (!fullSm || !fullSm.content) {
        logger.debug(
          { matchedSmId: matchedSm.id },
          'Source map content not found in DB',
        );
        return frame;
      }
      consumer = new SourceMapConsumer(fullSm.content as any);
      consumerCache.set(matchedSm.id, consumer);
    } catch (err) {
      logger.error(
        { err, sourceMapId: matchedSm.id },
        'Failed to parse source map',
      );
      return frame;
    }
  }

  try {
    let pos: any = null;
    if (
      frame.columnNumber !== undefined &&
      frame.columnNumber !== null &&
      frame.columnNumber >= 0
    ) {
      pos = consumer.originalPositionFor({
        line: frame.lineNumber,
        column: frame.columnNumber,
      });
    }

    if (pos && pos.source && pos.line !== null) {
      const isMeteorApp = pos.source.startsWith('meteor://💻app/');
      let cleanPath = pos.source.replace(
        /^(webpack:\/\/(?:[^/]+\/)?|file:\/\/\/|meteor:\/\/(?:[^/]+\/)?)/,
        '',
      );
      cleanPath = cleanPath.split('?')[0];
      cleanPath = cleanPath.replace(/\\/g, '/');
      cleanPath = cleanPath.replace(/^\/+/, '');
      cleanPath = cleanPath.replace(/^\/+/, '');

      const sourceRoot = consumer.sourceRoot || '';
      const baseDir = path.posix.dirname(matchedSm.fileName);

      let resolvedPath = resolvePathWithOverlap(baseDir, cleanPath, sourceRoot);

      resolvedPath = path.posix.normalize(resolvedPath);
      if (resolvedPath.startsWith('./'))
        resolvedPath = resolvedPath.substring(2);
      resolvedPath = resolvedPath.replace(/^(\.\.\/)+/, '');

      if (isMeteorApp) {
        if (resolvedPath.startsWith('app/')) {
          resolvedPath = resolvedPath.substring(4);
        } else if (resolvedPath.includes('/app/')) {
          resolvedPath = resolvedPath.replace('/app/', '/');
        }
      }

      return {
        ...frame,
        fileName: resolvedPath,
        lineNumber: pos.line,
        columnNumber:
          typeof pos.column === 'number' ? pos.column : frame.columnNumber,
        functionName: pos.name || frame.functionName,
      };
    } else {
      logger.debug(
        { pos, frameLine: frame.lineNumber, frameCol: frame.columnNumber },
        'Source map pos failed or no source',
      );
    }
  } catch (err) {
    logger.debug({ err, frame }, 'Failed to map stack frame coordinate');
  }

  return frame;
}

async function processBatch(batch: TelemetryBatch) {
  const logger = getLogger();
  const prisma = getDatabase();
  const { agentId, events } = batch;
  if (!events || events.length === 0) return;

  const probeIds = [...new Set(events.map((e) => e.probeId))] as string[];
  const probes = await prisma.probe.findMany({
    where: { id: { in: probeIds } },
    include: { service: true },
  });
  const probeMap = new Map(probes.map((p) => [p.id, p]));

  const snapshotData: any[] = [];
  const logData: any[] = [];
  const metricData: any[] = [];
  const hitIncrements = new Map<string, number>();

  for (const event of events) {
    const probe = probeMap.get(event.probeId);
    if (!probe) {
      logger.warn(
        {
          probeId: event.probeId,
          agentId,
          foundProbeIds: Array.from(probeMap.keys()),
        },
        'Received telemetry for unknown probe.',
      );
      continue;
    }

    hitIncrements.set(
      event.probeId,
      (hitIncrements.get(event.probeId) || 0) + 1,
    );
    const capturedAt = new Date(Number(event.timestampMs));

    if (probe.type === DbProbeType.SNAPSHOT) {
      let vars = null;
      let watch = null;
      let captureError = event.captureError || '';

      try {
        if (event.capturedVarsJson)
          vars = sanitizePayloadKeys(JSON.parse(event.capturedVarsJson));
      } catch (e: any) {
        captureError = `[Parse Error (vars)]: ${e.message}${captureError ? `; ${captureError}` : ''}`;
      }

      try {
        if (event.watchResultsJson)
          watch = sanitizePayloadKeys(JSON.parse(event.watchResultsJson));
      } catch (e: any) {
        captureError = `[Parse Error (watch)]: ${e.message}${captureError ? `; ${captureError}` : ''}`;
      }

      let resolvedStackFrames = event.stackFrames;
      if (
        probe.service?.sourceMapRequired &&
        event.stackFrames &&
        event.stackFrames.length > 0
      ) {
        resolvedStackFrames = await Promise.all(
          event.stackFrames.map((frame) =>
            resolveOriginalStackFrame(
              prisma,
              frame,
              probe.serviceId,
              probe.environment,
              probe.commitSha,
              logger,
            ),
          ),
        );
      }

      snapshotData.push({
        probeId: event.probeId,
        serviceId: probe.serviceId,
        agentId,
        capturedAt,
        traceId: event.traceId || null,
        payload: {
          stack: resolvedStackFrames,
          vars,
          watch,
          error: captureError,
        },
      });
    } else if (probe.type === DbProbeType.LOG) {
      let message = event.evaluatedLog || '';
      if (event.captureError) {
        message = `[Error evaluating log template] ${event.captureError}`;
      }
      logData.push({
        probeId: event.probeId,
        serviceId: probe.serviceId,
        agentId,
        capturedAt,
        traceId: event.traceId || null,
        message,
      });
    } else if (
      probe.type === DbProbeType.COUNTER ||
      probe.type === DbProbeType.METRIC ||
      probe.type === DbProbeType.DURATION
    ) {
      metricData.push({
        probeId: event.probeId,
        serviceId: probe.serviceId,
        agentId,
        capturedAt,
        value: event.metricValue ?? 0,
        traceId: event.traceId || null,
      });
    }
  }

  await prisma.$transaction(async (tx) => {
    if (snapshotData.length > 0)
      await tx.snapshotEvent.createMany({ data: snapshotData });
    if (logData.length > 0) await tx.logEvent.createMany({ data: logData });
    if (metricData.length > 0)
      await tx.metricEvent.createMany({ data: metricData });

    // Check hit limits in Redis and update Postgres status to COMPLETED if reached.
    // We do this inside the consumer to ensure Postgres reflects the retired state eventually.
    const multi = redisClient.multi();
    for (const probeId of probeIds) {
      multi.get(getHitKey(probeId));
      multi.get(getLimitKey(probeId));
    }
    const redisRes = await multi.exec();

    const probesToComplete: { id: string; hitCount: number }[] = [];
    for (let i = 0; i < probeIds.length; i++) {
      const hits = parseInt((redisRes[i * 2] as string) || '0', 10);
      const limit = parseInt((redisRes[i * 2 + 1] as string) || '0', 10);

      if (limit > 0 && hits >= limit) {
        probesToComplete.push({ id: probeIds[i], hitCount: hits });
      }
    }

    if (probesToComplete.length > 0) {
      logger.info(
        { probesToComplete: probesToComplete.map((p) => p.id) },
        'Marking probes as COMPLETED in database',
      );
      await Promise.all(
        probesToComplete.map((probe) =>
          tx.probe.update({
            where: { id: probe.id },
            data: {
              status: ProbeStatus.COMPLETED,
              hitCount: probe.hitCount,
            },
          }),
        ),
      );
    }
  });
}

start().catch((err) => {
  const logger = getLogger();
  logger.error(err);
  process.exit(1);
});
