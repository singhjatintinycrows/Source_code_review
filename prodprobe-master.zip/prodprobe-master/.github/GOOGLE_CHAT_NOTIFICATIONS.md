# Google Chat merge and version notifications

`Google Chat Notifications` runs on every push to `master`. It uses the exact push
range, not the current branch tip. A standalone Node 22 script reads Git history
and GitHub PR metadata, asks Gemini for summaries, and posts to a Google Chat space.
No monorepo installation, build, server, or npm dependency is required.

## Configuration

In GitHub, open **Settings > Secrets and variables > Actions** and add repository
secrets (or organization secrets with access granted to this repository):

| Name | Value |
| --- | --- |
| `GOOGLE_CHAT_WEBHOOK_URL` | The complete incoming webhook URL from the destination Chat space |
| `GEMINI_API_KEY` | A Gemini API key from a company-approved project |

The workflow supplies `GITHUB_TOKEN` automatically, with read-only contents and PR
permissions. Do not create a personal access token for it.

The runner supports `TARGET_BRANCH` and defaults to `master`. This production
workflow explicitly sets it to `master` and restricts its event filters and
notification job to that branch. The sandbox branch and test package versions are
not part of this setup.

Optionally add a repository **variable**, `GEMINI_MODEL`, with a model ID supported
by your Gemini project and the `generateContent` structured-output API. The default
is `gemini-2.5-flash`. Model availability changes: if this model is unavailable,
choose a currently supported model in AI Studio and update the variable.

Enable GitHub Actions for the repository and allow `actions/checkout` and
`actions/setup-node`. Incoming webhooks must be enabled by your Workspace admin.
The Chat space can also be viewed from Gmail; this sends Chat messages, not email.

Never commit either secret or store it in source files. The workflow does not read
local credential files. Do not paste keys or webhook URLs into PR descriptions,
commit messages, or workflow inputs.

## Sender name and avatar

The sender name beside the **App** badge comes from the Google Chat incoming
webhook, not the GitHub user or the message payload. In the destination Chat space,
open **Apps & integrations** and edit the existing webhook's name to
`GitHub Notifications`. Its avatar can be configured there too; the **App** badge
remains. This GitHub logo URL can be used for the avatar:

```text
https://github.githubassets.com/images/modules/logos_page/GitHub-Mark.png
```

Renaming the existing webhook requires no code change. If your Chat interface
requires creating a replacement webhook instead, update `GOOGLE_CHAT_WEBHOOK_URL`
in GitHub Actions with the new URL. Never commit the webhook URL.

## Activation and preview

1. Merge the workflow, script, tests, and this guide into `master` through a PR.
2. That merge activates the workflow and can send the first real merge notification.
3. Open **Actions > Google Chat Notifications > Run workflow** and select `master`.
4. Leave **dry_run** checked. Set **after_sha** to a full master commit SHA and
   **before_sha** to the full SHA immediately before the range to preview. Blank
   values preview the latest master commit against its first parent.
5. Read the **Generate and deliver notifications** logs. Lines beginning
   `Preview (not posted):` contain JSON message bodies. This mode still reads GitHub
   and calls Gemini, but never calls the Chat webhook. Logs contain private PR
   metadata, so keep Actions log access appropriately restricted.
6. To test delivery, run again with the same range and **dry_run** unchecked. This
   posts real messages to the configured space. Expect duplicates if that range
   has already been delivered.

For a cumulative preview, choose an `after_sha` that changes the root version and
its first parent as `before_sha`. The script discovers the earlier version boundary
automatically; you do not need to supply it.

## Merge message

```text
feat/request-filtering merged into master

Title: Add filtering for captured requests
Authors: Alice, Bob

Summary:
Added request filtering and improved invalid-filter validation.

PR: https://github.com/owner/repo/pull/123
```

GitHub identifies the original PR/branch for merge commits, squash merges, and
rebase merges. Each PR is reported once per run, at its final integration commit.
Authors include the PR opener, every PR commit author, the integration commit author,
and `Co-authored-by` credits (including credits added only to the final squash commit),
including bots. GitHub logins and commit emails are used for deduplication; displayed
names prefer commit author names. People using unrelated identities may appear
more than once. Contributor collection uses paginated GraphQL, avoiding the REST
PR endpoint's 250-commit limit. Collection failures fail the run rather than claim
an incomplete author list is complete.

Direct pushes or local merges without an associated GitHub PR cannot reliably
recover a source branch, PR title, or all branch authors. They do not produce a
normal PR notification, but are listed as direct commits in cumulative messages.
Require PRs via branch protection if every change must have a branch notification.

## Version message

When root `package.json` changes version on master, a separate message includes:

- A bold **New Version Update** heading, not the version-bump branch's merge line.
- The previous and new versions.
- The target branch (`master`).
- A numbered feature list with PR titles, short descriptions, authors, and PR links.
- A short descriptive cumulative summary and a GitHub comparison link.

```text
New Version Update
Version: 1.2.27-3 -> 1.2.28
Branch: master

1. Request filtering: Add filtering for captured requests
Authors: Alice, Bob
https://github.com/owner/repo/pull/123

Descriptive summary:
Added request filtering and improved invalid-filter validation.

Compare: <GitHub comparison link>
```

The heading says "Update", not "Release", because changing the root version does
not confirm publishing or deployment. Ordinary merge-message headings are unchanged.

The range starts **after the commit introducing the preceding root version** and
ends **at the current version-change commit**, including the bump PR. Every value
change counts, including prereleases, downgrades, and returning to an older version.
Tags and publication status are not used. Unrelated manifest edits and transient
version edits inside normally merged feature branches do not reset the boundary.
Every version transition in a multi-commit push is processed separately.

For rebase merges, commits become individual entries on master's main history. If
a version changes halfway through a rebased PR, that version notification ends at
that exact commit. The not-yet-complete PR is represented by its direct commits,
not by features from later commits. The normal merge notification follows at the
PR's final integration commit. If that PR spans a version boundary, the following
version summarizes only its remaining commits and their authors, not the whole PR.

The initial version establishes a baseline without a cumulative notification.
Force-push/non-first-parent ranges are rejected rather than inventing a release
range. Initial branch creation is unsupported. A version change is **not proof
of successful publishing or deployment**.

## AI, security, and delivery

Gemini receives PR titles, descriptions (up to 12,000 characters), commit subjects
(up to 100), and changed-file names (up to 150), with an abbreviation indicator.
Raw source diffs are never sent. Approve the provider's data-handling terms for
private repository metadata before activation. Authors, branch names, versions,
and links come from GitHub/Git, not model output. Metadata is treated as untrusted
input, and model output is schema-checked, but AI descriptions can still be wrong.
Accurate PR descriptions are the best way to improve summary quality.

Large version summaries are synthesized in batches. The complete feature/author
list is retained even when the descriptive summary is condensed. Long messages
are split into numbered parts below Chat's message-size limit.

Missing Gemini credentials, unavailable models, quota errors, malformed responses,
or safety blocks fall back to factual PR titles and an explicit unavailable-summary
notice. Chat credential/delivery failures fail the Actions job. Requests retry
temporary network, rate-limit, and server failures with bounded backoff, and Chat
messages are spaced apart. Independent workflow runs may finish out of order.
No concurrency setting cancels an earlier push's notifications.

Delivery is **not exactly once**: retries, manual previews switched to live delivery,
or rerunning a partially completed job can duplicate messages. There is no durable
delivery ledger. Inspect the Chat space before rerunning a failed job, and use the
smallest appropriate manual SHA range. After fixing credentials or quota, rerun
the failed job or use manual dispatch; never paste a secret into the logs.

The notification job only executes code already on `master`; PR test jobs receive
no Chat or Gemini secrets. Branch protection/code review should cover these files.

## Local verification

```sh
node --check .github/scripts/google-chat-notifications.mjs
node --test .github/scripts/google-chat-notifications.test.mjs
```

Tests use temporary Git repositories and mocked HTTP responses. They need no keys,
do not contact GitHub/Gemini/Chat, and do not modify the working repository's history.

References: [Google Chat webhooks](https://developers.google.com/workspace/chat/quickstart/webhooks),
[Gemini structured output](https://ai.google.dev/gemini-api/docs/structured-output),
[GitHub commit-associated PRs](https://docs.github.com/en/rest/commits/commits#list-pull-requests-associated-with-a-commit).
