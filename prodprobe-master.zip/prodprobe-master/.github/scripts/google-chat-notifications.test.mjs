import assert from 'node:assert/strict';
import { execFileSync } from 'node:child_process';
import { mkdtempSync, rmSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import test from 'node:test';
import { runNotifications } from './google-chat-notifications.mjs';

function fixture(t) {
  const cwd = mkdtempSync(join(tmpdir(), 'chat-notifications-'));
  t.after(() => rmSync(cwd, { recursive: true, force: true }));
  const git = (...args) =>
    execFileSync('git', args, {
      cwd,
      encoding: 'utf8',
      stdio: ['ignore', 'pipe', 'pipe'],
      env: {
        ...process.env,
        GIT_AUTHOR_NAME: 'Alice',
        GIT_AUTHOR_EMAIL: 'alice@example.test',
        GIT_COMMITTER_NAME: 'Alice',
        GIT_COMMITTER_EMAIL: 'alice@example.test',
      },
    }).trim();
  git('init', '-b', 'master');
  function commit(title, version) {
    if (version)
      writeFileSync(join(cwd, 'package.json'), JSON.stringify({ version }));
    git('add', '.');
    git(
      '-c',
      'core.hooksPath=/dev/null',
      '-c',
      'commit.gpgsign=false',
      'commit',
      '--allow-empty',
      '-m',
      title,
    );
    return git('rev-parse', 'HEAD');
  }
  const baseline = commit('Initial version', '1.0.0');
  const prs = new Map();
  const requests = [];
  const messages = [];
  const logs = [];
  const warnings = [];
  function pr(sha, number, title = `Feature ${number}`) {
    const value = {
      number,
      title,
      body: 'Adds a documented feature.',
      merged_at: '2026-09-14T10:00:00Z',
      merge_commit_sha: sha,
      user: { login: 'alice' },
      base: { ref: 'master', repo: { full_name: 'acme/probe' } },
      head: { ref: `feat/${number}` },
      html_url: `https://github.com/acme/probe/pull/${number}`,
      changed_files: 1,
      commitsData: [
        {
          commit: {
            oid: sha,
            message: `${title}\n\nCo-authored-by: Bob <bob@example.test>`,
            author: {
              name: 'Alice',
              email: 'alice@example.test',
              user: { login: 'alice' },
            },
          },
        },
      ],
    };
    prs.set(sha, value);
    return value;
  }
  const fetchImpl = async (url, options = {}) => {
    const address = new URL(url);
    const body = options.body ? JSON.parse(options.body) : undefined;
    requests.push({ url: address, options, body });
    if (address.hostname === 'chat.googleapis.com') {
      messages.push(body.text);
      return Response.json({ name: 'spaces/test/messages/1' });
    }
    if (address.hostname === 'generativelanguage.googleapis.com') {
      return Response.json({
        candidates: [
          {
            finishReason: 'STOP',
            content: {
              parts: [
                {
                  text: JSON.stringify({
                    title: 'Improve request filtering',
                    summary: 'Added request filters and improved validation.',
                  }),
                },
              ],
            },
          },
        ],
      });
    }
    if (address.pathname === '/graphql') {
      const value = [...prs.values()].find(
        (item) => item.number === body.variables.number,
      );
      return Response.json({
        data: {
          repository: {
            pullRequest: {
              commits: {
                nodes: value.commitsData,
                totalCount: value.commitsData.length,
                pageInfo: { hasNextPage: false, endCursor: null },
              },
            },
          },
        },
      });
    }
    const associated = address.pathname.match(/\/commits\/([^/]+)\/pulls$/);
    if (associated)
      return Response.json(
        prs.has(associated[1]) ? [prs.get(associated[1])] : [],
      );
    const pull = address.pathname.match(/\/pulls\/(\d+)(\/files)?$/);
    if (pull) {
      const value = [...prs.values()].find(
        (item) => item.number === Number(pull[1]),
      );
      return Response.json(
        pull[2]
          ? [{ filename: 'src/filter.js', patch: 'DO NOT SEND SOURCE' }]
          : value,
      );
    }
    throw new Error(`Unexpected request: ${address.pathname}`);
  };
  const env = {
    GITHUB_REPOSITORY: 'acme/probe',
    GITHUB_TOKEN: 'github-secret',
    GEMINI_API_KEY: 'gemini-secret',
    GOOGLE_CHAT_WEBHOOK_URL:
      'https://chat.googleapis.com/v1/spaces/test/messages?key=secret&token=secret',
    GITHUB_EVENT_NAME: 'push',
    GITHUB_REF: 'refs/heads/master',
    DRY_RUN: 'false',
  };
  const run = (before, after, overrides = {}) =>
    runNotifications({
      cwd,
      env,
      event: { ref: 'refs/heads/master', before, after },
      fetchImpl,
      sleep: async () => {},
      log: (text) => logs.push(text),
      warn: (text) => warnings.push(text),
      ...overrides,
    });
  return {
    cwd,
    git,
    commit,
    baseline,
    pr,
    prs,
    requests,
    messages,
    logs,
    warnings,
    env,
    run,
    fetchImpl,
  };
}

test('a merged PR posts an AI summary with its branch and all credited authors', async (t) => {
  const f = fixture(t);
  const sha = f.commit('Add filtering');
  f.pr(sha, 1);
  await f.run(f.baseline, sha);
  assert.equal(f.messages.length, 1);
  assert.match(f.messages[0], /feat\/1 merged into master/);
  assert.match(f.messages[0], /Title: Improve request filtering/);
  assert.match(f.messages[0], /Authors: Alice, Bob/);
  assert.match(f.messages[0], /Summary:\nAdded request filters/);
  assert.match(f.messages[0], /https:\/\/github.com\/acme\/probe\/pull\/1/);
  const ai = f.requests.find(
    (request) => request.url.hostname === 'generativelanguage.googleapis.com',
  );
  assert.ok(ai);
  assert.doesNotMatch(
    JSON.stringify(ai.body),
    /DO NOT SEND SOURCE|github-secret|gemini-secret/,
  );
});

test('a version bump sends both messages and includes only PRs since the previous version boundary', async (t) => {
  const f = fixture(t);
  const excluded = f.commit('Previous release', '1.1.0-1');
  f.pr(excluded, 1);
  f.pr(f.commit('Add filters'), 2);
  // An unrelated manifest edit must not reset the version boundary.
  writeFileSync(
    join(f.cwd, 'package.json'),
    JSON.stringify({ version: '1.1.0-1', private: true }),
  );
  f.pr(f.commit('Update package metadata'), 3);
  const before = f.git('rev-parse', 'HEAD');
  const bump = f.commit('Next version', '1.1.0-2');
  f.pr(bump, 4);
  await f.run(before, bump);
  assert.equal(f.messages.length, 2);
  assert.match(f.messages[0], /feat\/4 merged into master/);
  const release = f.messages[1];
  assert.match(
    release,
    /^\*New Version Update\*\nVersion: 1\.1\.0-1 -> 1\.1\.0-2\nBranch: master/,
  );
  assert.doesNotMatch(release, /merged into/);
  assert.doesNotMatch(release, /\/pull\/1\b/);
  for (const number of [2, 3, 4])
    assert.match(release, new RegExp(`/pull/${number}\\b`));
  assert.match(release, /Descriptive summary:/);
  assert.match(release, new RegExp(`/compare/${excluded}\\.\\.\\.${bump}`));
});

test('branch and author underscores are preserved while Chat mentions are neutralized', async (t) => {
  const f = fixture(t);
  const sha = f.commit('Feature');
  const pr = f.pr(sha, 1);
  pr.head.ref = 'feat/filter_v2';
  pr.commitsData[0].commit.author.name = 'Alice_Smith <users/all>';
  await f.run(f.baseline, sha);
  assert.match(f.messages[0], /feat\/filter_v2 merged into master/);
  assert.match(f.messages[0], /Alice_Smith \(users\/all\)/);
  assert.doesNotMatch(f.messages[0], /<users\/all>/);
});

test('normal merges ignore temporary feature-branch versions', async (t) => {
  const f = fixture(t);
  f.git('switch', '-c', 'feature');
  f.commit('Temporary version', '9.0.0');
  f.commit('Restore version', '1.0.0');
  f.git('switch', 'master');
  f.git(
    '-c',
    'core.hooksPath=/dev/null',
    '-c',
    'commit.gpgsign=false',
    'merge',
    '--no-ff',
    'feature',
    '-m',
    'Merge feature',
  );
  const merged = f.git('rev-parse', 'HEAD');
  f.pr(merged, 1);
  const bump = f.commit('Release', '1.1.0');
  f.pr(bump, 2);
  await f.run(f.baseline, bump);
  assert.equal(f.messages.length, 3);
  assert.match(f.messages[2], /Version: 1\.0\.0 -> 1\.1\.0/);
  assert.match(f.messages[2], /\/pull\/1/);
  assert.doesNotMatch(f.messages.join('\n'), /9\.0\.0/);
});

test('rebase commits produce one PR notification and one feature entry', async (t) => {
  const f = fixture(t);
  const first = f.commit('Rebased first commit');
  const last = f.commit('Rebased second commit');
  const pr = f.pr(last, 1);
  f.prs.set(first, pr);
  const bump = f.commit('Release', '1.1.0');
  f.pr(bump, 2);
  await f.run(f.baseline, bump);
  assert.equal(f.messages.length, 3);
  assert.equal(
    f.messages.filter((message) => message.startsWith('feat/1 merged')).length,
    1,
  );
  assert.equal(f.messages[2].match(/\/pull\/1\b/g).length, 1);
  assert.doesNotMatch(f.messages[2], /Direct commit/);
});

test('every version transition in a push is reported, including a return to an older version', async (t) => {
  const f = fixture(t);
  const first = f.commit('Prerelease', '1.0.1-1');
  f.pr(first, 1);
  const last = f.commit('Rollback version', '1.0.0');
  f.pr(last, 2);
  await f.run(f.baseline, last);
  assert.equal(f.messages.length, 4);
  assert.match(f.messages[2], /Version: 1\.0\.0 -> 1\.0\.1-1/);
  assert.match(f.messages[3], /Version: 1\.0\.1-1 -> 1\.0\.0/);
  assert.doesNotMatch(f.messages[3], /\/pull\/1\b/);
});

test('unrelated manifest edits do not send a version notification', async (t) => {
  const f = fixture(t);
  writeFileSync(
    join(f.cwd, 'package.json'),
    JSON.stringify({ version: '1.0.0', private: true }),
  );
  const sha = f.commit('Change metadata');
  f.pr(sha, 1);
  await f.run(f.baseline, sha);
  assert.equal(f.messages.length, 1);
});

test('dry runs preview both messages without a webhook or any Chat request', async (t) => {
  const f = fixture(t);
  const sha = f.commit('Release', '1.1.0');
  f.pr(sha, 1);
  delete f.env.GOOGLE_CHAT_WEBHOOK_URL;
  delete f.env.DRY_RUN;
  await f.run(f.baseline, sha);
  assert.equal(f.messages.length, 0);
  assert.equal(f.logs.length, 2);
  assert.match(f.logs[1], /Version: 1\.0\.0 -> 1\.1\.0/);
  assert.ok(
    f.requests.some(
      (request) => request.url.hostname === 'generativelanguage.googleapis.com',
    ),
  );
});

test('Gemini failures use factual PR titles without leaking response bodies or credentials', async (t) => {
  const f = fixture(t);
  const sha = f.commit('Feature');
  f.pr(sha, 1, 'Add the request filter');
  await f.run(f.baseline, sha, {
    fetchImpl: async (url, options) => {
      if (String(url).includes('generativelanguage'))
        return Response.json({ error: 'gemini-secret' }, { status: 400 });
      return f.fetchImpl(url, options);
    },
  });
  assert.match(f.messages[0], /Title: Add the request filter/);
  assert.match(f.messages[0], /Detailed summary unavailable/);
  assert.equal(f.warnings.length, 1);
  assert.doesNotMatch(
    [...f.logs, ...f.warnings, ...f.messages].join('\n'),
    /gemini-secret|github-secret|token=secret/,
  );
});

test('malformed or truncated AI summaries fall back instead of inventing content', async (t) => {
  const f = fixture(t);
  const sha = f.commit('Feature');
  f.pr(sha, 1);
  await f.run(f.baseline, sha, {
    fetchImpl: async (url, options) => {
      if (String(url).includes('generativelanguage'))
        return Response.json({
          candidates: [
            {
              finishReason: 'MAX_TOKENS',
              content: { parts: [{ text: '{"title":"UNSAFE"}' }] },
            },
          ],
        });
      return f.fetchImpl(url, options);
    },
  });
  assert.match(f.messages[0], /Title: Feature 1/);
  assert.doesNotMatch(f.messages[0], /UNSAFE/);
});

test('Chat rate limits and server failures retry with backoff before succeeding', async (t) => {
  const f = fixture(t);
  const sha = f.commit('Feature');
  f.pr(sha, 1);
  const waits = [];
  let attempts = 0;
  await f.run(f.baseline, sha, {
    sleep: async (delay) => waits.push(delay),
    fetchImpl: async (url, options) => {
      if (String(url).includes('chat.googleapis.com')) {
        attempts++;
        if (attempts === 1)
          return Response.json(
            {},
            { status: 429, headers: { 'retry-after': '3' } },
          );
        if (attempts === 2) return Response.json({}, { status: 503 });
      }
      return f.fetchImpl(url, options);
    },
  });
  assert.equal(attempts, 3);
  assert.deepEqual(waits, [3000, 2000]);
  assert.equal(f.messages.length, 1);
});

test('Chat permanent errors fail delivery without exposing the webhook', async (t) => {
  const f = fixture(t);
  const sha = f.commit('Feature');
  f.pr(sha, 1);
  await assert.rejects(
    f.run(f.baseline, sha, {
      fetchImpl: async (url, options) => {
        if (String(url).includes('chat.googleapis.com'))
          return Response.json({ error: 'token=secret' }, { status: 403 });
        return f.fetchImpl(url, options);
      },
    }),
    /Google Chat request failed \(HTTP 403\)\./,
  );
  assert.equal(f.messages.length, 0);
});

test('all contributors are collected across more than 250 PR commits', async (t) => {
  const f = fixture(t);
  const sha = f.commit('Large branch');
  const pr = f.pr(sha, 1);
  pr.commitsData = Array.from({ length: 301 }, (_, index) => ({
    commit: {
      oid: String(index),
      message: 'Contribution',
      author: {
        name: `Contributor ${index}`,
        email: `${index}@example.test`,
        user: null,
      },
    },
  }));
  let pages = 0;
  await f.run(f.baseline, sha, {
    fetchImpl: async (url, options) => {
      if (new URL(url).pathname === '/graphql') {
        pages++;
        const offset = Number(JSON.parse(options.body).variables.cursor || 0);
        return Response.json({
          data: {
            repository: {
              pullRequest: {
                commits: {
                  nodes: pr.commitsData.slice(offset, offset + 100),
                  totalCount: 301,
                  pageInfo: {
                    hasNextPage: offset + 100 < 301,
                    endCursor: String(offset + 100),
                  },
                },
              },
            },
          },
        });
      }
      return f.fetchImpl(url, options);
    },
  });
  assert.equal(pages, 4);
  assert.match(f.messages.join('\n'), /Contributor 0,/);
  assert.match(f.messages.join('\n'), /Contributor 300/);
});

test('incomplete contributor data fails rather than sending an incomplete author list', async (t) => {
  const f = fixture(t);
  const sha = f.commit('Feature');
  f.pr(sha, 1);
  await assert.rejects(
    f.run(f.baseline, sha, {
      fetchImpl: async (url, options) => {
        if (new URL(url).pathname === '/graphql')
          return Response.json({ errors: [{ message: 'private details' }] });
        return f.fetchImpl(url, options);
      },
    }),
    /Unable to collect all PR contributors/,
  );
  assert.equal(f.messages.length, 0);
});

test('long messages split without omitting contributors and stay below the Chat JSON size limit', async (t) => {
  const f = fixture(t);
  const sha = f.commit('Large contributor list');
  const pr = f.pr(sha, 1);
  const names = Array.from({ length: 700 }, (_, index) =>
    `Contributor ${index} ${'Long name '.repeat(4)}`.trim(),
  );
  pr.commitsData[0].commit.message += names
    .map((name, index) => `\nCo-authored-by: ${name} <co${index}@example.test>`)
    .join('');
  await f.run(f.baseline, sha);
  assert.ok(f.messages.length > 1);
  for (const request of f.requests.filter(
    (item) => item.url.hostname === 'chat.googleapis.com',
  )) {
    assert.ok(Buffer.byteLength(request.options.body) < 32000);
  }
  const joined = f.messages
    .map((message) => message.replace(/^Part \d+\/\d+\n/, ''))
    .join('');
  for (const name of names) assert.ok(joined.includes(name), `Missing ${name}`);
});

test('direct commits remain visible in version summaries without inventing a source branch', async (t) => {
  const f = fixture(t);
  const change = f.commit('Fix timeout handling');
  const bump = f.commit('Update version', '1.1.0');
  await f.run(f.baseline, bump);
  assert.equal(f.messages.length, 1);
  assert.match(
    f.messages[0],
    /^\*New Version Update\*\nVersion: 1\.0\.0 -> 1\.1\.0\nBranch: master/,
  );
  assert.doesNotMatch(f.messages[0], /merged into|source branch unavailable/);
  assert.match(f.messages[0], /Fix timeout handling/);
  assert.match(f.messages[0], new RegExp(`/commit/${change}`));
});

test('unmerged and other-target PRs never produce a merge notification', async (t) => {
  const f = fixture(t);
  const first = f.commit('Unmerged association');
  f.pr(first, 1).merged_at = null;
  const last = f.commit('Other target');
  f.pr(last, 2).base.ref = 'develop';
  await f.run(f.baseline, last);
  assert.equal(f.messages.length, 0);
});

test('non-master events and deleted branches make no API requests', async (t) => {
  const f = fixture(t);
  await f.run(f.baseline, f.baseline, {
    env: { ...f.env, GITHUB_REF: 'refs/heads/feature' },
  });
  await f.run(f.baseline, f.baseline, { event: { deleted: true } });
  assert.equal(f.requests.length, 0);
});

test('non-first-parent and invalid SHA ranges fail before contacting external services', async (t) => {
  const f = fixture(t);
  f.git('switch', '-c', 'side');
  const side = f.commit('Side change');
  f.git('switch', 'master');
  const master = f.commit('Master change');
  await assert.rejects(f.run(side, master), /non-first-parent range/);
  await assert.rejects(f.run('--all', master), /before must be/);
  assert.equal(f.requests.length, 0);
});

test('manual dispatch rejects after SHAs outside the selected master history', async (t) => {
  const f = fixture(t);
  f.git('switch', '-c', 'unmerged');
  const side = f.commit('Unmerged version', '2.0.0');
  f.git('switch', 'master');
  await assert.rejects(
    f.run(f.baseline, side, {
      env: {
        ...f.env,
        GITHUB_EVENT_NAME: 'workflow_dispatch',
        GITHUB_SHA: f.baseline,
      },
    }),
    /after must belong to the selected master history/,
  );
  assert.equal(f.requests.length, 0);
});

test('credits added only to the final integration commit are included', async (t) => {
  const f = fixture(t);
  const sha = f.commit(
    'Squash feature\n\nCo-authored-by: Carol <carol@example.test>',
  );
  f.pr(sha, 1);
  await f.run(f.baseline, sha);
  assert.match(f.messages[0], /Authors: Alice, Bob, Carol/);
});

test('a rebased PR crossing a version boundary summarizes only remaining commits in the next version', async (t) => {
  const f = fixture(t);
  const middle = f.commit('EARLIER-CHANGE', '1.1.0');
  const last = f.commit('REMAINING-CHANGE');
  const pr = f.pr(last, 1, 'Spanning PR');
  pr.body = 'EARLIER-CHANGE and REMAINING-CHANGE';
  f.prs.set(middle, pr);
  const bump = f.commit('Next version', '1.2.0');
  f.pr(bump, 2);
  await f.run(middle, bump);
  const payloads = f.requests
    .filter(
      (request) => request.url.hostname === 'generativelanguage.googleapis.com',
    )
    .map((request) => JSON.parse(request.body.contents[0].parts[0].text));
  const partial = payloads.find(
    (payload) => payload.kind === 'PR commits after previous version',
  );
  assert.ok(partial, 'Expected a range-limited PR summary');
  assert.match(JSON.stringify(partial), /REMAINING-CHANGE/);
  assert.doesNotMatch(JSON.stringify(partial), /EARLIER-CHANGE/);
  assert.match(
    f.messages.at(-1),
    /Spanning PR \(commits after previous version\)/,
  );
});

test('cumulative Gemini input retains direct-commit subjects', async (t) => {
  const f = fixture(t);
  f.commit('Fix unique timeout bug');
  const bump = f.commit('Update version', '1.1.0');
  await f.run(f.baseline, bump);
  const ai = f.requests.find(
    (request) => request.url.hostname === 'generativelanguage.googleapis.com',
  );
  assert.match(JSON.stringify(ai.body), /Fix unique timeout bug/);
});

test('unreadable successful Chat responses report ambiguous delivery without exposing the body', async (t) => {
  const f = fixture(t);
  const sha = f.commit('Feature');
  f.pr(sha, 1);
  await assert.rejects(
    f.run(f.baseline, sha, {
      fetchImpl: async (url, options) => {
        if (String(url).includes('chat.googleapis.com'))
          return new Response('token=secret NOT JSON');
        return f.fetchImpl(url, options);
      },
    }),
    /^Error: Google Chat accepted the request but returned an unreadable response\. Check the space before rerunning\.$/,
  );
});

test('TARGET_BRANCH selects notifications-test for both merge and version notifications', async (t) => {
  const f = fixture(t);
  f.env.TARGET_BRANCH = 'notifications-test';
  f.env.GITHUB_REF = 'refs/heads/notifications-test';
  const sha = f.commit('Release', '1.1.0');
  f.pr(sha, 1).base.ref = 'notifications-test';
  await f.run(f.baseline, sha, {
    event: {
      ref: 'refs/heads/notifications-test',
      before: f.baseline,
      after: sha,
    },
  });
  assert.equal(f.messages.length, 2);
  assert.match(
    f.messages[0],
    /^feat\/1 merged into notifications-test\n\nTitle:/,
  );
  assert.match(
    f.messages[1],
    /^\*New Version Update\*\nVersion: 1\.0\.0 -> 1\.1\.0\nBranch: notifications-test/,
  );
  assert.doesNotMatch(f.messages[1], /merged into/);
  assert.match(
    f.messages[1],
    /This is a version change on notifications-test, not confirmation of publication\./,
  );
  for (const message of f.messages) assert.doesNotMatch(message, /master/);
});
