# HyperProbe Release Workflow

The workflow runs a manually triggered, single-job production build and publish
on the existing self-hosted runner. Pushes and merges do not start a release.

## Runtime

- Runner label: `github-self-hosted-amd-runner`
- Job container: `debian:trixie-slim`
- Docker service: `docker:29.1.1-dind-alpine3.22` in privileged mode
- Trigger: manual dispatch with a branch selector

The workflow checks out the selected branch with full Git history. Its root
`package.json` version is used automatically. Stable versions can only be
published from `master`; other branches must publish a prerelease such as
`1.2.27-1`.

Every manual run uses `SHOULD_PUBLISH=yes` and attempts a real production
release. There is no workflow dry-run input or reviewer approval gate.
The workflow does not upload downloadable GitHub Actions artifacts or create
a GitHub Release page. Ruby release builds remain disabled in `build.sh`.

Local builds and CI use pnpm 10.30.3. `build.sh` installs dependencies with
`--frozen-lockfile` before the publishing preflight, then runs the pinned
`@vscode/vsce` and `ovsx` tools with `pnpm exec`. The workspace explicitly
disables `keytar`'s native install script to avoid build-approval prompts.
VSIX packaging does not need a desktop keychain; Open VSX publishing uses
`OVSX_PAT` rather than interactive login.

## Required GitHub Actions secrets

Configure these as repository or organization Actions secrets:

| Secret | Purpose |
| --- | --- |
| `AWS_ACCESS_KEY_ID` | AWS ECR Public and S3 access |
| `AWS_SECRET_ACCESS_KEY` | AWS secret key |
| `NPM_TOKEN` | Publish Node SDK and MCP Server |
| `PYPI_API_TOKEN` | Publish `hyperprobe-agent` |
| `SONATYPE_USERNAME` | Maven Central token username |
| `SONATYPE_PASSWORD` | Maven Central token password |
| `MAVEN_GPG_PRIVATE_KEY` | ASCII-armored Java signing private key |
| `MAVEN_GPG_PASSPHRASE` | Java signing key passphrase |
| `OVSX_PAT` | Open VSX publishing token |

`GITHUB_TOKEN` is generated automatically and is used by `build.sh` to push the
final Git tag. The workflow grants it `contents: write`.

## Release flow

1. Select the release branch in **Use workflow from**.
2. Click **Run workflow** for a real production release.
3. The workflow installs Node, pnpm, Python, Java, Maven, AWS CLI, GPG, and build
   tools in the Debian job container.
4. AWS credentials and package registry/signing configuration are prepared.
5. `SHOULD_PUBLISH=yes bash build.sh` performs the complete build and publish.

`build.sh` builds and validates the workspace, packages the Node/Python/Java
SDKs, builds the Docker image and VSIX, checks the remote Git tag, and publishes
NPM, PyPI, Maven Central, ECR Public, S3, and Open VSX. It creates the Git tag
before publishing and runs its existing rollback logic if a later step fails.

The AWS identity therefore needs ECR Public describe/push/delete permissions and
S3 bucket read/upload/delete permissions for `hyperprobe-assets/vsc-plugin/`.

Stable NPM versions use `latest`; prereleases use `next`.

## Before the first release

- Merge the workflow into the default branch to make manual dispatch available.
  The selected release branch must also contain the workflow and release tools.
- Use a version not already published in the registries or tagged remotely.
- Confirm the self-hosted runner and all release credentials are configured.
- Confirm the Docker builder supports both `linux/amd64` and `linux/arm64`;
  native-only dry runs do not verify multi-platform builds.
- A successful dry run does not verify signing or publishing permissions.
  PyPI and Maven Central uploads cannot be automatically rolled back; inspect
  each registry before retrying a partially failed release.
