#!/bin/bash
set -e
export HP_BUILD_MODE="yes"

ROOT_DIR="$(pwd)"

TAG_CREATED=0
NPM_PUBLISHED=0
MCP_PUBLISHED=0
PYTHON_PUBLISHED=0
JAVA_PUBLISHED=0
RUBY_PUBLISHED=0
RUBY_RELEASE_FILES_TOUCHED=0
DOCKER_PUBLISHED=0
S3_UPLOADED=0

# Define variables that will be used in rollback
VERSION=""
MAVEN_SETTINGS_ARGS=()
OVSX_PAT_FILE="${OVSX_PAT_FILE:-${HOME}/.config/hyperprobe-openvsx-pat}"
OVSX_PAT_VALUE=""

fail() {
  echo "Error: $*" >&2
  exit 1
}

require_command() {
  command -v "$1" >/dev/null 2>&1 || fail "Required command '$1' was not found."
}

verify_ruby_build_prerequisites() {
  echo "[preflight] Verifying both Ruby release toolchains..."
  require_command ruby
  require_command gem
  require_command bundle
  require_command mvn
  require_command java
  require_command javac
  require_command "${HYPERPROBE_JRUBY:-jruby}"

  ruby -e 'exit(RUBY_ENGINE == "ruby" && Gem::Version.new(RUBY_VERSION) >= Gem::Version.new("3.0") ? 0 : 1)' >/dev/null 2>&1 || \
    fail "Ruby releases require MRI 3.0+ as the default ruby interpreter."
  "${HYPERPROBE_JRUBY:-jruby}" --debug -e '
    abort unless defined?(JRUBY_VERSION) && Gem::Version.new(JRUBY_VERSION) >= Gem::Version.new("9.4")
    require "java"
    abort unless java.lang.System.getProperty("java.specification.version").to_i >= 11
    require "rspec"
    require "google/protobuf"
    require "binding_of_caller"
  ' >/dev/null 2>&1 || \
    fail "Ruby releases require JRuby 9.4+ on Java 11+ with rspec, google-protobuf and binding_of_caller installed."
}

configure_maven_settings() {
  MAVEN_SETTINGS_ARGS=()
  if [ -f "$ROOT_DIR/maven-settings.xml" ]; then
    echo "Using root maven-settings.xml for Maven credentials."
    MAVEN_SETTINGS_ARGS=(-s "$ROOT_DIR/maven-settings.xml")
  fi
}

verify_pypi_configuration() {
  local twine_config="${TWINE_CONFIG_FILE:-}"
  local pypi_token="${PYPI_API_TOKEN:-}"
  local twine_token="${TWINE_PASSWORD:-}"

  if [ -n "$twine_config" ]; then
    [ -r "$twine_config" ] || fail "TWINE_CONFIG_FILE is not readable: $twine_config"
    return
  fi

  if [ -r "$ROOT_DIR/.pypirc" ] || [ -r "$ROOT_DIR/agents/python-sdk/.pypirc" ]; then
    return
  fi

  if [ -n "$pypi_token" ] && [ -n "$twine_token" ] && [ "$pypi_token" != "$twine_token" ]; then
    fail "PYPI_API_TOKEN and TWINE_PASSWORD are both set but do not match."
  fi

  local token="${pypi_token:-$twine_token}"
  [ -n "$token" ] || fail "Provide .pypirc, PYPI_API_TOKEN, or TWINE_PASSWORD for PyPI publishing."
  [[ "$token" == pypi-* ]] || fail "PyPI API tokens must start with 'pypi-'."
}

verify_rubygems_configuration() {
  local gem_key="${GEM_HOST_API_KEY:-${RUBYGEMS_API_KEY:-}}"
  local creds_file="${RUBYGEMS_CREDENTIALS_FILE:-}"

  if [ -n "$creds_file" ] && [ -r "$creds_file" ]; then
    return
  fi

  if [ -r "$ROOT_DIR/.gemcredentials" ] || [ -r "$ROOT_DIR/.gem/credentials" ] || \
     [ -r "$ROOT_DIR/agents/ruby-sdk/.gemcredentials" ] || [ -r "$ROOT_DIR/agents/ruby-sdk/.gem/credentials" ] || \
     [ -r "$HOME/.gem/credentials" ]; then
    return
  fi

  [ -n "$gem_key" ] || fail "Provide .gemcredentials, ~/.gem/credentials, GEM_HOST_API_KEY, or RUBYGEMS_API_KEY for RubyGems publishing."
}

resolve_ovsx_pat() {
  OVSX_PAT_VALUE="${OVSX_PAT:-}"
  if [ -z "$OVSX_PAT_VALUE" ]; then
    [ -r "$OVSX_PAT_FILE" ] || fail "Set OVSX_PAT or provide a readable token file at $OVSX_PAT_FILE."
    OVSX_PAT_VALUE="$(<"$OVSX_PAT_FILE")"
  fi

  [ -n "$OVSX_PAT_VALUE" ] || fail "Open VSX token is empty."
  unset OVSX_PAT
}

verify_publish_prerequisites() {
  echo "[preflight] Verifying publish tools, configuration, and connectivity..."

  require_command npm
  require_command pnpm
  require_command mvn
  require_command aws
  require_command docker
  # Ruby publishing is temporarily disabled.
  # require_command ruby
  # require_command gem
  # require_command bundle

  [ -r "$ROOT_DIR/.npmrc" ] || fail "NPM publishing requires a readable $ROOT_DIR/.npmrc."
  npm whoami --userconfig "$ROOT_DIR/.npmrc" >/dev/null || fail "NPM authentication failed."

  verify_pypi_configuration
  # RubyGems publishing is temporarily disabled.
  # verify_rubygems_configuration

  mvn -B -q help:effective-settings "${MAVEN_SETTINGS_ARGS[@]}" >/dev/null || \
    fail "Maven settings could not be loaded."

  aws sts get-caller-identity --no-cli-pager >/dev/null || fail "AWS authentication failed."
  aws ecr-public get-login-password --region us-east-1 --no-cli-pager >/dev/null || \
    fail "AWS ECR Public authentication failed."
  aws s3api head-bucket --bucket hyperprobe-assets --no-cli-pager || \
    fail "AWS cannot access the hyperprobe-assets bucket."

  docker version --format '{{.Server.Version}}' >/dev/null || fail "Docker daemon is unavailable."
  docker buildx version >/dev/null || fail "Docker Buildx is unavailable."

  resolve_ovsx_pat
  OVSX_PAT="$OVSX_PAT_VALUE" pnpm exec ovsx verify-pat hyperprobe >/dev/null || \
    fail "Open VSX authentication failed for namespace hyperprobe."

  echo "[preflight] Publish prerequisites verified."
}

cleanup_and_rollback() {
  local exit_code=$?
  set +e # Prevent errors during rollback from exiting trap immediately
  cd "$ROOT_DIR" # Guarantee we are in the root directory before running cleanup commands

  if [ $exit_code -ne 0 ]; then
    echo ""
    echo "====================================="
    echo "Build or publish failed with exit code $exit_code. Rolling back published artifacts..."
    echo "====================================="
    if [ "$SHOULD_PUBLISH" = "yes" ]; then
      if [ $NPM_PUBLISHED -eq 1 ] && [ -n "$VERSION" ]; then
        echo "Rolling back NPM publish..."
        npm unpublish @hyperprobe/node-sdk@$VERSION --force || echo "Failed to unpublish NPM package."
      fi
      if [ $MCP_PUBLISHED -eq 1 ] && [ -n "$VERSION" ]; then
        echo "Rolling back MCP server publish..."
        npm unpublish @hyperprobe/mcp-server@$VERSION --force || echo "Failed to unpublish MCP package."
      fi
      if [ $PYTHON_PUBLISHED -eq 1 ]; then
        echo "Notice: PyPI releases cannot be automatically deleted. Please yank $VERSION manually if needed."
      fi
      if [ $JAVA_PUBLISHED -eq 1 ]; then
        echo "Notice: Maven Central releases cannot be automatically deleted."
      fi
      if [ $RUBY_PUBLISHED -eq 1 ]; then
        echo "Notice: RubyGems releases cannot be automatically deleted. Please yank $VERSION manually if needed."
      fi
      if [ $TAG_CREATED -eq 1 ] && [ -n "$VERSION" ]; then
        echo "Rolling back Git tag..."
        git push --delete origin v$VERSION || echo "Failed to delete remote git tag."
        git tag -d v$VERSION || echo "Failed to delete local git tag."
      fi
      if [ $DOCKER_PUBLISHED -eq 1 ] && [ -n "$VERSION" ]; then
        echo "Attempting to rollback Docker image (if exists)..."
        aws ecr-public batch-delete-image --repository-name hyperprobe/platform --image-ids imageTag=$VERSION --region us-east-1 --no-cli-pager || true
      fi
      if [ $S3_UPLOADED -eq 1 ] && [ -n "$VERSION" ]; then
        echo "Rolling back S3 upload..."
        aws s3 rm s3://hyperprobe-assets/vsc-plugin/hyperprobe-extension-$VERSION.vsix || echo "Failed to delete S3 object."
      fi
    fi
  else
    echo ""
    echo "====================================="
    echo "Cleaning up temporary release versions..."
    echo "====================================="

    # Restore only the specific files that were temporarily modified during a successful build
    git restore packages/node-sdk/package.json || true
    git restore packages/mcp-server/package.json || true
    git restore agents/python-sdk/setup.py || true
    if [ "$RUBY_RELEASE_FILES_TOUCHED" -eq 1 ]; then
      git restore -- agents/ruby-sdk/lib/hyperprobe/version.rb agents/ruby-sdk/Gemfile.lock || true
    fi

    if [ -d "agents/java-sdk" ]; then
      find agents/java-sdk -name "pom.xml" -exec git restore {} + || true
    fi
  fi
  exit $exit_code
}

trap cleanup_and_rollback EXIT

echo "====================================="
echo "  hyperprobe Automated Build Script  "
echo "====================================="

# 1. Manage single version source of truth
VERSION=$(node -p "require('./package.json').version")
export VITE_EXTENSION_VERSION=$VERSION
echo "[1/6] Single source version: $VERSION"

if [ "$SHOULD_PUBLISH" = "yes" ]; then
  if git ls-remote --tags origin | grep -q "refs/tags/v$VERSION$"; then
    echo "Error: Tag v$VERSION already exists on remote. Aborting publish."
    exit 1
  fi
fi

# 2. Synchronize versions across all SDKs (Node.js, Python, Java, Ruby)
echo "[2/6] Synchronizing version $VERSION across all SDKs..."

# Cleanup restores temporary version files, so never start with user changes.
DIRTY_WORKTREE="$(git status --porcelain)"
if [ -n "$DIRTY_WORKTREE" ]; then
  echo "Error: release builds require a clean worktree:"
  echo "$DIRTY_WORKTREE"
  exit 1
fi

# Install locked release tools before the preflight invokes ovsx.
pnpm install --frozen-lockfile

configure_maven_settings
# Ruby build prerequisites are temporarily disabled.
# verify_ruby_build_prerequisites

if [ "$SHOULD_PUBLISH" = "yes" ]; then
  verify_publish_prerequisites
fi

# Validate the Python release version before modifying any manifests.
echo "Converting and validating Node version $VERSION to PEP-440 Python version..."
PYTHON_VERSION=$(python3 -c "
import sys
import re
try:
    from packaging.version import Version, InvalidVersion
except ImportError:
    print('Error: Python packaging library is required for validation.', file=sys.stderr)
    sys.exit(1)

raw_version = sys.argv[1]
pep_version = re.sub(r'-([a-zA-Z]*)\.?([0-9]*)', lambda m: (m.group(1) or 'beta') + (m.group(2) or ''), raw_version)

try:
    Version(pep_version)
    print(pep_version)
except InvalidVersion:
    print(f'Error: Could not convert {raw_version} to a valid PEP-440 version (tried {pep_version})', file=sys.stderr)
    sys.exit(1)
" "$VERSION") || {
    echo "Error: Python version conversion failed. Aborting publish."
    exit 1
}

echo "Converted Python version: $PYTHON_VERSION"

# Ruby version validation is temporarily disabled with the Ruby release.
# # Validate and convert the Ruby release version before modifying any manifests.
# echo "Converting and validating Node version $VERSION to RubyGems version..."
# RUBY_VERSION=$(ruby -e "
# raw_version = ARGV[0]
# unless Gem::Version.correct?(raw_version)
#   STDERR.puts \"Error: #{raw_version} is not a valid RubyGems version format.\"
#   exit 1
# end
# puts Gem::Version.new(raw_version).to_s
# " "$VERSION") || {
#     echo "Error: Ruby version conversion failed. Aborting publish."
#     exit 1
# }
#
# echo "Converted Ruby version: $RUBY_VERSION"

# Sync Node.js SDK & MCP Server
(cd packages/node-sdk && pnpm version "$VERSION" --no-git-tag-version --allow-same-version --no-git-checks)
(cd packages/mcp-server && pnpm version "$VERSION" --no-git-tag-version --allow-same-version --no-git-checks)

# Sync Python SDK (setup.py)
VERSION="$PYTHON_VERSION" node -e "
  const fs = require('fs');
  const path = 'agents/python-sdk/setup.py';
  let content = fs.readFileSync(path, 'utf8');
  content = content.replace(/version=\"[^\"]+\"/, 'version=\"' + process.env.VERSION + '\"');
  fs.writeFileSync(path, content);
"

# Sync Java SDK (Parent POM + submodules)
if command -v mvn >/dev/null 2>&1; then
  (cd agents/java-sdk && mvn versions:set -B -DnewVersion=$VERSION -DprocessAllModules=true -DgenerateBackupPoms=false)
else
  if [ "$SHOULD_PUBLISH" = "yes" ]; then
    echo "Error: 'mvn' CLI not found. Aborting publish to avoid partial cross-SDK release."
    exit 1
  fi
  echo "Warning: 'mvn' CLI not found. Skipping Java POM version update."
fi

# Ruby SDK version synchronization is temporarily disabled with the Ruby release.
# # Sync Ruby SDK (lib/hyperprobe/version.rb)
# RUBY_RELEASE_FILES_TOUCHED=1
# VERSION="$RUBY_VERSION" node -e "
#   const fs = require('fs');
#   const path = 'agents/ruby-sdk/lib/hyperprobe/version.rb';
#   let content = fs.readFileSync(path, 'utf8');
#   content = content.replace(/VERSION = '[^']+'/, 'VERSION = \'' + process.env.VERSION + '\'');
#   fs.writeFileSync(path, content);
# "

# 3. Build & Test Phase (No remote uploads)
echo "[3/6] Building workspace packages..."
pnpm build

echo "[3.1/6] Building & testing Node.js SDK and MCP Server..."
(cd packages/node-sdk && pnpm pack)
(cd packages/mcp-server && pnpm pack)

echo "[3.2/6] Building & validating Python SDK..."
(cd agents/python-sdk && bash publish_pypi.sh --dry-run)

if command -v mvn >/dev/null 2>&1; then
  echo "[3.3/6] Building & testing Java SDK..."
  (cd agents/java-sdk && mvn clean verify -B "${MAVEN_SETTINGS_ARGS[@]}" -Dgpg.skip=true)
fi

# Ruby SDK build and dry-run validation are temporarily disabled.
# echo "[3.4/6] Building & validating Ruby SDK..."
# # Bundler can print authenticated source URLs; keep install output out of release logs.
# (cd agents/ruby-sdk && bundle install >/dev/null 2>&1) || \
#   fail "Ruby bundle install failed. Check the SDK's Bundler configuration and dependencies locally; install output was suppressed to protect credentials."
# (cd agents/ruby-sdk && bash publish_rubygems.sh --dry-run)

echo "[3.5/6] Preparing deployment artifacts (Docker & VSCode Extension)..."

# Docker Platform
rm -rf deploy
mkdir -p deploy/backend ./deploy/logger ./deploy/logger-consumer
cp -r apps/backend/dist ./deploy/backend/
cp -r apps/logger/dist ./deploy/logger/
cp -r apps/logger-consumer/dist ./deploy/logger-consumer/
cp -r packages/database/bundle ./deploy/database

DOCKER_IMAGE_NAME="public.ecr.aws/hypertestco/hyperprobe/platform:$VERSION"
cp Dockerfile ./deploy/Dockerfile

cd deploy
if [ "$SHOULD_PUBLISH" = "yes" ]; then
  echo "Validating multi-platform Docker image via buildx..."

  if ! docker buildx ls | grep -q "hyperprobe"; then
    echo "Creating Docker Buildx builder: hyperprobe"
    docker buildx create --name hyperprobe --use
  else
    echo "Using existing Docker Buildx builder: hyperprobe"
    docker buildx use hyperprobe
  fi

  docker buildx build -f Dockerfile -t "$DOCKER_IMAGE_NAME" --platform linux/amd64,linux/arm64 .
  echo "Validated $DOCKER_IMAGE_NAME image"
else
  echo "Building Docker image locally..."
  docker build -f Dockerfile -t "$DOCKER_IMAGE_NAME" .
  echo "Built $DOCKER_IMAGE_NAME image locally"
fi
cd "$ROOT_DIR"

# VSCode Extension
echo "Packaging VSCode Extension..."
cd apps/vsc-extension
VSCE_PACKAGE_ARGS=(--no-git-tag-version --no-update-package-json --no-dependencies)
if [[ "$VERSION" == *"-"* ]]; then
  VSCE_PACKAGE_ARGS+=(--pre-release)
fi
pnpm exec vsce package "$VERSION" "${VSCE_PACKAGE_ARGS[@]}"
cd "$ROOT_DIR"
VSIX_PATH="apps/vsc-extension/hyperprobe-extension-$VERSION.vsix"
echo "VSCode Extension built: $VSIX_PATH"

# 4. Git Tagging (if SHOULD_PUBLISH="yes")
if [ "$SHOULD_PUBLISH" = "yes" ]; then
  echo "[4/6] Creating and pushing git tag v$VERSION..."
  git tag v$VERSION
  git push origin v$VERSION
  TAG_CREATED=1
else
  echo "[4/6] Skipping git tag creation (SHOULD_PUBLISH != yes)..."
fi

# 5. Publish Phase (Only when SHOULD_PUBLISH="yes")
NPM_TAG="latest"
if [[ "$VERSION" == *"-"* ]]; then
  NPM_TAG="next"
fi

if [ "$SHOULD_PUBLISH" = "yes" ]; then
  echo "[5/6] Publishing SDKs to package repositories..."

  # Publish Node SDK
  echo "Publishing Node SDK to NPM..."
  (cd packages/node-sdk && npm publish "hyperprobe-node-sdk-$VERSION.tgz" --userconfig "$ROOT_DIR/.npmrc" --no-git-checks --tag $NPM_TAG)
  NPM_PUBLISHED=1

  # Publish MCP Server
  echo "Publishing MCP Server to NPM..."
  (cd packages/mcp-server && npm publish "hyperprobe-mcp-server-$VERSION.tgz" --userconfig "$ROOT_DIR/.npmrc" --no-git-checks --tag $NPM_TAG)
  MCP_PUBLISHED=1

  # Publish Python SDK
  echo "Publishing Python SDK to PyPI..."
  (cd agents/python-sdk && bash publish_pypi.sh --yes)
  PYTHON_PUBLISHED=1

  # Publish Java SDK
  if command -v mvn >/dev/null 2>&1; then
    echo "Publishing Java SDK to Maven Central..."
    (
      if [ -z "${MAVEN_GPG_PASSPHRASE:-}" ]; then
        JAVA_GPG_PASSPHRASE_FILE="${MAVEN_GPG_PASSPHRASE_FILE:-${HOME}/.config/hyperprobe-java-sdk-gpg-passphrase}"
        if [ -r "$JAVA_GPG_PASSPHRASE_FILE" ]; then
          export MAVEN_GPG_PASSPHRASE="$(<"$JAVA_GPG_PASSPHRASE_FILE")"
        fi
      fi
      cd agents/java-sdk
      mvn clean deploy -DskipTests -B "${MAVEN_SETTINGS_ARGS[@]}"
    )
    JAVA_PUBLISHED=1
  fi

  # RubyGems publishing is temporarily disabled.
  # # Publish Ruby SDK
  # echo "Publishing Ruby SDK to RubyGems..."
  # (cd agents/ruby-sdk && bash publish_rubygems.sh --yes)
  # RUBY_PUBLISHED=1
else
  echo "[5/6] Skipping publishing phase based on SHOULD_PUBLISH env var."
fi

# 6. Publish Docker Platform and VSCode Extension
if [ "$SHOULD_PUBLISH" = "yes" ]; then
  echo "[6/6] Publishing deployment artifacts (Docker & VSCode Extension)..."

  cd deploy
  echo "Uploading Docker image via buildx..."
  aws ecr-public get-login-password --region us-east-1 | docker login --username AWS --password-stdin public.ecr.aws/hypertestco

  docker buildx build -f Dockerfile -t "$DOCKER_IMAGE_NAME" --platform linux/amd64,linux/arm64 --push .
  echo "Pushed $DOCKER_IMAGE_NAME image to ECR repository"
  DOCKER_PUBLISHED=1

  cd "$ROOT_DIR"
  echo "Uploading VSCode Extension to S3..."
  aws s3 cp "$VSIX_PATH" s3://hyperprobe-assets/vsc-plugin/
  S3_UPLOADED=1

  echo "Publishing VSCode Extension to Open VSX..."
  OVSX_PAT="$OVSX_PAT_VALUE" pnpm exec ovsx publish "$VSIX_PATH"
  OVSX_PAT_VALUE=""
else
  echo "[6/6] Skipping deployment artifact upload (SHOULD_PUBLISH != yes)..."
fi

echo "====================================="
echo "All builds and releases completed successfully!"
echo "====================================="
