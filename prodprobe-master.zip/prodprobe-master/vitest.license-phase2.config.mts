import { createRequire } from 'node:module';
import { fileURLToPath } from 'node:url';
import { defineConfig } from 'vitest/config';

const source = (path: string) => fileURLToPath(new URL(path, import.meta.url));
const externalRequire = createRequire(
  new URL('./external/licensing-server/package.json', import.meta.url),
);

export default defineConfig({
  root: source('.'),
  cacheDir: '/tmp/opencode/license-phase2-vitest',
  resolve: {
    alias: {
      '@hyperprobe/common': source('./packages/common/src/index.ts'),
      '@hyperprobe/constants': source('./packages/constants/index.ts'),
      'firebase-admin': externalRequire.resolve('firebase-admin'),
      jsonwebtoken: externalRequire.resolve('jsonwebtoken'),
      dotenv: externalRequire.resolve('dotenv'),
    },
  },
  test: {
    name: 'license-phase2',
    include: [
      'apps/backend/test/license-phase2/**/*.test.ts',
      'apps/vsc-extension/webview-ui/test/courier-config.test.ts',
    ],
    environment: 'node',
    setupFiles: [],
    globalSetup: [],
    fileParallelism: false,
    maxWorkers: 1,
    testTimeout: 10_000,
    restoreMocks: true,
    unstubGlobals: true,
    unstubEnvs: true,
  },
});
