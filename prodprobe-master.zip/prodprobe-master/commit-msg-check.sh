#!/bin/sh

# Run Commitlint to check the commit message
pnpm exec commitlint --config commitlint.config.cjs --edit "$1"
RESULT=$?

# If Commitlint fails, display the custom error message
if [ $RESULT -ne 0 ]; then
  echo "❌ Commit message format is incorrect."
  echo "Please follow the Conventional Commits format:"
  echo ""
  echo "<type>(<scope>(Optional)): <subject>"
  echo ""
  echo "Valid types include: feat, fix, docs, style, refactor, test, chore, revert, tmp"
  echo ""
  echo "Please ensure the subject is at least 5 characters long."
  echo ""
  echo "Example:"
  echo "  feat(instrumentation): add pg instrumentation"
  echo "  fix(auth): resolve login bug"
  echo "See https://www.conventionalcommits.org for more information."
  exit 1
fi

exit 0

